export default [
  {
    path: '/',
    exact: true,
    component: () => import('../components/splash'),
  },
];
