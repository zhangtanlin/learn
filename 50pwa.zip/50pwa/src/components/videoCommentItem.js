import React, { useEffect, useMemo, useRef, useState } from "react";
import Hammer from "hammerjs";
import Avatar from "./avatar";
import StackStore from "../store/stack";
import zan_white from "../resources/img/public/zan_white.png";
import zan_red from "../resources/img/public/zan_red.png";
import more_white from "../resources/img/public/more_white.png";
import comment from "../resources/img/public/comment.png";
import "../resources/css/videoCommentItem.less";
import { mvCommentsLike } from "../libs/http";

export default (props) => {
  const { item, onTap, onPause } = props;
  const [zanNum, setZanNum] = useState(item.like_num);
  const [isZan, setIsZan] = useState(item.is_like);
  const [stacks] = StackStore.useGlobalState("stacks");
  const zanRef = useRef(null);
  const commentRef = useRef(null);
  useEffect(() => {
    if (!commentRef.current) {
      return;
    }
    const commentHammer = new Hammer(commentRef.current);
    commentHammer.on("tap", openComment);
    return () => {
      commentHammer.off("tap", openComment);
    };
  }, [commentRef.current]);
  useEffect(() => {
    if (!zanRef.current) {
      return;
    }
    const zanHammer = new Hammer(zanRef.current);
    zanHammer.on("tap", onZan);
    return () => {
      zanHammer.off("tap", onZan);
    };
  }, [zanRef.current, isZan, zanNum]);
  const openComment = () => {
    onTap && onTap();
  };
  const onZan = () => {
    if (isZan) {
      setZanNum(zanNum - 1);
    } else {
      setZanNum(zanNum + 1);
    }
    setIsZan(!isZan);
    mvCommentsLike({ commentId: item.id });
  };
  return (
    <div className="video-comment-item">
      <Avatar
        img={item.member.thumb}
        uuid={item.uuid}
        isCreater={item.member.auth_status}
        onTap={() => {
          onPause && onPause();
        }}
      />
      <div className="comment-right" ref={commentRef}>
        <div className="flex-row flex-rowBtw">
          <span className="comment-name">{item.member.nickname}</span>
          <span className="flex-row" ref={zanRef}>
            <img className="comment-icon" src={isZan ? zan_red : zan_white} />
            <span className="comment-name">{zanNum}</span>
          </span>
        </div>
        <div className="comment-content">{item.comment}</div>
        <div className="flex-row flex-rowBtw">
          <span className="comment-time">{item.created_at}</span>
          <div className="flex-row">
            <span className="flex-row">
              <img className="comment-icon" src={comment} />
              <span className="comment-name">0</span>
            </span>
            <img
              className="comment-icon"
              style={{ marginRight: 0, marginLeft: 20 }}
              src={more_white}
            />
          </div>
        </div>
      </div>
    </div>
  );
};
