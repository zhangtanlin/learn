import React, {useEffect, useRef, useState} from "react";
import "../../resources/css/videoGroupPopup.less"
import emit from "../../libs/eventEmitter";
import {
  createDatingGroup, createVideoGroup, getDatingGroupList, getVideoGroupList, unlockCartoonEpisode, unlockDating
} from "../../libs/http";
import edit from "../../resources/img/public/edit.png"
import StackStore from "../../store/stack";
import StackPage from "../stackpage";
import MyMember from "../user/myMember";
import Emit from "../../libs/eventEmitter";
import unselected from "../../resources/img/public/unselected.png"
import selected from "../../resources/img/public/selected.png"
import UserStore from "../../store/user";

const getIsAutoBuyCartoon = () => {
  return JSON.parse(localStorage.getItem("isAutoBuyCartoon") ?? 'false')
}

const updateIsAutoBuyCartoon = (status = false) => {
  localStorage.setItem("isAutoBuyCartoon", JSON.stringify(status))
}
const UnlockCartoonAlert = () => {
  const [show, setShow] = useState(false)
  const [buyPrice, setBuyPrice] = useState(0)
  const [stacks] = StackStore.useGlobalState("stacks");
  const [isAutoBuyCartoon, setIsAutoBuyCartoon] = useState(getIsAutoBuyCartoon())
  const id = useRef(undefined)
  const episodeNumber = useRef(undefined)
  const [user] = UserStore.useGlobalState("user");

  const onMember = () => {
    setShow(false)
    const stackKey = `user-member-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push", payload: {
        name: "user-member", element: (<StackPage
          stackKey={stackKey}
          key={stackKey}
          style={{zIndex: stacks.length + 2}}
        >
          <MyMember stackKey={stackKey}/>
        </StackPage>),
      },
    });
  };

  useEffect(() => {
    const fn = (data) => {
      setShow(true)
      id.current = data.detail.id
      episodeNumber.current = data.episode.episode
      setBuyPrice(data.episode.view_money)
    }
    emit.on("showUnlockCartoonAlert", fn)

    return () => {
      emit.off("showUnlockCartoonAlert", fn)
    }
  }, [])

  const buy = () => {
    unlockCartoonEpisode({id: id.current, episode: episodeNumber.current})
      .then(res => {
        if (res.status !== 200) {
          Emit.emit("showToast", {text: res.msg});
        } else {
          Emit.emit("onUnlockCartoonAlertSuccess")
          Emit.emit("showToast", {text: "购买成功"});
        }
        setShow(false)
      })
  }

  return <div className={"VideoGroupPopup cartoon"} style={{display: show ? 'flex' : 'none'}}>
    <div className={"mask"} onClick={() => setShow(false)}></div>
    <div className={"VideoGroupPopup-content"}>
      <p className={"VideoGroupPopup-title"}>您有灰币：<span>{user.coins}</span></p>
      <div className={"VideoGroupPopup-submit"} onClick={buy}><span>{buyPrice}灰币购买</span></div>
      <div className={"VideoGroupPopup-radio"} onClick={() => {
        updateIsAutoBuyCartoon(!isAutoBuyCartoon)
        setIsAutoBuyCartoon(!isAutoBuyCartoon)
      }}><img src={isAutoBuyCartoon ? selected : unselected}/><span>下话自动购买</span>
      </div>
    </div>
  </div>
}


export default UnlockCartoonAlert
