import React, {useEffect, useRef, useState} from "react";
import "../../resources/css/videoGroupPopup.less"
import emit from "../../libs/eventEmitter";
import {
  createDatingGroup, createVideoGroup, getDatingGroupList, getVideoGroupList, unlockDating
} from "../../libs/http";
import edit from "../../resources/img/public/edit.png"
import StackStore from "../../store/stack";
import StackPage from "../stackpage";
import MyMember from "../user/myMember";
import Emit from "../../libs/eventEmitter";
import UserStore from "../../store/user";

const UnlockDatingAlert = () => {
  const [show, setShow] = useState(false)
  const [buyPrice, setBuyPrice] = useState(0)
  const [stacks] = StackStore.useGlobalState("stacks");
  const [user] = UserStore.useGlobalState("user");
  const id = useRef(undefined)

  const onMember = (type = 0) => {
    setShow(false)
    const stackKey = `user-member-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push", payload: {
        name: "user-member", element: (<StackPage
          stackKey={stackKey}
          key={stackKey}
          style={{zIndex: stacks.length + 2}}
        >
          <MyMember stackKey={stackKey} type={type}/>
        </StackPage>),
      },
    });
  };

  const coinsUnlock = () => {
    unlockDating({id: id.current})
      .then(res => {
        if (res.status !== 200 || res.data?.status === 600) {
          Emit.emit("showToast", {text: res.msg});
        } else {
          Emit.emit("onUnlockDatingAlertSuccess")
          Emit.emit("showToast", {text: "解锁成功"});
        }
        setShow(false)
      })
  }

  useEffect(() => {
    const fn = (data) => {
      setShow(true)
      id.current = data.id
      setBuyPrice(data.buy_price)
    }
    emit.on("showUnlockDatingAlert", fn)

    return () => {
      emit.off("showUnlockDatingAlert", fn)
    }
  }, [])

  return <div className={"VideoGroupPopup"} style={{display: show ? 'flex' : 'none'}}>
    <div className={"mask"} onClick={() => setShow(false)}></div>
    <div className={"VideoGroupPopup-content"}>
      <p>温馨提示</p>
      { user.vip ? <pre>支付{buyPrice}汤币即可解锁当前联系方式<br/></pre> : <pre>支付{buyPrice}汤币即可解锁当前联系方式<br/>开通VIP可免费解锁所有帖子联系方式</pre> }
      { user.vip ? <div></div> : <div className={"VideoGroupPopup-submit"} onClick={() => onMember(0)}><span>开通VIP</span></div> }
      <div className={"VideoGroupPopup-submit"} style={{backgroundColor: "#ffa55a"}} onClick={coinsUnlock}>
        <span>汤币解锁</span></div>
    </div>
  </div>
}


export default UnlockDatingAlert
