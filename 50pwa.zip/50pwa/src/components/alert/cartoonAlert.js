import React, {useEffect, useRef, useState} from "react";
import "../../resources/css/videoGroupPopup.less"
import emit from "../../libs/eventEmitter";
import {
  createDatingGroup, createVideoGroup, getDatingGroupList, getVideoGroupList, unlockDating
} from "../../libs/http";
import edit from "../../resources/img/public/edit.png"
import StackStore from "../../store/stack";
import StackPage from "../stackpage";
import MyMember from "../user/myMember";
import Emit from "../../libs/eventEmitter";
import wenxintishi from "../../resources/img/public/wenxinntishi.png"

const CartoonAlert = () => {
  const [show, setShow] = useState(false)
  const [buyPrice, setBuyPrice] = useState(0)
  const [stacks] = StackStore.useGlobalState("stacks");
  const id = useRef(undefined)
  const [isSimple, setIsSimple] = useState(false)

  const onMember = (type = 0) => {
    setShow(false)
    const stackKey = `user-member-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push", payload: {
        name: "user-member", element: (<StackPage
          stackKey={stackKey}
          key={stackKey}
          style={{zIndex: stacks.length + 2}}
        >
          <MyMember stackKey={stackKey} type={type}/>
        </StackPage>),
      },
    });
  };

  useEffect(() => {
    const fn = (data) => {
      setIsSimple(Boolean(data?.isSimple ?? false))
      setShow(true)
    }
    emit.on("showCartoonAlert", fn)

    return () => {
      emit.off("showCartoonAlert", fn)
    }
  }, [])

  return <div className={"VideoGroupPopup"} style={{display: show ? 'flex' : 'none'}}>
    <div className={"mask"} onClick={() => setShow(false)}></div>
    <div className={"VideoGroupPopup-content"}>
      <img src={wenxintishi} style={{position: "absolute", width: "100%", left: 0, top: "-79%"}}/>
      {
        isSimple === false && <p style={{fontSize: "15px"}}>您的金币不足，快去充值吧</p>
      }
      <div className={"VideoGroupPopup-submit"} onClick={() => onMember(0)} style={{marginTop: isSimple ? '1rem' : ''}}>
        <span>开通VIP免费看</span></div>
      {
        isSimple === false &&
        <div className={"VideoGroupPopup-submit"} style={{backgroundColor: "#ffa55a"}} onClick={() => onMember(1)}>
          <span>充值金币</span></div>
      }
    </div>
  </div>
}


export default CartoonAlert
