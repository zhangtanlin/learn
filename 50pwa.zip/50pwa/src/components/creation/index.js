import React, { useEffect, useMemo, useRef, useState } from "react";
import StackStore from "../../store/stack";
export default (props) => {
  const { isVisible } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const [pageStatus, setPageStatus] = useState(0);
  useEffect(() => {
    if (isVisible && pageStatus === 0) {
      setPageStatus(2);
    }
  }, [isVisible]);
  return (
    <div className={`positioned-container ${isVisible ? "visible" : "hide"}`}>
      创作
    </div>
  );
};
