import React, {useEffect, useRef, useState} from "react";
import Hammer from "hammerjs";

import StackStore from "../store/stack";
import UserStore from "../store/user";

import Featured from "./featured";
import Category from "./category";
import Weitie from "./weitie";
import Game from "./game";
import Creation from "./creation";
import User from "./user";
import FeaturedIcon from "../resources/img/BottomIcon/featured.png";
import FeaturedIconActive from "../resources/img/BottomIcon/featuredActive.png";
import CategoryIcon from "../resources/img/BottomIcon/category.png";
import CategoryIconActive from "../resources/img/BottomIcon/categoryActive.png";
import DatingIcon from "../resources/img/BottomIcon/dating.png";
import DatingIconActive from "../resources/img/BottomIcon/datingActive.png";
import WeitieIcon from "../resources/img/BottomIcon/weitie.png";
import GameIcon from '../resources/img/BottomIcon/game.png'
import GameIconActive from '../resources/img/BottomIcon/gameActive.png'
import WeitieIconActive from "../resources/img/BottomIcon/weitieActive.png";
import UserIcon from "../resources/img/BottomIcon/user.png";
import UserIconActive from "../resources/img/BottomIcon/userActive.png";
import "../resources/orientationchange-fix.min.js";
import Alert from "./alert";
import Toast from "./toast";
import {getUserInfo, getReportType, getHomeConfig} from "../libs/http";
import globalVar from "../libs/globalVar";
import Emit from "../libs/eventEmitter";
import "../libs/defendCC";
import Announcement from "./announcement";
import GameAlert from './gameAlert';
import Loading from "./loading";
import UpdatePwa from "./updatePwa";
import Acitvity from './acitvity';
import Dating from "./dating";
import CityPicker from "./cityPicker";
import VideoGroupPopup from "./group/videoGroupPopup";
import DatingGroupPopup from "./group/datingGroupPopup";
import UnlockDatingAlert from "./alert/unlockDatingAlert";
import UnlockCartoonAlert from "./alert/unlockCartoonAlert";
import CartoonAlert from "./alert/cartoonAlert";
import CartoonGroupPopup from "./group/cartoonGroupPopup";
import EditGroupPopup from "./group/editGroupPopup";
import StackPage from "./stackpage";
import CartoonDetail from "./cartoon/cartoonDetail";
import CartoonView from "./cartoon/cartoonView";
import AllCreative from "./creative/allCreative";
import MyBuy from "./user/myBuy";

export default () => {
  const [stacks] = StackStore.useGlobalState("stacks");
  const [initApp, setAppStatus] = useState(false); //初始化
  const [showAnnouncement, setShowAnnouncement] = useState(false);
  const [notice, setNotice] = useState(null);
  // eslint-disable-next-line no-unused-vars
  const [horizontalScreen, setScreen] = useState(false); //是否横屏
  const [pageStatus, setPageStatus] = useState(0);
  const [versionMsg, setVersionMsg] = useState(null);
  const [tabs, setTabs] = useState([
    {
      name: "精选",
      icon: FeaturedIcon,
      iconActive: FeaturedIconActive
    },
    {
      name: "发现",
      icon: CategoryIcon,
      iconActive: CategoryIconActive
    },
    {
      name: "约炮",
      icon: DatingIcon,
      iconActive: DatingIconActive
    },
    {
      name: "社区",
      icon: WeitieIcon,
      iconActive: WeitieIconActive
    },
    {
      name: "我的",
      icon: UserIcon,
      iconActive: UserIconActive
    }
  ])

  // useEffect(() => {
  //   const stackKey = `user-buy-${new Date().getTime()}`;
  //   StackStore.dispatch({
  //     type: "push",
  //     payload: {
  //       name: "user-buy",
  //       element: (
  //         <StackPage
  //           stackKey={stackKey}
  //           key={stackKey}
  //           style={{zIndex: stacks.length + 2}}
  //         >
  //           <MyBuy stackKey={stackKey}/>
  //         </StackPage>
  //       ),
  //     },
  //   });
  // }, [])

  // useEffect(() => {
  //   const readCartoon = (episode) => {
  //     const a = {
  //       "id": 26,
  //       "recommend_title": "用户推荐的第19部漫画",
  //       "title": "岳母家的刺激生活（完结）",
  //       "description": "（完结）什么..!! 炮友怀孕了..?!而丈母娘居然是我儿时的初恋对象?!这命运的玩笑有点儿开大了..",
  //       "author": "TEAM.serious",
  //       "categories": "连载",
  //       "bg_thumb": "https://new.milu888.link/images/mh",
  //       "thumb": "https://new.milu888.link/images/mh/data/cover/26.jpg",
  //       "re_thumb": "",
  //       "tags": "剧情",
  //       "is_free": 0,
  //       "adult": 1,
  //       "finished": 0,
  //       "images_count": 5369,
  //       "views_count": 151967062,
  //       "favorites": 41,
  //       "likes_count": 392362,
  //       "view_money": 20,
  //       "download_money": 1,
  //       "status": 0,
  //       "update_time": "周日",
  //       "free_time": 1572796799,
  //       "recommend": 0,
  //       "index_recommend": 0,
  //       "obtained": 1,
  //       "from": 0,
  //       "created_at": "2022-02-19 10:00:05",
  //       "updated_at": "2022-07-26 16:24:01",
  //       "series": 50,
  //       "pay_num": 0,
  //       "construct_id": 0,
  //       "editor_sort": 0,
  //       "is_like": 0,
  //       "isfree": 0,
  //       "tip1": "连载-50话",
  //       "finished_str": "连载中",
  //       "likes_count_str": "39W+",
  //       "views_count_str": "1亿+"
  //     }
  //     const stackKey = `CartoonView-${new Date().getTime()}`;
  //     StackStore.dispatch({
  //       type: "push", payload: {
  //         name: "CartoonView", element: (<StackPage
  //           stackKey={stackKey}
  //           key={stackKey}
  //           style={{zIndex: stacks.length + 2}}
  //         >
  //           <CartoonDetail
  //             stackKey={stackKey}
  //             id={a.id}
  //             title={a.title}
  //           />
  //         </StackPage>),
  //       },
  //     });
  //   }
  //
  //   readCartoon()
  // }, [])

  const httpString = s => {
    //var reg = /(http:\/\/|https:\/\/)((\w|=|\?|\.|\/|&|-)+)/g;
    var reg = /(https?|http|ftp|file):\/\/[-A-Za-z0-9+&@#/%?=~_|!:,.;]+[-A-Za-z0-9+&@#/%=~_|]/g;
    s = s.match(reg);
    return s;
  };
  const [selectName, setSelectName] = useState("精选");
  const [selectParams, setSelectParams] = useState({});
  const [loading, setLoading] = useState(true);
  const getData = async () => {
    try {
      const homeData = await getHomeConfig();
      const userData = await getUserInfo();
      const reportData = await getReportType();

      if (homeData.data) {
        if (homeData.data?.pwa_game) {
          tabs.splice(3, 0,
            {
              name: "游戏",
              icon: GameIcon,
              iconActive: GameIconActive,
            },
          )
          setTabs([...tabs])
        }
        setVersionMsg(homeData.data.versionMsg);
        setNotice(homeData.data.notice);
        setShowAnnouncement(true);
        setLoading(false);
        globalVar.officialGroup = homeData?.data?.config?.official_group; // 官方群
        globalVar.agentRules = homeData?.data?.config?.agent_url; // 代理规则h5地址
        globalVar.upload_img_ticket = homeData?.data?.config?.img_upload_url; //图片上传地址
        globalVar.upload_img_key = homeData?.data?.config?.upload_img_key; // 图片上传key
        if (homeData?.data?.pop_ads) {
          if (homeData?.data?.pop_ads?.length > 0) {
            globalVar.activity = homeData.data.pop_ads;
            Emit.emit("activityAlert")
          }
        }
      }
      if (userData.data) {
        globalVar.uuid = userData.data.uuid;
        globalVar.aff_url_copy = userData.data.aff_url_copy;
        globalVar.downloadUrl = userData.data.center.url;
        globalVar.isBindMobile = userData.data.phone;
        // globalVar.isBindMobile=true
        const daily_view = initDaily_view();
        const tempObject = {
          ...userData.data,
          ...{daily_view}
        }; // 字段说明参考userStore
        UserStore.dispatch({
          type: "replace",
          payload: tempObject
        });
      }

      if (reportData.data) {
        globalVar.reportType = reportData.data;
      }
    } catch (e) {
      Emit.emit("changeAlert", {
        _title: "提示",
        _content: "请求失败！请稍后重试！",
        _submitText: "确定",
        _notDouble: true
      });
      // console.log("e", e);
    }
  };

  useEffect(() => {
    // let token = localStorage.getItem("50_token");
    // if (token) {
    //   globalVar.token = token;
    // }
    if (!globalVar.bodyFontSize) {
      globalVar.bodyFontSize = parseInt(
        document.documentElement.style.fontSize.replace("px", "")
      );
    }
    setPageStatus(2);
    if (!initApp) {
      setAppStatus(true);
      // detectionScreen();
      window.addEventListener(
        "orientationchange",
        function () {
          // console.log(document.body.clientWidth);
          if (window.neworientation.current === "portrait") {
            // console.log("-------------竖屏--------------");
            setScreen(false);
          } else {
            // console.log("**************横屏*************");
            setScreen(true);
          }
        },
        false
      );
    }
    document.body.addEventListener(
      "touchmove",
      event => {
        event.preventDefault();
      },
      {
        passive: false
      }
    );
    getData();
  }, []);
  const homeTabBarRef = useRef(null);
  useEffect(() => {
    if (!homeTabBarRef.current) return;

    const hometabitems = Array.from(homeTabBarRef.current.getElementsByClassName(
      "home-tab-item"
    ));
    const hammers = [];
    hometabitems.forEach(hti => {
      const hammer = new Hammer(hti);
      hammer.on("tap", () => {
        const name = hti.getAttribute("data-name");
        setSelectName(name);
      });
      hammers.push(hammer);
    });
    return () => {
      hammers.forEach(hammer => {
        hammer.off("tap");
      });
    };
  }, [homeTabBarRef.current, pageStatus, tabs]);
  useEffect(() => {
    Emit.on("CHANGE_HOME_TAB", (name, params) => {
      setSelectName(name);
      setSelectParams(params ?? {});
    });
    return () => {
      Emit.off("CHANGE_HOME_TAB");
    };
  }, []);
  // 初始化观看次数
  const initDaily_view = () => {
    let daily_view = 1;
    const SET = () => {
      const data = {
        daily_view: 1,
        day: new Date().getDate()
      };
      localStorage.setItem("DAILY_VIEW", JSON.stringify(data));
    };
    let res = localStorage.getItem("DAILY_VIEW");
    // console.log("DAILY_VIEW", res);
    if (!res) {
      SET();
    } else {
      const result = JSON.parse(res);
      if (result.day != new Date().getDate()) {
        SET();
      } else {
        daily_view = result.daily_view;
      }
    }
    return daily_view;
  };
  return pageStatus === 0 ? null : (
    <div className="container">
      <div className="full-column">
        {loading ? (
          <div
            style={{
              display: "flex",
              flex: 1,
              alignItems: "center",
              justifyContent: "center",
              backgroundColor: "#282828"
            }}
          >
            <Loading show text="数据准备中..."/>
          </div>
        ) : (
          <>
            <Featured isVisible={selectName === "精选"}/>
            <Category isVisible={selectName === "发现"} {...selectParams}/>
            <Game isVisible={selectName === "游戏"}/>
            <Weitie isVisible={selectName === "社区"}/>
            <Dating isVisible={selectName === "约炮"}/>

            {/* <Creation isVisible={selectName === "创作"} /> */}
            <User isVisible={selectName === "我的"}/>
          </>
        )}
      </div>
      <div className="home-tab-bar" ref={homeTabBarRef}>
        {tabs.map(t => (
          <div
            data-name={t.name}
            className={`home-tab-item ${selectName === t.name ? "selected" : ""
            }`}
            key={`home-tab-item-${t.name}`}
          >
            <img src={selectName === t.name ? t.iconActive : t.icon}/>
            <p>{t.name}</p>
          </div>
        ))}
      </div>
      <div className="stack-pages-container">{stacks.map(s => s.element)}</div>
      <Alert/>
      <Toast/>
      {/*TODO  开发完成需要取消注释  否则广告不会弹出来*/}
      <Acitvity/>
      <Announcement
        show={notice && showAnnouncement}
        content={
          notice &&
          notice.content.replaceAll(
            httpString(notice.content),
            `<a href="${httpString(
              notice.content
            )}" target="_blank">${httpString(notice.content)}</a>`
          )
        }
        title={notice && notice.title}
        onClose={setNotice}
        type={notice && notice.type}
      />
      {versionMsg != null && (
        <UpdatePwa
          text={versionMsg.tips}
          url={versionMsg.apk}
          remotelyVersion={versionMsg.version}
        />
      )}
      <CityPicker></CityPicker>
      <GameAlert/>
      <VideoGroupPopup></VideoGroupPopup>
      <DatingGroupPopup></DatingGroupPopup>
      <UnlockDatingAlert></UnlockDatingAlert>
      <UnlockCartoonAlert></UnlockCartoonAlert>
      <CartoonAlert></CartoonAlert>
      <CartoonGroupPopup></CartoonGroupPopup>
      <EditGroupPopup></EditGroupPopup>
    </div>
  );
};
