import React, { useEffect, useMemo, useRef, useState } from "react";
import BackHeader from "../components/backHeader";
export default props => {
  const { url, stackKey, title } = props;
  const [loading, setLoading] = useState(true);
  const iframeRef = useRef(null);
  useEffect(() => {
    if (!iframeRef.current) return;
    iframeRef.current.onload = () => {
      setLoading(false);
    };
  }, [iframeRef.current]);
  return useMemo(
    () => (
      <div className="webview-page">
        <BackHeader title={title} stackKey={stackKey} />
        {loading ? (
          <div className="webview-loading">
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
          </div>
        ) : (
          ""
        )}
        <iframe
          ref={iframeRef}
          style={{
            transition: "all 0.5s ease-in",
            opacity: loading ? "0" : "1",
            width: "100%",
            height: "100%"
          }}
          src={url}
          frameBorder="0"
        ></iframe>
      </div>
    ),
    [loading]
  );
};
