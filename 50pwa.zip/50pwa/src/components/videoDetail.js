import React, {useEffect, useMemo, useRef, useState} from "react";
import Hammer from "hammerjs";
import StackStore from "../store/stack";
import ScrollArea from "./scrollarea";
import "../resources/css/videoDetail.less";
import Emit from "../libs/eventEmitter";
import StackPage from "./stackpage";
import jubao from "../resources/img/public/jubao_video.png";
import coin from "../resources/img/public/coin.png";
import like from "../resources/img/public/video_detail_like.png";
import liked from "../resources/img/public/video_detail_like_red.png";
import lookMore from "../resources/img/public/video_detail_more.png";
import shang from "../resources/img/public/video_detail_shang.png";
import heji from "../resources/img/public/video_detail_com.png";
import right from "../resources/img/public/right_black.png";
import write from "../resources/img/public/video_detail_send.png";
import share from "../resources/img/public/video_detail_more_share.png";
import jubaoNormal from "../resources/img/public/jubao_normal.png";
import jubaoRed from "../resources/img/public/jubao_checked_red.png";
import shop_bg from "../resources/img/public/shop_bg.png";
import money_white from "../resources/img/public/money_white.png";
import backWhite from "../resources/img/public/backWhite.png";
import videoShare from "../resources/img/public/icon_preview_free_share.png";
import huibiIcon from "../resources/img/public/iconn_video_list_pay.png";
import vipIcon from "../resources/img/public/icon_video_list_vip.png";

import Avatar from "./avatar";
import ScrollH from "./horizontal_scroller";
import ShareLayer from "./shareLayer";
import BottomLayer from "./bottomLayer";
import CommentInput from "./commentInput";
import VideoCommentItem from "./videoCommentItem";
import Loading from "./loading";
import NoData from "./noData";
import WantAv from "./featured/wantAv";
import Dashang from "./dashang";
import WebView from "./webview";
import {Swiper, SwiperSlide} from "swiper/react";
import SwiperCore, {Controller} from "swiper";
import "swiper/swiper.min.css";
import {
  getMvDetail,
  followUp,
  setMvLike,
  getTagMvList,
  getMvReportType,
  reportMv,
  getMvComments,
  pushComment,
  buyMv,
  findMv,
  getPlayPurView,
  getUserInfo
} from "../libs/http";
import ClickBtn from "./clickBtn";
import Simg from "./simg";
import VideoDetail from "./videoDetail";
import UserPage from "./category/user_page";
import MyMember from "./user/myMember";
import Qiupian_Detail from "./weitie/qiupian/qiupian_detail";
import VideoPlayer from "./videoPlayer";
import UserStore from "../store/user";
import VideoLoading from "./videoLoading";
import emit from "../libs/eventEmitter";

SwiperCore.use([Controller]);
export default props => {
  const [firstShow, setFirstShow] = useState(false);
  const {stackKey, id} = props;
  const [tabIndex, setTabIndex] = useState(0);
  const [controlledSwiper, setControlledSwiper] = useState(null);
  const [stacks] = StackStore.useGlobalState("stacks");
  const [user] = UserStore.useGlobalState("user");
  const saveRef = useRef(null);
  const likeRef = useRef(null);
  const wantRef = useRef(null);
  const shangRef = useRef(null);
  const hejiRef = useRef(null);
  const videoRef = useRef(null);
  const [isSave, setIsSave] = useState(false);
  const [isLike, setIsLike] = useState(false);
  const [showInput, setShowInput] = useState(false);
  const [showLayer, setShowLayer] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [videoStatus, setVideoStatus] = useState(true);
  const [detail, setDetail] = useState(null);
  const [commentList, setCommentList] = useState([]);
  const [showBottomLayer, setShowBottomLayer] = useState(false);
  const [showBuyLayer, setShowBuyLayer] = useState(false);
  const [currentTag, setCurrentTag] = useState("");
  const [chooseJubao, setChooseJubao] = useState(-1);
  const [showJubao, setShowJubao] = useState(false);
  const [jubaoList, setJubaoList] = useState(["广告", "未成年", "强奸/迷奸/偷拍"]);
  const [shouldPlay, setShouldPlay] = useState(false);
  const [isPreview, setIsPreview] = useState(false);
  const [overLoading, setOverLoading] = useState(false);
  const [showBack, setShowBack] = useState(true);
  const [videoUrl, setVideoUrl] = useState("");
  useEffect(() => {
    if (!saveRef.current) {
      return;
    }
    const saveHammer = new Hammer(saveRef.current);
    const likeHammer = new Hammer(likeRef.current);
    const wantHammer = new Hammer(wantRef.current);
    const shangHammer = new Hammer(shangRef.current);
    saveHammer.on("tap", onSave);
    likeHammer.on("tap", onLike);
    wantHammer.on("tap", onWantAv);
    shangHammer.on("tap", onDaShang);
    return () => {
      saveHammer.off("tap", onSave);
      likeHammer.off("tap", onLike);
      wantHammer.off("tap", onWantAv);
      shangHammer.off("tap", onDaShang);
    };
  }, [saveRef.current, likeRef.current, wantRef.current, shangRef.current, isSave, isLike]);
  useEffect(() => {
    getDetail();
  }, []);
  const getDetail = () => {
    getMvDetail({id}).then(res => {
      const {is_club, is_pay, isfree} = res.data.detail;
      setIsLoading(false);
      setDetail(res.data);
      setIsSave(res.data.detail.member.is_follow);
      setIsLike(res.data.detail.is_like);
      if (isfree || is_pay || is_club) {
        // getVideoUrl(res.data.detail.source_240, (url) => {
        //   setVideoUrl(url);
        // });
        setVideoUrl(res.data.detail.source_240);
      }
      if (res.data.comment.length > 0) {
        setCommentList(res.data.comment);
      }
      if (is_club || is_pay) {
        // 是粉丝团或者购买过，直接看
        setShouldPlay(true);
        setVideoStatus(false);
      } else if (res.data.detail.preview_video) {
        setIsPreview(true);
        setVideoUrl(res.data.detail.preview_video);
        setShouldPlay(true);
        setVideoStatus(false);
      } else if (isfree) {
        // 是免费片
        if (user.vip_level) {
          // 是会员
          setShouldPlay(true);
          setVideoStatus(false);
        } else {
          // 判断是否有免费次数
          getPlayPurView({id: res.data.detail.id})
            .then(res => {
              // console.log("res", res);
              if (res.data.daily_view) {
                setShouldPlay(true);
                // 扣次数，存本地,改状态
                const DAILY_VIEW = {
                  daily_view: 0, day: new Date().getDate()
                };
                localStorage.setItem("DAILY_VIEW", JSON.stringify(DAILY_VIEW));
                const tempObject = {
                  ...user, ...{daily_view: 0}
                }; // 字段说明参考userStore
                UserStore.dispatch({
                  type: "replace", payload: tempObject
                });
              }
              setVideoStatus(false);
            })
            .catch(err => {
              // console.log("err", err);
              setVideoStatus(false);
            });
        }
      } else {
        setVideoStatus(false);
      }
      // console.log("detail", res);
    });
  };
  useEffect(() => {
    if (showJubao) {
      Emit.emit("changeAlert", {
        _title: "举报视频", _content: (<div className="video-detail-jubao">
          <p>若该视频包含以下内容，你可以在此举报</p>
          <div>
            {jubaoList.map((item, index) => {
              return jubaoItem(item, index);
            })}
          </div>
        </div>), _submitText: "确定", _cancel: () => {
          setShowJubao(false);
        }, _submit: () => {
          // console.log(jubaoList[chooseJubao]);
          if (jubaoList[chooseJubao]) {
            reportMv({
              content: jubaoList[chooseJubao], mv_id: detail.detail.id
            });
            Emit.emit("showToast", {text: "举报成功！"});
          } else {
            Emit.emit("showToast", {text: "请选择举报内容"});
          }
          setShowJubao(false);
        }, _notDouble: true
      });
    }
  }, [showJubao, chooseJubao]);
  useEffect(() => {
    if (!hejiRef.current) {
      return;
    }
    const hejiHammer = new Hammer(hejiRef.current);
    hejiHammer.on("tap", showHejiList);
    return () => {
      hejiHammer.off("tap", showHejiList);
    };
  }, [hejiRef.current]);
  const onSave = () => {
    setIsSave(!isSave);
    followUp({follow_uuid: detail.detail.member.uuid});
  };
  const onLike = () => {
    if (isLike) {
      setIsLike(!isLike);
      setMvLike({id: detail.detail.id});
      return
    }
    const fn = (data) => {
      if (data.id === -1) {
        setIsLike(!isLike);
        setMvLike({id: detail.detail.id});
      } else {
        setIsLike(!isLike);
        setMvLike({id: detail.detail.id, group_id: data.id});
      }
      emit.off("onVideoGroupPopupSubmit", fn)
    }
    emit.on("onVideoGroupPopupSubmit", fn)
    emit.on("onVideoGroupPopupClose", () => emit.off("onVideoGroupPopupSubmit", fn))
    emit.emit("showVideoGroupPopup")
  };
  const onWantAv = async () => {
    setOverLoading(true);
    let findData = await findMv({vid: detail.detail.id});
    setOverLoading(false);
    // console.log("findData", findData);
    if (findData.data.forward_create == 1) {
      const mvData = {
        id: detail.detail.id,
        cover: detail.detail.thumb_cover,
        title: detail.detail.title,
        nickname: detail.detail.member.nickname,
        playNum: detail.detail.count_play_str,
        duration: detail.detail.duration_str
      };
      const stackKey = `WantAv-${new Date().getTime()}`;
      videoRef.current && videoRef.current.pause();
      StackStore.dispatch({
        type: "push", payload: {
          name: "WantAv", element: (<StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{zIndex: stacks.length + 2}}
          >
            <WantAv stackKey={stackKey} mvData={mvData}/>
          </StackPage>)
        }
      });
    } else if (findData.data.forward_create == 2) {
      Emit.emit("changeAlert", {
        _title: "温馨提示", _content: "已有求片正在排队审核了哦～", _submitText: "确定", _notDouble: true
      });
    } else {
      videoRef.current && videoRef.current.pause();
      const stackKey = `Qiupian_Detail-${new Date().getTime()}`;
      StackStore.dispatch({
        type: "push", payload: {
          name: "Qiupian_Detail", element: (<StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{zIndex: stacks.length + 2}}
          >
            <Qiupian_Detail stackKey={stackKey} id={findData.data.find_id}/>
          </StackPage>)
        }
      });
    }
  };
  const onDaShang = () => {
    videoRef.current && videoRef.current.pause();
    const stackKey = `Dashang-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push", payload: {
        name: "Dashang", element: (<StackPage
          stackKey={stackKey}
          key={stackKey}
          style={{zIndex: stacks.length + 2}}
        >
          <Dashang
            stackKey={stackKey}
            member={detail.detail.member}
            id={detail.detail.id}
          />
        </StackPage>)
      }
    });
  };
  const onJubao = () => {
    getMvReportType().then(res => {
      // console.log(res);
      setJubaoList(res.data);
    });
    setShowJubao(true);
  };
  const showHejiList = () => {
    setCurrentTag("collect");
    setShowBottomLayer(true);
  };
  const jubaoItem = (text, index) => {
    return (<div
      className="video-detail-jubao-item"
      key={index}
      onClick={() => {
        // console.log(index);
        setChooseJubao(index);
      }}
    >
      <img src={chooseJubao == index ? jubaoRed : jubaoNormal}/>
      <span
        style={{
          color: chooseJubao == index ? "#f1bc8d" : "#878799"
        }}
      >
          {text}
        </span>
    </div>);
  };
  const renderVideo = () => {
    return (<ClickBtn
      className="video-box"
      onTap={() => {
        if (shouldPlay) {
          setShowBack(!showBack);
        }
      }}
    >
      <div
        className={`pinduoduo-vd-back ${showBack ? "pinduoduo-vd-back-show" : "pinduoduo-vd-back-hide"}`}
        onClick={() => {
          Emit.emit(stackKey, stackKey);
        }}
      >
        <img src={backWhite}/>
      </div>
      {videoStatus ? (<VideoLoading/>) : shouldPlay ? (!videoUrl ? (<VideoLoading/>) : (<div
        style={{
          position: "relative", height: "100%"
        }}
      >
        <VideoPlayer
          auto={true}
          src={videoUrl}
          videoRef={videoRef}
          onPause={() => {
          }}
          thumb={detail.detail.thumb_cover}
          onEnd={() => {
            console.log("播放结束");
            if (!firstShow && isPreview) {
              setFirstShow(true);
              Emit.emit("changeAlert", {
                _title: "温馨提示",
                _content: detail.detail.isfree ? "还有更多精彩内容哦！开通会员即可观看完整版～" : `还有更多精彩内容哦！支付${detail.detail.coins}汤币购买即可观看完整版`,
                _submitText: detail.detail.isfree ? "立即开通" : "立即购买",
                _submit: () => {
                  if (detail.detail.isfree) {
                    toMyMember(0);
                  } else {
                    setShowBuyLayer(true);
                  }
                },
                _notDouble: true
              });
            }
          }}
          onErr={err => {
            Emit.emit("showToast", {
              text: "视频加载失败~", time: 3000
            });
          }}
        />
        {isPreview && (<ClickBtn
          styles={{
            fontSize: "0.38rem",
            height: "0.7rem",
            borderRadius: "0.35rem",
            lineHeight: "0.7rem",
            background: "rgba(0,0,0,0.7)",
            padding: "0 0.38rem",
            position: "absolute",
            top: "50%",
            left: "50%",
            zIndex: "999",
            transform: "translate(-50%, -50%)"
          }}
          onTap={() => {
            if (!detail.detail.isfree) {
              setShowBuyLayer(true);
            } else {
              toMyMember(0);
            }
          }}
        >
          <div
            style={{
              color: "#ffffff"
            }}
          >
            {detail?.detail?.preview_tip}
          </div>
        </ClickBtn>)}
      </div>)) : (videolayer())}
    </ClickBtn>);
  };
  const videolayer = () => {
    if (!detail) {
      return;
    }
    if (!detail.detail.isfree) {
      return (<div className="videoDetail-videolayer">
        <p className="videoDetail-videolayer-title">
          当前为用户发布的收费视频
        </p>
        <div className="videoDetail-videolayer-btn">
          <ClickBtn
            onTap={() => {
              setShowBuyLayer(true);
            }}
          >
            <img src={huibiIcon}/>
            <span>支付{detail.detail.coins}灰币</span>
          </ClickBtn>
        </div>
        <ClickBtn
          onTap={() => {
            toUserPage(detail.detail.member.uuid);
          }}
          className="videoDetail-videolayer-tips"
        >
          <span>加入粉丝团 免费看片</span>
        </ClickBtn>
      </div>);
    }
    return (<div className="videoDetail-videolayer">
      <p className="videoDetail-videolayer-title">免费观看次数已用尽</p>
      <div className="videoDetail-videolayer-btn">
        <ClickBtn
          onTap={() => {
            toMyMember(0);
          }}
        >
          <img src={vipIcon}/>
          <span>充值VIP</span>
        </ClickBtn>
        <ClickBtn
          onTap={() => {
            setShowLayer(true);
          }}
        >
          <img src={videoShare}/>
          <span>分享无限看</span>
        </ClickBtn>
      </div>
    </div>);
  };
  const swiperTitle = () => {
    const commentNum = detail?.detail?.count_comment || 0;
    return (<div className="video-swiper-title">
      <div>
          <span
            className={tabIndex == 0 ? "active" : ""}
            onClick={() => {
              setTabIndex(0);
              controlledSwiper.slideTo(0);
            }}
          >
            简介
          </span>
        <span
          className={tabIndex == 1 ? "active" : ""}
          onClick={() => {
            setTabIndex(1);
            controlledSwiper.slideTo(1);
          }}
        >
            评论{commentNum}
          </span>
      </div>
      <div onClick={onJubao}>
        <img src={jubao}/>
        <span>举报</span>
      </div>
    </div>);
  };
  const toWebView = (url, title) => {
    window.open(url, "_blank");
  };

  const renderHeji = () => {
    return (<div className="video-detail-heji">
      <div ref={hejiRef} className="heji-title">
        <div>
          <img src={heji}/>
          <p>{detail.collect.row.title}</p>
        </div>
        <img src={right}/>
      </div>
      <ScrollH>
        {detail.collect.list.map((item, index) => {
          return <HejiItem item={item} key={index} index={index + 1}/>;
        })}
      </ScrollH>
    </div>);
  };
  const recommend = () => {
    return (<div className="info-recommend">
      <p className="info-recommend-title">为你推荐</p>
      {detail.recommend.map((item, index) => {
        return <VideoItem item={item} key={index}/>;
      })}
      <div style={{height: "1.4rem"}}/>
    </div>);
  };
  const toUserPage = uuid => {
    videoRef.current && videoRef.current.pause();
    const stackKey = `userpage-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push", payload: {
        name: "userpage", element: (<StackPage
          stackKey={stackKey}
          key={stackKey}
          style={{zIndex: stacks.length + 2}}
        >
          <UserPage stackKey={stackKey} uuid={uuid}/>
        </StackPage>)
      }
    });
  };
  const renderInfo = () => {
    return (<div className="video-detail-swiper-item">
      <ScrollArea downRefresh={false} ListData={1}>
        <div className="info-top">
          <div className="info-userItem">
            <div className="info-row">
              <Avatar
                img={detail.detail.member.thumb}
                uuid={detail.detail.member.uuid}
                onTap={() => {
                  videoRef.current && videoRef.current.pause();
                }}
                isCreater={detail.detail.member.auth_status}
                boxClass="userItem-avatarbox"
                avatarClass="info-avatar"
              />
              <ClickBtn
                onTap={() => {
                  toUserPage(detail.detail.member.uuid);
                }}
              >
                <div className="userItem-info">
                  <p>{detail.detail.member.nickname}</p>
                  <div>
                    {detail.detail.member.taggroup_name}
                    <span className="info-point">·</span>
                    {detail.detail.member.followed_count}粉丝
                    <span className="info-point">·</span>
                    {detail.detail.member.videos_count}视频
                  </div>
                </div>
              </ClickBtn>
            </div>
            <div
              className={isSave ? "info-isLike" : "info-like"}
              ref={saveRef}
            >
              {isSave ? "已关注" : "关注"}
            </div>
          </div>
          <p className="info-title">{detail.detail.title}</p>
          <div className="info-tagList">
            {!detail.detail.isfree && (<TagItem type={0} coins={detail.detail.coins}/>)}
            {detail.detail.tags.map((item, index) => {
              return (<TagItem
                text={item}
                type={1}
                key={index}
                onTap={() => {
                  setCurrentTag(item);
                  setShowBottomLayer(true);
                }}
              />);
            })}
          </div>
          <p className="info-time">
            {detail.detail.count_play_str}
            <span className="info-point">·</span>
            {detail.detail.count_like}赞<span className="info-point">·</span>
            {detail.detail.created_at}发布
          </p>
          <div className="info-btn-box">
            <div className="info-btn-item" ref={likeRef}>
              <img src={isLike ? liked : like}/>
              <span className={isLike ? "info-liked" : ""}>喜欢</span>
            </div>
            <div className="info-btn-item" ref={wantRef}>
              <img src={lookMore}/>
              <span>求续集</span>
            </div>
            <div className="info-btn-item" ref={shangRef}>
              <img src={shang}/>
              <span>打赏</span>
            </div>
          </div>
        </div>
        {detail.collect.list && detail.collect.list.length > 0 && renderHeji()}
        {detail.banner && detail.banner.length > 0 && (<div className="info-ad">
          <ClickBtn
            onTap={() => {
              const type = detail.banner[0].type;
              if (type == 1 || type == 2) {
                toWebView(detail.banner[0].url, "");
              }
            }}
          >
            <div className="info-ad-img">
              <Simg src={detail.banner[0].img_url}/>
            </div>
          </ClickBtn>
        </div>)}
        {detail.recommend && detail.recommend.length > 0 && recommend()}
      </ScrollArea>
    </div>);
  };

  const renderFooter = () => {
    const {isfree, is_pay} = detail.detail;
    return (<div className="video-detail-footer">
      <div className="footer-left">
        <div
          onClick={() => {
            setShowInput(true);
          }}
        >
          <img src={write}/>
          <span>优质评论优先展示</span>
        </div>
        <img src={isLike ? liked : like} onClick={onLike}/>
      </div>
      {!isfree ? (<div
        className="footer-right buy-btn"
        onClick={() => {
          if (is_pay) {
            Emit.emit("showToast", {
              text: "您已购买过该片，无需再次购买！"
            });
          } else {
            setShowBuyLayer(true);
          }
        }}
      >
        <span>马上购买</span>
      </div>) : (<div
        className="footer-right"
        onClick={() => {
          setShowLayer(true);
        }}
      >
        <img src={share}/>
        <span>无限看</span>
      </div>)}
    </div>);
  };
  const toMyMember = type => {
    const stackKey = `MyMember-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push", payload: {
        name: "MyMember", element: (<StackPage
          stackKey={stackKey}
          key={stackKey}
          style={{zIndex: stacks.length + 2}}
        >
          <MyMember stackKey={stackKey} type={type}/>
        </StackPage>)
      }
    });
  };
  const setUserData = async () => {
    const res = await getUserInfo();
    const tempObject = {
      ...res.data, ...{daily_view: user.daily_view}
    }; // 字段说明参考userStore
    UserStore.dispatch({
      type: "replace", payload: tempObject
    });
  };
  const buyAvBody = () => {
    return (<div className="video-detail-buyLayer">
      <img className="buyLayer-bg" src={shop_bg}/>
      <div className="buyLayer-body">
        <p>当前为创作者发布的收费视频</p>
        <span className="buyLayer-moneyNum">
            <span>{detail.detail.coins}</span>
            灰币
          </span>
        <div
          className="buyLayer-btn"
          onClick={() => {
            setShowBuyLayer(false);
            setOverLoading(true);
            buyMv({mv_id: detail.detail.id}).then(res => {
              // console.log("buyMv", res);
              setOverLoading(false);
              let title = "灰币余额不足，立即充值";
              let subText = "灰币充值";
              if (res.data.code == 0) {
                setVideoStatus(true);
                title = "购买成功";
                subText = "确定";
                setIsPreview(false);
                setShouldPlay(true);
                // getVideoUrl(res.data.url, (url) => {
                //   setVideoUrl(url);
                // });
                setVideoUrl(res.data.url);
                setUserData();
                setVideoStatus(false);
              } else if (res.data.code == 2) {
                title = "请不要重复购买";
                subText = "确定";
              }
              Emit.emit("changeAlert", {
                _title: "温馨提示", _content: title, _submitText: subText, _submit: () => {
                  if (res.data.code == 1) {
                    toMyMember(1);
                  }
                }, _notDouble: true
              });
            });
          }}
        >
          <img src={money_white}/>
          <span>立即支付</span>
        </div>
        <span
          className="buyLayer-tip"
          onClick={() => {
            Emit.emit("changeAlert", {
              _title: "温馨提示", _content: "请下载APP使用上传功能", _submitText: "确定", _notDouble: true
            });
          }}
        >
            {"我也要发片赚钱 >"}{" "}
          </span>
      </div>
    </div>);
  };
  return (<div className="page-content-flex">
    {renderVideo()}
    {/* {isPreview && (
        <div
          style={{
            fontSize: "0.32rem",
            display: "flex",
            flexDirection: "row",
            margin: "0.3rem 0.4rem 0 0.4rem"
          }}
        >
          <span
            style={{
              color: "#999999"
            }}
          >
            正在播放预览视频,
          </span>
          <ClickBtn
            onTap={() => {
              if (!detail.detail.isfree) {
                setShowBuyLayer(true);
              } else {
                toMyMember(0);
              }
            }}
          >
            <div
              style={{
                color: "#fd5c18"
              }}
            >
              {detail?.detail?.preview_tip}
            </div>
          </ClickBtn>
        </div>
      )} */}
    <div
      style={{
        display: "flex", flexDirection: "column", flex: 1
      }}
    >
      {swiperTitle()}
      {isLoading ? (<Loading show text={""} overSize={false} size={25}/>) : detail ? (<Swiper
        className={"video-detail-swiper"}
        // edgeSwipeThreshold={100}
        // longSwipesMs={500}
        controller={{control: controlledSwiper}}
        onSwiper={setControlledSwiper}
        onSlideChange={e => {
          setTabIndex(e.activeIndex);
        }}
      >
        <SwiperSlide>{renderInfo()}</SwiperSlide>
        <SwiperSlide>
          <RenderComment
            commentList={commentList}
            mv_id={detail.detail.id}
            onTap={() => {
              setShowInput(true);
            }}
            onPause={() => {
              videoRef.current && videoRef.current.pause();
            }}
          />
        </SwiperSlide>
      </Swiper>) : (<NoData/>)}
    </div>
    {detail && renderFooter()}
    {showInput && (<CommentInput
      onClose={() => {
        setShowInput(false);
      }}
      onSubmit={value => {
        if (!value) {
          Emit.emit("showToast", {text: "请输入内容！"});
        } else {
          pushComment({mv_id: detail.detail.id, comment: value}).then(res => {
            Emit.emit("showToast", {text: res.msg});
          });
        }
      }}
    />)}
    {detail && (<ShareLayer
      show={showLayer}
      info={detail.detail}
      onTap={() => {
        setShowLayer(false);
      }}
    />)}

    {detail && (<BottomLayer
      show={showBottomLayer}
      onTap={() => {
        setShowBottomLayer(false);
      }}
    >
      <TagList
        title={currentTag}
        show={showBottomLayer}
        collectData={detail.collect}
        onTap={() => {
          setShowBottomLayer(false);
        }}
      />
    </BottomLayer>)}
    {/* 购买弹窗 */}
    {detail && (<BottomLayer
      show={showBuyLayer}
      onTap={() => {
        setShowBuyLayer(false);
      }}
      notList
    >
      {buyAvBody()}
    </BottomLayer>)}
    {overLoading && <Loading show overSize size={30}/>}
  </div>);
};

const RenderComment = props => {
  const {commentList, mv_id, onTap, onPause} = props;
  const [data, setData] = useState([]);
  const [scollStatus, setScollStatus] = useState(null);
  const [loadingMore, setLoadingMore] = useState({a: true});
  useEffect(() => {
    if (commentList.length > 0) {
      setData(commentList);
    }
  }, [commentList]);
  useEffect(() => {
    if (scollStatus) {
      getData();
    }
  }, [scollStatus]);
  const getData = () => {
    if (!loadingMore.a) return;
    getMvComments({mv_id, lastId: data[data.length - 1].id}).then(res => {
      // console.log("getMvComments=>", data[data.length - 1].id, res.data);
      if (res.data.length > 0) {
        setData(pre => [...pre, ...res.data]);
      } else {
        loadingMore.a = false;
        setLoadingMore({...loadingMore});
      }
    });
  };

  if (commentList.length == 0) {
    return <NoData text="好想被你填满"/>;
  }
  return (<div className="video-detail-swiper-item">
    <ScrollArea
      ListData={data}
      onScrollEnd={() => {
        setScollStatus(new Date());
      }}
      loadingMore={loadingMore.a}
    >
      {data.map((k, i) => {
        return (<VideoCommentItem
          item={k}
          key={i}
          onTap={onTap}
          onPause={onPause}
        />);
      })}
      <div style={{height: "1.7rem"}}/>
    </ScrollArea>
  </div>);
};

const HejiItem = props => {
  const {index, item} = props;
  const hejiRef = useRef(null);
  const [stacks] = StackStore.useGlobalState("stacks");
  useEffect(() => {
    if (!hejiRef.current) {
      return;
    }
    const hejiHammer = new Hammer(hejiRef.current);
    hejiHammer.on("tap", jump);
    return () => {
      hejiHammer.off("tap", jump);
    };
  }, [hejiRef.current]);
  const jump = () => {
    const stackKey = `VideoDetail-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "replace", payload: {
        name: "VideoDetail", element: (<StackPage
          stackKey={stackKey}
          key={stackKey}
          style={{zIndex: stacks.length + 2}}
        >
          <VideoDetail stackKey={stackKey} id={item.id}/>
        </StackPage>)
      }
    });
  };
  return (<div className="heji-item" ref={hejiRef}>
    <div className="heji-item-cover">
      <div className="heji-item-cover-img">
        <Simg src={item.thumb_cover}/>
      </div>
      <span>{index}</span>
      <span>{item.duration_str}</span>
    </div>
    <p>{item.title}</p>
  </div>);
};

const VideoItem = props => {
  const {item} = props;
  const videoRef = useRef(null);
  const [stacks] = StackStore.useGlobalState("stacks");
  useEffect(() => {
    if (!videoRef.current) {
      return;
    }
    const videoHammer = new Hammer(videoRef.current);
    videoHammer.on("tap", jump);
    return () => {
      videoHammer.off("tap", jump);
    };
  }, [videoRef.current]);
  const jump = () => {
    const stackKey = `VideoDetail-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "replace", payload: {
        name: "VideoDetail", element: (<StackPage
          stackKey={stackKey}
          key={stackKey}
          style={{zIndex: stacks.length + 2}}
        >
          <VideoDetail stackKey={stackKey} id={item.id}/>
        </StackPage>)
      }
    });
  };
  return (<div className="info-videoItem" ref={videoRef}>
    <div className="info-videoCover">
      <div className="info-videoCover-img">
        <Simg src={item.thumb_cover}/>
      </div>
      <span>{item.duration_str}</span>
    </div>
    <div className="info-videoInfo">
      <p>{item.title}</p>
      <div>
        <span>{item.member.nickname}</span>
        <span>{item.count_play_str}</span>
      </div>
    </div>
  </div>);
};

const TagItem = props => {
  const {text, type, coins, onTap} = props;
  const tagRef = useRef(null);
  useEffect(() => {
    if (!tagRef.current) {
      return;
    }
    const tagHammer = new Hammer(tagRef.current);
    tagHammer.on("tap", onClick);
    return () => {
      tagHammer.off("tap", onClick);
    };
  }, [tagRef.current]);
  const onClick = () => {
    onTap && onTap();
  };
  if (type == 0) {
    return (<div className="tag-item1">
      <img src={coin}/>
      <span>{coins}</span>
    </div>);
  }
  return (<div className="tag-item" ref={tagRef}>
    #{text}
  </div>);
};

const TagList = props => {
  const {title, onTap, show, collectData} = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const [selfTitle, setSelfTitle] = useState("");
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState([]);
  const [loadingMore, setLoadingMore] = useState({a: true});
  let page = 1;
  useEffect(() => {
    if (show && title != "collect") {
      setSelfTitle(title);
      getData("init");
    } else if (show && title == "collect") {
      setSelfTitle(collectData.row.title);
      setData(collectData.list);
      setLoading(false);
      loadingMore.a = false;
      setLoadingMore({...loadingMore});
    }
  }, [show, title]);
  const getData = status => {
    if (!loadingMore.a) return;
    if (!status) {
      page++;
    }
    getTagMvList({page: page, name: title})
      .then(res => {
        // console.log("getTagMvList=>", page, res);
        setLoading(false);
        if (res.data.list.length > 0) {
          setData(pre => [...pre, ...res.data.list]);
        } else {
          if (page == 1) {
            setData([]);
          }
          loadingMore.a = false;
          setLoadingMore({...loadingMore});
        }
      })
      .catch(() => {
        setLoading(false);
      });
  };
  return (<div className="tag-list">
    <div className="tag-list">
      <div className="tag-border"/>
      <div className="tag-list-title">
        <span>关闭</span>
        <span>{selfTitle}</span>
        <span
          onClick={() => {
            onTap && onTap();
          }}
        >
            关闭
          </span>
      </div>
      <div className="tag-border"/>
      <div className="tag-list-list">
        {loading ? (<Loading show text={"正在获取数据..."} overSize={false} size={25}/>) : data.length > 0 ? (<ScrollArea
          ListData={data}
          onScrollEnd={getData}
          loadingMore={loadingMore.a}
          onScrollTop={() => {
            Emit.emit("CHANGE_MOVE_STATUS", true);
          }}
          scrollChange={() => {
            Emit.emit("CHANGE_MOVE_STATUS", false);
          }}
        >
          {data.map((item, index) => {
            return <VideoItem item={item} key={index}/>;
          })}
        </ScrollArea>) : (<NoData/>)}
      </div>
    </div>
  </div>);
};
