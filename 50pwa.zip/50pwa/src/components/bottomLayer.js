import React, { useEffect, useMemo, useRef, useState } from "react";
import "../resources/css/bottomLayer.less";
import Emit from "../libs/eventEmitter";
let shouldMove = true;
export default (props) => {
  const { show, onTap, children, notList } = props;
  const [hideSelf, setHideSelf] = useState(true);
  let initY = 0;
  let moveY = 0;
  const _height = document.getElementById("app").clientHeight;
  useEffect(() => {
    if (!notList) {
      Emit.on("CHANGE_MOVE_STATUS", onChange);
      return () => {
        Emit.off("CHANGE_MOVE_STATUS", onChange);
      };
    }
  }, []);
  useEffect(() => {
    if (show) {
      setHideSelf(false);
      setTimeout(() => {
        if (document && document.getElementsByClassName("bottom-layer")[0]) {
          document
            .getElementsByClassName("bottom-layer")[0]
            .classList.add("bottom-layer-show");
        }
      }, 100);
    } else {
      if (document && document.getElementsByClassName("bottom-layer")[0]) {
        document
          .getElementsByClassName("bottom-layer")[0]
          .classList.add("bottom-layer-hide");
      }
      setTimeout(() => {
        setHideSelf(true);
      }, 300);
    }
  }, [show]);
  const onChange = (status) => {
    shouldMove = status;
  };
  if (hideSelf) {
    return null;
  }
  return (
    <div className={`bottom-layer`}>
      <div
        className={"bottom-layer-close"}
        onClick={() => {
          onTap(false);
        }}
      />
      <div
        className={"bottom-layer-body"}
        onTouchStart={(e) => {
          initY = e.touches[0].pageY;
        }}
        onTouchEnd={() => {
          if (Math.abs(moveY) > _height * 0.2) {
            onTap(false);
            setTimeout(() => {
              document
                .getElementsByClassName("bottom-layer-body")[0]
                .setAttribute("style", "display:flex");
            }, 300);
          } else {
            document
              .getElementsByClassName("bottom-layer-body")[0]
              .setAttribute(
                "style",
                `transform: translateY(0px);transition: all 0.2s ease-in;`
              );
          }
          moveY = 0;
        }}
        onTouchMove={(e) => {
          let y = e.touches[0].pageY;
          if (!shouldMove && moveY == 0) {
            initY = e.touches[0].pageY;
          }
          if (y - initY > 0 && (shouldMove || moveY > 0)) {
            moveY = y - initY;
            document
              .getElementsByClassName("bottom-layer-body")[0]
              .setAttribute("style", `transform: translateY(${moveY}px);`);
          }
        }}
      >
        {children}
      </div>
    </div>
  );
};
