import axios from "axios";
import React, { useEffect, useMemo, useRef, useState } from "react";
import RcViewer from "rc-viewer";
import CryptoData from "../libs/CryptoData";
import Emit from "../libs/eventEmitter";
import global from "../libs/globalVar";
import logoWhitePng from "../resources/img/public/logoBg.png";
// eslint-disable-next-line import/no-unresolved
import ClickBtn from "./clickbtn";
export default (props) => {
  // noBg 不需要预加载图和背景 imgFinish图片准备完成
  const {
    className,
    isZoom,
    onTap,
    src,
    noBg,
    imgFinish,
    objectFit,
    isHorizontal,
    refreshScroll,
    alwaysShow,
  } = props;
  const [src_state, setSrc] = useState(logoWhitePng);
  const imgRef = useRef(null);
  const [preview, setPreview] = useState(null);
  const [isVisible, setIsVisible] = useState(false);
  useEffect(() => {
    if (refreshScroll && src_state !== logoWhitePng) {
      refreshScroll();
    }
  }, [src_state]);
  useEffect(() => {
    if (!preview) return;
    if (onTap) {
      onTap(() => {
        if (src_state === logoWhitePng) {
          Emit.emit("showToast", {
            text: "图片正在加载中...",
            time: 3000,
          });
          return;
        }
        preview.viewer.show();
      });
    }
  }, [onTap, preview, src_state]);
  useEffect(() => {
    if ((!src || !isVisible) && !alwaysShow) return;
    const SrcOfPwaDomain = src;
    const arraybufferToBase64 = function (t) {
      return new Promise((function (e) {
        const n = new Blob([t]);
        const r = new FileReader();
        r.onload = function (t) {
          const n = t.target.result;
          const r = n.substring(n.indexOf(",") + 1);
          e(r);
        };
        r.readAsDataURL(n);
      }));
    };
    // .replace(
    //   '/^http(s)?:\/\/(.*?)\//',
    //   "https://pwa.91tv.tv/"
    // );
    let ext = SrcOfPwaDomain.substring(SrcOfPwaDomain.lastIndexOf(".") + 1);
    ext = ext === "jpg" ? "jpeg" : ext;
    if ("jpg,jpeg,png,gif".indexOf(ext) == -1) return;
    axios.get(SrcOfPwaDomain, { responseType: 'arraybuffer' }).then((res) => {
      arraybufferToBase64(res.data).then(base64str => {
        const decryptStr = CryptoData.DecryptImage(base64str);
        fetch(`data:image/${ext};base64,${decryptStr}`).then(res => res.blob()).then(blob => {
          setSrc(URL.createObjectURL(blob));
        });
        imgFinish && imgFinish();
      });
    });
  }, [src, isVisible, alwaysShow]);
  useEffect(() => {
    const isInViewPort = () => {
      if (!global.bodyFontSize) {
        global.bodyFontSize = parseFloat(
          document.documentElement.style.fontSize
        );
      }
      const viewPortHeight =
        window.innerHeight ||
        document.documentElement.clientHeight ||
        document.body.clientHeight;
      const top =
        imgRef.current.getBoundingClientRect() &&
        imgRef.current.getBoundingClientRect().top;
      const right =
        imgRef.current.getBoundingClientRect() &&
        imgRef.current.getBoundingClientRect().right;
      const left =
        imgRef.current.getBoundingClientRect() &&
        imgRef.current.getBoundingClientRect().left;
      const bottom =
        imgRef.current.getBoundingClientRect() &&
        imgRef.current.getBoundingClientRect().bottom;
      const flag = isHorizontal
        ? left <= global.bodyFontSize * 10 + 100 && right > 0
        : top <= viewPortHeight + 100 && bottom > 0;
      if (!isVisible && flag) setIsVisible(flag);
    };
    if (imgRef.current && !isVisible) isInViewPort();
    if (!isVisible) {
      Emit.on("isInViewPortEvent", isInViewPort);
    } else {
      Emit.off("isInViewPortEvent", isInViewPort);
    }
    return () => {
      Emit.off("isInViewPortEvent", isInViewPort);
    };
  }, [imgRef.current, isVisible]);
  return useMemo(
    () => (isZoom ? (
      <ClickBtn
        styles={{
          width: "100%",
          height: "100%",
        }}
        onTap={() => {
          if (src_state === logoWhitePng) {
            Emit.emit("showToast", {
              text: "图片正在加载中...",
              time: 3000,
            });
            return;
          }
          preview.viewer.show();
        }}
      >
        <div
          className="no_point_event"
          styles={{
            width: "100%",
            height: "100%",
          }}
        >
          <RcViewer
            options={{ navbar: false }}
            ref={(v) => {
              setPreview(v);
            }}
            style={{
              width: "100%",
              height: "100%",
              display: "flex",
              flexDirection: "row",
              justifyContent: "center",
              alignItems: "center",
              background: "#4d4d4d",
            }}
          >
            <img
              ref={imgRef}
              className={className}
              src={src_state}
              style={{
                objectFit:
                  src_state === logoWhitePng
                    ? "contain"
                    : objectFit || "cover",
                width: src_state === logoWhitePng ? "40%" : "100%",

                height: src_state === logoWhitePng ? "40%" : "100%",
                opacity: noBg && src_state === logoWhitePng ? 0 : 1,
              }}
            />
          </RcViewer>
        </div>
      </ClickBtn>
    ) : (
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          flexDirection: "row",
          justifyContent: "center",
          alignItems: "center",
          background: "#4d4d4d",
        }}
      >
        <img
          ref={imgRef}
          className={className}
          src={src_state}
          style={{
            objectFit:
              src_state === logoWhitePng
                ? "contain"
                : objectFit || "cover",
            width: src_state === logoWhitePng ? "40%" : "100%",

            height: src_state === logoWhitePng ? "40%" : "100%",
            opacity: noBg && src_state === logoWhitePng ? 0 : 1,
          }}
        />
      </div>
    )),
    [src_state, preview]
  );
};
