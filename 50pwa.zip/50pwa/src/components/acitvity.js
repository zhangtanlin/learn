import React, { useEffect, useRef, useState } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import SwiperCore, { Autoplay } from "swiper/core";
import emit from "../libs/eventEmitter";
import Clickbtn from './clickbtn'
import "../resources/css/activity.less";
import "swiper/swiper.min.css";
import "swiper/components/pagination/pagination.min.css";
import Simg from '../components/simg'
import closeicon from '../resources/img/public/close_white.png'
import globalVar from "../libs/globalVar";
import StackStore from '../store/stack';
import StackPage from './stackpage';
import VideoDetail from '../components/videoDetail';
import MyMember from "./user/myMember";


SwiperCore.use([Autoplay]);
export default () => {
  const [hideSelf, setHideSelf] = useState(true);
  const [stacks] = StackStore.useGlobalState("stacks");

  useEffect(() => {
    emit.on(
      "activityAlert",
      () => {
        setHideSelf(false);
        setTimeout(() => {
          if (
            document &&
            document.getElementsByClassName("dialog_scaleLayer-02")[0]
          ) {
            document
              .getElementsByClassName("dialog_scaleLayer-02")[0]
              .classList.add("dialog_scale-in-02");
          }
        }, 100);
      })
    return () => {
      emit.off("activityAlert");
    };
  }, []);

  const onCloseNotice = () => {
    if (document && document.getElementsByClassName("dialog_scaleLayer-02")[0]) {
      document
        .getElementsByClassName("dialog_scaleLayer-02")[0]
        .classList.add("dialog_scale-out-02");
    }
    setTimeout(() => {
      setHideSelf(true);
    }, 300);
  }

  const toMvDetail = (value) => {
    const stackKey = `Search-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "Search",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <VideoDetail stackKey={stackKey} id={value} />
          </StackPage>
        ),
      },
    });
  };

  const toMyMember = (value) => {
    const stackKey = `Search-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "Search",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <MyMember stackKey={stackKey}/>
          </StackPage>
        ),
      },
    });
  };

  const onTapUrl = (item) => {
    console.log(item)
    if (item.type == 2) {
      window.open(item.url, "_blank");
    }
    if (item.type == 4) {
      toMvDetail(item.value)
      onCloseNotice()
    }
    if (item.type == 10) {
      toMyMember()
      onCloseNotice()
    }
  }

  if (hideSelf) {
    return null;
  }
  return (
    <div className="dialog_scaleLayer-02">
      <div
        className="dialog_scaleLayer-close-02"

      />
      <div className="dialog_scaleLayer-body-02">
        <div className="notice-container-02">

          <div className="notice-content-02" style={{ backgroundColor: 'transparent' }}>
            <Swiper
              initialSlide={0}
              className="featured-swiper"
              noSwipingClass={"noSwiper-container"}
              loop
              autoplay={ globalVar?.activity?.length == 1 ? false : {
                delay: 3000,
                disableOnInteraction: false
              }}
            >
              {globalVar.activity.map((item, index) => {
                return <SwiperSlide key={`${item}-${index}`}>
                  <Clickbtn onTap={() => {
                    onTapUrl(item)
                  }}>
                    <Simg className="swiper-img" src={item.img_url} noBg noThumb />
                  </Clickbtn>
                </SwiperSlide>
              })}
            </Swiper>
          </div>
          <Clickbtn className="notice-header-02" onTap={() => {
            onCloseNotice();
          }}>
            <img src={closeicon} />
          </Clickbtn>
        </div>
      </div>
    </div>
  );
};
