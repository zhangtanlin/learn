import React, {useEffect, useRef, useState} from "react";
import "../../resources/css/videoGroupPopup.less"
import emit from "../../libs/eventEmitter";
import {createVideoGroup, getVideoGroupList} from "../../libs/http";
import edit from "../../resources/img/public/edit.png"
import StackStore from "../../store/stack";
import StackPage from "../stackpage";
import GroupManage from "./index";
import Emit from "../../libs/eventEmitter";

const VideoGroupPopup = () => {
  const [show, setShow] = useState(false)
  const [currentGroupId, setCurrentGroupId] = useState(-1)
  const [dataList, setDataList] = useState([])
  const inputRef = useRef(undefined)
  const [stacks] = StackStore.useGlobalState("stacks");

  const getData = () => {
    getVideoGroupList()
      .then(res => {
        setDataList([{
          id: -1, name: "全部", sort: 0
        }, ...res.data.list])
      })
  }

  useEffect(() => {
    const fn = () => {
      getData()
      setShow(true)
    }
    emit.on("showVideoGroupPopup", fn)

    return () => {
      emit.off("showVideoGroupPopup", fn)
    }
  }, [])

  const onSubmit = () => {
    emit.emit("onVideoGroupPopupSubmit", {id: currentGroupId})
    inputRef.current.value = ""
    setCurrentGroupId(-1)
    setShow(false)
  }

  const onTextSubmit = async ({keyCode}) => {
    if (keyCode === 13) {
      const value = inputRef.current.value.trim()
      if (value.length === 0) {
        inputRef.current.value = value
        alert("分组名称不能为空")
        return
      }

      await createVideoGroup({title: value})
      inputRef.current.value = ""
      getData()
    }
  }

  const toGroupManage = () => {
    setShow(false)
    Emit.emit("onVideoGroupPopupClose")
    const stackKey = `GroupManage-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "GroupManage",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{zIndex: stacks.length + 2}}
          >
            <GroupManage stackKey={stackKey} type={0}/>
          </StackPage>
        ),
      },
    });
  }

  return <div className={"VideoGroupPopup"} style={{display: show ? 'flex' : 'none'}}>
    <div className={"mask"} onClick={() => setShow(false)}></div>
    <div className={"VideoGroupPopup-content"}>
      <p>选择分组</p>
      <div className={"VideoGroupPopup-tags"}>
        {dataList.map(value => {
          return <span key={value.id} className={`${currentGroupId === value.id ? 'active' : ''}`}
                       onClick={() => setCurrentGroupId(value.id)}>{value.name}</span>
        })}

        <span onClick={toGroupManage}>
          <img src={edit}/>
          <input ref={inputRef} placeholder={"自定义"} type={"text"} onKeyDown={onTextSubmit}/>
        </span>
      </div>
      <p className={"VideoGroupPopup-tips"} onClick={toGroupManage}>前去管理分组<span style={{fontSize: "1.8em"}}>›</span></p>
      <div className={"VideoGroupPopup-submit"} onClick={onSubmit}><span>确认</span></div>
    </div>
  </div>
}


export default VideoGroupPopup
