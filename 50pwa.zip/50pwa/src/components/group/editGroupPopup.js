import React, {useEffect, useRef, useState} from "react";
import "../../resources/css/videoGroupPopup.less"
import emit from "../../libs/eventEmitter";
import {
  createCartoonGroup, createDatingGroup,
  createVideoGroup,
  getCartoonGroupList,
  getDatingGroupList,
  getVideoGroupList, updateCartoonGroup, updateDatingGroup,
  updateVideoGroup
} from "../../libs/http";
import edit from "../../resources/img/public/edit.png"

const EditGroupPopup = () => {
  const [show, setShow] = useState(false)
  const inputRef = useRef(undefined)
  const id = useRef(undefined)
  const type = useRef(0)//type 0 1 2

  useEffect(() => {
    const fn = (data) => {
      const name = data.name
      const _id = data.id
      const _type = data.type
      inputRef.current.value = name
      id.current = _id
      type.current = _type
      setShow(true)
    }
    emit.on("showEditGroupPopup", fn)

    return () => {
      emit.off("showEditGroupPopup", fn)
    }
  }, [])

  const onSubmit = () => {
    emit.emit("onEditGroupPopupSubmit",)
    inputRef.current.value = ""
    setShow(false)
  }

  const updateGroup = ({title, id}) => {
    let apiUrl = ""
    switch (type.current) {
      case 0:
        apiUrl = updateVideoGroup
        break
      case 1:
        apiUrl = updateCartoonGroup
        break
      case 2:
        apiUrl = updateDatingGroup
        break
    }

    apiUrl({title, group_id: id})
      .then(res => {
        if (res.status === 200 || res.status === 251) {
          onSubmit()
        }
      })

  }

  const createGroup = ({title, id}) => {
    let apiUrl = ""
    switch (type.current) {
      case 0:
        apiUrl = createVideoGroup
        break
      case 1:
        apiUrl = createCartoonGroup
        break
      case 2:
        apiUrl = createDatingGroup
        break
    }

    apiUrl({title, group_id: id})
      .then(res => {
        if (res.status === 200 || res.status === 251) {
          onSubmit()
        }
      })

  }

  const onTextSubmit = async () => {
    const value = inputRef.current.value.trim()
    if (value.length === 0) {
      inputRef.current.value = value
      alert("分组名称不能为空")
      return
    }

    if (id.current){
      await updateGroup({title: value, id: id.current})
    }else {
      await createGroup({title: value, id: id.current})
    }
  }

  return <div className={"VideoGroupPopup"} style={{display: show ? 'flex' : 'none'}}>
    <div className={"mask"} onClick={() => setShow(false)}></div>
    <div className={"VideoGroupPopup-content"}>
      <p>编辑分组</p>
      <div className={"VideoGroupPopup-tags"}>
        <span style={{borderRadius:0}}>
          <input ref={inputRef} placeholder={"自定义"} type={"text"} style={{width:"5.6rem",height:"1rem"}}/>
        </span>
      </div>
      <div className={"VideoGroupPopup-submit"} onClick={onTextSubmit}><span>确认</span></div>
    </div>
  </div>
}


export default EditGroupPopup
