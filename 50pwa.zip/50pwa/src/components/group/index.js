import React, {useEffect, useState} from "react";
import BackHeader from "../backHeader";
import ScrollArea from "../scrollarea";
import {getCartoonGroupList, getDatingGroupList, getVideoGroupList} from "../../libs/http";
import "../../resources/css/groupManage.less"
import edit from "../../resources/img/public/edit.png";
import Emit from "../../libs/eventEmitter";

//type 0 视频 1 漫画 2 约炮
const GroupManage = ({stackKey, type = 0}) => {
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState([]);
  const [loadingMore, setLoadingMore] = useState({a: true});
  let page = 1;

  const getData = (status) => {
    if (!status) {
      page++;
    }

    setLoading(true)

    let apiUrl = ""
    switch (type) {
      case 0:
        apiUrl = getVideoGroupList
        break
      case 1:
        apiUrl = getCartoonGroupList
        break
      case 2:
        apiUrl = getDatingGroupList
        break
    }

    apiUrl()
      .then(res => {
        if (res.status === 200) {
          setData([...res.data.list])
        }
      })
      .finally(() => {
        setLoading(false)
        loadingMore.a = false;
        setLoadingMore({...loadingMore});
      })
  }

  useEffect(() => {
    getData("init")
  }, [])

  const toEdit = (data) => {
    const fn = () => {
      getData("init")
      Emit.off("onEditGroupPopupSubmit", fn)
    }
    Emit.on("onEditGroupPopupSubmit", fn)
    Emit.emit("showEditGroupPopup", {...data, type})
  }

  return <div className={"GroupManage"}>
    <BackHeader
      stackKey={stackKey}
      title="标签管理"
      right={() => {
        return <div onClick={() => toEdit({id: undefined, name: ""})}
                    style={{width: "1.8rem", color: "#ec5929", fontSize: "0.4rem"}}>添加分组</div>;
      }}
    />
    <ScrollArea ListData={data}
                onScrollEnd={getData}
                loadingMore={loadingMore.a}>
      <div className={"GroupManage-tags-wrap"}>
        {data.map((value, index) => {
          return <div key={index} className={"GroupManage-tags-wrap-item"}>
            <span>{value.name}</span>
            <span onClick={() => toEdit({name: value.name, id: value.id})}>
                <img src={edit}/>
                编辑
              </span>
          </div>
        })}
      </div>
    </ScrollArea>
  </div>
}


export default GroupManage
