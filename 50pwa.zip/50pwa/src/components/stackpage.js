/*
 * @Author: Tom
 * @Date: 2021-12-18 15:41:23
 * @LastEditTime: 2021-12-24 19:57:46
 * @LastEditors: Tom
 * @Description:
 * @FilePath: /50pwa/src/components/stackpage.js
 */
import React, { useEffect, useRef, useState } from "react";
import Hammer from "hammerjs";
import Emit from "../libs/eventEmitter";
import StackStore from "../store/stack";
// eslint-disable-next-line import/no-self-import
import StackPage from "./stackpage";

export default props => {
  const { style, children, stackKey } = props;
  const rootRef = useRef(null);
  const initialStyle = `z-index: ${style.zIndex};`;
  let moveX = 0;
  const setAttr = () => {
    if (rootRef.current) {
      rootRef.current.setAttribute(
        "style",
        `transform: translateX(0px); transition: all 0.5s;${initialStyle}`
      );
      setTimeout(() => {
        StackStore.dispatch({
          type: "pop"
        });
      }, 800);
    }
    Emit.removeListener(stackKey);
  };
  useEffect(() => {
    Emit.on(stackKey, setAttr);
    return () => {
      Emit.off(stackKey, setAttr);
    };
  }, [rootRef.current]);
  useEffect(() => {
    if (!rootRef.current) {
      return;
    }
    rootRef.current.setAttribute(
      "style",
      `transform: translateX(${-document.body
        .clientWidth}px); transition: all 0.5s;${initialStyle}`
    );
    window.addEventListener("resize", setElement)
    setElement()
    return () => window.removeEventListener("resize", setElement);
  }, [rootRef.current]);

  const setElement = () => {
    if (rootRef.current) {
      rootRef.current.setAttribute(
        "style",
        `transform: translateX(${-document.body
          .clientWidth}px); transition: all 0.4s cubic-bezier(0.25, 0.1, 0.25, 1);${initialStyle}`
      );
    }
  }
  // useEffect(() => {
  //   if (!slideBackRef.current || rootRef.current) return;
  //   const hammer = new Hammer(slideBackRef.current);
  //   const panmove = (e) => {
  //     // console.log("panmove", e.distance);
  //     if (e.distance > 0) {
  //       rootRef.current.setAttribute(
  //         "style",
  //         `transform: translateX(${e.distance}px);${initialStyle}`
  //       );
  //     }
  //   };
  //   const panend = (e) => {
  //     // console.log("panend", e.distance, document.body.clientWidth);
  //     const DURATION = 0.5;
  //     const MOVEPERCENT = e.distance / document.body.clientWidth;
  //     if (MOVEPERCENT > 0.5) {
  //       rootRef.current.setAttribute(
  //         "style",
  //         `transform: translateX(${
  //           document.body.clientWidth
  //         }px); transition: all ${
  //           0.5 - DURATION * MOVEPERCENT
  //         }s;${initialStyle}`
  //       );
  //       setTimeout(() => {
  //         StackStore.dispatch({
  //           type: "pop",
  //         });
  //       }, DURATION * 1000);
  //     } else {
  //       rootRef.current.setAttribute(
  //         "style",
  //         `transform: translateX(0px); transition: all ${
  //           0.5 - DURATION * MOVEPERCENT
  //         }s;${initialStyle}`
  //       );
  //     }
  //   };
  //   hammer.on("panmove", panmove);
  //   hammer.on("panend", panend);
  //   setTimeout(() => {
  //     setIsAnimated(false);
  //   }, 800);
  //   return () => {
  //     hammer.off("panmove", panmove);
  //     hammer.off("panend", panend);
  //   };
  // }, [slideBackRef.current, rootRef.current]);
  return (
    <div ref={rootRef} className="stack-page" style={style}>
      <div
        className="stack-page-slide-back"
        onTouchEnd={() => {
          let DURATION = 0.25;
          if (document.body.clientWidth > 400) {
            DURATION = 0.2;
          }
          const MOVEPERCENT = moveX / document.body.clientWidth;
          if (MOVEPERCENT > DURATION) {
            rootRef.current.setAttribute(
              "style",
              `transform: translateX(0px); transition: all ${0.3 -
                DURATION * MOVEPERCENT}s;${initialStyle}`
            );
            setTimeout(() => {
              StackStore.dispatch({
                type: "pop"
              });
            }, (0.3 - DURATION * MOVEPERCENT) * 1000);
          } else {
            rootRef.current.setAttribute(
              "style",
              `transform: translateX(${-document.body
                .clientWidth}px); transition: all ${0.3 -
                DURATION * MOVEPERCENT}s;${initialStyle}`
            );
          }
        }}
        onTouchMove={e => {
          moveX = e.touches[0].pageX;
          if (moveX > 0) {
            rootRef.current &&
              rootRef.current.setAttribute(
                "style",
                `transform: translateX(${moveX -
                  document.body.clientWidth}px);${initialStyle}`
              );
          }
        }}
      />
      {children}
    </div>
  );
};
