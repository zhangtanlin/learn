import React, {useEffect, useMemo, useRef, useState} from "react";
import Hammer from "hammerjs";
import StackStore from "../../store/stack";
import SearchHeader from "../searchHeader";
import ScrollArea from "../scrollarea";
import WebView from "../webview";
import playIcon from "../../resources/img/public/play.png";
import likeIcon from "../../resources/img/public/like.png";
import talkIcon from "../../resources/img/public/talk.png";
import shareIcon from "../../resources/img/public/share.png";
import featuredIcon from "../../resources/img/public/featured.png";
import fansIcon from "../../resources/img/public/fans.png";
import pindan from "../../resources/img/public/pindan.png";
import pintuan from "../../resources/img/public/pintuan.png";
import categoryIcon from "../../resources/img/public/categoryIcon.png";
import rightIcon from "../../resources/img/public/icon_mine_check_more.png";

import Avatar from "../avatar";
import VideoDetail from "../videoDetail";
import StackPage from "../stackpage";
import Loading from "../loading";
import NoData from "../noData";
import ScrollH from "../horizontal_scroller";
import Simg from "../simg";
import {ShareLayer} from "../pinduoduoVideoDetail";
import UserPage from "../category/user_page";
import ClickBtn from "../clickBtn";

import {featuredTab, getFeatureList, followUp, getHomeNewList, getAllCreativeList} from "../../libs/http";

import {Swiper, SwiperSlide} from "swiper/react";
import "swiper/swiper.min.css";
import "swiper/components/pagination/pagination.min.css";
import {Controller} from "swiper";
import SwiperCore, {Pagination, Autoplay} from "swiper/core";
import Emit from "../../libs/eventEmitter";
import {TwoColumnsVideo} from "../featured/twoColumnsVideo";
import BackHeader from "../backHeader";

// install Swiper modules
SwiperCore.use([Pagination, Autoplay, Controller]);
export default (props) => {
  const {index, current, stackKey, taggroup_id, title} = props;
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState([]);
  const [loadingMore, setLoadingMore] = useState({a: true});
  const [banner, setBanner] = useState(null);
  const [widget, setWidget] = useState(null);
  const [idol, setIdol] = useState(null);
  const [stacks] = StackStore.useGlobalState("stacks");
  let page = 1;
  let limit = 10;
  useEffect(() => {
    if (index == current && data.length == 0) {
      getData("init");
    }
  }, [current]);
  const getData = (status) => {
    if (!loadingMore.a) return;
    if (!status) {
      page++;
    }

    getAllCreativeList({page: page, size: 10, taggroup_id})
      .then(res => {
        if (!banner && res.data.banner) {
          setBanner(res.data.banner);
        }
        if (!widget && res.data.widget) {
          setWidget(res.data.widget);
        }
        if (res.data.idol) {
          setIdol(res.data.idol);
        }
        setLoading(false);
        if (res.data.list.length > 0) {
          setData((pre) => [...pre, ...res.data.list]);
        } else {
          if (page == 1) {
            setData([]);
          }
          loadingMore.a = false;
          setLoadingMore({...loadingMore});
        }
      })
      .catch(() => {
        setLoading(false);
      });
  };

  const renderHeader = () => {
    return <></>
    // return renderSwiper();
  };
  const renderSwiper = () => {
    if (!banner || banner.length == 0) {
      return null;
    }
    return (
      <Swiper
        pagination
        autoplay={{
          delay: 3000,
          disableOnInteraction: false,
        }}
        className="featured-wiper"
      >
        {banner.map((item, index) => {
          return (
            <SwiperSlide key={index}>
              <SwiperItem item={item}/>
            </SwiperSlide>
          );
        })}
      </Swiper>
    );
  };

  return (
    <div className={"positioned-container"}>
      <BackHeader
        stackKey={stackKey}
        title={title}
        right={() => {
          return <div style={{width: "1.2rem"}}/>;
        }}
      />
      {loading ? (
        <Loading show text={"正在获取数据..."} overSize={false} size={25}/>
      ) : data.length > 0 ? (
        <ScrollArea
          ListData={data}
          onScrollEnd={getData}
          loadingMore={loadingMore.a}
          pullDonRefresh={() => {
            page = 1;
            loadingMore.a = true;
            setData([]);
            setLoading(true);
            setLoadingMore({...loadingMore});
            getData("init");
          }}
        >
          {renderHeader()}
          {data.map((item, index) => {
            return <TwoColumnsVideo data={item} key={`TwoColumnsVideo-${index}`}/>;
          })}
          <div style={{height: "30px"}}/>
        </ScrollArea>
      ) : (
        <NoData/>
      )}
    </div>
  );
}
