import React, {useEffect, useMemo, useRef, useState} from "react";
import StackStore from "../../store/stack";
import "../../resources/css/category.less";
import {Swiper, SwiperSlide} from "swiper/react";
import SwiperCore, {Controller} from "swiper";
import ScrollArea from "../scrollarea";
import ClickBtn from "../clickBtn";
import SearchHead from "../searchHeader";
import RightContent from "./category_content";
import {getConcentrationList, getFeatureList, getMoreConcentrationList, getStyleTab} from "../../libs/http";
import Loading from "../loading";
import BackHeader from "../backHeader";
import HeaderTab from "../user/headerTab";
import {SeekVideo, SmallInfo} from "../user/myPost";
import everyday from "../../resources/img/public/everyday.png";
import StackPage from "../stackpage";
import EveryDayPage from "../featured/everday";
import {TwoColumnsVideo} from "../featured/twoColumnsVideo";
import {Concentration} from "../featured/concentration";
import moreIcon from "../../resources/img/public/more.png"
import Hammer from "hammerjs";
import Simg from "../simg";
import DatingDetail from "../dating/datingDetail";
import MoreConcentration from "../featured/concentration/moreConcentration";
import SearchPage from "../featured/search";
import searchIcon from "../../resources/img/public/search.png";
import NoData from "../noData";

SwiperCore.use([Controller]);
export default props => {
  const {isVisible, stackKey, defaultTab = 0} = props;
  const [categoreTab, setCategoreTab] = useState(1);
  const [initPage, setInitPage] = useState(false);
  const [pageStatus, setPageStatus] = useState(0);
  const [categoreList, setCategoreList] = useState(null);
  useEffect(() => {
    if (isVisible && pageStatus === 0) {
      setPageStatus(2);
    }
  }, [isVisible]);
  useEffect(() => {
    if (pageStatus !== 2) return;
    getStyleTab().then(res => {
      // console.log("分类", res);
      setCategoreList(res.data);
      setCategoreTab(res.data[0].id);
      setInitPage(true);
    });
  }, [pageStatus]);
  return (<div
    className={`category_page positioned-container ${isVisible ? "visible" : "hide"}`}
  >
    {useMemo(() => !initPage ? (<Loading show overSize={false}/>) : (
      <Bypass defaultTab={defaultTab} defaultCategoreTab={categoreTab} categoreList={categoreList}
              stackKey={stackKey}></Bypass>), [initPage, categoreTab, categoreList, defaultTab])}
  </div>);
};


const Bypass = ({defaultCategoreTab, categoreList, stackKey, defaultTab}) => {
  const [stacks] = StackStore.useGlobalState("stacks");
  const navList = [{name: '精选',}, {name: '分类',},];
  const [currentTab, setCurrentTab] = useState(defaultTab ?? 0);
  const [controlledSwiper, setControlledSwiper] = useState(null);
  const setSecondPage = (index) => {
    if (index === 1) {
      return <Category defaultCategoreTab={defaultCategoreTab} categoreList={categoreList}></Category>;
    }
    return <ConcentrationPage stackKey={stackKey}></ConcentrationPage>;
  };

  useEffect(() => {
    setCurrentTab(defaultTab ?? currentTab)
    if (controlledSwiper) {
      controlledSwiper.slideTo(defaultTab ?? currentTab);
    }
  }, [defaultTab])

  return useMemo(() => (<div className="positioned-container user-member user-member2">
    <BackHeader
      stackKey={stackKey}
      left={() => {
        return <div className={"searchHeader"}>
          <img
            className="searchHeader-everyday"
            src={everyday}
            onClick={() => {
              const stackKey = `EveryDayPage-${new Date().getTime()}`;
              StackStore.dispatch({
                type: "push", payload: {
                  name: "EveryDayPage", element: (<StackPage
                    stackKey={stackKey}
                    key={stackKey}
                    style={{zIndex: stacks.length + 2}}
                  >
                    <EveryDayPage stackKey={stackKey}/>
                  </StackPage>)
                }
              });
            }}
          />
        </div>
      }}
      center={() => (<HeaderTab
        style={{position: "relative"}}
        navItems={navList}
        currentIndex={currentTab}
        onChangeTab={(index) => {
          setCurrentTab(index);
          controlledSwiper && controlledSwiper.slideTo(index);
        }}
      />)}
      right={() => (
        <div
          className="searchHeader-input"
          style={{flex: "unset"}}
          onClick={() => {
            const stackKey = `SearchPage-${new Date().getTime()}`;
            StackStore.dispatch({
              type: "push",
              payload: {
                name: "SearchPage",
                element: (
                  <StackPage
                    stackKey={stackKey}
                    key={stackKey}
                    style={{zIndex: stacks.length + 2}}
                  >
                    <SearchPage stackKey={stackKey}/>
                  </StackPage>
                )
              }
            });
          }}
        >
          <img src={searchIcon}/>
          <span>搜索</span>
        </div>
      )}
    />
    <div className="user-member-content">
      <Swiper
        className="user-swiper"
        controller={{control: controlledSwiper}}
        onSwiper={setControlledSwiper}
        initialSlide={currentTab}
        autoplay={false}
        onSlideChange={e => {
          setCurrentTab(e.realIndex);
        }}
      >
        {navList.map((item, index) => (<SwiperSlide key={`user-post-swiper-${index}`}>
          {setSecondPage(index)}
        </SwiperSlide>))}
      </Swiper>
    </div>
  </div>), [navList, currentTab]);
}

const ConcentrationPage = ({stackKey}) => {
  const [dataList, setDataList] = useState([])
  const [loadingMore, setLoadingMore] = useState({a: true});
  const [loading, setLoading] = useState(true);
  const [banner, setBanner] = useState(null);
  const [stacks] = StackStore.useGlobalState("stacks");
  let page = 1;
  let limit = 10;

  useEffect(() => {
    getData("init")
  }, [])

  const getData = (status) => {
    if (!loadingMore.a) return;
    if (!status) {
      page++;
    }

    getConcentrationList({page: page})
      .then(res => {
        if (res.data.banner && res.data.banner.length !== 0) {
          setBanner(res.data.banner)
        }

        if (res.data.list.length > 0) {
          setDataList((pre) => [...pre, ...res.data.list]);
        } else {
          if (page == 1) {
            setDataList(() => [...dataList, ...res.data.list])
          }
          loadingMore.a = false;
          setLoadingMore({...loadingMore});
        }
      })
      .finally(() => {
        setLoading(false);
      })
  };

  const renderSwiper = () => {
    if (!banner || banner.length == 0) {
      return null;
    }
    return (<Swiper
      pagination
      autoplay={{
        delay: 3000, disableOnInteraction: false,
      }}
      className="featured-wiper"
    >
      {banner.map((item, index) => {
        return (<SwiperSlide key={index}>
          <SwiperItem item={item}/>
        </SwiperSlide>);
      })}
    </Swiper>);
  };

  const toMore = (value) => {
    const id = value.id
    const title = value.title
    const stackKey = `DatingDetail-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push", payload: {
        name: "DatingDetail", element: (<StackPage
          stackKey={stackKey}
          key={stackKey}
          style={{zIndex: stacks.length + 2}}
        >
          <MoreConcentration stackKey={stackKey} id={id} title={title}/>
        </StackPage>)
      }
    });
  }

  return (
    <>
      {loading ? (
        <Loading show text={"正在获取数据..."} overSize={false} size={25}/>
      ) : dataList.length > 0 ? (
        <ScrollArea
          ListData={dataList}
          onScrollEnd={getData}
          loadingMore={loadingMore.a}
          pullDonRefresh={() => {
            page = 1;
            loadingMore.a = true;
            setDataList([]);
            setLoading(true);
            setLoadingMore({...loadingMore});
            getData("init");
          }}
        >
          <div className={"ConcentrationPage"}>
            {renderSwiper()}
            {dataList.map((value, index) => {
              return <div key={index} style={{width: "100%", display: "flex", flexFlow: "wrap"}}>
                <div className={"ConcentrationPage-label"}>
                  <div className={"ConcentrationPage-label-left"}>
                    <span>{value.title}</span>
                    <span>{value.sub_title}</span>
                  </div>
                  <div className={"ConcentrationPage-label-right"} onClick={() => toMore(value)}>
                    <span>更多</span>
                    <img src={moreIcon}/>
                  </div>
                </div>

                {value.type !== 3 && value.values.map((value, index) => {
                  return <Concentration data={value} key={`Concentration-${index}`}></Concentration>
                })}

                {value.type === 3 && value.values.slice(0, 1).map((value, index) => {
                  return <Concentration type={1} data={value} key={`Concentration-${index}`}></Concentration>
                })}

                {value.type === 3 && value.values.slice(1, value.values.length).map((value, index) => {
                  return <Concentration data={value} key={`Concentration-${index}`}></Concentration>
                })}

              </div>
            })}
          </div>
          <div style={{height: "30px"}}/>
        </ScrollArea>
      ) : (
        <NoData/>
      )}
    </>
  );
}

const SwiperItem = (props) => {
  const {item} = props;
  const itemRef = useRef(null);
  const [stacks] = StackStore.useGlobalState("stacks");
  const _width = document.body.clientWidth;
  useEffect(() => {
    if (!itemRef.current) {
      return;
    }
    const itemHammer = new Hammer(itemRef.current);
    itemHammer.on("tap", onClick);
    return () => {
      itemHammer.off("tap", onClick);
    };
  }, [itemRef.current]);
  const onClick = () => {
    //跳外部
    if ((item.type == 1 || item.type == 2) && item.url) {
      toWebView(item.url, "");
    }
  };
  const toWebView = (url, title) => {
    window.open(url, "_blank");
  };
  return (<div
    style={{
      width: _width, height: _width * 0.35,
    }}
    ref={itemRef}
  >
    <Simg className="no-hammers" src={item.img_url}/>
  </div>);
};

const Category = ({defaultCategoreTab, categoreList}) => {
  const [stacks] = StackStore.useGlobalState("stacks");
  const [categoreSwiper, setCategoreSwiper] = useState(null);
  const [categoreTab, setCategoreTab] = useState(defaultCategoreTab);

  useEffect(() => {
    setCategoreTab(defaultCategoreTab)
  }, [defaultCategoreTab])

  return <div className="category_content">
    <div className="category_page_row">
      <div
        style={{
          width: "2.4rem", height: "100%", overflow: "hidden", display: "flex"
        }}
      >
        <ScrollArea>
          <div className="category_tab_list">
            {categoreList.map((item, index) => (<ClickBtn
              key={`category_list_item_${index}`}
              className={`category_item_tab ${categoreTab === item.id ? "category_item_tab_active" : ""}`}
              onTap={() => {
                setCategoreTab(item.id);
                categoreSwiper && categoreSwiper.slideTo(index);
              }}
            >
              <span>{item.name}</span>
              <div className="item_border"></div>
            </ClickBtn>))}
          </div>
        </ScrollArea>
      </div>
      <div className="category_tsb_content">
        <Swiper
          loop={false}
          direction="vertical"
          controller={{control: categoreSwiper}}
          className="category_swiper swiper-no-swiping"
          onSwiper={setCategoreSwiper}
          autoplay={false}
          onSlideChangeTransitionEnd={e => {
            setCategoreTab(categoreList[e.realIndex].id);
          }}
        >
          {categoreList.map((category, n) => (<SwiperSlide key={`category_content_${n}`}>
            <RightContent
              tabs={category}
              show={categoreTab === category.id}
            />
          </SwiperSlide>))}
        </Swiper>
      </div>
    </div>
  </div>
}
