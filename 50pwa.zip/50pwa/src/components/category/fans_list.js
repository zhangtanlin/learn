import React, { useEffect, useMemo, useRef, useState } from "react";
import ScrollArea from "../scrollarea";
import Simg from "../simg";
import Loading from "../loading";
import emit from "../../libs/eventEmitter";
import NoData from "../noData";
import { getOtherFansList, followUp } from "../../libs/http";
import Avatar from "../avatar";
import BackHead from "../backHeader";
import ClickBtn from "../clickBtn";

export default props => {
  const { uuid, stackKey } = props;
  const [loading, setLoading] = useState(true);
  const [isAll, setIsAll] = useState(true);
  const [listData, setListData] = useState({
    data: []
  });
  const [page, setPage] = useState({
    num: 1
  });

  const size = 15;
  const FansCard = props => {
    const { data } = props;
    const [item, setItem] = useState(data);
    const followeUser = async () => {
      const res = await followUp({ follow_uuid: item.uuid });
      if (res.status === 200) {
        // console.log(res);
        setItem({
          ...item,
          doubleFollow: !item.doubleFollow
        });
      } else {
        emit.emit("showToast", {
          text: res.msg,
          time: 3000
        });
      }
    };
    return useMemo(
      () => (
        <div className="fans_item_box">
          <div className="flex_row">
            <Avatar
              img={item.thumb}
              boxClass="fans_item_avatar"
              isCreater={item.auth_status}
            />
            <div>
              <div className="fans_nickname">{item.nickname}</div>
              <div
                className="flex_row"
                style={{
                  fontSize: "0.32rem"
                }}
              >
                <div style={{ marginRight: "0.32rem" }}>
                  {item.followed_count}粉丝
                </div>
                <div>{item.videos_count}作品</div>
              </div>
            </div>
          </div>
          <ClickBtn
            className={`gz_btn ${item.doubleFollow ? "ygz_btn" : ""}`}
            onTap={followeUser}
          >
            {item.doubleFollow ? "已关注" : "关注"}
          </ClickBtn>
        </div>
      ),
      [data, item]
    );
  };
  const initListData = async () => {
    const res = await getOtherFansList({
      uuid,
      page: page.num
    });
    // console.log("列表", res);
    if (res.status === 200) {
      if (page.num === 1) {
        listData.data = [...res.data];
      } else {
        listData.data = [...listData.data, ...res.data];
      }
      // if (res.data.length < size) {
      //   setIsAll(true);
      // }
      setListData({ ...listData });
      setLoading(false);
    }
  };
  const _loadMoreData = () => {
    if (isAll) return;
    page.num = page.num + 1;
    setPage({ ...page });
  };
  useEffect(() => {
    initListData();
  }, [page]);
  return useMemo(() => {
    return (
      <div className="full-column">
        <BackHead stackKey={stackKey} title="粉丝" />
        <div className="full-column">
          {loading ? (
            <Loading show overSize={false} />
          ) : listData.data.length === 0 ? (
            <NoData />
          ) : (
            <ScrollArea
              groupId="user_info_group"
              ListData={listData.data}
              loadingMore={!isAll}
              onScrollEnd={_loadMoreData}
            >
              <div
                style={{
                  padding: "0 0.32rem"
                }}
              >
                {listData.data.map((item, index) => (
                  <div key={`list_fans_item_${index}`}>
                    <FansCard data={item} />
                  </div>
                ))}
              </div>
            </ScrollArea>
          )}
        </div>
      </div>
    );
  }, [loading, isAll, listData]);
};
