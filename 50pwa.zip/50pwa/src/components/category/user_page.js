import React, { useEffect, useMemo, useRef, useState } from "react";
import BackHead from "../backHeader";
import ScrollArea from "../scrollarea";
import { Swiper, SwiperSlide } from "swiper/react";
import CardList from "./card_list";
import ClickBtn from "../clickBtn";
import Simg from "../simg";
import Loading from "../loading";
import iconYueka from "../../resources/img/public/icon_nianka_yueka.png";
import iconJika from "../../resources/img/public/icon_nianka_jika.png";
import iconNianka from "../../resources/img/public/icon_nianka_head.png";
import iconNohead from "../../resources/img/public/icon_normal_head.png";
import iconYoingjiu from "../../resources/img/public/icon_vip_yongjiu_head.png";
import iconRz from "../../resources/img/public/creter_tag.png";
import { getOtherUserInfo, followUp } from "../../libs/http";
import emit from "../../libs/eventEmitter";
import StackStore from "../../store/stack";
import StackPage from "../stackpage";
import FansList from "./fans_list";
import FansGroup from "./fans_group";
export default props => {
  const { stackKey, uuid } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const [cotSwiper, setCotSwiper] = useState(null);
  const contentRef = useRef(null);
  const listRef = useRef(null);
  const [loading, setLoading] = useState(true);
  const [userInfo, setUserInfo] = useState(null);
  const [cTab, setCTab] = useState(1);
  // const uuid = "046fbb9fb43467ea1124db011acb4e2b";
  const [tabList, setTabList] = useState([
    {
      title: "视频",
      id: 1
    },
    {
      title: "合集",
      id: 2
    },
    {
      title: "微头条",
      id: 3
    }
  ]);
  const toFansList = () => {
    if (!uuid) return;
    const stackKey = `fans_list-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "fans_list",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <FansList stackKey={stackKey} uuid={uuid} />
          </StackPage>
        )
      }
    });
  };
  const toFansGroup = (id) => {
    const stackKey = `fans_group-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "fans_group",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <FansGroup stackKey={stackKey} id={id}/>
          </StackPage>
        )
      }
    });
  };
  const getHead = vip => {
    let userVip;
    switch (vip) {
      case 1:
        userVip = iconYueka;
        break;
      case 2:
        userVip = iconJika;
        break;
      case 3:
        userVip = iconNianka;
        break;
      case 4:
        userVip = iconYoingjiu;
        break;
      default:
        userVip = iconNohead;
        break;
    }
    return userVip;
  };
  const followeUser = async () => {
    const res = await followUp({ follow_uuid: userInfo.uuid });
    if (res.status === 200) {
      setUserInfo({
        ...userInfo,
        is_followed: !userInfo.is_followed
      });
    } else {
      emit.emit("showToast", {
        text: res.msg,
        time: 3000
      });
    }
  };
  useEffect(() => {
    if (!contentRef.current || !listRef.current) return;
    listRef.current.setAttribute(
      "style",
      `height:${contentRef.current.clientHeight}px`
    );
    setTimeout(() => {
      setLoading(false);
    }, 300);
  }, [contentRef.current, listRef.current, userInfo]);
  useEffect(() => {
    getOtherUserInfo({ uuid }).then(res => {
      if (res.status === 200) {
        // console.log("个人中心", res);
        if (res.data.creator_desc) {
          res.data.creator_desc = res.data.creator_desc.replaceAll(
            "\n",
            "<br/>"
          );
        }
        if (!(res.data.clubInfo instanceof Array)) {
          setTabList([
            ...tabList,
            {
              title: "粉丝团专属",
              id: 4
            }
          ]);
        }
        setUserInfo(res.data);
      }
    });
  }, []);
  return useMemo(
    () => (
      <div
        className="full-column user_page"
        style={{
          width: "100%"
        }}
      >
        <BackHead
          stackKey={stackKey}
          title={!userInfo ? "个人中心" : userInfo.nickname}
        />
        {!userInfo ? (
          <Loading show overSize={false} />
        ) : (
          <div className="user_page_content" ref={contentRef}>
            <ScrollArea groupId="user_info_group">
              <div className="user_info_box">
                <div className="thumb">
                  <div className="user_thumb">
                    <img
                      className="thum_border"
                      src={
                        userInfo.vip ? getHead(userInfo.vip_level) : iconNohead
                      }
                    />
                    <Simg src={userInfo.thumb} />
                  </div>
                </div>
                <div className="user_info_right">
                  <div className="number_info">
                    <ClickBtn className="number_item" onTap={toFansList}>
                      <div className="number">{userInfo.followed_count}</div>
                      <div className="title">粉丝</div>
                    </ClickBtn>
                    <div className="number_item">
                      <div className="number">{userInfo.fans_count}</div>
                      <div className="title">关注</div>
                    </div>
                    <div className="number_item">
                      <div className="number">{userInfo.videos_count}</div>
                      <div className="title">视频</div>
                    </div>
                  </div>
                  <ClickBtn
                    onTap={followeUser}
                    className={`gz_btn ${
                      userInfo.is_followed ? "ygz_btn" : ""
                    }`}
                  >
                    {userInfo.is_followed ? "已关注" : "关注"}
                  </ClickBtn>
                </div>
              </div>
              {!(userInfo.clubInfo instanceof Array) && (
                <div className="fans_tuan_box">
                  <div className="flex_row">
                    {userInfo.clubInfo.items.length > 0 && (
                      <div className="avatar_box">
                        {userInfo.clubInfo.items.map((item, index) =>
                          index <= 3 ? (
                            <div
                              key={`fans_avatar_${index}`}
                              className="fans_avatar"
                              style={{
                                left: `${index * 0.2265}rem`
                              }}
                            >
                              <Simg src={item} />
                            </div>
                          ) : (
                            ""
                          )
                        )}
                      </div>
                    )}
                    <div className="fans_text">{userInfo.clubInfo.text}</div>
                  </div>
                  <ClickBtn className="add_fans" onTap={()=>toFansGroup(userInfo.clubInfo.id)}>
                    立即加入
                  </ClickBtn>
                </div>
              )}
              {userInfo.taggroup_name && (
                <div
                  style={{
                    padding: "0 0.32rem",
                    marginBottom: "0.48rem"
                  }}
                >
                  50度灰官方.优质{userInfo.taggroup_name}创作者
                </div>
              )}
              {userInfo.creator_desc && userInfo.creator !== 0 && (
                <div className="rz_text">
                  <div>
                    <img
                      src={iconRz}
                      style={{
                        width: "0.9rem",
                        marginRight: "0.32rem"
                      }}
                    />
                  </div>
                  <div
                    style={{ flex: "1", lineHeight: "1.5" }}
                    dangerouslySetInnerHTML={{ __html: userInfo.creator_desc }}
                  ></div>
                </div>
              )}
              <div className="user_page_box" ref={listRef}>
                <div className="tab_box">
                  {tabList.map((item, index) => (
                    <ClickBtn
                      className={`tab_item ${
                        cTab === item.id ? "tab_item_active" : ""
                      }`}
                      onTap={() => {
                        setCTab(item.id);
                        cotSwiper && cotSwiper.slideTo(index);
                      }}
                      key={`tab_item_${index}`}
                    >
                      <span>{item.title}</span>
                      <div className="tab_border"></div>
                    </ClickBtn>
                  ))}
                </div>
                <div className="user_page_content">
                  {loading ? (
                    <Loading show overSize={false} size={30} />
                  ) : (
                    <Swiper
                      loop={false}
                      controller={{ control: cotSwiper }}
                      className="user_page_swiper" // swiper-no-swiping
                      onSwiper={setCotSwiper}
                      autoplay={false}
                      onSlideChangeTransitionEnd={e => {
                        setCTab(tabList[e.realIndex].id);
                      }}
                    >
                      {tabList.map((tab, n) => (
                        <SwiperSlide key={`category_content_${n}`}>
                          <CardList
                            uuid={uuid}
                            tabId={tab.id}
                            show={cTab === tab.id}
                          />
                        </SwiperSlide>
                      ))}
                    </Swiper>
                  )}
                </div>
              </div>
            </ScrollArea>
          </div>
        )}
      </div>
    ),
    [
      userInfo,
      contentRef.current,
      listRef.current,
      cotSwiper,
      cTab,
      loading,
      tabList
    ]
  );
};
