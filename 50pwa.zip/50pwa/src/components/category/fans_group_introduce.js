import React, { useEffect, useMemo, useRef, useState } from "react";
import BackHead from "../backHeader";
import Loading from "../loading";
import ScrollArea from "../scrollarea";
import { fansGroupUserRule } from "../../libs/http";
export default props => {
  const { stackKey } = props;
  const [data, setData] = useState(null);
  useEffect(() => {
    fansGroupUserRule().then(res => {
      // console.log("用户规则", res);
      setData(res.data);
    });
  }, []);
  return (
    <div className="full-column">
      <BackHead stackKey={stackKey} title={!data ? "粉丝团规则" : data.title} />
      <div className="full-column">
        {!data ? (
          <Loading show={true} overSize={false} />
        ) : (
          <ScrollArea>
            <div style={{ padding: "0 0.32rem" }}>
              {data.items.map((item, index) => (
                <div className="introduce_box" key={`introduce_item_${index}`}>
                  <div className="title">{item.title}</div>
                  <div className="content">{item.content}</div>
                </div>
              ))}
            </div>
          </ScrollArea>
        )}
      </div>
    </div>
  );
};
