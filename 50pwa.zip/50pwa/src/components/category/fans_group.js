import React, { useEffect, useMemo, useRef, useState } from "react";
import { fansGroupInfo, joinFansGroup } from "../../libs/http";
import iconNotice from "../../resources/img/public/icon_notice.png";
import BackHead from "../backHeader";
import ScrollArea from "../scrollarea";
import Loading from "../loading";
import rightIcon from "../../resources/img/public/icon_check_more.png";
import iconYue from "../../resources/img/public/icon_fan_moth_ka.png";
import iconJi from "../../resources/img/public/icon_fan_qurt_ka.png";
import iconNian from "../../resources/img/public/icon_fan_year_ka.png";
import iconOne from "../../resources/img/public/icon_fv_rank_one.png";
import iconTwo from "../../resources/img/public/icon_fv_rank_two.png";
import iconThree from "../../resources/img/public/icon_fv_rank_three.png";
import tagNian from "../../resources/img/public/icon_nianka_tag.png";
import tagJi from "../../resources/img/public/icon_jika_tag.png";
import tagYue from "../../resources/img/public/icon_month_tag.png";
import img_a from "../../resources/img/public/fans_group_1.png";
import img_b from "../../resources/img/public/fans_group_2.png";
import Avatar from "../avatar";
import BottomSheet from "../bottom_sheet";
import ClickBtn from "../clickBtn";
import StackPage from "../stackpage";
import MyMember from "../user/myMember";
import StackStore from "../../store/stack";
import emit from "../../libs/eventEmitter";
import FansGroupIntroduce from "./fans_group_introduce";
export default (props) => {
  const { stackKey, id } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const [groupData, setGroupData] = useState(null);
  const [show, setShow] = useState(false);
  const kingNum = [iconOne, iconTwo, iconThree];
  const vipType = {
    year: iconNian,
    quarter: iconJi,
    month: iconYue,
  };
  const initpage = () => {
    fansGroupInfo({
      id,
    }).then((res) => {
      // console.log("粉丝团", res);
      setGroupData(res.data);
    });
  };
  useEffect(() => {
    initpage();
  }, []);
  return useMemo(() => {
    const fanTypeList = [
      {
        icon: tagYue,
        title: "粉丝团月票",
        coin: !groupData ? 0 : groupData.clubInfo.month,
        type: "month",
      },
      {
        icon: tagJi,
        title: "粉丝团季票",
        coin: !groupData ? 0 : groupData.clubInfo.quarter,
        type: "quarter",
      },
      {
        icon: tagNian,
        title: "粉丝团年票",
        coin: !groupData ? 0 : groupData.clubInfo.year,
        type: "year",
      },
    ];
    const toIntroduce = () => {
      const stackKey = `fans_group_introduce-${new Date().getTime()}`;
      StackStore.dispatch({
        type: "push",
        payload: {
          name: "fans_group_introduce",
          element: (
            <StackPage
              stackKey={stackKey}
              key={stackKey}
              style={{ zIndex: stacks.length + 2 }}
            >
              <FansGroupIntroduce stackKey={stackKey} />
            </StackPage>
          ),
        },
      });
    };
    return (
      <div className="full-column">
        <BottomSheet show={show} setShow={setShow}>
          <div className="conment_head">
            <span></span>
            <div className="title">
              {groupData && groupData.hasJoin ? "续费" : "加入"}粉丝团{"  "}
              <span
                style={{
                  color: "#c0bdcc",
                  fontSize: "0.4rem",
                }}
              >
                (视频免费看)
              </span>
            </div>
            <span></span>
          </div>
          <div className="group_type_list">
            {fanTypeList.map((item, index) => (
              <ClickBtn
                className="fans_type_item"
                key={`fans_type_item_${index}`}
                onTap={() => {
                  setShow(false);
                  joinFansGroup({
                    id,
                    type: item.type,
                  }).then((res) => {
                    // console.log("加入粉丝团", res);
                    if (!res.data.success) {
                      emit.emit("changeAlert", {
                        _title: "温馨提示",
                        _content: "灰币余额不足，立即充值",
                        _submitText: "灰币充值",
                        _notDouble: true,
                        _cancal: () => {},
                        _submit: () => {
                          const stackKey = `user-member-${new Date().getTime()}`;
                          StackStore.dispatch({
                            type: "push",
                            payload: {
                              name: "user-member",
                              element: (
                                <StackPage
                                  stackKey={stackKey}
                                  key={stackKey}
                                  style={{ zIndex: stacks.length + 2 }}
                                >
                                  <MyMember stackKey={stackKey} type={1} />
                                </StackPage>
                              ),
                            },
                          });
                        },
                      });
                    } else {
                      initpage();
                      emit.emit("showToast", {
                        text: res.data.msg,
                        time: 3000,
                      });
                    }
                  });
                }}
              >
                <div className="flex_row fans_group_type">
                  <img src={item.icon} />
                  <div>{item.title}</div>
                </div>
                <span className="fans_group_coin">{item.coin}灰币</span>
              </ClickBtn>
            ))}
          </div>
        </BottomSheet>
        <BackHead
          title={groupData && groupData.name ? groupData.name : "粉丝团详情"}
          stackKey={stackKey}
        />
        <div className="full-column">
          {!groupData ? (
            <Loading show={true} overSize={false} />
          ) : (
            <ScrollArea>
              <div className="fans_group_content">
                <div className="flex_row fans_notice_title">
                  <img src={iconNotice} />
                  致粉丝公告：
                </div>
                <p className="notice_text">{groupData.clubInfo.notice}</p>
                <div className="join_title">
                  <span>入团特权</span>
                  <ClickBtn className="right_text" onTap={toIntroduce}>
                    粉丝团介绍
                    <img src={rightIcon} />
                  </ClickBtn>
                </div>
                <img src={img_a} className="group_img" />
                <img src={img_b} className="group_img" />
                <div className="fans_list_box">
                  {groupData.items.map((item, index) => (
                    <div key={`fans_item_${index}`} className="fans_item">
                      <div className="flex_row">
                        <div className="fans_king_num">
                          {index <= 2 ? (
                            <img src={kingNum[index]} />
                          ) : (
                            index + 1
                          )}
                        </div>
                        <Avatar
                          img={item.thumb}
                          size={1.1}
                          uuid={item.uuid}
                          boxClass="avatar_box"
                        />
                        <div className="user_info">
                          <span>{item.nickname}</span>
                          <img src={vipType[item.type]} />
                        </div>
                      </div>
                      <span className="exp_text">{item.exp}</span>
                    </div>
                  ))}
                </div>
              </div>
            </ScrollArea>
          )}
        </div>
        {groupData && !groupData.hasJoin && (
          <ClickBtn className="join_btn" onTap={() => setShow(true)}>
            加入TA的粉丝团
          </ClickBtn>
        )}
        {groupData && groupData.hasJoin && (
          <ClickBtn className="join_btn" onTap={() => setShow(true)}>
            续费粉丝团
            {typeof groupData.selfInfo === "object" &&
              groupData.selfInfo.expired_at && (
                <span>{groupData.selfInfo.expired_at}</span>
              )}
          </ClickBtn>
        )}
      </div>
    );
  }, [show, groupData]);
};
