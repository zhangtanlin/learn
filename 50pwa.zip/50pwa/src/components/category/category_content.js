import React, {useEffect, useMemo, useRef, useState} from "react";
import HorizontalScroll from "../horizontal_scroller";
import ScrollArea from "../scrollarea";
import ClickBtn from "../clickBtn";
import StackPage from "../stackpage";
import StackStore from "../../store/stack";
import {getStyleHotup} from "../../libs/http";
import TagList from "../featured/tagList";
import Avatar from "../avatar";
import Loading from "../loading";
import AllCreative from "../creative/allCreative";

export default (props) => {
  const {tabs, show} = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const [initPage, setInitPage] = useState(false);
  const [loading, setLoading] = useState(true);
  const [hotUpList, setHotUpList] = useState(null);
  const toTagPage = item => {
    const stackKey = `tag-page-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "user_page",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{zIndex: stacks.length + 2}}
          >
            <TagList stackKey={stackKey} tagItem={item}/>
          </StackPage>
        )
      }
    });
  };
  const toAllCreative = () => {
    const stackKey = `AllCreative-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "AllCreative",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{zIndex: stacks.length + 2}}
          >
            <AllCreative stackKey={stackKey} title={tabs.name} taggroup_id={tabs.id.toString()}/>
          </StackPage>
        )
      }
    });
  };
  useEffect(() => {
    if (show && !initPage) {
      setInitPage(true);
    }
  }, [show]);
  useEffect(() => {
    if (initPage) {
      getStyleHotup({
        taggroup_id: tabs.id.toString()
      }).then(res => {
        // console.log("热门创作者", res.data);
        setHotUpList(res.data);
        setLoading(false);
      });
    }
  }, [initPage]);
  return useMemo(
    () => (
      <div className="category_right_content">
        {loading ? (
          <Loading show overSize={false}/>
        ) : (
          <ScrollArea>
            {hotUpList && hotUpList.length > 0 && (
              <div className="hot_user_creator">
                <p className="category_title">热门创作者<span className={"all"} onClick={toAllCreative}>查看全部</span></p>
                <div className="creator_box">
                  <HorizontalScroll>
                    <div
                      className="flex_row"
                      style={{
                        padding: "0 0.4rem"
                      }}
                    >
                      {hotUpList.map((item, index) => (
                        <div
                          className="creator_item"
                          key={`creator_item_${index}`}
                        >
                          <Avatar
                            boxClass="creator_item"
                            avatarClass="creator_thumb"
                            img={item.thumb}
                            size={1.52}
                            uuid={item.uuid}
                            isCreater={item.auth_status}
                          />
                          {/* <div className="creator_thumb">
                          <Simg src={item.thumb} />
                        </div> */}
                          <div className="creator_name one_line">
                            {item.nickname}
                          </div>
                        </div>
                      ))}
                    </div>
                  </HorizontalScroll>
                </div>
              </div>
            )}
            <p className="category_title">全部标签</p>
            <div className="category_tag_wrap">
              {tabs.child.map((item, index) => (
                <ClickBtn
                  key={`category_tag_item_${index}`}
                  onTap={() => toTagPage(item)}
                  className="creator_tag_item"
                >
                  {item.name}
                </ClickBtn>
              ))}
            </div>
          </ScrollArea>
        )}
      </div>
    ),
    [hotUpList, tabs, loading]
  );
};
