import React, { useEffect, useMemo, useRef, useState } from "react";
import ScrollArea from "../scrollarea";
import Simg from "../simg";
import Loading from "../loading";
import moreIcon from "../../resources/img/public/more_icon.png";
import NoData from "../noData";
import {
  getOtherFeatured,
  getOtherHer,
  getOtherTie,
  getOtheClubVideos
} from "../../libs/http";
import iconTop from "../../resources/img/public/icon_video_top.png";
import { ToutiaoCard } from "../weitie/qiupian/qiupian_card";
import StackPage from "../stackpage";
import VideoDetai from "../videoDetail";
import StackStore from "../../store/stack";
import ClickBtn from "../clickBtn";
import HejiVideoList from "../featured/hejiVideoList";
export default props => {
  const { show, uuid, tabId } = props;
  const [initList, setInitList] = useState(false);
  const [loading, setLoading] = useState(true);
  const [isAll, setIsAll] = useState(false);
  const [lastId, setLastId] = useState(0);
  const [stacks] = StackStore.useGlobalState("stacks");

  const [listData, setListData] = useState({
    data: []
  });
  const [page, setPage] = useState({
    num: 1
  });
  const size = 15;
  const toVideoDetail = videoId => {
    const stackKey = `video_detai-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "video_detai",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <VideoDetai stackKey={stackKey} id={videoId} />
          </StackPage>
        )
      }
    });
  };
  const HejiCard = props => {
    const { data } = props;
    return useMemo(
      () => (
        <ClickBtn
          className="heji_card"
          onTap={() => {
            const stackKey = `HejiVideoList-${new Date().getTime()}`;
            StackStore.dispatch({
              type: "push",
              payload: {
                name: "HejiVideoList",
                element: (
                  <StackPage
                    stackKey={stackKey}
                    key={stackKey}
                    style={{ zIndex: stacks.length + 2 }}
                  >
                    <HejiVideoList
                      stackKey={stackKey}
                      title={data.title}
                      id={data.id}
                    />
                  </StackPage>
                )
              }
            });
          }}
        >
          <div className="heji_warp">
            <div className="heji_name">
              <p>{data.title}</p>
            </div>
            <div className="heji_num">
              <img src={moreIcon} /> 共{data.count}个视频
            </div>
          </div>
          <Simg src={data.image} />
        </ClickBtn>
      ),
      [data]
    );
  };
  const VideoCard = props => {
    const { data } = props;
    return useMemo(
      () => (
        <ClickBtn
          className="card_item_box"
          onTap={() => {
            toVideoDetail(data.id);
          }}
        >
          <div className="card_item_thumb">
            <div className="video_time">{data.duration_str}</div>
            {data.is_top !== 0 && (
              <div className="video_top">
                <img src={iconTop} />
              </div>
            )}
            <Simg src={data.thumb_cover} />
          </div>
          <div className="card_right_info">
            <div className="video_title">{data.title}</div>
            <div className="video_num_info">
              <div
                style={{
                  marginRight: "0.4rem"
                }}
              >
                {data.count_play_str}
              </div>
              <div>{data.count_like_str}次点赞</div>
            </div>
          </div>
        </ClickBtn>
      ),
      [data]
    );
  };
  const getCard = data => {
    let card;
    switch (tabId) {
      case 1:
        card = <VideoCard data={data} />;
        break;
      case 2:
        card = <HejiCard data={data} />;
        break;
      case 3:
        card = <ToutiaoCard data={data} />;
        break;
      case 4:
        card = <VideoCard data={data} />;
        break;
      default:
      case 1:
        card = <VideoCard data={data} />;
        break;
        break;
    }
    return card;
  };
  const initListData = async () => {
    let res;
    switch (tabId) {
      case 1:
        res = await getOtherFeatured({
          uuid,
          size,
          lastId
        });
        break;
      case 2:
        res = await getOtherHer({
          uuid,
          page: page.num
        });
        break;
      case 3:
        res = await getOtherTie({
          uuid,
          size,
          page: page.num
        });
        break;
      case 4:
        res = await getOtheClubVideos({
          uuid,
          size,
          page: page.num
        });
        break;
      default:
        break;
    }
    // console.log("列表", res);
    if (res.status === 200) {
      const isArr = res.data instanceof Array;
      if (!isAll && res.data.lastId) {
        setLastId(res.data.lastId);
      }
      if (page.num === 1) {
        listData.data = isArr ? [...res.data] : [...res.data.list];
      } else {
        listData.data = isArr
          ? [...listData.data, ...res.data]
          : [...listData.data, ...res.data.list];
      }
      if (tabId == 2) {
        setIsAll(true);
      }
      if ((isArr ? res.data : res.data.list).length < size) {
        setIsAll(true);
      }
      setListData({ ...listData });
      setLoading(false);
    }
  };
  const _loadMoreData = () => {
    if (isAll) return;
    page.num = page.num + 1;
    setPage({ ...page });
  };
  useEffect(() => {
    if (show && !initList) {
      setInitList(true);
    }
  }, [show]);
  useEffect(() => {
    if (initList) {
      initListData();
    }
  }, [initList, page]);
  return useMemo(() => {
    return (
      <div className="full-column">
        {!initList || loading ? (
          <Loading show overSize={false} />
        ) : listData.data.length === 0 ? (
          <NoData />
        ) : (
          <ScrollArea
            groupId="user_info_group"
            ListData={listData.data}
            loadingMore={!isAll}
            onScrollEnd={_loadMoreData}
          >
            <div
              style={{
                padding: "0 0.32rem"
              }}
            >
              {listData.data.map((item, index) => (
                <div key={`list_item_${index}`}>{getCard(item)}</div>
              ))}
            </div>
          </ScrollArea>
        )}
      </div>
    );
  }, [initList, loading, isAll, listData]);
};
