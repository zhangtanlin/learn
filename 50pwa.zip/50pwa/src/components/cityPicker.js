import React, {useEffect, useMemo, useRef, useState} from "react";
import {CSSTransition} from 'react-transition-group'
import Hammer from "hammerjs";

import "../resources/css/citylayer.less";
import Emit from "../libs/eventEmitter";
import localCitydata from '../libs/citydata'
import ScrollArea from './scrollarea'
import Clickbtn from './clickbtn'
import backWhite from "../resources/img/public/backWhite.png";
import {getDatingCityList} from "../libs/http";

export default () => {
  const [visible, setVisible] = useState(false)
  const [cityListState, setCityListState] = useState(false)
  const [letterValue, setLetterValue] = useState(null)
  const [hotCity, setHotCity] = useState([])
  const [citydata, setCitydata] = useState([])

  const cityHotConverter = (list = []) => {
    const newList = []
    for (let i of list) {
      newList.push({name: i.shortname})
    }
    return newList
  }

  const cityAllConverter = (list = []) => {
    const newList = []
    const initialMap = {}

    for (let i of list) {
      const code = i.short_pinyin.toUpperCase()[0]
      if (!initialMap[code]) {
        initialMap[code] = []
      }
      initialMap[code].push({
        "code": i.id, "name": i.shortname, "pinyin": i.short_pinyin, "label": i.short_pinyin + i.id
      },)
    }

    for (let i of Object.keys(initialMap).sort()) {
      newList.push({
        initial: i, list: initialMap[i]
      })
    }

    return newList
  }

  const getData = async () => {
    await getDatingCityList()
      .then(res => {
        const list = cityAllConverter(res.data.list)
        const hot = cityHotConverter(res.data.hot)

        setCitydata(list)
        setHotCity(hot)
      })
  }

  useEffect(() => {
    Emit.on("showPicker", () => {
      getData().finally(() => {
        setVisible(true);
        setCityListState(true)
      })
    });
    return () => {
      Emit.off("showPicker");
      setCityListState(false)
    };
  }, []);

  const handleCancel = () => {
    setVisible(false)
    setCityListState(false)
  }

  const handleSelect = (city) => {
    setVisible(false)
    setCityListState(false)
    let findItem = {}
    for (let i of Object.keys(citydata)) {
      const item = citydata[i].list.find(v => v.name === city)
      if (item) {
        findItem = item
        continue
      }
    }
    Emit.emit('choosePicker', findItem);
  }

  useEffect(() => {
    if (letterValue) {
      let el = document.getElementsByClassName(`city-word-${letterValue}`)[0];
      if (!el) return;
      let y = -el.offsetTop;
      Emit.emit("city-scrollto", {y});
    }
  }, [letterValue])

  useEffect(() => {
    const setCenterText = e => {
      setLetterValue(e);
    };
    Emit.on("set_center_text", setCenterText);
    return () => {
      Emit.off("set_center_text", setCenterText);
    };
  }, []);

  return (<div className="picker-container view">
    <CSSTransition
      in={visible}
      classNames="picker-fade"
      timeout={300}
      onEnter={(node) => {
        node.style.display = 'block'
      }}
      onExited={(node) => {
        node.style.display = ''
      }}
    >
      <div
        className="picker"
      >
        <CSSTransition in={visible} classNames="picker-move" timeout={300}>
          <div className="picker-panel">
            <div className="picker-choose">
              <img className="cancel-img" src={backWhite} onClick={() => {
                handleCancel()
              }}/>
              <h1 className="picker-title">切换城市</h1>
            </div>
            <div className="picker-content">
              <div className="picker-content-scroll-area">
                <ScrollArea
                  emitName="city-scrollto"
                  downRefresh={false}
                  ListData={cityListState}>
                  <div>
                    <div className="hot-city-title">热门城市</div>
                    {useMemo(() => (<div className="hot-city-item-container">
                      {hotCity.map((item, index) => {
                        return <Clickbtn onTap={() => {
                          handleSelect(item.name)
                        }} className="hot-city-item-value" key={index}>{item.name}</Clickbtn>
                      })}
                    </div>), [hotCity])}

                    {useMemo(() => (<>
                      {citydata.map((item, index) => {
                        return <div key={index}>
                          <div className={`initial-item-value city-word-${item.initial}`}>{item.initial}</div>
                          {item.list.map((city, index2) => {
                            return <Clickbtn onTap={() => {
                              handleSelect(city.name)
                            }} className={"city-item-value"} key={index2}>{city.name}</Clickbtn>
                          })}
                        </div>
                      })}
                    </>), [citydata])}
                  </div>
                </ScrollArea>
              </div>
              {citydata && <Letters list={citydata} state={cityListState}/>}
              {letterValue && <div className="initial-curret-word">{letterValue}</div>}
            </div>
          </div>
        </CSSTransition>
      </div>
    </CSSTransition>
  </div>);
};

const Letters = (props) => {
  const {list, state} = props;
  const initialRef = useRef(null)
  let letterbox = 0
  let fontSize = parseFloat(document.documentElement.style.fontSize)
  const LetterItem = props => {
    const {letter} = props;
    const letterRef = useRef(null);
    useEffect(() => {
      if (!letterRef.current) return;
      const letterHammer = new Hammer(letterRef.current);
      const setCenter = e => {
        let textEl = document.elementFromPoint(letterbox, e.center.y);
        if (textEl) {
          let text = textEl.innerText;
          if (/^[a-zA-Z]+$/.test(text)) {
            Emit.emit("set_center_text", text);
          }
        }
      };
      const clearLetter = () => {
        Emit.emit("set_center_text", null);
      };
      letterHammer
        .get("pan")
        .set({threshold: 1, direction: Hammer.DIRECTION_VERTICAL});
      setTimeout(() => {
        Emit.emit("set_center_text", null);
      }, 500);
      letterHammer.on("pan", setCenter);
      letterHammer.on("panend", clearLetter);
      return () => {
        letterHammer.off("pan", setCenter);
        letterHammer.off("panend", clearLetter);
      };
    }, [letterRef.current, state]);
    return (<div className="letter_item" ref={letterRef}>{letter}</div>)
  };

  useEffect(() => {
    if (!initialRef.current) return;
    letterbox = (10 * fontSize) - initialRef.current.clientWidth;
  }, [initialRef.current, list, state]);

  return useMemo(() => (<div className="initial-fixed-list" ref={initialRef}>
    {list.map((item, index) => {
      return <LetterItem letter={item.initial} key={index}/>
    })}
  </div>), [list, initialRef.current, state])
}
