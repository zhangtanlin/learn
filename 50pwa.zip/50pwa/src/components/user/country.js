import React, { useEffect, useMemo, useState } from "react";

import ScrollArea from "../scrollarea";
import BackHeader from '../backHeader';
import ClickBtn from "../clickBtn";
import Loading from "../loading";
import NoData from '../noData';

import Emit from "../../libs/eventEmitter";
import GlobalVar from "../../libs/globalVar";
import { getCountryCode } from "../../libs/http";

import iconChoose from '../../resources/img/public/iconChoose.png';

export default (props) => {
  const { stackKey } = props;

  const [loading, setLoading] = useState(true);
  const [list, setList] = useState({});
  const arrayToObject = (data) => {
    const tempObject = {};
    if (data?.length) {
      data.forEach((item) => {
        const tempObjectKeys = Object.keys(tempObject);
        if (tempObjectKeys.includes(item.codeGroup)) {
          tempObject[item.codeGroup].push(item);
        } else {
          tempObject[item.codeGroup] = [item];
        }
      });
    }
    return tempObject;
  };
  const getList = () => {
    getCountryCode().then(res => {
      if (res?.data?.length) {
        const list = res.data;
        list.map((item) => {
          item.codeGroup = (item.eName).slice(0, 1);
          item.choose = false;
          return item;
        });
        const newList = arrayToObject(list);
        setList(newList);
        setLoading(false);
      }
    });
  };
  useEffect(() => {
    getList();
  }, []);
  const onChoose = (data) => {
    GlobalVar.country = data; // 存储选中的国家
    const tempList = {};
    const tempKeys = Object.keys(list);
    const tempValues = Object.values(list).map((item) => {
      item.map((obj) => {
        if (obj.choose) {
          obj.choose = false;
        }
        if (obj.id === data.id) {
          obj.choose = true;
        }
        return obj;
      });
      return item;
    });
    tempKeys.forEach((item, index) => {
      tempList[item] = tempValues[index];
    });
    setList(tempList);
  };
  return useMemo(() => (
    <div className="positioned-container user-country">
      <BackHeader
        stackKey={stackKey}
        leftIconIsDark
        rightBtn={() => (
          <ClickBtn
            className="user-country-head-btn"
            onTap={() => {
              Emit.emit(stackKey, stackKey);
            }}
          >
            确定
          </ClickBtn>
        )}
        style={{ background: 'white', color: 'black', }}
      />
      {
        loading ? (
          <Loading show overSize={false} />
        ) : (
          <ScrollArea emitName="international-scrollto">
            <div className="user-country-content">
              {
                Object.keys(list).length ? (
                  Object.keys(list).map((item, index) => (
                    <div
                      key={`user-country-item-${index}`}
                      className={`user-country-item user-country-item-${item}`}
                    >
                      <div className="user-country-item-head">
                        {item}
                      </div>
                      {
                        list[item]?.length ? (
                          list[item].map((data, i) => (
                            <ClickBtn
                              key={`user-country-item-inner-${i}`}
                              className="user-country-item-inner"
                              onTap={() => onChoose(data)}
                            >
                              <div className="user-country-item-inner-mark">
                                {
                                  data?.choose ? (
                                    <img src={iconChoose} />
                                  ) : (<></>)
                                }
                              </div>
                              <div className="user-country-item-inner-key">
                                {data?.name}
                              </div>
                              <div className="user-country-item-inner-value">
                                {data?.code ? `+${data.code}` : ''}
                              </div>
                            </ClickBtn>
                          ))
                        ) : <></>
                      }
                    </div>
                  ))
                ) : (<NoData />)
              }
            </div>
          </ScrollArea>
        )
      }
    </div>
  ), [loading, list]);
};
