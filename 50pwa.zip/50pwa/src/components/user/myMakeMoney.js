import React, { useEffect, useMemo, useState } from "react";

import StackPage from "../stackpage";
import StackStore from "../../store/stack";
import UserStore from "../../store/user";
import GlobalVar from "../../libs/globalVar";

import BackHeader from '../backHeader';
import Loading from '../loading';
import ScrollArea from "../scrollarea";
import ClickBtn from '../clickBtn';
import MyShare from './myShare';
import Withdraw from './withdraw';
import BandPhone from './bandPhone';
import WebView from '../webview';

import makeMoneyAd from '../../resources/img/user/makeMoneyAd.jpg';

import Emit from "../../libs/eventEmitter";
import { apiGetProxy } from '../../libs/http';

export default (props) => {
  const { stackKey } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const [user] = UserStore.useGlobalState("user");

  const [info, setInfo] = useState({});

  // 跳转分享页
  const handleMyShare = () => {
    const stackKey = `user-share-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "user-share",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <MyShare stackKey={stackKey} />
          </StackPage>
        )
      }
    });
  };
  // 提现
  const handleWithdraw = () => {
    if (user?.phone) {
      const stackKey = `user-withdraw-${new Date().getTime()}`;
      StackStore.dispatch({
        type: "push",
        payload: {
          name: "user-withdraw",
          element: (
            <StackPage
              stackKey={stackKey}
              key={stackKey}
              style={{ zIndex: stacks.length + 2 }}
            >
              <Withdraw stackKey={stackKey} type={2}/>
            </StackPage>
          )
        }
      });
    } else {
      const stackKey = `user-bandPhone-${new Date().getTime()}`;
      StackStore.dispatch({
        type: "push",
        payload: {
          name: "user-bandPhone",
          element: (
            <StackPage
              stackKey={stackKey}
              key={stackKey}
              style={{ zIndex: stacks.length + 2 }}
            >
              <BandPhone stackKey={stackKey} />
            </StackPage>
          )
        }
      });
    }
  };
  // 代理规则
  const handleAnentRules = () => {
    if (GlobalVar?.agentRules) {
      const stackKey = `webview-${new Date().getTime()}`;
      StackStore.dispatch({
        type: "push",
        payload: {
          name: "webview",
          element: (
            <StackPage
              stackKey={stackKey}
              key={stackKey}
              isReplace
              style={{
                zIndex: stacks.length + 1,
              }}
            >
              <WebView title='代理规则' url={GlobalVar?.agentRules} stackKey={stackKey} />
            </StackPage>
          ),
        },
      });
    }
  };
  const [loading, setLoading] = useState(true);
  const getList = async () => {
    try {
      const res = await apiGetProxy();
      if (res?.status === 200) {
        setInfo(res?.data);
      } else {
        Emit.emit("showToast", {
          text: "请求列表失败",
          time: 3000
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
        time: 3000
      });
    }
    setLoading(false);
  };
  useEffect(() => {
    getList();
  }, []);
  return useMemo(() => (
    <div className="positioned-container user-make-money">
      <BackHeader
        stackKey={stackKey}
        title="代理赚钱"
        rightBtn={() => (
          <ClickBtn
            className="user-make-money-header-btn"
            onTap={() => handleMyShare()}
          >
            开始代理
          </ClickBtn>
        )}
      />
      {
        loading ? (
          <Loading show overSize={false} />
        ) : (
          <ScrollArea>
            <div className="user-make-money-top">
              <div className="user-make-money-top-box">
                <div className="user-make-money-top-row">
                  <div className="user-make-money-top-item">
                    总业绩
                  </div>
                  <div className="user-make-money-top-item">
                    总收益
                  </div>
                </div>
                <div className="user-make-money-top-row">
                  <div className="user-make-money-top-item large-text">
                    {info?.proxy_total || 0.00}
                  </div>
                  <div className="user-make-money-top-item large-text">
                    {info?.proxy_total_amount || 0.00}
                  </div>
                </div>
                <ClickBtn
                  className="user-make-money-top-btn"
                  onTap={() => handleWithdraw()}
                >
                  现金提现
                </ClickBtn>
              </div>
            </div>
            <ClickBtn
              className="user-make-money-ad"
              onTap={() => handleAnentRules()}
            >
              <img src={makeMoneyAd} />
            </ClickBtn>
            <div className="user-make-money-list">
              <div className="user-make-money-list-box">
                <div className="user-make-money-list-row">
                  <div className="user-make-money-list-item">
                    当月收益(元)
                  </div>
                  <div className="user-make-money-list-item">
                    当月业绩(元)
                  </div>
                  <div className="user-make-money-list-item">
                    当月推广人数
                  </div>
                </div>
                <div className="user-make-money-list-row large-text">
                  <div className="user-make-money-list-item">
                    {info?.month_total_amount || 0}
                  </div>
                  <div className="user-make-money-list-item">
                    {info?.month_proxy_total || 0}
                  </div>
                  <div className="user-make-money-list-item">
                    {info?.invite_num || 0}
                  </div>
                </div>
              </div>
            </div>
            <div className="user-make-money-list">
              <div className="user-make-money-list-title">
                推广人数统计
              </div>
              <div className="user-make-money-list-box">
                <div className="user-make-money-list-row large-text">
                  <div className="user-make-money-list-item">
                    {info?.proxy_data?.level_1 || 0}
                  </div>
                  <div className="user-make-money-list-item">
                    {info?.proxy_data?.level_2 || 0}
                  </div>
                  <div className="user-make-money-list-item">
                    {info?.proxy_data?.level_3 || 0}
                  </div>
                  <div className="user-make-money-list-item">
                    {info?.proxy_data?.level_4 || 0}
                  </div>
                </div>
                <div className="user-make-money-list-row">
                  <div className="user-make-money-list-item">
                    一级推广
                  </div>
                  <div className="user-make-money-list-item">
                    二级推广
                  </div>
                  <div className="user-make-money-list-item">
                    三级推广
                  </div>
                  <div className="user-make-money-list-item">
                    四级推广
                  </div>
                </div>
              </div>
            </div>
            <div className="user-make-money-list">
              <div className="user-make-money-list-title">
                业绩明细
              </div>
              <div
                className="user-make-money-list-box"
                style={{ padding: '0.3rem' }}
              >
                {
                  info?.lists?.length > 0 ? (
                    info?.lists.map((item, index) => (
                      <div
                        key={`user-make-money-list-row-${index}`}
                        className="user-make-money-list-row"
                      >
                        <div
                          className="user-make-money-list-item"
                          style={{ textAlign: 'left', }}
                        >
                          {item?.from_name}
                        </div>
                        <div className="user-make-money-list-item">
                          {item?.amount}
                        </div>
                        <div
                          className="user-make-money-list-item"
                          style={{ textAlign: 'right', }}
                        >
                          {item?.descp}
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="user-make-money-list-row">
                      <div className="user-make-money-list-item">暂无代理数据</div>
                    </div>
                  )
                }
              </div>
            </div>
          </ScrollArea>
        )
      }
    </div>
  ), [loading, info]);
};
