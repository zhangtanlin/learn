import React, {useEffect, useMemo, useRef, useState} from "react";
import {Swiper, SwiperSlide} from "swiper/react";

import BackHeader from '../backHeader';
import HeaderTab from "./headerTab";
import Loading from '../loading';
import NoData from '../noData';
import ScrollArea from "../scrollarea";
import {SelectVideo} from '../weitie/qiupian/qiupian_card';

import Emit from "../../libs/eventEmitter";
import {
  apiGetMyLike,
  createCartoonGroup,
  createVideoGroup,
  getCartoonGroupList,
  getDatingGroupList,
  getUserCartoonLikeList,
  getVideoGroupList
} from '../../libs/http';
import {Concentration} from "../featured/concentration";
import {CartoonItem} from "../cartoon";
import edit from "../../resources/img/public/edit.png";
import StackStore from "../../store/stack";
import StackPage from "../stackpage";
import GroupManage from "../group";

export const List = (props) => {
  const {type = 0} = props;
  const [loading, setLoading] = useState(true);
  const [loadMore, setLoadMore] = useState(true);
  const [page, setPage] = useState(1);
  const [size, setSize] = useState(10);
  const [list, setList] = useState([]);
  const [catList, setCatList] = useState([])
  const [currentGroupId, setCurrentGroupId] = useState(-1)
  const inputRef = useRef(undefined)
  const [stacks] = StackStore.useGlobalState("stacks");

  const _getCartoonGroupList = () => {
    getCartoonGroupList()
      .then(res => {
        if (res.status !== 200) return
        setCatList([{
          id: -1, name: "全部", sort: 0
        }, ...res.data.list])
      })
  }

  const _getVideoGroupList = () => {
    getVideoGroupList()
      .then(res => {
        if (res.status !== 200) return
        setCatList([{
          id: -1, name: "全部", sort: 0
        }, ...res.data.list])
      })
  }

  const onTextSubmit = async ({keyCode}) => {
    if (keyCode === 13) {
      const value = inputRef.current.value.trim()
      if (value.length === 0) {
        inputRef.current.value = value
        alert("分组名称不能为空")
        return
      }

      if (type === 0) {
        await createVideoGroup({title: value})
      }

      if (type === 1) {
        await createCartoonGroup({title: value})
      }

      inputRef.current.value = ""

      if (type === 0) {
        _getVideoGroupList()
      }

      if (type === 1) {
        _getCartoonGroupList()
      }
    }
  }

  const getList = async () => {
    setLoadMore(true);
    try {
      let apiUrl = "";

      switch (type) {
        case 0:
          apiUrl = apiGetMyLike;
          break;
        case 1:
          apiUrl = getUserCartoonLikeList;
          break;
      }
      const tempParam = {
        page, size,
      };

      if (currentGroupId !== -1) {
        tempParam.group_id = currentGroupId
      }

      if (type === 0) {
        _getVideoGroupList()
      }

      if (type === 1) {
        _getCartoonGroupList()
      }

      const res = await apiUrl(tempParam);

      if (res?.status === 200) {
        console.log(res?.data?.list)
        if (page === 1) {
          setList(res?.data?.list);
        } else {
          setList([...list, ...res?.data?.list]);
        }
      } else {
        Emit.emit("showToast", {
          text: "请求列表失败", time: 3000
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败", time: 3000
      });
    }
    setLoading(false);
    setLoadMore(false);
  };
  const loadMoreData = () => {
    setPage((page) => (page + 1));
  };
  useEffect(() => {
    getList();
  }, [page, size, currentGroupId]);
  const toGroupManage = () => {
    const stackKey = `GroupManage-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "GroupManage",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{zIndex: stacks.length + 2}}
          >
            <GroupManage stackKey={stackKey} type={1}/>
          </StackPage>
        ),
      },
    });
  }
  return useMemo(() => (<div className="user-like-list">
    {loading ? (<Loading show overSize={false}/>) : (list?.length > 0 || catList.length > 0 ? (<ScrollArea
      loadingMore={loadMore}
      onScrollEnd={() => loadMoreData()}
    >
      <div style={{display: "flex", width: "100%", flexFlow: "wrap"}}>
        <div className={"VideoGroupPopup-tags"}>
          {catList.map(value => {
            return <span key={value.id} className={`${currentGroupId === value.id ? 'active' : ''}`}
                         onClick={() => {
                           setCurrentGroupId(value.id)
                         }
                         }>{value.name}</span>
          })}

          <span onClick={toGroupManage}>
          <img src={edit}/>
          <input readOnly={true} ref={inputRef} placeholder={"自定义"} type={"text"} onKeyDown={onTextSubmit}/>
        </span>
        </div>

        {type === 0 && list && list.map((item, index) => (<Concentration
          key={`user-like-item-${index}`}
          data={item}
        />))}
        {type === 1 && <div className={"Cartoon-page"}>
          <div className={"Cartoon-list"}>
            {list && list.map((item, index) => (<CartoonItem
              key={`user-like-item-${index}`}
              item={item}
            />))}
          </div>
        </div>}
      </div>
    </ScrollArea>) : (<NoData/>))}
  </div>), [type, loading, loadMore, list, currentGroupId, catList]);
};

export default (props) => {
  const {stackKey, type} = props; // type：选中的选项卡{0:全部,1:精选,2:拼多多}

  const navList = [{name: '视频',}, {name: '漫画',},];
  const [currentTab, setCurrentTab] = useState(type || 0);
  const [controlledSwiper, setControlledSwiper] = useState(null);
  return useMemo(() => (<div className="positioned-container my-like">
    <BackHeader
      style={{position: "fixed", top: 0}}
      stackKey={stackKey}
    />
    <HeaderTab
      navItems={navList}
      currentIndex={currentTab}
      onChangeTab={(index) => {
        setCurrentTab(index);
        controlledSwiper && controlledSwiper.slideTo(index);
      }}
      style={{flex: 'none', paddingBottom: '0.25rem', marginTop: "0.4rem",zIndex:10}}
    />
    <div className="user-like-content">
      <Swiper
        className="user-swiper"
        controller={{control: controlledSwiper}}
        onSwiper={setControlledSwiper}
        initialSlide={type || 0}
        autoplay={false}
        onSlideChange={e => {
          setCurrentTab(e.realIndex);
        }}
      >
        {navList.map((item, index) => (<SwiperSlide key={`user-like-swiper-${index}`}>
          <List type={index}/>
        </SwiperSlide>))}
      </Swiper>
    </div>
  </div>), [navList, currentTab]);
};
