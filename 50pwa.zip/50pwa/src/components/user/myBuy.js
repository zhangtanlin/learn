import React, {useEffect, useMemo, useState} from "react";
import {Swiper, SwiperSlide} from "swiper/react";

import BackHeader from '../backHeader';
import HeaderTab from "./headerTab";
import Loading from '../loading';
import NoData from '../noData';
import ScrollArea from "../scrollarea";
import {SelectVideo} from '../weitie/qiupian/qiupian_card';

import Emit from "../../libs/eventEmitter";
import {apiGetMyBuy, getUserBookList} from '../../libs/http';
import {CartoonItem} from "../cartoon";
import {TwoColumnsVideo} from "../featured/twoColumnsVideo";
import {Concentration} from "../featured/concentration";

export const List = (props) => {
  const {type} = props;
  const [loading, setLoading] = useState(true);
  const [loadMore, setLoadMore] = useState(false);
  const [page, setPage] = useState(1);
  const [size, setSize] = useState(10);
  const [list, setList] = useState([]);
  const getList = async () => {
    setLoadMore(true);

    try {
      let mv_type = null;
      switch (type) {
        case 0:
          mv_type = 2;
          break;
        case 1:
          mv_type = 3;
          break;
      }
      const tempParam = {
        page, size, mv_type
      };

      if (type === 2) {
        delete tempParam.mv_type
        const res = await getUserBookList(tempParam)
        if (res?.status === 200) {
          if (page === 1) {
            setList(res?.data.list);
          } else {
            setList([...list, ...res?.data.list]);
          }
        } else {
          Emit.emit("showToast", {
            text: "请求列表失败", time: 3000
          });
        }
        setLoading(false);
        setLoadMore(false);
        return
      }

      const res = await apiGetMyBuy(tempParam);
      if (res?.status === 200) {
        if (page === 1) {
          setList(res?.data);
        } else {
          setList([...list, ...res?.data]);
        }
      } else {
        Emit.emit("showToast", {
          text: "请求列表失败", time: 3000
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败", time: 3000
      });
    }
    setLoading(false);
    setLoadMore(false);
  };
  const _loadMoreData = async () => {
    setPage((page) => (page + 1));
  };
  useEffect(() => {
    getList();
  }, [page, size]);
  return useMemo(() => (<div className="user-buy-list">
    {loading ? (<Loading show overSize={false}/>) : (list?.length > 0 ? (<ScrollArea
      loadingMore={loadMore}
      onScrollEnd={_loadMoreData}
    >
      <div style={{display: "flex", flexFlow: "wrap"}}>
        {type !== 2 && list.map((item, index) => (<Concentration
          key={`user-buy-item-${index}`}
          data={item}
        />))}

        {type === 2 && <div className={"Cartoon-page"}>
          <div className={"Cartoon-list"}>
            {list && list.map((item, index) => (<CartoonItem
              key={`user-like-item-${index}`}
              item={item}
            />))}
          </div>
        </div>}
      </div>
    </ScrollArea>) : (<NoData/>))}
  </div>), [type, loading, loadMore, list]);
};

export default (props) => {
  const {stackKey, type} = props; // type：选中的选项卡{0:全部,1:精选,2:拼多多}
  const navList = [{name: '精选',}, {name: '拼多多',}, {name: '漫画',},];
  const [currentTab, setCurrentTab] = useState(type || 0);
  const [controlledSwiper, setControlledSwiper] = useState(null);
  return useMemo(() => (<div className="positioned-container">
    <BackHeader
      stackKey={stackKey}
      title="我的购买"
    />
    <HeaderTab
      navItems={navList}
      currentIndex={currentTab}
      onChangeTab={(index) => {
        setCurrentTab(index);
        controlledSwiper && controlledSwiper.slideTo(index);
      }}
      style={{flex: 'none', paddingBottom: '0.25rem',}}
    />
    <div className="user-buy-content">
      <Swiper
        className="user-swiper"
        controller={{control: controlledSwiper}}
        onSwiper={setControlledSwiper}
        initialSlide={type || 0}
        autoplay={false}
        loop={false}
        onSlideChange={e => {
          setCurrentTab(e.realIndex);
        }}
      >
        {navList.map((item, index) => (<SwiperSlide key={`user-buy-swiper-${index}`}>
          <List type={index}/>
        </SwiperSlide>))}
      </Swiper>
    </div>
  </div>), [navList, currentTab]);
};
