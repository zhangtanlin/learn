import React, {useEffect, useMemo, useState} from "react";
import {Swiper, SwiperSlide} from "swiper/react";

import StackPage from "../stackpage";
import BackHeader from "../backHeader";
import ClickBtn from "../clickBtn";
import CaptchaDialog from "../captchaDialog";
import Country from "./country";

import StackStore from "../../store/stack";
import Emit from "../../libs/eventEmitter";
import GlobalVar from "../../libs/globalVar";
import {
  binPhone,
  verfiyPhone,
  sendPhoneCode,
  loginByPassword, registerByPassword
} from "../../libs/http";

export default props => {
  const {stackKey} = props;
  const [stacks] = StackStore.useGlobalState("stacks");

  const [currentTab, setCurrentTab] = useState(0);
  const [controlledSwiper, setControlledSwiper] = useState(null);
  const [footBtnText, setFootBtnText] = useState("下一步");
  // 【定义】图形验证码
  const [showCaptchaDialog, setShowCaptchaDialog] = useState(false);
  // 【定义】发送验证码
  const [params, setParams] = useState({
    prefix: 86,
    phone: "",
    code: "",
    password: "",
    verifyPassword: "",
    loginPassword: ""
  });
  const [startSend, setStartSend] = useState(false); // 开始倒计时
  let countdownFn = null;
  useEffect(() => {
    if (GlobalVar?.country?.code) {
      setParams({...params, ...{prefix: GlobalVar?.country?.code}});
    }
  }, [GlobalVar?.country?.code]);
  // 倒计时监听
  useEffect(() => {
    if (startSend) {
      let timeNum = 120;
      countdownFn = setInterval(() => {
        // console.log(timeNum);
        timeNum--;
        setFootBtnText(`立即登录  ${timeNum.toString()}s`);
        if (timeNum === 0) {
          clearInterval(countdownFn);
          setStartSend(false);
          setFootBtnText("重新获取");
        }
      }, 1000);
    }
    return () => {
      if (countdownFn) {
        clearInterval(countdownFn);
      }
    };
  }, [startSend]);
  // 发送验证码
  const onSendCaptch = value => {
    if (!value) {
      Emit.emit("showToast", {
        text: "请输入图形码～",
        time: 3000
      });
      return;
    }
    onSubmit(value);
  };
  // 选择国家
  const handleChooseCountry = () => {
    const stackKey = `user-share-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "user-share",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{zIndex: stacks.length + 2}}
          >
            <Country
              stackKey={stackKey}
              onSubmit={data => {
                // console.log("data", data);
              }}
            />
          </StackPage>
        )
      }
    });
  };
  // 底部按钮
  const onFootBtn = () => {
    if (currentTab === 0) {
      const reg = /^\s*$/g;
      if (reg.test(params.phone)) {
        Emit.emit("showToast", {
          text: "手机号不能为空～",
          time: 3000
        });
        return;
      }

      verfiyPhone({
        phone: params.phone
      }).then(res => {
        if (res?.data?.usedPhone) {
          setCurrentTab(2);
          controlledSwiper && controlledSwiper.slideTo(2);
        } else {
          onSubmit();
        }
      });
    }
  };
  // 提交
  const onSubmit = value => {
    // console.log("params", params);
    GlobalVar.bandPhone = params?.phone;
    sendPhoneCode({
      verify_code: value,
      phone: params.phone,
      mobile_prefix: params.prefix
    }).then(res => {
      if (res?.status === 253) {
        setShowCaptchaDialog(true);
      } else if (res.status === 200) {
        Emit.emit("showToast", {
          text: "验证码发送成功",
          time: 3000
        });
        if (currentTab === 0) {
          setCurrentTab(1);
        }
        setStartSend(true);
        setShowCaptchaDialog(false);
        setFootBtnText("120s");
        controlledSwiper && controlledSwiper.slideTo(1);
        // Emit.emit(stackKey, stackKey);
      } else {
        Emit.emit("showToast", {
          text: res.msg,
          time: 3000
        });
      }
    });
  };
  // 【页面】验证手机号
  const verifyPhonePage = () => (
    <div className="user-band-phone-verify">
      <div className="user-band-phone-bigtitle">输入电话号码</div>
      <div className="user-band-phone-form">
        <div className="user-band-phone-form-item">
          <ClickBtn
            className="user-band-phone-form-key"
            onTap={handleChooseCountry}
          >
            {`+${params.prefix}`}
          </ClickBtn>
          <div className="user-band-phone-form-value">
            <input
              type="text"
              placeholder="请输入手机号"
              defaultValue={params.phone}
              onChange={({target}) => {
                const cutTemp = target.value.replace(/[^\d]/g, "");
                if (cutTemp.length > 11) {
                  const strTemp = String(cutTemp).slice(0, 11);
                  target.value = strTemp;
                  setParams({...params, ...{phone: strTemp}});
                  Emit.emit("showToast", {
                    text: "手机号不能超过11字"
                  });
                } else {
                  target.value = cutTemp;
                  setParams({...params, ...{phone: cutTemp}});
                }
              }}
            />
          </div>
        </div>
      </div>
    </div>
  );
  // 【页面】输入密码登录
  const loginPhonePage = () => (
    <div className="user-band-phone-verify">
      <div className="user-band-phone-bigtitle">登陆或注册</div>

      <div className="user-band-phone-form">
        <div className="user-band-phone-form-item">
          <div
            className="user-band-phone-form-key"
          >
            账号/手机号
          </div>
          <div className="user-band-phone-form-value">
            <input
              type="text"
              placeholder="账号/手机号"
              defaultValue={params.phone}
              onChange={({target}) => {
                setParams({...params, ...{phone: target.value}});
              }}
            />
          </div>
        </div>
      </div>

      <div style={{marginTop: '0.5rem'}} className="user-band-phone-form">
        <div className="user-band-phone-form-item">
          <div className="user-band-phone-form-key">账号密码</div>
          <div className="user-band-phone-form-value">
            <input
              type="password"
              placeholder="请输入密码"
              onChange={({target}) => {
                // const cutTemp = target.value.replace(/[^\d]/g, '');
                if (target.value) {
                  setParams({...params, ...{loginPassword: target.value}});
                }
              }}
            />
          </div>
        </div>
      </div>


      <div style={{display: "flex"}}>
        <ClickBtn
          className="user-public-btn"
          styles={{
            marginTop: "1.5rem",
            flex: 1
          }}
          onTap={() => {
            loginByPassword({
              phone: params.phone,
              password: params.loginPassword
            }).then(res => {
              if (res.status === 200) {
                window.location.reload();
                // global.token = res.data.token;
                // localStorage.setItem("50_token", res.data.token);
              } else {
                Emit.emit("showToast", {
                  text: res.msg
                });
              }
            });
          }}
        >
          登录
        </ClickBtn>
        <ClickBtn
          className="user-public-btn"
          styles={{
            marginTop: "1.5rem",
            flex: 1
          }}
          onTap={() => {
            registerByPassword({
              phone: params.phone,
              password: params.loginPassword
            }).then(res => {
              if (res.status === 200) {
                window.location.reload();
                // global.token = res.data.token;
                // localStorage.setItem("50_token", res.data.token);
              } else {
                Emit.emit("showToast", {
                  text: res.msg
                });
              }
            });
          }}
        >
          注册
        </ClickBtn>
      </div>
    </div>
  );
  // 【页面】输入验证码
  const EnterCode = () => (
    <>
      <div className="user-band-phone-title" style={{marginTop: "1rem"}}>
        验证码我们已发送至手机
      </div>
      <div className="user-band-phone-title">
        {params.prefix ? `+${params.prefix}` : ""}
        {params.phone}
      </div>
      <div
        className="user-input-box center"
        style={{width: "6rem", margin: "1rem auto", textAlign: "center"}}
      >
        <input
          type="number"
          placeholder="请输入验证码"
          onChange={({target}) => {
            const cutTemp = target.value.replace(/[^\d]/g, "");
            if (cutTemp.length > 6) {
              const strTemp = String(cutTemp).slice(0, 6);
              target.value = strTemp;
              setParams({...params, ...{code: strTemp}});
              Emit.emit("showToast", {
                text: "验证码应该是6位"
              });
            } else {
              target.value = cutTemp;
              setParams({...params, ...{code: cutTemp}});
            }
          }}
        />
      </div>
      <div
        className="user-band-phone-subtitle"
        style={{margin: "0.32rem 0", marginBottom: "0.75rem"}}
      >
        请输入收到信息当中的验证码
      </div>
      <div className="user-changepwd-content">
        <div className="user-changepwd-form">
          <div className="user-form-item">
            <div className="user-form-key">设置密码</div>
            <div className="user-form-value">
              <input
                type="password"
                placeholder="请输入密码"
                onChange={({target}) => {
                  // const cutTemp = target.value.replace(/[^\d]/g, '');
                  if (target.value) {
                    setParams({...params, ...{password: target.value}});
                  }
                }}
              />
            </div>
          </div>
          <div className="user-form-item">
            <div className="user-form-key">确认密码</div>
            <div className="user-form-value">
              <input
                type="password"
                placeholder="请输入密码"
                onChange={({target}) => {
                  // const cutTemp = target.value.replace(/[^\d]/g, '');
                  if (target.value) {
                    setParams({
                      ...params,
                      ...{verifyPassword: target.value}
                    });
                  }
                }}
              />
            </div>
          </div>
        </div>
      </div>
      <ClickBtn
        className="user-public-btn"
        style={{marginTop: "3rem"}}
        onTap={() => {
          if (footBtnText === "重新获取") {
            onSubmit();
          } else {
            if (params.password.length < 6) {
              Emit.emit("showToast", {
                text: "请输入至少六位数密码"
              });
              return;
            }
            if (params.password !== params.verifyPassword) {
              Emit.emit("showToast", {
                text: "两次密码输入不一致"
              });
              return;
            }
            binPhone({
              phone: params.phone,
              phonePrefix: params.prefix,
              password: params.password,
              code: params.code
            }).then(res => {
              // console.log("绑定手机", res);
              if (res.status === 200) {
                Emit.emit("showToast", {
                  text: "手机绑定成功"
                });
                window.location.reload();
              } else {
                Emit.emit("showToast", {
                  text: res.msg
                });
              }
            });
          }
        }}
      >
        {footBtnText}
      </ClickBtn>
    </>
  );

  return useMemo(
    () => (
      <div className="positioned-container user-band-phone">
        <CaptchaDialog
          show={showCaptchaDialog}
          onClose={setShowCaptchaDialog}
          setCode={e => onSendCaptch(e)}
        />
        <BackHeader
          stackKey={stackKey}
          leftIconIsDark
          // rightBtn={() => (
          //   <ClickBtn
          //     style={{ fontSize: '0.35rem', color: 'red', }}
          //     onTap={() => onSubmit()}
          //   >
          //     确定
          //   </ClickBtn>
          // )}
          style={{background: "white", color: "#fd5c18"}}
        />
        <div className="user-band-phone-content">
          <Swiper
            className="user-swiper swiper-no-swiping"
            controller={{control: controlledSwiper}}
            onSwiper={setControlledSwiper}
            onSlideChange={e => {
              setCurrentTab(e.realIndex);
            }}
            autoplay={false}
            loop={false}
          >
            {/*<SwiperSlide>{verifyPhonePage()}</SwiperSlide>*/}
            {/*<SwiperSlide>{EnterCode()}</SwiperSlide>*/}
            <SwiperSlide>{loginPhonePage()}</SwiperSlide>
          </Swiper>
          {/*{currentTab === 0 ? (*/}
          {/*  <ClickBtn className="user-public-btn" onTap={() => onFootBtn()}>*/}
          {/*    下一步*/}
          {/*  </ClickBtn>*/}
          {/*) : (*/}
          {/*  <></>*/}
          {/*)}*/}
        </div>
      </div>
    ),
    [controlledSwiper, currentTab, showCaptchaDialog, params, footBtnText]
  );
};
