import React, { useEffect, useMemo, useState } from "react";

import BackHeader from "../backHeader";
import ScrollArea from "../scrollarea";
import StackPage from "../stackpage";
import StackStore from "../../store/stack";
import Loading from "../loading";
import NoData from "../noData";
import { getQuestions } from "../../libs/http";
import Simg from "../simg";
import ClickBtn from "../clickBtn";
import QuestionDetail from "./questionDetail";
import KefuDetail from "./kefuDetail";
import GlobalVar from "../../libs/globalVar";
export default (props) => {
  const { stackKey } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const [questionList, setQuestionList] = useState([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    getQuestions().then((res) => {
      // console.log("getQuestions", res);
      setLoading(false);
      setQuestionList(res.data);
    });
  }, []);
  const toDetail = (data) => {
    const stackKey = `QuestionDetail-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "QuestionDetail",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <QuestionDetail stackKey={stackKey} data={data} />
          </StackPage>
        ),
      },
    });
  };
  const toKefu = () => {
    const stackKey = `KefuDetail-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "KefuDetail",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <KefuDetail stackKey={stackKey} />
          </StackPage>
        ),
      },
    });
  };
  const questionItem = (item, index) => {
    return (
      <div
        className="onlinekefu-questionItem"
        key={`onlinekefu-questionItem-${index}`}
      >
        <p>{item.name}</p>
        {item.items.map((k, i) => {
          return (
            <ClickBtn
              className="onlinekefu-questionItem-item"
              key={`onlinekefu-questionItem-item-${i}`}
              onTap={() => {
                toDetail(k);
              }}
            >{`${k.question} >>`}</ClickBtn>
          );
        })}
      </div>
    );
  };
  return (
    <div className="page-content-flex">
      <BackHeader
        stackKey={stackKey}
        title="在线客服"
        rightBtn={() => {
          return (
            <ClickBtn
              styles={{ color: "#fd5c18", fontSize: "0.35rem" }}
              onTap={() => {
                if (GlobalVar?.officialGroup[0].url) {
                  window.open(GlobalVar?.officialGroup[0].url, "_blank");
                }
              }}
            >
              加入官方群
            </ClickBtn>
          );
        }}
      />
      {loading ? (
        <Loading show overSize={false} size={30} />
      ) : questionList.length > 0 ? (
        <ScrollArea>
          {questionList.map((item, index) => {
            return questionItem(item, index);
          })}
        </ScrollArea>
      ) : (
        <NoData />
      )}
      <div className="onlinekefu-btn-box">
        <ClickBtn className="onlinekefu-btn" onTap={toKefu}>
          在线客服
        </ClickBtn>
      </div>
    </div>
  );
};
