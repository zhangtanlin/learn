import React, {useEffect, useMemo, useState} from "react";

import StackPage from "../stackpage";
import StackStore from "../../store/stack";
import UserStore from "../../store/user";
import ScrollArea from "../scrollarea";
import ClickBtn from "../clickBtn";
import BackHeader from "../backHeader";

import imgSetting from "../../resources/img/user/setting.png";
import iconMember from "../../resources/img/user/iconMember.png";

import iconActiveMember from "../../resources/img/user/iconActiveMember.png";
import iconActiveBuy from "../../resources/img/user/iconActiveBuy.png";
import iconActiveWallet from "../../resources/img/user/iconActiveWallet.png";
import iconActiveShare from "../../resources/img/user/iconActiveShare.png";
import iconActiveLike from "../../resources/img/user/iconActiveLike.png";
import iconActiveFans from "../../resources/img/user/iconActiveFans.png";
import iconActiveMakeMoney from "../../resources/img/user/iconActiveMakeMoney.png";
import iconActivePost from "../../resources/img/user/iconActivePost.png";
import iconActiveMyDating from "../../resources/img/user/iconActiveMyDating.png";

import iconServerAttest from "../../resources/img/user/iconServerAttest.png";
import iconServerMsg from "../../resources/img/user/iconServerMsg.png";
import iconServerCustomer from "../../resources/img/user/iconServerCustomer.png";
import iconServerBulletin from "../../resources/img/user/iconServerBulletin.png";
import iconServerSet from "../../resources/img/user/iconServerSet.png";
import iconServerGroup from "../../resources/img/user/iconServerGroup.png";
import iconServerApp from "../../resources/img/user/iconServerApp.png";
import iconServerExchangeCode from "../../resources/img/user/iconServerExchangeCode.png";
import iconServerInviteCode from "../../resources/img/user/iconServerInviteCode.png";

import MyShare from "./myShare";
import MyMember from "./myMember";
import MyWallet from "./myWallet";
import MyBuy from "./myBuy";
import MyLike from "./myLike";
import MyFans from "./myFans";
import MyMakeMoney from "./myMakeMoney";
import MyPost from "./myPost";
import App from "./app";
import Bulletin from "./bulletin";
import Set from "./set";
import MyMsg from "./myMsg";
import Manage from "./manage";
import Simg from "../simg";
import BandPhone from "./bandPhone";
import OnlineKefu from "./onlineKefu";

import Emit from "../../libs/eventEmitter";
import {getUserInfo, apiSetInvite, apiSetExchange} from "../../libs/http";
import GlobalVar from "../../libs/globalVar";
import MyDating from "./myDating";
import GroupManage from "../group";

export default (props) => {
  const {isVisible} = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const [user] = UserStore.useGlobalState("user");

  let inviteCode = "";
  let exchangeCode = "";
  // 跳转会员购买
  const onMember = () => {
    const stackKey = `user-member-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "user-member",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{zIndex: stacks.length + 2}}
          >
            <MyMember stackKey={stackKey}/>
          </StackPage>
        ),
      },
    });
  };
  const activeList = [
    // {
    //   name: "会员中心",
    //   icon: iconActiveMember,
    //   onTap: () => onMember(),
    // },
    {
      name: "约炮解锁",
      icon: iconActiveMyDating,
      onTap: () => {
        const stackKey = `MyDating-${new Date().getTime()}`;
        StackStore.dispatch({
          type: "push",
          payload: {
            name: "MyDating",
            element: (
              <StackPage
                stackKey={stackKey}
                key={stackKey}
                style={{zIndex: stacks.length + 2}}
              >
                <MyDating stackKey={stackKey}/>
              </StackPage>
            ),
          },
        });
      },
    },
    {
      name: "购买",
      icon: iconActiveBuy,
      onTap: () => {
        const stackKey = `user-buy-${new Date().getTime()}`;
        StackStore.dispatch({
          type: "push",
          payload: {
            name: "user-buy",
            element: (
              <StackPage
                stackKey={stackKey}
                key={stackKey}
                style={{zIndex: stacks.length + 2}}
              >
                <MyBuy stackKey={stackKey}/>
              </StackPage>
            ),
          },
        });
      },
    },
    {
      name: "钱包",
      icon: iconActiveWallet,
      onTap: () => {
        const stackKey = `user-wallet-${new Date().getTime()}`;
        StackStore.dispatch({
          type: "push",
          payload: {
            name: "user-wallet",
            element: (
              <StackPage
                stackKey={stackKey}
                key={stackKey}
                style={{zIndex: stacks.length + 2}}
              >
                <MyWallet stackKey={stackKey}/>
              </StackPage>
            ),
          },
        });
      },
    },
    {
      name: "分享无限看",
      icon: iconActiveShare,
      onTap: () => {
        const stackKey = `user-share-${new Date().getTime()}`;
        StackStore.dispatch({
          type: "push",
          payload: {
            name: "user-share",
            element: (
              <StackPage
                stackKey={stackKey}
                key={stackKey}
                style={{zIndex: stacks.length + 2}}
              >
                <MyShare stackKey={stackKey}/>
              </StackPage>
            ),
          },
        });
      },
    },
    {
      name: "我的喜欢",
      icon: iconActiveLike,
      onTap: () => {
        const stackKey = `user-like-${new Date().getTime()}`;
        StackStore.dispatch({
          type: "push",
          payload: {
            name: "user-like",
            element: (
              <StackPage
                stackKey={stackKey}
                key={stackKey}
                style={{zIndex: stacks.length + 2}}
              >
                <MyLike stackKey={stackKey}/>
              </StackPage>
            ),
          },
        });
      },
    },
    {
      name: "粉丝团",
      icon: iconActiveFans,
      onTap: () => {
        const stackKey = `user-fans-${new Date().getTime()}`;
        StackStore.dispatch({
          type: "push",
          payload: {
            name: "user-fans",
            element: (
              <StackPage
                stackKey={stackKey}
                key={stackKey}
                style={{zIndex: stacks.length + 2}}
              >
                <MyFans stackKey={stackKey}/>
              </StackPage>
            ),
          },
        });
      },
    },
    {
      name: "代理赚钱",
      icon: iconActiveMakeMoney,
      onTap: () => {
        const stackKey = `user-make-money-${new Date().getTime()}`;
        StackStore.dispatch({
          type: "push",
          payload: {
            name: "user-make-money",
            element: (
              <StackPage
                stackKey={stackKey}
                key={stackKey}
                style={{zIndex: stacks.length + 2}}
              >
                <MyMakeMoney stackKey={stackKey}/>
              </StackPage>
            ),
          },
        });
      },
    },
    {
      name: "我的微贴",
      icon: iconActivePost,
      onTap: () => {
        const stackKey = `user-post-${new Date().getTime()}`;
        StackStore.dispatch({
          type: "push",
          payload: {
            name: "user-post",
            element: (
              <StackPage
                stackKey={stackKey}
                key={stackKey}
                style={{zIndex: stacks.length + 2}}
              >
                <MyPost stackKey={stackKey}/>
              </StackPage>
            ),
          },
        });
      },
    },
  ];
  // 认证状态
  const isCreator = () => {
    switch (user?.creator) {
      case 1:
        return "认证中";
      case 2:
        return "认证失败";
      case 3:
        return "拉黑";
      case 4:
        return "已认证";
      default:
        return "未认证";
    }
  };
  // 认证管理
  const handleCreator = () => {
    Emit.emit("changeAlert", {
      _title: "提示",
      _content: "请下载app进行认证操作",
      _submitText: "确认",
      _notDouble: true,
      _submit: () => {
        window.open(GlobalVar.downloadUrl, "_blank");
      },
    });
    // if (user?.creator === 1) {
    //   Emit.emit("showToast", {
    //     text: "认证中，请耐心等待平台处理",
    //     time: 3000,
    //   });
    // } else if (user?.creator === 2) {
    //   Emit.emit("showToast", {
    //     text: "认证失败",
    //     time: 3000,
    //   });
    // } else if (user?.creator === 3) {
    //   Emit.emit("showToast", {
    //     text: "您已被拉黑，请联系客服处理",
    //     time: 3000,
    //   });
    // } else if (user?.creator === 4) {
    //   const stackKey = `user-creator-manager-${new Date().getTime()}`;
    //   StackStore.dispatch({
    //     type: "push",
    //     payload: {
    //       name: "user-creator-manager",
    //       element: (
    //         <StackPage
    //           stackKey={stackKey}
    //           key={stackKey}
    //           style={{ zIndex: stacks.length + 2 }}
    //         >
    //           <CreatorManage stackKey={stackKey} />
    //         </StackPage>
    //       ),
    //     },
    //   });
    // } else {
    //   const stackKey = `user-become-creator-${new Date().getTime()}`;
    //   StackStore.dispatch({
    //     type: "push",
    //     payload: {
    //       name: "user-become-creator",
    //       element: (
    //         <StackPage
    //           stackKey={stackKey}
    //           key={stackKey}
    //           style={{ zIndex: stacks.length + 2 }}
    //         >
    //           <BecomeCreator stackKey={stackKey} />
    //         </StackPage>
    //       ),
    //     },
    //   });
    // }
  };
  const attestList = [
    {
      name: "认证管理",
      icon: iconServerAttest,
      status: isCreator(),
      onTap: () => handleCreator(),
    },
    {
      name: "邀请码",
      icon: iconServerInviteCode,
      status: user?.invited_by,
      onTap: () => onInvite(),
    },
  ];
  // 邀请码
  const onInvite = () => {
    if (user?.invited_by) {
      Emit.emit("showToast", {
        text: "已经填写过邀请码了～",
        time: 3000,
      });
    } else {
      Emit.emit("changeAlert", {
        _title: "邀请码",
        _boxStyle: {background: "#fff", color: "#000"},
        _content: (
          <div className="user-input-box center" style={{width: "6rem"}}>
            <input
              type="text"
              placeholder="请输入邀请码"
              onChange={({target}) => {
                const tempReplace = target.value.replace(/^\s+|\s+$/g, "");
                if (tempReplace.length > 8) {
                  const tempCut = String(tempReplace).slice(0, 8);
                  target.value = tempCut;
                  inviteCode = tempCut;
                  Emit.emit("showToast", {text: "邀请码不大于8位"});
                } else {
                  target.value = tempReplace;
                  inviteCode = tempReplace;
                }
              }}
            />
          </div>
        ),
        _submitText: "确定",
        _submit: async () => {
          try {
            const res = await apiSetInvite({aff_code: inviteCode});
            if (res?.status === 251) {
              Emit.emit("showToast", {text: "邀请码绑定成功"});
              _pullDownRefresh();
            } else {
              Emit.emit("showToast", {text: res?.msg || "邀请码绑定失败"});
            }
          } catch (error) {
            Emit.emit("showToast", {text: "邀请码绑定失败"});
          }
        },
        _notDouble: true,
      });
    }
  };
  // 兑换码
  const onExchange = () => {
    Emit.emit("changeAlert", {
      _title: "兑换码",
      _boxStyle: {background: "#fff", color: "#000"},
      _content: (
        <div className="user-input-box center" style={{width: "6rem"}}>
          <input
            type="text"
            placeholder="请输入兑换码"
            onChange={({target}) => {
              const tempReplace = target.value.replace(/^\s+|\s+$/g, "");
              if (tempReplace.length > 30) {
                const tempCut = String(tempReplace).slice(0, 30);
                target.value = tempCut;
                exchangeCode = tempCut;
                Emit.emit("showToast", {text: "兑换码不大于8位"});
              } else {
                target.value = tempReplace;
                exchangeCode = tempReplace;
              }
            }}
          />
        </div>
      ),
      _submitText: "确定",
      _submit: async () => {
        try {
          const res = await apiSetExchange({code: exchangeCode});
          if (res?.status === 251) {
            Emit.emit("showToast", {text: "兑换码兑换成功"});
            _pullDownRefresh();
          } else {
            Emit.emit("showToast", {text: res?.msg || "兑换码兑换失败"});
          }
        } catch (error) {
          Emit.emit("showToast", {text: "兑换码兑换失败"});
        }
      },
      _notDouble: true,
    });
  };
  const serverList = [
    {
      name: "认证管理",
      icon: iconServerAttest,
      status: isCreator(),
      onTap: () => handleCreator(),
    },
    {
      name: "我的消息",
      icon: iconServerMsg,
      status: "",
      onTap: () => {
        const stackKey = `user-msg-${new Date().getTime()}`;
        StackStore.dispatch({
          type: "push",
          payload: {
            name: "user-msg",
            element: (
              <StackPage
                stackKey={stackKey}
                key={stackKey}
                style={{zIndex: stacks.length + 2}}
              >
                <MyMsg stackKey={stackKey}/>
              </StackPage>
            ),
          },
        });
      },
    },
    {
      name: "在线客服",
      icon: iconServerCustomer,
      status: "",
      onTap: () => {
        const stackKey = `user-kefu-${new Date().getTime()}`;
        StackStore.dispatch({
          type: "push",
          payload: {
            name: "user-kefu",
            element: (
              <StackPage
                stackKey={stackKey}
                key={stackKey}
                style={{zIndex: stacks.length + 2}}
              >
                <OnlineKefu stackKey={stackKey}/>
              </StackPage>
            ),
          },
        });
      },
    },
    {
      name: "官方公告",
      icon: iconServerBulletin,
      status: "",
      onTap: () => {
        const stackKey = `user-bulletin-${new Date().getTime()}`;
        StackStore.dispatch({
          type: "push",
          payload: {
            name: "user-bulletin",
            element: (
              <StackPage
                stackKey={stackKey}
                key={stackKey}
                style={{zIndex: stacks.length + 2}}
              >
                <Bulletin stackKey={stackKey}/>
              </StackPage>
            ),
          },
        });
      },
    },
    {
      name: "设置",
      icon: iconServerSet,
      status: "",
      onTap: () => {
        const stackKey = `user-set-${new Date().getTime()}`;
        StackStore.dispatch({
          type: "push",
          payload: {
            name: "user-set",
            element: (
              <StackPage
                stackKey={stackKey}
                key={stackKey}
                style={{zIndex: stacks.length + 2}}
              >
                <Set stackKey={stackKey}/>
              </StackPage>
            ),
          },
        });
      },
    },
    {
      name: "加入官方群",
      icon: iconServerGroup,
      status: "",
      onTap: () => {
        if (GlobalVar?.officialGroup[0].url) {
          window.open(GlobalVar?.officialGroup[0].url, "_blank");
        }
      },
    },
    {
      name: "应用中心",
      icon: iconServerApp,
      status: "",
      onTap: () => {
        const stackKey = `user-app-${new Date().getTime()}`;
        StackStore.dispatch({
          type: "push",
          payload: {
            name: "user-app",
            element: (
              <StackPage
                stackKey={stackKey}
                key={stackKey}
                style={{zIndex: stacks.length + 2}}
              >
                <App stackKey={stackKey}/>
              </StackPage>
            ),
          },
        });
      },
    },
    {
      name: "兑换码",
      icon: iconServerExchangeCode,
      status: "",
      onTap: () => onExchange(),
    },
    {
      name: "邀请码",
      icon: iconServerInviteCode,
      status: user?.invited_by,
      onTap: () => onInvite(),
    },
  ];
  // 个人管理
  const handleManage = () => {
    const stackKey = `user-manager-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "user-manager",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{zIndex: stacks.length + 2}}
          >
            <Manage stackKey={stackKey}/>
          </StackPage>
        ),
      },
    });
  };
  const [pageStatus, setPageStatus] = useState(0);
  // 下拉刷新
  const _pullDownRefresh = async () => {
    try {
      const res = await getUserInfo();
      GlobalVar.uuid = res.data.uuid;
      const tempObject = {
        ...res.data,
        ...{daily_view: user.daily_view},
      }; // 字段说明参考userStore
      UserStore.dispatch({
        type: "replace",
        payload: tempObject,
      });
    } catch (error) {
      Emit.emit("showToast", {
        text: "刷新用户信息失败",
      });
    }
  };
  useEffect(() => {
    if (isVisible && pageStatus === 0) {
      setPageStatus(2);
    }
  }, [isVisible]);
  // vip等级块
  const setVipLevelItem = () => {
    let text = "开通会员无限看片";
    let showBtn = false; // 是否显示立即开通按钮
    if (user?.vip) {
      switch (user?.vip_level) {
        case 1:
          text = `您是月卡会员，到期时间${user?.expired_at}`;
          break;
        case 2:
          text = `您是季卡会员，到期时间${user?.expired_at}`;
          break;
        case 3:
          text = `您是年卡会员，到期时间${user?.expired_at}`;
          break;
        case 4:
          text = `您是尊贵的永久会员，永不到期`;
          break;
        default:
          text = `您是临时会员，到期时间${user?.expired_at}`;
          break;
      }
    } else {
      showBtn = true;
    }
    return (
      <ClickBtn className="user-member-box" onTap={() => onMember()}>
        <div className="user-member-info">
          <img className="user-member-icon" src={iconMember}/>
          <span>{text}</span>
        </div>
        {showBtn ? <div className="user-member-btn">查看详情</div> : <></>}
      </ClickBtn>
    );
  };
  // 设置按钮
  const handleSet = () => {
    const stackKey = `user-set-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "user-set",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{zIndex: stacks.length + 2}}
          >
            {user?.phone ? (
              <Set stackKey={stackKey}/>
            ) : (
              <BandPhone stackKey={stackKey}/>
            )}
          </StackPage>
        ),
      },
    });
  };

  return useMemo(
    () => (pageStatus ?
        <div
          className={`positioned-container ${isVisible ? "visible" : "hide"
          } user-page`}
        >
          {/*<BackHeader*/}
          {/*  left={() => <div className="user-header-left">我的</div>}*/}
          {/*  right={() => (*/}
          {/*    <ClickBtn className="user-header-right" onTap={() => handleSet()}>*/}
          {/*      <img src={imgSetting} />*/}
          {/*    </ClickBtn>*/}
          {/*  )}*/}
          {/*/>*/}
          <ScrollArea pullDonRefresh={_pullDownRefresh}>
            <div className="user-header-content">
              <ClickBtn className="user-avatar-box" onTap={handleManage}>
                <div className="user-avatar">
                  <Simg src={user?.thumb}/>
                </div>
                <div className="user-avatar-info">
                  <div className="user-avatar-title">{user?.nickname}</div>
                  {
                    user.phone ? <></> :
                      <ClickBtn onTap={() => handleSet()} className="user-avatar-login-tips">
                        登录/注册<span style={{fontSize: "0.6rem"}}>›</span>
                      </ClickBtn>
                  }
                  {/* <div className="user-avatar-subtitle">
                  剩余免费观看次数：
                  {user?.vip ? '无限' : user?.daily_view}
                </div> */}
                </div>
              </ClickBtn>
              <div className="user-info-box">
                <div className="user-info-item">
                  <div className="user-info-item-title">{user?.videos_count}</div>
                  <div className="user-info-item-subtitle">作品</div>
                </div>
                <div className="user-info-item">
                  <div className="user-info-item-title">{user?.followed}</div>
                  <div className="user-info-item-subtitle">粉丝</div>
                </div>
                <div className="user-info-item">
                  <div className="user-info-item-title">
                    {user?.fabulous_count}
                  </div>
                  <div className="user-info-item-subtitle">获赞</div>
                </div>
              </div>
              {setVipLevelItem()}
              <div className="user-active-box">
                {activeList.map((item, index) => (
                  <ClickBtn key={`user-active-item-${index}`} onTap={item.onTap}>
                    <div className="user-active-item">
                      <img className="user-active-icon" src={item.icon}/>
                      <p className="user-active-title">{item.name}</p>
                    </div>
                  </ClickBtn>
                ))}
              </div>
              {/*<div className="user-server-box">*/}
              {/*  {attestList.map((item, index) => (*/}
              {/*    <ClickBtn*/}
              {/*      key={`user-server-item-${index}`}*/}
              {/*      className="user-server-item"*/}
              {/*      onTap={item.onTap}*/}
              {/*    >*/}
              {/*      <div className="user-server-item-left">*/}
              {/*        <img className="user-server-item-icon" src={item.icon} />*/}
              {/*        <div className="user-server-item-title">{item.name}</div>*/}
              {/*      </div>*/}
              {/*      <div className="user-server-item-right">{item.status}</div>*/}
              {/*    </ClickBtn>*/}
              {/*  ))}*/}
              {/*</div>*/}
              <div className="user-active-box">
                {serverList.map((item, index) => (
                  <ClickBtn key={`user-active-item-${index}`} onTap={item.onTap}>
                    <div className="user-active-item">
                      <img className="user-active-icon" src={item.icon}/>
                      <p className="user-active-title">{item.name}</p>
                    </div>
                  </ClickBtn>
                ))}
              </div>
            </div>
          </ScrollArea>
        </div> : <></>
    ),
    [isVisible, user, activeList, serverList]
  );
};
