import React, { useEffect, useMemo, useState } from "react";

import BackHeader from "../backHeader";
import ScrollArea from "../scrollarea";
import StackPage from "../stackpage";
import StackStore from "../../store/stack";
import Loading from "../loading";
import NoData from "../noData";
import { getFeedbackList, sendFeedback } from "../../libs/http";
import Simg from "../simg";
import ClickBtn from "../clickBtn";
import QuestionDetail from "./questionDetail";
import Emit from "../../libs/eventEmitter";
import CommentInput from "../commentInput";
import mineIcon from "../../resources/img/public/icon_message_me.png";
import imgIcon from "../../resources/img/public/icon_message_img.png";
import iconLogo from "../../resources/img/public/iconLogo.jpg";
import { UploadRequest } from "../../libs/uploadImg";
let getting = false;
export default (props) => {
  const { stackKey } = props;
  const [showInput, setShowInput] = useState(false);
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState({ a: true });
  const [stacks] = StackStore.useGlobalState("stacks");
  let page = 1;
  useEffect(() => {
    getData("init");
  }, []);
  const getData = (status) => {
    if (!loadingMore.a || getting) return;
    if (!status) {
      page++;
    }
    getFeedbackList({ page })
      .then((res) => {
        // console.log("getFeedbackList=>", page, res);
        if (res.data.length > 0) {
          if (status) {
            setData(res.data.reverse());
          } else {
            setData((pre) => [...pre, ...res.data].reverse());
          }
        } else {
          if (page == 1) {
            setData([]);
          }
          loadingMore.a = false;
          setLoadingMore({ ...loadingMore });
        }
        setLoading(false);
        getting = false;
      })
      .catch(() => {
        setLoading(false);
        getting = false;
      });
  };
  const onSetCover = async ({ target }) => {
    setLoading(true);
    const imgFile = new FileReader();
    imgFile.readAsDataURL(target.files[0]);
    imgFile.onload = () => {
      UploadRequest({
        id: new Date().getTime(),
        cover: imgFile.result.toString(),
      })
        .then((res) => {
          if (res) {
            sendMsg(res, true);
          } else {
            Emit.emit("changeAlert", {
              _title: "提示",
              _content: "图片上传失败，请稍后再试",
              _submitText: "确定",
              _submit: () => {},
              _notDouble: true,
            });
            setLoading(false);
          }
        })
        .catch(() => {
          setLoading(false);
          Emit.emit("changeAlert", {
            _title: "提示",
            _content: "图片上传失败，请稍后再试",
            _submitText: "确定",
            _submit: () => {},
            _notDouble: true,
          });
        });
    };
  };
  const sendMsg = (value, status) => {
    if (!status && !value) {
      Emit.emit("showToast", { text: "请输入内容！" });
      return;
    }
    let pramas = {};
    if (status) {
      pramas.image = value;
      pramas.message_type = 2;
    } else {
      pramas.content = value;
      pramas.message_type = 1;
    }
    sendFeedback(pramas)
      .then((res) => {
        Emit.emit("showToast", { text: res.msg });
        getting = false;
        setLoading(false);
        page = 1;
        loadingMore.a = true;
        setLoadingMore({ ...loadingMore });
        getData("init");
      })
      .catch(() => {
        getting = false;
        setLoading(false);
        Emit.emit("changeAlert", {
          _title: "提示",
          _content: "反馈信息上传失败，请稍后再试",
          _submitText: "确定",
          _submit: () => {},
          _notDouble: true,
        });
      });
  };
  const mineItem = (item, index) => {
    return (
      <div key={index} className="kefuDetail-mineItem">
        <div className="kefuDetail-msg-time">{item.createdAt}</div>
        <div className="kefuDetail-msg">
          {item.messageType == 1 ? (
            <div className="kefuDetail-msg-content">{item.message}</div>
          ) : (
            <div className="kefuDetail-img">
              <Simg src={item.message} objectFit="contain" alwaysShow />
            </div>
          )}
          <img className="kefuDetail-avatar" src={mineIcon} />
        </div>
      </div>
    );
  };
  const hisItem = (item, index) => {
    return (
      <div key={index} className="kefuDetail-hisItem">
        <div className="kefuDetail-msg-time">{item.createdAt}</div>
        <div className="kefuDetail-msg">
          <img className="kefuDetail-avatar" src={iconLogo} />
          {item.messageType == 1 ? (
            <div className="kefuDetail-msg-content">{item.message}</div>
          ) : (
            <div className="kefuDetail-img">
              <Simg src={item.message} objectFit="contain" alwaysShow />
            </div>
          )}
        </div>
      </div>
    );
  };
  return (
    <div className="page-content-flex kefuDetail">
      <BackHeader
        stackKey={stackKey}
        leftIconIsDark
        style={{ color: "rgb(51, 51, 51)" }}
        title="50度灰在线"
        right={() => {
          return <div style={{ width: "1.2rem" }} />;
        }}
      />
      {data.length > 0 && (
        <ScrollArea
          ListData={data}
          onScrollEnd={getData}
          loadingMore={loadingMore.a}
          startToBottom
          noEndText
        >
          {data.map((item, index) => {
            if (item.status == 1) {
              return mineItem(item, index);
            }
            return hisItem(item, index);
          })}
          <div style={{ height: "1.5rem" }} />
        </ScrollArea>
      )}
      <div className="kefuDetail-btn">
        <div className="thin-line" />
        <div>
          <div className="kefuDetail-uploadImg">
            <img src={imgIcon} />
            <input type="file" accept="image/*" onChange={onSetCover} />
          </div>
          <ClickBtn
            className="kefuDetail-btn-input"
            onTap={() => {
              setShowInput(true);
            }}
          >
            输入意见或想说的
          </ClickBtn>
          <div className="kefuDetail-btn-send">发送</div>
        </div>
      </div>
      {showInput && (
        <CommentInput
          onClose={() => {
            setShowInput(false);
          }}
          placeholder="输入意见或想说的"
          onSubmit={sendMsg}
        />
      )}
      {loading && <Loading show overSize />}
    </div>
  );
};
