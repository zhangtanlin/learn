import React from "react";
import QRCode from "qrcode.react";

import StackPage from "../stackpage";
import StackStore from "../../store/stack";
import UserStore from "../../store/user";
import { copyText } from '../../libs/utils';
import Emit from "../../libs/eventEmitter";

import ScrollArea from "../scrollarea";
import BackHeader from '../backHeader';
import ClickBtn from '../clickBtn';
import MyInvite from './myInvite';
// 分享
export default (props) => {
  const { stackKey } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const [user] = UserStore.useGlobalState("user");

  const shareQrcode = user?.aff_url;
  const shareCode = user?.aff_code;
  const shareCopy = user?.aff_url_copy;

  const handleInvite = () => {
    const stackKey = `user-wallet-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "user-wallet",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <MyInvite stackKey={stackKey} />
          </StackPage>
        )
      }
    });
  };
  const handleSaveLink = () => {
    copyText(shareCopy);
    Emit.emit("showToast", { text: "复制成功,快去分享吧！", });
  };
  const handleSaveImg = () => {
    Emit.emit("showToast", { text: "请自行截图分享二维码", time: 3000 });
  };

  return (
    <div className="positioned-container user-share">
      <BackHeader
        stackKey={stackKey}
        rightBtn={() => (
          <ClickBtn
            className="user-share-head-btn"
            onTap={() => handleInvite()}
          >
            邀请记录
          </ClickBtn>
        )}
      />
      <ScrollArea>
        <div style={{paddingBottom: '0.45rem'}}>
          <div className="user-share-head" />
          <div className="user-share-qrcode">
            <div className="user-share-qrcode-inner">
              {
                shareQrcode ? (
                  <QRCode
                    style={{
                      height: "100%",
                      width: "100%"
                    }}
                    value={shareQrcode}
                  />
                ) : <></>
              }
            </div>
            <div className="user-share-qrcode-name">
              我的推广码：{shareCode}
            </div>
          </div>
          <div className="user-share-qrcode-prompt">
            *好友也可在注册时直接填写你的邀请码
          </div>
          <div className="user-share-btn-box">
            <ClickBtn
              className="user-share-btn-link"
              onTap={() => handleSaveLink()}
            >
              复制链接分享
            </ClickBtn>
            <ClickBtn
              className="user-share-btn-img"
              onTap={() => handleSaveImg()}
            >
              保存图片分享
            </ClickBtn>
          </div>
          <div className="user-share-describe">
            <div className="user-share-describ-title">
              推广福利
            </div>
            <div className="user-share-describ-text">
              邀请好友看片赚钱并获得VIP
            </div>
            <div className="user-share-describ-title">
              推广说明
            </div>
            <div className="user-share-describ-text">
              问：怎样才算邀请成功？<br />
              答：发送推广链接给其他新用户，用户第一次安装并打开app后算
              邀请成功，或在个人中心输入您的推广码。<br />
              问：为什么推广链接别人打不开？<br />
              答：请勿使用微信或者QQ等第三方内置浏览器打开，因为包含
              色情内容导致被屏蔽，推荐使用自带浏览器或UC等浏览器打开。<br />
              问：分享到什么平台？<br />
              答：复制推广链接或推广图转发3个tg群(重复群无效)、微信群、
              qq群、抖音、今日头条、微博、陌陌等平台，联系在线客服并
              发出截图，即可领取【3天VIP】，可无限叠加！<br />
            </div>
          </div>
        </div>
      </ScrollArea>
    </div>
  );
};
