import React, { useEffect, useMemo, useState } from "react";

import ScrollArea from "../scrollarea";
import BackHeader from '../backHeader';
import HorizontalScroll from "../horizontal_scroller";
import ClickBtn from "../clickBtn";
import Simg from "../simg";
import Loading from "../loading";

import iconMoney from '../../resources/img/user/iconMoney.png';
import iconWater from '../../resources/img/user/iconWater.png';
import iconBook from '../../resources/img/user/iconBook.png';
import iconTrend from '../../resources/img/user/iconTrend.png';

import { apiGetCertifiedCreator } from '../../libs/http';
import Emit from "../../libs/eventEmitter";

export default (props) => {
  const { stackKey } = props;

  const [loading, setLoading] = useState(true);
  const descriptList = [
    {
      name: '千万平台分红',
      icon: iconMoney,
      descript: '视频你来发，平台帮你赚钱，月薪平均1W+',
    },
    {
      name: '全链路流量池',
      icon: iconWater,
      descript: '平台旗下18款流量产品曝光机会、收益翻倍涨',
    },
    {
      name: '创作培训',
      icon: iconBook,
      descript: '1部手机即可开始创作平台全程辅导',
    },
    {
      name: '无限盈利空间',
      icon: iconTrend,
      descript: '平均一部剪辑过几分钟的短片，就变现几百元',
    },
  ];
  const [list, setList] = useState([]);
  const getCreatorList = async () => {
    try {
      const res = await apiGetCertifiedCreator();
      if (res?.status === 200) {
        setList(res?.data);
      } else {
        Emit.emit("showToast", {
          text: "请求列表失败",
          time: 3000
        });
      }
      setLoading(false);
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求列表失败",
        time: 3000
      });
    }
  };
  useEffect(() => {
    getCreatorList();
  }, []);
  return useMemo(() => (
    <div className="positioned-container">
      <BackHeader
        stackKey={stackKey}
        title="认证官方创作者"
        right={() => <div style={{ width: '1.2rem', height: '0.1rem' }} />}
      />
      {
        loading ? (
          <Loading show overSize={false} />
        ) : (
          <ScrollArea>
            <div className="user-become-creator-title">
              享用官方创作者特权
            </div>
            <div className="user-become-creator-descript">
              {
                descriptList.map((item, index) => (
                  <div
                    key={`user-become-creator-descript-item-${index}`}
                    className="user-become-creator-descript-item"
                  >
                    <img className="user-become-creator-descript-icon" src={item.icon} />
                    <div className="user-become-creator-descript-name">
                      {item.name}
                    </div>
                    <div className="user-become-creator-descript-text">
                      {item.descript}
                    </div>
                  </div>
                ))
              }
            </div>
            <div className="user-become-creator-row">
              <div className="user-become-creator-row-title">
                他们已经赚钱
              </div>
              <div className="user-become-creator-row-subtitle">
                上周打赏收入
                <span className="user-become-creator-row-color">10万+</span>
                金币榜单
              </div>
            </div>
            <div className="user-become-creator-show-box">
              {
                list?.length ? (
                  <HorizontalScroll>
                    <div className="user-become-creator-show-list">
                      {
                        list.map((item, index) => (
                          <div
                            key={`user-become-creator-show-${index}`}
                            className="user-become-creator-show"
                          >
                            <div className="user-become-creator-show-header">
                              <div style={{
                                width: '100%',
                                height: '100%',
                                borderRadius: '100%',
                                overflow: 'hidden',
                              }}>
                                <Simg src={item?.thumb_url} />
                              </div>
                              <div className="user-become-creator-show-header-mark" />
                            </div>
                            <div className="user-become-creator-show-text">
                              {item?.nickname}
                            </div>
                          </div>
                        ))
                      }
                    </div>
                  </HorizontalScroll>
                ) : (
                  <div className="user-become-creator-prompt">加载中...</div>
                )
              }
            </div>
            <div className="user-become-creator-row">
              <div className="user-become-creator-row-title">
                马上成为50度灰创作者
              </div>
            </div>
            <div className="user-become-creator-text">
              比小视频更高的曝光量更丰厚的宏利我们期待你的加入
            </div>
            <div className="user-become-creator-footer">
              <ClickBtn
                className="user-become-creator-btn"
                onTap={() => { }}
              >
                申请成为创作者
              </ClickBtn>
            </div>
          </ScrollArea>
        )
      }
    </div>
  ), [loading, list]);
};
