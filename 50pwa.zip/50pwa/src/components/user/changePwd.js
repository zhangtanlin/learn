import React, { useMemo, useState } from "react";

import BackHeader from "../backHeader";
import ClickBtn from "../clickBtn";

import emit from "../../libs/eventEmitter";
import { updatePwd } from "../../libs/http";
export default props => {
  const { stackKey } = props;

  const [params, setParams] = useState({
    password: "",
    verifyPassword: ""
  });
  // 提交
  const onSubmit = () => {
    // console.log("params", params);
    if (params.password.length < 6) {
      emit.emit("showToast", {
        text: "请输入至少六位数的密码",
        time: 3000
      });
      return;
    }
    if (params.password !== params.verifyPassword) {
      emit.emit("showToast", {
        text: "两次输入的密码不一致",
        time: 3000
      });
      return;
    }
    updatePwd({
      password: params.password
    }).then(res => {
      if (res.status === 200) {
        emit.emit("showToast", {
          text: "密码修改成功",
          time: 3000
        });
        emit.emit(stackKey, stackKey);
      } else {
        emit.emit("showToast", {
          text: res.msg,
          time: 3000
        });
      }
    });
  };

  return useMemo(
    () => (
      <div className="positioned-container white-panel">
        <BackHeader
          stackKey={stackKey}
          leftIconIsDark
          title="设置密码"
          right={() => <div style={{ width: "1.2rem" }} />}
          style={{ background: "white", color: "#000" }}
        />
        <div className="user-changepwd-content">
          <div className="user-changepwd-form">
            <div className="user-form-item">
              <div className="user-form-key">设置密码</div>
              <div className="user-form-value">
                <input
                  type="password"
                  placeholder="请输入密码"
                  onChange={({ target }) => {
                    // const cutTemp = target.value.replace(/[^\d]/g, '');
                    if (target.value) {
                      setParams({ ...params, ...{ password: target.value } });
                    }
                  }}
                />
              </div>
            </div>
            <div className="user-form-item">
              <div className="user-form-key">确认密码</div>
              <div className="user-form-value">
                <input
                  type="password"
                  placeholder="请输入密码"
                  onChange={({ target }) => {
                    // const cutTemp = target.value.replace(/[^\d]/g, '');
                    if (target.value) {
                      setParams({
                        ...params,
                        ...{ verifyPassword: target.value }
                      });
                    }
                  }}
                />
              </div>
            </div>
          </div>
          <ClickBtn className="user-public-btn" onTap={() => onSubmit()}>
            确定
          </ClickBtn>
        </div>
      </div>
    ),
    [params]
  );
};
