import React, { useEffect, useMemo, useState } from "react";
import { Swiper, SwiperSlide } from "swiper/react";

import BackHeader from "../backHeader";
import HeaderTab from "./headerTab";
import ScrollArea from "../scrollarea";
import Loading from "../loading";
import NoData from "../noData";
import { getMsg } from "../../libs/http";
import Simg from "../simg";
import iconLogo from "../../resources/img/public/iconLogo.jpg";

export const UserMsgItem = (props) => {
  const { item } = props;
  return (
    <div className="user-msg-item">
      <div className="user-msg-item-head">
        {item.thumb ? <Simg src={item.thumb} /> : <img src={iconLogo} />}
      </div>
      <div className="user-msg-item-info">
        <div className="user-msg-item-title">{item.nickname || "系统"}</div>
        <div className="user-msg-item-sutitle">{item.description}</div>
      </div>
      <div className="user-msg-item-active">{item.created_text}</div>
    </div>
  );
};

// 【一级选项卡】
export const MessageList = (props) => {
  const { index, current } = props;
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState([]);
  const [loadingMore, setLoadingMore] = useState({ a: true });
  let page = 1;
  useEffect(() => {
    if (index == current && data.length == 0) {
      getData("init");
    }
  }, [current]);
  const getData = (status) => {
    if (!loadingMore.a) return;
    if (!status) {
      page++;
    }
    getMsg({ page: page, type: index + 1 })
      .then((res) => {
        // console.log("getMsg=>", page, res);
        setLoading(false);
        if (res.data.length > 0) {
          setData((pre) => [...pre, ...res.data]);
        } else {
          if (page == 1) {
            setData([]);
          }
          loadingMore.a = false;
          setLoadingMore({ ...loadingMore });
        }
      })
      .catch(() => {
        setLoading(false);
      });
  };
  return (
    <div className="user-msg-list">
      {loading ? (
        <Loading show overSize={false} size={30} />
      ) : data.length > 0 ? (
        <ScrollArea
          ListData={data}
          onScrollEnd={getData}
          loadingMore={loadingMore.a}
        >
          {data.map((item, index) => {
            return <UserMsgItem key={`user-msg-item-${index}`} item={item} />;
          })}
          <div style={{ height: "30px" }} />
        </ScrollArea>
      ) : (
        <NoData />
      )}
    </div>
  );
};

export default (props) => {
  const { stackKey } = props;
  const navList = [
    { name: "获赞" },
    { name: "关注" },
    { name: "系统" },
    { name: "评论" },
  ];
  const [currentTab, setCurrentTab] = useState(0);
  const [controlledSwiper, setControlledSwiper] = useState(null);
  return useMemo(() => (
    <div className="positioned-container user-msg">
      <BackHeader
        stackKey={stackKey}
        title="我的消息"
        right={() => <div style={{ width: "1.2rem", height: "0.1rem" }} />}
      />
      <HeaderTab
        navItems={navList}
        currentIndex={currentTab}
        onChangeTab={(index) => {
          setCurrentTab(index);
          controlledSwiper && controlledSwiper.slideTo(index);
        }}
        style={{
          flex: "none",
          height: "1rem",
          justifyContent: "flex-start",
          margin: "0.25rem 0.45rem",
        }}
      />
      <div className="user-msg-content">
        <Swiper
          className="user-swiper"
          controller={{ control: controlledSwiper }}
          onSwiper={setControlledSwiper}
          initialSlide={0}
          autoplay={false}
          onSlideChange={(e) => {
            setCurrentTab(e.realIndex);
          }}
        >
          {navList.map((item, index) => (
            <SwiperSlide key={`user-msg-swiper-${index}`}>
              <MessageList current={currentTab} index={index} />
            </SwiperSlide>
          ))}
        </Swiper>
      </div>
    </div>
  ));
};
