import React, { useEffect, useMemo, useState } from "react";

import UserStore from '../../store/user';

import ScrollArea from '../scrollarea';
import BackHeader from '../backHeader';
import Loading from "../loading";
import Avatar from "../avatar";
import ClickBtn from "../clickBtn";

import iconCreatorLevel from "../../resources/img/public/iconCreatorLevel.png";
import iconGoldRight from "../../resources/img/public/iconGoldRight.png";

// 认证管理
export default (props) => {
  const { stackKey } = props;
  const [user] = UserStore.useGlobalState("user");

  const [loading, setLoading] = useState(true);

  const [params, setParams] = useState({
    descript: ''
  })

  useEffect(() => {
    setLoading(false);
  }, []);
  // 设置会员卡
  const setLevel = () => {
    if (user?.vip) {
      switch (user?.vip_level) {
        case 1:
          return '月卡';
        case 2:
          return '季卡';
        case 3:
          return '年卡';
        case 4:
          return '永久会员';
        case 9:
          return '临时会员';
        default:
          return '您还不是vip';
      }
    } else {
      return '您还不是vip';
    }
  };
  const onEdit = () => {
    // console.log('params', params)
  }
  return useMemo(() => (
    <div className="positioned-container">
      <BackHeader
        stackKey={stackKey}
        title="认证管理"
        right={() => <div style={{ width: '1.2rem', }} />}
      />
      {
        loading ? (
          <Loading show overSize={false} />
        ) : (
          <ScrollArea>
            <div className="creator-manager-content">
              <div className="creator-manager-box">
                <div className="creator-manager-row">
                  <div className="creator-manager-avatar">
                    <Avatar img={user?.thumb} size={1.35} uuid={user?.uuid} />
                  </div>
                  <div className="creator-manager-info">
                    <div>{user?.nickname}</div>
                    <span className="creator-manager-btn">
                      {setLevel()}
                    </span>
                  </div>
                  <div className="creator-manager-active">
                    {
                      !user?.creator_level ? (
                        <>
                          <img src={iconCreatorLevel} className="creator-manager-active-mark" />
                          {user?.creator_level ? `创作者${user?.creator_level}级` : ''}
                          <img src={iconGoldRight} className="creator-manager-active-right" />
                        </>
                      ) : (<></>)
                    }
                  </div>
                </div>
              </div>
              <div className="creator-manager-box">
                <div className="creator-manager-row">
                  <div className="creator-manager-status">
                    已认证
                  </div>
                  <div className="creator-manager-status-value">
                    {user?.creator_auth_at_day ? `${user?.creator_auth_at_day}天` : ''}
                  </div>
                </div>
                <div className="creator-manager-row">
                  <div className="creator-manager-status">
                    认证标签
                  </div>
                  <div className="creator-manager-status-value">
                    {
                      user?.creator_tag?.length ? (
                        user?.creator_tag.map((item, index) => (
                          <div
                            key={`creator-manager-tag-btn-${index}`}
                            className="creator-manager-tag-btn"
                          >
                            {item}
                          </div>
                        ))
                      ) : (<></>)
                    }
                  </div>
                </div>
              </div>
              <div className="creator-manager-box">
                <div className="creator-manager-row">
                  <div className="creator-manager-status">
                    创作介绍
                  </div>
                  <ClickBtn
                    className="creator-manager-status-value creator-manager-status-end"
                    onTap={() => onEdit()}
                  >
                    编辑
                  </ClickBtn>
                </div>
                <div className="creator-manager-row">
                  <textarea
                    placeholder="请输入创作介绍"
                    defaultValue={user?.creator_desc}
                    onChange={({ target }) => {
                      const tempReplace = target.value.replace(/^\s+|\s+$/g, '');
                      if (tempReplace.length > 200) {
                        const tempCut = String(tempReplace).slice(0, 200);
                        target.value = tempCut;
                        inviteCode = tempCut;
                        setParams({ ...params, ...{ descript: tempReplace } });
                        Emit.emit("showToast", { text: "描述不能超过200字" });
                      } else {
                        target.value = tempReplace;
                        setParams({ ...params, ...{ descript: tempReplace } });
                      }
                    }}
                  />
                </div>
              </div>
            </div>
          </ScrollArea>
        )
      }
    </div>
  ), [loading]);
};
