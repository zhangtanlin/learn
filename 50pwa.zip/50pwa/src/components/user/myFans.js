import React, { useEffect, useMemo, useState } from "react";

import StackStore from "../../store/stack";

import StackPage from "../stackpage";
import BackHeader from '../backHeader';
import Loading from '../loading';
import NoData from '../noData';
import ScrollArea from "../scrollarea";
import ClickBtn from '../clickBtn';
import Simg from '../simg';
import FansGroup from '../category/fans_group';

import Emit from "../../libs/eventEmitter";
import { apiGetMyClubItem } from '../../libs/http';

export default (props) => {
  const { stackKey } = props;
  const [stacks] = StackStore.useGlobalState("stacks");

  const [loading, setLoading] = useState(true);
  const [loadMore, setLoadMore] = useState(true);
  const [page, setPage] = useState(1);
  const [size, setSize] = useState(10);
  const [list, setList] = useState([]);
  const getList = async () => {
    setLoadMore(true);
    try {
      setLoadMore(true);
      const tempParam = { page, size };
      const res = await apiGetMyClubItem(tempParam);
      if (res?.status === 200) {
        if (page === 1) {
          setList(res?.data);
        } else {
          setList([...list, ...res?.data]);
        }
      } else {
        Emit.emit("showToast", {
          text: "请求列表失败",
          time: 3000
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
        time: 3000
      });
    }
    setLoading(false);
    setLoadMore(false);
  };
  // 进入粉丝团
  const handleFans = (clubId) => {
    if (clubId) {
      const stackKey = `user-fans-group-${new Date().getTime()}`;
      StackStore.dispatch({
        type: "push",
        payload: {
          name: "user-fans-group",
          element: (
            <StackPage
              stackKey={stackKey}
              key={stackKey}
              style={{ zIndex: stacks.length + 2 }}
            >
              <FansGroup stackKey={stackKey} id={clubId} />
            </StackPage>
          ),
        },
      });
    }
  };
  const itemFn = (obj, index) => (
    <div
      key={`user-fans-item-${index}`}
      className="user-avatar-box"
    >
      <div className="user-avatar">
        <Simg src={obj?.user?.thumb} />
      </div>
      <div className="user-avatar-info">
        <div className="user-avatar-title">{obj?.club?.name}</div>
        <div className="user-avatar-subtitle">
          <span>{obj?.club?.videos_count || 0}个作品</span>
          <span>{obj?.club?.count || 0}个粉丝</span>
        </div>
      </div>
      <div className="user-avatar-active">
        <ClickBtn
          className="user-avatar-active-btn"
          onTap={() => handleFans(obj?.club_id)}
        >
          进入粉丝团
        </ClickBtn>
      </div>
    </div>
  );
  const _loadMoreData = async () => {
    setPage((page) => (page + 1));
  };
  useEffect(() => {
    getList();
  }, [page, size]);
  return useMemo(() => (
    <div className="positioned-container">
      <BackHeader
        stackKey={stackKey}
        title="粉丝团"
      />
      {
        loading ? (
          <Loading show overSize={false} />
        ) : (
          list?.length > 0 ? (
            <ScrollArea
              loadingMore={loadMore}
              onScrollEnd={_loadMoreData}
            >
              {
                list.map((item, index) => itemFn(item, index))
              }
            </ScrollArea>
          ) : (
            <NoData />
          )
        )
      }
    </div>
  ), [loading, loadMore, list]);
};
