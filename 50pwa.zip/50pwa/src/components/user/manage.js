import React, { useMemo, useState } from "react";

import StackPage from "../stackpage";
import StackStore from "../../store/stack";

import ScrollArea from "../scrollarea";
import BackHeader from "../backHeader";
import ClickBtn from "../clickBtn";
import BandPhone from "./bandPhone";
import ChangePwd from "./changePwd";
import UserStore from "../../store/user";
import Emit from "../../libs/eventEmitter";
import Simg from "../simg";
import { formatPhone } from "../../libs/utils";

import { apiSetInvite, apiSetExchange, updateInfo } from "../../libs/http";

// 修改昵称
export const Nickname = props => {
  const { stackKey } = props;
  const [userInfo] = UserStore.useGlobalState("user");
  const [params, setParams] = useState({
    nickname: ""
  });
  const onSubmit = () => {
    updateInfo({
      update: {
        nickname: params.nickname
      }
    }).then(res => {
      // console.log(res);
      if (res.status === 200) {
        UserStore.dispatch({
          type: "replace",
          payload: {
            ...userInfo,
            nickname: params.nickname
          }
        });
        Emit.emit(stackKey, stackKey);
        Emit.emit("showToast", {
          text: "昵称修改成功"
        });
      } else {
        Emit.emit("showToast", {
          text: res.msg
        });
      }
    });
  };
  return (
    <div className="positioned-container user-nickname">
      <BackHeader
        stackKey={stackKey}
        title="个人管理"
        leftIconIsDark
        right={() => <div style={{ width: "1.2rem", height: "0.1rem" }} />}
        style={{ background: "white", color: "black" }}
      />
      <div className="user-nickname-form-item">
        <textarea
          placeholder="请设置昵称(不超过15字)"
          value={params.nickname}
          onChange={({ target }) => {
            const cutTemp = target.value.replace(/\s+/g, "");
            if (cutTemp.length > 15) {
              const strTemp = String(cutTemp).slice(0, 15);
              target.value = strTemp;
              setParams({ ...params, ...{ nickname: strTemp } });
              Emit.emit("showToast", {
                text: "昵称不能超过15字"
              });
            } else {
              target.value = cutTemp;
              setParams({ ...params, ...{ nickname: cutTemp } });
            }
          }}
        />
      </div>
      <ClickBtn className="user-public-btn" onTap={onSubmit}>
        确定
      </ClickBtn>
    </div>
  );
};

export default props => {
  const { stackKey } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const [userInfo] = UserStore.useGlobalState("user");
  let inviteCode = "";
  let exchangeCode = "";

  // 邀请码
  const onInvite = () => {
    if (userInfo?.invited_by) {
      Emit.emit("showToast", {
        text: "已经填写过邀请码了～",
        time: 3000
      });
    } else {
      Emit.emit("changeAlert", {
        _title: "邀请码",
        _content: (
          <div className="user-input-box center" style={{ width: "6rem" }}>
            <input
              type="text"
              placeholder="请输入邀请码"
              onChange={({ target }) => {
                const tempReplace = target.value.replace(/^\s+|\s+$/g, "");
                if (tempReplace.length > 8) {
                  const tempCut = String(tempReplace).slice(0, 8);
                  target.value = tempCut;
                  inviteCode = tempCut;
                  Emit.emit("showToast", { text: "邀请码不大于8位" });
                } else {
                  target.value = tempReplace;
                  inviteCode = tempReplace;
                }
              }}
            />
          </div>
        ),
        _submitText: "确定",
        _submit: async () => {
          try {
            const res = apiSetInvite({ aff_code: inviteCode });
            if (res?.status === 251) {
              Emit.emit("showToast", { text: "邀请码绑定成功" });
            } else {
              Emit.emit("showToast", { text: res?.msg || "邀请码绑定失败" });
            }
          } catch (error) {
            Emit.emit("showToast", { text: "邀请码绑定失败" });
          }
        },
        _notDouble: true
      });
    }
  };
  // 兑换码
  const onExchange = () => {
    Emit.emit("changeAlert", {
      _title: "兑换码",
      _content: (
        <div className="user-input-box center" style={{ width: "6rem" }}>
          <input
            type="text"
            placeholder="请输入兑换码"
            onChange={({ target }) => {
              const tempReplace = target.value.replace(/^\s+|\s+$/g, "");
              if (tempReplace.length > 8) {
                const tempCut = String(tempReplace).slice(0, 8);
                target.value = tempCut;
                exchangeCode = tempCut;
                Emit.emit("showToast", { text: "兑换码不大于8位" });
              } else {
                target.value = tempReplace;
                exchangeCode = tempReplace;
              }
            }}
          />
        </div>
      ),
      _submitText: "确定",
      _submit: async () => {
        try {
          const res = await apiSetExchange({ code: exchangeCode });
          if (res?.status === 251) {
            Emit.emit("showToast", { text: "兑换码兑换成功" });
          } else {
            Emit.emit("showToast", { text: res?.msg || "兑换码兑换失败" });
          }
        } catch (error) {
          Emit.emit("showToast", { text: "兑换码兑换失败" });
        }
      },
      _notDouble: true
    });
  };
  return useMemo(() => {
    const list = [
      {
        name: "昵称",
        status: userInfo.nickname,
        onTap: () => {
          const stackKey = `user-change-nickname-${new Date().getTime()}`;
          StackStore.dispatch({
            type: "push",
            payload: {
              name: "user-change-nickname",
              element: (
                <StackPage
                  stackKey={stackKey}
                  key={stackKey}
                  style={{ zIndex: stacks.length + 2 }}
                >
                  <Nickname stackKey={stackKey} />
                </StackPage>
              )
            }
          });
        }
      },
      {
        name: "绑定手机",
        status: userInfo?.phone ? formatPhone(userInfo?.phone) : "请绑定手机",
        onTap: () => {
          if (userInfo?.phone) {
            return;
          }
          const stackKey = `user-band-phone-${new Date().getTime()}`;
          StackStore.dispatch({
            type: "push",
            payload: {
              name: "user-band-phone",
              element: (
                <StackPage
                  stackKey={stackKey}
                  key={stackKey}
                  style={{ zIndex: stacks.length + 2 }}
                >
                  <BandPhone stackKey={stackKey} />
                </StackPage>
              )
            }
          });
        }
      },
      {
        name: "邀请码",
        status: userInfo?.invited_by || '',
        onTap: () => onInvite()
      },
      {
        name: "兑换码",
        status: "",
        onTap: () => onExchange()
      },
      {
        name: "修改密码",
        status: "",
        onTap: () => {
          const stackKey = `user-change-pwd-${new Date().getTime()}`;
          StackStore.dispatch({
            type: "push",
            payload: {
              name: "user-change-pwd",
              element: (
                <StackPage
                  stackKey={stackKey}
                  key={stackKey}
                  style={{ zIndex: stacks.length + 2 }}
                >
                  <ChangePwd stackKey={stackKey} />
                </StackPage>
              )
            }
          });
        }
      }
    ];
    return (
      <div className="positioned-container">
        <BackHeader
          stackKey={stackKey}
          title="个人管理"
          right={() => <div style={{ width: "1.2rem", height: "0.1rem" }} />}
        />
        <ScrollArea>
          <div className="user-manage-list">
            <div
              className="user-avatar-box"
              style={{
                margin: "0.3rem 0 0 0",
                paddingBottom: "0.3rem",
                borderBottom: "0.01rem solid #4c4c4c"
              }}
            >
              <div className="user-avatar">
                <Simg src={userInfo?.thumb} />
              </div>
            </div>
            {list.map((item, index) => (
              <ClickBtn
                key={`user-manage-item-${index}`}
                className="user-manage-item"
                onTap={item.onTap}
              >
                <div className="user-manage-item-key">{item.name}</div>
                <div className="user-manage-item-value">{item.status}</div>
              </ClickBtn>
            ))}
          </div>
          {userInfo.phone && (
            <ClickBtn
              className="user-public-btn"
              style={{
                marginTop: "1.5rem"
              }}
              onTap={() => {
                const stackKey = `user-band-phone-${new Date().getTime()}`;
                StackStore.dispatch({
                  type: "push",
                  payload: {
                    name: "user-band-phone",
                    element: (
                      <StackPage
                        stackKey={stackKey}
                        key={stackKey}
                        style={{ zIndex: stacks.length + 2 }}
                      >
                        <BandPhone stackKey={stackKey} type="change" />
                      </StackPage>
                    )
                  }
                });
              }}
            >
              更换绑定
            </ClickBtn>
          )}
        </ScrollArea>
      </div>
    );
  }, [userInfo]);
};
