import React, { useEffect, useMemo, useState } from "react";
import { Swiper, SwiperSlide } from "swiper/react";

import BackHeader from "../backHeader";
import HeaderTab from "./headerTab";
import ScrollArea from "../scrollarea";
import Loading from "../loading";
import NoData from "../noData";
import { NewCard, ToutiaoCard } from "../weitie/qiupian/qiupian_card";

import Emit from "../../libs/eventEmitter";
import {
  apiGetMySeekList,
  apiGetFindLook,
  apiGetMyReply,
  apiGetMyFindWeiList,
} from '../../libs/http';

// 【二级选项卡】求片
export const SeekVideoList = (props) => {
  const { type } = props; // type 区分我的发布/我喜欢的{0: 我的求片,1: 我喜欢的,2: 我的推荐}
  const [loading, setLoading] = useState(true);
  const [loadMore, setLoadMore] = useState(true);
  const [page, setPage] = useState(1);
  const [size, setSize] = useState(10);
  const [list, setList] = useState([]);
  const getList = async () => {
    setLoadMore(true);
    try {
      let res = null;
      let tempParam = null;
      switch (type) {
        case 1:
          tempParam = { page, size };
          res = await apiGetFindLook();
          break;
        case 2:
          tempParam = { page, size };
          res = await apiGetMyReply();
          break;
        default:
          tempParam = { page, size };
          res = await apiGetMySeekList(tempParam);
          break;
      }
      if (res?.status === 200) {
        if (page === 1) {
          setList(res?.data);
        } else {
          setList([...list, ...res?.data]);
        }
      } else {
        Emit.emit("showToast", {
          text: "请求列表失败",
          time: 3000
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
        time: 3000
      });
    }
    setLoading(false);
    setLoadMore(false);
  };
  const loadMoreData = () => {
    setPage((page) => (page + 1));
  };
  useEffect(() => {
    getList();
  }, [page, size]);
  // 根据类型判定加载不同的列表样式
  const setCard = (item, index) => {
    if (type === 0) {
      return (
        <NewCard
          key={`user-post-seek-item-${index}`}
          data={item}
        />
      );
    }
    if (type === 1) {
      return (
        <NewCard
          key={`user-post-seek-item-${index}`}
          data={item}
        />
      );
    }
    if (type === 2) {
      return (
        <NewCard
          key={`user-post-seek-item-${index}`}
          data={item}
        />
      );
    }
  };
  return useMemo(() => (
    <div className="user-post-seek-list">
      {
        loading ? (
          <Loading show overSize={false} />
        ) : (
          list?.length ? (
            <ScrollArea
              loadingMore={loadMore}
              onScrollEnd={() => loadMoreData()}
            >
              {
                list.map((item, index) => (setCard(item, index)))
              }
            </ScrollArea>
          ) : (
            <NoData />
          )
        )
      }
    </div>
  ), [type, loading, loadMore, list]);
};

// 【二级选项卡】微头条
export const SmallInfoList = (props) => {
  const { type } = props; // type 区分我的发布/我喜欢的{0: 我发布的,1: 我喜欢的}
  const [loading, setLoading] = useState(true);
  const [loadMore, setLoadMore] = useState(true);
  const [page, setPage] = useState(1);
  const [size, setSize] = useState(10);
  const [list, setList] = useState([]);
  const getList = async () => {
    setLoadMore(true);
    try {
      let is_praise = null;
      switch (type) {
        case 1:
          is_praise = 1;
          break;
        default:
          is_praise = 0;
          break;
      }
      const tempParam = {
        page,
        size,
        is_praise
      };
      const res = await apiGetMyFindWeiList(tempParam);
      if (res?.status === 200) {
        if (page === 1) {
          setList(res?.data);
        } else {
          setList([...list, ...res?.data]);
        }
      } else {
        Emit.emit("showToast", {
          text: "请求列表失败",
          time: 3000
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
        time: 3000
      });
    }
    setLoading(false);
    setLoadMore(false);
  };
  const loadMoreData = () => {
    setPage((page) => (page + 1));
  };
  useEffect(() => {
    getList();
  }, [page, size]);
  return useMemo(() => (
    <div className="user-post-small-list">
      {
        loading ? (
          <Loading show overSize={false} />
        ) : (
          list?.length ? (
            <ScrollArea
              loadingMore={loadMore}
              onScrollEnd={() => loadMoreData()}
            >
              {
                list.map((item, index) => (
                  <ToutiaoCard
                    key={`user-post-small-item-${index}`}
                    data={item}
                  />
                ))
              }
            </ScrollArea>
          ) : (
            <NoData />
          )
        )
      }
    </div>
  ), [type, loading, loadMore, list]);
};

// 【一级选项卡】求片
export const SeekVideo = () => {
  const navList = [
    { name: "我的求片" },
    { name: "我的喜欢" },
    { name: "我的推荐" },
  ];
  const [currentTab, setCurrentTab] = useState(0);
  const [controlledSwiper, setControlledSwiper] = useState(null);
  return useMemo(() => (
    <div className="user-recharge-vip">
      <HeaderTab
        navItems={navList}
        currentIndex={currentTab}
        onChangeTab={(index) => {
          setCurrentTab(index);
          controlledSwiper && controlledSwiper.slideTo(index);
        }}
        style={{
          justifyContent: 'flex-start',
          margin: '0.6rem 0 0 0.45rem',
          paddingBottom: '0.25rem',
        }}
      />
      <Swiper
        className="user-swiper"
        controller={{ control: controlledSwiper }}
        onSwiper={setControlledSwiper}
        autoplay={false}
        onSlideChange={e => {
          setCurrentTab(e.realIndex);
        }}
      >
        {
          navList.map((item, index) => (
            <SwiperSlide key={`user-post-seek-swiper-${index}`}>
              <SeekVideoList type={index} />
            </SwiperSlide>
          ))
        }
      </Swiper>
    </div>
  ), [navList, currentTab]);
};

// 【一级选项卡】微头条
export const SmallInfo = () => {
  const navList = [
    { name: "我发布的" },
    { name: "我喜欢的" }
  ];
  const [currentTab, setCurrentTab] = useState(0);
  const [controlledSwiper, setControlledSwiper] = useState(null);
  return useMemo(() => (
    <div className="user-recharge-coins">
      <HeaderTab
        navItems={navList}
        currentIndex={currentTab}
        onChangeTab={(index) => {
          setCurrentTab(index);
          controlledSwiper && controlledSwiper.slideTo(index);
        }}
        style={{
          justifyContent: 'flex-start',
          margin: '0.6rem 0 0 0.45rem',
          paddingBottom: '0.25rem',
        }}
      />
      <Swiper
        className="user-swiper"
        controller={{ control: controlledSwiper }}
        onSwiper={setControlledSwiper}
        autoplay={false}
        onSlideChange={e => {
          setCurrentTab(e.realIndex);
        }}
      >
        {
          navList.map((item, index) => (
            <SwiperSlide key={`user-post-small-swiper-${index}`}>
              <SmallInfoList type={index} />
            </SwiperSlide>
          ))
        }
      </Swiper>
    </div>
  ), [navList]);
};

export default (props) => {
  const { stackKey } = props;
  const navList = [
    { name: '求片', },
    { name: '微头条', },
  ];
  const [currentTab, setCurrentTab] = useState(0);
  const [controlledSwiper, setControlledSwiper] = useState(null);
  const setSecondPage = (index) => {
    if (index === 1) {
      return <SmallInfo />; // 微视频
    }
    return <SeekVideo />; // 求片
  };

  return useMemo(() => (
    <div className="positioned-container user-member">
      <BackHeader
        stackKey={stackKey}
        center={() => (
          <HeaderTab
            navItems={navList}
            currentIndex={currentTab}
            onChangeTab={(index) => {
              setCurrentTab(index);
              controlledSwiper && controlledSwiper.slideTo(index);
            }}
          />
        )}
        right={() => (<div style={{ width: '1.2rem' }} />)}
      />
      <div className="user-member-content">
        <Swiper
          className="user-swiper"
          controller={{ control: controlledSwiper }}
          onSwiper={setControlledSwiper}
          initialSlide={0}
          autoplay={false}
          onSlideChange={e => {
            setCurrentTab(e.realIndex);
          }}
        >
          {
            navList.map((item, index) => (
              <SwiperSlide key={`user-post-swiper-${index}`}>
                {setSecondPage(index)}
              </SwiperSlide>
            ))
          }
        </Swiper>
      </div>
    </div>
  ), [navList]);
};
