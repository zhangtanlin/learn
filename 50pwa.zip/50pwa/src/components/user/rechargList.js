import React, { useEffect, useMemo, useState } from "react";

import StackPage from "../stackpage";
import StackStore from "../../store/stack";

import { copyText } from "../../libs/utils";
import Emit from "../../libs/eventEmitter";

import ScrollArea from "../scrollarea";
import BackHeader from '../backHeader';
import ClickBtn from '../clickBtn';
import Loading from '../loading';
import NoData from '../noData';
import MyShare from "./myShare";

import { apiGetOrderList } from '../../libs/http';

export const RechargeListItem = (props) => {
  const { item } = props;
  return useMemo(() => (
    <div className="user-recharg-list-item">
      <div className="user-recharg-list-row">
        <div className="user-recharg-list-row-left">
          <div className="user-recharg-list-title">
            在线支付:{item?.payway_text}
          </div>
        </div>
        <div className="user-recharg-list-row-right">
          <div className="user-recharg-list-title-color">
            {item?.status_text}
          </div>
        </div>
      </div>
      <div className="user-recharg-list-row">
        <div className="user-recharg-list-row-left">
          <div className="user-recharg-list-title-light">
            订单编号：{item?.order_id}
          </div>
        </div>
        <div className="user-recharg-list-row-right">
          <div className="user-recharg-list-subtitle">
            {item?.pay_amount ? `¥${item?.pay_amount}` : ''}
          </div>
        </div>
      </div>
      <div className="user-recharg-list-row">
        <div className="user-recharg-list-row-left">
          <div className="user-recharg-list-title-small">
            {item?.created_at}
          </div>
        </div>
        <div className="user-recharg-list-row-right">
          <ClickBtn
            className="user-recharg-list-item-btn"
            onTap={() => {
              copyText(item?.order_id);
              Emit.emit("showToast", { text: `复制编号${item?.order_id}成功！`, });
            }}
          >
            复制编号
          </ClickBtn>
          {
            item?.status == '未支付' ? (
              <div className="user-recharg-list-item-btn red">
                联系商家
              </div>
            ) : <></>
          }
        </div>
      </div>
    </div>
  ), []);
};

export default (props) => {
  const { stackKey } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  // 跳转分享页
  const handleMyShare = () => {
    const stackKey = `user-share-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "user-share",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <MyShare stackKey={stackKey} />
          </StackPage>
        )
      }
    });
  };
  const [loading, setLoading] = useState(true);
  const [loadMore, setLoadMore] = useState(true);
  const [page, setPage] = useState(1);
  const [size, setSize] = useState(10);
  const [list, setList] = useState([]);
  const getList = async () => {
    setLoadMore(true);
    try {
      const tempParam = { page, size, };
      const res = await apiGetOrderList(tempParam);
      if (res?.status === 200) {
        if (page === 1) {
          setList(res?.data);
        } else {
          setList([...list, ...res?.data]);
        }
      } else {
        Emit.emit("showToast", {
          text: "请求列表失败",
          time: 3000
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
        time: 3000
      });
    }
    setLoading(false);
    setLoadMore(false);
  };
  const _loadMoreData = async () => {
    setPage((page) => (page + 1));
  };
  useEffect(() => {
    getList();
  }, [page, size]);

  return useMemo(() => (
    <div className="positioned-container user-recharg-list">
      <BackHeader
        stackKey={stackKey}
        title="充值明细"
        leftIconIsDark
        rightBtn={() => (
          <ClickBtn
            className="user-recharg-list-btn"
            onTap={() => handleMyShare()}
          >
            马上赚钱
          </ClickBtn>
        )}
        style={{ color: '#000', background: '#fff', }}
      />
      {
        loading ? (
          <Loading show overSize={false} />
        ) : (
          list?.length > 0 ? (
            <ScrollArea
              loadingMore={loadMore}
              onScrollEnd={_loadMoreData}
            >
              {
                list.map((item, index) => (
                  <RechargeListItem
                    key={`user-recharge-List-item-${index}`}
                    item={item}
                  />
                ))
              }
            </ScrollArea>
          ) : (
            <NoData />
          )
        )
      }
    </div>
  ), [loading, loadMore, list]);
};
