import React, { useEffect, useState } from "react";

import ScrollArea from "../scrollarea";
import BackHeader from "../backHeader";
import ClickBtn from "../clickBtn";
import Loading from "../loading";
import NoData from "../noData";
import StackStore from "../../store/stack";

import iconLogo from "../../resources/img/public/iconLogo.jpg";
import { getNotice } from "../../libs/http";
import globalVar from "../../libs/globalVar";

export default props => {
  const { stackKey } = props;
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [stacks] = StackStore.useGlobalState("stacks");
  const httpString = s => {
    //var reg = /(http:\/\/|https:\/\/)((\w|=|\?|\.|\/|&|-)+)/g;
    var reg = /(https?|http|ftp|file):\/\/[-A-Za-z0-9+&@#/%?=~_|!:,.;]+[-A-Za-z0-9+&@#/%=~_|]/g;
    s = s.match(reg);
    return s;
  };
  useEffect(() => {
    getNotice().then(res => {
      setLoading(false);
      setData(res.data);
      // console.log(res);
      //
    });
  }, []);
  const textItem = text => {
    if (!httpString(text)) {
      return text;
    } else {
      const arr = text.split(httpString(text));
      return (
        <p>
          {arr[0]}
          <ClickBtn
            className="user-bulletin-item-info-link"
            onTap={() => {
              window.open(httpString(text), "_blank");
            }}
          >
            {httpString(text)}
          </ClickBtn>
          {arr[1]}
        </p>
      );
    }
  };
  return (
    <div className="positioned-container user-bulletin">
      <ClickBtn onTap={() => {}}></ClickBtn>
      <BackHeader
        stackKey={stackKey}
        title="公告"
        leftIconIsDark
        style={{ color: "rgb(51, 51, 51)" }}
        rightBtn={() => (
          <ClickBtn
            className="user-bulletin-header-btn"
            onTap={() => {
              window.open(globalVar.downloadUrl, "_blank");
            }}
          >
            进入官网
          </ClickBtn>
        )}
      />
      {loading ? (
        <Loading show overSize={false} size={30} />
      ) : data.length > 0 ? (
        <ScrollArea>
          {data.map((item, index) => {
            const itemAry = item.content.split("\n");
            return (
              <div
                key={`user-bulletin-item-${index}`}
                className="user-bulletin-item"
              >
                <div className="user-bulletin-item-logo">
                  <img src={iconLogo} />
                </div>
                <div className="user-bulletin-item-info">
                  <div className="user-bulletin-item-info-list">
                    <div className="user-bulletin-item-info-item">
                      <div className="user-bulletin-item-info-title">
                        {itemAry.map((k, i) => {
                          return <p key={i}>{textItem(k)}</p>;
                        })}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </ScrollArea>
      ) : (
        <NoData />
      )}
    </div>
  );
};
