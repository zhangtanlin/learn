import React, { useMemo, useState, useEffect } from "react";

import StackPage from "../stackpage";
import StackStore from "../../store/stack";
import UserStore from '../../store/user';

import ScrollArea from "../scrollarea";
import BackHeader from '../backHeader';
import ClickBtn from '../clickBtn';
import Withdraw from './withdraw';

import Emit from "../../libs/eventEmitter";
import {
  getHomeConfig,
  apiGetCanWithdrawCoins,
  apiSetWithdrawCoins,
  proxyWithdraw,
  proxyCanWithdrawMoney,
} from "../../libs/http";

export default (props) => {
  const { stackKey,type = 1 } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const [ruleList, setRuleList] = useState([
    '1、提现金币仅限于上传视频的收益，充值金币不可提现',
    '2、每次提现最低200元起，只可提现100的整数',
    '3、收款人账户卡号和姓名必须一致，到账时间为24小时内',
  ])
  // 汇率/可提现金额
  const [info, setInfo] = useState({
    rate: 1,
    canWithdraw: 0,
  });
  // 提现金额/银行卡/姓名
  const [params, setParams] = useState({
    number: '',
    bankCard: '',
    name: '',
  });
  // 获取提现金币
  const getCoins = async () => {
    try {
      let res = null;
      if (type == 1) {
        res = await apiGetCanWithdrawCoins();
        if (res && res.status === 200) {
          setInfo({
            rate: res?.data?.ratio ?? 1,
            canWithdraw: res?.data?.coins,
          });
        } else {
          Emit.emit("showToast", {
            text: "未获取提现额度",
            time: 3000
          });
        }
      }
      if (type == 2) {
        res = await proxyCanWithdrawMoney();
        if (res && res.status === 200) {
          setInfo({
            rate: res?.data?.withdraw_rate ?? 0.05,
            canWithdraw: res?.data?.money,
          });
          let newRule = res?.data?.withdraw_rules?.split('#')
          setRuleList(newRule)
        } else {
          Emit.emit("showToast", {
            text: "未获取提现额度",
            time: 3000
          });
        }
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "获取提现额度失败",
        time: 3000
      });
    }
  };
  // 整合接口
  const initHomeConfig = async () => {
    try {
      const res = await getHomeConfig();
      if (res && res?.status === 200) {
        const tempObject = {
          ...res.data,
          ...{ daily_view: res?.daily_view },
        }; // 字段说明参考userStore
        UserStore.dispatch({
          type: "replace",
          payload: tempObject
        });
      } else {
        Emit.emit("showToast", {
          text: res?.msg || '更新整合接口失败',
          time: 3000
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: '更新整合接口失败',
        time: 3000
      });
    }
  };
  // 刷新当前页面
  const reload = () => {
    const stackKey = `user-withdraw-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "replace",
      payload: {
        name: "user-withdraw",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 1 }}
          >
            <Withdraw stackKey={stackKey} type={type}/>
          </StackPage>
        ),
      },
    });
  };
  // 提现
  const withdraw = async () => {
    try {
      const reg = /^\s*$/g;
      if (Number(params.number) <= 0) {
        Emit.emit("showToast", {
          text: "请输入提现金额",
          time: 3000
        });
        return;
      }
      if (reg.test(params.bankCard)) {
        Emit.emit("showToast", {
          text: "请输入银行卡号",
          time: 3000
        });
        return;
      }
      if (reg.test(params.name)) {
        Emit.emit("showToast", {
          text: "请输入姓名",
          time: 3000
        });
        return;
      }
      const tempParams = {
        withdraw_account: params.bankCard,
        withdraw_name: params.name,
        withdraw_amount: params.number,
      };
      let res = null;
      if(type == 1) {
        res = await apiSetWithdrawCoins(tempParams);
      }
      if(type == 2) {
        res = await proxyWithdraw(tempParams);
      }
      if (res && res?.status === 251) {
        Emit.emit("showToast", {
          text: res?.msg || "提现成功",
          time: 3000
        });
        initHomeConfig();
        getCoins();
        reload();
      } else {
        Emit.emit("showToast", {
          text: res?.msg || '提现失败',
          time: 3000
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "提现失败",
        time: 3000
      });
    }
  };

  useEffect(() => {
    getCoins();
  }, []);

  return useMemo(() => (
    <div className="positioned-container user-withdraw">
      <BackHeader
        stackKey={stackKey}
        title={ type == 1 ? "金币提现" : "代理提现" }
        right={() => <div style={{ width: '1.2rem', height: '0.1rem' }} />}
      />
      <ScrollArea>
        <div className="user-withdraw-content">
          <div className="user-withdraw-item">
          <div className="user-withdraw-key">
              {type == 1 ? "金币收益" : "代理收益" }
              <span>{info?.canWithdraw}</span>
              (可提现)
            </div>
            {type == 1 && <div className="user-withdraw-value">
              (1金币={info?.rate}元)
            </div>}
          </div>
          <div className="user-withdraw-input">
            <input
              type="number"
              placeholder="输入大于100的整数,单笔最大提取1万元"
              onInput={({ target }) => {
                const tempReplace = target.value.replace(/[^\d]/g, '');
                if (Number(tempReplace) > info?.canWithdraw) {
                  const strTemp = String(tempReplace).substr(
                    0,
                    String(tempReplace).length - 1
                  );
                  target.value = Number(strTemp);
                  setParams({ ...params, ...{ number: Number(strTemp) } });
                  Emit.emit("showToast", {
                    text: "当前输入大于可提现金额",
                    time: 3000
                  });
                } else {
                  target.value = Number(tempReplace);
                  setParams({ ...params, ...{ number: Number(tempReplace) } });
                }
              }}
            />
          </div>
          <div className="user-withdraw-item">
            <div className="user-withdraw-key">
              填写收款人信息
            </div>
          </div>
          <div className="user-withdraw-form">
            <div className="user-withdraw-key">
              银行卡
            </div>
            <div className="user-withdraw-value">
              <input
                type="number"
                placeholder="请输入银行卡号"
                onInput={({ target }) => {
                  const tempReplace = String(target.value).replace(/[^\d]/g, '');
                  if (tempReplace?.length > 19) {
                    const tempString = tempReplace.slice(0, 19);
                    target.value = tempString;
                    setParams({ ...params, ...{ bankCard: tempString } });
                  } else {
                    target.value = tempReplace;
                    setParams({ ...params, ...{ bankCard: tempReplace } });
                  }
                }}
              />
            </div>
          </div>
          <div className="user-withdraw-form">
            <div className="user-withdraw-key">
              收款人
            </div>
            <div className="user-withdraw-value">
              <input
                type="text"
                placeholder="请输入收款人姓名"
                onChange={({ target }) => {
                  const tempReplace = target.value.replace(/^\s+|\s+$/g, '');
                  target.value = tempReplace;
                  setParams({ ...params, ...{ name: tempReplace } });
                }}
              />
            </div>
          </div>
          <div
            className="user-withdraw-item"
            style={{ marginTop: '0.5rem' }}
          >
            <div className="user-withdraw-key">
              提现规则
            </div>
          </div>
          {
            ruleList.map((item, index) => (
              <div
                key={`user-withdraw-subtitle-${index}`}
                className="user-withdraw-subtitle"
              >
                {item}
              </div>
            ))
          }
          <ClickBtn
            className="user-withdraw-btn"
            onTap={() => withdraw()}
          >
            确认提现
          </ClickBtn>
        </div>
      </ScrollArea>
    </div>
  ));
};
