import React, { useMemo } from "react";

import StackPage from "../stackpage";
import StackStore from "../../store/stack";
import UserStore from "../../store/user";

import ScrollArea from "../scrollarea";
import BackHeader from '../backHeader';
import ClickBtn from '../clickBtn';

import iconActiveMember from '../../resources/img/user/iconActiveMember.png';
import iconWalletGold from '../../resources/img/user/iconWalletGold.png';
import iconWalletCoin from '../../resources/img/user/iconWalletCoin.png';
import iconActiveShare from '../../resources/img/user/iconActiveShare.png';

import iconRight from '../../resources/img/user/iconRight.png';

import IncomeExpenses from "./incomeExpenses";
import MyShare from "./myShare";
import MyMember from "./myMember";
import MyMakeMoney from "./myMakeMoney";
import Withdraw from "./withdraw";

export default (props) => {
  const { stackKey } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const [user] = UserStore.useGlobalState("user");

  const mallList = [
    {
      name: '充值会员',
      icon: iconActiveMember,
      onTap: () => {
        const stackKey = `user-member-${new Date().getTime()}`;
        StackStore.dispatch({
          type: "push",
          payload: {
            name: "user-member",
            element: (
              <StackPage
                stackKey={stackKey}
                key={stackKey}
                style={{ zIndex: stacks.length + 2 }}
              >
                <MyMember stackKey={stackKey} type={0} />
              </StackPage>
            )
          }
        });
      }
    },
    {
      name: '充值灰币',
      icon: iconWalletGold,
      onTap: () => {
        const stackKey = `user-member-${new Date().getTime()}`;
        StackStore.dispatch({
          type: "push",
          payload: {
            name: "user-member",
            element: (
              <StackPage
                stackKey={stackKey}
                key={stackKey}
                style={{ zIndex: stacks.length + 2 }}
              >
                <MyMember stackKey={stackKey} type={1} />
              </StackPage>
            )
          }
        });
      }
    },
  ];
  const activityList = [
    {
      name: '全民赚钱',
      icon: iconWalletCoin,
      onTap: () => {
        const stackKey = `user-make-money-${new Date().getTime()}`;
        StackStore.dispatch({
          type: "push",
          payload: {
            name: "user-make-money",
            element: (
              <StackPage
                stackKey={stackKey}
                key={stackKey}
                style={{ zIndex: stacks.length + 2 }}
              >
                <MyMakeMoney stackKey={stackKey} />
              </StackPage>
            )
          }
        });
      }
    },
    {
      name: '分享无限看',
      icon: iconActiveShare,
      onTap: () => {
        const stackKey = `user-share-${new Date().getTime()}`;
        StackStore.dispatch({
          type: "push",
          payload: {
            name: "user-share",
            element: (
              <StackPage
                stackKey={stackKey}
                key={stackKey}
                style={{ zIndex: stacks.length + 2 }}
              >
                <MyShare stackKey={stackKey} />
              </StackPage>
            )
          }
        });
      }
    },
  ];

  // 消费明细
  const handleConsumerDetail = () => {
    const stackKey = `user-post-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "user-post",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <IncomeExpenses stackKey={stackKey} />
          </StackPage>
        )
      }
    });
  };
  // 提现
  const handleWithdraw = () => {
    const stackKey = `user-withdraw-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "user-withdraw",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <Withdraw stackKey={stackKey} />
          </StackPage>
        )
      }
    });
  };

  return useMemo(() => (
    <div className="positioned-container my-wallet">
      <BackHeader
        stackKey={stackKey}
        title="钱包"
        rightBtn={() => (
          <ClickBtn
            className="my-wallet-detail"
            onTap={() => handleConsumerDetail()}
          >
            消费明细
          </ClickBtn>
        )}
      />
      <ScrollArea>
        <div className="my-wallet-header">
          <div className="my-wallet-header-info">
            <div className="my-wallet-header-title">
              账户余额
              <img className="my-wallet-header-mark" src={iconRight} />
            </div>
            <div className="my-wallet-header-subtitle">{user?.coins}金币</div>
          </div>
          <div className="my-wallet-header-active">
            <ClickBtn
              className="my-wallet-header-btn"
              onTap={() => handleWithdraw()}
            >
              提现
            </ClickBtn>
          </div>
        </div>
        <div className="my-wallet-list">
          <div className="my-wallet-list-title">商城</div>
          {
            mallList.map((item, index) => (
              <ClickBtn
                key={`my-wallet-item-${index}`}
                className="my-wallet-item"
                onTap={item.onTap}
              >
                <div className="my-wallet-item-info">
                  <img className="my-wallet-item-icon" src={item.icon} />
                  <div className="my-wallet-item-title">{item.name}</div>
                </div>
                <div className="my-wallet-item-active" />
              </ClickBtn>
            ))
          }
        </div>
        <div className="my-wallet-list">
          <div className="my-wallet-list-title">活动</div>
          {
            activityList.map((item, index) => (
              <ClickBtn
                key={`my-wallet-item-${index}`}
                className="my-wallet-item"
                onTap={item.onTap}
              >
                <div className="my-wallet-item-info">
                  <img className="my-wallet-item-icon" src={item.icon} />
                  <div className="my-wallet-item-title">{item.name}</div>
                </div>
                <div className="my-wallet-item-active">
                  <img src={iconRight} />
                </div>
              </ClickBtn>
            ))
          }
        </div>
      </ScrollArea>
    </div>
  ), [user.coins]);
};
