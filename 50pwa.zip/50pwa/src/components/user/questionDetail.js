import React, { useEffect, useMemo, useState } from "react";

import BackHeader from "../backHeader";
import ScrollArea from "../scrollarea";
import Loading from "../loading";
import NoData from "../noData";
export default (props) => {
  const { stackKey, data } = props;
  return (
    <div className="page-content-flex">
      <BackHeader
        stackKey={stackKey}
        title="问题详情"
        right={() => {
          return <div style={{ width: "1.2rem" }} />;
        }}
      />
      <ScrollArea>
        <div className="questionDetail">
          <p>{data.question}</p>
          <p>{data.answer}</p>
        </div>
      </ScrollArea>
    </div>
  );
};
