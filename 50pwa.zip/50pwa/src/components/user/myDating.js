import React, {useEffect, useMemo, useRef, useState} from "react";
import Hammer from "hammerjs";
import StackStore from "../../store/stack";
import BackHeader from "../backHeader";
import ScrollArea from "../scrollarea";
import Emit from "../../libs/eventEmitter";
import Loading from "../loading";
import NoData from "../noData";
import StackPage from "../stackpage";
import hejiIcon from "../../resources/img/public/icon_comp_video_tag.png";
import {Swiper, SwiperSlide} from "swiper/react";
import SwiperCore, {Controller} from "swiper";
import "swiper/swiper.min.css";
import {
  createCartoonGroup, createDatingGroup,
  createVideoGroup,
  getCartoonGroupList,
  getCartoonList,
  getCompilationList, getDatingGroupList, getUserDatingLikeList,
  getUserDatingList
} from "../../libs/http";
import Simg from "../simg";
import ClickBtn from "../clickBtn";
import "../../resources/css/cartoon.less"
import "../../resources/css/myDating.less"
import {DatingItem} from "../dating";
import DatingComment from "../dating/datingComment";
import edit from "../../resources/img/public/edit.png";

SwiperCore.use([Controller]);
export default (props) => {
  const {stackKey} = props;

  const navs = ["解锁", "喜欢"];
  const [tabIndex, setTabIndex] = useState(0);
  const [controlledSwiper, setControlledSwiper] = useState(null);
  const [stacks] = StackStore.useGlobalState("stacks");

  return (<div className="page-content-flex Cartoon-page">
    <BackHeader
      stackKey={stackKey}
      title="约炮解锁"
      right={() => {
        return <div style={{width: "1.2rem"}}/>;
      }}
    />
    <div className="search-result">
      <div className="search-tab taglist-tab" style={{marginBottom: 10}}>
        <ClickBtn
          className={tabIndex == 0 ? "active" : ""}
          onTap={() => {
            setTabIndex(0);
            controlledSwiper.slideTo(0);
          }}
        >
          解锁
          {tabIndex == 0 && (<div className="taglist-tab-active ">
            <div/>
          </div>)}
        </ClickBtn>
        <ClickBtn
          className={tabIndex == 1 ? "active" : ""}
          onTap={() => {
            setTabIndex(1);
            controlledSwiper.slideTo(1);
          }}
        >
          喜欢
          {tabIndex == 1 && (<div className="taglist-tab-active ">
            <div/>
          </div>)}
        </ClickBtn>
      </div>
      <Swiper
        className={"featured-swiper"}
        controller={{control: controlledSwiper}}
        onSwiper={setControlledSwiper}
        onSlideChange={(e) => {
          setTabIndex(e.activeIndex);
        }}
      >
        {navs.map((item, index) => {
          return (<SwiperSlide key={index}>
            <SwiperItem index={index} current={tabIndex} title={item}/>
          </SwiperSlide>);
        })}
      </Swiper>
    </div>
  </div>);
};

const SwiperItem = (props) => {
  const [stacks] = StackStore.useGlobalState("stacks");
  const {index, current, title} = props;
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState([]);
  const [loadingMore, setLoadingMore] = useState({a: true});
  let page = 1;

  const [catList, setCatList] = useState([])
  const [currentGroupId, setCurrentGroupId] = useState(-1)
  const inputRef = useRef(undefined)

  const _getDatingGroupList = () => {
    // getDatingGroupList()
    //   .then(res => {
    //     if (res.status !== 200) return
    //     setCatList([{
    //       id: -1, name: "全部", sort: 0
    //     }, ...res.data.list])
    //   })
  }

  const onTextSubmit = async ({keyCode}) => {
    if (keyCode === 13) {
      const value = inputRef.current.value.trim()
      if (value.length === 0) {
        inputRef.current.value = value
        alert("分组名称不能为空")
        return
      }

      await createDatingGroup({title: value})

      inputRef.current.value = ""

      _getDatingGroupList()
    }
  }

  useEffect(() => {
    getData("init");
  }, [current, currentGroupId]);

  useEffect(() => {
    if (current === index && current === 1) {
      _getDatingGroupList()
    }
  }, [current])
  const getData = (status) => {
    if (!loadingMore.a) return;
    if (!status) {
      page++;
    }

    let api = undefined

    if (current === index && current === 0) {
      api = getUserDatingList
    }

    if (current === index && current === 1) {
      api = getUserDatingLikeList
    }

    if (!api) return;

    api({page: page, group_id: currentGroupId === -1 ? undefined : currentGroupId})
      .then((res) => {
        if (status && res.data.list.length === 0) {
          setData([]);
        }
        if (res.data.list.length > 0) {
          if (!status) {
            setData((pre) => [...pre, ...res.data.list]);
          } else {
            setData((pre) => [...res.data.list]);
          }

        } else {
          if (page == 1) {
            setData([]);
          }
          loadingMore.a = false;
          setLoadingMore({...loadingMore});
        }
      })
      .finally(() => {
        setLoading(false);
      });
  };


  return (<div className={"featured-swiper-item"}>
    {loading ? (<Loading show text={"正在获取数据..."} overSize={false} size={25}/>) : data.length > 0 ? (<ScrollArea
      ListData={data}
      onScrollEnd={getData}
      loadingMore={loadingMore.a}
    >
      <div className={"Cartoon-list"}>
        {/*{*/}
        {/*  current === index && current === 1 && <div style={{display: "flex", width: "100%", flexFlow: "wrap"}}>*/}
        {/*    <div className={"VideoGroupPopup-tags"}>*/}
        {/*      {catList.map(value => {*/}
        {/*        return <span key={value.id} className={`${currentGroupId === value.id ? 'active' : ''}`}*/}
        {/*                     onClick={() => {*/}
        {/*                       setCurrentGroupId(value.id)*/}
        {/*                     }*/}
        {/*                     }>{value.name}</span>*/}
        {/*      })}*/}

        {/*      <span>*/}
        {/*  <img src={edit}/>*/}
        {/*  <input ref={inputRef} placeholder={"自定义"} type={"text"} onKeyDown={onTextSubmit}/>*/}
        {/*</span>*/}
        {/*    </div>*/}
        {/*  </div>*/}
        {/*}*/}

        {data.map((item, index) => {
          return <CartoonItem item={item} key={index} type={current}/>;
        })}
      </div>
      <div style={{height: "30px"}}/>
    </ScrollArea>) : (<NoData/>)}
  </div>);
};

export const CartoonItem = (props) => {
  const {item, type = 0} = props;
  const videoRef = useRef(null);
  const [stacks] = StackStore.useGlobalState("stacks");

  const toDatingComment = () => {
    const id = item?.id
    const stackKey = `DatingComment-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push", payload: {
        name: "DatingComment", element: (<StackPage
          stackKey={stackKey}
          key={stackKey}
          style={{zIndex: stacks.length + 2}}
        >
          <DatingComment data={{id}} stackKey={stackKey}/>
        </StackPage>)
      }
    });
  }

  useEffect(() => {
    if (!videoRef.current) {
      return;
    }
    const videoHammer = new Hammer(videoRef.current);
    videoHammer.on("tap", jump);
    return () => {
      videoHammer.off("tap", jump);
    };
  }, [videoRef.current]);
  const jump = () => {
  };
  return (<div className={`DatingPage MyDating-item ${type !== 0 ? 'no-btn' : ''}`} ref={videoRef}>
    <div className={"Dating"}>
      <DatingItem data={item}></DatingItem>
    </div>
    {
      type === 0 && <div className={"MyDating-item-btn"} onClick={toDatingComment}><span>发布体验评价</span></div>
    }
  </div>);
};
