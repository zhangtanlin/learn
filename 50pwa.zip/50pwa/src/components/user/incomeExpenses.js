import React, { useEffect, useState } from "react";

import StackPage from "../stackpage";
import StackStore from "../../store/stack";

import ScrollArea from "../scrollarea";
import BackHeader from '../backHeader';
import ClickBtn from '../clickBtn';
import MyShare from './myShare';
import Loading from '../loading';
import NoData from '../noData';

import { apiGetCoinsDetail } from '../../libs/http';
import Emit from "../../libs/eventEmitter";

// 收入支出明细
export default (props) => {
  const { stackKey } = props;
  const [stacks] = StackStore.useGlobalState("stacks");

  const handleMyShare = () => {
    const stackKey = `user-share-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "user-share",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <MyShare stackKey={stackKey} />
          </StackPage>
        )
      }
    });
  };

  // 下拉菜单
  const filterOptions = [
    {
      name: '全部明细',
      value: 0,
    },
    {
      name: '收入',
      value: 1,
    },
    {
      name: '支出',
      value: 2,
    }
  ];
  const [optionsShow, setOptionsShow] = useState(false);
  const changeOptions = (obj) => {
    // console.log('obj', obj);
    setParams({
      ...params,
      ...{ type: obj.value }
    });
    setOptionsShow(false);
  };
  // 参数
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [params, setParams] = useState({
    page: 1,
    type: 0,
  });
  const [list, setList] = useState([]);
  const getList = async () => {
    setLoadingMore(true);
    try {
      const res = await apiGetCoinsDetail(params);
      if (res?.status === 200) {
        if (params.page === 1) {
          setList(res?.data);
        } else {
          setList([...list, ...res?.data]);
        }
        setLoading(false);
        setLoadingMore(false);
      } else {
        Emit.emit("showToast", {
          text: "请求列表失败",
          time: 3000
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求列表失败",
        time: 3000
      });
    }
  };
  // 加载更多
  const _loadMoreData = async () => {
    params.page += 1;
    setParams({ ...params });
  };
  useEffect(() => {
    getList();
  }, [params]);

  return (
    <div className="positioned-container user-income-expenses">
      <BackHeader
        stackKey={stackKey}
        title="收支明细"
        leftIconIsDark
        rightBtn={() => (
          <ClickBtn
            className="user-income-expenses-btn"
            onTap={() => handleMyShare()}
          >
            马上赚钱
          </ClickBtn>
        )}
        style={{ color: '#000', background: '#fff', }}
      />
      <div className="user-income-expenses-filter">
        <ClickBtn
          className="user-income-expenses-filter-inner"
          onTap={() => {
            setOptionsShow(!optionsShow);
          }}
        >
          <div className="user-income-expenses-filter-key">筛选</div>
          <div className="user-income-expenses-filter-value">
            {filterOptions[params.type].name}
          </div>
        </ClickBtn>
        <div
          className="user-income-expenses-filter-options"
          style={{
            transform: `translateX(${optionsShow ? 0 : '200%'})`
          }}
        >
          <div className="user-income-expenses-filter-options-inner">
            {
              filterOptions.map((item, index) => (
                <ClickBtn
                  key={`user-income-expenses-filter-options-item-${index}`}
                  className="user-income-expenses-filter-options-item"
                  onTap={() => changeOptions(item)}
                >
                  {item?.name}
                </ClickBtn>
              ))
            }
          </div>
        </div>
      </div>
      {
        loading ? (
          <Loading show overSize={false} />
        ) : (
          list?.length ? (
            <ScrollArea
              loadingMore={false}
              onScrollEnd={() => _loadMoreData}
            >
              {
                list.map((item, index) => (
                  <div
                    key={`user-income-expenses-item-${index}`}
                    className="user-income-expenses-item"
                  >
                    <div className="user-income-expenses-item-left">
                      <div className="user-income-expenses-item-title">
                        {item?.memo}
                      </div>
                      <div className="user-income-expenses-item-subtitle">
                        {item?.created_at}
                      </div>
                    </div>
                    <div className="user-income-expenses-item-right">
                      {item?.coins}
                    </div>
                  </div>
                ))
              }
            </ScrollArea>
          ) : (<NoData />)
        )
      }
    </div>
  );
};
