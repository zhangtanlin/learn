import React, { useMemo } from "react";

import ScrollArea from "../scrollarea";
import BackHeader from '../backHeader';

export default (props) => {
  const { stackKey } = props;

  const list = [
    {
      name: '当前版本',
      number: 'v1.2.0',
    },
  ];
  return useMemo(() => (
    <div className="positioned-container">
      <BackHeader
        stackKey={stackKey}
        title="设置"
        right={() => <div style={{ width: '1.2rem', height: '0.1rem' }} />}
      />
      <ScrollArea>
        {
          list.map((item, index) => (
            <div
              key={`user-set-list-${index}`}
              className="user-set-list"
            >
              {
                list.map((item, index) => (
                  <div
                    key={`user-set-row-${index}`}
                    className="user-set-item"
                  >
                    <div className="user-set-key">
                      {item.name}
                    </div>
                    <div className="user-set-value">
                      {item.number}
                    </div>
                  </div>
                ))
              }
            </div>
          ))
        }
      </ScrollArea>
    </div>
  ), []);
};
