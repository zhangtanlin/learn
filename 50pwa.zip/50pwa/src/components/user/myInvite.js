import React, { useEffect, useMemo, useState } from "react";

import ScrollArea from "../scrollarea";
import BackHeader from '../backHeader';
import CommonList, { CommonListHeader } from './commonList';
import Loading from '../loading';
import NoData from '../noData';

import { apiGetInviteList } from '../../libs/http';
import Emit from "../../libs/eventEmitter";

// 推广记录
export default (props) => {
  const { stackKey } = props;

  const [loading, setLoading] = useState(true);
  const [loadMore, setLoadMore] = useState(true);
  const [page, setPage] = useState(1);
  const [size, setSize] = useState(10);
  const [list, setList] = useState([]);
  const headerList = [
    { name: '昵称', value: 'nickname', },
    { name: '推广级别', value: 'proxy_level' },
    { name: '加入时间', value: 'created_at' },
  ];
  const _getList = async () => {
    setLoadMore(true);
    try {
      const tempParam = { page, size, };
      const res = await apiGetInviteList(tempParam);
      if (res?.status === 200) {
        if (page === 1) {
          setList(res?.data || []);
        } else {
          setList([...list, ...res?.data]);
        }
      } else {
        Emit.emit("showToast", {
          text: "请求列表失败",
          time: 3000
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
        time: 3000
      });
    }
    setLoading(false);
    setLoadMore(false);
  };
  // 加载更多
  const _loadMoreData = async () => {
    setPage((page) => (page + 1));
  };
  useEffect(() => {
    _getList();
  }, [page, size]);

  return useMemo(() => (
    <div className="positioned-container user-invite">
      <BackHeader
        stackKey={stackKey}
        title="推广记录"
        leftIconIsDark
        style={{ background: '#FFF', color: 'rgb(51, 51, 51)' }}
      />
      <CommonListHeader list={headerList} />
      {
        loading ? (
          <Loading show overSize={false} />
        ) : (
          <ScrollArea
            loadingMore={loadMore}
            onScrollEnd={() => _loadMoreData()}
          >
            {
              list.length ? (
                list.map((item, index) => (
                  <CommonList
                    key={`user-invite-${index}`}
                    headerList={headerList}
                    item={item}
                  />
                ))
              ) : (<NoData />)
            }
          </ScrollArea>
        )
      }

    </div>
  ), [loading, loadMore, list]);
};
