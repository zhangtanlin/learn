import React, { useEffect, useMemo, useState } from "react";
import { Swiper, SwiperSlide } from "swiper/react";

import StackPage from "../stackpage";
import StackStore from "../../store/stack";
import UserStore from "../../store/user";

import ClickBtn from "../clickBtn";
import BackHeader from "../backHeader";
import HeaderTab from "./headerTab";
import ScrollArea from "../scrollarea";
import Loading from "../loading";
import NoData from "../noData";
import RechargList from "./rechargList";
import Simg from "../simg";
import BottomLayer from "../bottomLayer";
import WebView from "../webview";

import { apiGetGoodsList, apiCreatePaying } from "../../libs/http";
import Emit from "../../libs/eventEmitter";

import iconHook from "../../resources/img/public/iconHook.png";
import iconAlipay from "../../resources/img/public/icon_alipay.png";
import iconWechat from "../../resources/img/public/icon_wechat.png";
import iconUnionPay from "../../resources/img/public/icon_unionPay.png";
import iconVisa from "../../resources/img/public/icon_visa.png";
import iconEcny from "../../resources/img/public/icon_ecny.png";

/**
 * 【二级选项卡】
 * @param {*} props.parentType: 父选项卡类型
 * @param {*} props.name: 当前选项卡名称, type: 类型(1: 会员vip,2: 充值灰币)}
 * @param {*} props.type: 当前选项卡类型(1: 会员vip,2: 充值灰币)
 */
export const SecondTab = props => {
  const { parentType, name, type } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const [loading, setLoading] = useState(true);
  const [list, setList] = useState([]);
  const [showLayer, setShowLayer] = useState(false);
  const [payWayList, setPayWayList] = useState([]);
  const [choosePayWay, setChoosePayWay] = useState({});
  const getList = async () => {
    try {
      const res = await apiGetGoodsList({
        type: parentType ? parentType + 1 : 1,
        pay_type: "online"
      });
      if (res && res?.status === 200) {
        let temp = [];
        temp = res?.data.map(item => {
          const id = item?.id;
          const promoPrice = item?.promo_price;
          const tempKeys = Object.keys(item);
          const tempValues = Object.values(item);
          const payWays = [];
          tempKeys.forEach((data, i) => {
            const tempPayWay = [
              "payway_bank",
              "payway_visa",
              "payway_wechat",
              "payway_alipay",
              "payway_ecny"
            ]; // 银行卡/visa/微信/支付宝
            if (
              // data.includes('payway_') &&
              // tempValues[i] === 0 &&
              // data.split('_').length - 1 === 1
              tempPayWay.includes(data) &&
              tempValues[i] === 0
            ) {
              const tempObject = {};
              tempObject[data] = 0;
              tempObject.name = "";
              switch (data) {
                case "payway_bank":
                  tempObject.name = data;
                  tempObject.nickname = "银行卡";
                  tempObject.type = "bank";
                  tempObject.icon = iconUnionPay;
                  tempObject.product_id = id;
                  tempObject.promo_price = promoPrice;
                  break;
                case "payway_visa":
                  tempObject.name = data;
                  tempObject.nickname = "visa";
                  tempObject.type = "visa";
                  tempObject.icon = iconVisa;
                  tempObject.product_id = id;
                  tempObject.promo_price = promoPrice;
                  break;
                case "payway_wechat":
                  tempObject.name = data;
                  tempObject.nickname = "微信";
                  tempObject.type = "wechat";
                  tempObject.icon = iconWechat;
                  tempObject.product_id = id;
                  tempObject.promo_price = promoPrice;
                  break;
                case "payway_alipay":
                  tempObject.name = data;
                  tempObject.nickname = "支付宝";
                  tempObject.type = "alipay";
                  tempObject.icon = iconAlipay;
                  tempObject.product_id = id;
                  tempObject.promo_price = promoPrice;
                  break;
                case "payway_ecny":
                  tempObject.name = data;
                  tempObject.nickname = "数字人民币";
                  tempObject.type = "ecny";
                  tempObject.icon = iconEcny;
                  tempObject.product_id = id;
                  tempObject.promo_price = promoPrice;
                  break;
                default:
                  break;
              }
              payWays.push(tempObject);
            }
          });
          item.payWays = payWays;
          return item;
        });
        setList(temp);
      } else {
        Emit.emit("showToast", {
          text: "请求列表失败",
          time: 3000
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
        time: 3000
      });
    }
    setLoading(false);
  };
  // 根据类型不同,加载不同样式
  // 父组件是vip充值+在线充值=>使用单列列表
  // 父组件是灰币充值+在线充值=>使用多列列表
  // 父组件是VIP充值+代理充值=>不展示
  // 父组件是灰币充值+代理充值=>不展示
  const judgeType = () => {
    let cb = <NoData />; // 返回值
    let tempClassName = ""; // 设置类名
    if (parentType === 0 && type === 0) {
      tempClassName = "user-recharge-online-list";
    }
    if (parentType === 1 && type === 0) {
      tempClassName = "user-recharge-online-list-more";
    }
    if (list?.length && tempClassName) {
      cb = (
        <div className={tempClassName}>
          {list.map((item, index) => (
            <ClickBtn
              key={`user-recharge-online-item-${index}`}
              className="user-recharge-online-item"
              onTap={() => {
                setPayWayList(item?.payWays);
                setChoosePayWay(item?.payWays[0]);
                setShowLayer(true);
              }}
            >
              <Simg src={item.img} />
            </ClickBtn>
          ))}
        </div>
      );
    }
    return cb;
  };
  const setPayWay = () => (
    <BottomLayer
      show={showLayer}
      onTap={() => {
        setChoosePayWay({});
        setShowLayer(false);
      }}
      notList
    >
      <div className="user-recharge-layer">
        <div className="user-recharge-layer-head">选择支付方式</div>
        <div className="user-recharge-layer-content">
          <div className="user-recharge-layer-title">
            <span className="user-recharge-layer-mark">¥</span>
            {payWayList[0]?.promo_price || ""}
          </div>
          {payWayList?.length ? (
            payWayList?.map((item, index) => (
              <ClickBtn
                key={`user-recharge-layer-row-${index}`}
                className="user-recharge-layer-row"
                onTap={() => {
                  setChoosePayWay(item);
                }}
              >
                <div className="user-recharge-layer-key">
                  <img src={item?.icon} />
                  {item?.nickname}
                </div>
                <div className="user-recharge-layer-value">
                  {item?.type === choosePayWay?.type ? (
                    <img src={iconHook} />
                  ) : (
                    <></>
                  )}
                </div>
              </ClickBtn>
            ))
          ) : (
            <Loading show overSize={false} />
          )}
          <ClickBtn className="user-public-btn" onTap={() => rechargeSubmit()}>
            确认充值
          </ClickBtn>
        </div>
      </div>
    </BottomLayer>
  );
  let winRef;
  let origin = window.location.origin + "/";
  // 底部确认充值
  const rechargeSubmit = async () => {
    winRef = window.open(origin + "waiting.html", "_blank");
    try {
      const tempParam = {
        pay_way: choosePayWay?.name,
        pay_type: "online",
        product_id: choosePayWay?.product_id
      };
      const res = await apiCreatePaying(tempParam);
      if (!res) {
        Emit.emit("showToast", { text: "网络异常" });
        return;
      }
      if (res.status === 200) {
        setShowLayer(false);
        Emit.emit("changeAlert", {
          _title: "温馨提示",
          _content:
            "1、充值高峰期间到账可能存在延迟，请稍作等待；\n2、如遇充值多次失败、长时间未到账且消费金额未返还情况，请在“充值记录”中选择该订单说明情况，我们会尽快处理。",
          _submitText: "知道了",
          _notDouble: true
        });
        if (res?.data?.pay_type === "url") {
          if (res?.data?.payUrl) {
            winRef.location = res.data.payUrl;
            // window.open(res?.data?.payUrl, "_blank");
          } else {
            winRef.close();
            Emit.emit("showToast", { text: "获取支付地址失败" });
          }
        } else {
          winRef.close();
          Emit.emit("showToast", { text: "跳转失败" });
        }
      } else {
        winRef.close();
        Emit.emit("showToast", { text: res?.msg || "请求支付失败" });
      }
    } catch (error) {
      winRef.close();
      Emit.emit("showToast", { text: "请求支付失败" });
    }
  };
  useEffect(() => {
    getList();
  }, []);
  return useMemo(
    () => (
      <div className="user-recharge-online">
        {loading ? (
          <Loading show overSize={false} />
        ) : (
          <>
            <ScrollArea>{judgeType()}</ScrollArea>
            {setPayWay()}
          </>
        )}
      </div>
    ),
    [type, loading, list, showLayer, payWayList, choosePayWay]
  );
};

/**
 * 【一级选项卡】
 * @param {*} props.name 当前选项卡名称
 * @param {*} props.type 当前选项卡序号(0: 会员VIP, 1: 充值灰币)
 * @returns
 */
export const FirstTab = props => {
  const { name, type } = props;
  const [user] = UserStore.useGlobalState("user");
  const navList = [{ name: "在线充值" }, { name: "代理充值" }];
  const [currentTab, setCurrentTab] = useState(0);
  const [controlledSwiper, setControlledSwiper] = useState(null);
  return useMemo(
    () => (
      <div className="user-recharge-vip">
        <div className="user-avatar-box">
          <div className="user-avatar">
            <Simg src={user?.thumb} />
          </div>
          {type === 0 ? (
            <div className="user-avatar-info">
              <div className="user-avatar-title">{user?.nickname}</div>
              {/* <div className="user-avatar-subtitle">
                剩余免费观看次数：
                {user?.vip ? "无限" : user?.daily_view}
              </div> */}
            </div>
          ) : (
            <div className="user-avatar-info">
              <div className="user-avatar-title">{user?.nickname}</div>
              <div className="user-avatar-subtitle">{user?.coins}灰币</div>
            </div>
          )}
        </div>
        <HeaderTab
          navItems={navList}
          currentIndex={currentTab}
          onChangeTab={index => {
            setCurrentTab(index);
            controlledSwiper && controlledSwiper.slideTo(index);
          }}
          style={{
            justifyContent: "flex-start",
            margin: "0.6rem 0 0 0.45rem",
            paddingBottom: "0.25rem"
          }}
        />
        <Swiper
          className="user-swiper"
          controller={{ control: controlledSwiper }}
          onSwiper={setControlledSwiper}
          autoplay={false}
          onSlideChange={e => {
            setCurrentTab(e.realIndex);
          }}
        >
          {navList.map((item, index) => (
            <SwiperSlide key={`user-member-swiper-${index}`}>
              <SecondTab
                key={`pay-type-${index}`}
                parentType={type}
                name={item}
                type={index}
              />
            </SwiperSlide>
          ))}
        </Swiper>
      </div>
    ),
    [name, type, navList, currentTab]
  );
};

/**
 * 默认导出
 * @param {*} props.type 选中的选项卡{0:表示选中第一个选项卡,1:表示选中第二个选项卡}
 */
export default props => {
  const { stackKey, type } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const navList = [{ name: "会员VIP" }, { name: "充值灰币" }];
  const [currentTab, setCurrentTab] = useState(type || 0);
  const [controlledSwiper, setControlledSwiper] = useState(null);
  const handleRechargList = () => {
    const stackKey = `user-recharg-list-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "user-recharg-list",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <RechargList stackKey={stackKey} />
          </StackPage>
        )
      }
    });
  };
  return useMemo(
    () => (
      <div className="positioned-container user-member">
        <BackHeader
          stackKey={stackKey}
          center={() => (
            <HeaderTab
              navItems={navList}
              currentIndex={currentTab}
              onChangeTab={index => {
                setCurrentTab(index);
                controlledSwiper && controlledSwiper.slideTo(index);
              }}
              style={{ flex: 1 }}
            />
          )}
          rightBtn={() => (
            <ClickBtn
              className="user-member-header-btn"
              onTap={() => handleRechargList()}
            >
              充值明细
            </ClickBtn>
          )}
        />
        <div className="user-member-content">
          <Swiper
            className="user-swiper"
            controller={{ control: controlledSwiper }}
            onSwiper={setControlledSwiper}
            initialSlide={type || 0}
            autoplay={false}
            onSlideChange={e => {
              setCurrentTab(e.realIndex);
            }}
          >
            {navList.map((item, index) => (
              <SwiperSlide key={`user-member-swiper-${index}`}>
                <FirstTab
                  key={`user-recharge-${index}`}
                  name={item}
                  type={index}
                />
              </SwiperSlide>
            ))}
          </Swiper>
        </div>
      </div>
    ),
    [navList, currentTab]
  );
};
