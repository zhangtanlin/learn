import React, { useEffect, useMemo, useState } from "react";
import { Swiper, SwiperSlide } from "swiper/react";

import StackStore from "../../store/stack";

import ScrollArea from "../scrollarea";
import BackHeader from "../backHeader";
import ClickBtn from "../clickBtn";
import Loading from "../loading";
import NoData from "../noData";
import Simg from "../simg";
import { getAppcenter } from "../../libs/http";

export default (props) => {
  const { stackKey } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    getAppcenter().then((res) => {
      setLoading(false);
      setData(res.data);
    });
  }, []);
  const handleDownload = (url, title) => {
    window.open(url, "_blank");
  };
  const toWebView = (url, title) => {
    window.open(url, "_blank");
  };
  return (
    <div className="positioned-container">
      <BackHeader
        stackKey={stackKey}
        title="应用中心"
        right={() => <div style={{ width: "1.2rem", height: "0.1rem" }} />}
      />
      {loading ? (
        <Loading show overSize={false} size={30} />
      ) : data ? (
        <ScrollArea>
          <Swiper
            pagination
            autoplay={{
              delay: 3000,
              disableOnInteraction: false,
            }}
            loop
            className="user-app-ad"
          >
            {data.banner.map((item, index) => (
              <SwiperSlide key={index}>
                <ClickBtn
                  className="user-app-ad-item"
                  onTap={() => toWebView(item.url, "")}
                >
                  <Simg className="user-app-ad-item-img" src={item.img_url} />
                </ClickBtn>
              </SwiperSlide>
            ))}
          </Swiper>
          <div className="user-app-list">
            <div className="user-app-list-title">大家都在玩</div>
            {data.apps.map((item, index) => (
              <ClickBtn
                onTap={() => handleDownload(item.link_url, "下载")}
                key={`user-app-list-item-${index}`}
                className="user-app-list-item"
              >
                <div className="user-app-list-item-head">
                  <Simg src={item.img_url} />
                </div>
                <div className="user-app-list-item-info">
                  <p className="user-app-list-item-title">{item.title}</p>
                  <p className="user-app-list-item-subtitle">
                    {item.clicked}次下载
                  </p>
                  <p className="user-app-list-item-descript">
                    {item.description}
                  </p>
                </div>
                <div className="user-app-list-item-active">
                  <div
                    className="user-app-list-item-btn"

                  >
                    下载
                  </div>
                </div>
              </ClickBtn>
            ))}
          </div>
        </ScrollArea>
      ) : (
        <NoData />
      )}
    </div>
  );
};
