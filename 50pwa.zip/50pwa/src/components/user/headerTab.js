import React from "react";

import ClickBtn from "../clickBtn";

export default props => {
  const {
    navItems,
    keyName,
    currentIndex,
    onChangeTab,
    style,
  } = props;

  return (
    <div className="user-header-tab" style={style}>
      {
        navItems && navItems.length ?
          navItems.map((item, index) => (
            <ClickBtn
              key={`user-header-tab-item-${index}`}
              onTap={() => onChangeTab(index)}
              className={`user-header-tab-item ${currentIndex == index ? 'user-header-tab-active' : ''}`}
            >
              {keyName ? item[keyName] : item.name}
            </ClickBtn>
          )) : <></>
      }
    </div>
  );
};
