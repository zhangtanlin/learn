import React from "react";

export const CommonListHeader = (props) => {
  const { list } = props;
  return (
    <div className="user-common-list-header">
      {
        list ?
          list.map((item, index) => (
            <div
              key={`user-common-list-item-${index}`}
              className="user-common-list-item"
            >
              {item.name}
            </div>
          )) : <></>
      }
    </div>
  );
};

export default (props) => {
  const { item, headerList } = props;
  return (
    <div className="user-common-list">
      {
        headerList ? (
          headerList.map((obj, index) => (
            <div
              key={`user-common-list-item-${index}`}
              className="user-common-list-item"
            >
              {item[obj.value] || ''}
            </div>
          ))
        ) : (
          <></>
        )
      }
    </div>
  );
};
