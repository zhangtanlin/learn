import React, { useEffect, useRef, useState, useMemo } from "react";
import axios from "axios";
import "../resources/css/home.less";
import { getHomeConfig, apiSetInvite } from "../libs/http";

import WebView from "./webview";
import StackStore from "../store/stack";
import StackPage from "./stackpage";
import Loading from "../components/loading";
import Simg from "./simg";
import CryptoData from "../libs/CryptoData";
import "swiper/swiper.min.css";
import "swiper/components/pagination/pagination.min.css";

import SwiperCore, { Pagination } from "swiper/core";

// install Swiper modules
SwiperCore.use([Pagination]);

export default (props) => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [stacks] = StackStore.useGlobalState("stacks");
  const [seconed, setSeconed] = useState({ a: 5 });
  const [showBtn, setShowBtn] = useState(false);
  const getQueryString = (name) => {
    let reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
    let r = window.location.search.substr(1).match(reg);
    if (r != null) {
      return decodeURIComponent(r[2]);
    }
    return null;
  };
  useEffect(() => {
    getHomeConfig()
      .then((res) => {
        getImg();
        // console.log("启屏数据", res);
        // setLoading(false);
        if (res.data && res.data.ads && res.data.ads.img_url) {
          setImg(res.data.ads.img_url, res.data.ads.url);
        }
        //获取渠道参数
        let affCode = getQueryString("aff_code");
        if (affCode) {
          apiSetInvite({
            aff_code: affCode,
          });
        }
      })
      .catch(() => {
        getImg();
      });
  }, []);
  const arraybufferToBase64 = function (t) {
    return new Promise((function (e) {
      const n = new Blob([t]);
      const r = new FileReader();
      r.onload = function (t) {
        const n = t.target.result;
        const r = n.substring(n.indexOf(",") + 1);
        e(r);
      };
      r.readAsDataURL(n);
    }));
  };
  const setImg = (img, url) => {
    const SrcOfPwaDomain = img;
    // .replace(
    //   /^http(s)?:\/\/(.*?)\//,
    //   "http://images.ycyj365.cn/"
    // );
    let ext = SrcOfPwaDomain.substring(SrcOfPwaDomain.lastIndexOf(".") + 1);
    ext = ext === "jpg" ? "jpeg" : ext;
    if ("jpg,jpeg,png,gif".indexOf(ext) == -1) return;
    axios.get(SrcOfPwaDomain, { responseType: 'arraybuffer' }).then((res) => {
      // console.log("setImg", decryptStr);
      arraybufferToBase64(res.data).then(base64str => {
        const decryptStr = CryptoData.DecryptImage(base64str);
        const _obj = {
          img: `data:image/${ext};base64,${decryptStr}`,
          url,
        };
        localStorage.setItem("WELCOME_AD_CHA", JSON.stringify(_obj));
      });

    });
  };
  const getImg = () => {
    const _obj = localStorage.getItem("WELCOME_AD_CHA");
    // console.log("getImg", JSON.parse(_obj));
    if (_obj) {
      setData(JSON.parse(_obj));
      imgFinish();
    } else {
      props.history.replace("/home");
    }
  };
  const imgFinish = () => {
    setShowBtn(true);
    let timer;
    timer = setInterval(() => {
      seconed.a -= 1;
      setSeconed({ ...seconed });
      if (seconed.a == 0) {
        props.history.replace("/home");
        clearInterval(timer);
      }
    }, 1000);
  };
  const toWebView = (url, title) => {
    const stackKey = `webview-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "webview",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            isReplace
            style={{
              zIndex: stacks.length + 1,
            }}
          >
            <WebView title={title} url={url} stackKey={stackKey} />
          </StackPage>
        ),
      },
    });
  };

  return (
    <div className="container">
      {data && data.img && seconed.a != 0 && (
        <div className="welcome-ad">
          <img style={{ width: "100%", height: "100%" }} src={data.img} />
          <div
            onClick={() => {
              if (data.url) {
                window.open(data.url, "_blank");
                // toWebView(data.url, "广告");
              }
            }}
            className="welcome-ad-layer"
          />
          {showBtn && <div className="welcome-ad-btn">{seconed.a}</div>}
        </div>
      )}
    </div>
  );
};
