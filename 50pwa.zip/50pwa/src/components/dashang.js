import React, { useEffect, useMemo, useRef, useState } from "react";
import "../resources/css/dashang.less";
import StackStore from "../store/stack";
import BackHeader from "./backHeader";
import Loading from "./loading";
import Emit from "../libs/eventEmitter";
import StackPage from "./stackpage";
import Avatar from "./avatar";
import MyMember from "./user/myMember";
import { getGiftList, followUp, rewardHer } from "../libs/http";

export default (props) => {
  const { stackKey, member, id } = props;
  const [isSave, setIsSave] = useState(false);
  const [choose, setChoose] = useState(-1);
  const [isLoading, setIsLoading] = useState(false);
  const [stacks] = StackStore.useGlobalState("stacks");
  const [list, setList] = useState([]);
  useEffect(() => {
    getGiftList().then((res) => {
      // console.log("getGiftList", res);
      if (res.data && res.data.length > 0) {
        setList(res.data);
      }
    });
  }, []);
  const toMyMember = () => {
    const stackKey = `MyMember-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "MyMember",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <MyMember stackKey={stackKey} type={1} />
          </StackPage>
        ),
      },
    });
  };
  const item = (item, index) => {
    return (
      <div
        key={index}
        className={`dashang-item ${
          choose == index ? "dashang-item-active" : ""
        }`}
        onClick={() => {
          setChoose(index);
        }}
      >
        {item.value}
        <span>币</span>
      </div>
    );
  };
  return (
    <div className="page-content-flex">
      <BackHeader
        stackKey={stackKey}
        title="打赏"
        rightBtn={() => {
          return (
            <div
              style={{
                color: "#fd5c18",
                fontSize: "0.35rem",
                marginLeft: "-0.5rem",
              }}
              onClick={toMyMember}
            >
              灰币充值
            </div>
          );
        }}
      />
      <div className="dashang">
        <div style={{ display: "flex", flexDirection: "column" }}>
          <div className="dashang-header">
            <div className="info-userItem">
              <div className="info-row">
                <Avatar
                  boxClass="userItem-avatarbox"
                  avatarClass="info-avatar"
                  img={member.thumb}
                  isCreater={member.auth_status}
                />
                <div className="userItem-info">
                  <p>{member.nickname}</p>
                  <div>
                    {member.taggroup_name}
                    <span className="info-point">·</span>
                    {member.followed_count}粉丝
                    <span className="info-point">·</span>
                    {member.videos_count}视频
                  </div>
                </div>
              </div>
              <div
                className={isSave ? "info-isLike" : "info-like"}
                onClick={() => {
                  setIsSave(!isSave);
                  followUp({ follow_uuid: member.uuid });
                }}
              >
                {isSave ? "已关注" : "关注"}
              </div>
            </div>
          </div>
          <div className="dashang-list">
            {list.length > 0 &&
              list.map((n, i) => {
                return item(n, i);
              })}
          </div>
        </div>
        <div
          className="dashang-btn"
          onClick={() => {
            if (choose == -1) {
              Emit.emit("showToast", { text: "老板，选点礼物撒！" });
              return;
            }
            setIsLoading(true);
            rewardHer({ mv_id: id, gkey: list[choose].gkey }).then((res) => {
              setIsLoading(false);
              Emit.emit("changeAlert", {
                _title: "提示",
                _content: res.data.msg,
                _submitText: res.data.code == 1 ? "灰币充值" : "确定",
                _notDouble: true,
                _submit: () => {
                  if (res.data.code == 1) {
                    toMyMember();
                  }
                },
              });
            });
          }}
        >
          打赏作者
        </div>
      </div>
      {isLoading && <Loading show />}
    </div>
  );
};
