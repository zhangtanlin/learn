import BackHeader from "../backHeader";
import ScrollArea from "../scrollarea";
import React, {useEffect, useMemo, useRef, useState} from "react";
import "../../resources/css/datingDetail.less"
import {Swiper, SwiperSlide} from "swiper/react";
import "swiper/swiper.min.css";
import "swiper/components/pagination/pagination.min.css";
import StackStore from "../../store/stack";
import Hammer from "hammerjs";
import Simg from "../simg";
import yougui from "../../resources/img/public/youhui.png"
import baozhengjin from "../../resources/img/public/baozhengjin.png"
import city from "../../resources/img/public/city.png"
import item from "../../resources/img/public/item.png"
import money from "../../resources/img/public/money.png"
import info from "../../resources/img/public/info.png"
import phone from "../../resources/img/public/phone.png"
import unlock from "../../resources/img/public/unlock.png"
import love_unfull from "../../resources/img/public/love_unfull.png"
import love_full from "../../resources/img/public/love_full.png"
import share2 from "../../resources/img/public/share2.png"
import {getDatingDetail, getDatingDetailCommentList, likeDating, setMvLike} from "../../libs/http";
import VideoPlayer from "../videoPlayer";
import emit from "../../libs/eventEmitter";
import StackPage from "../stackpage";
import DatingComment from "./datingComment";
import Emit from "../../libs/eventEmitter";
import MyShare from "../user/myShare";

const DatingDetail = ({stackKey, data}) => {
  const [detailData, setDetailData] = useState(undefined)
  const [loadingMore, setLoadingMore] = useState({a: true});
  const [commentList, setCommentList] = useState([])
  const [isLike, setIsLike] = useState(false)
  const [isPay, setIsPay] = useState(false)
  const [stacks] = StackStore.useGlobalState("stacks");
  let page = 1;
  let limit = 10;

  const getData = async (status) => {
    const id = data?.id

    if (!loadingMore.a) return;
    if (!status) {
      page++;
    }

    await getDatingDetail({id})
      .then(({data}) => {
        // console.log(data.detail)
        setIsLike(Boolean(data.detail.is_like))
        setIsPay(Boolean(data.detail.is_pay))
        setDetailData(data.detail)
      })

    await getDatingDetailCommentList({page, id})
      .then(({data}) => {
        setCommentList(data.list)
      })

    setLoadingMore({...loadingMore, a: false})
  }

  useEffect(() => {
    getData()
    Emit.on("onUnlockDatingAlertSuccess", getData)
    return () => Emit.off("onUnlockDatingAlertSuccess", getData)
  }, [])

  const toDatingComment = () => {
    const id = data?.id
    const stackKey = `DatingComment-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push", payload: {
        name: "DatingComment", element: (<StackPage
          stackKey={stackKey}
          key={stackKey}
          style={{zIndex: stacks.length + 2}}
        >
          <DatingComment data={{id}} stackKey={stackKey}/>
        </StackPage>)
      }
    });
  }

  const onLikeChange = (id) => {
    // if (isLike) {
    //   setIsLike(!isLike);
    //   likeDating({id});
    //   return
    // }
    // const fn = (data) => {
    //   if (data.id === -1) {
    //     setIsLike(!isLike);
    //     likeDating({id});
    //   } else {
    //     setIsLike(!isLike);
    //     likeDating({id, group_id: data.id});
    //   }
    //   emit.off("onDatingGroupPopupSubmit", fn)
    // }
    // emit.on("onDatingGroupPopupSubmit", fn)
    // emit.emit("showDatingGroupPopup")
    setIsLike(!isLike);
    likeDating({id});
  }

  const viewInfo = () => {
    Emit.emit("showUnlockDatingAlert", data)
  }

  const toShare = () => {
    const stackKey = `user-share-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "user-share",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{zIndex: stacks.length + 2}}
          >
            <MyShare stackKey={stackKey}/>
          </StackPage>
        ),
      },
    });
  }

  return useMemo(() => {
    return <div className={"positioned-container DatingDetail"}>
      <BackHeader
        stackKey={stackKey}
      />
      <div className={"DatingDetail-float-bottom"}>
        <div className={"DatingDetail-float-left"}>
          <div onClick={() => onLikeChange(detailData.id)}>
            <img src={isLike ? love_full : love_unfull}/>
            <span>喜欢</span>
          </div>
          <div onClick={toShare}>
            <img src={share2}/>
            <span>分享</span>
          </div>
        </div>
        {
          isPay === false ?
            <div className={"DatingDetail-float-right"} onClick={viewInfo}>
              <span>查看联系方式</span>
            </div> :
            <div className={"DatingDetail-float-right"} onClick={toDatingComment}>
              <span>评价</span>
            </div>
        }
      </div>
      {detailData && <ScrollArea onScrollEnd={getData}
                                 loadingMore={loadingMore.a}
                                 pullDonRefresh={() => {
                                   page = 1;
                                   loadingMore.a = true;
                                   setDetailData(undefined);
                                   setLoadingMore({...loadingMore});
                                   getData("init");
                                 }} ListData={detailData}>
        <div className={"DatingDetail-wrap"}>
          <div className={"DatingDetail-albums"}>
            <RenderSwiper data={detailData}></RenderSwiper>
          </div>
          <div className={"DatingDetail-label"}>
            <p>{detailData.title}</p>
            <div className={"DatingDetail-label-bottom"}>
              <div className={"DatingDetail-label-bottom-left"}><img src={yougui}/><span>线下体验减免100元</span></div>
              <div className={"DatingDetail-label-bottom-right"}><img src={baozhengjin}/><span>赔付保证金20000元</span></div>
            </div>
          </div>

          <div className={"DatingDetail-baseInfo"}>
            <div className={"DatingDetail-row"}>
              <span><img src={city}/>城市：</span>
              <span>{detailData.cityName}</span>
            </div>
            <div className={"DatingDetail-row"}>
              <span><img src={item}/>项目：</span>
              <span>{detailData.girl_service_type}</span>
            </div>
            <div className={"DatingDetail-row"}>
              <span><img src={money}/>价格：</span>
              <span className={"orange"}>{detailData.girl_price}</span>
            </div>
            <div className={"DatingDetail-row"}>
              <span><img src={info}/>资料：</span>
              <span>{detailData.girl_age}岁 / {detailData.girl_height}cm / {detailData.girl_cup}罩杯</span>
            </div>
            <div className={"DatingDetail-row"} style={{alignContent: "flex-start", alignItems: "flex-start"}}>
              <span>简介：</span>
              <pre>{detailData.desc}</pre>
            </div>
          </div>

          <div className={"DatingDetail-unlock"}>
            <div className={"DatingDetail-row"}>
              <span><img src={phone}/>联系方式：</span>
              <div>
                <span>{detailData.buy_price}灰币解锁</span>
                <span className={"orange"}>
                {
                  isPay ? <>{detailData.phone}</> :
                    <div onClick={viewInfo} style={{alignContent: "center", alignItems: "center"}}>
                      <img src={unlock}/>
                      立即解锁
                    </div>
                }
              </span>
              </div>
            </div>
          </div>

          <div className={"DatingDetail-comment"}>

            <div className={"DatingDetail-comment-label"}>
              <span>体验评论</span>
            </div>

            <div className={"DatingDetail-comment-list"}>

              {commentList.map(value => {
                return <div className={"DatingDetail-comment-list-item"}>
                  <div className={"DatingDetail-comment-list-item-label"}>
                    <Simg src={value.member.thumb_url}></Simg>
                    <div className={"right"}>
                      <p>{value.member.nickname}</p>
                      <p>体验时间 {value.member.enjoy_str}</p>
                    </div>
                  </div>
                  <div className={"DatingDetail-comment-list-bottom"}>
                    <div className={"images"}>
                      {value.image_list.map(value2 => {
                        return <Simg src={value2.url}></Simg>
                      })}
                    </div>
                    <div className={"comment-content"}>
                      <pre>{value.comment}</pre>
                    </div>
                  </div>
                </div>
              })}

            </div>


          </div>

        </div>
      </ScrollArea>}
    </div>
  }, [isLike, isPay, detailData, commentList])
}

const RenderSwiper = ({data}) => {
  const [banner, setBanner] = useState(data.items);

  if (!banner || banner.length == 0) {
    return null;
  }
  return (<Swiper
    pagination
    autoplay={{
      delay: 3000, disableOnInteraction: false,
    }}
    className="featured-wiper"
  >
    {banner.map((item, index) => {
      return (<SwiperSlide key={index}>
        <SwiperItem item={item}/>
      </SwiperSlide>);
    })}
  </Swiper>);
};

const SwiperItem = (props) => {
  const {item} = props;
  const itemRef = useRef(null);
  const [stacks] = StackStore.useGlobalState("stacks");
  const _width = document.body.clientWidth;
  return (<div
    style={{}}
    ref={itemRef}
  >
    {item.type === 1 ? <Simg className="no-hammers" src={item.url}/> :
      <VideoPlayer auto={true} thumb={item.video_cover} src={item.url}></VideoPlayer>}
  </div>);
};


export default DatingDetail
