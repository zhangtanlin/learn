import moreIcon from "../../resources/img/public/more.png";
import {Concentration} from "../featured/concentration";
import ScrollArea from "../scrollarea";
import React, {useEffect, useMemo, useRef, useState} from "react";
import official from "../../resources/img/public/official.png"
import location from "../../resources/img/public/location.png"
import "../../resources/css/dating.less"
import eyeOpen from "../../resources/img/public/eye-open.png"
import StackStore from "../../store/stack";
import Hammer from "hammerjs";
import Simg from "../simg";
import {Swiper, SwiperSlide} from "swiper/react";
import "swiper/swiper.min.css";
import "swiper/components/pagination/pagination.min.css";
import {Controller} from "swiper";
import SwiperCore, {Pagination, Autoplay} from "swiper/core";
import BackHeader from "../backHeader";
import everyday from "../../resources/img/public/everyday.png";
import gpsPlain from "../../resources/img/public/gps-plain.png";
import StackPage from "../stackpage";
import EveryDayPage from "../featured/everday";
import HeaderTab from "../user/headerTab";
import SearchPage from "../featured/search";
import searchIcon from "../../resources/img/public/search.png";
import Emit from "../../libs/eventEmitter";
import PostDating from "./postDating";
import DatingDetail from "./datingDetail";
import {getDatingList} from "../../libs/http";
import DatingComment from "./datingComment";
import qingdu from "../../resources/img/public/qingdu.png"
import zhongdu from "../../resources/img/public/zhongdu.png"
import zhongdu2 from "../../resources/img/public/zhongdu2.png"

const Dating = (props) => {
  const {isVisible, stackKey} = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const [pageStatus, setPageStatus] = useState(0);
  const [dataList, setDataList] = useState([])
  const [loadingMore, setLoadingMore] = useState({a: true});
  const [loading, setLoading] = useState(true);
  const [city, setCity] = useState({name: "全国"});
  const [topTips, setTopTips] = useState("已有3021人约会成功")
  const [tip, setTip] = useState("SM调教特色服务,官方包赔付")
  const [banner, setBanner] = useState([]);
  let page = 1;
  let limit = 10;

  const getData = (status) => {
    if (!loadingMore.a) return;
    if (!status) {
      page++;
    }

    console.log({page: page, city: city.name === "全国" ? "" : city.name})
    getDatingList({page: page, city: city.name === "全国" ? "" : city.name})
      .then(res => {
        if (res.data.banner && res.data.banner.length !== 0) {
          setBanner(res.data.banner)
        }

        setTopTips(res.data.top_tip)
        setTip(res.data.tip)

        if (res.data.list.length > 0) {
          setDataList((pre) => [...pre, ...res.data.list]);
        } else {
          if (page == 1) {
            setDataList([]);
          }
          loadingMore.a = false;
          setLoadingMore({...loadingMore});
        }
      })
      .finally(() => {
        setLoading(false);
      })
  };

  useEffect(() => {
    if (isVisible) {
      getData("init")
    }
  }, [isVisible, city]);

  useEffect(() => {
    const chang = (city) => {
      setCity(city)
    }
    Emit.on("choosePicker", chang)
    return () => {
      Emit.off(chang)
    }
  }, [])

  const showCityPicker = () => {
    Emit.emit("showPicker")
  }

  const toPostDating = () => {
    const stackKey = `PostDating-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push", payload: {
        name: "PostDating", element: (<StackPage
          stackKey={stackKey}
          key={stackKey}
          style={{zIndex: stacks.length + 2}}
        >
          <PostDating stackKey={stackKey}/>
        </StackPage>)
      }
    });
  }

  return <div className={`positioned-container ${isVisible ? "visible" : "hide"} DatingPage`}>
    <BackHeader
      stackKey={stackKey}
      left={() => {
        return <div className={"searchHeader"}>
          <div className={"searchHeader-location"} onClick={showCityPicker}>
            <img src={gpsPlain}/>
            <span>{city.name}</span>
          </div>
        </div>
      }}
      center={() => {
        return <div
          className="searchHeader-input"
          onClick={() => {
            const stackKey = `SearchPage-${new Date().getTime()}`;
            StackStore.dispatch({
              type: "push", payload: {
                name: "SearchPage", element: (<StackPage
                  stackKey={stackKey}
                  key={stackKey}
                  style={{zIndex: stacks.length + 2}}
                >
                  <SearchPage stackKey={stackKey}/>
                </StackPage>)
              }
            });
          }}
        >
          <img src={searchIcon}/>
          <span>{topTips}</span>
        </div>
      }}
      right={() => (<div className={"searchHeader"}>
        <div className={"searchHeader-post"} onClick={toPostDating}>
          <span>+</span>
          <span>发布</span>
        </div>
      </div>)}
    />
    <ScrollArea
      ListData={dataList}
      onScrollEnd={getData}
      loadingMore={loadingMore.a}
      pullDonRefresh={() => {
        page = 1;
        loadingMore.a = true;
        setDataList([]);
        setLoading(true);
        setLoadingMore({...loadingMore});
        getData("init");
      }}
    >
      <div className={"Dating"}>

        {banner.length !== 0 && <RenderSwiper banner={banner}></RenderSwiper>}

        <div className={"Dating-label"}>
          <img src={official}/>
          <span>{tip}</span>
        </div>

        {dataList.map((value, index) => {
          return <DatingItem key={index} data={value}></DatingItem>
        })}

      </div>

      <div style={{height: "30px"}}/>
    </ScrollArea>
  </div>
}

export const DatingItem = ({data}) => {
  const [stacks] = StackStore.useGlobalState("stacks");
  const toDatingDetail = () => {
    const stackKey = `DatingDetail-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push", payload: {
        name: "DatingDetail", element: (<StackPage
          stackKey={stackKey}
          key={stackKey}
          style={{zIndex: stacks.length + 2}}
        >
          <DatingDetail data={data} stackKey={stackKey}/>
        </StackPage>)
      }
    });
  }
  return <div className={"Dating-item"} onClick={() => toDatingDetail()}>
    {data.category_subscript === "轻度SM" &&
      <img style={{position: "absolute", right: 0, top: 0, width: "1.5rem"}} src={qingdu}/>}

    {data.category_subscript === "中度SM" &&
      <img style={{position: "absolute", right: 0, top: 0, width: "1.5rem"}} src={zhongdu}/>}

    {data.category_subscript === "重度SM" &&
      <img style={{position: "absolute", right: 0, top: 0, width: "1.5rem"}} src={zhongdu2}/>}

    <div className={"Dating-item-left"}>
      <Simg src={data.cover}/>
      <span className={"Dating-item-left-tips"}>{data.buy_count}人约过</span>
    </div>
    <div className={"Dating-item-right"}>
      <p className={"Dating-item-right-title"}>{data.title}</p>
      <p>
        {data.girl_tags.split(",").map((val, index) => {
          return <span key={index}>#{val}</span>
        })}
      </p>
      <p>{data.girl_age}岁/{data.girl_height}cm/{data.girl_cup}罩杯</p>
      <div className={"Dating-item-right-bottom"}>
        <span>
          <img src={location}/>
          {data.cityName}
        </span>
        <span>
          <img src={eyeOpen}/>
          {data.view}
        </span>
      </div>
    </div>
  </div>
}

const RenderSwiper = ({banner}) => {
  if (!banner || banner.length == 0) {
    return null;
  }
  return (<Swiper
    pagination
    autoplay={{
      delay: 3000, disableOnInteraction: false,
    }}
    className="featured-wiper"
  >
    {banner.map((item, index) => {
      return (<SwiperSlide key={index}>
        <SwiperItem item={item}/>
      </SwiperSlide>);
    })}
  </Swiper>);
};

const SwiperItem = (props) => {
  const {item} = props;
  const itemRef = useRef(null);
  const [stacks] = StackStore.useGlobalState("stacks");
  const _width = document.body.clientWidth;
  useEffect(() => {
    if (!itemRef.current) {
      return;
    }
    const itemHammer = new Hammer(itemRef.current);
    itemHammer.on("tap", onClick);
    return () => {
      itemHammer.off("tap", onClick);
    };
  }, [itemRef.current]);
  const onClick = () => {
    //跳外部
    if ((item.type == 1 || item.type == 2) && item.url) {
      toWebView(item.url, "");
    }
  };
  const toWebView = (url, title) => {
    window.open(url, "_blank");
  };
  return (<div
    style={{
      width: _width, height: _width * 0.35,
    }}
    ref={itemRef}
  >
    <Simg className="no-hammers" src={item.img_url}/>
  </div>);
};

export default Dating
