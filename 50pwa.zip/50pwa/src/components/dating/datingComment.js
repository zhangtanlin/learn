import React, {useState} from "react"
import "../../resources/css/datingComment.less"
import BackHeader from "../backHeader";
import {UploadRequest} from "../../libs/uploadImg";
import Emit from "../../libs/eventEmitter";
import Loading from "../loading";
import {createDatingComment} from "../../libs/http";
import stop from "../../resources/img/public/stop.png"

const DatingComment = ({stackKey, data}) => {
  const [loading, setLoading] = useState(false);
  const [alreadyImgs, setAlreadyImgs] = useState({})
  const [content, setContent] = useState("")
  const maxImg = 6

  const onSetCover = async ({target}) => {
    setLoading(true);
    const imgFile = new FileReader();
    imgFile.readAsDataURL(target.files[0]);
    imgFile.onload = () => {
      const cover = imgFile.result.toString()
      UploadRequest({
        id: new Date().getTime(), cover: cover,
      })
        .then((res) => {
          if (res) {
            setAlreadyImgs({...alreadyImgs, ...{[res]: cover}})
            setLoading(false);
          } else {
            Emit.emit("changeAlert", {
              _title: "提示", _content: "图片上传失败，请稍后再试", _submitText: "确定", _submit: () => {
              }, _notDouble: true,
            });
            setLoading(false);
          }
        })
        .catch(() => {
          setLoading(false);
          Emit.emit("changeAlert", {
            _title: "提示", _content: "图片上传失败，请稍后再试", _submitText: "确定", _submit: () => {
            }, _notDouble: true,
          });
        });
    };
  };

  const publish = () => {
    if (content.length === 0) {
      Emit.emit("changeAlert", {
        _title: "提示", _content: "服务评价不能为空", _submitText: "确定", _submit: () => {
        }, _notDouble: true,
      });
      return
    }

    createDatingComment({
      id: data.id,
      content,
      image_json: JSON.stringify(Object.keys(alreadyImgs).map(value => ({url: value, width: 0, height: 0})))
    })
      .then(res => {
        if (res.status === 551) {
          Emit.emit("changeAlert", {
            _title: "提示", _content: res.msg, _submitText: "确定", _submit: () => {
            }, _notDouble: true,
          });
          return
        }

        Emit.emit(stackKey, stackKey);
      })
  }

  return <div className={"DatingComment"}>
    <BackHeader stackKey={stackKey} title={"发布体验评价"}></BackHeader>
    {loading && <Loading show overSize/>}
    <div className={"DatingComment-float-bottom"} onClick={publish}>
      <span>发布</span>
    </div>
    <div className={"DatingComment-wrap"}>
      <div className={"DatingComment-box"}>
        <p>服务评价</p>
        <div className={"DatingComment-content"}>
          <textarea value={content} onChange={({target}) => {
            setContent(target.value.trim())
          }} className={"DatingComment-content-input-comment"} placeholder={"可从妹子颜值、服务技术、整体环境等方面进行评价"}/>
        </div>
      </div>
      <div className={"DatingComment-box"}>
        <p>上传图片 ({Object.keys(alreadyImgs).length}/{maxImg})</p>
        <div className={"DatingComment-content"}>
          {Object.keys(alreadyImgs).map(value => {
            return <div key={value} className={"DatingComment-content-img-wrap"}>
              <img className={"delete"} src={stop} onClick={() => {
                setAlreadyImgs(() => {
                  delete alreadyImgs[value]
                  return {...alreadyImgs}
                })
              }
              }/>
              <img src={alreadyImgs[value]}/>
            </div>
          })}
          {Object.keys(alreadyImgs).length >= maxImg ? <></> : <div className={"DatingComment-content-img-selector"}>
            <input type="file" accept="image/*" multiple={false} onChange={onSetCover}/>
            <div className={"DatingComment-content-img-selector-box"}>+</div>
          </div>}
        </div>
      </div>
    </div>
  </div>
}

export default DatingComment
