import BackHeader from "../backHeader";
import React, {useEffect, useState} from "react";
import "../../resources/css/PostDating.less"
import ScrollArea from "../scrollarea";
import {getCreateDatingRule} from "../../libs/http";
import Simg from "../simg";

const PostDating = ({stackKey}) => {
  const [data, setData] = useState(undefined)
  const getData = () => {
    getCreateDatingRule()
      .then(({data}) => {
        console.log(data)
        setData(data)
      })
  }

  useEffect(() => {
    getData()
  }, [])

  return <div className={"positioned-container PostDating"}>
    <BackHeader
      stackKey={stackKey}
      title="官方认证"
    />
    <ScrollArea downRefresh={false} ListData={1}>
      <div className={"PostDating-wrap"}>
        {data && data.map((val, index) => {
          if (val.body && val.body.length !== 0) {
            return <div key={index} className={"PostDating-item"}>
              <div className={"PostDating-item-label"}><span>{val.name}</span></div>
              <div className={"PostDating-item-content"}>
                <pre>{val.body}</pre>
              </div>
            </div>
          }

          return <div key={index} style={{
            display: "flex",
            alignItems: "center",
            alignContent: "center",
            justifyContent: "space-between",
            padding: "0 0.5rem"
          }} className={"PostDating-wrap-link"}>
            {val.items && val.items.map((val2, index2) => {
              return <a target={"_blank"}
                        style={{color: "#fff", width: "1.8rem", height: "1.8rem", textAlign: "center"}} key={index2}
                        href={val2.url}>
                <Simg src={val2.icon}></Simg>
                <span style={{top: "0.2rem", position: "relative", fontSize: "0.4rem"}}>{val2.name}</span>
              </a>
            })}
          </div>
        })}
      </div>
    </ScrollArea>
  </div>
}

export default PostDating
