import React, { useEffect, useRef, useState } from "react";
import BScroll from "@better-scroll/core";
import Hammer from "hammerjs";
import categoryIcon from "../resources/img/public/categoryIcon.png";
import Emit from "../libs/eventEmitter";
export const TopSlidePanel = (props) => {
  const { children, style } = props;
  return (
    <div className="top-slide-panel" style={style}>
      {children}
    </div>
  );
};

export default (props) => {
  // scrollable: 决定是可滚动的还是固定平均分布的导航
  const {
    navitems,
    scrollable,
    currentIndex,
    onChangeTab,
    children,
    isSearch,
    childPanelWidth,
    getHammer,
    noIcon,
    navClassName = "",
    activeClassName = "",
  } = props;

  const scrollerRef = useRef(null);
  const navitemsRef = useRef(null);
  const itemWrapperClN = scrollable ? "scroll-item-wrapper" : "item-wrapper";

  let bscroll;
  useEffect(() => {
    if (!scrollerRef.current || !scrollable) {
      return;
    }
    bscroll = new BScroll(scrollerRef.current, {
      scrollY: false,
      scrollX: true,
      useTransition: false,
    });
    return () => {
      if (bscroll) {
        bscroll.destroy();
      }
    };
  }, [scrollerRef.current]);
  const wrapperRef = useRef(null);
  const [wrapperInitialStyle, setWrapperInitialStyle] = useState(null);
  useEffect(() => {
    if (!wrapperRef.current) {
      return;
    }
    if (!navitemsRef.current) {
      return;
    }
    const onChangeAnimation = (index) => {
      wrapperRef.current.setAttribute(
        "style",
        `${wrapperInitialStyle} transform: translateX(${
          -index * childPanelWidth
        }px); transition: all 0.5s`
      );
      onChangeTab(index);
    };
    // tab点击切换
    const itemWrappers =
      navitemsRef.current.getElementsByClassName(itemWrapperClN);
    const hammers = [];
    itemWrappers.forEach((iw, index) => {
      const hammer = new Hammer(iw);
      hammer.on("tap", () => {
        if (index !== currentIndex) {
          onChangeAnimation(index);
        }
      });
      hammers.push(hammer);
    });
    // 滑动切换
    const swipeHammer = new Hammer(wrapperRef.current);
    const onPanMove = (e) => {
      if (e.target.className == "no-hammers") return; // 屏蔽轮播图
      if (Math.abs(e.deltaX) < 75) return;
      if (currentIndex === 0 && e.deltaX > 0) {
        return;
      }
      if (currentIndex === navitems.length - 1 && e.deltaX < 0) {
        return;
      }
      wrapperRef.current.setAttribute(
        "style",
        `${wrapperInitialStyle} transform: translateX(${
          e.deltaX - currentIndex * childPanelWidth
        }px)`
      );
    };
    const onPanEnd = (e) => {
      if (e.target.className == "no-hammers") return; // 屏蔽轮播图
      if (Math.abs(e.deltaX) < 75) return;
      if (currentIndex === 0 && e.deltaX > 0) {
        return;
      }
      if (currentIndex === navitems.length - 1 && e.deltaX < 0) {
        return;
      }
      const DURATION = 0.5;
      if (e.distance / childPanelWidth > 0.3) {
        if (e.deltaX > 0) {
          onChangeAnimation(currentIndex - 1);
        } else {
          onChangeAnimation(currentIndex + 1);
        }
      } else {
        wrapperRef.current.setAttribute(
          "style",
          `${wrapperInitialStyle} transform: translateX(${
            -currentIndex * childPanelWidth
          }px); transition: all ${DURATION * (e.distance / childPanelWidth)}s`
        );
      }
    };
    swipeHammer
      .get("pan")
      .set({ direction: Hammer.DIRECTION_HORIZONTAL, threshold: 75 });
    if (!wrapperInitialStyle) {
      setWrapperInitialStyle(wrapperRef.current.getAttribute("style"));
    }
    swipeHammer.on("panmove", onPanMove);
    swipeHammer.on("panend", onPanEnd);
    // 获取 hammer
    getHammer && getHammer(swipeHammer);
    return () => {
      swipeHammer.off("panmove", onPanMove);
      swipeHammer.off("panend", onPanEnd);
      hammers.forEach((h) => {
        h.off("tap");
      });
    };
  }, [wrapperRef.current, navitemsRef.current, currentIndex]);
  return (
    <>
      <div className="top-nav-box">
        <div className="top-nav-list">
          <div
            ref={scrollerRef}
            className={`top-slide-nav ${scrollable ? "" : "no-scroll"}`}
          >
            <div
              ref={navitemsRef}
              className={`top-slide-content ${navClassName}`}
            >
              {navitems.map((n, index) => (
                <span
                  key={`iwc-${index}`}
                  className={`${itemWrapperClN} ${
                    index === currentIndex ? `active ${activeClassName}` : ""
                  }`}
                >
                  {n}
                </span>
              ))}
            </div>
          </div>
        </div>
        {!noIcon && (
          <div className="seaech-btn" onClick={() => {}}>
            <img src={categoryIcon} />
          </div>
        )}
      </div>
      <div className="wrapper-page-box">
        <div
          ref={wrapperRef}
          className="top-slide-panel-wrapper"
          style={{
            width: childPanelWidth * navitems.length,
          }}
        >
          {children}
        </div>
      </div>
    </>
  );
};
