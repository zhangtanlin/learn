/*
 * @Author: Tom
 * @Date: 2022-01-13 16:34:47
 * @LastEditTime: 2022-01-20 10:04:23
 * @LastEditors: Tom
 * @Description:
 * @FilePath: /50pwa/src/components/avatar.js
 */
import React, { useEffect, useMemo, useRef, useState } from "react";
// import Hammer from "hammerjs";
import StackStore from "../store/stack";
import StackPage from "./stackpage";
import chuangIcon from "../resources/img/public/chuang.png";
import UserPage from "./category/user_page";
import ClickBtn from "./clickBtn";
import Simg from "./simg";
import globalVar from "../libs/globalVar";
import Emit from "../libs/eventEmitter";
export default props => {
  const {
    img,
    isCreater = false,
    size = 1, //rem
    boxClass,
    avatarClass,
    iconClass,
    uuid,
    onTap
  } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const toUserPage = () => {
    if (!uuid) return;
    onTap && onTap();
    const stackKey = `userpage-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "userpage",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <UserPage stackKey={stackKey} uuid={uuid} />
          </StackPage>
        )
      }
    });
  };
  return (
    <ClickBtn
      className={`featured-avItem-avatar ${boxClass || ""}`}
      styles={{
        width: `${size}rem`,
        height: `${size}rem`
      }}
      onTap={toUserPage}
    >
      <div className={`avItem-avatar ${avatarClass || ""}`}>
        <Simg src={img} />
      </div>
      {isCreater && (
        <img
          className={`avItem-chuang ${iconClass || ""}`}
          src={chuangIcon}
          style={{
            width: `${size * 0.4}rem`,
            height: `${size * 0.4}rem`
          }}
        />
      )}
    </ClickBtn>
  );
};
