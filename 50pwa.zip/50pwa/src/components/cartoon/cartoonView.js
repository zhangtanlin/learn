import BackHeader from "../backHeader";
import React, {useEffect, useMemo, useRef, useState} from "react";
import ScrollArea from "../scrollarea";
import Loading from "../loading";
import "../../resources/css/cartoonView.less"
import directory from "../../resources/img/public/directory.png"
import share from "../../resources/img/public/share2.png"
import {getCartoonEpisode, getCartoonEpisodeContent} from "../../libs/http";
import Simg from "../simg";
import {DirectoryPage} from "./cartoonDetail";
import StackStore from "../../store/stack";
import StackPage from "../stackpage";
import MyShare from "../user/myShare";
import Emit from "../../libs/eventEmitter";
import UserStore from "../../store/user";
import backWhite from "../../resources/img/public/backWhite.png";

export const getCartoonStoreRecordById = (id) => {
  const cartoonReadRecord = JSON.parse(localStorage.getItem("cartoonReadRecord") ?? "{}")
  return cartoonReadRecord[id]
}

export const updateCartoonStoreById = (id, {lastEpisode} = {}) => {
  let cartoonReadRecord = JSON.parse(localStorage.getItem("cartoonReadRecord") ?? "{}")
  let current = cartoonReadRecord[id] ?? {}
  if (!current) {
    current = {}
  }

  current.lastEpisode = lastEpisode

  if (!current.alreadyEpisodes) current.alreadyEpisodes = []

  current.alreadyEpisodes.push(lastEpisode)

  current.alreadyEpisodes = [...new Set(current.alreadyEpisodes)]

  cartoonReadRecord[id] = current

  localStorage.setItem("cartoonReadRecord", JSON.stringify(cartoonReadRecord))
}

//episode不传的时候  自动读取本地历史记录
const CartoonView = ({stackKey, detail, episode = undefined}) => {
  const [initPage, setInitPage] = useState(false);
  const [showLoading, setShowLoading] = useState(true);
  const [title, setTitle] = useState(`第${episode}话`)
  const [imgs, setImgs] = useState([])
  const [showDirectoryPopups, setShowDirectoryPopups] = useState(false)
  const [stacks] = StackStore.useGlobalState("stacks");
  const scrollAreaRef = useRef()
  const episodeListRef = useRef([])
  const [user] = UserStore.useGlobalState("user");

  let checkLoad = true;
  let showAlertTimes = 0

  const getData = () => {

    let _episode = episode
    if (_episode === undefined) {
      const local = getCartoonStoreRecordById(detail.id)
      if (local?.lastEpisode) {
        _episode = local?.lastEpisode
      } else {
        _episode = 1
      }
    }

    setTitle(`第${_episode}话`)

    setShowLoading(true)
    getCartoonEpisodeContent({id: detail.id, episode: _episode})
      .then((res) => {
        const data = res.data

        updateCartoonStoreById(detail.id, {lastEpisode: _episode})

        if (data.cur.episode_title) {
          setTitle(data.cur.episode_title)
        }

        if (data.read && data.read.length !== 0) {
          setImgs(data.read)
        }
      })
      .finally(() => {
        setInitPage(true)
        setShowLoading(false)
      })
  }

  useEffect(() => {
    getData()
  }, [])

  // useEffect(() => {

  //   setTimeout(() => {
  //     if (showLoading === false) {
  //       if (scrollAreaRef?.current) {
  //         scrollAreaRef.current.refresh()
  //       }
  //     }
  //   }, 100)
  // }, [showLoading])

  const toShare = () => {
    const stackKey = `user-share-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push", payload: {
        name: "user-share", element: (<StackPage
          stackKey={stackKey}
          key={stackKey}
          style={{zIndex: stacks.length + 2}}
        >
          <MyShare stackKey={stackKey}/>
        </StackPage>),
      },
    });
  }

  const getCartoonEpisodeData = async () => {
    if (episodeListRef.current.length !== 0) return episodeListRef.current
    return await getCartoonEpisode({id: detail.id})
      .then(res => {
        episodeListRef.current = res.data?.list ?? []
        return res.data?.list ?? []
      })
  }

  const toNextCartoon = (_episode) => {
    const stackKey = `CartoonView-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "replace", payload: {
        name: "CartoonView", element: (<StackPage
          stackKey={stackKey}
          key={stackKey}
          style={{zIndex: stacks.length + 2}}
        >
          <CartoonView
            stackKey={stackKey}
            detail={detail}
            episode={_episode}
          />
        </StackPage>),
      },
    });
    // setShowLoading(true)
    // if (!checkLoad) return
    // getCartoonEpisodeContent({id: detail.id, episode: _episode})
    //   .then((res) => {
    //     const data = res.data
    //
    //     if (!data) return
    //     if (data.cur.is_pay == 0) {
    //       checkLoad = false
    //       return
    //     }
    //
    //     episode = _episode
    //
    //     updateCartoonStoreById(detail.id, {lastEpisode: _episode})
    //
    //     if (data.cur.episode_title) {
    //       setTitle(data.cur.episode_title)
    //     }
    //
    //     if (data.read && data.read.length !== 0) {
    //       let current = [...imgs]
    //       let paramsList = [...current, ...data.read]
    //       let newImgs = Array.from(new Set(paramsList))
    //       setImgs(newImgs)
    //     }
    //   })
  }

  function uniques(params) {
    return Array.from(new Set(params))
  }

  const nextPage = async (status) => {
    console.log('end')
    if (checkLoad == false) return
    const _getCartoonEpisodeData = await getCartoonEpisodeData()

    let value = undefined
    let _episode = episode
    if (_episode === undefined) {
      const local = getCartoonStoreRecordById(detail.id)
      if (local?.lastEpisode) {
        _episode = local?.lastEpisode
      } else {
        _episode = 1
      }
    }

    if (status === "prev") {
      _episode--
    } else {
      _episode++
    }

    if (_episode <= 0) _episode = 1

    for (let i of _getCartoonEpisodeData) {
      if (_episode === i.episode) {
        value = i
      }
    }

    if (!value) return alert("没有下一话了");

    //弹窗展示次数限制
    // if (showAlertTimes > 3) return

    if ((value.is_free === 2 && value.view_money !== 0)) {
      if (user.coins < value.view_money) {
        Emit.emit("showCartoonAlert")
        showAlertTimes++
        return;
      }
      if (value.is_pay === 1) {
        toNextCartoon(value.episode)
      } else {
        const fn = () => {
          toNextCartoon(value.episode)
          Emit.off("onUnlockCartoonAlertSuccess", fn)
        }
        Emit.on("onUnlockCartoonAlertSuccess", fn)
        Emit.emit("showUnlockCartoonAlert", {detail, episode: value})
        showAlertTimes++
      }
      return
    }

    if ((value.is_free === 1)) {
      if (user.vip) {
        toNextCartoon(value.episode)
      } else {
        Emit.emit("showCartoonAlert", {isSimple: true})
        showAlertTimes++
      }
      return;
    }

    toNextCartoon(value.episode)
  }

  return <div className={"positioned-container CartoonViewPage"}>
    <BackHeader
      stackKey={stackKey}
      title={title}
    />
    {
      title !== "第1话" && title !== "全章" && <div className={"CartoonViewPage-next"} onClick={() => {
        nextPage("prev")
      }}>
        <img src={backWhite}/>
        <span>上一话</span>
      </div>
    }
    <div className={"CartoonViewPage-prev"} onClick={() => {
      nextPage()
    }}>
      <span>下一话</span>
      <img src={backWhite}/>
    </div>
    {showDirectoryPopups &&
      <DirectoryPopups detail={detail} onClose={() => setShowDirectoryPopups(false)}></DirectoryPopups>}
    {showLoading && <Loading show overSize={true}/>}
    <div className={"CartoonView-float-bottom"}>
      <div onClick={() => setShowDirectoryPopups(true)}>
        <img src={directory}/>
        <span>查看目录</span>
      </div>
      <div onClick={toShare}>
        <img src={share}/>
        <span>分享好友</span>
      </div>
    </div>
    <ScrollArea ref={scrollAreaRef} loadingMore={showLoading} ListData={imgs}>
      <div className={"CartoonViewPage-wrap"}>
        <div className={"CartoonViewPage-wrap-list"}>
          {imgs && imgs.map((value, index) => {
            return <Simg key={index} src={value.img_url} refreshScroll={() => scrollAreaRef.current.refresh()}/>
          })}
        </div>
        <div style={{height: "1.5rem"}}></div>
      </div>
    </ScrollArea>
  </div>
}

const DirectoryPopups = ({
                           detail, onClose = () => {
  }
                         }) => {
  return <div className={"DirectoryPopups"}>
    <div className={"mask"} onClick={() => onClose()}></div>
    <div className={"DirectoryPopups-DirectoryPage-wrap"}>
      <p className={"DirectoryPopups-title"}>{detail.title}</p>
      <DirectoryPage isReplace={true} detail={detail} onClose={onClose}></DirectoryPage>
    </div>
  </div>
}

export default CartoonView
