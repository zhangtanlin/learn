import BackHeader from "../backHeader";
import React, {useEffect, useMemo, useRef, useState} from "react";
import ScrollArea from "../scrollarea";
import "../../resources/css/cartoonDetail.less"
import StackStore from "../../store/stack";
import everyday from "../../resources/img/public/everyday.png";
import StackPage from "../stackpage";
import EveryDayPage from "../featured/everday";
import HeaderTab from "../user/headerTab";
import {Swiper, SwiperSlide} from "swiper/react";
import Loading from "../loading";
import SwiperCore, {Controller} from "swiper";
import {CartoonItem} from "./index";
import collect from "../../resources/img/public/collect.png"
import collectActive from "../../resources/img/public/collect-active.png"
import share from "../../resources/img/public/share2.png"
import sortUp from "../../resources/img/public/sort-up.png"
import sortDown from "../../resources/img/public/sort-down.png"
import coin from "../../resources/img/public/coin.png"
import {getCartoonDetail, getCartoonEpisode, likeCartoon, likeDating, setMvLike} from "../../libs/http";
import Simg from "../simg";
import {formatNumber} from "../../libs/utils";
import CartoonView, {getCartoonStoreRecordById} from "./cartoonView";
import UserStore from "../../store/user";
import MyMember from "../user/myMember";
import Emit from "../../libs/eventEmitter";
import emit from "../../libs/eventEmitter";
import MyShare from "../user/myShare";

SwiperCore.use([Controller]);
const CartoonDetail = ({title, id, stackKey}) => {
  const [categoreTab, setCategoreTab] = useState(1);
  const [initPage, setInitPage] = useState(false);
  const [categoreList, setCategoreList] = useState(null);
  const [detail, setDetail] = useState(undefined)
  const [recommendList, setRecommendList] = useState([])
  const [stacks] = StackStore.useGlobalState("stacks");
  const [isLike, setIsLike] = useState(false)
  const episodeList = useRef([])
  const [user] = UserStore.useGlobalState("user");

  const getData = () => {
    getCartoonDetail({id})
      .then(res => {
        setDetail(res.data.detail)
        setIsLike(res.data.detail.is_like)
        setInitPage(true)
        setRecommendList(res.data.recommend_list)
      })
  }

  useEffect(() => {
    getData()
  }, [])

  const onUpdate = (list) => {
    episodeList.current = list
  }

  const toCartoon = (episode) => {
    const stackKey = `CartoonView-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push", payload: {
        name: "CartoonView", element: (<StackPage
          stackKey={stackKey}
          key={stackKey}
          style={{zIndex: stacks.length + 2}}
        >
          <CartoonView
            stackKey={stackKey}
            detail={detail}
            episode={episode}
          />
        </StackPage>),
      },
    });
  }

  const onMember = () => {
    const stackKey = `user-member-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push", payload: {
        name: "user-member", element: (<StackPage
          stackKey={stackKey}
          key={stackKey}
          style={{zIndex: stacks.length + 2}}
        >
          <MyMember stackKey={stackKey}/>
        </StackPage>),
      },
    });
  };

  const readCartoon = () => {
    let value = undefined
    let _episode = undefined
    if (_episode === undefined) {
      const local = getCartoonStoreRecordById(detail.id)
      if (local?.lastEpisode) {
        _episode = local?.lastEpisode
      } else {
        _episode = 1
      }
    }
    for (let i of episodeList.current) {
      if (_episode === i.episode) {
        value = i
      }
    }

    if (!value) return;

    if ((value.is_free === 2 && value.view_money !== 0)) {
      if (user.coins < value.view_money) {
        Emit.emit("showCartoonAlert")
        return;
      }
      if (value.is_pay === 1) {
        toCartoon(value.episode)
      } else {
        const fn = () => {
          toCartoon(value.episode)
          Emit.off("onUnlockCartoonAlertSuccess", fn)
        }
        Emit.on("onUnlockCartoonAlertSuccess", fn)
        Emit.emit("showUnlockCartoonAlert", {detail, episode: value})
      }
      return
    }

    if ((value.is_free === 1)) {
      if (user.vip) {
        toCartoon(value.episode)
      } else {
        Emit.emit("showCartoonAlert", {isSimple: true})
      }
      return;
    }

    toCartoon(value.episode)
  }

  const onLikeChange = (id) => {
    if (isLike) {
      setIsLike(!isLike);
      likeCartoon({id});
      return
    }
    const fn = (data) => {
      if (data.id === -1) {
        setIsLike(!isLike);
        likeCartoon({id});
      } else {
        setIsLike(!isLike);
        likeCartoon({id, group_id: data.id});
      }
      emit.off("onCartoonGroupPopupSubmit", fn)
    }
    emit.on("onCartoonGroupPopupSubmit", fn)
    emit.on("onCartoonGroupPopupClose", () => emit.off("onCartoonGroupPopupSubmit", fn))
    emit.emit("showCartoonGroupPopup")
  }

  const toShare = () => {
    const stackKey = `user-share-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "user-share",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{zIndex: stacks.length + 2}}
          >
            <MyShare stackKey={stackKey}/>
          </StackPage>
        ),
      },
    });
  }

  return <div className={"positioned-container CartoonDetail"}>
    <BackHeader
      stackKey={stackKey}
      title={title}
    />
    <div className={"CartoonDetail-float-bottom"}>
      <div onClick={() => onLikeChange(detail.id)}>
        <img src={isLike ? collectActive : collect}/>
        <span>收藏</span>
      </div>
      <div onClick={toShare}>
        <img src={share}/>
        <span>分享</span>
      </div>
      <div onClick={readCartoon}>
        <span>开始阅读</span>
      </div>
    </div>
    {
      initPage ?
        <ScrollArea pullDonRefresh={getData} ListData={JSON.stringify(recommendList) + JSON.stringify(detail)}>
          <div className={"CartoonDetail-wrap"}>
            <div className={"CartoonDetail-albums"}>
              <Simg className={"simg"} src={detail?.thumb}></Simg>
              <div className={"CartoonDetail-info"}>
                <span>{detail?.categories}</span>
                <span>·</span>
                <span>{detail?.series}话</span>
                <span className={"CartoonDetail-tips"}>{detail?.finished === 1 ? '已完结' : '连载中'}</span>
              </div>
            </div>
            <div className={"CartoonDetail-content"}>
              {!initPage && !detail ? (<Loading show overSize={false}/>) : (
                <Bypass detail={detail} onUpdate={onUpdate} recommendList={recommendList}
                        defaultCategoreTab={categoreTab}
                        categoreList={categoreList}
                        stackKey={stackKey}></Bypass>)}
            </div>
            <div style={{height: "50px"}}></div>
          </div>
        </ScrollArea>
        :
        <></>
    }
  </div>
}

const Bypass = ({defaultCategoreTab, categoreList, stackKey, detail, recommendList, onUpdate}) => {
  const [stacks] = StackStore.useGlobalState("stacks");
  const navList = [{name: '作品',}, {name: '目录',},];
  const [currentTab, setCurrentTab] = useState(0);
  const [controlledSwiper, setControlledSwiper] = useState(null);
  const setSecondPage = (index) => {
    if (index === 0) {
      return <WorksPage detail={detail} recommendList={recommendList} defaultCategoreTab={defaultCategoreTab}
                        categoreList={categoreList}></WorksPage>;
    }

    return <DirectoryPage detail={detail} onUpdate={onUpdate}></DirectoryPage>;
  };

  return useMemo(() => (<div className="CartoonDetail-bypass">
    <HeaderTab
      navItems={navList}
      currentIndex={currentTab}
      onChangeTab={(index) => {
        setCurrentTab(index);
        controlledSwiper && controlledSwiper.slideTo(index);
      }}
    />
    <div className="CartoonDetail-bypass-content">
      <Swiper
        className="user-swiper"
        controller={{control: controlledSwiper}}
        onSwiper={setControlledSwiper}
        initialSlide={0}
        autoplay={false}
        onSlideChange={e => {
          setCurrentTab(e.realIndex);
        }}
      >
        {navList.map((item, index) => (<SwiperSlide key={`user-post-swiper-${index}`}>
          {setSecondPage(index)}
        </SwiperSlide>))}
      </Swiper>
    </div>
  </div>), [navList, detail]);
}

const WorksPage = ({detail, recommendList}) => {
  return <div className={"CartoonDetail-WorksPage"}>
    <pre>{detail.description}</pre>
    <div className={"CartoonDetail-WorksPage-statistics"}>
      <span>{detail.views_count_str}次浏览</span>
      <span>·</span>
      <span>{detail.likes_count_str}喜欢</span>
    </div>
    <p className={"p"}>为你推荐</p>
    <div className={"CartoonDetail-WorksPage-recommend Cartoon-page"}>
      <div className={"Cartoon-list"}>
        {recommendList.map((item, index) => {
          return <CartoonItem item={item} key={index}/>;
        })}
      </div>
    </div>
  </div>
}


export const DirectoryPage = ({
                                isReplace = false,
                                detail, onClose = () => {
  },
                                onUpdate = () => {
                                }
                              }) => {
  const [stacks] = StackStore.useGlobalState("stacks");
  const [sort, setSort] = useState("asc")//desc
  const [episodeList, setEpisodeList] = useState([])
  const cartoonStoreRecordById = getCartoonStoreRecordById(detail.id)
  const alreadyEpisodes = cartoonStoreRecordById?.alreadyEpisodes ?? []
  const [user] = UserStore.useGlobalState("user");

  const getData = () => {
    getCartoonEpisode({sort, id: detail.id})
      .then(res => {
        onUpdate(res.data.list)
        setEpisodeList(res.data.list)
      })
  }

  useEffect(() => {
    getData()
  }, [sort])

  const readCartoon = (episode) => {
    const stackKey = `CartoonView-${new Date().getTime()}`;
    StackStore.dispatch({
      type: isReplace ? "replace" : "push", payload: {
        name: "CartoonView", element: (<StackPage
          stackKey={stackKey}
          key={stackKey}
          style={{zIndex: stacks.length + 2}}
        >
          <CartoonView
            stackKey={stackKey}
            episode={episode}
            detail={detail}
          />
        </StackPage>),
      },
    });
  }

  const onMember = () => {
    const stackKey = `user-member-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push", payload: {
        name: "user-member", element: (<StackPage
          stackKey={stackKey}
          key={stackKey}
          style={{zIndex: stacks.length + 2}}
        >
          <MyMember stackKey={stackKey}/>
        </StackPage>),
      },
    });
  };

  const toRead = (value) => {
    onClose()

    if ((value.is_free === 2 && value.view_money !== 0)) {
      if (user.coins < value.view_money) {
        Emit.emit("showCartoonAlert")
        return;
      }
      if (value.is_pay === 1) {
        readCartoon(value.episode)
      } else {
        const fn = () => {
          readCartoon(value.episode)
          Emit.off("onUnlockCartoonAlertSuccess", fn)
        }
        Emit.on("onUnlockCartoonAlertSuccess", fn)
        Emit.emit("showUnlockCartoonAlert", {detail, episode: value})
      }
      return
    }

    if ((value.is_free === 1)) {
      if (user.vip) {
        readCartoon(value.episode)
      } else {
        Emit.emit("showCartoonAlert", {isSimple: true})
      }
      return;
    }
    readCartoon(value.episode)
  }

  return useMemo(() => {
    return <div className={"CartoonDetail-DirectoryPage"}>
      <div className={"CartoonDetail-DirectoryPage-label"}>
        <div className={"CartoonDetail-DirectoryPage-label-left"}>
          <span>{detail.finished === 0 ? '连载中' : '已完结'}</span>
          <span>({detail.update_time})</span>
          <span>更新至{detail.series}话</span>
        </div>
        <div className={"CartoonDetail-DirectoryPage-label-right"} onClick={() => {
          if (sort === "asc") {
            setSort("desc")
          } else {
            setSort("asc")
          }
        }}>
          <img src={sort === "asc" ? sortUp : sortDown}/>
        </div>
      </div>

      <div className={"CartoonDetail-DirectoryPage-list"}>
        {episodeList.map((value, index) => {
          return <div onClick={() => toRead(value)} key={index}
                      className={`CartoonDetail-DirectoryPage-list-item ${alreadyEpisodes.includes(value.episode) ? 'is-read' : ''}`}>
            <span>{value.episode_title}{alreadyEpisodes.includes(value.episode) ? '(已读)' : ''}</span>

            {(value.is_free === 2 && value.view_money !== 0) &&
              <span className={"CartoonDetail-DirectoryPage-tips-coins"}><img src={coin}/>{value.view_money}</span>}

            {(value.is_free === 1) && <span className={"CartoonDetail-DirectoryPage-tips-vip"}>VIP</span>}
          </div>
        })}
      </div>
    </div>
  }, [sort, episodeList])
}

export default CartoonDetail
