import React, { useEffect, useMemo, useRef, useState } from "react";
import BackHead from "../../backHeader";
import ScrollArea from "../../scrollarea";
import ClickBtn from "../../clickBtn";
import Simg from "../../simg";
import StackPage from "../../stackpage";
import StackStore from "../../../store/stack";
import sendIcon from "../../../resources/img/public/icon_send_video_tag_find.png";
import coinIcon from "../../../resources/img/public/icon_tb_tag.png";
import xkIcon from "../../../resources/img/public/xk_icon.png";
import yqIcon from "../../../resources/img/public/yq_icon.png";
import write from "../../../resources/img/public/video_detail_send.png";
import { RexinUserCard } from "./qiupian_card";
import AppendCoin from "../qiupian/append_coins";
import iconRight from "../../../resources/img/public/icon_right.png";
import TuipianPage from "./tuipian_page";
import emit from "../../../libs/eventEmitter";
import VideoDetail from "../../videoDetail";
import MyMember from "../../user/myMember";
import BottomSheet from "../../bottom_sheet";
import {
  getQiupianDetail,
  getReplyByFind,
  appendCoins,
  commentReply
} from "../../../libs/http";
import Loading from "../../loading";
import Avatar from "../../avatar";
import NoData from "../../noData";
const TimeShow = props => {
  const { coin, starTime, endTime } = props;
  const [timeStr, setTimeStr] = useState("");
  useEffect(() => {
    let timer;
    if (starTime < endTime) {
      timer = setInterval(() => {
        let ctime = new Date().getTime();
        let specialTime = endTime * 1000 - ctime;
        if (specialTime <= 0) {
          clearInterval(timer);
        }
        let day = Math.floor(specialTime / 1000 / 60 / 60 / 24);
        let hour = Math.floor((specialTime / 1000 / 60 / 60) % 24);
        let minute = Math.floor((specialTime / 1000 / 60) % 60);
        let second = Math.floor((specialTime / 1000) % 60);
        let tStr = `<span>${day < 10 ? "0" + day : day}</span>天<span>${
          hour < 10 ? "0" + hour : hour
        }</span>小时<span>${
          minute < 10 ? "0" + minute : minute
        }</span>分<span>${second < 10 ? "0" + second : second}</span>秒`;
        setTimeStr(tStr);
      }, 1000);
    }
    return () => {
      if (timer) {
        clearInterval(timer);
      }
    };
  }, []);
  return useMemo(
    () => (
      <div className="sj_time">
        <div className="flex_row">
          <div className="fans_text" style={{ marginRight: "0.32rem" }}>
            剩余打赏金额
          </div>
          <div className="coin_text">{coin}灰币</div>
        </div>
        {starTime > endTime ? (
          <p
            style={{
              fontSize: "0.32rem",
              color: "#ffffff"
            }}
          >
            此次求片已经结束
          </p>
        ) : (
          <div className="flex_row">
            <div className="fans_text">倒计时:</div>
            <div
              className="flex_row countdown"
              dangerouslySetInnerHTML={{ __html: timeStr }}
            ></div>
          </div>
        )}
      </div>
    ),
    [starTime, endTime, coin, timeStr]
  );
};
export default props => {
  const { stackKey, id } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const [showInput, setShowInput] = useState(false);
  const [qiupianInfo, setQiupianInfo] = useState(null);
  const [findList, setFindList] = useState(null);
  const [showComment, setShowComment] = useState(false);
  const [scrollRefresh, setScrollRefresh] = useState(null);
  const [page, setPage] = useState({
    num: 1
  });
  const [isAll, setIsAll] = useState(false);
  const [commentId, setCommentId] = useState(null);
  const [toUuid, setToUuid] = useState("");
  const size = 10;
  const toTuipian = () => {
    const stackKey = `tuipian-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "tuipian",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <TuipianPage stackKey={stackKey} id={id} />
          </StackPage>
        )
      }
    });
  };
  const toVideoDetail = videoId => {
    const stackKey = `video_detail-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "video_detail",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <VideoDetail stackKey={stackKey} id={videoId} />
          </StackPage>
        )
      }
    });
  };
  const toAppendCoin = () => {
    const stackKey = `append_conin-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "append_conin",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <AppendCoin stackKey={stackKey} id={id} />
          </StackPage>
        )
      }
    });
  };
  const addCoins = () => {
    let coinStr = "";
    emit.emit("changeAlert", {
      _title: "追加赏金",
      _content: (
        <div className="coin_input_box">
          <input
            placeholder="输入打赏金额"
            type="number"
            onChange={e => {
              coinStr = e.target.value;
            }}
          />
        </div>
      ),
      _submitText: "确定",
      _notDouble: true,
      _cancal: () => {},
      _submit: () => {
        if (!coinStr) {
          emit.emit("showToast", {
            text: "请输入打赏金额",
            time: 3000
          });
        }
        appendCoins({
          find_id: id,
          coins: coinStr
        }).then(res => {
          // console.log("-----追加赏金", res);
          if (res.data.status === 200) {
            emit.emit("showToast", {
              text: "打赏成功",
              time: 3000
            });
          } else {
            if (res.data.msg.indexOf("余额不足") !== -1) {
              setTimeout(() => {
                emit.emit("changeAlert", {
                  _title: "温馨提示",
                  _content: "灰币余额不足，立即充值",
                  _submitText: "灰币充值",
                  _notDouble: true,
                  _cancal: () => {},
                  _submit: () => {
                    const stackKey = `user-member-${new Date().getTime()}`;
                    StackStore.dispatch({
                      type: "push",
                      payload: {
                        name: "user-member",
                        element: (
                          <StackPage
                            stackKey={stackKey}
                            key={stackKey}
                            style={{ zIndex: stacks.length + 2 }}
                          >
                            <MyMember stackKey={stackKey} type={1} />
                          </StackPage>
                        )
                      }
                    });
                  }
                });
              }, 300);
            }
            emit.emit("showToast", {
              text: res.data.msg,
              time: 3000
            });
          }
        });
      }
    });
  };
  const renderInput = () => {
    let inputValue = "";
    return (
      <div className="video-detail-input-layer">
        <ClickBtn
          className="video-detail-input-close"
          onTap={() => {
            setShowInput(false);
          }}
        />
        <div className="video-detail-input">
          <div className="input-box">
            <img src={write} />
            <input
              type="text"
              placeholder="优质评论优先展示"
              onChange={e => {
                inputValue = e.target.value;
              }}
              autoFocus
            />
          </div>
          <ClickBtn
            className="input-sub"
            onTap={() => {
              setShowInput(false);
              if (!inputValue) {
                emit.emit("showToast", {
                  text: "请输入评论内容～",
                  time: 3000
                });
                return;
              }
              commentReply({
                reply_id: commentId,
                comment: inputValue,
                to_uuid: toUuid
              }).then(res => {
                // console.log(res);
                if (res.data && res.data.status === 200) {
                  emit.emit("showToast", {
                    text: "评论成功",
                    time: 3000
                  });
                } else {
                  emit.emit("showToast", {
                    text: res.msg,
                    time: 3000
                  });
                }
              });
            }}
          >
            确定
          </ClickBtn>
        </div>
      </div>
    );
  };
  useEffect(() => {
    getQiupianDetail({
      find_id: id
    }).then(res => {
      // console.log("求片详情", res);
      setQiupianInfo(res.data);
    });
  }, []);
  useEffect(() => {
    getReplyByFind({
      find_id: id,
      page: page.num,
      size
    }).then(res => {
      // console.log("推荐", res);
      if (res.status === 200) {
        if (page.num === 1) {
          setFindList(res.data.list);
        } else {
          setFindList([...findList, ...res.data.list]);
        }
        if (res.data.list.length < size) {
          setIsAll(true);
        }
      }
    });
  }, [page]);
  return useMemo(
    () => (
      <div className="full-column">
        <BackHead stackKey={stackKey} title="详情" />
        {showInput && renderInput()}
        {!qiupianInfo ? (
          <Loading show overSize={false} />
        ) : (
          <div className="qiupian_page">
            <ScrollArea
              ListData={findList}
              loadingMore={!isAll}
              isRefresh={scrollRefresh}
              onScrollEnd={() => {
                if (isAll) return;
                page.num = page.num + 1;
                setPage({ ...page });
              }}
            >
              <div
                className="qp_card_box"
                style={{
                  padding: "0 0.32rem"
                }}
              >
                <div className="user_info_box">
                  <div className="flex_row">
                    <Avatar
                      boxClass="user_thumb"
                      size={0.96}
                      isCreater={Boolean(
                        qiupianInfo.detail.member?.auth_status
                      )}
                      img={qiupianInfo.detail.member?.thumb}
                      uuid={qiupianInfo.detail.member?.uuid}
                    />
                    <div>
                      <p className="user_name">
                        {!qiupianInfo.detail.member
                          ? "数据错误"
                          : qiupianInfo.detail.member.nickname}
                      </p>
                      <p className="xk_num">{qiupianInfo.detail.like}人想看</p>
                    </div>
                  </div>
                  <span className="user_fb_time">
                    {qiupianInfo.detail.created_at_format}
                  </span>
                </div>
                <div className="qp_card_content">
                  <p className="qp_text">{qiupianInfo.detail.title}</p>
                  {/* <div className="user_img_box"><Simg /></div> */}
                  {qiupianInfo.detail.mv_info &&
                    !(qiupianInfo.detail.mv_info instanceof Array) && (
                      <ClickBtn
                        className="video_info"
                        onTap={() => {
                          toVideoDetail(qiupianInfo.detail.mv_info.mv.id);
                        }}
                      >
                        <div className="video_thumb">
                          <Simg
                            src={qiupianInfo.detail.mv_info.mv.thumb_cover}
                          />
                        </div>
                        <div className="video_play_info">
                          <p className="video_title">
                            {qiupianInfo.detail.mv_info.mv.title}
                          </p>
                          <div className="play_num one_line">
                            {qiupianInfo.detail.mv_info.mv_member.nickname}{" "}
                            {qiupianInfo.detail.mv_info.mv.count_play_str}
                          </div>
                        </div>
                      </ClickBtn>
                    )}
                  {qiupianInfo.detail.images.length > 0 && (
                    <div className="detai_user_img_list">
                      {qiupianInfo.detail.images.map((item, index) => {
                        const contentW = 10 - 0.64 - 1.18;
                        return (
                          <div
                            key={`detai_user_img_${index}`}
                            className="detai_user_img_item"
                            style={{
                              width: `${contentW}rem`
                              // minHeight: `${contentW}rem`
                            }}
                          >
                            <Simg
                              src={item}
                              isZoom={true}
                              refreshScroll={() =>
                                setScrollRefresh(new Date().getTime())
                              }
                            />
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
                <div className="flex_row">
                  {qiupianInfo.detail.coins > 0 &&
                    !Boolean(qiupianInfo.detail.is_match) && (
                      <ClickBtn
                        className="tuipian_btn add_coin_btn"
                        onTap={addCoins}
                      >
                        <img src={coinIcon} />
                        <span>追加打赏</span>
                      </ClickBtn>
                    )}
                  <ClickBtn
                    className="tuipian_btn"
                    onTap={toTuipian}
                    styles={{
                      width:
                        qiupianInfo.detail.coins > 0 &&
                        !Boolean(qiupianInfo.detail.is_match)
                          ? "4.48rem"
                          : "100%"
                    }}
                  >
                    <img src={sendIcon} />
                    <span>我要推片</span>
                  </ClickBtn>
                </div>
                {qiupianInfo.detail.coins > 0 && (
                  <div>
                    <div className="flex_row" style={{ marginTop: "0.8rem" }}>
                      <div className="title_text">总赏金</div>
                      <span className="coin_text">
                        {qiupianInfo.detail.total_coins}灰币
                      </span>
                    </div>
                    <ClickBtn className="ds_users" onTap={toAppendCoin}>
                      <div className="avatar_box">
                        {[...Array(4)].map((item, index) => (
                          <div
                            key={`fans_avatar_${index}`}
                            className="fans_avatar"
                            style={{
                              left: `${index * 0.2265}rem`
                            }}
                          >
                            {qiupianInfo.append_list.length >= index + 1 && (
                              <Simg
                                src={qiupianInfo.append_list[index].thumb}
                              />
                            )}
                          </div>
                        ))}
                      </div>
                      <div className="fans_text flex_row">
                        {qiupianInfo.append_list.length === 0 ? (
                          <span>暂无人追加赏金</span>
                        ) : (
                          <span>
                            {qiupianInfo.append_list.length}人追加了
                            {qiupianInfo.append_list.reduce(
                              (sum, e) => sum + Number(e.coins),
                              0
                            )}
                            灰币
                          </span>
                        )}
                        <img src={iconRight} />
                      </div>
                    </ClickBtn>
                    <TimeShow
                      coin={qiupianInfo.detail.coins}
                      starTime={qiupianInfo.count_down.now}
                      endTime={qiupianInfo.count_down.expire_at}
                    />
                  </div>
                )}
              </div>
              <div
                style={{
                  height: "1px",
                  width: "100%",
                  background: "#332d46",
                  margin: "0.4rem 0"
                }}
              ></div>
              <div className="rexin_user">
                <div className="rexin_title">
                  <div className="title">热心群众</div>
                  <div className="number">{qiupianInfo.detail.reply}人</div>
                </div>

                {!findList ? (
                  <Loading show overSize={false} size={30} />
                ) : findList.length == 0 ? (
                  <NoData />
                ) : (
                  <div>
                    {findList.map((item, index) => (
                      <div key={`rexin_user_${index}`}>
                        <RexinUserCard
                          onFocus={(id, uuid) => {
                            setShowInput(true);
                            setCommentId(id);
                            setToUuid(uuid ? uuid : "");
                          }}
                          data={item}
                        />
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </ScrollArea>
          </div>
        )}
      </div>
    ),
    [showInput, qiupianInfo, isAll, findList, scrollRefresh, commentId, toUuid]
  );
};
