import React, { useEffect, useMemo, useRef, useState } from "react";
import BackHead from "../../backHeader";
import ScrollArea from "../../scrollarea";
import NoData from "../../noData";
import Loading from "../../loading";
import emit from "../../../libs/eventEmitter";
import { SelectVideo } from "../qiupian/qiupian_card";
import { getMvList } from "../../../libs/http";
import ClickBtn from "../../clickBtn";
export default props => {
  const { stackKey, setVideoList, type } = props;
  const [mvList, setMvList] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectMv, setSelectMv] = useState({
    data: []
  });
  const [isAll, setIsAll] = useState(false);
  const inputRef = useRef(null);
  const [page, setPage] = useState({
    num: 1
  });
  const size = 15;
  useEffect(() => {
    if (!inputRef.current) return;
    getMvList({
      type,
      size,
      page: page.num,
      kwy: inputRef.current.value
    }).then(res => {
      // console.log("**作品库**", res);
      if (res.status === 200) {
        if (loading) {
          setLoading(false);
        }
        if (page.num === 1) {
          setMvList([...res.data]);
        } else {
          setMvList([...mvList, ...res.data]);
        }

        if (res.data.length < size) {
          setIsAll(true);
        }
      } else {
        emit.emit("showToast", {
          text: res.msg,
          time: 3000
        });
      }
    });
  }, [page, inputRef.current]);
  return (
    <div className="full-column tuipian_page">
      <BackHead
        stackKey={stackKey}
        title="选择视频"
        right={() => (
          <ClickBtn
            className="right_serch"
            onTap={() => {
              selectMv.data = [];
              setSelectMv({ ...selectMv });
              setIsAll(false);
              setLoading(true);
              page.num = 1;
              setPage({ ...page });
            }}
          >
            搜索
          </ClickBtn>
        )}
      />
      <div className="seach_input_box">
        <input placeholder="输入标题名称搜索" ref={inputRef} />
      </div>
      {useMemo(
        () =>
          loading ? (
            <Loading show />
          ) : (
            <div className="full-column">
              {mvList.length === 0 ? (
                <NoData />
              ) : (
                <ScrollArea
                  ListData={mvList}
                  onScrollEnd={() => {
                    if (isAll) return;
                    page.num = page.num + 1;
                    setPage({ ...page });
                  }}
                  loadingMore={!isAll}
                >
                  {mvList.map((item, index) => (
                    <div key={`upload_video_${index}`}>
                      <SelectVideo
                        type="select"
                        isSelect={
                          selectMv.data.filter(n => n.id === item.id).length !==
                          0
                        }
                        data={item}
                        onSelect={() => {
                          const arr = selectMv.data.filter(
                            n => n.id === item.id
                          );
                          if (arr.length === 0) {
                            if (selectMv.data.length === 10) {
                              emit.emit("showToast", {
                                text: "最多只能选择10个",
                                time: 3000
                              });
                              return;
                            }
                            selectMv.data = [...selectMv.data, item];
                            setSelectMv({ ...selectMv });
                          } else {
                            selectMv.data.map((v, i) => {
                              if (v.id === item.id) {
                                selectMv.data.splice(i, 1);
                              }
                            });
                            setSelectMv({ ...selectMv });
                          }
                        }}
                      />
                    </div>
                  ))}
                </ScrollArea>
              )}
            </div>
          ),
        [loading, mvList, selectMv, isAll]
      )}
      {!loading && (
        <div className="select_fot">
          <span>已选择{selectMv.data.length}个视频</span>
          <ClickBtn
            onTap={() => {
              setVideoList([...selectMv.data]);
              emit.emit(stackKey, stackKey);
            }}
          >
            完成
          </ClickBtn>
        </div>
      )}
    </div>
  );
};
