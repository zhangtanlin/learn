import React, { useEffect, useMemo, useRef, useState } from "react";
import "../../../resources/css/card.less";
import Simg from "../../simg";
import sendIcon from "../../../resources/img/public/icon_send_video_tag_find.png";
import coinIcon from "../../../resources/img/public/icon_tb_tag.png";
import xkIcon from "../../../resources/img/public/xk_icon.png";
import yqIcon from "../../../resources/img/public/yq_icon.png";
import oneIcon from "../../../resources/img/public/icon_fv_rank_one.png";
import twoIcon from "../../../resources/img/public/icon_fv_rank_two.png";
import threeIcon from "../../../resources/img/public/icon_fv_rank_three.png";
import ttVideoIcon from "../../../resources/img/public/tt_video_icon.png";
import seeIcon from "../../../resources/img/public/icon_see_num.png";
import nozanIcon from "../../../resources/img/public/icon_like_tag.png";
import zanIcon from "../../../resources/img/public/icon_text_like_red.png";
import msgIcon from "../../../resources/img/public/icon_message_num.png";
import jubaoIcon from "../../../resources/img/public/icon_jubao_video.png";
import moreIcon from "../../../resources/img/public/icon_more_check.png";
import deleteIcon from "../../../resources/img/public/icon_replay_fv_delete.png";
import unselectIcon from "../../../resources/img/public/icon_unselect.png";
import selectIcon from "../../../resources/img/public/icon_select.png";
import seekbIcon from "../../../resources/img/public/icon_fv_seekb_bg.png";
import jubaoNormal from "../../../resources/img/public/jubao_normal.png";
import jubaoRed from "../../../resources/img/public/jubao_checked_red.png";
import cainaIcon from "../../../resources/img/public/icon_find_video_ok.png";
import ClickBtn from "../../clickBtn";
import StackPage from "../../stackpage";
import StackStore from "../../../store/stack";
import ToutiaoDetail from "./toutiao_detail";
import UserPage from "../../category/user_page";
import QiupianDetail from "./qiupian_detail";
import HorizontalScroller from "../../horizontal_scroller";
import Hammer from "hammerjs";
import Avatar from "../../avatar";
import emit from "../../../libs/eventEmitter";
import global from "../../../libs/globalVar";
import VideoDetai from "../../videoDetail";
import {
  wangtLook,
  followUp,
  praiseWei,
  praiseComment,
  reportTiezi,
  zanMvReply,
} from "../../../libs/http";
const kingIcon = [oneIcon, twoIcon, threeIcon];
export const NewCard = (props) => {
  const { data } = props;
  const [like, setLike] = useState(data.is_like);
  const isArry = data.mv_info instanceof Array || data.mv_info == null;
  const contentW = 10 - 0.64 - (data.images.length - 1) * 0.119; //0.64指padding宽  0.119间隔宽
  const [stacks] = StackStore.useGlobalState("stacks");
  const toDetail = () => {
    const stackKey = `toutiao_detai-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "toutiao_detai",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <QiupianDetail stackKey={stackKey} id={data.id} />
          </StackPage>
        ),
      },
    });
  };
  const toVideoDetail = (id) => {
    const stackKey = `video_detail-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "video_detail",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <VideoDetai stackKey={stackKey} id={id} />
          </StackPage>
        ),
      },
    });
  };

  return useMemo(
    () => (
      <ClickBtn className="qp_card_box" onTap={toDetail}>
        <div className="user_info_box">
          {!data.member ? (
            <p
              style={{
                color: "#ffffff",
                fontSize: "0.373rem",
              }}
            >
              数据错误
            </p>
          ) : (
            <div className="flex_row">
              <Avatar
                boxClass="user_thumb"
                img={data?.member?.thumb}
                size={0.92}
                uuid={data.uuid}
              />
              <div>
                <p className="user_name">{data?.member?.nickname}</p>
                <p className="xk_num">{data.like}人想看</p>
              </div>
            </div>
          )}
          <ClickBtn
            className={`xk_btn ${like ? "yq_btn" : ""}`}
            onTap={() => {
              if (like) return;
              setLike(true);
              wangtLook({
                find_id: data.id,
              }).then((res) => {
                // console.log("想看", res);
              });
            }}
          >
            <img src={like ? yqIcon : xkIcon} />
            <span>{like ? "已求" : "想看"}</span>
          </ClickBtn>
        </div>
        <div className="qp_card_content">
          <p className="qp_text">{data.title}</p>
          {data.images.length > 0 && (
            <div className="user_img_list">
              {data.images.map((item, index) => {
                const imgW = contentW / data.images.length;
                let onTap;
                return (
                  <ClickBtn
                    key={`user_img_${index}`}
                    className="user_img_item"
                    onTap={() => onTap()}
                    styles={{
                      width: `${imgW}rem`,
                      height: `${7.14 / data.images.length}rem`,
                    }}
                  >
                    <Simg
                      src={item}
                      isZoom={true}
                      onTap={(fn) => {
                        onTap = fn;
                      }}
                    />
                  </ClickBtn>
                );
              })}
            </div>
          )}
          {!isArry && (
            <ClickBtn
              className="video_info"
              onTap={() => {
                toVideoDetail(data.mv_info.mv.id);
              }}
            >
              <div className="video_thumb">
                <Simg src={data.mv_info.mv.thumb_cover} />
              </div>
              <div className="video_play_info">
                <p className="video_title">{data.mv_info.mv.title}</p>
                <div className="play_num one_line">
                  {data.mv_info.mv_member.nickname}{" "}
                  {data.mv_info.mv.count_play_str}
                </div>
              </div>
            </ClickBtn>
          )}
        </div>
        <div className="qp_fot_box">
          {data.coins ? (
            <div className="left_text">
              <img src={coinIcon} />
              <span>{data.coins}灰币</span>
            </div>
          ) : (
            <span></span>
          )}
          <div className="right_text">
            <img src={sendIcon} />
            <span>{data.reply}人回复</span>
          </div>
        </div>
      </ClickBtn>
    ),
    [data, like]
  );
};

export const KingCard = (props) => {
  const { index, data } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const toDetail = () => {
    const stackKey = `toutiao_detai-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "toutiao_detai",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <UserPage stackKey={stackKey} uuid={data.uuid} />
          </StackPage>
        ),
      },
    });
  };
  return useMemo(
    () => (
      <ClickBtn className="king_item_box" onTap={toDetail}>
        <div className="flex_row">
          <div className="user_num">
            {index <= 2 ? <img src={kingIcon[index]} /> : index + 1}
          </div>
          <div className="user_info_box">
            <Avatar
              boxClass="user_thumb"
              size={1.08}
              uuid={data.uuid}
              img={data?.member?.thumb}
              isCreater={data?.member?.auth_status ? true : false}
            />
            <div className="user_column">
              <div className="user_name">{data?.member?.nickname}</div>
              <div className="fans_num">粉丝{data?.member?.followed_count}</div>
            </div>
          </div>
        </div>
        <span className="tj_text">推荐{data.receive}</span>
      </ClickBtn>
    ),
    [data]
  );
};
export const ToutiaoCard = (props) => {
  const { data } = props;
  if (!data.uuid) {
    return "";
  }
  const [follow, setFollow] = useState(data?.member?.is_follow);
  const [zan, setZan] = useState(data.is_like);
  const [chooseJubao, setChooseJubao] = useState(-1);
  const [showJubao, setShowJubao] = useState(false);
  const [likeNum, setLikeNum] = useState({
    num: data.like,
  });
  const [stacks] = StackStore.useGlobalState("stacks");
  const contentW = 10 - 0.64 - (data.imagesFull.length - 1) * 0.119; //0.64指padding宽  0.119间隔宽
  const toDetail = () => {
    const stackKey = `toutiao_detai-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "toutiao_detai",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <ToutiaoDetail stackKey={stackKey} id={data.id} />
          </StackPage>
        ),
      },
    });
  };
  const followeUser = async () => {
    const res = await followUp({ follow_uuid: data.uuid });
    if (res.status === 200) {
      setFollow(!follow);
    } else {
      emit.emit("showToast", {
        text: res.msg,
        time: 3000,
      });
    }
  };
  const jubaoItem = (text, index) => {
    return (
      <div
        className="video-detail-jubao-item"
        key={index}
        onClick={() => {
          setChooseJubao(index);
        }}
      >
        <img src={chooseJubao == index ? jubaoRed : jubaoNormal} />
        <span
          style={{
            color: chooseJubao == index ? "#f1bc8d" : "#878799",
          }}
        >
          {text}
        </span>
      </div>
    );
  };
  useEffect(() => {
    if (showJubao) {
      emit.emit("changeAlert", {
        _title: "举报推荐",
        _content: (
          <div className="video-detail-jubao">
            <p>若该视频包含以下内容，你可以在此举报</p>
            <div>
              {global.reportType.map((item, index) => {
                return jubaoItem(item, index);
              })}
            </div>
          </div>
        ),
        _submitText: "确定",
        _cancel: () => {
          setShowJubao(false);
        },
        _submit: () => {
          if (chooseJubao !== -1) {
            reportTiezi({
              wei_id: data.id,
              content: global.reportType[chooseJubao],
            }).then((res) => {
              if (res.status !== 200) {
                emit.emit("showToast", {
                  text: res.msg,
                  time: 3000,
                });
              }
            });
          } else {
            emit.emit("showToast", {
              text: "请选择举报类型",
              time: 3000,
            });
          }
          setShowJubao(false);
        },
        _notDouble: true,
      });
    }
  }, [showJubao, chooseJubao]);
  return useMemo(
    () => (
      <ClickBtn className="qp_card_box tt_card_box" onTap={toDetail}>
        <div className="user_info_box">
          <div className="flex_row">
            <Avatar
              boxClass="user_thumb"
              size={1.08}
              img={data?.member?.thumb}
              isCreater={data?.member?.auth_status ? true : false}
              uuid={data.uuid}
            />
            <div>
              <p className="user_name">{data?.member?.nickname}</p>
              <p className="xk_num">{data.created_str}</p>
            </div>
          </div>
          <ClickBtn
            className={`gz_btn ${follow ? "ygz_btn" : ""}`}
            onTap={followeUser}
          >
            {follow ? "已关注" : "关注"}
          </ClickBtn>
        </div>
        <div className="qp_card_content">
          <p className="qp_text">{data.title}</p>
          {data.imagesFull.length > 0 && (
            <div className="user_img_list">
              {data.imagesFull.map((item, index) => {
                const imgW = contentW / data.imagesFull.length;
                let onTap;
                return (
                  <ClickBtn
                    key={`user_img_${index}`}
                    className="user_img_item"
                    onTap={() => onTap()}
                    styles={{
                      width: `${imgW}rem`,
                      height: `${7.14 / data.imagesFull.length}rem`,
                    }}
                  >
                    <Simg
                      src={item.source}
                      isZoom={true}
                      onTap={(fn) => {
                        onTap = fn;
                      }}
                    />
                  </ClickBtn>
                );
              })}
            </div>
          )}
        </div>
        {data.mv_info && (
          <ClickBtn
            className="video_href_box"
            onTap={() => {
              const stackKey = `video_detail-${new Date().getTime()}`;
              StackStore.dispatch({
                type: "push",
                payload: {
                  name: "video_detail",
                  element: (
                    <StackPage
                      stackKey={stackKey}
                      key={stackKey}
                      style={{ zIndex: stacks.length + 2 }}
                    >
                      <VideoDetai stackKey={stackKey} id={data.mv_info.id} />
                    </StackPage>
                  ),
                },
              });
            }}
          >
            <img src={ttVideoIcon} />
            <div className="one_line">{data.mv_info.title}</div>
          </ClickBtn>
        )}
        <div className="tt_card_fot_box">
          <span className="tt_num_item">
            <img src={seeIcon} />
            <span>{data.look}</span>
          </span>
          <ClickBtn
            className="tt_num_item"
            styles={{
              color: zan ? "#fd5c18" : "#999999",
            }}
            onTap={() => {
              praiseWei({
                wei_id: data.id,
                type: zan ? "unset" : "set",
              }).then((res) => {
                if (res.status === 200) {
                  likeNum.num = zan ? likeNum.num - 1 : likeNum.num + 1;
                  setLikeNum({ ...likeNum });
                  setZan(!zan);
                  // console.log("赞", res);
                }
              });
            }}
          >
            <img src={zan ? zanIcon : nozanIcon} />
            <span>{likeNum.num}</span>
          </ClickBtn>
          <div className="tt_num_item">
            <img src={msgIcon} />
            <span>{data.comment_number}</span>
          </div>
          <ClickBtn
            className="tt_num_item"
            onTap={() => {
              setShowJubao(true);
            }}
          >
            <img src={jubaoIcon} />
          </ClickBtn>
        </div>
      </ClickBtn>
    ),
    [data, follow, zan, chooseJubao]
  );
};
export const RexinUserCard = (props) => {
  const { onFocus, data } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const [follow, setFollow] = useState(data?.member?.is_follow);
  const [zan, setZan] = useState(Boolean(data.is_like));
  const [chooseJubao, setChooseJubao] = useState(-1);
  const [showJubao, setShowJubao] = useState(false);
  const [zanNum, setZanNum] = useState({
    num: data.like_num_str,
  });
  const followeUser = async () => {
    const res = await followUp({ follow_uuid: data?.member?.uuid });
    if (res.status === 200) {
      setFollow(!follow);
    } else {
      emit.emit("showToast", {
        text: res.msg,
        time: 3000,
      });
    }
  };
  const jubaoItem = (text, index) => {
    return (
      <div
        className="video-detail-jubao-item"
        key={index}
        onClick={() => {
          setChooseJubao(index);
        }}
      >
        <img src={chooseJubao == index ? jubaoRed : jubaoNormal} />
        <span
          style={{
            color: chooseJubao == index ? "#f1bc8d" : "#878799",
          }}
        >
          {text}
        </span>
      </div>
    );
  };
  useEffect(() => {
    if (showJubao) {
      emit.emit("changeAlert", {
        _title: "举报推荐",
        _content: (
          <div className="video-detail-jubao">
            <p>若该视频包含以下内容，你可以在此举报</p>
            <div>
              {global.reportType.map((item, index) => {
                return jubaoItem(item, index);
              })}
            </div>
          </div>
        ),
        _submitText: "确定",
        _cancel: () => {
          setShowJubao(false);
        },
        _submit: () => {
          if (chooseJubao !== -1) {
            reportTiezi({
              wei_id: data.id,
              content: global.reportType[chooseJubao],
            }).then((res) => {
              if (res.status !== 200) {
                emit.emit("showToast", {
                  text: res.msg,
                  time: 3000,
                });
              }
            });
          } else {
            emit.emit("showToast", {
              text: "请选择举报类型",
              time: 3000,
            });
          }
          setShowJubao(false);
        },
        _notDouble: true,
      });
    }
  }, [showJubao, chooseJubao]);
  return useMemo(
    () => (
      <div className="rexin_card">
        {Boolean(data.is_accept) && <img className="caina" src={cainaIcon} />}
        <div
          className="flex_row"
          style={{
            justifyContent: "space-between",
          }}
        >
          <div className="user_info_head">
            <Avatar
              img={data?.member?.user_thumb}
              boxClass="user_thumb"
              uuid={data?.member?.uuid}
            />
            <div>
              <div className="flex_row">
                <div className="user_name">{data?.member?.nickname}</div>
                <div className="dian"></div>
                <ClickBtn
                  className={`gz_btn ${follow ? "ygz_btn" : ""}`}
                  onTap={followeUser}
                >
                  {follow ? "已关注" : "关注"}
                </ClickBtn>
              </div>
              <div className="fans_num">{data?.member?.followed_count}粉丝</div>
            </div>
          </div>
          {Boolean(data.coins) && (
            <div
              style={{
                fontSize: "0.32rem",
                color: "#fc9b3c",
                marginRight: "0.32rem",
              }}
            >
              获得全部赏金{data.coins}灰币
            </div>
          )}
        </div>

        <div className="rexin_content">
          <HorizontalScroller>
            <div className="rexin_video_list">
              {data.mvs.map((item, index) => (
                <ClickBtn
                  className="rexin_video_item"
                  key={`rexin_video_${index}`}
                  onTap={() => {
                    const stackKey = `video_detail-${new Date().getTime()}`;
                    StackStore.dispatch({
                      type: "push",
                      payload: {
                        name: "video_detail",
                        element: (
                          <StackPage
                            stackKey={stackKey}
                            key={stackKey}
                            style={{ zIndex: stacks.length + 2 }}
                          >
                            <VideoDetai stackKey={stackKey} id={item.id} />
                          </StackPage>
                        ),
                      },
                    });
                  }}
                >
                  <div className="rexin_video_thumb">
                    <div className="video_time">{item.duration_str}</div>
                    <Simg src={item.thumb_cover} />
                  </div>
                  <div className="rexin_video_title one_line">{item.title}</div>
                </ClickBtn>
              ))}
            </div>
          </HorizontalScroller>
        </div>
        <div className="rexin_card_fot">
          <span></span>
          {/* <div className="ds_btn">
            <img src={coinIcon} />
            <span>打赏</span>
          </div> */}
          <div className="flex_row num_box">
            <ClickBtn
              className="tt_num_item"
              styles={{ marginRight: "0.853rem" }}
              onTap={() => {
                setShowJubao(true);
              }}
            >
              <img src={jubaoIcon} />
            </ClickBtn>
            <ClickBtn
              className="flex_row"
              styles={{
                marginRight: "0.853rem",
                color: zan ? "#fd5c18" : "#999999",
              }}
              onTap={() => {
                zanMvReply({
                  reply_id: data.id,
                  type: zan ? "unset" : "set",
                }).then((res) => {
                  // console.log("赞", res);
                  zanNum.num = zan
                    ? Number(zanNum.num) - 1
                    : Number(zanNum.num) + 1;
                  setZanNum({ ...zanNum });
                  setZan(!zan);
                });
              }}
            >
              <img src={zan ? zanIcon : nozanIcon} />
              <span>{zanNum.num}</span>
            </ClickBtn>
            <ClickBtn
              className="flex_row"
              onTap={() => {
                onFocus && onFocus(data.id);
              }}
            >
              <img src={msgIcon} />
              <span>{data.comment_list.total}</span>
            </ClickBtn>
          </div>
        </div>
        {data.comment_list.list.length > 0 && (
          <div className="pl_box">
            <div>
              {data.comment_list.list.map((item, index) => (
                <div key={`pl_item_${index}`} className="pl_item">
                  <div className="user_info_box">
                    <div className="flex_row">
                      <Avatar
                        boxClass="thumb"
                        img={item.member.thumb}
                        uuid={item.member.uuid}
                      />
                      <div className="user_name">{item.member.nickname}</div>
                    </div>
                    <div className="flex_row num_box">
                      <img src={msgIcon} />
                      <span>58</span>
                    </div>
                  </div>
                  <div className="pl_content">
                    {item.comment}
                    {/* 回复<span>@哥只是个传说</span>遇到我直用白浆遇白浆把喷泉盛满。 */}
                  </div>
                  <div
                    className="flex_row"
                    style={{
                      marginTop: "0.32rem",
                      color: "#fff",
                      paddingLeft: "1.02rem",
                    }}
                  >
                    <p>{item.created_str}</p>
                  </div>
                </div>
              ))}
            </div>
            {/* <div className="more_box">
              <span>查看更多</span>
              <img src={moreIcon} />
            </div> */}
          </div>
        )}
      </div>
    ),
    [follow, data, zanNum, zan]
  );
};
export const SelectVideo = props => {
  const { type, onDelete, onSelect, isSelect, data } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const jump = () => {
    const stackKey = `video_detail-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "video_detail",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <VideoDetai stackKey={stackKey} id={data.id} />
          </StackPage>
        ),
      },
    });
  };
  const onSelectCard = () => {
    onSelect();
  };
  return useMemo(
    () => (
      <ClickBtn
        className="search-videoItem"
        onTap={type === "select" ? onSelectCard : jump}
      >
        {type === "delete" && (
          <ClickBtn className="delete_btn" onTap={onDelete}>
            <img src={deleteIcon} />
          </ClickBtn>
        )}
        {type === "select" && (
          <div className="select_btn">
            <img src={isSelect ? selectIcon : unselectIcon} />
          </div>
        )}
        <div className="search-videoCover">
          <Simg src={data.thumb_cover} />
          <span>{data.duration_str}</span>
        </div>
        <div className="search-videoInfo">
          <p>{data.title}</p>
          <div>
            <span>{data.nickname}</span>
            <span>{data.count_play_str}</span>
          </div>
        </div>
      </ClickBtn>
    ),
    [isSelect, onSelect, data]
  );
};

export const CommentCard = (props) => {
  const { data, onFocus } = props;
  const [zan, setZan] = useState(false);
  const [zanNum, setZanNum] = useState({
    num: data.like_num,
  });
  return useMemo(
    () => (
      <div className="comment_card_box">
        <div className="user_info_head">
          <Avatar
            size={0.96}
            boxClass="user_thumb"
            isCreater={data?.member?.auth_status}
            uuid={data.uuid}
          />
          <div>
            <div className="flex_row">
              <div className="user_name">{data?.member?.nickname}</div>
            </div>
            <div className="fans_num">{data?.member?.followed_count}粉丝</div>
          </div>
        </div>
        <div className="comment_content">
          <p className="comment_text">{data.comment}</p>
          <div className="comment_time">
            <span className="time">{data.created_at}</span>
            <div className="flex_row num_box">
              <ClickBtn
                className="flex_row"
                styles={{
                  marginRight: "0.853rem",
                  color: zan ? "#fd5c18" : "#999999",
                }}
                onTap={() => {
                  praiseComment({
                    comment_id: data.id,
                    type: zan ? "unset" : "set",
                  }).then((res) => {
                    if (res.status === 200) {
                      zanNum.num = zan ? zanNum.num - 1 : zanNum.num + 1;
                      setZanNum({ ...zanNum });
                      setZan(!zan);
                      // console.log("赞", res);
                    }
                  });
                }}
              >
                <img src={zan ? zanIcon : nozanIcon} />
                <span>{zanNum.num}</span>
              </ClickBtn>
              <ClickBtn
                className="flex_row"
                onTap={() => {
                  onFocus && onFocus(data.id);
                }}
              >
                <img src={msgIcon} />
                <span>{data.reply_num}</span>
              </ClickBtn>
            </div>
          </div>
        </div>
        {/* <div className="pl_box">
          <div>
            {[...Array(2)].map((item, index) => (
              <div key={`pl_item_${index}`} className="pl_item">
                <div className="user_info_box">
                  <div className="flex_row">
                    <div className="thumb">
                      <Simg />
                    </div>
                    <div className="user_name">哥只是个传说</div>
                  </div>
                  <div className="flex_row num_box">
                    <img src={zanIcon} />
                    <span>58</span>
                  </div>
                </div>
                <div className="pl_content">
                  回复<span>@哥只是个传说</span>遇到我直用白浆遇白浆把喷泉盛满。
                  <div className="hf_time">
                    <div>2010-10-11 23:11</div>
                    <div>回复</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="more_box">
            <span>查看更多</span>
            <img src={moreIcon} />
          </div>
        </div> */}
        <div className="line"></div>
      </div>
    ),
    [data, zan]
  );
};
export const FilterCard = (props) => {
  const { type, onSubmit, onCancel, filter, setFilter } = props;
  const [filterValue, setFilterValue] = useState("");
  const [coinValue, setCoinValue] = useState("");
  const [statusValue, setStatusValue] = useState("");
  const [timeValue, setTimeValue] = useState(0);
  const pRef = useRef(null);
  const dayRef = useRef(null);
  const onReset = () => {
    setFilterValue("");
    setCoinValue("");
    setStatusValue("");
    setTimeValue(0);
  };
  const getTimeStr = (date) => {
    return `${date.getFullYear()}-${date.getMonth() + 1}-${date.getDate()}`;
  };
  const onSetFilter = () => {
    if (type === "new") {
      setFilter({
        has_coins: coinValue,
        is_match: statusValue,
      });
    } else {
      let dataRange = "";
      if (timeValue !== 0 && timeValue !== 31) {
        let currentTime = new Date();
        currentTime.setDate(currentTime.getDate() - timeValue);
        dataRange = `${getTimeStr(currentTime)},${getTimeStr(new Date())}`;
      }
      setFilter({
        has_coins: coinValue,
        is_match: statusValue,
        sort: filterValue,
        date_range: dataRange,
      });
    }
  };
  const filterList = [
    {
      title: "想看",
      id: "like",
    },
    {
      title: "赏金",
      id: "coins",
    },
    {
      title: "回复",
      id: "reply",
    },
  ];
  const coinList = [
    {
      title: "有赏金",
      id: 1,
    },
    {
      title: "无赏金",
      id: 0,
    },
  ];
  const statusList = [
    {
      title: "已采纳",
      id: 1,
    },
    {
      title: "未采纳",
      id: 0,
    },
  ];

  useEffect(() => {
    if (!pRef.current || !dayRef.current) return;
    const pHammer = new Hammer(pRef.current);
    const setDays = (e) => {
      const leftPx = pRef.current.getBoundingClientRect().left;
      const dayW = dayRef.current.clientWidth / 30;
      const curDay = Math.floor((e.center.x - leftPx) / dayW);
      if (curDay <= 31 && curDay >= 0) {
        setTimeValue(curDay);
      }
    };
    pHammer
      .get("pan")
      .set({ threshold: 1, direction: Hammer.DIRECTION_VERTICAL });
    pHammer.on("pan", setDays);
    return () => {
      pHammer.off("pan", setDays);
    };
  }, [pRef.current, dayRef.current]);
  return useMemo(
    () => (
      <div className="filter_box">
        {type == "hot" && (
          <div>
            <div className="filter_title">排序</div>
            <div className="btn_list">
              {filterList.map((item, index) => (
                <ClickBtn
                  onTap={() => {
                    setFilterValue(item.id);
                  }}
                  key={`filter_${index}`}
                  className={`filter_btn ${
                    filterValue === item.id ? "filter_btn_active" : ""
                  }`}
                >
                  {item.title}
                </ClickBtn>
              ))}
            </div>
            <div className="filter_title">
              时间
              <div>
                {timeValue > 0 && (timeValue == 31 ? "全部" : timeValue + "天")}
              </div>
            </div>
            <div className="gesture_box" ref={pRef}>
              <div className="progress_box">
                {timeValue <= 0 && (
                  <div className="progress_box_dian">
                    <img src={seekbIcon} />
                  </div>
                )}
                <div className="day_progress_box" ref={dayRef}>
                  {[...Array(30)].map((item, index) => (
                    <div
                      className={`progress_item ${
                        timeValue - 1 >= index ? "progress_item_active" : ""
                      }`}
                      key={`progress_item_${index}`}
                    >
                      {timeValue < 31 && timeValue - 1 === index && (
                        <div className="progress_item_dian">
                          <img src={seekbIcon} />
                        </div>
                      )}
                    </div>
                  ))}
                </div>
                <div
                  className={`progress_all ${
                    timeValue >= 31 ? "progress_item_active" : ""
                  }`}
                >
                  {timeValue >= 31 && (
                    <div className="progress_item_dian">
                      <img src={seekbIcon} />
                    </div>
                  )}
                </div>
              </div>
            </div>
            <div className="days_text">
              <span>1天</span>
              <div className="flex_row">
                <div className="month">30天</div>
                <div>全部</div>
              </div>
            </div>
          </div>
        )}
        <div className="filter_title">赏金</div>
        <div className="btn_list">
          {coinList.map((item, index) => (
            <ClickBtn
              onTap={() => {
                setCoinValue(item.id);
              }}
              key={`coin_${index}`}
              className={`filter_btn ${
                coinValue === item.id ? "filter_btn_active" : ""
              }`}
            >
              {item.title}
            </ClickBtn>
          ))}
        </div>
        <div className="filter_title">状态</div>
        <div className="btn_list">
          {statusList.map((item, index) => (
            <ClickBtn
              onTap={() => {
                setStatusValue(item.id);
              }}
              key={`status_${index}`}
              className={`filter_btn ${
                statusValue === item.id ? "filter_btn_active" : ""
              }`}
            >
              {item.title}
            </ClickBtn>
          ))}
        </div>
        <div className="footer_btn_list">
          <ClickBtn
            onTap={() => {
              // onCancel && onCancel();
              onReset();
            }}
          >
            重置
          </ClickBtn>
          <ClickBtn
            className="sure_btn"
            onTap={() => {
              onSetFilter();
              onSubmit && onSubmit();
            }}
          >
            确定
          </ClickBtn>
        </div>
      </div>
    ),
    [filterValue, coinValue, statusValue, timeValue, onCancel, onSubmit]
  );
};
