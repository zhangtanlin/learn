import React, { useEffect, useMemo, useRef, useState } from "react";
import BackHead from "../../backHeader";
import ScrollArea from "../../scrollarea";
import { SelectVideo } from "../qiupian/qiupian_card";
import ClickBtn from "../../clickBtn";
import StackPage from "../../stackpage";
import StackStore from "../../../store/stack";
import SelectVideoPage from "./selectvideo_page";
import NoData from "../../noData";
import emit from "../../../libs/eventEmitter";
import { uploadReply } from "../../../libs/http";
export default props => {
  const { stackKey, id } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const [videoList, setVideoList] = useState([]);
  const toSelectvideo = type => {
    const stackKey = `select_video-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "select_video",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <SelectVideoPage
              stackKey={stackKey}
              type={type}
              setVideoList={setVideoList}
            />
          </StackPage>
        )
      }
    });
  };
  return useMemo(
    () => (
      <div className="full-column tuipian_page">
        <BackHead stackKey={stackKey} title="我要推片" />
        <div className="full-column">
          <div className="head_content">
            <p className="title">可在作品库或从平台上传,最多添加10个</p>
            <div className="btn_list">
              <ClickBtn
                className="work_btn"
                onTap={() => toSelectvideo("my")}
              ></ClickBtn>
              <ClickBtn
                className="pt_btn"
                onTap={() => toSelectvideo("all")}
              ></ClickBtn>
            </div>
            <div className="add_num">
              <span>已添加</span> {videoList.length}个
            </div>
          </div>
          <div className="full-column">
            {videoList.length === 0 ? (
              <NoData text="快去选择作品吧" />
            ) : (
              <ScrollArea ListData={videoList}>
                {videoList.map((item, index) => (
                  <div key={`upload_video_${index}`}>
                    <SelectVideo
                      type="delete"
                      data={item}
                      onDelete={() => {
                        let newVideo = videoList;
                        newVideo.splice(index, 1);
                        // console.log(newVideo);
                        setVideoList([...newVideo]);
                      }}
                    />
                  </div>
                ))}
              </ScrollArea>
            )}
          </div>
          <ClickBtn
            className="sure_btn"
            onTap={() => {
              if (videoList.length === 0) {
                emit.emit("showToast", {
                  text: "请在作品库或平台添加作品",
                  time: 3000
                });
                return;
              }
              let videoId = [];
              videoList.map((item, index) => {
                videoId.push(item.id);
              });
              uploadReply({
                find_id: id,
                vid: videoId.join(",")
              }).then(res => {
                if (res.status === 200) {
                  emit.emit(stackKey, stackKey);
                  emit.emit("showToast", {
                    text: res.data.msg,
                    time: 3000
                  });
                } else {
                  emit.emit("showToast", {
                    text: res.msg,
                    time: 3000
                  });
                }
              });
            }}
          >
            确定
          </ClickBtn>
        </div>
      </div>
    ),
    [videoList]
  );
};
