import React, { useEffect, useMemo, useRef, useState } from "react";
import ScrollArea from "../../scrollarea";
import { NewCard, ToutiaoCard, KingCard } from "./qiupian_card";
import Loading from "../../loading";
import NoData from "../../noData";
import { getWeitie, getQiupianList, qiupianKingRank } from "../../../libs/http";
export default props => {
  const { type, filter, show } = props;
  const [loading, setLoading] = useState(true);
  const [initList, setInitList] = useState(false);
  const [listData, setListData] = useState({
    data: []
  });
  const [page, setPage] = useState({
    num: 1
  });
  const [isAll, setIsAll] = useState(false);
  const size = 10;
  useEffect(() => {
    if (show && !initList) {
      setInitList(true);
    }
  }, [show]);
  useEffect(() => {
    setIsAll(false);
    setLoading(true);
    page.num = 1;
    setPage({ ...page });
  }, [filter]);
  const _pullDonRefresh = () => {
    setIsAll(false);
    page.num = 1;
    setPage({ ...page });
  };
  const initListData = async () => {
    let res;
    switch (type) {
      case "new":
        res = await getQiupianList({
          page: page.num,
          type: "new",
          size,
          has_coins: filter.has_coins,
          is_match: filter.is_match
        });
        break;
      case "hot":
        res = await getQiupianList({
          page: page.num,
          type: "hot",
          sort: filter.sort,
          size,
          has_coins: filter.has_coins,
          is_match: filter.is_match,
          date_range: filter.date_range
        });
        break;
      case "king":
        res = await qiupianKingRank();
        break;
      case "toutiao":
        res = await getWeitie({
          type: filter,
          page: page.num
        });
        break;
      default:
        break;
    }
    // console.log("求片列表", res);
    if (res.status === 200) {
      if (page.num === 1) {
        listData.data = [...res.data];
      } else {
        listData.data = [...listData.data, ...res.data];
      }
      if (res.data.length < size) {
        setIsAll(true);
      }
      setListData({ ...listData });
      setLoading(false);
    }
  };
  const _loadMoreData = () => {
    if (isAll) return;
    page.num = page.num + 1;
    setPage({ ...page });
  };
  useEffect(() => {
    if (initList) {
      initListData();
    }
  }, [initList, page]);
  const getCard = (data, index) => {
    switch (type) {
      case "new":
        return <NewCard data={data} index={index} />;
        break;
      case "hot":
        return <NewCard data={data} index={index} />;
        break;
      case "king":
        return <KingCard data={data} index={index} />;
        break;
      case "toutiao":
        return <ToutiaoCard data={data} index={index} />;
        break;
      default:
        break;
    }
  };
  return useMemo(
    () => (
      <div className="full-column">
        {loading || !initList ? (
          <Loading show text={"正在获取数据..."} overSize={false} size={25} />
        ) : listData.data.length > 0 ? (
          <ScrollArea
            ListData={listData.data}
            // pullDonRefresh={_pullDonRefresh}
            onScrollEnd={type === "king" ? null : _loadMoreData}
            loadingMore={!isAll}
            groupId="weitie_list"
          >
            {listData.data.map((item, index) => (
              <div key={`new_card_${index}`}>{getCard(item, index)}</div>
            ))}
          </ScrollArea>
        ) : (
          <NoData />
        )}
      </div>
    ),
    [loading, initList, listData, type, filter]
  );
};
