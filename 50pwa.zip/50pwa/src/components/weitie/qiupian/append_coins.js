import React, { useEffect, useMemo, useRef, useState } from "react";
import BackHead from "../../backHeader";
import Simg from "../../simg";
import ScrollArea from "../../scrollarea";
import { appendCoinsUserList, appendCoins } from "../../../libs/http";
import emit from "../../../libs/eventEmitter";
import Avatar from "../../avatar";
import Loading from "../../loading";
import NoData from "../../noData";
import ClickBtn from "../../clickBtn";
import StackPage from "../../stackpage";
import StackStore from "../../../store/stack";
import MyMember from "../../user/myMember";
export default props => {
  const { stackKey, id } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const [userList, setUserList] = useState([]);
  const [loading, setLoading] = useState(false);
  const initList = () => {
    appendCoinsUserList({
      find_id: id
    }).then(res => {
      // console.log("追加赏金列表", res);
      if (res.status === 200) {
        setUserList([...res.data.list]);
        setLoading(true);
      } else {
        emit.emit("showToast", {
          text: res.msg,
          time: 3000
        });
      }
    });
  };
  useEffect(() => {
    initList();
  }, []);
  const addCoins = () => {
    let coinStr = "";
    emit.emit("changeAlert", {
      _title: "追加赏金",
      _content: (
        <div className="coin_input_box">
          <input
            placeholder="输入打赏金额"
            type="number"
            onChange={e => {
              coinStr = e.target.value;
            }}
          />
        </div>
      ),
      _submitText: "确定",
      _notDouble: true,
      _cancal: () => {},
      _submit: () => {
        if (!coinStr) {
          emit.emit("showToast", {
            text: "请输入打赏金额",
            time: 3000
          });
        }
        appendCoins({
          find_id: id,
          coins: coinStr
        }).then(res => {
          // console.log("-----追加赏金", res);
          if (res.data.status === 200) {
            initList();
            emit.emit("showToast", {
              text: "打赏成功",
              time: 3000
            });
          } else {
            if (res.data.msg.indexOf("余额不足") !== -1) {
              setTimeout(() => {
                emit.emit("changeAlert", {
                  _title: "温馨提示",
                  _content: "灰币余额不足，立即充值",
                  _submitText: "灰币充值",
                  _notDouble: true,
                  _cancal: () => {},
                  _submit: () => {
                    const stackKey = `user-member-${new Date().getTime()}`;
                    StackStore.dispatch({
                      type: "push",
                      payload: {
                        name: "user-member",
                        element: (
                          <StackPage
                            stackKey={stackKey}
                            key={stackKey}
                            style={{ zIndex: stacks.length + 2 }}
                          >
                            <MyMember stackKey={stackKey} type={1} />
                          </StackPage>
                        )
                      }
                    });
                  }
                });
              }, 300);
            }
            emit.emit("showToast", {
              text: res.data.msg,
              time: 3000
            });
          }
        });
      }
    });
  };
  return useMemo(
    () => (
      <div className="full-column append_page">
        <BackHead title="追加赏金列表" stackKey={stackKey} />
        {!loading && (
          <div className="add_total">
            共追加了{userList.reduce((sum, e) => sum + Number(e.coins), 0)}金币
          </div>
        )}
        {loading ? (
          <Loading show />
        ) : userList.length === 0 ? (
          <NoData />
        ) : (
          <div className="full-column">
            <ScrollArea ListData={userList}>
              <div className="user_list">
                {userList.map((item, index) => (
                  <div key={`user_item_i_${index}`} className="user_item">
                    <div className="flex_row">
                      <Avatar
                        boxClass="thumb"
                        size={1.1}
                        img={item.thumb}
                        uuid={item.from_uuid}
                        isCreater={Boolean(item.auth_status)}
                      />
                      <div>
                        <div className="nickname">{item.nickname}</div>
                        <div className="fans_number">
                          {item.followed_count}粉丝
                        </div>
                      </div>
                    </div>
                    <span className="coin_number">追加了{item.coins}金币</span>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </div>
        )}
        {!loading && (
          <ClickBtn onTap={addCoins} className="append_btn">
            追加赏金
          </ClickBtn>
        )}
      </div>
    ),
    [userList]
  );
};
