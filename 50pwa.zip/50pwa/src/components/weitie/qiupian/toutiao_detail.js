import React, { useEffect, useMemo, useRef, useState } from "react";
import BackHead from "../../backHeader";
import ScrollArea from "../../scrollarea";
import seeIcon from "../../../resources/img/public/icon_see_num.png";
import nozanIcon from "../../../resources/img/public/icon_like_tag.png";
import zanIcon from "../../../resources/img/public/icon_text_like_red.png";
import msgIcon from "../../../resources/img/public/icon_message_num.png";
import jubaoIcon from "../../../resources/img/public/icon_jubao_video.png";
import jubaoNormal from "../../../resources/img/public/jubao_normal.png";
import jubaoRed from "../../../resources/img/public/jubao_checked_red.png";
import write from "../../../resources/img/public/video_detail_send.png";
import Simg from "../../simg";
import Avatar from "../../avatar";
import ClickBtn from "../../clickBtn";
import global from "../../../libs/globalVar";
import emit from "../../../libs/eventEmitter";
import NoData from "../../noData";
import BottomSheet from "../../bottom_sheet";

import { SelectVideo, CommentCard } from "../qiupian/qiupian_card";
import UserStore from "../../../store/user";
import {
  getWeiDetail,
  followUp,
  praiseWei,
  getCommentList,
  replyComment,
  commentReplyList,
  reportTiezi
} from "../../../libs/http";
import Loading from "../../loading";
export default props => {
  const { stackKey, id } = props;
  const [showComment, setShowComment] = useState(false);
  const [commentDetail, setCommentDetail] = useState(null);
  const [cLoading, setCloading] = useState(true);
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [follow, setFollow] = useState(false);
  const [zan, setZan] = useState(false);
  const [commentList, setCommentList] = useState(null);
  const [chooseJubao, setChooseJubao] = useState(-1);
  const [showJubao, setShowJubao] = useState(false);
  const [showInput, setShowInput] = useState(false);
  const [userInfo] = UserStore.useGlobalState("user");
  const [toUuid, setToUuid] = useState("");
  const [page, setPage] = useState({
    num: 1
  });
  const [isAll, setIsAll] = useState(false);
  const getCommentDetail = () => {
    commentReplyList({
      wei_id: id,
      last_id:
        commentList && commentList.length > 0
          ? ""
          : commentList[commentList.length - 1].id,
      cid: global.conmentId
    }).then(res => {
      // console.log("评论详情", res);
    });
  };
  useEffect(() => {
    if (showComment) {
      getCommentDetail();
    }
  }, [showComment]);
  useEffect(() => {
    getWeiDetail({
      wei_id: id
    }).then(res => {
      // console.log("帖子详情", res);
      setData(res.data);
      setFollow(res.data.detail.member.is_follow);
      setZan(res.data.detail.is_like);
      setLoading(false);
    });
  }, []);
  useEffect(() => {
    getCommentList({
      wei_id: id,
      page: page.num
    }).then(res => {
      if (res.status === 200) {
        // console.log("评论列表", res);
        if (page.num === 1) {
          setCommentList(res.data);
        } else {
          setCommentList([...commentList, ...res.data]);
        }
        if (res.data.length === 0) {
          setIsAll(true);
        }
      }
    });
  }, [page]);
  const followeUser = async () => {
    const res = await followUp({ follow_uuid: data.detail.uuid });
    if (res.status === 200) {
      setFollow(!follow);
    } else {
      emit.emit("showToast", {
        text: res.msg,
        time: 3000
      });
    }
  };
  const jubaoItem = (text, index) => {
    return (
      <div
        className="video-detail-jubao-item"
        key={index}
        onClick={() => {
          setChooseJubao(index);
        }}
      >
        <img src={chooseJubao == index ? jubaoRed : jubaoNormal} />
        <span
          style={{
            color: chooseJubao == index ? "#f1bc8d" : "#878799"
          }}
        >
          {text}
        </span>
      </div>
    );
  };
  useEffect(() => {
    if (showJubao) {
      emit.emit("changeAlert", {
        _title: "举报推荐",
        _content: (
          <div className="video-detail-jubao">
            <p>若该视频包含以下内容，你可以在此举报</p>
            <div>
              {global.reportType.map((item, index) => {
                return jubaoItem(item, index);
              })}
            </div>
          </div>
        ),
        _submitText: "确定",
        _cancel: () => {
          setShowJubao(false);
        },
        _submit: () => {
          if (chooseJubao !== -1) {
            reportTiezi({
              wei_id: data.detail.id,
              content: global.reportType[chooseJubao]
            }).then(res => {
              if (res.status !== 200) {
                emit.emit("showToast", {
                  text: res.msg,
                  time: 3000
                });
              }
            });
          } else {
            emit.emit("showToast", {
              text: "请选择举报类型",
              time: 3000
            });
          }
          setShowJubao(false);
        },
        _notDouble: true
      });
    }
  }, [showJubao, chooseJubao]);
  const renderInput = () => {
    let inputValue = "";
    return (
      <div className="video-detail-input-layer">
        <ClickBtn
          className="video-detail-input-close"
          onTap={() => {
            setShowInput(false);
          }}
        />
        <div className="video-detail-input">
          <div className="input-box">
            <img src={write} />
            <input
              type="text"
              placeholder="优质评论优先展示"
              onChange={e => {
                inputValue = e.target.value;
              }}
              autoFocus
            />
          </div>
          <ClickBtn
            className="input-sub"
            onTap={() => {
              setShowInput(false);
              if (!inputValue) {
                emit.emit("showToast", {
                  text: "请输入评论内容～",
                  time: 3000
                });
                return;
              }
              replyComment({
                wei_id: data.id,
                comment: inputValue,
                cid: toUuid
              }).then(res => {
                if (res.data && res.data.status === 200) {
                  emit.emit("showToast", {
                    text: "评论成功",
                    time: 3000
                  });
                } else {
                  emit.emit("showToast", {
                    text: res.msg,
                    time: 3000
                  });
                }
              });
            }}
          >
            确定
          </ClickBtn>
        </div>
      </div>
    );
  };
  return useMemo(
    () => (
      <div className="full-column">
        <BackHead stackKey={stackKey} title="微头条" />
        <BottomSheet
          hideClose={true}
          show={showComment}
          setShow={setShowComment}
        >
          <div className="conment_head">
            <span></span>
            <span className="title">评论详情</span>
            <ClickBtn className="close" onTap={() => setShowComment(false)}>
              关闭
            </ClickBtn>
          </div>
          <div className="conment_detail_box">
            {cLoading ? (
              <Loading show={true} overSize={false} />
            ) : (
              <div>2131123</div>
            )}
          </div>
        </BottomSheet>
        {showInput && renderInput()}
        {loading ? (
          <Loading show overSize={false} />
        ) : (
          <div className="full-column">
            <ScrollArea
              ListData={commentList}
              onScrollEnd={() => {
                if (isAll) return;
                page.num = page.num + 1;
                setPage({ ...page });
              }}
              loadingMore={!isAll}
            >
              <div className="toutiao_detai">
                <div className="qp_card_box tt_card_box">
                  <div className="user_info_box">
                    <div className="flex_row">
                      <Avatar
                        boxClass="user_thumb"
                        img={data.detail.member.thumb}
                        size={1.08}
                        uuid={data.detail.uuid}
                        isCreater={Boolean(data.detail.member.auth_status)}
                      />
                      <div>
                        <p className="user_name one_line">
                          {data.detail.member.nickname}
                        </p>
                        <p className="xk_num">{data.detail.created_str}</p>
                      </div>
                    </div>
                    <ClickBtn
                      className={`gz_btn ${follow ? "ygz_btn" : ""}`}
                      onTap={followeUser}
                    >
                      {follow ? "已关注" : "关注"}
                    </ClickBtn>
                  </div>
                  <div className="qp_card_content">
                    <p
                      style={{
                        color: "#ffffff",
                        fontSize: "0.423rem",
                        lineHeight: "1.7"
                      }}
                      dangerouslySetInnerHTML={{
                        __html: data.detail.title.replaceAll("\n", "</br>")
                      }}
                    ></p>
                    <div className="detai_user_img_list">
                      {data.detail.imagesFull.map((item, index) => {
                        const contentW = 10 - 0.64;
                        const ismin =
                          item.width < contentW * global.bodyFontSize;
                        const imgW = ismin
                          ? item.width
                          : contentW * global.bodyFontSize;
                        const imgH = ismin
                          ? item.height
                          : (imgW / item.width) * item.height;
                        return (
                          <div
                            key={`detai_user_img_${index}`}
                            className="detai_user_img_item"
                            style={{
                              width: `${imgW / global.bodyFontSize}rem`,
                              height: `${imgH / global.bodyFontSize}rem`
                            }}
                          >
                            <Simg src={item.source} isZoom={true} />
                          </div>
                        );
                      })}
                    </div>
                  </div>
                  <div className="tt_card_fot_box">
                    <span className="tt_num_item">
                      <img src={seeIcon} />
                      <span>{data.detail.look}</span>
                    </span>
                    <ClickBtn
                      className="tt_num_item"
                      styles={{
                        color: zan ? "#fd5c18" : "#999999"
                      }}
                      onTap={() => {
                        praiseWei({
                          wei_id: data.detail.id,
                          type: zan ? "unset" : "set"
                        }).then(res => {
                          if (res.status === 200) {
                            data.detail.like = zan
                              ? data.detail.like - 1
                              : data.detail.like + 1;
                            setData({
                              ...data
                            });
                            setZan(!zan);
                            // console.log("赞", res);
                          }
                        });
                      }}
                    >
                      <img src={zan ? zanIcon : nozanIcon} />
                      <span>{data.detail.like}</span>
                    </ClickBtn>
                    <div className="tt_num_item">
                      <img src={msgIcon} />
                      <span>{data.detail.comment_number}</span>
                    </div>
                    <ClickBtn
                      className="tt_num_item"
                      onTap={() => {
                        setShowJubao(true);
                      }}
                    >
                      <img src={jubaoIcon} />
                    </ClickBtn>
                  </div>
                </div>
                {data.detail.mv_info && (
                  <div>
                    <div className="gl_title">关联作品</div>
                    {data.detail.mv_info.map((item, index) => (
                      <div key={`detail_video_${index}`}>
                        <SelectVideo
                          data={{
                            ...item,
                            nickname: data.detail.member.nickname
                          }}
                        />
                      </div>
                    ))}
                  </div>
                )}

                {!commentList ? (
                  <Loading show overSize={false} />
                ) : commentList.length > 0 ? (
                  <div>
                    <div className="pl_title">
                      评论 <span>{commentList.length}</span>
                    </div>
                    <div
                      className="flex_row"
                      style={{
                        margin: "0.53rem 0"
                      }}
                    >
                      <div className="my_thumb">
                        <Simg src={userInfo.thumb} />
                      </div>
                      <ClickBtn
                        className="my_input"
                        onTap={() => {
                          setToUuid("");
                          setShowInput(true);
                        }}
                      >
                        是不是你的最爱，快来说两句
                      </ClickBtn>
                    </div>
                    <div className="comment_list_box">
                      {commentList.map((item, index) => (
                        <CommentCard
                          key={`comment_item_${index}`}
                          data={item}
                          onFocus={uuid => {
                            // global.conmentId = uuid;
                            // setShowComment(true);
                            setToUuid(uuid);
                            setShowInput(true);
                          }}
                        />
                      ))}
                    </div>
                  </div>
                ) : (
                  <NoData />
                )}
              </div>
            </ScrollArea>
          </div>
        )}
      </div>
    ),
    [
      data,
      loading,
      follow,
      zan,
      isAll,
      showInput,
      toUuid,
      showComment,
      cLoading
    ]
  );
};
