import React, { useEffect, useMemo, useRef, useState } from "react";
import ClickBtn from "../clickBtn";
import { Swiper, SwiperSlide } from "swiper/react";
import Hammer from "hammerjs";
import StackStore from "../../store/stack";
import ScrollArea from "../scrollarea";
import Loading from "../loading";
import QiupianList from "./qiupian/qiupian_list";
import { getAdvertise } from "../../libs/http";
import Simg from "../simg";
export default props => {
  const [controlledSwiper, setControlledSwiper] = useState(null);
  const [currenTab, setTab] = useState(1);
  const [loading, setLoading] = useState(true);
  const contentRef = useRef(null);
  const listRef = useRef(null);
  const tabList = [
    {
      title: "最新",
      id: 1
    },
    {
      title: "最热",
      id: 2
    }
  ];
  useEffect(() => {
    if (!contentRef.current || !listRef.current) return;
    listRef.current.setAttribute(
      "style",
      `height:${contentRef.current.clientHeight}px`
    );
    setTimeout(() => {
      setLoading(false);
    }, 300);
  }, [contentRef.current, listRef.current]);
  return useMemo(
    () => (
      <div className="flex_column" ref={contentRef}>
        <ScrollArea groupId="weitie_list">
          <RenderSwiper />
          <div className="weitie_swiper_warp_box" ref={listRef}>
            <div
              className="weitie_tab"
              style={{
                padding: "0.32rem"
              }}
            >
              {tabList.map((item, index) => (
                <ClickBtn
                  className={`tab_item ${
                    currenTab === item.id ? "tab_item_active" : ""
                  }`}
                  key={`wt_tab_${index}`}
                  onTap={() => {
                    setTab(item.id);
                    controlledSwiper && controlledSwiper.slideTo(index);
                  }}
                >
                  {item.title}
                </ClickBtn>
              ))}
            </div>
            {loading ? (
              <Loading show overSize={false} size={30} />
            ) : (
              <div
                style={{
                  flex: "1",
                  overflow: "hidden"
                }}
              >
                <Swiper
                  className="wt_list_swiper"
                  loop={false}
                  controller={{ control: controlledSwiper }}
                  onSwiper={setControlledSwiper}
                  autoplay={false}
                  onSlideChange={e => {
                    setTab(tabList[e.realIndex].id);
                  }}
                >
                  <SwiperSlide>
                    <QiupianList
                      type="toutiao"
                      show={currenTab === 1}
                      filter="new"
                    />
                  </SwiperSlide>
                  <SwiperSlide>
                    <QiupianList
                      type="toutiao"
                      show={currenTab === 2}
                      filter="hot"
                    />
                  </SwiperSlide>
                </Swiper>
              </div>
            )}
          </div>
        </ScrollArea>
      </div>
    ),
    [currenTab, contentRef.current, listRef.current, controlledSwiper, loading]
  );
};
const RenderSwiper = props => {
  const [advList, setAdvList] = useState(null);
  useEffect(() => {
    getAdvertise({
      pos: "507"
    }).then(res => {
      // console.log("微头条广告", res);
      setAdvList(res.data);
    });
  }, []);
  return useMemo(
    () =>
      !advList ? (
        ""
      ) : (
        <Swiper
          pagination
          autoplay={{
            delay: 3000,
            disableOnInteraction: false
          }}
          className="weitie_gg_wiper"
        >
          {advList.map((item, index) => {
            return (
              <SwiperSlide key={index}>
                <SwiperItem item={item} />
              </SwiperSlide>
            );
          })}
        </Swiper>
      ),
    [advList]
  );
};
const SwiperItem = props => {
  const { item } = props;
  const itemRef = useRef(null);
  const [stacks] = StackStore.useGlobalState("stacks");
  const _width = document.body.clientWidth;
  useEffect(() => {
    if (!itemRef.current) {
      return;
    }
    const itemHammer = new Hammer(itemRef.current);
    itemHammer.on("tap", onClick);
    return () => {
      itemHammer.off("tap", onClick);
    };
  }, [itemRef.current]);
  const onClick = () => {
    window.open(item.url, "_blank");
    // if (!item.link) {
    //   return;
    // }
    // if (item.type == 4 || item.type == 5) {
    //   toWebView(item.link, "活动内容");
    // } else if (item.type == 2 || item.type == 3) {
    //   const { aff, uuid } = userInfo;
    //   toWebView(`${item.link}?aff=${aff}&chaid=${uuid}`, "活动内容");
    // } else if (item.link.indexOf("game") != -1) {
    //   // 内部
    //   Emit.emit("homeToPage", "ToGame");
    // }
  };
  return (
    <div
      style={{
        width: _width,
        height: _width * 0.35
      }}
      ref={itemRef}
    >
      <Simg src={item.img_url} />
    </div>
  );
};
