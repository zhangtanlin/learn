import React, { useEffect, useMemo, useRef, useState } from "react";
import StackStore from "../../store/stack";
import SearchHead from "../searchHeader";
import ClickBtn from "../clickBtn";
import { Swiper, SwiperSlide } from "swiper/react";
import "../../resources/css/weitie.less";
import QiutiePage from "./qiupian_page";
import ToutiaoPage from "./toutiao_page";
import BottomSheet from "../bottom_sheet";
import { FilterCard } from "./qiupian/qiupian_card";

export default props => {
  const { isVisible } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const [pageStatus, setPageStatus] = useState(0);
  const [controlledSwiper, setControlledSwiper] = useState(null);
  const [currenTab, setTab] = useState(1);
  const [newsSheetShow, setNewsSheetShow] = useState(false);
  const [hotSheetShow, setHotSheetShow] = useState(false);
  const [newFilter, setNewFilter] = useState({
    has_coins: "",
    is_match: ""
  });
  const [hotFilter, setHotFilter] = useState({
    has_coins: "",
    is_match: "",
    sort: "",
    date_range: ""
  });

  const tabList = [
    {
      title: "求片",
      id: 1
    },
    {
      title: "微头条",
      id: 2
    }
  ];
  useEffect(() => {
    if (isVisible && pageStatus === 0) {
      setPageStatus(2);
    }
  }, [isVisible]);
  return useMemo(
    () => (
      <div
        className={`positioned-container ${
          isVisible ? "visible" : "hide"
        } weitie_page`}
      >
        <BottomSheet
          direction="top"
          show={newsSheetShow}
          setShow={setNewsSheetShow}
        >
          <FilterCard
            type="new"
            filter={newFilter}
            setFilter={setNewFilter}
            onCancel={() => {
              setNewsSheetShow(false);
            }}
            onSubmit={() => {
              setNewsSheetShow(false);
            }}
          />
        </BottomSheet>
        <BottomSheet
          direction="top"
          show={hotSheetShow}
          setShow={setHotSheetShow}
        >
          <FilterCard
            type="hot"
            filter={hotFilter}
            setFilter={setHotFilter}
            onCancel={() => {
              setHotSheetShow(false);
            }}
            onSubmit={() => {
              setHotSheetShow(false);
            }}
          />
        </BottomSheet>
        <SearchHead
          center={() => {
            return (
              <div className="weitie_tab">
                {tabList.map((item, index) => (
                  <ClickBtn
                    className={`tab_item ${
                      currenTab === item.id ? "tab_item_active" : ""
                    }`}
                    key={`wt_tab_${index}`}
                    onTap={() => {
                      setTab(item.id);
                      controlledSwiper && controlledSwiper.slideTo(index);
                    }}
                  >
                    {item.title}
                  </ClickBtn>
                ))}
              </div>
            );
          }}
        />
        <div className="weitie_content">
          <Swiper
            className="swiper_flex_wrap"
            loop={false}
            controller={{ control: controlledSwiper }}
            onSwiper={setControlledSwiper}
            autoplay={false}
            onSlideChange={e => {
              setTab(tabList[e.realIndex].id);
            }}
          >
            <SwiperSlide>
              <QiutiePage
                filterNew={setNewsSheetShow}
                filterHot={setHotSheetShow}
                newFilter={newFilter}
                hotFilter={hotFilter}
              />
            </SwiperSlide>
            <SwiperSlide>
              <ToutiaoPage />
            </SwiperSlide>
          </Swiper>
        </div>
      </div>
    ),
    [isVisible, currenTab, controlledSwiper, newsSheetShow, hotSheetShow]
  );
};
