/*
 * @Author: Tom
 * @Date: 2021-10-20 21:53:29
 * @LastEditTime: 2022-01-20 10:03:52
 * @LastEditors: Tom
 * @Description:
 * @FilePath: /50pwa/src/components/videoPlayer.js
 */
import React, {
  useEffect,
  useRef,
  useMemo,
  useState,
  useLayoutEffect,
} from "react";
import "../resources/css/video.less";
import Simg from "./simg";
let tryTimes = 5;
export default (props) => {
  const newVideoRef = useRef(null);
  const boxRef = useRef(null);
  const sourceRef = useRef(null);
  const [loading, setLoading] = useState(true);
  const {
    src,
    isPlay = true,
    thumb,
    auto = false,
    durationChange,
    onPause,
    onErr,
    onEnd,
    videoRef = newVideoRef,
    hideControls,
  } = props;

  const setPlaying = () => {
    setLoading(false);
    durationChange && durationChange();
  };
  const videoErr = () => {
    if (tryTimes < 0 || tryTimes == 0) {
      return;
    }
    tryTimes--;
    videoRef.current.setAttribute("src", src);
    videoRef.current.load();
    // console.log("视频失败,再次加载", tryTimes);
  };
  useLayoutEffect(() => {
    videoRef.current.addEventListener("timeupdate", setPlaying, false);
    onPause && videoRef.current.addEventListener("onPause", onPause, false);
    videoErr && videoRef.current.addEventListener("error", videoErr, false);
    onEnd && videoRef.current.addEventListener("ended", onEnd, false);
    return () => {
      videoRef.current.removeEventListener("timeupdate", setPlaying);
      onPause && videoRef.current.removeEventListener("onPause", onPause);
      videoErr && videoRef.current.removeEventListener("error", videoErr);
      onEnd && videoRef.current.removeEventListener("ended", onEnd);
      videoRef.current.pause();
      videoRef.current.setAttribute("src", "");
      videoRef.current.load();
    };
  }, [videoRef.current]);

  useLayoutEffect(() => {
    tryTimes = 5;
    let _handler = (e) => {
      e.stopPropagation();
    };
    if (boxRef.current) {
      boxRef.current.addEventListener("touchmove", _handler);
    }
    return () => {
      if (boxRef.current) {
        boxRef.current.removeEventListener("touchmove", _handler);
      }
    };
  }, []);

  return useMemo(() => {
    return (
      <div ref={boxRef} className="web-video-box">
        {isPlay ? (
          <video
            ref={videoRef}
            controls={!hideControls}
            autoPlay
            poster={thumb}
            onLoadedMetadata={() => {
              // console.log("------m3u8加载完成-------");
              setLoading(false);
            }}
            src={src}
            playsInline
            webkit-playsinline="true"
          >
            {/* <source ref={sourceRef}  type="application/x-mpegURL" /> */}
          </video>
        ) : (
          ""
        )}
        {loading ? <div className="video_center_text">视频加载中...</div> : ""}
      </div>
    );
  }, [src, isPlay, loading]);
};
