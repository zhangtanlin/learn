import React, { useEffect, useRef, useState, useMemo } from "react";
import "../resources/css/captchaDialog.less";
import ClickBtn from "./clickBtn";

import { getVerifyImg } from "../libs/http";

export default props => {
  const { show, setCode, onClose } = props;
  const [codeImg, setCodeImg] = useState(null);
  const [loading, setLoading] = useState(true);
  const codeRef = useRef(null);
  const getcode = () => {
    getVerifyImg().then(res => {
      // console.log('res', res);
      if (res?.data?.verifyUrl) {
        setCodeImg(res?.data?.verifyUrl);
        setLoading(false);
      }
    });
  };
  useEffect(() => {
    if (show) {
      setLoading(true);
      getcode();
    } else {
      setCodeImg(null);
      if (codeRef.current && codeRef.current.value) {
        codeRef.current.value = "";
      }
    }
  }, [show]);
  return useMemo(
    () => (
      <div className={`captcha_hide_box ${show ? "captcha_show_box" : ""}`}>
        <ClickBtn
          className="close_box"
          onTap={() => {
            onClose && onClose(false);
          }}
        />
        <div className="captcha_content">
          <div className="title">图形验证码</div>
          {loading ? (
            <div className="code_loading">正在加载图形码...</div>
          ) : (
            <ClickBtn
              className="code_img"
              onTap={() => {
                setLoading(true);
                getcode();
              }}
            >
              <img src={codeImg} />
              <div className="code_img_btn">点击刷新</div>
            </ClickBtn>
          )}
          <div className="input_box">
            <input ref={codeRef} placeholder="请输入图形验证码" />
          </div>
          <ClickBtn
            className="submit_btn"
            onTap={() => {
              if (codeRef.current) {
                setCode(codeRef.current.value);
              }
            }}
          >
            确定
          </ClickBtn>
        </div>
      </div>
    ),
    [codeRef.current, show, onClose, loading, codeImg]
  );
};
