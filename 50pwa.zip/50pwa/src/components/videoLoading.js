import React, { useEffect, useRef, useMemo, useState } from "react";
import "../resources/css/videoLoading.less";
import a1 from "../resources/img/videoLoading/anim_a00.png";
import a2 from "../resources/img/videoLoading/anim_a01.png";
import a3 from "../resources/img/videoLoading/anim_a02.png";
import a4 from "../resources/img/videoLoading/anim_a03.png";
import a5 from "../resources/img/videoLoading/anim_a04.png";
import a6 from "../resources/img/videoLoading/anim_a05.png";
import a7 from "../resources/img/videoLoading/anim_a06.png";
import a8 from "../resources/img/videoLoading/anim_a07.png";
import a9 from "../resources/img/videoLoading/anim_a08.png";
import a10 from "../resources/img/videoLoading/anim_a09.png";
import a11 from "../resources/img/videoLoading/anim_a10.png";
import a12 from "../resources/img/videoLoading/anim_a11.png";
import a13 from "../resources/img/videoLoading/anim_a12.png";
import a14 from "../resources/img/videoLoading/anim_a13.png";
import a15 from "../resources/img/videoLoading/anim_a14.png";
import a16 from "../resources/img/videoLoading/anim_a15.png";
import a17 from "../resources/img/videoLoading/anim_a16.png";
import a18 from "../resources/img/videoLoading/anim_a17.png";
import a19 from "../resources/img/videoLoading/anim_a18.png";
import a20 from "../resources/img/videoLoading/anim_a19.png";
import a21 from "../resources/img/videoLoading/anim_a20.png";
import a22 from "../resources/img/videoLoading/anim_a21.png";
import a23 from "../resources/img/videoLoading/anim_a22.png";
import a24 from "../resources/img/videoLoading/anim_a23.png";
import a25 from "../resources/img/videoLoading/anim_a24.png";

const loading = [
  a1,
  a2,
  a3,
  a4,
  a5,
  a6,
  a7,
  a8,
  a9,
  a10,
  a11,
  a12,
  a13,
  a14,
  a15,
  a16,
  a17,
  a18,
  a19,
  a20,
  a21,
  a22,
  a23,
  a24,
  a25,
];
export default (props) => {
  useEffect(() => {
    let num = 0;
    let timer = setInterval(() => {
      document
        .getElementById("videoLoading-box")
        .setAttribute("style", `left:${num * -4}rem`);
      if (num < 24) {
        num++;
      } else {
        num = 0;
      }
    }, 30);
    return () => {
      clearInterval(timer);
    };
  }, []);
  return (
    <div className="videoLoading">
      <div>
        <div id="videoLoading-box">
          {loading.map((item, index) => {
            return <img key={index} src={item} />;
          })}
        </div>
      </div>
    </div>
  );
};
