import React, { useEffect, useRef, useState, useMemo } from "react";
import Simg from "./simg";
import global from "../libs/globalVar";
import ClickBtn from "./clickbtn";
import headImg from "../resources/img/public/notice_head.png";
import ScrollArea from "./scrollarea";
import StackStore from "../store/stack";
import StackPage from "./stackpage";
import App from "./user/app";

export default props => {
  const { show, title, content, onClose, type } = props;
  const codeRef = useRef(null);
  const [stacks] = StackStore.useGlobalState("stacks");
  useEffect(() => {}, [show]);
  return useMemo(
    () => (
      <div className={`captch_hide_box ${show ? "captch_show_box" : ""}`}>
        <ClickBtn
          className="close_box"
          onTap={() => {
            onClose && onClose(false);
          }}
        />
        {show && (
          <ClickBtn className="dialog_content">
            <img
              src={headImg}
              style={{
                width: "100%"
              }}
            />
            <div className="dialog_text_content">
              <div
                style={{
                  flex: "1",
                  overflow: "hidden",
                  display: "flex",
                  flexDirection: "column"
                }}
              >
                <ScrollArea>
                  <div
                    style={{
                      lineHeight: "1.7"
                    }}
                    dangerouslySetInnerHTML={{
                      __html: content.replaceAll("\n", "<br/>")
                    }}
                  ></div>
                </ScrollArea>
              </div>
              <div className="btn_box">
                <ClickBtn
                  className="submit_btn"
                  onTap={() => {
                    onClose && onClose(false);
                    const stackKey = `user-app-${new Date().getTime()}`;
                    StackStore.dispatch({
                      type: "push",
                      payload: {
                        name: "user-app",
                        element: (
                          <StackPage
                            stackKey={stackKey}
                            key={stackKey}
                            style={{ zIndex: stacks.length + 2 }}
                          >
                            <App stackKey={stackKey} />
                          </StackPage>
                        )
                      }
                    });
                  }}
                >
                  应用中心
                </ClickBtn>
              </div>
            </div>
          </ClickBtn>
        )}
      </div>
    ),
    [codeRef.current, show, onClose, content, title]
  );
};
