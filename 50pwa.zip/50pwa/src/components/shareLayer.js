import React, { useEffect, useMemo, useRef, useState } from "react";
import "../resources/css/everyday.less";
import Emit from "../libs/eventEmitter";
import closeIcon from "../resources/img/public/close_white.png";
import shareBorder from "../resources/img/public/share_border.png";
import playIcon from "../resources/img/public/play.png";
import shareDesc from "../resources/img/public/share_desc.png";
import Avatar from "./avatar";
import Simg from "./simg";
import globalVar from "../libs/globalVar";

export default (props) => {
  const { show, onTap, info } = props;
  let initY = 0;
  let moveY = 0;
  const _height = document.getElementById("app").clientHeight;
  const copyText = (text) => {
    // 数字没有 .length 不能执行selectText 需要转化成字符串
    const textString = text.toString();
    let input = document.querySelector("#copy-input");
    if (!input) {
      input = document.createElement("input");
      input.id = "copy-input";
      input.readOnly = "readOnly"; // 防止ios聚焦触发键盘事件
      input.style.position = "absolute";
      input.style.left = "-1000px";
      input.style.zIndex = "-1000";
      document.body.appendChild(input);
    }
    input.value = textString;
    // ios必须先选中文字且不支持 input.select();
    selectText(input, 0, textString.length);
    if (document.execCommand("copy")) {
      document.execCommand("copy");
    }
    input.blur();
    function selectText(textbox, startIndex, stopIndex) {
      if (textbox.createTextRange) {
        //ie
        const range = textbox.createTextRange();
        range.collapse(true);
        range.moveStart("character", startIndex); //起始光标
        range.moveEnd("character", stopIndex - startIndex); //结束光标
        range.select(); //不兼容苹果
      } else {
        //firefox/chrome
        textbox.setSelectionRange(startIndex, stopIndex);
        textbox.focus();
      }
    }
  };
  return (
    <div
      className={`yajian-layer ${
        show ? "yajian-layer-show" : "yajian-layer-hide"
      }`}
    >
      <div
        className={"yajian-layer-close"}
        onClick={() => {
          onTap(false);
        }}
      />
      {!!info && (
        <div
          className={"yajian-layer-body"}
          onTouchStart={(e) => {
            initY = e.touches[0].pageY;
          }}
          onTouchEnd={() => {
            if (Math.abs(moveY) > _height * 0.2) {
              onTap(false);
              setTimeout(() => {
                document
                  .getElementsByClassName("yajian-layer-body")[0]
                  .setAttribute("style", "display:flex");
              }, 300);
            } else {
              document
                .getElementsByClassName("yajian-layer-body")[0]
                .setAttribute(
                  "style",
                  `transform: translateY(0px);transition: all 0.2s ease-in;`
                );
            }
          }}
          onTouchMove={(e) => {
            let y = e.touches[0].pageY;
            if (y - initY > 0) {
              moveY = y - initY;
              document
                .getElementsByClassName("yajian-layer-body")[0]
                .setAttribute("style", `transform: translateY(${moveY}px);`);
            }
          }}
        >
          {/* <div className="layer-close">
          <img src={closeIcon} />
        </div> */}
          <div className="layer-header">
            <div className="layer-avatar">
              <Simg src={info.member.thumb} alwaysShow/>
            </div>
            <div>
              <div className="layer-name">
                <span>{info.member.nickname}</span>
                {info.member.auth_status && <span>原创大人</span>}
              </div>
              <p className="layer-title">{info.title}</p>
            </div>
          </div>
          <div className="layer-cover">
            <div className="layer-cover-img">
              <Simg src={info.thumb_cover} alwaysShow/>
            </div>
            <img className="layer-border" src={shareBorder} />
            <img className="layer-border2" src={shareBorder} />
            <div>
              <img src={playIcon} />
            </div>
          </div>
          <img className="layer-share-desc" src={shareDesc} />
          <div className="layer-btnBox">
            <div
              onClick={() => {
                copyText(globalVar.aff_url_copy);
                Emit.emit("showToast", { text: "复制成功，快去分享吧" });
              }}
            >
              复制分享链接
            </div>
            <div
              onClick={() => {
                Emit.emit("showToast", { text: "请在本页面截图保存图片" });
              }}
            >
              保存图片分享
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
