import React, { useEffect, useRef, useState } from "react";
import noData from "../resources/img/public/noData.webp";
import "../resources/css/noData.less";

export default (props) => {
  const { text, guideText } = props;
  return (
    <div className={"noData"}>
      <img src={noData} />
      <span>{text || "什么都没有，好空虚啊"}</span>
      {guideText && guideText()}
    </div>
  );
};
