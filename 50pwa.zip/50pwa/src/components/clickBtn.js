/*
 * @Author: Tom
 * @Date: 2021-08-11 19:50:48
 * @LastEditTime: 2022-01-20 09:58:51
 * @LastEditors: Tom
 * @Description:
 * @FilePath: /50pwa/src/components/clickBtn.js
 */
import React, { useEffect, useRef } from "react";
export default (props) => {
  const { onTap, children, className, styles } = props;
  // const clickRef = useRef(null);
  // const setCurrenLine = e => {
  //   if (!global.hammer) {
  //     global.hammer = "hammer";
  //     onTap && onTap();
  //     setTimeout(() => {
  //       global.hammer = null;
  //     }, 300);
  //   }
  // };
  // useEffect(() => {
  //   if (!clickRef.current) return;
  //   const hammer = new Hammer(clickRef.current);
  //   hammer.on("tap", setCurrenLine);
  //   return () => {
  //     hammer.off("tap", setCurrenLine);
  //   };
  // }, [clickRef.current, onTap]);
  // let current_date = 0;
  // let clickStatus = true;
  return (
    <div
      className={`${className}`}
      style={styles}
      // onTouchStart={(e) => {
      //   e.stopPropagation();
      //   clickStatus = true;
      //   current_date = new Date().getTime();
      // }}
      // onTouchMove={() => {
      //   clickStatus = false;
      // }}
      // onTouchEnd={(e) => {
      //   e.stopPropagation();
      //   if (new Date().getTime() - current_date < 300 && clickStatus) {
      //     onTap && onTap();
      //   }
      // }}
      onClick={()=>{
        onTap && onTap();
      }}
    >
      {children}
    </div>
  );
};
