import React, { useEffect, useMemo, useRef, useState } from "react";
import { getMsgindex } from "../../libs/http";
import BackHeader from "../backHeader";
import Loading from "../loading";
import NoData from "../noData";
import Scrollarea from "../scrollarea";

export default (props) => {
    const { stackKey, type } = props
    const [pageData, setPageData] = useState([]);
    const [isLoading, setLoading] = useState(true);
    let page = 1;

    useEffect(() => {
        init()
    }, [])

    const init = () => {
        getMsgindex({ type: type }).then((res) => {
            let result = res.data;
            console.log("messge:", result)
            setPageData(result.items);
            setLoading(false)
        })
    }

    const getMore = () => {
        getMsgindex({ type: type, page: page }).then((res) => {
            let result = res.data;
            if (result.item.length == 0) result
            setPageData(prev => [...prev, ...result.items]);
        })
    }

    const renderTitle = () => {
        switch (type) {
            case 1:
                return "点赞"
            case 2:
                return "粉丝"
            case 3:
                return "系统消息"
            case 4:
                return "评论"
            default:
                break;
        }
    }

    return (
        <div className='positioned-container message-detail'>
            <BackHeader
                stackKey={stackKey}
                title={renderTitle()}
            />
            {isLoading ? <Loading show type={1} /> : pageData.length > 0 ?
                <Scrollarea
                noEndText
                    pullDonRefresh={() => {
                        init();
                    }}
                    ListData={pageData}
                    onScrollEnd={() => {
                        page++;
                        getMore()
                    }}>
                    {pageData.map((item, index) => <RenderItem key={index} item={item} index={index} />)}
                    <div style={{ height: '1rem' }}></div>
                </Scrollarea> : <NoData />}
        </div>
    )
}

const RenderItem = (props) => {
    const { type, item, index } = props;
    return (
        <div key={`${index}_${item.id}`} className="message-item">
            <div className="content"><span>@{item.nickname}</span> {item.description} </div>
            <div className="time">{item.createdStr}</div>
        </div>
    )
}