import React, {useState, useEffect} from "react";
import {Swiper, SwiperSlide} from "swiper/react";
import "swiper/swiper.min.css";
import "swiper/components/pagination/pagination.min.css";
import "../../resources/css/hot.less";
import NoData from "../noData";
import StackPage from "../stackpage";
import Clickbtn from '../clickbtn'
import StackStore from "../../store/stack";
import Loading from '../loading'
import City from '../hot/city'
import Friend from './friend'
import Message from "./message";
import Addfriend from './addfriend';
import Emit from "../../libs/eventEmitter";
import locationIcon from '../../resources/img/new_version/community/location_white.png';
import AddFriendIcon from '../../resources/img/new_version/add_friend.png';

export default (props) => {
  const {isVisible} = props;
  const [init, setInit] = useState(false)
  const [tabIndex, setTabIndex] = useState(0);
  const [controlledSwiper, setControlledSwiper] = useState(null);
  const [stacks] = StackStore.useGlobalState("stacks");
  const [cityValue, setCityValue] = useState({name: "全国"})

  useEffect(() => {
    if (isVisible && !init) {
      setInit(true)
    }
  }, [isVisible])

  const tabs = [
    {name: "同城", id: 1},
    {name: "消息", id: 2},
    {name: "好友", id: 3},
  ];

  const getSelect = (select) => {
    setTabIndex(select.index);
    controlledSwiper.slideTo(select.index);
  };

  useEffect(() => {
    Emit.on("choosePicker", (res) => {
      setCityValue(res)
    })
    return () => {
      Emit.off("choosePicker")
    }
  }, [])

  const handleCityPicker = () => {
    Emit.emit("showPicker")
  }

  return (
    <div
      className={`positioned-container ${isVisible ? "visible" : "hide"} hot-body`}
      style={{
        opacity: isVisible ? "1" : "0",
        zIndex: isVisible ? 1 : -1
      }}
    >
      {init ? <>
        <div className="tabs-header-container">
          <div className="friend-tabs" style={{flex: 1}}>
            <Tabsbar onChange={getSelect} arr={tabs} current={tabIndex}/>

          </div>
          {tabIndex == 0 && (
            <div className="city-header-picker-container city-index">
              <Clickbtn onTap={() => handleCityPicker()} className={"city-header-picker-value"}>
                <img src={locationIcon}/>
                <div>{cityValue.name}</div>
              </Clickbtn>
            </div>
          )}
          {tabIndex == 2 && (
            <div className="friend-add" onClick={() => {
              const stackKey = `kefuDetail-${new Date().getTime()}`;
              StackStore.dispatch({
                type: "push",
                payload: {
                  name: "kefuDetail",
                  element: (
                    <StackPage
                      stackKey={stackKey}
                      key={stackKey}
                      style={{zIndex: stacks.length + 2}}
                    >
                      <Addfriend stackKey={stackKey}/>
                    </StackPage>
                  ),
                },
              });
            }}>
              <img src={AddFriendIcon}/>
            </div>
          )}
        </div>
        <Swiper
          initialSlide={0}
          className={"featured-swiper"}
          noSwipingClass={"noSwiper-container"}
          controller={controlledSwiper}
          onSwiper={setControlledSwiper}
          onSlideChange={(e) => {
            setTabIndex(e.activeIndex);
          }}
        >
          {tabs.map((item, index) => {
            switch (index) {
              case 0:
                return <SwiperSlide key={`${item.name}-${index}`}><City name={item.name} index={index}
                                                                        current={tabIndex}
                                                                        show={isVisible}/></SwiperSlide>
              case 1:
                return <SwiperSlide key={`${item.name}-${index}`}><Message isVisible={tabIndex == index}/></SwiperSlide>
              case 2:
                return <SwiperSlide key={`${item.name}-${index}`}><Friend name={item.name} index={index}
                                                                          current={tabIndex}
                                                                          show={isVisible}/></SwiperSlide>
              default:
                return <div></div>;
            }
          })}
        </Swiper>
      </> : <Loading/>}
    </div>
  );
};

const Tabsbar = (props) => {
  const {arr, onChange, current} = props

  const select = (item, index) => {
    onChange({value: item, index});
  }

  return <div className={'city_tabs_bar_container'}>
    <div className={'city_tabs_item'}>
      {Array.isArray(arr) &&
        arr.map((item, index) => (
          <div
            key={index}
            className={index === current ? 'active' : 'unactive'}
            onClick={() => select(item, index)}
          >
            {item.name}
          </div>
        ))
      }
    </div>
  </div>
}
