import React, { useEffect, useMemo, useRef, useState } from "react";
import Simg from '../simg'
import Loading from '../loading'
import ScrollArea from '../scrollarea'
import NoData from '../noData'
import Clickbtn from '../clickbtn'
import BackHeader from '../backHeader'
import Emit from "../../libs/eventEmitter";
import StackPage from "../stackpage";
import StackStore from "../../store/stack";
import { getUser, addFriend } from '../../libs/http';
import "../../resources/css/citys.less";
import levelIcon from '../../resources/img/new_version/community/level.png';
import girlIcon from '../../resources/img/new_version/girl_bg.png'
import boyIcon from '../../resources/img/new_version/boy_bg.png'
import UserStore from "../../store/user";
import Chat from "../message/chat";
import globalVar from "../../libs/globalVar";

export default (props) => {
    const { stackKey } = props;
    const [loadingPage, setLoadingPage] = useState(false)
    const [list, setList] = useState(null)
    const [stacks] = StackStore.useGlobalState("stacks");
    const [user] = UserStore.useGlobalState("user");
    const [flag, setFlag] = useState("");
    const [isFriend, setIsFriend] = useState(false);

    const getListData = (aff) => {
        getUser({ flag: aff }).then((res) => {
            console.log(res)
            let result = res.data;
            if (result?.success) {
                setList(result?.list ?? null)
                if(result.list.is_friend){
                    setIsFriend(true)
                }
            } else {
                Emit.emit("showToast", {
                    text: "该用户不存在",
                    time: 3000
                });
            }
            setLoadingPage(false)
        })
    }

    const onSubmit = () => {
        if (!flag) {
            Emit.emit("showToast", {
                text: "请输入91号",
                time: 3000
            });
        } else {
            setLoadingPage(true)
            getListData(flag)
        }

    }

    const onAddFriend = () => {
        addFriend({ uuid: list.uuid }).then((res) => {
            if (res.data.success) {
                setIsFriend(true)
                Emit.emit("refreshFirend")
            }
            Emit.emit("showToast", {
                text: res.msg,
                time: 3000
            });
        })
    }

    const onChat = () => {
        console.log(list)
        if(globalVar.canUseIm){
            let data = {
                friend_uuid: list.uuid,
                id: list.id,
                nickname: list.nickname
              }
              const stackKey = `kefuDetail-${new Date().getTime()}`;
              StackStore.dispatch({
                type: "push",
                payload: {
                  name: "kefuDetail",
                  element: (
                    <StackPage
                      stackKey={stackKey}
                      key={stackKey}
                      style={{ zIndex: stacks.length + 2 }}
                    >
                      <Chat stackKey={stackKey} user={data} />
                    </StackPage>
                  ),
                },
              });
        }else{
            Emit.emit("showToast", {
                text: "只有年卡用户才能使用私聊功能",
                time: 3000
            });
        }
        
    }

    return (
        <div className={"positioned-container background140 add-friend"}>
            <BackHeader
                stackKey={stackKey}
                title={"添加好友"}
            />
            <div className="add-friend-container">
                <input placeholder="输入91号" value={flag} onChange={({ target }) => {
                    setFlag(target.value)
                }} />
                <div className="search" onClick={() => { onSubmit() }}>搜索</div>
            </div>
            <div className="my-91-number">我的91号：{user.aff_num ?? '状态异常，请重新登录'}</div>
            {loadingPage ? <Loading show text={"正在获取数据..."} overSize={false} size={25} /> :
                <ScrollArea
                    ListData={list}
                >
                    <div>
                        {list != null && (
                            (
                                <div className="friend-item-container" >
                                    <div className="avatar"><Simg src={list.thumb} /></div>
                                    <div className="information">
                                        <div className="nickname">{list.nickname}</div>
                                        <div className="base">
                                            {list.is_vip && <div className="icon"><img src={levelIcon} /><span>{list.vip_level}</span></div>}
                                        </div>
                                    </div>
                                    {isFriend ? (<div onClick={() => {
                                        onChat()
                                    }} className="action">私聊</div>) : (<div onClick={() => {
                                        onAddFriend()
                                    }} className="action">添加好友</div>)}
                                </div>
                            )
                        )}
                    </div>
                    <div style={{ height: "5rem" }}></div>
                </ScrollArea>
            }
        </div>
    )
}

