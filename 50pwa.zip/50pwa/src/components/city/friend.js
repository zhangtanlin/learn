import React, { useEffect, useMemo, useRef, useState } from "react";
import Simg from '../simg'
import Loading from '../loading'
import ScrollArea from '../scrollarea'
import NoData from '../noData'
import Clickbtn from '../clickbtn'
import Emit from "../../libs/eventEmitter";
import StackPage from "../stackpage";
import StackStore from "../../store/stack";
import { getFriends } from '../../libs/http';
import "../../resources/css/citys.less";
import levelIcon from '../../resources/img/new_version/community/level.png';
import girlIcon from '../../resources/img/new_version/girl_bg.png'
import boyIcon from '../../resources/img/new_version/boy_bg.png'
import Chat from "../message/chat";
import globalVar from "../../libs/globalVar";

export default (props) => {
    const { index, current, show } = props;
    const [loadingPage, setLoadingPage] = useState(true)
    const [stacks] = StackStore.useGlobalState("stacks");
    const [list, setList] = useState([{}, {}, {}])
    const [loadingMore, setLoadingMore] = useState({ a: false })
    let page = 1;
    useEffect(() => {
        if (index == current && show) {
            getListData()
        }
    }, [index, current])

    useEffect(() => {
        Emit.on('refreshFirend', () => {
            getListData()
        })
    }, [])

    const getListData = () => {
        getFriends().then((res) => {
            let result = res.data;
            if (result.length < 10) {
                loadingMore.a = false;
                setLoadingMore({ ...loadingMore });
            }
            setList(result)
            setLoadingPage(false)
        })
    }

    const onGetMoreData = () => {
        if (!loadingMore.a) return;
        getFriends({ page: page++ }).then((res) => {
            let result = res.data;
            if (result.length < 10) {
                loadingMore.a = false;
                setLoadingMore({ ...loadingMore });
            }
            setList(prev => [...prev, ...result])
            setLoadingPage(false)
        })
    }

    const handleChat = (item) => {
        console.log(item)
        if (globalVar.canUseIm) {
            const stackKey = `chat-${new Date().getTime()}`;
            StackStore.dispatch({
                type: "push",
                payload: {
                    name: "chat",
                    element: (
                        <StackPage
                            stackKey={stackKey}
                            key={stackKey}
                            style={{ zIndex: stacks.length + 2 }}
                        >
                            <Chat stackKey={stackKey} user={item} />
                        </StackPage>
                    ),
                },
            });
        } else {
            Emit.emit("showToast", {
                text: "只有年卡用户才能使用私聊功能",
                time: 3000
            });
        }
    }

    return (
        <div className={"featured-swiper-item"}>
            {loadingPage ? <Loading show text={"正在获取数据..."} overSize={false} size={25} /> :
                <ScrollArea
                    ListData={list}
                    onScrollEnd={onGetMoreData}
                    loadingMore={loadingMore.a}
                    moreTextFalse={"没有更多好友了"}
                    pullDonRefresh={() => {
                        page = 1;
                        loadingMore.a = true;
                        setList([]);
                        setLoadingPage(true);
                        setLoadingMore({ ...loadingMore });
                        getListData();
                    }}
                >
                    <div>
                        {list.map((item, index) => {
                            return (
                                <div className="friend-item-container" key={index} onClick={() => {
                                    handleChat(item)
                                }}>
                                    <div className="avatar"><Simg src={item.thumb} /></div>
                                    <div className="information">
                                        <div className="nickname">{item.nickname}</div>
                                        <div className="base">
                                            <div className="icon"><img src={levelIcon} /><span>{item.level}</span></div>
                                            {item.sexType > 0 && <div className="sex"><img src={item.sexType == 1 ? boyIcon : girlIcon} /><span>{item.age}</span></div>}
                                        </div>
                                    </div>
                                </div>
                            )
                        })}
                    </div>
                    <div style={{ height: "5rem" }}></div>
                </ScrollArea>
            }
        </div>
    )
}

