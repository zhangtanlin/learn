/*
 * @Author: Tom
 * @Date: 2021-12-22 14:04:07
 * @LastEditTime: 2021-12-22 14:47:58
 * @LastEditors: Tom
 * @Description:
 * @FilePath: /91pornpwa/src/components/message/index.js
 */
import React, { useEffect, useMemo, useRef, useState } from "react";
import StackStore from "../../store/stack";
import "../../resources/css/message.less";
import logoIcon from "../../resources/img/message/kefuIcon.png";
import guanfangIcon from "../../resources/img/message/icon_guanfang_tag.png";
import KefuDetail from "../message/kefuDetail";
import Clickbtn from "../clickbtn";
import StackPage from "../stackpage";
import Loading from '../loading';

import { getMsgindex } from '../../libs/http';

import likeIcon from '../../resources/img/new_version/likes_notice.png';
import commentIcon from '../../resources/img/new_version/comment_notice.png';
import fansIcon from '../../resources/img/new_version/fans_notice.png';
import officeIcon from '../../resources/img/new_version/office_icon.png';
import systemmsg from '../../resources/img/message/systemmsg.png';
import Simg from "../simg";
import { ChatService } from "../../libs/storage_service/chat_service";
import Scrollarea from "../scrollarea";
import UserStore from "../../store/user";
import Emit from "../../libs/eventEmitter";
import Chat from "../message/chat";
import Msgdetail from "./msgdetail";
import { Dialog, SwipeAction } from "antd-mobile";
import globalVar from "../../libs/globalVar";

const servers = new ChatService();

export default (props) => {
  const { isVisible } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const [init, setInit] = useState(false)
  const [pageData, setPageData] = useState(null);
  const [userinfo] = UserStore.useGlobalState("user");
  const [contactList, setContactList] = useState([]);
  const [sysNotice, setSysnotice] = useState(null);
  const [dots, setDots] = useState({ fans: false, like: false, comment: false })

  useEffect(async () => {
    updateUserContact()
    Emit.on("updateContactList", () => {
      updateUserContact()
    })
    return () => {
      Emit.off("updateContactList")
    }
  }, [])

  const updateUserContact = async () => {
    let contact = await servers.getUserContact(userinfo.uuid);
    if (contact.length > 0) {
      setContactList(contact)
    }
  }


  const renderItem = () => {
    return (
      <Clickbtn
        className="message_item"
        onTap={() => {
          const stackKey = `kefuDetail-${new Date().getTime()}`;
          StackStore.dispatch({
            type: "push",
            payload: {
              name: "kefuDetail",
              element: (
                <StackPage
                  stackKey={stackKey}
                  key={stackKey}
                  style={{ zIndex: stacks.length + 2 }}
                >
                  <KefuDetail stackKey={stackKey} />
                </StackPage>
              ),
            },
          });
        }}
      >
        <div className="message_item_avatar">
          <img src={logoIcon} />
          <img src={guanfangIcon} />
        </div>
        <div className="message_desc">
          <p>在线客服</p>
          <span>{pageData?.online?.description}</span>
        </div>
      </Clickbtn>
    );
  };



  useEffect(() => {
    if (isVisible && !init) {
      setInit(true)
    }
  }, [isVisible])

  useEffect(() => {
    if (init) {
      getMsgindex({ type: 0 }).then((res) => {
        const result = res.data;
        setPageData(result);
        const sys = result.items.filter((item) => item.type == 3);
        if (sys.length > 0) {
          setSysnotice(sys[0])
        }
        const fans = result.items.filter((item) => item.type == 2);
        const like = result.items.filter((item) => item.type == 1);
        const comment = result.items.filter((item) => item.type == 4);
        const dotsStatus = { fans: fans.length > 0, like: like.length > 0, comment: comment.length > 0 }
        setDots(dotsStatus)
      })
    }
  }, [init])

  const handleMessages = (type) => {
    const stackKey = `kefuDetail-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "kefuDetail",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <Msgdetail stackKey={stackKey} type={type} />
          </StackPage>
        ),
      },
    });
  }

  return (
    <div
      className={`positioned-container message_container ${isVisible ? "visible" : "hide"
        }`}
      style={{
        opacity: isVisible ? "1" : "0",
      }}
    >
      <div className="message-header-container">
        <Clickbtn onTap={() => {
          handleMessages(2)
          setDots(prev => ({ ...prev, fans: false }))
        }} className="item-icon">
          <img src={fansIcon} />
          {dots.fans && <div className="dots"></div>}
        </Clickbtn>
        <Clickbtn onTap={() => {
          handleMessages(1)
          setDots(prev => ({ ...prev, like: false }))
        }} className="item-icon">
          <img src={likeIcon} />
          {dots.like && <div className="dots"></div>}
        </Clickbtn>
        <Clickbtn onTap={() => {
          handleMessages(4)
          setDots(prev => ({ ...prev, comment: false }))
        }} className="item-icon">
          <img src={commentIcon} />
          {dots.comment && <div className="dots"></div>}
        </Clickbtn>
      </div>
      <Scrollarea ListData={contactList}
        pullDonRefresh={() => {
          getMsgindex({ type: 0 }).then((res) => {
            console.log(res)
            let result = res.data;
            setPageData(result);
          })
        }}>
        {init ? renderItem() : <Loading />}
        {sysNotice && <RenderSysNotice notice={sysNotice} />}
        <div className="noSwiper-container">
          {contactList.map((item, index) => <RenderContact key={index} item={item} index={index} />)}
        </div>
      </Scrollarea>
    </div>
  );
};

const RenderSysNotice = (props) => {
  const { notice } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const handleNotice = () => {
    const stackKey = `kefuDetail-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "kefuDetail",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <Msgdetail stackKey={stackKey} type={3} />
          </StackPage>
        ),
      },
    });
  }
  return (
    <Clickbtn onTap={() => { handleNotice() }} className="message_item">
      <div className="message_item_avatar"><img src={systemmsg} /></div>
      <div className="message_desc">
        <p>系统公告</p>
        <span>{notice.description}</span>
      </div>
    </Clickbtn>
  )
}

const RenderContact = (props) => {
  const { item, index } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const [userinfo] = UserStore.useGlobalState("user");

  const handleChat = () => {
    if (globalVar.canUseIm) {
      let data = {
        friend_uuid: item.chatUuid,
        id: item.imDataId,
        nickname: item.chatName
      }

      const stackKey = `kefuDetail-${new Date().getTime()}`;
      StackStore.dispatch({
        type: "push",
        payload: {
          name: "kefuDetail",
          element: (
            <StackPage
              stackKey={stackKey}
              key={stackKey}
              style={{ zIndex: stacks.length + 2 }}
            >
              <Chat stackKey={stackKey} user={data} />
            </StackPage>
          ),
        },
      });
    } else {
      Emit.emit("showToast", {
        text: "只有年卡用户才能使用私聊功能",
        time: 3000
      });
    }
  }

  return useMemo(() => (
    <SwipeAction
      key={index}
      style={{ backgroundColor: "unset", width: "100%" }}
      rightActions={[
        {
          key: 'delete',
          text: '删除',
          color: 'danger',
          onClick: () => {
            Dialog.confirm({
              content: '是否删除该消息？',
              onConfirm: async () => {
                await servers.removeContact(item.chatUuid, userinfo.uuid)
                Emit.emit("updateContactList")
              },
            })
          }
        },
        {
          key: 'clear',
          text: '清空',
          color: 'rgb(31,1,58)',
          onClick: () => {
            Dialog.confirm({
              content: '是否清空聊天记录？',
              onConfirm: async () => {
                await servers.removeConversation(item.chatUuid, userinfo.uuid)
                await servers.updateLastContent(item.chatUuid)
                Emit.emit("updateContactList")
              },
            })
          }
        },
      ]} ><Clickbtn
        key={`${index}-${item.lastTime}`}
        className="message_item"
        onTap={() => {
          handleChat()
        }}
      >
        <div className="message_item_avatar">
          {item.chatThumb ? <Simg className="office-avatar" src={item.chatThumb} /> : <img src={logoIcon} />}
        </div>
        <div className="message_desc">
          <p>{item.chatName}</p>
          <span>{item.lastMsgType == "photos" ? "[图片]" : item.lastMsgContent}</span>
        </div>
        {item.unReadMsgNum > 0 && <div className="red-dot"></div>}
      </Clickbtn></SwipeAction>
  ), [item,index])
};