import React, { useEffect, useMemo, useRef } from "react";
import StartGame from "../game/startgame";
import StackPage from "../stackpage";
import StackStore from "../../store/stack";
import Hammer from "hammerjs";
import { enterGame } from "../../libs/http";
import Simg from "../../components/simg";
import globalVar from '../../libs/globalVar';
import BindPhone from '../user/bandPhone'

export default props => {
  const { data } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const gameRef = useRef(null);
  const _onGame = () => {
    if (!globalVar.isBindMobile) {
      const stackKey = `BindPhone-${new Date().getTime()}`;
      StackStore.dispatch({
        type: "push",
        payload: {
          name: "bindPhone",
          element: (
            <StackPage
              stackKey={stackKey}
              key={stackKey}
              style={{ zIndex: stacks.length + 2 }}
            >
              <BindPhone stackKey={stackKey} />
            </StackPage>
          ),
        },
      });
    } else {
      enterGame({ id: data.id }).then(res => {
        const stackKey = `recharge-${new Date().getTime()}`;
        StackStore.dispatch({
          type: "push",
          payload: {
            name: "recharge",
            element: (
              <StackPage
                stackKey={stackKey}
                key={stackKey}
                style={{ zIndex: stacks.length + 2 }}
              >
                <StartGame stackKey={stackKey} url={res.data.url} />
              </StackPage>
            )
          }
        });
      });
    }
  };
  useEffect(() => {
    const gameHammer = new Hammer(gameRef.current);
    gameHammer.on("tap", _onGame);
    return () => {
      gameHammer.off("tap", _onGame);
    };
  }, [gameRef.current]);
  return (
    <div className="game-item" ref={gameRef}>
      <div className="game-img">
        <Simg src={data.icons} />
      </div>
      <div className="game-item-title">
        <span>{data.name}</span>
        <div className="game-start">马上开始</div>
      </div>
    </div>
  );
};
