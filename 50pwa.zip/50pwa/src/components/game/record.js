import React, { useEffect, useMemo, useRef, useState } from "react";
import BackHeader from "../../components/backHeader";
import ScrollArea from "../scrollarea";
import "../../resources/css/game.less";
import TimeIcon from "../../resources/img/game/time.png";
import SuccessIcon from "../../resources/img/game/success.png";
import { getGemeOrder, getWithdrawList } from "../../libs/http";
import NoData from "../../components/noData";
import Loading from "../../components/loading";
export default props => {
  const { type, stackKey } = props;
  const [oderList, setOderList] = useState([]);
  const [page, setPage] = useState(1);
  const [isAll, setAll] = useState(false);
  const [loading, setLoading] = useState(true);
  let listPage = 1;
  const styles = {
    recordItem: {
      border: "#d9d9d9 solid 1px",
      borderRadius: "0.266rem",
      padding: "0.4rem",
      backgroundColor: "#fafafa",
      marginBottom: "0.4rem"
    },
    flexRowBtw: {
      display: "flex",
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "space-between"
    },
    flexRow: {
      display: "flex",
      flexDirection: "row",
      alignItems: "center"
    },
    borderBox: {
      paddingBottom: "0.32rem",
      marginBottom: "0.32rem",
      borderBottom: "#e6e6e6 solid 1px"
    },
    text1: {
      color: "#333",
      fontSize: "0.373rem"
    },
    text2: {
      color: "#666666",
      fontSize: "0.32rem"
    },
    text3: {
      fontSize: "0.266rem",
      color: "#999999"
    },
    icon: {
      width: "0.32rem",
      height: "0.32rem",
      marginRight: "0.133rem"
    }
  };
  const getColor = status => {
    switch (status) {
      case 0:
        return "#0bc10f";
        break;
      case 2:
        return "#f34751";
        break;
      case 3:
        return "#999999";
        break;
      default:
        return "#999999";
    }
  };
  const getStatusText = status => {
    switch (status) {
      case 0:
        return "审核中";
        break;
      case 1:
        return "已完成";
        break;
      case 3:
        return "通过，回调中";
      default:
        return "未通过";
    }
  };
  const getPageData = async () => {
    if (isAll) return;
    let res;
    if (type == 0) {
      res = await getGemeOrder({
        page
      });
    } else {
      res = await getWithdrawList({
        page
      });
    }
    console.log(res)
    let newdata;
    if (page === 1) {
      newdata = res.data.list;
      setOderList([...newdata]);
      setLoading(false);
    } else {
      newdata = oderList.concat(res.data.list);
      setOderList([...newdata]);
    }
    if (res.data && res.data.list?.length === 0) {
      setAll(true);
    }
  };
  useEffect(() => {
    listPage = page;
    getPageData();
  }, [page]);
  return useMemo(
    () => (
      <div className="full-column" style={{ width: "100%" }}>
        <BackHeader
          stackKey={stackKey}
          title={type == 0 ? "充值记录" : "提现记录"}
        />
        {loading ? (
          <Loading show text={"正在获取数据..."} overSize={false} size={14} />
        ) : oderList.length === 0 ? (
          <NoData text={`还没有${type == 0 ? "充值" : "提现"}记录`} />
        ) : (
          <ScrollArea
            loadingMore={!isAll}
            pullDonRefresh={() => {
              listPage = 1;

              setPage(listPage);
            }}
            onScrollEnd={() => {
              listPage++;
              setPage(listPage);
            }}
          >
            <div
              style={{
                padding: "0.32rem"
              }}
            >
              {oderList.map((item, index) => (
                <div style={styles.recordItem} key={`record-card-${index}`}>
                  <div style={{ ...styles.flexRowBtw, ...styles.borderBox }}>
                    <span style={styles.text1}>
                      {type == 0 ? "充值" : "提现"}
                    </span>
                    <span style={(styles.text2, { color: "#f8c855" })}>
                      {type == 0 ? "+" : "-"}
                      {item.amount}
                    </span>
                  </div>
                  <div
                    style={{ ...styles.flexRowBtw, paddingBottom: "0.32rem" }}
                  >
                    <div style={styles.flexRow}>
                      <img style={styles.icon} src={TimeIcon} />
                      <span style={styles.text2}>
                        {type == 0 ? "充值时间" : "申请时间"}
                      </span>
                    </div>
                    <span style={styles.text3}>{item.created_at}</span>
                  </div>
                  <div style={styles.flexRowBtw}>
                    <div style={styles.flexRow}>
                      <img style={styles.icon} src={SuccessIcon} />
                      <span style={styles.text2}>
                        {type == 0 ? "充值状态" : "申请状态"}
                      </span>
                    </div>
                    <span
                      style={
                        (styles.text2,
                        {
                          color: type === 0 ? "#999999" : getColor(item?.status)
                        })
                      }
                    >
                      {getStatusText(item?.status)}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>
        )}
      </div>
    ),
    [isAll, oderList, loading]
  );
};
