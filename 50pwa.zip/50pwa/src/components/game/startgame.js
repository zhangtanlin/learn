import React, { useEffect, useState, useRef } from "react";
import "../../resources/css/game.less";
import BackHeader from "../../components/backHeader";
import centerIcon from '../../resources/img/public/iconLogo.jpg';
import btn3Icon from '../../resources/img/games/btn3.png';
import Emit from "../../libs/eventEmitter";
export default props => {
  const { url, stackKey } = props;
  const iframeRef = useRef(null);
  const [showIcon, setShowIcon] = useState(false)
  const requestFullScreen = element => {
    // 判断各种浏览器，找到正确的方法
    var requestMethod =
      element.requestFullScreen || //W3C
      element.webkitRequestFullScreen || //FireFox
      element.mozRequestFullScreen || //Chrome等
      element.msRequestFullScreen; //IE11
    if (requestMethod) {
      requestMethod.call(element);
    } else if (typeof window.ActiveXObject !== "undefined") {
      //for Internet Explorer
      var wscript = new ActiveXObject("WScript.Shell");
      if (wscript !== null) {
        wscript.SendKeys("{F11}");
      }
    }
  };
  //退出全屏 判断浏览器种类
  function exitFull() {
    // 判断各种浏览器，找到正确的方法
    var exitMethod =
      document.exitFullscreen || //W3C
      document.mozCancelFullScreen || //FireFox
      document.webkitExitFullscreen || //Chrome等
      document.webkitExitFullscreen; //IE11
    if (exitMethod) {
      exitMethod.call(document);
    } else if (typeof window.ActiveXObject !== "undefined") {
      //for Internet Explorer
      var wscript = new ActiveXObject("WScript.Shell");
      if (wscript !== null) {
        wscript.SendKeys("{F11}");
      }
    }
    Emit.emit(stackKey, stackKey)
    onToggle();
  }
  useEffect(() => {
    requestFullScreen(iframeRef.current);
    return () => {};
  }, []);
  const onToggle = () => {
    setShowIcon(!showIcon)
  }
  return (
    <div className="pull-game-page" ref={iframeRef}>
       <div className="game-back">
        <div className={`content ${showIcon ? 'active' : ''}`} onClick={() => { exitFull() }}><img src={btn3Icon} /></div>
        <div className="center" onClick={() => { onToggle() }}><img src={centerIcon} /></div>
      </div>
      <iframe
        style={{
          width: "100%",
          height: "100%"
        }}
        src={url}
        scrolling="no"
        frameBorder="0"
      ></iframe>
    </div>
  );
};
