import React, { useEffect, useRef, useState } from "react";
import Hammer from "hammerjs";
import BackHeader from "../backHeader";
import ScrollArea from "../scrollarea";
import "../../resources/css/game.less";
import StackPage from "../stackpage";
import redPoint from "../../resources/img/game/redPoint.png";
import RecordPage from "./record";
import StackStore from "../../store/stack";
import {
  rechargeValueGame,
  payGame,
  gameTurn,
} from "../../libs/http";
import ClickBtn from "../clickbtn";
import Emit from "../../libs/eventEmitter";
import wechatIcon from "../../resources/img/game/wechat.png";
import bankIcon from "../../resources/img/game/bank.png";
import alipayIcon from "../../resources/img/game/alipay.png";
import agentIcon from "../../resources/img/game/agent.png";
import WebView from "../webview";
import GlobalVar from "../../libs/globalVar";
import KefuIcon from "../../resources/img/game/kefu.png";
import CaptchDialog from "../../components/captchaDialog";
import turn2 from "../../resources/img/game/turn1.png";
import KefuDetail from "../user/kefuDetail";

export default (props) => {
  const { stackKey, transfer, homeData } = props;

  const [stacks] = StackStore.useGlobalState("stacks");
  const [showCode, setShowCode] = useState(false);
  const [product, setProduct] = useState(null);
  const [question, setQuestion] = useState([]);
  const captchaRef = useRef(null);
  const questionRef = useRef(null);
  const [captcha, setCaptcha] = useState("");
  const [data, setData] = useState(null);
  const inputRef = useRef(null);
  let captchaCode = "";
  useEffect(() => {
    if (!questionRef.current) return;
    // 问题反馈
    const toQuestionPutIn = () => {
      const stackKey = `QuestionPutIn -${new Date().getTime()}`;
      StackStore.dispatch({
        type: "push",
        payload: {
          name: "QuestionPutIn",
          element: (
            <StackPage
              stackKey={stackKey}
              key={stackKey}
              style={{ zIndex: stacks.length + 2 }}
            >
              <KefuDetail stackKey={stackKey} />
            </StackPage>
          ),
        },
      });
    };
    const questionHammer = new Hammer(questionRef.current);
    questionHammer.on("tap", toQuestionPutIn);
    return () => {
      questionHammer.off("tap", toQuestionPutIn);
    };
  }, [questionRef.current]);
  const payWayList = {
    agent: {
      icon: agentIcon,
      color: "#f7956e",
      name: "在线支付"
    },
    wechat: {
      icon: wechatIcon,
      color: "#69c928",
      name: "微信支付"
    },
    alipay: {
      icon: alipayIcon,
      color: "#3ba9f2",
      name: "支付宝支付"
    },
    bankcard: {
      icon: bankIcon,
      color: "#2d90a3",
      name: "银行卡支付"
    },
  };
  const toWebView = (url, title) => {
    const stackKey = `webview-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "replace",
      payload: {
        name: "webview",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            isReplace
            style={{
              zIndex: stacks.length + 1,
            }}
          >
            <WebView title={title} url={url} stackKey={stackKey} />
          </StackPage>
        ),
      },
    });
  };
  let currentPay = null;
  const toRecord = () => {
    const stackKey = `recharge-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "recharge",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <RecordPage type={0} stackKey={stackKey} />
          </StackPage>
        ),
      },
    });
  };
  const userRecharge = () => {
    rechargeValueGame().then((res) => {
      setData(res.data);
      setProduct(res && res.data.list);
      if (homeData && homeData?.pay_text) {
        let newQuetion = homeData.pay_text.split("\n");
        setQuestion(newQuetion);
      }
    });
  };
  useEffect(() => {
    if (captcha) {
      GlobalVar.payParams.code = captcha;
      payGameUrl();
    }
  }, [captcha]);
  const jump = () => {
    payGameUrl();
  };
  // 创建订单
  let winRef;
  const origin = `${window.location.origin}/`;
  const payGameUrl = () => {
    winRef = window.open(`${origin}waiting.html`, "_blank");
    payGame({ ...GlobalVar.payParams })
      .then((res) => {
        if (res.status !== 0 && res.data) {
          // toWebView(res.data.payUrl, "支付");
          winRef.location = res.data.payUrl;
          if(res?.data?.tips){
            Emit.emit("changeAlert", {
              _title: "提示",
              _content: res?.data?.tips,
              _notDouble: false,
              _submit: () => { },
            });
          }
        } else {
          Emit.emit("showToast", {
            text: res.msg,
            time: 3000,
          });
          winRef.location = `${origin}error.html`;
        }
      })
      .catch((ee) => {
        winRef.location = `${origin}error.html`;
      });
  };
  useEffect(() => {
    userRecharge();
  }, []);

  const showPay = (payWay, value) => {
    Emit.emit("changeAlert", {
      _title: "选择支付方式",
      _Nobtn: true,
      _content: (
        <div>
          {payWay.map((n, index) => (

            <ClickBtn
              onTap={() => {
                GlobalVar.payParams = {
                  way: n.way,
                  pid: value,
                  type: n.way == "agent" ? "agent" : "online",
                };
                jump();
              }}
              key={`pay-way-item-${index}`}
              styles={{
                fontSize: "0.373rem",
                color: "#ffffff",
                height: "1.06rem",
                width: "6.16rem",
                borderRadius: "0.533rem",
                marginBottom: "0.4rem",
                background: payWayList[n.way].color,
                display: "flex",
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <img
                src={payWayList[n.way].icon}
                style={{
                  display: "inline-block",
                  marginRight: "0.213rem",
                  height: "0.666rem",
                  width: "0.666rem",
                }}
              />
              {payWayList[n.way].name}
              {payWay[index].tip && (
                <span
                  style={{
                    color: "#faf32a",
                    fontSize: "0.293rem",
                  }}
                >
                  {payWay[index].tip}
                </span>
              )}
            </ClickBtn>
          ))}
        </div>
      ),
    });
  };
  const huazhuan = () => {
    if (homeData && homeData.balance && homeData.balance !== undefined) {
      return (
        <div className="game_huazhuan">
          {huazhuanItem("游戏余额", homeData.balance, false, true, 'fromGameToWallet')}
          {huazhuanItem(
            "金币余额",
            homeData.app_balance,
            false,
            true,
            'fromWalletToGame'
          )}
          {huazhuanItem(
            "代理余额",
            homeData.agent_balance,
            transfer.fromProxyToGame,
            true,
            'fromProxyToGame'
          )}
        </div>
      );
    }
    return <></>;
  };
  const huazhuanItem = (name, coin, showBtn, showQuestion, valueString) => {
    const renderString = () => {
      switch (valueString) {
        case 'fromGameToWallet':
          return "游戏余额划转到金币余额";
        case 'fromWalletToGame':
          return "金币余额划转到游戏余额";
        case 'fromProxyToGame':
          return "代理余额划转到游戏余额";
        default:
          break;
      }
    }
    const btnTyoe = () => {
      switch (valueString) {
        case 'fromGameToWallet':
          return {
            from_type: "game_coins",
            to_type: "coins"
          };
        case 'fromWalletToGame':
          return {
            from_type: "coins",
            to_type: "game_coins"
          };
        case 'fromProxyToGame':
          return {
            from_type: "agent_coins",
            to_type: "game_coins"
          };
        default:
          break;
      }
    }
    return (
      <div className="game_huazhuan_item">
        <span className="game_huazhuan_item_name_box">
          <span className="game_huazhuan_item_name">
            {name}
            {showQuestion && (
              <i
                onClick={() => {
                  Emit.emit("changeAlert", {
                    _title: "",
                    _content: renderString(),
                    _notDouble: true,
                  });
                }}
                className={"iconfont question"}
              />
            )}
          </span>
          <span className="game_huazhuan_item_coin">{coin}</span>
        </span>
        {showBtn ? (
          <ClickBtn
            className="game_huazhuan_item_btn"
            onTap={() => {
              Emit.emit("changeAlert", {
                _title: renderString(),
                _content: (
                  <div className="game_huazhuan_alert">
                    <input
                      type="number"
                      ref={inputRef}
                      placeholder="请输入划转金额"
                      onChange={(e) => {
                        if (!/^[1-9]\d*$/.test(e.target.value)) {
                          Emit.emit("showToast", { text: "请输入数字" });
                        }
                        if (inputRef.current && inputRef.current.value > parseInt(coin)) {
                          inputRef.current.value = coin;
                        }
                      }}
                    />
                  </div>
                ),
                _notDouble: false,
                _submit: () => {
                  if (inputRef.current.value && inputRef.current.value != 0 && showBtn) {
                    const { to_type, from_type } = btnTyoe
                    gameTurn({
                      amount: inputRef.current.value,
                      from_type,
                      to_type
                    }).then((e) => {
                      if (e?.data?.success) {
                        Emit.emit("showToast", { text: e.data.msg });
                        userRecharge();
                      } else {
                        Emit.emit("showToast", { text: e?.data?.msg });
                      }
                    });
                  } else {
                    Emit.emit("showToast", { text: "请输入划转金额" });
                  }
                },
              });
            }}
          >
            <img src={turn2} />
          </ClickBtn>
        ) : (
          <div />
        )}
      </div>
    );
  };
  return (
    <div
      className="full-column"
      style={{ width: "100%", position: "relative" }}
    >
      <CaptchDialog
        show={showCode}
        setCode={(e) => setCaptcha(e)}
        onClose={setShowCode}
      />
      <div
        ref={questionRef}
        style={{
          position: "absolute",
          width: "1.54rem",
          height: "1.54rem",
          backgroundImage: `url(${KefuIcon})`,
          backgroundRepeat: "no-repeat",
          backgroundSize: "cover",
          bottom: "1rem",
          right: "0.2rem",
          zIndex: "99",
        }}
      />
      <BackHeader stackKey={stackKey} title="充值" />
      <ScrollArea downRefresh={false}>
        {huazhuan()}
        <div className="recharge_page">
          <div className="game_title_row">
            <span
              style={{
                color: "white",
                fontSize: "0.43rem",
              }}
            >
              游戏余额充值
            </span>
            <span
              style={{
                fontSize: "0.36rem",
                color: "#999999",
              }}
              onClick={() => {
                toRecord();
              }}
            >
              {"充值记录>"}
            </span>
          </div>
          <div className="product-list-box">
            {product ? (
              product.map((n, index) => (
                <ClickBtn
                  className="product-card"
                  key={`product-card-${index}`}
                  onTap={() => {
                    showPay(product[index].ways, n.id);
                  }}
                >
                  <div className="product-price">
                    {n.promo_price}
                    <span
                      style={{

                        fontSize: "0.29rem",
                      }}
                    >
                      元
                    </span>
                  </div>
                  <p className="vip-text">{n.first_pay_tip}</p>
                </ClickBtn>
              ))
            ) : (
              <div
                style={{
                  width: "100%",
                  height: "1.5rem",
                  lineHeight: "1.5rem",
                  textAlign: "center",
                  fontSize: "0.373rem",
                  color: "#F683A2",
                }}
              >
                正在加载产品信息...
              </div>
            )}
          </div>
          <div className="game_title_row">
            <span
              style={{
                color: "rgb(178,178,178)",
                fontSize: "0.39rem",
              }}
            >
              常见问题
            </span>
          </div>
          <div
            style={{
              padding: "0.316rem",
              background: "rgb(59,59,59)",
              width: "100%",
            }}
          >
            {question.map((n, index) => (
              <div className="question-box" key={`recharge-question-${index}`}>
                <div className="question_item">
                  <img className="red_point" src={redPoint} />
                  <div>{n}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </ScrollArea>
    </div>
  );
};
