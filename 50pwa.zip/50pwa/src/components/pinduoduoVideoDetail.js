import React, { useEffect, useMemo, useRef, useState } from "react";
import Hammer from "hammerjs";
import QRCode from "qrcode.react";
import "../resources/css/pinduoduoVideoDetail.less";
import backWhite from "../resources/img/public/backWhite.png";
import seeMore from "../resources/img/public/icon_see_more_more.png";
import shareIcon from "../resources/img/public/icon_see_more_share.png";
import likeIcon from "../resources/img/public/icon_see_more_like.png";
import likeRedIcon from "../resources/img/public/icon_see_more_like_checked.png";
import tipBg from "../resources/img/public/icon_see_more_all_man.png";
import shop_bg from "../resources/img/public/shop_bg.png";
import money_white from "../resources/img/public/money_white.png";
import pinTitle from "../resources/img/public/icon_see_more_title.webp";
import pinClose from "../resources/img/public/icon_see_more_close.png";
import shareTitle from "../resources/img/public/icon_see_more_share_header.png";
import shareTips from "../resources/img/public/icon_see_all_d.png";
import logo from "../resources/img/public/icon_share_desc_tag.png";
import seeWorld from "../resources/img/public/icon_share_show_d.png";
import codeBg from "../resources/img/public/icon_share_fg_bg.png";
import videoShare from "../resources/img/public/icon_preview_free_share.png";
import huibiIcon from "../resources/img/public/iconn_video_list_pay.png";
import vipIcon from "../resources/img/public/icon_video_list_vip.png";

import ScrollArea from "./scrollarea";
import StackStore from "../store/stack";
import CommentInput from "./commentInput";
import VideoCommentItem from "./videoCommentItem";
import Loading from "./loading";
import NoData from "./noData";
import Avatar from "./avatar";
import Emit from "../libs/eventEmitter";
import StackPage from "./stackpage";
import BottomLayer from "./bottomLayer";
import ClickBtn from "./clickBtn";
import Simg from "./simg";
import globalVar from "../libs/globalVar";
import {
  getMvDetail,
  followUp,
  setMvLike,
  buyMv,
  getMvComments,
  pushComment,
  getPlayPurView,
  getUserInfo
} from "../libs/http";
import PinduoduoVideoDetail from "./pinduoduoVideoDetail";
import UserStore from "../store/user";
import VideoPlayer from "./videoPlayer";
import VideoLoading from "./videoLoading";
import MyMember from "./user/myMember";
import getVideoUrl from "../libs/getVideoUrl";

export default props => {
  const [firstShow, setFirstShow] = useState(false);
  const { stackKey, id } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const [showInput, setShowInput] = useState(false);
  const [loading, setLoading] = useState(true);
  const [isLike, setIsLike] = useState(false);
  const [isSave, setIsSave] = useState(false);
  const [showBuyLayer, setShowBuyLayer] = useState(false);
  const [showPinLayer, setShowPinLayer] = useState(false);
  const [showVideoDetail, setShowVideoDetail] = useState(false);
  const [showShare, setShowShare] = useState(false);
  const [detail, setDetail] = useState(null);
  const [commentList, setCommentList] = useState([]);
  const [scollStatus, setScollStatus] = useState(null);
  const [loadingMore, setLoadingMore] = useState({ a: true });
  const [user] = UserStore.useGlobalState("user");
  const videoRef = useRef(null);
  const [shouldPlay, setShouldPlay] = useState(false);
  const [videoStatus, setVideoStatus] = useState(true);
  const [overLoading, setOverLoading] = useState(false);
  const [showBack, setShowBack] = useState(true);
  const [videoUrl, setVideoUrl] = useState("");
  const [isPreview, setIsPreview] = useState(false);
  useEffect(() => {
    getMvDetail({ id }).then(res => {
      const { is_pay, isfree } = res.data.detail;
      setLoading(false);
      setDetail(res.data);
      setIsSave(res.data.detail.member.is_follow);
      setIsLike(res.data.detail.is_like);
      if (isfree || is_pay) {
        // getVideoUrl(res.data.detail.source_240, (url) => {
        //   setVideoUrl(url);
        // });
        setVideoUrl(res.data.detail.source_240);
      }
      if (res.data.comment.length > 0) {
        setCommentList(res.data.comment);
      } else {
        loadingMore.a = false;
        setLoadingMore({ ...loadingMore });
      }
      if (is_pay) {
        // 购买过，直接看
        setShouldPlay(true);
        setVideoStatus(false);
      } else if (res.data.detail.preview_video) {
        setIsPreview(true);
        setVideoUrl(res.data.detail.preview_video);
        setShouldPlay(true);
        setVideoStatus(false);
      } else if (isfree) {
        // 是免费片
        if (user.vip_level) {
          // 是会员
          setShouldPlay(true);
          setVideoStatus(false);
        } else {
          // 判断是否有免费次数
          getPlayPurView({ id: res.data.detail.id }).then(res => {
            // console.log("res", res);
            if (res.data.daily_view) {
              setShouldPlay(true);
              // 扣次数，存本地,改状态
              const DAILY_VIEW = {
                daily_view: 0,
                day: new Date().getDate()
              };
              localStorage.setItem("DAILY_VIEW", JSON.stringify(DAILY_VIEW));
              const tempObject = {
                ...user,
                ...{ daily_view: 0 }
              }; // 字段说明参考userStore
              UserStore.dispatch({
                type: "replace",
                payload: tempObject
              });
            }
            setVideoStatus(false);
          });
        }
      } else {
        setVideoStatus(false);
      }
      // console.log("detail", res);
    });
  }, []);
  useEffect(() => {
    if (scollStatus) {
      getCommentList();
    }
  }, [scollStatus]);
  const getCommentList = () => {
    if (!loadingMore.a) return;
    getMvComments({
      mv_id: detail.detail.id,
      lastId: commentList[commentList.length - 1].id
    }).then(res => {
      // console.log(
      //   "getMvComments=>",
      //   commentList[commentList.length - 1].id,
      //   res.data
      // );
      if (res.data.length > 0) {
        setCommentList(pre => [...pre, ...res.data]);
      } else {
        loadingMore.a = false;
        setLoadingMore({ ...loadingMore });
      }
    });
  };
  const onLike = () => {
    setIsLike(!isLike);
    setMvLike({ id: detail.detail.id });
  };
  const onShare = () => {
    setShowShare(true);
  };
  const onInput = () => {
    // console.log(11111);
    setShowInput(true);
  };
  const toMyMember = type => {
    videoRef.current && videoRef.current.pause();
    const stackKey = `MyMember-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "MyMember",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <MyMember stackKey={stackKey} type={type} />
          </StackPage>
        )
      }
    });
  };
  const renderVideo = () => {
    return (
      <ClickBtn
        className="pinduoduo-vd-video"
        styles={{ opacity: showShare ? 0 : 1 }}
        onTap={() => {
          if (shouldPlay) {
            setShowBack(!showBack);
          }
        }}
      >
        <div
          className={`pinduoduo-vd-back ${
            showBack ? "pinduoduo-vd-back-show" : "pinduoduo-vd-back-hide"
          }`}
          onClick={() => {
            Emit.emit(stackKey, stackKey);
          }}
        >
          <img src={backWhite} />
        </div>
        {videoStatus ? (
          <VideoLoading />
        ) : shouldPlay ? (
          !videoUrl ? (
            <VideoLoading />
          ) : (
            <div
              style={{
                position: "relative",
                height:'100%'
              }}
            >
              <VideoPlayer
                auto={true}
                src={videoUrl}
                videoRef={videoRef}
                onPause={() => {}}
                thumb={detail.detail.thumb_cover}
                onEnd={() => {
                  console.log("播放结束");
                  if (!firstShow && isPreview) {
                    setFirstShow(true);
                    Emit.emit("changeAlert", {
                      _title: "温馨提示",
                      _content: detail.detail.isfree
                        ? "还有更多精彩内容哦！开通会员即可观看完整版～"
                        : `还有更多精彩内容哦！支付${detail.detail.coins}汤币购买即可观看完整版`,
                      _submitText: detail.detail.isfree
                        ? "立即开通"
                        : "立即购买",
                      _submit: () => {
                        if (detail.detail.isfree) {
                          toMyMember(0);
                        } else {
                          setShowBuyLayer(true);
                        }
                      },
                      _notDouble: true
                    });
                  }
                }}
                onErr={err => {
                  Emit.emit("showToast", {
                    text: "视频加载失败~",
                    time: 3000
                  });
                }}
              />
              {isPreview && (
                <ClickBtn
                  styles={{
                    fontSize: "0.38rem",
                    height: "0.7rem",
                    borderRadius: "0.35rem",
                    lineHeight: "0.7rem",
                    background: "rgba(0,0,0,0.7)",
                    padding: "0 0.38rem",
                    position: "absolute",
                    top: "50%",
                    left: "50%",
                    zIndex: "999",
                    transform: "translate(-50%, -50%)"
                  }}
                  onTap={() => {
                    if (!detail.detail.isfree) {
                      setShowBuyLayer(true);
                    } else {
                      toMyMember(0);
                    }
                  }}
                >
                  <div
                    style={{
                      color: "#ffffff"
                    }}
                  >
                    {detail?.detail?.preview_tip}
                  </div>
                </ClickBtn>
              )}
            </div>
          )
        ) : (
          videolayer()
        )}
      </ClickBtn>
    );
  };
  const videolayer = () => {
    if (!detail) {
      return;
    }
    if (!detail.detail.isfree) {
      return (
        <div className="videoDetail-videolayer">
          <p className="videoDetail-videolayer-title">该视频为收费视频</p>
          <div className="videoDetail-videolayer-btn">
            <ClickBtn
              onTap={() => {
                setShowBuyLayer(true);
              }}
            >
              <img src={huibiIcon} />
              <span>支付{detail.detail.coins}灰币</span>
            </ClickBtn>
          </div>
        </div>
      );
    }
    return (
      <div className="videoDetail-videolayer">
        <p className="videoDetail-videolayer-title">免费观看次数已用尽</p>
        <div className="videoDetail-videolayer-btn">
          <ClickBtn
            onTap={() => {
              toMyMember(0);
            }}
          >
            <img src={vipIcon} />
            <span>充值VIP</span>
          </ClickBtn>
          <ClickBtn onTap={onShare}>
            <img src={videoShare} />
            <span>分享无限看</span>
          </ClickBtn>
        </div>
      </div>
    );
  };
  const renderTag = () => {
    if (detail.detail.tags.length == 0) {
      return "";
    }
    return detail.detail.tags.map(item => {
      return ` ${item}`;
    });
  };
  const renderTitle = () => {
    return (
      <div className="pinduoduo-vd-title">
        <div>
          <p>{detail.detail.title}</p>
          <span
            onClick={() => {
              // console.log(11111);
              setShowVideoDetail(true);
            }}
          >
            更多
            <img src={seeMore} />
          </span>
        </div>
        <div>
          {detail.detail.count_play_str} / {detail.detail.count_like}点赞 /
          {renderTag()}
        </div>
        <div className="pinduoduo-vd-btnbox">
          <ClickBtn onTap={onLike}>
            <div
              className={`pinduoduo-vd-btn ${
                isLike ? "pinduoduo-vd-like" : ""
              }`}
            >
              <img src={isLike ? likeRedIcon : likeIcon} />
              喜欢
            </div>
          </ClickBtn>
          <ClickBtn onTap={onShare}>
            <div className="pinduoduo-vd-btn">
              <img src={shareIcon} />
              分享
            </div>
          </ClickBtn>
        </div>
      </div>
    );
  };
  const renderAllLike = () => {
    if (detail.recommend.length > 0) {
      return (
        <div className="pinduoduo-vd-allLike">
          <p>大家都在拼</p>
          <div className="pinduoduo-vd-allList">
            {detail.recommend.map((item, index) => {
              return <VideoItem item={item} key={index} />;
            })}
          </div>
        </div>
      );
    }
    return;
  };
  const renderComment = () => {
    return (
      <div className="pinduoduo-vd-comment">
        <p className="pinduoduo-vd-comment-title">
          全部热评<span>{detail.detail.count_comment}评论</span>
        </p>
        <div className="pinduoduo-vd-comment-input">
          <div className="pinduoduo-vd-comment-input-img">
            <Simg src={user.thumb} />
          </div>
          <ClickBtn
            className="pinduoduo-vd-comment-input-input"
            onTap={onInput}
          >
            <div>我来说两句</div>
          </ClickBtn>
        </div>
        {commentList.length > 0 ? (
          <div>
            {commentList.map((item, index) => {
              return (
                <VideoCommentItem
                  item={item}
                  key={index}
                  onTap={() => {
                    setShowInput(true);
                  }}
                  onPause={() => {
                    videoRef.current && videoRef.current.pause();
                  }}
                />
              );
            })}
          </div>
        ) : (
          <NoData text={"好想被你填满"} />
        )}
      </div>
    );
  };
  const renderFooter = () => {
    return (
      <div className="pinduoduo-vd-footer">
        <div className="thin-line" />
        <div className="pinduoduo-vd-footer-btn">
          <div
            onClick={() => {
              setShowBuyLayer(true);
            }}
          >
            原价5灰币 观看
          </div>
          {/* <div
            onClick={() => {
              setShowPinLayer(true);
            }}
          >
            0元拼团 免费看片
          </div> */}
        </div>
      </div>
    );
  };
  const renderTips = () => {
    return (
      <div className="pinduoduo-vd-tips">
        <img src={tipBg} />
        <p>该视频共有564人组团成功看片了</p>
      </div>
    );
  };
  const setUserData = async () => {
    const res = await getUserInfo();
    const tempObject = {
      ...res.data,
      ...{ daily_view: user.daily_view }
    }; // 字段说明参考userStore
    UserStore.dispatch({
      type: "replace",
      payload: tempObject
    });
  };
  const buyAvBody = () => {
    return (
      <div className="pinduoduo-vd-buyLayer">
        <img className="buyLayer-bg" src={shop_bg} />
        <div className="buyLayer-body">
          <p>当前为收费视频</p>
          <span className="buyLayer-moneyNum">
            <span>{detail.detail.coins}</span>
            灰币
          </span>
          <div
            className="buyLayer-btn"
            onClick={() => {
              setShowBuyLayer(false);
              setOverLoading(true);
              buyMv({ mv_id: detail.detail.id }).then(res => {
                // console.log(res);
                setOverLoading(false);
                let title = "灰币余额不足，立即充值";
                let subText = "灰币充值";
                if (res.data.code == 0) {
                  setVideoStatus(true);
                  title = "购买成功";
                  subText = "确定";
                  setIsPreview(false);
                  setShouldPlay(true);
                  // getVideoUrl(res.data.url, (url) => {
                  //   setVideoUrl(url);
                  // });
                  setVideoUrl(res.data.url);
                  setUserData();
                  setVideoStatus(false);
                } else if (res.data.code == 2) {
                  title = "请不要重复购买";
                  subText = "确定";
                }
                Emit.emit("changeAlert", {
                  _title: "温馨提示",
                  _content: title,
                  _submitText: subText,
                  _submit: () => {
                    if (res.data.code == 1) {
                      toMyMember(1);
                    }
                  },
                  _notDouble: true
                });
              });
            }}
          >
            <img src={money_white} />
            <span>立即支付</span>
          </div>
        </div>
      </div>
    );
  };
  const pinBody = () => {
    return (
      <div className="pinduoduo-vd-pinbody">
        <img src={pinTitle} />
        <img
          src={pinClose}
          onClick={() => {
            setShowPinLayer(false);
          }}
        />
        <div>
          <p>邀请10人拼团免费看</p>
          <div>
            <span>1.邀请2人拼团成功，系统退还4灰币</span>
            <span>2.邀请10人拼团成功，系统退还全部灰币</span>
          </div>
          <div
            onClick={() => {
              setShowPinLayer(false);
              Emit.emit("changeAlert", {
                _title: "温馨提示",
                _content: "灰币余额不足，立即充值",
                _submitText: "灰币充值",
                _notDouble: true
              });
            }}
          >
            8灰币拼团 免费看片
          </div>
        </div>
      </div>
    );
  };
  const videoDetail = () => {
    return (
      <div className="pinduoduo-vd-vd">
        <div className="vd-title">
          <span>关闭</span>
          <span>视频详情</span>
          <span
            onClick={() => {
              setShowVideoDetail(false);
            }}
          >
            关闭
          </span>
        </div>
        <div className="thin-line" />
        <div className="info-userItem">
          <div className="info-row">
            <Avatar
              size={1.1}
              img={detail.detail.member.thumb}
              uuid={detail.detail.member.uuid}
              isCreater={detail.detail.member.auth_status}
              onTap={() => {
                videoRef.current && videoRef.current.pause();
              }}
            />
            <div className="userItem-info">
              <p>{detail.detail.member.nickname}</p>
              <div>
                {detail.detail.member.followed_count}粉丝 |{" "}
                {detail.detail.member.videos_count}视频
              </div>
            </div>
          </div>
          <div
            className={isSave ? "info-isLike" : "info-like"}
            onClick={() => {
              setIsSave(!isSave);
              followUp({ follow_uuid: detail.detail.member.uuid });
            }}
          >
            {isSave ? "已关注" : "关注"}
          </div>
        </div>
        <div className="vd-info">
          <p>{detail.detail.title}</p>
          <p>
            视频价格：<span>{detail.detail.coins}灰币</span>
          </p>
          <p>
            {detail.detail.count_play_str} / {detail.detail.count_like}点赞 /
            {renderTag()}
          </p>
        </div>
        <div className="thin-line" />
        <div className="vd-desc">
          <p>简介</p>
          <p>{detail.detail.desc}</p>
        </div>
      </div>
    );
  };
  return (
    <div className="page-content-flex">
      {renderVideo()}
      {/* {isPreview && (
        <div
          style={{
            fontSize: "0.32rem",
            display: "flex",
            flexDirection: "row",
            margin: "0.15rem 0.4rem 0.15rem 0.4rem"
          }}
        >
          <span
            style={{
              color: "#999999"
            }}
          >
            正在播放预览视频,
          </span>
          <ClickBtn
            onTap={() => {
              if (!detail.detail.isfree) {
                setShowBuyLayer(true);
              } else {
                toMyMember(0);
              }
            }}
          >
            <div
              style={{
                color: "#fd5c18"
              }}
            >
              {detail?.detail?.preview_tip}
            </div>
          </ClickBtn>
        </div>
      )} */}
      {loading ? (
        <Loading show text={""} overSize={false} size={25} />
      ) : detail ? (
        <ScrollArea
          onScrollEnd={
            detail.detail.count_comment != 0
              ? () => {
                  setScollStatus(new Date());
                }
              : null
          }
          loadingMore={loadingMore.a}
          ListData={commentList}
        >
          {renderTitle()}
          {renderAllLike()}
          {renderComment()}
          {/* <div style={{ height: "1.6rem" }} /> */}
        </ScrollArea>
      ) : (
        <NoData />
      )}
      {showInput && (
        <CommentInput
          onClose={() => {
            setShowInput(false);
          }}
          onSubmit={value => {
            if (!value) {
              Emit.emit("showToast", { text: "请输入内容！" });
            } else {
              pushComment({ mv_id: detail.detail.id, comment: value }).then(
                res => {
                  Emit.emit("showToast", { text: res.msg });
                }
              );
            }
          }}
        />
      )}
      {/* {renderFooter()} */}
      {/* {renderTips()} */}
      {/* 购买观看 */}
      {detail && (
        <BottomLayer
          show={showBuyLayer}
          onTap={() => {
            setShowBuyLayer(false);
          }}
          notList
        >
          {buyAvBody()}
        </BottomLayer>
      )}
      {/* 拼团观看 */}
      {/* <BottomLayer
        bgColor="transparent"
        show={showPinLayer}
        onTap={() => {
          setShowPinLayer(false);
        }}
        notList
      >
        {pinBody()}
      </BottomLayer> */}
      {/* 视频简介 */}
      {detail && (
        <BottomLayer
          show={showVideoDetail}
          onTap={() => {
            setShowVideoDetail(false);
          }}
          notList
        >
          {videoDetail()}
        </BottomLayer>
      )}
      {detail && (
        <ShareLayer
          show={showShare}
          info={detail.detail}
          onClose={() => {
            setShowShare(false);
          }}
        />
      )}
      {overLoading && <Loading show overSize size={30} />}
    </div>
  );
};

const VideoItem = props => {
  const { item } = props;
  const itemRef = useRef(null);
  const [stacks] = StackStore.useGlobalState("stacks");
  useEffect(() => {
    if (!itemRef.current) {
      return;
    }
    const itemHammer = new Hammer(itemRef.current);
    itemHammer.on("tap", jump);
    return () => {
      itemHammer.off("tap", jump);
    };
  }, [itemRef.current]);
  const jump = () => {
    const stackKey = `PinduoduoVideoDetail-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "replace",
      payload: {
        name: "PinduoduoVideoDetail",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <PinduoduoVideoDetail stackKey={stackKey} id={item.id} />
          </StackPage>
        )
      }
    });
  };
  return (
    <div className="pinduoduo-vd-all-viewItem" ref={itemRef}>
      <div className="pinduoduo-vd-all-viewItem-img">
        <Simg src={item.thumb_cover} />
      </div>
      <p>{item.title}</p>
    </div>
  );
};

export const ShareLayer = props => {
  const { show, onClose, info } = props;
  const copyText = text => {
    // 数字没有 .length 不能执行selectText 需要转化成字符串
    const textString = text.toString();
    let input = document.querySelector("#copy-input");
    if (!input) {
      input = document.createElement("input");
      input.id = "copy-input";
      input.readOnly = "readOnly"; // 防止ios聚焦触发键盘事件
      input.style.position = "absolute";
      input.style.left = "-1000px";
      input.style.zIndex = "-1000";
      document.body.appendChild(input);
    }
    input.value = textString;
    // ios必须先选中文字且不支持 input.select();
    selectText(input, 0, textString.length);
    if (document.execCommand("copy")) {
      document.execCommand("copy");
    }
    input.blur();
    function selectText(textbox, startIndex, stopIndex) {
      if (textbox.createTextRange) {
        //ie
        const range = textbox.createTextRange();
        range.collapse(true);
        range.moveStart("character", startIndex); //起始光标
        range.moveEnd("character", stopIndex - startIndex); //结束光标
        range.select(); //不兼容苹果
      } else {
        //firefox/chrome
        textbox.setSelectionRange(startIndex, stopIndex);
        textbox.focus();
      }
    }
  };
  return (
    <div
      className={`pinduoduo-vd-shareLayer ${
        show ? "pinduoduo-vd-share-in" : "pinduoduo-vd-share-out"
      }`}
    >
      <div
        className="pinduoduo-vd-shareLayer-close"
        onClick={() => {
          onClose();
        }}
      />
      {info && (
        <div className="pinduoduo-vd-shareLayer-body">
          <div className="shareLayer-body">
            <img src={shareTitle} />
            <p>{info.member.nickname}</p>
            <img src={shareTips} />
            <div className="shareLayer-video">
              <div className="shareLayer-video-cover">
                <div className="shareLayer-video-cover-img">
                  <Simg src={info.thumb_cover} alwaysShow/>
                </div>
                <span>{info.duration_str}</span>
              </div>
              <div className="shareLayer-video-info">
                <p>{info.title}</p>
                <div>
                  {info.length > 0 &&
                    info.tags.map((item, index) => {
                      if (index > 2) {
                        return "";
                      }
                      return <span key={index}>{item}</span>;
                    })}
                </div>
                <div>
                  <span>{info.count_play_str}</span>
                  <span>{info.count_like}次赞</span>
                </div>
              </div>
            </div>
            <div className="shareLayer-body-bottom">
              <div>
                <img src={logo} />
                <img src={seeWorld} />
                <span>{globalVar.downloadUrl}</span>
              </div>
              <div>
                <img src={codeBg} />
                <div>
                  {globalVar.downloadUrl ? (
                    <QRCode
                      style={{
                        height: "100%",
                        width: "100%"
                      }}
                      value={globalVar.downloadUrl}
                    />
                  ) : (
                    <></>
                  )}
                </div>
              </div>
            </div>
            <div className="shareLayer-avatar">
              <p>我要和你一起看片！</p>
              <div className="shareLayer-avatar-img">
                <Simg src={info.member.thumb} alwaysShow/>
              </div>
            </div>
          </div>
          <div className="pinduoduo-vd-shareLayer-btn">
            <div
              onClick={() => {
                copyText(globalVar.aff_url_copy);
                Emit.emit("showToast", { text: "复制成功，快去分享吧" });
              }}
            >
              复制链接分享
            </div>
            <div
              onClick={() => {
                Emit.emit("showToast", { text: " 请自行在本页面截图保存" });
              }}
            >
              保存图片分享
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
