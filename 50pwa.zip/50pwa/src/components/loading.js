import React, { useEffect, useRef, useState } from "react";
import "../resources/css/loading.less";

export default (props) => {
  const { text, show, overSize = true, size = 30 } = props;
  if (!show) {
    return "";
  }
  return (
    <div className={overSize ? "loading" : "loading-inPage"}>
      <div
        className={"skCircleFade"}
        style={{ width: `${size}px`, height: `${size}px` }}
      >
        {(() => {
          let ary = [];
          for (let i = 0; i < 12; i++) {
            ary.push(
              <div
                className={`skCircleFadeDot ${
                  overSize ? "" : "skCircleFadeDot1"
                }`}
                key={i}
              />
            );
          }
          return ary;
        })()}
      </div>
      <span>{text}</span>
    </div>
  );
};
