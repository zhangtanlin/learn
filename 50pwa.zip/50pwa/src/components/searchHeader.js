import React, {useEffect, useMemo, useRef, useState} from "react";
import StackStore from "../store/stack";
import everyday from "../resources/img/public/everyday.png";
import searchIcon from "../resources/img/public/search.png";
import publishIcon from "../resources/img/public/publishIcon.png";
import StackPage from "./stackpage";
import SearchPage from "./featured/search";
import EveryDayPage from "./featured/everday";
import Emit from "../libs/eventEmitter";

export default props => {
  const [stacks] = StackStore.useGlobalState("stacks");
  const {center, showPostButton = true} = props;
  return useMemo(
    () => (
      <div className="searchHeader">
        <img
          className="searchHeader-everyday"
          src={everyday}
          onClick={() => {
            const stackKey = `EveryDayPage-${new Date().getTime()}`;
            StackStore.dispatch({
              type: "push",
              payload: {
                name: "EveryDayPage",
                element: (
                  <StackPage
                    stackKey={stackKey}
                    key={stackKey}
                    style={{zIndex: stacks.length + 2}}
                  >
                    <EveryDayPage stackKey={stackKey}/>
                  </StackPage>
                )
              }
            });
          }}
        />
        {center ? (
          center()
        ) : (
          <div
            className="searchHeader-input"
            onClick={() => {
              const stackKey = `SearchPage-${new Date().getTime()}`;
              StackStore.dispatch({
                type: "push",
                payload: {
                  name: "SearchPage",
                  element: (
                    <StackPage
                      stackKey={stackKey}
                      key={stackKey}
                      style={{zIndex: stacks.length + 2}}
                    >
                      <SearchPage stackKey={stackKey}/>
                    </StackPage>
                  )
                }
              });
            }}
          >
            <img src={searchIcon}/>
            <span>视频｜创作者</span>
          </div>
        )}
        {
          showPostButton && <img
            className="searchHeader-publish"
            src={publishIcon}
            onClick={() => {
              Emit.emit("changeAlert", {
                _title: "温馨提示",
                _content: "请下载50度灰APP使用上传功能！",
                _submitText: "确定",
                _notDouble: true
              });
            }}
          />
        }
      </div>
    ),
    [center, showPostButton]
  );
};
