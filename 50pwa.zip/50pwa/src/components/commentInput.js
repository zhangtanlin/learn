import React, { useEffect, useMemo, useRef, useState } from "react";
import "../resources/css/videoDetail.less";
import Emit from "../libs/eventEmitter";
import write from "../resources/img/public/video_detail_send.png";

export default (props) => {
  const { onClose, onSubmit, placeholder = "优质评论优先展示" } = props;
  const inputRef = useRef(null);
  return (
    <div className="video-detail-input-layer">
      <div
        className="video-detail-input-close"
        onClick={() => {
          onClose && onClose();
        }}
      />
      <div className="video-detail-input">
        <div className="input-box">
          <img src={write} />
          <input
            ref={inputRef}
            type="text"
            placeholder={placeholder}
            autoFocus
          />
        </div>
        <span
          className="input-sub"
          onClick={() => {
            onSubmit && onSubmit(inputRef.current.value);
            onClose && onClose();
          }}
        >
          确定
        </span>
      </div>
    </div>
  );
};
