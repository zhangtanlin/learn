import React, { useEffect, useState } from "react";
import ClickBtn from "./clickBtn";
export default props => {
  const { text, url, remotelyVersion } = props;
  const version = 100;
  const [isHide, setIsHide] = useState(true);
  let remotely = remotelyVersion.replaceAll(".", "");
  useEffect(() => {
    if (remotely > version) {
      setIsHide(false);
    }
    return () => {};
  }, []);
  return (
    <div
      style={{
        position: "fixed",
        top: "0",
        right: "0",
        left: "0",
        bottom: "0",
        background: "rgba(0,0,0,0.7)",
        zIndex: isHide ? "0" : "9999",
        transition: "0.3s all ease-in",
        pointerEvents: isHide ? "none" : "auto",
        opacity: isHide ? "0" : "1"
      }}
    >
      <div
        style={{
          position: "absolute",
          top: "50%",
          left: "50%",
          width: "80%",
          lineHeight: "1.5",
          transform: "translate(-50%,-50%)",
          padding: "0.4rem",
          borderRadius: "0.15rem",
          background: "#ffffff",
          color: "#333333",
          fontSize: "0.427rem"
        }}
      >
        {text}
        <div
          style={{
            marginTop: "0.15rem",
            color: "#0269c8",
            fontSize: "0.373rem",
            display: "flex",
            flexDirection: "row",
            justifyContent: "flex-end"
          }}
        >
          <ClickBtn
            onTap={() => {
              setIsHide(true);
            }}
          >
            取消
          </ClickBtn>
          <ClickBtn
            onTap={() => {
              window.open(url, "_blank");
              setIsHide(true);
            }}
            styles={{
              marginLeft: "1rem"
            }}
          >
            去更新
          </ClickBtn>
        </div>
      </div>
    </div>
  );
};
