import React, { useEffect, useMemo, useRef, useState } from "react";
import Hammer from "hammerjs";
import StackStore from "../../store/stack";
import BackHeader from "../backHeader";
import Simg from "../simg";
import ScrollArea from "../scrollarea";
import "../../resources/css/search.less";
import Emit from "../../libs/eventEmitter";
import Loading from "../loading";
import NoData from "../noData";
import { Swiper, SwiperSlide } from "swiper/react";
import SwiperCore, { Controller } from "swiper";
import { getStyleVideo } from "../../libs/http";
import "swiper/swiper.min.css";
import StackPage from "../stackpage";
import VideoDetail from "../videoDetail";
import ClickBtn from "../clickBtn";
SwiperCore.use([Controller]);
export default props => {
  const { stackKey, title, tagItem } = props;
  const navs = [
    {
      title: "最新",
      orderBy: "id"
    },
    {
      title: "最热",
      orderBy: "play"
    }
  ];
  const [tabIndex, setTabIndex] = useState(0);
  const [controlledSwiper, setControlledSwiper] = useState(null);
  return (
    <div className="page-content-flex">
      <BackHeader
        stackKey={stackKey}
        title={`#${tagItem.name}`}
        right={() => {
          return <div style={{ width: "1.2rem" }} />;
        }}
      />
      <div className="search-result">
        <div className="search-tab taglist-tab">
          <ClickBtn
            className={tabIndex == 0 ? "active" : ""}
            onTap={() => {
              setTabIndex(0);
              controlledSwiper.slideTo(0);
            }}
          >
            最新
            {tabIndex == 0 && (
              <div className="taglist-tab-active ">
                <div />
              </div>
            )}
          </ClickBtn>
          <ClickBtn
            className={tabIndex == 1 ? "active" : ""}
            onTap={() => {
              setTabIndex(1);
              controlledSwiper.slideTo(1);
            }}
          >
            最热
            {tabIndex == 1 && (
              <div className="taglist-tab-active ">
                <div />
              </div>
            )}
          </ClickBtn>
        </div>
        <Swiper
          className={"featured-swiper"}
          controller={{ control: controlledSwiper }}
          onSwiper={setControlledSwiper}
          onSlideChange={e => {
            setTabIndex(e.activeIndex);
          }}
        >
          {navs.map((item, index) => {
            return (
              <SwiperSlide key={index}>
                <SwiperItem
                  show={tabIndex == index}
                  orderBy={item.orderBy}
                  id={tagItem.id}
                />
              </SwiperSlide>
            );
          })}
        </Swiper>
      </div>
    </div>
  );
};

const SwiperItem = props => {
  const { show, orderBy, id } = props;
  const [loading, setLoading] = useState(true);
  const [initList, setInitList] = useState(false);
  const [listData, setListData] = useState({
    data: []
  });
  const [page, setPage] = useState({
    num: 1
  });
  const [isAll, setIsAll] = useState(false);
  const size = 15;
  useEffect(() => {
    if (show && !initList) {
      setInitList(true);
    }
  }, [show]);
  const initListData = async () => {
    let res = await getStyleVideo({
      id,
      orderBy,
      page: page.num,
      size
    });
    // console.log("列表", res);
    if (res.status === 200) {
      if (page.num === 1) {
        listData.data = [...res.data.list];
      } else {
        listData.data = [...listData.data, ...res.data.list];
      }
      if (res.data.list.length < size) {
        setIsAll(true);
      }
      setListData({ ...listData });
      setLoading(false);
    }
  };
  const _loadMoreData = () => {
    if (isAll) return;
    page.num = page.num + 1;
    setPage({ ...page });
  };
  useEffect(() => {
    if (initList) {
      initListData();
    }
  }, [initList, page]);
  return useMemo(
    () => (
      <div className={"featured-swiper-item"}>
        {loading || !initList ? (
          <Loading show text={"正在获取数据..."} overSize={false} size={25} />
        ) : listData.data.length > 0 ? (
          <ScrollArea
            ListData={listData.data}
            onScrollEnd={_loadMoreData}
            loadingMore={!isAll}
          >
            {listData.data.map((item, index) => {
              return <VideoItem key={index} data={item} />;
            })}
            <div style={{ height: "30px" }} />
          </ScrollArea>
        ) : (
          <NoData />
        )}
      </div>
    ),
    [loading, initList, listData]
  );
};

const VideoItem = props => {
  const { data } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const videoRef = useRef(null);
  useEffect(() => {
    if (!videoRef.current) {
      return;
    }
    const videoHammer = new Hammer(videoRef.current);
    videoHammer.on("tap", jump);
    return () => {
      videoHammer.off("tap", jump);
    };
  }, [videoRef.current]);
  const jump = () => {
    const stackKey = `video-detai-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "video-detai",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <VideoDetail stackKey={stackKey} id={data.id} />
          </StackPage>
        )
      }
    });
  };
  return useMemo(() => {
    return (
      <div className="search-videoItem" ref={videoRef}>
        <div className="search-videoCover">
          <Simg src={data.thumb_cover} />
          <span>{data.duration_str}</span>
        </div>
        <div className="search-videoInfo">
          <p>{data.title}</p>
          <div>
            <span>{data.member.nickname}</span>
            <span>{data.count_play_str}</span>
          </div>
        </div>
      </div>
    );
  }, [data]);
};
