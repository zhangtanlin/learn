import React, { useEffect, useMemo, useRef, useState } from "react";
import Hammer from "hammerjs";
import StackStore from "../../store/stack";
import BackHeader from "../backHeader";
import ScrollArea from "../scrollarea";
import "../../resources/css/pinduoduo.less";
import Emit from "../../libs/eventEmitter";
import Loading from "../loading";
import NoData from "../noData";
import StackPage from "../stackpage";
import headerBg from "../../resources/img/public/icon_see_more_manager_header.webp";
import rightIcon from "../../resources/img/public/icon_mine_check_more.png";
import pointIcon from "../../resources/img/public/pointx3.png";

import { Swiper, SwiperSlide } from "swiper/react";
import SwiperCore, { Controller } from "swiper";
import "swiper/swiper.min.css";
import { getMyPindan, getClubInfo, getPindanByCode } from "../../libs/http";

SwiperCore.use([Controller]);
export default (props) => {
  const { stackKey, type } = props;

  const navs = ["我参团的", "搜索拼单"];
  const [tabIndex, setTabIndex] = useState(0);
  const [controlledSwiper, setControlledSwiper] = useState(null);
  useEffect(() => {
    getClubInfo().then((res) => {
      // console.log("getClubInfo", res);
    });
    getMyPindan().then((res) => {
      // console.log("getMyPindan", res);
    });
  }, []);
  return (
    <div className="page-content-flex pinduoduo">
      <BackHeader
        stackKey={stackKey}
        title="邀请好友免费看片"
        right={() => {
          return <div style={{ width: "1.2rem" }} />;
        }}
      />
      <ScrollArea downRefresh={false} ListData={1} groupId="pinduoduo">
        <img className="pinduoduo-bg" src={headerBg} />
        <div className="pinduoduo-body">
          <div className="pinduoduo-result">
            <div
              className="pinduoduo-tab taglist-tab"
              style={{ marginBottom: 10 }}
            >
              <span
                className={tabIndex == 0 ? "active" : ""}
                onClick={() => {
                  setTabIndex(0);
                  controlledSwiper.slideTo(0);
                }}
              >
                我参团的
                {tabIndex == 0 && (
                  <div className="taglist-tab-active ">
                    <div />
                  </div>
                )}
              </span>
              <span
                className={tabIndex == 1 ? "active" : ""}
                onClick={() => {
                  setTabIndex(1);
                  controlledSwiper.slideTo(1);
                }}
              >
                搜索拼单
                {tabIndex == 1 && (
                  <div className="taglist-tab-active ">
                    <div />
                  </div>
                )}
              </span>
            </div>
            <Swiper
              className={"featured-swiper"}
              controller={{ control: controlledSwiper }}
              onSwiper={setControlledSwiper}
              onSlideChange={(e) => {
                setTabIndex(e.activeIndex);
              }}
              initialSlide={type}
            >
              {navs.map((item, index) => {
                return (
                  <SwiperSlide key={index}>
                    <SwiperItem index={index} current={tabIndex} title={item} />
                  </SwiperSlide>
                );
              })}
            </Swiper>
          </div>
        </div>
      </ScrollArea>
    </div>
  );
};

const SwiperItem = (props) => {
  const { index, current, title } = props;
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState([]);
  const [loadingMore, setLoadingMore] = useState({ a: true });
  let page = 1;
  useEffect(() => {
    if (index == current && data.length == 0) {
      getData("init");
    }
  }, [current]);
  const getData = (status) => {
    if (!loadingMore.a) return;
    if (!status) {
      page++;
    }
    setTimeout(() => {
      setLoading(false);
      setData((pre) => [...pre, 1, 1, 1, 1, 1, 1, 1]);
    }, 1000);
    // postLotteryLog({ page: page, limit: 20, id: index + 1 })
    //   .then((res) => {
    //     // console.log("payMvLog=>", res);
    //     setLoading(false);
    //     if (res.data.length > 0) {
    //       if (res.data.length < 20) {
    //         loadingMore.a = false;
    //         setLoadingMore({ ...loadingMore });
    //       }
    //       setData((pre) => [...pre, ...res.data]);
    //     } else {
    //       if (page == 1) {
    //         setData([]);
    //       }
    //       loadingMore.a = false;
    //       setLoadingMore({ ...loadingMore });
    //     }
    //   })
    //   .catch(() => {
    //     setLoading(false);
    //   });
  };
  const renderInput = () => {
    return (
      <dvi className="pinduoduo-input">
        <div className="pinduoduo-input-box">
          <input type="text" placeholder="输入拼单码 搜索拼单团" />
        </div>
        <span>搜索</span>
      </dvi>
    );
  };
  return (
    <div className={"featured-swiper-item"}>
      {index == 1 && renderInput()}
      {loading ? (
        <Loading show text={"正在获取数据..."} overSize={false} size={25} />
      ) : data.length > 0 ? (
        <ScrollArea
          ListData={data}
          onScrollEnd={getData}
          loadingMore={loadingMore.a}
          groupId="pinduoduo"
        >
          {data.map((item, index) => {
            return <PinduoduoItem key={index} />;
          })}
        </ScrollArea>
      ) : (
        <NoData text="好想被你填满" />
      )}
    </div>
  );
};

const PinduoduoItem = (props) => {
  const videoRef = useRef(null);
  const avatarList = [1, 1, 1, 1, 1, 1];
  useEffect(() => {
    if (!videoRef.current) {
      return;
    }
    const videoHammer = new Hammer(videoRef.current);
    videoHammer.on("tap", jump);
    return () => {
      videoHammer.off("tap", jump);
    };
  }, [videoRef.current]);
  const jump = () => {};
  const tagItem = (text, index) => {
    return (
      <span key={index} className="tag-item">
        {text}
      </span>
    );
  };
  const avatarItem = (index) => {
    if (index == avatarList.length - 1) {
      return (
        <div
          key={index}
          className="pinduoduo-avatarItem-point"
          style={{ left: `-${index * 0.3}rem`, zIndex: index + 1 }}
        >
          <img src={pointIcon} />
        </div>
      );
    }
    return (
      <div
        key={index}
        className="pinduoduo-avatarItem"
        style={{ left: `-${index * 0.3}rem`, zIndex: index + 1 }}
      >
        <img
          src={"https://image.mn52.com/img/allimg/190911/8-1Z911123341.png"}
        />
      </div>
    );
  };
  return (
    <div className="pinduoduoItem">
      <div className="pinduoduo-videoItem" ref={videoRef}>
        <div className="pinduoduo-videoCover">
          <img
            src={"https://image.mn52.com/img/allimg/190911/8-1Z911123341.png"}
          />
        </div>
        <div className="pinduoduo-videoInfo">
          <p>
            撒好看的哈萨克都好看啦收到啦说了电话啦收到啦收到啦还撒了点回来撒好的啦
          </p>
          <span>演员：大傻逼</span>
          <div className="pinduoduo-tag-list">
            {["后入", "后入", "后入", "后入"].map((item, index) => {
              return tagItem(item, index);
            })}
          </div>
          <div className="pinduoduo-name">
            <span>山东快书斯巴达克斯</span>
            <span>12456次播放</span>
          </div>
        </div>
      </div>
      <div className="pinduoduo-daojishi">
        <span className="pinduoduo-joinNum">
          共有15人加入拼团 <img src={rightIcon} />
        </span>
        <div className="pinduoduo-time">
          <span>倒计时</span>
          <div>
            <span>2</span>
            <span>2</span>
            <i>:</i>
            <span>2</span>
            <span>2</span>
            <i>:</i>
            <span>2</span>
            <span>2</span>
          </div>
        </div>
      </div>
      <div className="pinduoduo-avatarList">
        {avatarList.map((item, index) => {
          return avatarItem(index);
        })}
      </div>
      <div className="pinduoduo-btn">邀请好友（满30人免费看片）</div>
      <div className="thin-line" />
    </div>
  );
};
