import React, {useEffect, useMemo, useRef, useState} from "react";
import Hammer from "hammerjs";
import StackStore from "../../../store/stack";
import BackHeader from "../../backHeader";
import ScrollArea from "../../scrollarea";
import Emit from "../../../libs/eventEmitter";
import Loading from "../../loading";
import NoData from "../../noData";
import StackPage from "../../stackpage";
import hejiIcon from "../../../resources/img/public/icon_comp_video_tag.png";
import {Swiper, SwiperSlide} from "swiper/react";
import SwiperCore, {Controller} from "swiper";
import "swiper/swiper.min.css";
import {getCompilationList, getMoreConcentrationList} from "../../../libs/http";
import Simg from "../../simg";
import ClickBtn from "../../clickBtn";
import "../../../resources/css/cartoon.less"
import VideoDetail from "../../videoDetail";
import {Concentration} from "./index";

SwiperCore.use([Controller]);
export default (props) => {
  const {stackKey, title, id} = props;

  const navs = ["最新排序", "最热排序"];
  const [tabIndex, setTabIndex] = useState(0);
  const [controlledSwiper, setControlledSwiper] = useState(null);
  return (<div className="page-content-flex Cartoon-page">
    <BackHeader
      stackKey={stackKey}
      title={title}
      right={() => {
        return <div style={{width: "1.2rem"}}/>;
      }}
    />
    <div className="search-result">
      <div className="search-tab taglist-tab" style={{marginBottom: 10}}>
        <ClickBtn
          className={tabIndex == 0 ? "active" : ""}
          onTap={() => {
            setTabIndex(0);
            controlledSwiper.slideTo(0);
          }}
        >
          最新排序
          {tabIndex == 0 && (<div className="taglist-tab-active ">
            <div/>
          </div>)}
        </ClickBtn>
        <ClickBtn
          className={tabIndex == 1 ? "active" : ""}
          onTap={() => {
            setTabIndex(1);
            controlledSwiper.slideTo(1);
          }}
        >
          最热排序
          {tabIndex == 1 && (<div className="taglist-tab-active ">
            <div/>
          </div>)}
        </ClickBtn>
      </div>
      <Swiper
        className={"featured-swiper"}
        controller={{control: controlledSwiper}}
        onSwiper={setControlledSwiper}
        onSlideChange={(e) => {
          setTabIndex(e.activeIndex);
        }}
      >
        {navs.map((item, index) => {
          return (<SwiperSlide key={index}>
            <SwiperItem id={id} index={index} current={tabIndex} title={item}/>
          </SwiperSlide>);
        })}
      </Swiper>
    </div>
  </div>);
};

const SwiperItem = (props) => {
  const [stacks] = StackStore.useGlobalState("stacks");
  const {index, current, title, id} = props;
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState([]);
  const [loadingMore, setLoadingMore] = useState({a: true});
  let page = 1;
  useEffect(() => {
    if (index == current && data.length == 0) {
      getData("init");
    }
  }, [current]);

  const getData = (status) => {
    if (!loadingMore.a) return;
    if (!status) {
      page++;
    }
    getMoreConcentrationList({page: page, sort: index == 0 ? "new" : "hot", id})
      .then((res) => {
        if (res.data.list.length > 0) {
          setData((pre) => [...pre, ...res.data.list]);
        } else {
          if (page == 1) {
            setData([]);
          }
          loadingMore.a = false;
          setLoadingMore({...loadingMore});
        }
      })
      .finally(() => {
        setLoading(false);
      });
  };


  return (<div className={"featured-swiper-item"}>
    {loading ? (<Loading show text={"正在获取数据..."} overSize={false} size={25}/>) : data.length > 0 ? (<ScrollArea
      ListData={data}
      onScrollEnd={getData}
      loadingMore={loadingMore.a}
    >
      <div className={"Cartoon-list"}>
        {data.map((item, index) => {
          return <Concentration data={item} key={index}/>;
        })}
      </div>
      <div style={{height: "30px"}}/>
    </ScrollArea>) : (<NoData/>)}
  </div>);
};
