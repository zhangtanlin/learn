import React, { useEffect, useMemo, useRef, useState } from "react";
import Hammer from "hammerjs";
import StackStore from "../../store/stack";
import BackHeader from "../backHeader";
import ScrollArea from "../scrollarea";
import "../../resources/css/search.less";
import Emit from "../../libs/eventEmitter";
import Loading from "../loading";
import NoData from "../noData";
import StackPage from "../stackpage";
import HejiVideoList from "./hejiVideoList";
import hejiIcon from "../../resources/img/public/icon_comp_video_tag.png";
import { Swiper, SwiperSlide } from "swiper/react";
import SwiperCore, { Controller } from "swiper";
import "swiper/swiper.min.css";
import { getCompilationList } from "../../libs/http";
import Simg from "../simg";
import ClickBtn from "../clickBtn";
SwiperCore.use([Controller]);
export default (props) => {
  const { stackKey } = props;

  const navs = ["最新", "最热"];
  const [tabIndex, setTabIndex] = useState(0);
  const [controlledSwiper, setControlledSwiper] = useState(null);
  return (
    <div className="page-content-flex">
      <BackHeader
        stackKey={stackKey}
        title="精选合集"
        right={() => {
          return <div style={{ width: "1.2rem" }} />;
        }}
      />
      <div className="search-result">
        <div className="search-tab taglist-tab" style={{ marginBottom: 10 }}>
          <ClickBtn
            className={tabIndex == 0 ? "active" : ""}
            onTap={() => {
              setTabIndex(0);
              controlledSwiper.slideTo(0);
            }}
          >
            最新
            {tabIndex == 0 && (
              <div className="taglist-tab-active ">
                <div />
              </div>
            )}
          </ClickBtn>
          <ClickBtn
            className={tabIndex == 1 ? "active" : ""}
            onTap={() => {
              setTabIndex(1);
              controlledSwiper.slideTo(1);
            }}
          >
            最热
            {tabIndex == 1 && (
              <div className="taglist-tab-active ">
                <div />
              </div>
            )}
          </ClickBtn>
        </div>
        <Swiper
          className={"featured-swiper"}
          controller={{ control: controlledSwiper }}
          onSwiper={setControlledSwiper}
          onSlideChange={(e) => {
            setTabIndex(e.activeIndex);
          }}
        >
          {navs.map((item, index) => {
            return (
              <SwiperSlide key={index}>
                <SwiperItem index={index} current={tabIndex} title={item} />
              </SwiperSlide>
            );
          })}
        </Swiper>
      </div>
    </div>
  );
};

const SwiperItem = (props) => {
  const { index, current, title } = props;
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState([]);
  const [loadingMore, setLoadingMore] = useState({ a: true });
  let page = 1;
  useEffect(() => {
    if (index == current && data.length == 0) {
      getData("init");
    }
  }, [current]);
  const getData = (status) => {
    if (!loadingMore.a) return;
    if (!status) {
      page++;
    }
    getCompilationList({ page: page, sort: index == 0 ? "new" : "hot" })
      .then((res) => {
        // console.log("getCompilationList=>", page, res);
        setLoading(false);
        if (res.data.length > 0) {
          setData((pre) => [...pre, ...res.data]);
        } else {
          if (page == 1) {
            setData([]);
          }
          loadingMore.a = false;
          setLoadingMore({ ...loadingMore });
        }
      })
      .catch(() => {
        setLoading(false);
      });
  };
  return (
    <div className={"featured-swiper-item"}>
      {loading ? (
        <Loading show text={"正在获取数据..."} overSize={false} size={25} />
      ) : data.length > 0 ? (
        <ScrollArea
          ListData={data}
          onScrollEnd={getData}
          loadingMore={loadingMore.a}
        >
          {data.map((item, index) => {
            return <HejiItem item={item} key={index} />;
          })}
          <div style={{ height: "30px" }} />
        </ScrollArea>
      ) : (
        <NoData />
      )}
    </div>
  );
};

const HejiItem = (props) => {
  const { item } = props;
  const videoRef = useRef(null);
  const [stacks] = StackStore.useGlobalState("stacks");
  useEffect(() => {
    if (!videoRef.current) {
      return;
    }
    const videoHammer = new Hammer(videoRef.current);
    videoHammer.on("tap", jump);
    return () => {
      videoHammer.off("tap", jump);
    };
  }, [videoRef.current]);
  const jump = () => {
    const stackKey = `HejiVideoList-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "HejiVideoList",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <HejiVideoList
              stackKey={stackKey}
              title={item.title}
              id={item.id}
            />
          </StackPage>
        ),
      },
    });
  };
  return (
    <div className="HejiItem" ref={videoRef}>
      <div className="HejiItem-cover">
        <Simg src={item.image} />
      </div>
      <div className="HejiItem-layer">
        <p>{item.title}</p>
        <div>
          <img src={hejiIcon} />
          <span>共{item.count}个视频</span>
        </div>
      </div>
    </div>
  );
};
