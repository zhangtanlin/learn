import React, { useEffect, useMemo, useRef, useState } from "react";
import Hammer from "hammerjs";
import StackStore from "../../store/stack";
import BackHeader from "../backHeader";
import ScrollArea from "../scrollarea";
import "../../resources/css/fansRank.less";
import Emit from "../../libs/eventEmitter";
import Loading from "../loading";
import NoData from "../noData";
import StackPage from "../stackpage";
import Avatar from "../avatar";
import no1 from "../../resources/img/public/icon_worker_one.png";
import no2 from "../../resources/img/public/icon_worker_two.png";
import no3 from "../../resources/img/public/icon_worker_three.png";
import UserPage from "../category/user_page";

import { Swiper, SwiperSlide } from "swiper/react";
import SwiperCore, { Controller } from "swiper";
import "swiper/swiper.min.css";
import { getFansRank, getNewstRank } from "../../libs/http";
import Simg from "../simg";
import ClickBtn from "../clickBtn";
import FansGroup from "../category/fans_group";

SwiperCore.use([Controller]);
export default (props) => {
  const { stackKey, type } = props;
  const [tabIndex, setTabIndex] = useState(0);
  const [controlledSwiper, setControlledSwiper] = useState(null);
  const changeTab = (num) => {
    setTabIndex(num);
    controlledSwiper.slideTo(num);
  };
  return (
    <div className="page-content-flex">
      <BackHeader
        stackKey={stackKey}
        center={() => {
          return (
            <div className="fansRank-title">
              <span
                className={tabIndex == 0 ? "fansRank-title-active" : ""}
                onClick={() => {
                  changeTab(0);
                }}
              >
                榜单
              </span>
              <span
                className={tabIndex == 1 ? "fansRank-title-active" : ""}
                onClick={() => {
                  changeTab(1);
                }}
              >
                最新
              </span>
            </div>
          );
        }}
        right={() => {
          return <div style={{ width: "1.2rem" }} />;
        }}
      />
      <Swiper
        className={"featured-swiper"}
        controller={{ control: controlledSwiper }}
        onSwiper={setControlledSwiper}
        onSlideChange={(e) => {
          setTabIndex(e.activeIndex);
        }}
      >
        <SwiperSlide>
          <Rank current={tabIndex} />
        </SwiperSlide>
        <SwiperSlide>
          <News current={tabIndex} />
        </SwiperSlide>
      </Swiper>
    </div>
  );
};

const Rank = (props) => {
  const { current } = props;
  const navs = ["日榜", "周榜", "月榜"];
  const [tabIndex, setTabIndex] = useState(0);
  const [controlledSwiper, setControlledSwiper] = useState(null);
  const tabItem = (text, index) => {
    return (
      <span
        className={`fansRank-rank-tabItem ${tabIndex == index ? "active" : ""}`}
        key={index}
        onClick={() => {
          setTabIndex(index);
          controlledSwiper.slideTo(index);
        }}
      >
        {text}
      </span>
    );
  };
  return (
    <div className="fansRank-rank">
      <div className="fansRank-rank-tabList">
        {navs.map((item, index) => {
          return tabItem(item, index);
        })}
      </div>
      <Swiper
        className={"featured-swiper"}
        controller={{ control: controlledSwiper }}
        onSwiper={setControlledSwiper}
        onSlideChange={(e) => {
          setTabIndex(e.activeIndex);
        }}
      >
        {navs.map((item, index) => {
          return (
            <SwiperSlide key={index}>
              <RankItemPage index={index} current={tabIndex} />
            </SwiperSlide>
          );
        })}
      </Swiper>
    </div>
  );
};

const RankItemPage = (props) => {
  const { index, current } = props;
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState([]);
  const [stacks] = StackStore.useGlobalState("stacks");
  useEffect(() => {
    if (index == current && data.length == 0) {
      getData();
    }
  }, [current]);
  const getType = () => {
    if (index == 0) {
      return "daily";
    } else if (index == 1) {
      return "week";
    }
    return "month";
  };
  const getData = () => {
    getFansRank({ type: getType() })
      .then((res) => {
        // console.log("getFansRank=>", res);
        setLoading(false);
        if (res.data.length > 0) {
          setData(res.data);
        }
      })
      .catch(() => {
        setLoading(false);
      });
  };
  const toUserPage = (uuid) => {
    const stackKey = `userpage-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "userpage",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <UserPage stackKey={stackKey} uuid={uuid} />
          </StackPage>
        ),
      },
    });
  };
  const oneToThree = () => {
    return (
      <div className="fansRank-oneToThree">
        <ClickBtn
          className="fansRank-oneToThree-item"
          onTap={() => {
            toUserPage(data[1].uuid);
          }}
        >
          <div className="fansRank-oneToThree-avatar">
            <div
              style={{ width: "1rem", height: "1rem", borderColor: "#ccdce3" }}
              className="fansRank-oneToThree-avatar-border"
            >
              <Avatar img={data[1].thumb} size={1} uuid={data[1].uuid} />
            </div>
            <img className="fansRank-oneToThree-avatar-num" src={no2} />
          </div>
          <p>{data[1].name}</p>
          <span>加入{data[1].num}人</span>
        </ClickBtn>
        <ClickBtn
          className="fansRank-oneToThree-item fansRank-big"
          onTap={() => {
            toUserPage(data[0].uuid);
          }}
        >
          <div className="fansRank-oneToThree-avatar">
            <div
              style={{ width: "1.2rem", height: "1.2rem" }}
              className="fansRank-oneToThree-avatar-border"
            >
              <Avatar size={1.2} img={data[0].thumb} uuid={data[0].uuid} />
            </div>
            <img className="fansRank-oneToThree-avatar-num" src={no1} />
          </div>
          <p>{data[0].name}</p>
          <span>加入{data[0].num}人</span>
        </ClickBtn>
        <ClickBtn
          className="fansRank-oneToThree-item"
          onTap={() => {
            toUserPage(data[2].uuid);
          }}
        >
          <div className="fansRank-oneToThree-avatar">
            <div
              style={{ width: "1rem", height: "1rem", borderColor: "#ffb585" }}
              className="fansRank-oneToThree-avatar-border"
            >
              <Avatar img={data[2].thumb} size={1} uuid={data[2].uuid} />
            </div>
            <img className="fansRank-oneToThree-avatar-num" src={no3} />
          </div>
          <p>{data[2].name}</p>
          <span>加入{data[2].num}人</span>
        </ClickBtn>
      </div>
    );
  };
  return (
    <div className={"featured-swiper-item"}>
      {loading ? (
        <Loading show text={"正在获取数据..."} overSize={false} size={25} />
      ) : data.length > 0 ? (
        <ScrollArea ListData={data} downRefresh={false}>
          <div style={{ height: "1rem" }} />
          {oneToThree()}
          {data.map((item, index) => {
            if (index < 3) {
              return null;
            }
            return <RankItem key={index} item={item} index={index} type={1} />;
          })}
          <div style={{ height: "30px" }} />
        </ScrollArea>
      ) : (
        <NoData />
      )}
    </div>
  );
};

const RankItem = (props) => {
  const { item, index, type } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const personRef = useRef(null);
  useEffect(() => {
    if (!personRef.current) {
      return;
    }
    const personHammer = new Hammer(personRef.current);
    personHammer.on("tap", toUserPage);
    return () => {
      personHammer.off("tap", toUserPage);
    };
  }, [personRef.current]);
  const toUserPage = () => {
    const stackKey = `userpage-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "userpage",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <UserPage stackKey={stackKey} uuid={item.uuid} />
          </StackPage>
        ),
      },
    });
  };
  const toFansGroup = () => {
    const stackKey = `FansGroup-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "FansGroup",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <FansGroup stackKey={stackKey} id={item.id} />
          </StackPage>
        ),
      },
    });
  };

  return (
    <div className="RankItem">
      <div className="RankItem-left">
        <span>{index + 1}</span>
        <Avatar img={item.thumb} uuid={item.uuid} />
        <div className="RankItem-left-name" ref={personRef}>
          <p>{item.name}</p>
          <span>{type == 1 ? `加入${item.num}人` : item.date}</span>
        </div>
      </div>
      <ClickBtn onTap={toFansGroup}>
        <div
          className={`RankItem-btn ${item.hasJoin ? "RankItem-btn-join" : ""}`}
        >
          {item.hasJoin ? "已加入" : "加入粉丝团"}
        </div>
      </ClickBtn>
    </div>
  );
};

const News = (props) => {
  const { current } = props;
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState([]);
  const [loadingMore, setLoadingMore] = useState({ a: true });
  let page = 1;
  useEffect(() => {
    if (current == 1 && data.length == 0) {
      getData("init");
    }
  }, [current]);
  const getData = (status) => {
    if (!loadingMore.a) return;
    if (!status) {
      page++;
    }
    getNewstRank({ page: page })
      .then((res) => {
        // console.log("getNewstRank=>", page, res);
        setLoading(false);
        if (res.data.length > 0) {
          setData((pre) => [...pre, ...res.data]);
        } else {
          if (page == 1) {
            setData([]);
          }
          loadingMore.a = false;
          setLoadingMore({ ...loadingMore });
        }
      })
      .catch(() => {
        setLoading(false);
      });
  };
  return (
    <div className="fansRank-news">
      {loading ? (
        <Loading show text={"正在获取数据..."} overSize={false} size={25} />
      ) : data.length > 0 ? (
        <ScrollArea
          ListData={data}
          onScrollEnd={getData}
          loadingMore={loadingMore.a}
        >
          {data.map((item, index) => {
            return <RankItem item={item} key={index} index={index} type={2} />;
          })}
          <div style={{ height: "30px" }} />
        </ScrollArea>
      ) : (
        <NoData />
      )}
    </div>
  );
};
