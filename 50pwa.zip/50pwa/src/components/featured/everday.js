import React, { useEffect, useMemo, useRef, useState } from "react";
import Hammer from "hammerjs";
import StackStore from "../../store/stack";
import BackHeader from "../backHeader";
import ScrollArea from "../scrollarea";
import "../../resources/css/everyday.less";
import Emit from "../../libs/eventEmitter";
import calendarIcon from "../../resources/img/public/calendar.png";
import chuangIcon from "../../resources/img/public/chuang.png";
import shareIcon from "../../resources/img/public/share.png";
import Loading from "../loading";
import NoData from "../noData";
import ShareLayer from "../shareLayer";
import Avatar from "../avatar";
import { getEveryDay } from "../../libs/http";
import Simg from "../simg";
import VideoDetail from "../videoDetail";
import UserPage from "../category/user_page";
import StackPage from "../stackpage";
import globalVar from "../../libs/globalVar";
export default props => {
  const { stackKey } = props;
  const [loading, setLoading] = useState(true);
  const [showLayer, setShowLayer] = useState(false);
  const [data, setData] = useState([]);
  const [loadingMore, setLoadingMore] = useState({ a: true });
  const [shareVideoInfo, setShareVideoInfo] = useState(null);
  const [stacks] = StackStore.useGlobalState("stacks");
  let page = 1;
  useEffect(() => {
    getData("init");
  }, []);
  const getData = status => {
    if (!loadingMore.a) return;
    if (!status) {
      page++;
    }
    getEveryDay({ page: page })
      .then(res => {
        // console.log("getEveryDay=>", page, res);
        setLoading(false);
        if (res.data && res.data.list && res.data.list.length > 0) {
          setData(pre => [...pre, res.data]);
        } else {
          if (page == 1) {
            setData([]);
          }
          loadingMore.a = false;
          setLoadingMore({ ...loadingMore });
        }
      })
      .catch(() => {
        setLoading(false);
      });
  };
  return (
    <div className="page-content-flex">
      <BackHeader
        stackKey={stackKey}
        title={"每日精选"}
        rightBtn={() => {
          return (
            <img
              className="calendarIcon"
              style={{ opacity: 0 }}
              src={calendarIcon}
            />
          );
        }}
      />
      {loading ? (
        <Loading show text={"正在获取数据..."} overSize={false} size={16} />
      ) : data.length > 0 ? (
        <ScrollArea
          ListData={data.length}
          onScrollEnd={getData}
          loadingMore={loadingMore.a}
          pullDonRefresh={() => {
            page = 1;
            loadingMore.a = true;
            setData([]);
            setLoading(true);
            setLoadingMore({ ...loadingMore });
            getData("init");
          }}
        >
          {data.map((item, index) => {
            return (
              <div key={index}>
                <div className="every-title">{item.info.title}</div>
                <div>
                  {item.list.length > 0 &&
                    item.list.map((k, i) => {
                      return (
                        <Card
                          key={i}
                          item={k}
                          onShare={info => {
                            setShareVideoInfo(info);
                            setShowLayer(true);
                          }}
                        />
                      );
                    })}
                </div>
              </div>
            );
          })}
          <div style={{ height: "30px" }} />
        </ScrollArea>
      ) : (
        <NoData />
      )}
      <ShareLayer
        show={showLayer}
        info={shareVideoInfo}
        onTap={() => {
          setShowLayer(false);
        }}
      />
    </div>
  );
};

const Card = props => {
  const { onShare, item } = props;
  const coverRef = useRef(null);
  const nameRef = useRef(null);
  const shareRef = useRef(null);
  const [stacks] = StackStore.useGlobalState("stacks");
  useEffect(() => {
    if (!coverRef.current) {
      return;
    }
    const coverHammer = new Hammer(coverRef.current);
    const nameHammer = new Hammer(nameRef.current);
    const shareHammer = new Hammer(shareRef.current);
    coverHammer.on("tap", toDetail);
    nameHammer.on("tap", toUserDetail);
    shareHammer.on("tap", toShare);
    return () => {
      coverHammer.off("tap", toDetail);
      nameHammer.off("tap", toUserDetail);
      shareHammer.off("tap", toShare);
    };
  }, [coverRef.current]);
  const toDetail = () => {
    const stackKey = `VideoDetail-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "VideoDetail",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <VideoDetail stackKey={stackKey} id={item.id} />
          </StackPage>
        )
      }
    });
  };
  const toUserDetail = () => {
    const stackKey = `userpage-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "userpage",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <UserPage stackKey={stackKey} uuid={item.member.uuid} />
          </StackPage>
        )
      }
    });
  };
  const toShare = () => {
    onShare && onShare(item);
  };
  return (
    <div className="every-item">
      <div className="every-item-cover" ref={coverRef}>
        <Simg src={item.thumb_cover} />
        <span>{item.duration_str}</span>
      </div>
      <div className="every-item-bottom">
        <div className="every-item-bottom-row" ref={nameRef}>
          <Avatar
            boxClass="every-item-bottom-avatar"
            img={item.member.thumb}
            isCreater={item.member.auth_status}
            uuid={item.member.uuid}
          />
          <div className="every-item-bottom-name">
            <p>{item.title}</p>
            <span>{item.member.nickname}</span>
          </div>
        </div>
        <img ref={shareRef} className="every-item-share" src={shareIcon} />
      </div>
    </div>
  );
};
