import React, {useEffect, useMemo, useRef, useState} from "react";
import Hammer from "hammerjs";
import StackStore from "../../store/stack";
import SearchHeader from "../searchHeader";
import ScrollArea from "../scrollarea";
import WebView from "../webview";
import playIcon from "../../resources/img/public/play.png";
import likeIcon from "../../resources/img/public/like.png";
import talkIcon from "../../resources/img/public/talk.png";
import shareIcon from "../../resources/img/public/share.png";
import featuredIcon from "../../resources/img/public/featured.png";
import fansIcon from "../../resources/img/public/fans.png";
import pindan from "../../resources/img/public/pindan.png";
import pintuan from "../../resources/img/public/pintuan.png";
import categoryIcon from "../../resources/img/public/categoryIcon.png";
import rightIcon from "../../resources/img/public/icon_mine_check_more.png";

import Avatar from "../avatar";
import VideoDetail from "../videoDetail";
import StackPage from "../stackpage";
import Loading from "../loading";
import NoData from "../noData";
import ScrollH from "../horizontal_scroller";
import FocusList from "./focusList";
import HejiList from "./hejiList";
import Pinduoduo from "./pinduoduo";
import FansRank from "./fansRank";
import PinduoduoVideoDetail from "../pinduoduoVideoDetail";
import Simg from "../simg";
import {ShareLayer} from "../pinduoduoVideoDetail";
import UserPage from "../category/user_page";
import ClickBtn from "../clickBtn";

import {featuredTab, getFeatureList, followUp, getHomeNewList} from "../../libs/http";

import {Swiper, SwiperSlide} from "swiper/react";
import "swiper/swiper.min.css";
import "swiper/components/pagination/pagination.min.css";
import {Controller} from "swiper";
import SwiperCore, {Pagination, Autoplay} from "swiper/core";
import Emit from "../../libs/eventEmitter";
import {TwoColumnsVideo} from "./twoColumnsVideo";
import Cartoon from "../cartoon";
import CartoonDetail from "../cartoon/cartoonDetail";
import CartoonView from "../cartoon/cartoonView";

// install Swiper modules
SwiperCore.use([Pagination, Autoplay, Controller]);
export default (props) => {
  const {isVisible} = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const [tabIndex, setTabIndex] = useState(0);
  const [controlledSwiper, setControlledSwiper] = useState(null);
  const [navs, setNavs] = useState([]);
  const [showShare, setShowShare] = useState(false);
  const [shareVideoInfo, setShareVideoInfo] = useState(null);

  useEffect(() => {
    getTabs();
  }, []);

  useEffect(() => {
    Emit.on("SHARE_VIDEO", onShare);
    return () => {
      Emit.off("SHARE_VIDEO", onShare);
    };
  }, [showShare, shareVideoInfo]);

  const onShare = (info) => {
    setShowShare(true);
    setShareVideoInfo(info);
  };

  const getTabs = () => {
    featuredTab().then((res) => {
      if (res && res.data && res.data.length > 0) {
        const ary = res.data.filter((e) => e.type != "small");
        setNavs(ary);
      }
      // console.log("featuredTab", res);
    });
  };

  const renderTab = () => {
    if (navs.length == 0) {
      return null;
    }
    return (
      <div className="featured-tab">
        <div>
          <ScrollH>
            {navs.map((item, index) => {
              return (
                <TabItem
                  item={item}
                  key={index}
                  index={index}
                  tabIndex={tabIndex}
                  onTap={(i) => {
                    setTabIndex(i);
                    controlledSwiper.slideTo(index);
                  }}
                />
              );
            })}
          </ScrollH>
        </div>
        <img
          src={categoryIcon}
          onClick={() => {
            Emit.emit("CHANGE_HOME_TAB", "发现", {defaultTab: 1});
          }}
        />
      </div>
    );
  };


  return (
    <div
      className={`positioned-container ${isVisible ? "visible" : "hide"}`}
      style={{
        opacity: isVisible ? "1" : "0",
      }}
    >
      <SearchHeader/>
      {renderTab()}
      {navs.length > 0 ? (
        <Swiper
          initialSlide={1}
          className={"featured-swiper"}
          controller={{control: controlledSwiper}}
          onSwiper={setControlledSwiper}
          onSlideChange={(e) => {
            setTabIndex(e.activeIndex);
          }}
        >
          {navs.map((item, index) => {
            return (
              <SwiperSlide key={index}>
                <SwiperTabItem
                  index={index}
                  current={tabIndex}
                  tabData={item}
                />
              </SwiperSlide>
            );
          })}
        </Swiper>
      ) : (
        <Loading show text={"正在获取数据..."} overSize={false} size={25}/>
      )}
      <ShareLayer
        show={showShare}
        info={shareVideoInfo}
        onClose={() => {
          setShowShare(false);
        }}
      />
    </div>
  );
};
// 关注-组键

const AVItem = (props) => {
  const {data} = props;
  const shareRef = useRef(null);
  useEffect(() => {
    if (!shareRef.current) {
      return;
    }
    const shareHammer = new Hammer(shareRef.current);
    shareHammer.on("tap", onShare);
    return () => {
      shareHammer.off("tap", onShare);
    };
  }, [shareRef.current]);
  const onShare = () => {
    Emit.emit("SHARE_VIDEO", data);
  };
  const detailRef = useRef(null);
  const [stacks] = StackStore.useGlobalState("stacks");
  useEffect(() => {
    if (!detailRef.current) {
      return;
    }
    const detailHammer = new Hammer(detailRef.current);
    detailHammer.on("tap", toDetail);
    return () => {
      detailHammer.off("tap", toDetail);
    };
  }, [detailRef.current]);
  const toDetail = () => {
    const stackKey = `VideoDetail-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "VideoDetail",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{zIndex: stacks.length + 2}}
          >
            <VideoDetail stackKey={stackKey} id={data.id}/>
          </StackPage>
        ),
      },
    });
  };
  const personRef = useRef(null);
  useEffect(() => {
    if (!personRef.current) {
      return;
    }
    const personHammer = new Hammer(personRef.current);
    personHammer.on("tap", toUserPage);
    return () => {
      personHammer.off("tap", toUserPage);
    };
  }, [personRef.current]);
  const toUserPage = () => {
    const stackKey = `userpage-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "userpage",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{zIndex: stacks.length + 2}}
          >
            <UserPage stackKey={stackKey} uuid={data.member.uuid}/>
          </StackPage>
        ),
      },
    });
  };
  return (
    <div className="featured-avItem">
      <div className="thin-line"/>
      <div className="featured-avItem-header">
        <Avatar
          img={data.member.thumb}
          isCreater={data.member.auth_status}
          uuid={data.member.uuid}
        />
        <div className="featured-avItem-name" ref={personRef}>
          <p>{data.member.nickname}</p>
          <span>{data.created_date}</span>
        </div>
      </div>
      <div className="featured-avItem-cover" ref={detailRef}>
        <div className="avItem-linear"/>
        <div className="avItem-cover">
          <Simg src={data.thumb_cover}/>
        </div>
        <div className="avItem-layer">
          <p>{data.title}</p>
          <div>
            <span>{data.count_play_str}</span>
            <span className="avItem-time">{data.duration_str}</span>
          </div>
        </div>
        <div className="avItem-layerCenter">
          <img src={playIcon}/>
        </div>
      </div>
      <div className="featured-avItem-bottom">
        <div className="featured-avItem-bottom-layer">
          <ClickBtn className="featured-avItem-bottom-layer" onTap={toDetail}/>
        </div>
        <div className="avItem-bottom-item">
          <img src={likeIcon}/>
          <span>{data.count_like}</span>
        </div>
        <div className="avItem-bottom-item">
          <img src={talkIcon}/>
          <span>{data.count_comment}</span>
        </div>
        <div
          className="avItem-bottom-item"
          style={{zIndex: 3}}
          ref={shareRef}
        >
          <img src={shareIcon}/>
          <span>分享</span>
        </div>
      </div>
    </div>
  );
};

const FocusOn = (props) => {
  const {idol} = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const avatar = (item, index) => {
    return (
      <div className="focusOn-info" key={index}>
        <Avatar
          size={1.35}
          boxClass="focusOn-avatarbox"
          avatarClass="focusOn-avatar"
          iconClass="focusOn-chuang"
          img={item.thumb}
          uuid={item.uuid}
          isCreater={item.auth_status}
        />
        <p>{item.nickname}</p>
      </div>
    );
  };
  return (
    <div className="focusOn">
      <div
        className="focusOn-title"
        onClick={() => {
          const stackKey = `FocusList-${new Date().getTime()}`;
          StackStore.dispatch({
            type: "push",
            payload: {
              name: "FocusList",
              element: (
                <StackPage
                  stackKey={stackKey}
                  key={stackKey}
                  style={{zIndex: stacks.length + 2}}
                >
                  <FocusList stackKey={stackKey}/>
                </StackPage>
              ),
            },
          });
        }}
      >
        我的偶像 <img src={rightIcon}/>
      </div>
      <div className="focusOn-avatarList">
        {idol.map((item, index) => {
          return avatar(item, index);
        })}
      </div>
    </div>
  );
};

// 推荐组建
const RecommendItem = (props) => {
  const {data} = props;
  const likeRef = useRef(null);
  const [isLike, setIslike] = useState(data.member.is_follow);
  const shareRef = useRef(null);
  useEffect(() => {
    if (!shareRef.current) {
      return;
    }
    const shareHammer = new Hammer(shareRef.current);
    shareHammer.on("tap", onShare);
    return () => {
      shareHammer.off("tap", onShare);
    };
  }, [shareRef.current]);
  const onShare = () => {
    Emit.emit("SHARE_VIDEO", data);
  };
  useEffect(() => {
    if (!likeRef.current) {
      return;
    }
    const likeHammer = new Hammer(likeRef.current);
    likeHammer.on("tap", onFocus);
    return () => {
      likeHammer.off("tap", onFocus);
    };
  }, [likeRef.current, isLike]);
  const onFocus = () => {
    setIslike(!isLike);
    followUp({follow_uuid: data.member.uuid}).then((res) => {
      // console.log(res);
    });
  };
  const detailRef = useRef(null);
  const [stacks] = StackStore.useGlobalState("stacks");
  useEffect(() => {
    if (!detailRef.current) {
      return;
    }
    const detailHammer = new Hammer(detailRef.current);
    detailHammer.on("tap", toDetail);
    return () => {
      detailHammer.off("tap", toDetail);
    };
  }, [detailRef.current]);
  const toDetail = () => {
    const stackKey = `VideoDetail-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "VideoDetail",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{zIndex: stacks.length + 2}}
          >
            <VideoDetail stackKey={stackKey} id={data.id}/>
          </StackPage>
        ),
      },
    });
  };
  const personRef = useRef(null);
  useEffect(() => {
    if (!personRef.current) {
      return;
    }
    const personHammer = new Hammer(personRef.current);
    personHammer.on("tap", toUserPage);
    return () => {
      personHammer.off("tap", toUserPage);
    };
  }, [personRef.current]);
  const toUserPage = () => {
    const stackKey = `userpage-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "userpage",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{zIndex: stacks.length + 2}}
          >
            <UserPage stackKey={stackKey} uuid={data.member.uuid}/>
          </StackPage>
        ),
      },
    });
  };
  return (
    <div className="featured-avItem" style={{border: "none"}}>
      <div className="featured-avItem-cover" ref={detailRef}>
        <div className="avItem-cover">
          <Simg src={data.thumb_cover}/>
        </div>
        <div className="avItem-linear"/>
        <div className="avItem-layer">
          <p>{data.title}</p>
          <div>
            <span>{data.count_play_str}</span>
            <span className="avItem-time">{data.duration_str}</span>
          </div>
        </div>
        <div className="avItem-layerCenter">
          <img src={playIcon}/>
        </div>
      </div>
      <div className="featured-avItem-header recommendItem-header">
        <div className="recommendItem-header-row">
          <Avatar
            img={data.member.thumb_url}
            isCreater={data.member.auth_status}
            uuid={data.member.uuid}
          />
          {/* <div className="featured-avItem-avatar">
            <img className="avItem-avatar" src={imgUrl} />
            <img className="avItem-chuang" src={chuangIcon} />
          </div> */}
          <div className="featured-avItem-name" ref={personRef}>
            <p>{data.member.nickname}</p>
            <span>
              {data.member.taggroup_name}创作者
              <span className="recommendItem-point">·</span>
              {data.member.followed_count}粉丝
            </span>
          </div>
          <div
            className={`recommendItem-focus ${isLike ? "isLike" : ""}`}
            ref={likeRef}
          >
            <span className="recommendItem-point">·</span>
            {isLike ? "已关注" : "关注"}
          </div>
        </div>
        <div className="featured-avItem-bottom" style={{flex: 1}}>
          <ClickBtn
            className="avItem-bottom-item"
            styles={{flex: 1, justifyContent: "flex-end"}}
            onTap={toDetail}
          >
            <img src={talkIcon}/>
            <span>{data.count_comment}</span>
          </ClickBtn>
          <div className="avItem-bottom-item" ref={shareRef}>
            <img src={shareIcon}/>
          </div>
        </div>
      </div>
    </div>
  );
};
// 拼多多组建
const PinduoduoItem = (props) => {
  const {data} = props;
  const pinduoduoRef = useRef(null);
  const [stacks] = StackStore.useGlobalState("stacks");
  useEffect(() => {
    if (!pinduoduoRef.current) {
      return;
    }
    const pinduoduoHammer = new Hammer(pinduoduoRef.current);
    pinduoduoHammer.on("tap", toPinduoduo);
    return () => {
      pinduoduoHammer.off("tap", toPinduoduo);
    };
  }, [pinduoduoRef.current]);
  const toPinduoduo = () => {
    const stackKey = `PinduoduoVideoDetail-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "PinduoduoVideoDetail",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{zIndex: stacks.length + 2}}
          >
            <PinduoduoVideoDetail stackKey={stackKey} id={data.id}/>
          </StackPage>
        ),
      },
    });
  };
  return (
    <div className="featured-avItem pinduoduo-item" ref={pinduoduoRef}>
      <div className="featured-avItem-cover">
        <div className="avItem-cover">
          <Simg src={data.thumb_cover}/>
        </div>
        <div className="avItem-layer">
          <p/>
          <div>
            <span>{data.count_play_str}</span>
            <span className="avItem-time">{data.duration_str}</span>
          </div>
        </div>
      </div>
      <p className="pinduoduo-title">{data.title}</p>
    </div>
  );
};

const SwiperItem = (props) => {
  const {item} = props;
  const itemRef = useRef(null);
  const [stacks] = StackStore.useGlobalState("stacks");
  const _width = document.body.clientWidth;
  useEffect(() => {
    if (!itemRef.current) {
      return;
    }
    const itemHammer = new Hammer(itemRef.current);
    itemHammer.on("tap", onClick);
    return () => {
      itemHammer.off("tap", onClick);
    };
  }, [itemRef.current]);
  const onClick = () => {
    //跳外部
    if ((item.type == 1 || item.type == 2) && item.url) {
      toWebView(item.url, "");
    }
  };
  const toWebView = (url, title) => {
    window.open(url, "_blank");
  };
  return (
    <div
      style={{
        width: _width,
        height: _width * 0.35,
      }}
      ref={itemRef}
    >
      <Simg className="no-hammers" src={item.img_url}/>
    </div>
  );
};

const SwiperTabItem = (props) => {
  const {index, current, tabData} = props;
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState([]);
  const [loadingMore, setLoadingMore] = useState({a: true});
  const [banner, setBanner] = useState(null);
  const [widget, setWidget] = useState(null);
  const [idol, setIdol] = useState(null);
  const [stacks] = StackStore.useGlobalState("stacks");
  let page = 1;
  let limit = 10;
  useEffect(() => {
    if (index == current && data.length == 0) {
      getData("init");
    }
  }, [current]);
  const getData = (status) => {
    if (!loadingMore.a) return;
    if (!status) {
      page++;
    }

    if (tabData.type === "v2206_list_with_mv") {
      getHomeNewList({page: page, ...tabData.params, size: 10, from: "latest", taggroup_id: 0})
        .then(res => {
          if (!banner && res.data.banner) {
            setBanner(res.data.banner);
          }
          if (!widget && res.data.widget) {
            setWidget(res.data.widget);
          }
          if (res.data.idol) {
            setIdol(res.data.idol);
          }
          setLoading(false);
          if (res.data.list.length > 0) {
            setData((pre) => [...pre, ...res.data.list]);
          } else {
            if (page == 1) {
              setData([]);
            }
            loadingMore.a = false;
            setLoadingMore({...loadingMore});
          }
        })
        .catch(() => {
          setLoading(false);
        });
      return;
    }

    getFeatureList(tabData.api, {page: page, ...tabData.params})
      .then((res) => {
        if (!banner && res.data.banner) {
          setBanner(res.data.banner);
        }
        if (!widget && res.data.widget) {
          setWidget(res.data.widget);
        }
        if (res.data.idol) {
          setIdol(res.data.idol);
        }
        setLoading(false);
        if (res.data.list.length > 0) {
          setData((pre) => [...pre, ...res.data.list]);
        } else {
          if (page == 1) {
            setData([]);
          }
          loadingMore.a = false;
          setLoadingMore({...loadingMore});
        }
      })
      .catch(() => {
        setLoading(false);
      });
  };

  const renderHeader = () => {
    if (tabData.type == "follow" && idol && idol.length > 0) {
      return <FocusOn idol={idol}/>;
    }
    if (tabData.type == "recommend") {
      return (
        <div>
          {renderSwiper()}
          {widget && widget.length > 0 && <RenderFeatured widget={widget}/>}
        </div>
      );
    }
    // if (tabData.type == "featuredAv" && widget && widget.length > 0) {
    //   return <RenderPinduoduo widget={widget} />;
    // }
    return renderSwiper();
  };
  const renderSwiper = () => {
    if (!banner || banner.length == 0) {
      return null;
    }
    return (
      <Swiper
        pagination
        autoplay={{
          delay: 3000,
          disableOnInteraction: false,
        }}
        className="featured-wiper"
      >
        {banner.map((item, index) => {
          return (
            <SwiperSlide key={index}>
              <SwiperItem item={item}/>
            </SwiperSlide>
          );
        })}
      </Swiper>
    );
  };

  return (
    <div className={"featured-swiper-item"}>
      {loading ? (
        <Loading show text={"正在获取数据..."} overSize={false} size={25}/>
      ) : data.length > 0 ? (
        <ScrollArea
          ListData={data}
          onScrollEnd={getData}
          loadingMore={loadingMore.a}
          pullDonRefresh={() => {
            page = 1;
            loadingMore.a = true;
            setData([]);
            setLoading(true);
            setLoadingMore({...loadingMore});
            getData("init");
          }}
        >
          {renderHeader()}
          {data.map((item, index) => {
            if (tabData.type === "v2206_list_with_mv") {
              return <TwoColumnsVideo data={item} key={`TwoColumnsVideo-${index}`}/>;
            }
            if (tabData.type == "follow") {
              return <AVItem data={item} key={`avitem-${index}`}/>;
            }
            if (tabData.type == "featuredAv") {
              return (
                <div key={index}>
                  <div className="PinduoduoTitle" key={`avitem-${index}`}>
                    {item.date}
                  </div>
                  {item.list.map((k, i) => {
                    return (
                      <PinduoduoItem data={k} key={`PinduoduoItem-${i}`}/>
                    );
                  })}
                </div>
              );
            }
            return <RecommendItem data={item} key={`RecommendItem-${index}`}/>;
          })}
          <div style={{height: "30px"}}/>
        </ScrollArea>
      ) : (
        <NoData/>
      )}
    </div>
  );
};

const RenderFeatured = (props) => {
  const {widget} = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const hejiRef = useRef(null);
  const fansRef = useRef(null);
  const cartoonsRef = useRef(null);
  useEffect(() => {
    if (!hejiRef.current) {
      return;
    }
    const hejiHammer = new Hammer(hejiRef.current);
    const fansHammer = new Hammer(fansRef.current);
    const cartoonHammer = new Hammer(cartoonsRef.current);
    hejiHammer.on("tap", toHeji);
    fansHammer.on("tap", toFans);
    cartoonHammer.on("tap", toCartoon);
    return () => {
      hejiHammer.off("tap", toHeji);
      fansHammer.off("tap", toFans);
      cartoonHammer.off("tap", toCartoon);
    };
  }, [hejiRef.current, fansRef.current, cartoonsRef.current]);
  const toHeji = () => {
    const stackKey = `HejiList-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "HejiList",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{zIndex: stacks.length + 2}}
          >
            <HejiList stackKey={stackKey}/>
          </StackPage>
        ),
      },
    });
  };
  const toFans = () => {
    const stackKey = `FansRank-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "FansRank",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{zIndex: stacks.length + 2}}
          >
            <FansRank stackKey={stackKey}/>
          </StackPage>
        ),
      },
    });
  };
  const toCartoon = () => {
    const stackKey = `Cartoon-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "Cartoon",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{zIndex: stacks.length + 2}}
          >
            <Cartoon stackKey={stackKey}/>
          </StackPage>
        ),
      },
    });
  };
  return (
    <div className="featured-part">
      <div className="featured-part-item column heji" ref={hejiRef}>
        {/*<img src={featuredIcon}/>*/}
        <div>
          {/*<span>{widget[0].name}</span>*/}
          <span>{widget[0].tip}</span>
        </div>
      </div>
      <div className="featured-part-item column fensiruan" ref={fansRef}>
        {/*<img src={fansIcon}/>*/}
        <div>
          {/*<span>{widget[1].name}</span>*/}
          <span>{widget[1].tip}</span>
        </div>
      </div>
      <div className="featured-part-item column chengrenmanhua" ref={cartoonsRef}>
        {/*<img src={fansIcon}/>*/}
        <div>
          {/*<span>{widget[1].name}</span>*/}
          <span>{widget[1].tip}</span>
        </div>
      </div>
    </div>
  );
};

const RenderPinduoduo = (props) => {
  const {widget} = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const pinduoduoRef = useRef(null);
  const pinduoduo1Ref = useRef(null);
  useEffect(() => {
    if (!pinduoduoRef.current) {
      return;
    }
    const pinduoduoHammer = new Hammer(pinduoduoRef.current);
    const pinduoduo1Hammer = new Hammer(pinduoduo1Ref.current);
    pinduoduoHammer.on("tap", toPinduoduo(1));
    pinduoduo1Hammer.on("tap", toPinduoduo(0));
    return () => {
      pinduoduoHammer.off("tap", toPinduoduo(1));
      pinduoduo1Hammer.off("tap", toPinduoduo(0));
    };
  }, [pinduoduoRef.current, pinduoduo1Ref.current]);
  const toPinduoduo = (type) => () => {
    const stackKey = `Pinduoduo-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "Pinduoduo",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{zIndex: stacks.length + 2}}
          >
            <Pinduoduo stackKey={stackKey} type={type}/>
          </StackPage>
        ),
      },
    });
  };
  return (
    <div className="featured-part">
      <div className="featured-part-item" ref={pinduoduoRef}>
        <img src={pindan}/>
        <div>
          <span>{widget[1].name}</span>
          <span>{widget[1].tip}</span>
        </div>
      </div>
      <div style={{height: 20, width: 1, backgroundColor: "#404040"}}/>
      <div className="featured-part-item" ref={pinduoduo1Ref}>
        <img src={pintuan}/>
        <div>
          <span>{widget[0].name}</span>
          <span>{widget[0].tip}</span>
        </div>
      </div>
    </div>
  );
};

const TabItem = (props) => {
  const {item, index, tabIndex, onTap} = props;
  const itemRef = useRef(null);
  useEffect(() => {
    if (!itemRef.current) {
      return;
    }
    const itemHammer = new Hammer(itemRef.current);
    itemHammer.on("tap", onClick);
    return () => {
      itemHammer.off("tap", onClick);
    };
  }, [itemRef.current, tabIndex]);
  const onClick = () => {
    // console.log(tabIndex, index);
    if (tabIndex != index) {
      onTap && onTap(index);
    }
  };
  return (
    <span
      className={`featured-tab-item ${
        index == tabIndex ? "featured-tab-item-active" : ""
      }`}
      key={index}
      ref={itemRef}
    >
      {item.name}
    </span>
  );
};
