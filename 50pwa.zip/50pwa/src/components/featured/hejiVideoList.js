import React, { useEffect, useMemo, useRef, useState } from "react";
import Hammer from "hammerjs";
import "../../resources/css/focusList.less";
import ScrollArea from "../scrollarea";
import StackStore from "../../store/stack";
import BackHeader from "../backHeader";
import Loading from "../loading";
import NoData from "../noData";
import Avatar from "../avatar";
import { SelectVideo } from "../weitie/qiupian/qiupian_card";
import "../../resources/css/dashang.less";
import Emit from "../../libs/eventEmitter";
import StackPage from "../stackpage";
import { getCompilationDetail } from "../../libs/http";
import Simg from "../simg";

export default (props) => {
  const { stackKey, title, id } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState([]);
  const [loadingMore, setLoadingMore] = useState({ a: true });
  let page = 1;
  let limit = 10;
  useEffect(() => {
    getData("init");
  }, []);
  const getData = (status) => {
    if (!loadingMore.a) return;
    if (!status) {
      page++;
    }
    getCompilationDetail({ page: page, id, limit })
      .then((res) => {
        // console.log("getCompilationDetail=>", page, res);
        setLoading(false);
        if (res.data.length > 0) {
          setData((pre) => [...pre, ...res.data]);
        } else {
          if (page == 1) {
            setData([]);
          }
          loadingMore.a = false;
          setLoadingMore({ ...loadingMore });
        }
      })
      .catch(() => {
        setLoading(false);
      });
  };
  return (
    <div className="page-content-flex">
      <BackHeader
        stackKey={stackKey}
        center={() => {
          return (
            <div className="hejiVideoList-title">
              <p>{title}</p>
            </div>
          );
        }}
        right={() => {
          return <div style={{ width: "1.2rem" }} />;
        }}
      />
      {loading ? (
        <Loading show text={"正在获取数据..."} overSize={false} size={25} />
      ) : data.length > 0 ? (
        <ScrollArea
          ListData={data}
          // onScrollEnd={getData}
          // loadingMore={loadingMore.a}
        >
          {data.map((item, index) => {
            return <SelectVideo data={item} key={index} />;
          })}
          <div style={{ height: "30px" }} />
        </ScrollArea>
      ) : (
        <NoData />
      )}
    </div>
  );
};
