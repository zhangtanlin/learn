import React, {useEffect, useRef, useState} from "react";
import Hammer from "hammerjs";
import Emit from "../../../libs/eventEmitter";
import StackStore from "../../../store/stack";
import StackPage from "../../stackpage";
import VideoDetail from "../../videoDetail";
import UserPage from "../../category/user_page";
import Avatar from "../../avatar";
import Simg from "../../simg";
import playIcon from "../../../resources/img/public/play.png";
import ClickBtn from "../../clickBtn";
import likeIcon from "../../../resources/img/public/like.png";
import talkIcon from "../../../resources/img/public/talk.png";
import shareIcon from "../../../resources/img/public/share.png";
import "../../../resources/css/twoColumnsVideo.less"
import {followUp} from "../../../libs/http";
import {formatNumber} from "../../../libs/utils";
import eyeOpen from "../../../resources/img/public/eye-open.png"
import zan from "../../../resources/img/public/zan.png"
import coin from "../../../resources/img/public/coin.png"

export const TwoColumnsVideo = (props) => {
  const {data} = props;
  const likeRef = useRef(null);
  const [isLike, setIslike] = useState(data.is_follow);
  const shareRef = useRef(null);
  useEffect(() => {
    if (!shareRef.current) {
      return;
    }
    const shareHammer = new Hammer(shareRef.current);
    shareHammer.on("tap", onShare);
    return () => {
      shareHammer.off("tap", onShare);
    };
  }, [shareRef.current]);
  const onShare = () => {
    Emit.emit("SHARE_VIDEO", data);
  };
  useEffect(() => {
    if (!likeRef.current) {
      return;
    }
    const likeHammer = new Hammer(likeRef.current);
    likeHammer.on("tap", onFocus);
    return () => {
      likeHammer.off("tap", onFocus);
    };
  }, [likeRef.current, isLike]);
  const onFocus = () => {
    setIslike(!isLike);
    followUp({follow_uuid: data.uuid}).then((res) => {
      // console.log(res);
    });
  };
  const detailRef = useRef(null);
  const [stacks] = StackStore.useGlobalState("stacks");
  useEffect(() => {
    if (!detailRef.current) {
      return;
    }
    const detailHammer = new Hammer(detailRef.current);
    detailHammer.on("tap", toDetail);
    return () => {
      detailHammer.off("tap", toDetail);
    };
  }, [detailRef.current]);
  const toDetail = (id) => {
    const stackKey = `VideoDetail-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push", payload: {
        name: "VideoDetail", element: (<StackPage
          stackKey={stackKey}
          key={stackKey}
          style={{zIndex: stacks.length + 2}}
        >
          <VideoDetail stackKey={stackKey} id={id}/>
        </StackPage>),
      },
    });
  };
  const personRef = useRef(null);
  useEffect(() => {
    if (!personRef.current) {
      return;
    }
    const personHammer = new Hammer(personRef.current);
    personHammer.on("tap", toUserPage);
    return () => {
      personHammer.off("tap", toUserPage);
    };
  }, [personRef.current]);
  const toUserPage = () => {
    const stackKey = `userpage-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push", payload: {
        name: "userpage", element: (<StackPage
          stackKey={stackKey}
          key={stackKey}
          style={{zIndex: stacks.length + 2}}
        >
          <UserPage stackKey={stackKey} uuid={data.uuid}/>
        </StackPage>),
      },
    });
  };
  return (<div className="featured-avItem TwoColumnsVideo" style={{border: "none"}}>
    <div className="featured-avItem-header recommendItem-header">
      <div className="recommendItem-header-row">
        <Avatar
          img={data.thumb_url}
          isCreater={data.auth_status}
          uuid={data.uuid}
        />
        {/* <div className="
        -avItem-avatar">
            <img className="avItem-avatar" src={imgUrl} />
            <img className="avItem-chuang" src={chuangIcon} />
          </div> */}
        <div className="featured-avItem-name" ref={personRef}>
          <p>{data.nickname}</p>
          <span>
              <span className={"TwoColumnsVideo-tag-name"}>{data.taggroup_name}创作者</span>
              <span className="recommendItem-point"></span>
            {formatNumber(data.followed_count)}粉丝
            </span>
        </div>
        <div
          className={`recommendItem-focus ${isLike ? "isLike" : ""}`}
          ref={likeRef}
        >
          {/*<span className="recommendItem-point">·</span>*/}
          {isLike ? "已关注" : "关注"}
        </div>
      </div>
      {/*<div className="featured-avItem-bottom" style={{ flex: 1 }}>*/}
      {/*  <ClickBtn*/}
      {/*    className="avItem-bottom-item"*/}
      {/*    styles={{ flex: 1, justifyContent: "flex-end" }}*/}
      {/*    onTap={toDetail}*/}
      {/*  >*/}
      {/*    <img src={talkIcon} />*/}
      {/*    <span>{data.count_comment}</span>*/}
      {/*  </ClickBtn>*/}
      {/*  <div className="avItem-bottom-item" ref={shareRef}>*/}
      {/*    <img src={shareIcon} />*/}
      {/*  </div>*/}
      {/*</div>*/}
    </div>
    <div className={"TwoColumnsVideo-cover-wrap"}>
      {data.items.map((data, index) => {
        return <div key={index} className="featured-avItem-cover" onClick={() => toDetail(data.id)}>
          <div className="avItem-cover">
            <div className="avItem-linear"/>
            <Simg src={data.thumb_cover}/>
            <div className="avItem-layerCenter">
              <img src={playIcon}/>
            </div>
            <div className={"TwoColumnsVideo-cover-bottom-row"}>
              {data.coins !== 0 && <span>
              <img className={"TwoColumnsVideo-icon"} src={coin}/>
                {data.coins}
            </span>}
              <span className="avItem-time">
              {data.duration_str}
            </span>
            </div>
          </div>
          <div className="avItem-layer">
            <p>{data.title}</p>
            <div>
            <span>
              <img className={"TwoColumnsVideo-icon"} src={eyeOpen}/>
              {data.count_play}
            </span>
              <span className="avItem-time">
              <img className={"TwoColumnsVideo-icon"} src={zan}/>
                {data.count_like}
            </span>
            </div>
          </div>
        </div>
      })}
    </div>
  </div>);
}
