import React, {useEffect, useMemo, useRef, useState} from "react";
import Hammer from "hammerjs";
import StackStore from "../../store/stack";
import BackHeader from "../backHeader";
import searchIcon from "../../resources/img/public/search.png";
import searchBanner from "../../resources/img/public/searchBanner.png";
import inputClose from "../../resources/img/public/input_close.png";
import Avatar from "../avatar";
import ScrollArea from "../scrollarea";
import "../../resources/css/search.less";
import Emit from "../../libs/eventEmitter";
import Simg from "../simg";
import TagList from "./tagList";
import StackPage from "../stackpage";
import Loading from "../loading";
import NoData from "../noData";
import {Swiper, SwiperSlide} from "swiper/react";
import SwiperCore, {Controller} from "swiper";
import VideoDetai from "../videoDetail";
import {
  getSearchHot,
  getSingleStyle,
  getSearchVideo,
  getSearchCreator,
  followUp, searchBookList, searchDatingList,
} from "../../libs/http";
import "swiper/swiper.min.css";
import ClickBtn from "../clickBtn";
import {CartoonItem} from "../cartoon";
import {DatingItem} from "../dating";

SwiperCore.use([Controller]);
export default (props) => {
  const {stackKey} = props;
  const inputRef = useRef(null);
  const clearRef = useRef(null);
  const [showClose, setShowClose] = useState(false);
  const [searchHistory, setSearchHistory] = useState([]);
  const [searching, setSearching] = useState(false);
  const [searchHot, setSearchHot] = useState([]);
  const [singleStyle, setSingleStyle] = useState([]);
  const [searchText, setSearchText] = useState("");
  useEffect(() => {
    if (!clearRef.current) {
      return;
    }
    const clearHammer = new Hammer(clearRef.current);
    clearHammer.on("tap", clearHistory);
    return () => {
      clearHammer.off("tap", clearHistory);
    };
  }, [clearRef.current]);
  useEffect(() => {
    const history = localStorage.getItem("SEARCH_HISTORY_50");
    // console.log("history", history);
    if (history) {
      setSearchHistory(history.split(","));
    }
  }, []);
  const clearHistory = () => {
    setSearchHistory([]);
    localStorage.setItem("SEARCH_HISTORY_50", "");
  };
  const initSearcTagList = () => {
    getSearchHot().then((res) => {
      // console.log("getSearchHot", res.data);
      if (res.status === 200) {
        setSearchHot(res.data);
      }
    });
    getSingleStyle().then((res) => {
      // console.log("hot", res);
      if (res.status === 200) {
        setSingleStyle(res.data);
      }
    });
  };
  useEffect(() => {
    initSearcTagList();
  }, []);
  const close = () => {
    return (
      <img
        src={inputClose}
        className="search-close"
        onClick={() => {
          inputRef.current.value = "";
          setShowClose(false);
          setSearching(false);
        }}
      />
    );
  };
  const renderSearchList = () => {
    // useMemo(
    //   () => (
    return (
      <ScrollArea
        downRefresh={false}
        // ListData={}
      >
        <div className="search-box">
          <div className="search-title">大家在搜</div>
          <div className="search-row">
            {searchHot.map((item, index) => {
              return (
                <Item1
                  key={`search_row_item_${index}`}
                  text={item.name || item}
                  onTap={() => {
                    inputRef.current.value = item.name || item;
                    setSearchText(item.name || item);
                    setSearching(true);
                    setShowClose(true);
                  }}
                />
              );
            })}
          </div>
        </div>
        <div className="search-box" style={{paddingTop: 10}}>
          <div className="search-btw">
            <div className="search-title" style={{margin: 0}}>
              搜索历史
            </div>
            <div ref={clearRef} className="search-clear">
              清除
            </div>
          </div>
          <div className="search-row">
            {searchHistory.length > 0 &&
              searchHistory.map((item, index) => {
                return (
                  <Item1
                    text={item}
                    key={`search_item_tag_${index}`}
                    onTap={() => {
                      inputRef.current.value = item;
                      setSearchText(item);
                      setSearching(true);
                      setShowClose(true);
                    }}
                  />
                );
              })}
          </div>
        </div>
        <ClickBtn
          className="search-banner"
          onTap={() => {
            Emit.emit("changeAlert", {
              _title: "温馨提示",
              _content: "请下载50度灰APP使用上传功能！",
              _submitText: "确定",
              _notDouble: true,
            });
          }}
        >
          <img src={searchBanner}/>
        </ClickBtn>
        <div
          className="search-box"
          style={{paddingTop: 10, paddingRight: 14, paddingBottom: 20}}
        >
          <div className="search-title">热门标签</div>
          <div className="search-row">
            {singleStyle.map((item, index) => {
              return (
                <Item2
                  key={`search_sing_item_${index}`}
                  tagItem={item}
                  onTap={() => {
                    inputRef.current.value = item.name;
                    setSearchText(item.name);
                    setSearching(true);
                    setShowClose(true);
                  }}
                />
              );
            })}
          </div>
        </div>
      </ScrollArea>
    );
    // ),
    // [searchHot, singleStyle, searchHistory, inputRef.current]
    // );
  };
  return (
    <div className="page-content-flex">
      <BackHeader
        stackKey={stackKey}
        style={{}}
        center={() => {
          return (
            <div
              className="searchHeader-input"
              style={{
                // marginLeft: "0.2rem",
                marginRight: "0.4rem",
                height: "0.9rem",
              }}
              onClick={() => {
              }}
            >
              <img src={searchIcon}/>
              <input
                ref={inputRef}
                placeholder="视频｜用户"
                onChange={() => {
                  if (inputRef.current.value && !showClose) {
                    setShowClose(true);
                  } else if (!inputRef.current.value && showClose) {
                    setShowClose(false);
                    setSearching(false);
                  }
                }}
              />
              {showClose && close()}
            </div>
          );
        }}
        rightBtn={() => {
          return (
            <span
              style={{
                color: "white",
                fontSize: "0.4rem",
              }}
              onClick={() => {
                if (inputRef.current.value) {
                  if (
                    typeof searchText === "string"
                      ? inputRef.current.value !== searchText
                      : inputRef.current.value !== searchText.value
                  ) {
                    if (searchHistory.indexOf(inputRef.current.value) == -1) {
                      localStorage.setItem(
                        "SEARCH_HISTORY_50",
                        [...searchHistory, inputRef.current.value].toString()
                      );
                      setSearchHistory([
                        ...searchHistory,
                        inputRef.current.value,
                      ]);
                    }
                    setSearchText(
                      searching
                        ? {value: inputRef.current.value}
                        : inputRef.current.value
                    );
                    setSearching(true);
                  }
                } else {
                  Emit.emit("showToast", {text: "请输入关键字"});
                }
              }}
            >
              搜索
            </span>
          );
        }}
      />
      {searching && !!searchText ? (
        <SearchResult value={searchText}/>
      ) : (
        renderSearchList()
      )}
    </div>
  );
};
const Item1 = (props) => {
  const {text, onTap, id} = props;
  const itemRef = useRef(null);
  useEffect(() => {
    if (!itemRef.current) {
      return;
    }
    const itemHammer = new Hammer(itemRef.current);
    itemHammer.on("tap", onClick);
    return () => {
      itemHammer.off("tap", onClick);
    };
  }, [itemRef.current]);
  const onClick = () => {
    onTap && onTap();
  };
  return (
    <div ref={itemRef} className="search-item1">
      {text}
    </div>
  );
};

const Item2 = (props) => {
  const {tagItem} = props;
  const itemRef = useRef(null);
  const childPanelWidth = document.body.clientWidth;
  const [stacks] = StackStore.useGlobalState("stacks");
  useEffect(() => {
    if (!itemRef.current) {
      return;
    }
    const itemHammer = new Hammer(itemRef.current);
    itemHammer.on("tap", onClick);
    return () => {
      itemHammer.off("tap", onClick);
    };
  }, [itemRef.current]);
  const onClick = () => {
    const stackKey = `TagList-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "TagList",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{zIndex: stacks.length + 2}}
          >
            <TagList stackKey={stackKey} tagItem={tagItem}/>
          </StackPage>
        ),
      },
    });
  };
  return (
    <div
      ref={itemRef}
      className="search-item2"
      style={{
        width: (childPanelWidth - 58) / 4,
      }}
    >
      {tagItem.name}
    </div>
  );
};

const SearchResult = (props) => {
  const {value} = props;
  const navs = [
    {
      title: "视频",
      orderBy: "video",
    },
    {
      title: "用户",
      orderBy: "user",
    },
    {
      title: "漫画",
      orderBy: "cartoon",
    },
    {
      title: "约炮",
      orderBy: "dating",
    },
  ];
  const [tabIndex, setTabIndex] = useState(0);
  const [controlledSwiper, setControlledSwiper] = useState(null);
  return (
    <div className="search-result">
      <div className="search-tab">
        <ClickBtn
          className={tabIndex == 0 ? "active" : ""}
          onTap={() => {
            setTabIndex(0);
            controlledSwiper.slideTo(0);
          }}
        >
          视频
        </ClickBtn>
        <ClickBtn
          className={tabIndex == 1 ? "active" : ""}
          onTap={() => {
            setTabIndex(1);
            controlledSwiper.slideTo(1);
          }}
        >
          用户
        </ClickBtn>
        <ClickBtn
          className={tabIndex == 2 ? "active" : ""}
          onTap={() => {
            setTabIndex(2);
            controlledSwiper.slideTo(2);
          }}
        >
          漫画
        </ClickBtn>
        <ClickBtn
          className={tabIndex == 3 ? "active" : ""}
          onTap={() => {
            setTabIndex(3);
            controlledSwiper.slideTo(3);
          }}
        >
          约炮
        </ClickBtn>
      </div>
      <Swiper
        className={"featured-swiper"}
        controller={{control: controlledSwiper}}
        onSwiper={setControlledSwiper}
        onSlideChange={(e) => {
          setTabIndex(e.activeIndex);
        }}
      >
        {navs.map((item, index) => {
          return (
            <SwiperSlide key={index}>
              <SwiperItem
                show={index === tabIndex}
                orderBy={item.orderBy}
                value={value}
              />
            </SwiperSlide>
          );
        })}
      </Swiper>
    </div>
  );
};

const SwiperItem = (props) => {
  const {show, orderBy, value} = props;
  const [loading, setLoading] = useState(true);
  const [initList, setInitList] = useState(false);
  const [listData, setListData] = useState({
    data: [],
  });
  const [page, setPage] = useState({
    num: 1,
  });
  const [isAll, setIsAll] = useState(false);
  const size = 15;
  let isGetData = false;
  useEffect(() => {
    if (show && !initList) {
      setInitList(true);
    }
  }, [show]);
  useEffect(() => {
    if (typeof value === "object" && show) {
      page.num = 1;
      setLoading(true);
      setListData({data: []});
      setIsAll(false);
      setPage({...page});
      initListData();
    }
  }, [value, show]);
  const initListData = async (_page) => {
    let res;
    isGetData = true;
    switch (orderBy) {
      case "video":
        res = await getSearchVideo({
          keyword: typeof value === "object" ? value.value : value,
          page: _page || page.num,
          size,
        });
        break
      case "cartoon":
        res = await searchBookList({
          kwy: typeof value === "object" ? value.value : value,
          page: _page || page.num,
          size,
        });
        break
      case "dating":
        res = await searchDatingList({
          kwy: typeof value === "object" ? value.value : value,
          page: _page || page.num,
          size,
        });
        break
      default:
        res = await getSearchCreator({
          keyword: typeof value === "object" ? value.value : value,
          page: _page || page.num,
          size,
        });
        break
    }
    isGetData = false;
    // console.log(
    //   typeof value === "object" ? value.value : value,
    //   res.data.list,
    //   page.num
    // );
    if (res.data && res.data.list.length > 0) {
      if (page.num === 1) {
        listData.data = [...res.data.list];
      } else {
        listData.data = [...listData.data, ...res.data.list];
      }
      if (res.data.list.length < size) {
        setIsAll(true);
      }
      setListData({...listData});
    } else {
      setIsAll(true);
    }
    setLoading(false);
  };
  const _loadMoreData = () => {
    if (isAll || isGetData) return;
    page.num = page.num + 1;
    setPage({...page});
    initListData(page.num);
  };
  useEffect(() => {
    if (initList) {
      initListData();
    }
  }, [initList]);
  return (
    <div className={"featured-swiper-item"}>
      {loading ? (
        <Loading show text={"正在获取数据..."} overSize={false} size={25}/>
      ) : listData.data.length > 0 ? (
        <ScrollArea
          ListData={listData}
          onScrollEnd={_loadMoreData}
          loadingMore={!isAll}
        >
          {orderBy === "video" && listData.data.map((item, index) => {
            return <VideoItem key={index} data={item}/>;
          })}

          {orderBy === "user" && listData.data.map((item, index) => {
            return <UserItem key={index} data={item}/>;
          })}

          {orderBy === "cartoon" && <div className={"Cartoon-page"}>
            <div className={"Cartoon-list"}>
              {listData.data.map((item, index) => {
                return <CartoonItem key={index} item={item}/>
              })}
            </div>
          </div>}

          {orderBy === "dating" && <div className={"DatingPage"}>
            <div className={"Dating"}>{listData.data.map((item, index) => {
              return <DatingItem key={index} data={item}/>;
            })}</div>
          </div>}

          <div style={{height: "30px"}}/>
        </ScrollArea>
      ) : (
        <NoData/>
      )}
    </div>
  );
};

const VideoItem = (props) => {
  const {data} = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const videoRef = useRef(null);
  useEffect(() => {
    if (!videoRef.current) {
      return;
    }
    const videoHammer = new Hammer(videoRef.current);
    videoHammer.on("tap", jump);
    return () => {
      videoHammer.off("tap", jump);
    };
  }, [videoRef.current]);
  const jump = () => {
    const stackKey = `video_detai-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "video_detai",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{zIndex: stacks.length + 2}}
          >
            <VideoDetai stackKey={stackKey} id={data.id}/>
          </StackPage>
        ),
      },
    });
  };
  return useMemo(
    () => (
      <div className="search-videoItem" ref={videoRef}>
        <div className="search-videoCover">
          <Simg src={data.thumb_cover}/>
          <span>{data.duration_str}</span>
        </div>
        <div className="search-videoInfo">
          <p>{data.title}</p>
          <div>
            <span>{data.member.nickname}</span>
            <span>{data.count_play_str}</span>
          </div>
        </div>
      </div>
    ),
    [data]
  );
};

const UserItem = (props) => {
  const {data} = props;
  const userRef = useRef(null);
  const [isLike, setLsLike] = useState(data.is_follow);
  const followeUser = async () => {
    const res = await followUp({follow_uuid: data.uuid});
    if (res.status === 200) {
      onLike();
    } else {
      Emit.emit("showToast", {
        text: res.msg,
        time: 3000,
      });
    }
  };
  useEffect(() => {
    if (!userRef.current) {
      return;
    }
    const videoHammer = new Hammer(userRef.current);
    videoHammer.on("tap", jump);
    return () => {
      videoHammer.off("tap", jump);
    };
  }, [userRef.current]);
  const jump = () => {
  };
  const onLike = () => {
    setLsLike(!isLike);
  };
  return useMemo(
    () => (
      <div className="search-userItem">
        <div className="search-row" ref={userRef}>
          <Avatar
            boxClass="userItem-avatarbox"
            isCreater={data.auth_status}
            img={data.thumb}
            uuid={data.uuid}
          />
          <div className="userItem-info">
            <p>{data.nickname}</p>
            <div>
              <span>{data.followed_count} 粉丝</span>
              <span>{data.videos_count} 作品</span>
            </div>
          </div>
        </div>
        <ClickBtn
          className={isLike ? "search-isLike" : "search-like"}
          onTap={followeUser}
        >
          {isLike ? "已关注" : "关注"}
        </ClickBtn>
      </div>
    ),
    [data, isLike]
  );
};
