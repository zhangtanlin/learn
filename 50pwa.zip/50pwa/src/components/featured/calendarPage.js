import React, { useEffect, useMemo, useRef, useState } from "react";
import Hammer from "hammerjs";
import StackStore from "../../store/stack";
import BackHeader from "../backHeader";
import ScrollArea from "../scrollarea";
import "../../resources/css/everyday.less";
import Emit from "../../libs/eventEmitter";
import calendarIcon from "../../resources/img/public/calendar.png";
import chuangIcon from "../../resources/img/public/chuang.png";
import shareIcon from "../../resources/img/public/share.png";
import Loading from "../loading";
import NoData from "../noData";
export default (props) => {
  const { stackKey, title } = props;
  return (
    <div className="page-content-flex">
      <BackHeader
        stackKey={stackKey}
        title={() => {
          return <span style={{ fontSize: "0.5rem" }}>漫游历</span>;
        }}
      />
    </div>
  );
};
