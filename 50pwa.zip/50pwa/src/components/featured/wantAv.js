import React, { useEffect, useMemo, useRef, useState } from "react";
import Hammer from "hammerjs";
import "../../resources/css/wantAv.less";
import ScrollArea from "../scrollarea";
import StackStore from "../../store/stack";
import BackHeader from "../backHeader";
import Loading from "../loading";
import Emit from "../../libs/eventEmitter";
import { SelectVideo } from "../weitie/qiupian/qiupian_card";
import jubaoRed from "../../resources/img/public/jubao_checked_red.png";
import PublishRule from "../publishRule";
import StackPage from "../stackpage";
import Simg from "../simg";
import { publishMv } from "../../libs/http";
import UserStore from "../../store/user";

export default (props) => {
  const { stackKey, mvData } = props;
  const textAreaRef = useRef(null);
  const inputRef = useRef(null);
  const [choose, setChoosed] = useState(false);
  const [stacks] = StackStore.useGlobalState("stacks");
  const [user] = UserStore.useGlobalState("user");
  const renderVideo = () => {
    return (
      <div className="search-videoItem">
        <div className="search-videoCover">
          <Simg src={mvData.cover} />
          <span>{mvData.duration}</span>
        </div>
        <div className="search-videoInfo">
          <p>{mvData.title}</p>
          <div>
            <span>{mvData.nickname}</span>
            <span>{mvData.playNum}</span>
          </div>
        </div>
      </div>
    );
  };
  return (
    <div className="page-content-flex">
      <BackHeader
        stackKey={stackKey}
        title="发布求片"
        right={() => {
          return <div style={{ width: "1.2rem" }} />;
        }}
      />
      <div className="wantAv">
        <div className="wantAv-top">
          <p className="wantAv-title">求片内容</p>
          <textarea
            ref={textAreaRef}
            maxLength={200}
            placeholder={
              "可以输入你对视频的玩法要求，也可输入想看的类型、片名、演员名称、番号..."
            }
          />
          <p className="wantAv-title">
            原视频<span>我想找续集</span>
          </p>
          {renderVideo()}
          <p className="wantAv-title" style={{ marginTop: "0.5rem" }}>
            打赏金额（灰币/个）
          </p>
          <div className="wantAv-input-box">
            <input
              type="number"
              ref={inputRef}
              placeholder="设置打赏推荐更积极收获多多"
            />
            <div className="thin-line" />
          </div>
        </div>
        <div className="wantAv-footer">
          <div className="wantAv-row">
            {choose ? (
              <img
                src={jubaoRed}
                onClick={() => {
                  setChoosed(false);
                }}
              />
            ) : (
              <div
                className="wantAv-circle"
                onClick={() => {
                  setChoosed(true);
                }}
              />
            )}
            <span className="wantAv-row">
              请阅读并遵守
              <span
                className="wantAv-blue"
                onClick={() => {
                  const stackKey = `PublishRule-${new Date().getTime()}`;
                  StackStore.dispatch({
                    type: "push",
                    payload: {
                      name: "PublishRule",
                      element: (
                        <StackPage
                          stackKey={stackKey}
                          key={stackKey}
                          style={{ zIndex: stacks.length + 2 }}
                        >
                          <PublishRule stackKey={stackKey} />
                        </StackPage>
                      ),
                    },
                  });
                }}
              >
                《50度灰发布规则》
              </span>
            </span>
          </div>
          <div
            className="wantAv-btn"
            onClick={() => {
              if (!textAreaRef.current.value) {
                Emit.emit("showToast", {
                  text: "请输入求片内容",
                });
                return;
              }
              if (!choose) {
                Emit.emit("showToast", {
                  text: "请确认已阅读50度灰发布规则",
                });
                return;
              }
              if (textAreaRef.current.value.length < 10) {
                Emit.emit("showToast", {
                  text: "详细的描述更方便照片，不少于10个字哦～",
                });
                return;
              }
              if (!user.vip_level) {
                Emit.emit("showToast", {
                  text: "仅允许充值会员用户发布求片信息",
                });
                return;
              }
              publishMv({
                vid: mvData.id,
                images: [mvData.cover],
                coins: inputRef.current.value,
                title: textAreaRef.current.value,
              }).then((res) => {
                if (res.data) {
                  Emit.emit("showToast", {
                    text: res.data.msg,
                  });
                  Emit.emit(stackKey, stackKey);
                } else {
                  Emit.emit("showToast", {
                    text: res.msg,
                  });
                }
              });
            }}
          >
            发布
          </div>
        </div>
      </div>
    </div>
  );
};
