import React, { useEffect, useMemo, useRef, useState } from "react";
import Hammer from "hammerjs";
import "../../resources/css/focusList.less";
import ScrollArea from "../scrollarea";
import StackStore from "../../store/stack";
import BackHeader from "../backHeader";
import Loading from "../loading";
import NoData from "../noData";
import Avatar from "../avatar";
import "../../resources/css/dashang.less";
import Emit from "../../libs/eventEmitter";
import StackPage from "../stackpage";
import { getIdolList, followUp } from "../../libs/http";
import globalVar from "../../libs/globalVar";
import UserPage from "../category/user_page";
import Simg from "../simg";

export default (props) => {
  const { stackKey } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState([]);
  const [loadingMore, setLoadingMore] = useState({ a: true });
  let page = 1;
  useEffect(() => {
    getData("init");
  }, []);
  const getData = (status) => {
    if (!loadingMore.a) return;
    if (!status) {
      page++;
    }
    getIdolList({ page: page, uuid: globalVar.uuid })
      .then((res) => {
        // console.log("getIdolList=>", page, res);
        setLoading(false);
        if (res.data.length > 0) {
          setData((pre) => [...pre, ...res.data]);
        } else {
          if (page == 1) {
            setData([]);
          }
          loadingMore.a = false;
          setLoadingMore({ ...loadingMore });
        }
      })
      .catch(() => {
        setLoading(false);
      });
  };
  return (
    <div className="page-content-flex">
      <BackHeader
        stackKey={stackKey}
        title="偶像"
        right={() => {
          return <div style={{ width: "1.2rem" }} />;
        }}
      />
      {loading ? (
        <Loading show text={"正在获取数据..."} overSize={false} size={25} />
      ) : data.length > 0 ? (
        <ScrollArea
          ListData={data}
          onScrollEnd={getData}
          loadingMore={loadingMore.a}
        >
          <div className="focusList">
            {data.map((item, index) => {
              return (
                <Item
                  item={item}
                  index={index}
                  key={index}
                  onDelete={(uuid) => {
                    // console.log(uuid)
                    const aaa = data.filter((e) => e.uuid != uuid);
                    // console.log("111", aaa);
                    setData([...aaa]);
                  }}
                />
              );
            })}
          </div>
          <div style={{ height: "30px" }} />
        </ScrollArea>
      ) : (
        <NoData />
      )}
    </div>
  );
};

const Item = (props) => {
  const { item, onDelete, index } = props;
  const saveRef = useRef(null);
  const userRef = useRef(null);
  const [isSave, setIsSave] = useState(true);
  const [stacks] = StackStore.useGlobalState("stacks");
  useEffect(() => {
    if (!saveRef.current) {
      return;
    }
    const saveHammer = new Hammer(saveRef.current);
    const userHammer = new Hammer(userRef.current);
    saveHammer.on("tap", onSave);
    userHammer.on("tap", toUserPage);
    return () => {
      saveHammer.off("tap", onSave);
      userHammer.off("tap", toUserPage);
    };
  }, [saveRef.current, userRef.current, item, index]);
  const onSave = () => {
    followUp({ follow_uuid: item.uuid });
    onDelete(item.uuid);
  };
  const toUserPage = () => {
    const stackKey = `userpage-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "userpage",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <UserPage stackKey={stackKey} uuid={item.uuid} />
          </StackPage>
        ),
      },
    });
  };
  return (
    <div className="info-userItem">
      <div className="info-row" ref={userRef}>
        <Avatar
          boxClass="userItem-avatarbox"
          avatarClass="info-avatar"
          img={item.thumb}
          isCreater={item.auth_status}
        />
        <div className="userItem-info">
          <p>{item.nickname}</p>
          <div>
            {item.followed_count}粉丝
            <span style={{ marginLeft: 15 }} />
            {item.videos_count}作品
          </div>
        </div>
      </div>
      <div className={isSave ? "info-isLike" : "info-like"} ref={saveRef}>
        {isSave ? "已关注" : "关注"}
      </div>
    </div>
  );
};
