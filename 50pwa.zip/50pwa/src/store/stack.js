import { createStore } from 'react-hooks-global-state';

const initialState = {
  stacks: [],
};
let canPush = true;
const reducer = (state, action) => {
  if (action.type === 'push' && canPush) {
    // console.log('push stack');
    canPush = false
    setTimeout(()=>{
      canPush = true
    },1300)
    return { ...state, stacks: state.stacks.concat([action.payload]) };
  } if (action.type === 'pop') {
    // console.log('pop stack');
    state.stacks.pop(); return { ...state, stacks: [...state.stacks] };
  } if (action.type === 'replace') {
    // console.log('replace stack');
    state.stacks[state.stacks.length - 1] = action.payload;
    return { ...state, stacks: [...state.stacks] };
  }
  return state;
};

const StackStore = createStore(reducer, initialState);

export default StackStore;
