import { createStore } from 'react-hooks-global-state';

const initialState = {
  user: {
    uuid: '',
    aff_code: '', // 推广码
    aff_url: '', // 推广链接
    aff_url_copy: '', // 推广内容
    coins: 0,
    nickname: '',
    invited_by: '', // 被邀请码
    invited_code: '', // 自己的邀请码
    phone: '',
    center: {}, // 版本信息
    free_view_cnt: 0, // 免费观看次数
    thumb: '', // 头像
    videos_count: 0, // 作品总数
    vip: false, // 是否是vip
    vip_level: 0, // vip等级(是vip才会有vip等级){0: 非vip, 1: 月卡, 2: 季卡, 3: 年卡, 4: 永久, 9: 临时}
    expired_at: '', // vip过期日期(是vip才会有vip过期日期)
    followed: 0, // 粉丝数
    fabulous_count: 0, // 获赞数
    daily_view: 0, // 剩余观看次数
    creator: 0, // 是否认证{0: 未认证,1: 认证中,2: 认证失败,3: 拉黑,4: 已认证}
    creator_level: 0, // 认证等级（数字就代表多少等级）
    creator_tag: [], // 认证标签
    creator_desc: '', // 认证描述
    creator_auth_at: '', // 认证通过的时间
    creator_auth_at_day: '', // 认证天数
  },
};

const reducer = (state, action) => {
  if (action.type === 'replace') {
    return { ...state, user: { ...state.user, ...action.payload } };
  }
  return state;
};

const UserStore = createStore(reducer, initialState);

export default UserStore;
