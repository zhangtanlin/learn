<!-- Love react-pwa? Please consider supporting our collective:
👉  https://opencollective.com/react-pwa/donate -->