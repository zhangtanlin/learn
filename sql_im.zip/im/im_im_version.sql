-- MySQL dump 10.13  Distrib 8.0.22, for macos10.15 (x86_64)
--
-- Host: 139.162.86.162    Database: im
-- ------------------------------------------------------
-- Server version	8.0.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `im_version`
--

DROP TABLE IF EXISTS `im_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `im_version` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `version` char(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '版本号',
  `apptype` int(1) DEFAULT '1' COMMENT '框架类型 1 java 2 rn',
  `type` char(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT 'android' COMMENT '型号',
  `apk` varchar(512) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '下载连接',
  `tips` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '更新说明',
  `bundle_id` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT 'ios企业安装包id',
  `must` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 不强制更新 1强制',
  `created_at` int(11) NOT NULL COMMENT '创建时间',
  `via` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT 'agent' COMMENT '来源 ''agent'' 企业签  ''single'' 个人签',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 启用  2 停用',
  `message` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '''''' COMMENT '系统维护公告',
  `mstatus` tinyint(1) NOT NULL DEFAULT '0' COMMENT '系统公告状态 0 没有 1通知 2禁用',
  `from_id` int(11) DEFAULT '0' COMMENT '更新起点',
  `to_id` int(11) NOT NULL DEFAULT '0' COMMENT '更新终点',
  `app_store` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='app下载版本控制表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `im_version`
--

LOCK TABLES `im_version` WRITE;
/*!40000 ALTER TABLE `im_version` DISABLE KEYS */;
INSERT INTO `im_version` VALUES (1,'1.0.1',2,'android','https://download.xxingqu.com/st/st1128.apk','1.更新更新#2.更新啊更新','1',0,1579323215,'agent',2,'\'\'',0,0,1,NULL),(2,'1.0.1',2,'ios','https://download.xxingqu.com/lupro/hl1106.apk','1.alsdhalksdjlaksd#2.aslkjdalsdkj','0',0,1578905635,'agent',1,'\'\'',0,0,0,NULL);
/*!40000 ALTER TABLE `im_version` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-01-17 11:00:13
