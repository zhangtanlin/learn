-- MySQL dump 10.13  Distrib 8.0.22, for macos10.15 (x86_64)
--
-- Host: 139.162.86.162    Database: im
-- ------------------------------------------------------
-- Server version	8.0.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `im_group`
--

DROP TABLE IF EXISTS `im_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `im_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '群组id',
  `group_name` varchar(155) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '' COMMENT '群组名称',
  `avatar` varchar(155) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '' COMMENT '群组头像',
  `avatar_background_color` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `owner_uuid` char(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '' COMMENT '群主id',
  `owner_sign` varchar(155) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '' COMMENT '群主签名',
  `group_type` enum('broadcast','group','private_group') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'group' COMMENT '频道群，一般群，私密群',
  `group_url` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '' COMMENT '群地址',
  `group_descp` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '' COMMENT '群简介',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '群状态，0-删除，1-正常,2-群禁言',
  `user_num` int(11) NOT NULL DEFAULT '0' COMMENT '群人数',
  `ban` tinyint(4) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL COMMENT '记录时间',
  `updated_at` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  KEY `group_name` (`group_name`),
  KEY `group_url` (`group_url`),
  KEY `owner_uuid` (`owner_uuid`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8 COMMENT='群的表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `im_group`
--

LOCK TABLES `im_group` WRITE;
/*!40000 ALTER TABLE `im_group` DISABLE KEYS */;
INSERT INTO `im_group` VALUES (1,'刚刚反反复复看电视','','#8ab0f9:#6364f6','2df646e8f16a48c84a0e18a444338766','','group','','',0,4,0,'2020-03-18 18:16:06','2020-03-18 18:16:06'),(2,'刚刚反反复复看电视','','#8ab0f9:#6364f6','2df646e8f16a48c84a0e18a444338766','','group','','',0,4,0,'2020-03-18 18:16:07','2020-03-18 18:16:07'),(3,'twst','','#8ab0f9:#6364f6','9a8aebe0c32fa88753b30a902d10f9d1','','private_group','','hahaha',1,6,0,'2020-04-09 16:04:17','2020-04-29 20:04:25'),(4,'51短视频','','#8ab0f9:#6364f6','e6020fe18da3e21dec3f1185edeb8f8e','','group','','',1,3,0,'2020-04-14 17:27:28','2020-04-18 19:46:57'),(5,'dsfgsdf','','#d7a5ee:#c972e7','e6020fe18da3e21dec3f1185edeb8f8e','','group','','',1,2,0,'2020-04-14 18:02:58','2020-04-14 18:02:58'),(6,'asdf34235','','#d7a5ee:#c972e7','e6020fe18da3e21dec3f1185edeb8f8e','','group','','',1,2,0,'2020-04-14 18:09:28','2020-04-21 19:44:19'),(7,'ghd146574','https://static.tiktik.me/image/20200414/20200414181028877361.png','#d7a5ee:#c972e7','e6020fe18da3e21dec3f1185edeb8f8e','','group','','',1,3,0,'2020-04-14 18:11:06','2020-04-14 18:11:06'),(8,'adfadsf','','#acdb89:#76c873','e6020fe18da3e21dec3f1185edeb8f8e','','group','','',1,2,0,'2020-04-15 16:04:15','2020-04-15 16:04:15'),(9,'sdfhsdfgfds','','#ef8c67:#ed5f6e','e6020fe18da3e21dec3f1185edeb8f8e','','group','','',1,2,0,'2020-04-15 16:06:34','2020-04-18 16:59:49'),(10,'adsjufoiasjdf','','#d7a5ee:#c972e7','e6020fe18da3e21dec3f1185edeb8f8e','','group','','',1,3,0,'2020-04-15 19:58:46','2020-04-15 19:58:46'),(11,'asdfasdf','','#f8ce79:#f4ab6a','e6020fe18da3e21dec3f1185edeb8f8e','','group','','',1,2,0,'2020-04-15 20:29:24','2020-04-18 21:11:01'),(12,'asdfasdf','','#8ab0f9:#6364f6','e6020fe18da3e21dec3f1185edeb8f8e','','group','','',1,3,0,'2020-04-15 20:30:08','2020-04-15 20:30:08'),(13,'sdfadsfasd','','#d7a5ee:#c972e7','e6020fe18da3e21dec3f1185edeb8f8e','','group','','',1,3,0,'2020-04-15 22:03:58','2020-04-15 22:03:58'),(14,'123+132+133+134Group','','#f8ce79:#f4ab6a','083dd55425b18c437339afa1ab0b4eb4','','private_group','','123+132+133+134Group Noti',1,4,0,'2020-04-17 15:45:19','2020-05-06 12:48:45'),(15,'123+132+133+134Group','','#f8ce79:#f4ab6a','083dd55425b18c437339afa1ab0b4eb4','','group','','123+132+133+134Group Noti',1,3,0,'2020-04-17 15:46:21','2020-04-17 15:53:45'),(16,'04/17/19:43 Create','','#ef8c67:#ed5f6e','a29a7110f0f2ecefa5f617520010c0d4','','group','','04/17/19:43 Create Info',1,1,0,'2020-04-17 20:44:23','2020-04-17 20:45:18'),(17,'Test/20 update Group Name','','#80e9d6:#80e9d6','a29a7110f0f2ecefa5f617520010c0d4','','private_group','','04/20 Update Info',2,3,1,'2020-04-17 20:44:57','2020-04-28 21:09:03'),(18,'昌盛','https://static.tiktik.me/image/20200418/20200418122326378507.png','#80e9d6:#80e9d6','4dd6c23466a4be1306069f1488f3ba05','','group','','',1,2,0,'2020-04-18 12:24:19','2020-04-28 20:26:46'),(19,'Test group','','#80e9d6:#80e9d6','a29a7110f0f2ecefa5f617520010c0d4','','group','','Test',1,2,0,'2020-04-20 19:53:10','2020-04-20 19:53:10'),(20,'Test group','','#acdb89:#76c873','a29a7110f0f2ecefa5f617520010c0d4','','group','','Test',1,2,0,'2020-04-20 19:53:11','2020-04-20 19:53:11'),(21,'Test group','','#80e9d6:#80e9d6','a29a7110f0f2ecefa5f617520010c0d4','','group','','Test ',1,2,0,'2020-04-20 19:53:21','2020-04-20 19:53:21'),(22,'lksdjfsdf','','#f8ce79:#f4ab6a','620b1d8300e8fa8f54918d9643ba9c2b','','group','','',1,2,0,'2020-04-21 19:53:43','2020-04-21 19:53:43'),(23,'搜同社区','','#ef8c67:#ed5f6e','4dd6c23466a4be1306069f1488f3ba05','','group','','',1,0,0,'2020-04-21 19:54:42','2020-04-21 19:54:42'),(25,'test','','#ef8c67:#ed5f6e','620b1d8300e8fa8f54918d9643ba9c2b','','group','','',1,2,0,'2020-04-22 19:46:44','2020-04-22 19:46:44'),(26,'test','','#6364f6:#4e9eeb','620b1d8300e8fa8f54918d9643ba9c2b','','group','','',1,2,0,'2020-04-22 19:46:45','2020-04-22 19:46:45'),(27,'扫黄大堆','','#f8ce79:#f4ab6a','4dd6c23466a4be1306069f1488f3ba05','','group','','',1,1,0,'2020-04-23 10:31:33','2020-04-28 20:26:42'),(28,'哎呀我去','','#ef8c67:#ed5f6e','4dd6c23466a4be1306069f1488f3ba05','','private_group','','',1,0,0,'2020-04-23 10:39:56','2020-04-25 18:28:36'),(29,'哈哈哈哈哈哈','/image/20200424/20200424122744230219.jpeg','#d7a5ee:#c972e7','4dd6c23466a4be1306069f1488f3ba05','','group','','',1,-1,1,'2020-04-23 10:55:17','2020-04-28 20:26:12'),(30,'asdwq','/image/20200424/20200424122933467488.jpeg','#8ab0f9:#6364f6','4dd6c23466a4be1306069f1488f3ba05','','group','','',1,0,0,'2020-04-23 10:56:21','2020-04-24 15:17:29'),(31,'564561','','#d7a5ee:#c972e7','4dd6c23466a4be1306069f1488f3ba05','','group','','',1,1,0,'2020-04-23 10:57:22','2020-04-28 20:26:50'),(33,'99999','','#80e9d6:#80e9d6','4dd6c23466a4be1306069f1488f3ba05','','group','','',1,0,1,'2020-04-23 11:05:56','2020-04-25 21:46:02'),(35,'滚滚滚滚滚滚1','/image/20200424/20200424122612469194.png','#6364f6:#4e9eeb','4dd6c23466a4be1306069f1488f3ba05','','group','','滚滚滚滚滚滚1',1,1,1,'2020-04-23 11:11:44','2020-04-29 19:20:53'),(36,'哈哈哈哈哈','https://static.tiktik.me/image/20200425/20200425194516884069.jpeg','#f8ce79:#f4ab6a','0533056278a6f9c4a1827897fc1495b2','','group','','',1,2,0,'2020-04-25 19:45:47','2020-04-25 19:45:48'),(37,'EGM','https://static.tiktik.me/image/20200425/20200425212410883156.jpeg','#ef8c67:#ed5f6e','0533056278a6f9c4a1827897fc1495b2','','group','','',1,3,0,'2020-04-25 21:24:52','2020-04-28 20:26:33'),(38,'搜同','https://static.tiktik.me/image/20200425/20200425213742988259.jpeg','#8ab0f9:#6364f6','1a8fb610376f8315a1c0c7c680ba5ad6','','group','','',1,2,0,'2020-04-25 21:38:38','2020-04-28 20:26:57'),(39,'wdqw','https://static.tiktik.me/image/20200425/20200425213911482059.jpeg','#6364f6:#4e9eeb','1a8fb610376f8315a1c0c7c680ba5ad6','','group','','',1,4,0,'2020-04-25 21:39:45','2020-04-28 20:27:02'),(40,'阿撒打算的','','#6364f6:#4e9eeb','620b1d8300e8fa8f54918d9643ba9c2b','','group','','',1,2,0,'2020-04-25 21:40:39','2020-04-25 21:40:39'),(45,'撒拉黑哟','https://static.tiktik.me/image/20200427/20200427155820527464.jpeg','#d7a5ee:#c972e7','1a8fb610376f8315a1c0c7c680ba5ad6','','group','','',1,2,0,'2020-04-27 15:58:56','2020-04-28 20:26:54'),(46,'蛋蛋','https://static.tiktik.me/image/20200427/20200427170652771098.jpeg','#d7a5ee:#c972e7','1a8fb610376f8315a1c0c7c680ba5ad6','','group','','',1,4,0,'2020-04-27 17:07:33','2020-04-29 19:20:50'),(47,'可口可乐','https://static.tiktik.me/image/20200427/20200427171025329675.png','#ef8c67:#ed5f6e','1a8fb610376f8315a1c0c7c680ba5ad6','','group','','',1,1,0,'2020-04-27 17:11:11','2020-05-07 19:47:23'),(48,'百事可乐','https://static.tiktik.me/image/20200427/20200427171025329675.png','#acdb89:#76c873','1a8fb610376f8315a1c0c7c680ba5ad6','','group','','',1,5,1,'2020-04-27 17:11:53','2020-05-07 16:51:02'),(49,'骚年','https://static.tiktik.me/image/20200428/20200428103625597670.png','#f8ce79:#f4ab6a','1a8fb610376f8315a1c0c7c680ba5ad6','','group','','',1,2,0,'2020-04-28 10:37:07','2020-04-28 20:26:28'),(50,'哦豁','https://static.tiktik.me/image/20200428/20200428103949116619.png','#8ab0f9:#6364f6','1a8fb610376f8315a1c0c7c680ba5ad6','','group','','',1,1,0,'2020-04-28 10:40:26','2020-04-28 20:27:26'),(51,'AE','https://static.tiktik.me/image/20200428/20200428162720721785.png','#ef8c67:#ed5f6e','1a8fb610376f8315a1c0c7c680ba5ad6','','group','','',1,0,0,'2020-04-28 16:28:07','2020-04-28 20:26:15'),(52,'约炮群','/image/20200507/20200507150702947289.png','#8ab0f9:#6364f6','1a8fb610376f8315a1c0c7c680ba5ad6','','group','','',2,3,1,'2020-04-29 19:21:18','2020-05-07 17:28:01'),(53,'吃瓜','https://static.tiktik.me/image/20200429/20200429192118887523.png','#acdb89:#76c873','1a8fb610376f8315a1c0c7c680ba5ad6','','group','','111',1,3,0,'2020-04-29 19:21:54','2020-05-04 11:11:54'),(54,'哈咯','https://static.tiktik.me/image/20200504/20200504100137568735.png','#d7a5ee:#c972e7','1a8fb610376f8315a1c0c7c680ba5ad6','','private_group','','',1,3,0,'2020-05-04 10:02:25','2020-05-07 17:07:26'),(55,'一上午','https://static.tiktik.me/image/20200505/20200505151652906620.png','#acdb89:#76c873','1a8fb610376f8315a1c0c7c680ba5ad6','','group','','',2,3,1,'2020-05-05 15:17:48','2020-05-07 17:10:13'),(56,'哈哈哈','https://static.tiktik.me/image/20200505/20200505151736233401.png','#80e9d6:#80e9d6','1a8fb610376f8315a1c0c7c680ba5ad6','','group','','',2,3,1,'2020-05-05 15:18:09','2020-05-07 17:27:48');
/*!40000 ALTER TABLE `im_group` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-01-17 10:59:45
