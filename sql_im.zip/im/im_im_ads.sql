-- MySQL dump 10.13  Distrib 8.0.22, for macos10.15 (x86_64)
--
-- Host: 139.162.86.162    Database: im
-- ------------------------------------------------------
-- Server version	8.0.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `im_ads`
--

DROP TABLE IF EXISTS `im_ads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `im_ads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '广告标题',
  `img_url` varchar(256) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '图片地址',
  `width` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '图片宽',
  `height` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '图片高',
  `url` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '广告跳转地址/QQ号/微信号',
  `level` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1：av长图   2：小视频短图  3：启动页全屏图',
  `belong_id` int(11) NOT NULL DEFAULT '0' COMMENT '归属用户aff,0表示所有',
  `bundle_id` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '包名ID 为空表示所有',
  `created_at` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '广告类型 0：下载链接 1：跳转qq 2:跳转微信',
  `status` tinyint(1) DEFAULT '1' COMMENT '0-禁用，1-启用',
  `proxy_level` mediumint(9) NOT NULL DEFAULT '0' COMMENT '广告层级',
  `apptype` tinyint(1) NOT NULL DEFAULT '1' COMMENT '框架类型 1 local 2rn',
  `oauth_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '广告设备类型 0所有 1iOS 2 android',
  `range_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '广告范围类型 0所有 1 48小时内 2 48小时后',
  `app_store` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT 'app store',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `im_ads`
--

LOCK TABLES `im_ads` WRITE;
/*!40000 ALTER TABLE `im_ads` DISABLE KEYS */;
INSERT INTO `im_ads` VALUES (3,'startAd','https://upload.cc/i1/2019/12/24/a0ojIR.jpg',0,0,'https://www.baidu.com',1,0,'',1577188226,0,1,0,1,0,0,'0');
/*!40000 ALTER TABLE `im_ads` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-01-17 10:59:21
