-- MySQL dump 10.13  Distrib 8.0.22, for macos10.15 (x86_64)
--
-- Host: 139.162.86.162    Database: im
-- ------------------------------------------------------
-- Server version	8.0.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `im_admin_menu`
--

DROP TABLE IF EXISTS `im_admin_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `im_admin_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '' COMMENT '菜单名称',
  `value` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '' COMMENT '菜单值，',
  `pid` int(11) NOT NULL DEFAULT '0' COMMENT '父ID 默认0-一级菜单',
  `level` tinyint(1) NOT NULL DEFAULT '1' COMMENT '级别',
  `sort` tinyint(4) NOT NULL DEFAULT '0' COMMENT '排序',
  `status` enum('yes','no') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'yes' COMMENT '状态',
  `created_at` datetime NOT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=92 DEFAULT CHARSET=utf8 COMMENT='后台权限菜单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `im_admin_menu`
--

LOCK TABLES `im_admin_menu` WRITE;
/*!40000 ALTER TABLE `im_admin_menu` DISABLE KEYS */;
INSERT INTO `im_admin_menu` VALUES (1,'主页','',0,1,1,'yes','2019-07-16 11:11:11'),(2,'控制台','/admin/index/console',1,2,1,'yes','2019-07-16 11:11:11'),(50,'菜单管理','',0,1,1,'yes','2019-07-16 11:11:11'),(51,'管理员','/admin/admin/index',50,2,0,'yes','2019-07-16 11:11:11'),(55,'角色管理','/admin/role/index',50,2,0,'yes','2019-07-16 11:11:11'),(57,'菜单管理','/admin/menu/index',50,2,1,'yes','2019-07-16 11:11:11'),(76,'修改密码','/admin/admin/password',1,2,2,'yes','2019-11-08 21:04:18'),(80,'用户管理','/',0,1,127,'yes','2019-12-06 15:02:57'),(81,'用户管理','/admin/members/index',80,2,0,'yes','2019-12-06 15:03:30'),(82,'动态管理','/',0,1,0,'yes','2019-12-06 15:10:36'),(83,'动态管理','/admin/dynamic/index',82,2,0,'yes','2019-12-06 15:11:09'),(84,'群组管理','/',0,1,0,'yes','2019-12-09 10:38:51'),(85,'群组管理','/admin/group/index',84,2,0,'yes','2019-12-09 10:39:16'),(86,'开屏公告及广告管理','/',0,1,0,'yes','2019-12-10 10:48:39'),(87,'开屏广告及公告','/admin/ads/index',86,2,0,'yes','2019-12-10 10:50:01'),(88,'版本管理','/admin/version/index',86,2,0,'yes','2019-12-10 11:00:22'),(90,'线路管理','/admin/area/index',1,2,0,'yes','2020-01-16 11:28:46'),(91,'线路检测','/admin/arealog/index',1,2,0,'yes','2020-01-16 11:29:11');
/*!40000 ALTER TABLE `im_admin_menu` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-01-17 10:59:24
