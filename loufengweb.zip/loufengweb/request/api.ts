import { serverBaseUrl } from './env'

// 首页导航
export const apHomeNav = `${serverBaseUrl}/admin/resource/menu`

// 登陆
export const apiLogin = `${serverBaseUrl}/admin/user/login`