// 服务端请求接口的BaseUrl
export const serverBaseUrl = process.env.NEXT_PUBLIC_DOMAIN_ENV === 'production' ?
  'https://api.jlymovies.com' :
  'http://10.211.55.3:3000'
