import axios from 'axios'
import { serverBaseUrl } from './env'
import CloneDeep from 'lodash/cloneDeep'

// axios基础信息设置
// withCredentials: 允许携带cookie
axios.defaults.baseURL = serverBaseUrl
axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded'
axios.defaults.withCredentials = true

// 创建客户端的axios实例
export const axiosDynamic = axios.create()
axiosDynamic.interceptors.request.use(
  (config) => {
    return config
  },
  (error) => Promise.reject(error),
)
axiosDynamic.interceptors.response.use(
  (response) => {
    if (!response || response.status != 200 || !response.data) {
      return Promise.reject(response)
    }
    switch (Number(response.data.status)) {
      case 400:
      case 401:
        return Promise.reject(response.data)
      default:
    }
    return Promise.resolve(response.data)
  },
  (error) => {
    const _error = { ...error }
    if (_error) {
      return Promise.reject({ msg: '客户端请求超时' })
    }
    return Promise.reject(error)
  }
)

// 创建服务端的axios实例
export const axiosSSR = axios.create()
axiosSSR.interceptors.request.use(
  (config) => {
    let tempConfig: any = CloneDeep(config)
    tempConfig.headers['authorization'] = 'U2FsdGVkX1+pOR36Z0dDecq2B5rZaCdpJGA+Gb6nUpXMq4Hb/Da6HZjmgUxvH4SDWcowSPIm2ebQiniipovTC3vzt8Z7oVwmFwJ0OsRGRC8/w969BHxnG+b32LvP2hY74N+tOBVcgoFhN6sq8AEzRY9nyzgvXNtiOxo+1umjNyE='
    return tempConfig
  },
  (error) => Promise.reject(error),
)
axiosSSR.interceptors.response.use(
  (response) => {
    return Promise.resolve(response.data)
  },
  (error) => {
    console.log('error', error)
    const _error = { ...error }
    if (_error.code) {
      return Promise.reject({ msg: '服务端请求超时' })
    }
    return Promise.reject(error)
  }
)
