import { StoreUser } from '@/types/store'
import {
  PayloadAction,
  createSlice,
} from '@reduxjs/toolkit'
import { HYDRATE } from 'next-redux-wrapper'

// 初始化用户信息
const internalInitialState: StoreUser = {
  token: '',
  isLogin: false,
}

// 创建 reducer
export const authSlice = createSlice({
  name: 'user',
  initialState: internalInitialState,
  reducers: {
    // 更新用户信息
    update(state, action) {
      state.token = action.payload.token
      state.isLogin = action.payload.isLogin
    },
    // 重置用户信息
    reset: () => internalInitialState
  },
  extraReducers: {
    // 把服务器端的reducer注入到客户端的reducer，达到数据统一的目的
    // [HYDRATE]: (state, { payload }) => ({
    //   ...state,
    //   ...payload.token,
    //   ...payload.isLogin,
    // }),
    [HYDRATE]: (state, action) => {
      console.log('更新客户端和服务端共享数据', action)
      console.log('HYDRATE', state, action.payload)
      return Object.assign(
        {},
        state,
        { ...action.payload.auth }
      )
    },
  },
})
