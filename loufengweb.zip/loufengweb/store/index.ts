import {
  configureStore,
  combineReducers,
} from '@reduxjs/toolkit'
import { createWrapper } from 'next-redux-wrapper'
import {
  nextReduxCookieMiddleware,
  wrapMakeStore,
} from 'next-redux-cookie-wrapper'
import { authSlice } from './slices/auth'

// 共享数据块
const combinedReducers = combineReducers({
  [authSlice.name]: authSlice.reducer,
})

// 客户端/服务端共享仓库
export const store = wrapMakeStore(() => configureStore({
  reducer: combinedReducers,
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware()
    .prepend(
      nextReduxCookieMiddleware({
        // 是否压缩
        // compress: false,
        // 设置在客户端和服务器端共享的数据
        subtrees: [
          'auth.token',
          'auth.isLogin',
        ],
      })
    ).concat()
}))

// 客户端/服务端共享仓库导出
export const wrapper = createWrapper(
  store,
  {
    debug: true
  }
)