import type { NextPage } from 'next'

// loading
export const Loading: NextPage = () => {
  return (
    <div className="container">
      Loading...
    </div>
  )
}
