import type { NextPage } from 'next'
import React from 'react'

type NoDataPropType = {
  className?: string
}

const NoData: NextPage<NoDataPropType> = (P) => {
  const {
    className
  } = P
  return (
    <p className={`alter ${className}`}>
      alert
    </p>
  )
}

export default NoData
