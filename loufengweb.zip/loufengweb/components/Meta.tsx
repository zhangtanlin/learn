import Head from "next/head";
import Script from 'next/script'
import { NextPage } from "next";
import { MetaType } from "@/types/base";

// 公共meta参数类型
type PropsType = {
  props: MetaType
}

// 公共meta
export const MetaDefault: NextPage<PropsType> = (propsType) => {
  const { props } = propsType;
  // google统计
  const googleAnalyticsReject = () => ({
    __html: `
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
      gtag('config', '');
    `
  })
  const GoogleAnalytics = () => (
    <>
      <Script
        id='google-statistics-1'
        async
        src=""
      />
      <Script
        id='google-statistics-2'
        dangerouslySetInnerHTML={googleAnalyticsReject()}
      />
    </>
  )
  return (
    <>
      <Head>
        <meta charSet="UTF-8" />
        <title>{props.title}</title>
        <link
          rel="apple-touch-icon"
          sizes="180x180"
          href="/favicon/apple-touch-icon.png"
        />
        <link
          rel="icon"
          type="image/png"
          sizes="32x32"
          href="/favicon/favicon-32x32.png"
        />
        <link
          rel="icon"
          type="image/png"  
          sizes="16x16"
          href="/favicon/favicon-16x16.png"
        />
        <link
          rel="mask-icon"
          href="/favicon/safari-pinned-tab.svg"
          color="#000000"
        />
        <link rel="shortcut icon" href="/favicon/favicon.ico" />
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no" />
        <meta name="renderer" content="webkit" />
        <meta name="force-rendering" content="webkit" />
        <meta httpEquiv="X-UA-Compatible" content="IE=Edge,chrome=1" />
        <meta httpEquiv="Content-Language" content="zh-CN" />
        <meta name="msapplication-TileColor" content="#000000" />
        <meta name="theme-color" content="#000" />
        <meta name="description" content={props.description}/>
        {/* facebook */}
        <meta property="og:title" content={props.title} />
        <meta property="og:type" content="video.movie" />
        <meta property="og:url" content="" />
        <meta property="og:image" content="" />
        {/* 推特 */}
        <meta name="twitter:title" content={props.title}/>
        <meta name="twitter:description" content={props.description}/>
        <meta name="twitter:image" content=""/>
        <meta name="twitter:card" content="summary_large_image"></meta>
        {/* google统计 */}
        <GoogleAnalytics />
      </Head>
    </>
  )
}
