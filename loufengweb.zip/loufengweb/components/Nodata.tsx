import type { NextPage } from 'next'
import Image from 'next/image'
import iconNoData from '@/public/images/common/no_data.png'

// 无数据
export const NoData: NextPage = () => {
  return (
    <div className="container">
      <Image
        className="icon"
        src={iconNoData}
        alt="暂无"
        width="40px"
        height="40px"
      />
      <p className="text">
        暂无数据
      </p>
    </div>
  )
}
