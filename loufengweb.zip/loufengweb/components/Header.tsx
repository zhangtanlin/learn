import Link from 'next/link'
import Image from 'next/image'
import { useState } from 'react'
import { HomeNav } from '@/types/base'

import imgLogo from '@/public/images/common/logo.png'

// 默认头部导航参数类型
type NavProps = {
  list: HomeNav[]
}

// 默认头部导航
export const HeaderDefault = (props: NavProps) => {
  const { list } = props
  // 小屏点击切换导航
  const [isActive, setIsActive] = useState(false)
  const mobileToggleNavItem = () => {
    setIsActive(!isActive)
  }
  // 设置导航列表
  const buildItem = () => {
    if (list && list?.length) {
      return <>
        {list.map((item: any, index: any) => {
          if (index < 5) {
            return (
              <a
                className="navbar-item"
                key={`navbar-item-${index}`}
              >
                {item.name}
              </a>
            )
          }
        })}
      </>
    }
    return <></>
  }
  // 如果数据太多添加“更多”按钮
  const buildMoreBtn = () => {
    if (list?.length > 5) {
      const tempList = list.slice(5)
      return (
        <div
          className="navbar-item is-hoverable"
        >
          <a className="navbar-link">
            更多
          </a>
          <div className="navbar-dropdown">
            {tempList.map((item: any, index: any) => (
              <Link
                className="navbar-item"
                href="https://bulma.io"
                key={`navbar-item-${index}`}
              >
                <a className="navbar-item">
                  {item.name}
                </a>
              </Link>
            ))}
          </div>
        </div>
      )
    }
    return <></>
  }

  return (
    <header>
      <nav
        className="navbar"
        role="navigation"
        aria-label="main navigation"
      >
        <div className="navbar-brand">
          <Link
            className="navbar-item"
            href="https://bulma.io"
          >
            <a className="navbar-item">
              <Image
                className="image"
                src={imgLogo}
                alt="图片"
              />
              <p className="title is-5">
                &nbsp;&nbsp;51品茶
              </p>
            </a>
          </Link>
          <a
            role="button"
            className={`
              ${isActive ? 'is-active' : ''}
              navbar-burger
            `}
            aria-label="menu"
            aria-expanded="false"
            onClick={mobileToggleNavItem}
          >
            <span aria-hidden="true"></span>
            <span aria-hidden="true"></span>
            <span aria-hidden="true"></span>
          </a>
        </div>
        <div
          className={`
            ${isActive ? 'is-active' : ''}
            navbar-menu
          `}
        >
          <div className="navbar-start">
            {buildItem()}
            {buildMoreBtn()}
          </div>
          <div className="navbar-end">
            <div className="navbar-item">
              <div className="buttons">
                <a className="button is-primary">
                  <strong>注册</strong>
                </a>
                <a className="button is-light">
                  登陆
                </a>
              </div>
            </div>
          </div>
        </div>
      </nav>
    </header>
  )
}
