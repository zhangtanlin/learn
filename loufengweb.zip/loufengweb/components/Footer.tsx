import type { NextPage } from 'next'

// 默认脚部
export const FooterDefault: NextPage = () => {
  return (
    <footer className="container">
      脚部
    </footer>
  )
}
