import { MetaType } from "@/types/base"

// 请求路由基础地址
export const BASE_URL = 'http://localhost:3000'

// meta 名称
export const META_NAME = '网站名'

// meta 公共描述
export const META_BASE: MetaType = {
  title: `${META_NAME}-默认标题`,
  description: `${META_NAME}默认描述`,
  keywords: '关键字1,关键字2,关键字3,关键字4,关键字5'
}
