This is a [Next.js](https://nextjs.org/) project bootstrapped with [`create-next-app`](https://github.com/vercel/next.js/tree/canary/packages/create-next-app).

## 开始

First, run the development server:

```bash
npm run dev
# or
yarn dev
```

用浏览器打开 [http://localhost:3030](http://localhost:3030) 进行预览.

`pages/index.tsx`. 路由是首页

[API routes](https://nextjs.org/docs/api-routes/introduction) can be accessed on [http://localhost:3000/api/hello](http://localhost:3000/api/hello). This endpoint can be edited in `pages/api/hello.ts`.

The `pages/api` directory is mapped to `/api/*`. Files in this directory are treated as [API routes](https://nextjs.org/docs/api-routes/introduction) instead of React pages.

## 学习更多

To learn more about Next.js, take a look at the following resources:

- [Next.js Documentation](https://nextjs.org/docs) - learn about Next.js features and API.
- [Learn Next.js](https://nextjs.org/learn) - an interactive Next.js tutorial.

You can check out [the Next.js GitHub repository](https://github.com/vercel/next.js/) - your feedback and contributions are welcome!

## 在Vercel上部署

The easiest way to deploy your Next.js app is to use the [Vercel Platform](https://vercel.com/new?utm_medium=default-template&filter=next.js&utm_source=create-next-app&utm_campaign=create-next-app-readme) from the creators of Next.js.

Check out our [Next.js deployment documentation](https://nextjs.org/docs/deployment) for more details.

## 参考学习文档：
- [html语义化标签文档](https://www.w3schools.com/tags/default.asp) - https://www.w3schools.com/tags/default.asp

- [响应式框架【bulma】](https://bulma.io/) - https://bulma.io/

- [事例文档](https://github.com/unicodeveloper/awesome-nextjs) - https://github.com/unicodeveloper/awesome-nextjs
- [github事例文档(ts文档)](https://github.com/vercel/next.js) - https://github.com/vercel/next.js
- [客户端/服务端代码区别](https://www.chkui.com/article/react/nextjs_component_ssr) - https://www.chkui.com/article/react/nextjs_component_ssr
- [中文文档](https://nextjs.frontendx.cn/docs/#%E5%AE%89%E8%A3%85) - https://nextjs.frontendx.cn/docs/#%E5%AE%89%E8%A3%85
- [中文文档-面试哥](https://www.mianshigee.com/tutorial/next.js-zh/) - https://www.mianshigee.com/tutorial/next.js-zh/

## 客户端/服务端数据共享相关
- [1:Next.js集成状态管理器共享access token以及access token过期解决方案](https://segmentfault.com/a/1190000040610201) - https://segmentfault.com/a/1190000040610201
- [2:Next.js集成状态管理器共享access token以及access token过期解决方案](https://codeantenna.com/a/v7a6tJfcPY) - https://codeantenna.com/a/v7a6tJfcPY
使用插件：
使用@reduxjs/toolkit集成reducer并创建store，
使用next-redux-wrapper连接next.js和redux，
使用next-redux-cookie-wrapper注册要共享到cookie的slice信息。
