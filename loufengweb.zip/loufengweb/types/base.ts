// meta参数类型
// keywords：关键字
// description：描述
// title：标题
export type MetaType = {
  keywords: string
  description: string
  title: string
}

// 首页导航类型
// id：导航id
// name：导航名称
// src：导航链接
export type HomeNav = {
  id: number,
  name: string,
  pid: number,
  alias: string,
  type: number,
  href: string,
  target: string,
  icon: string,
  is_show: number,
  is_navigation: number,
  permission: string,
  description: string,
  children: any[]


}
