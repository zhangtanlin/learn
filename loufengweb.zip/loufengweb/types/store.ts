// 客户端/服务端共享的用户信息
// token: 用户token
// isLogin: 是否登陆
export type StoreUser = {
  token: string
  isLogin: boolean
}
