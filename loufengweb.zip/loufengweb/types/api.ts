// api接口基础类型
export type BasicType = {
  data: any,
  status: number,
  message: string,
}
