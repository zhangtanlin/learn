import PaginationDefault from '@/components/pagination'
import { apHomeNav } from '@/request/api'
import type { GetServerSidePropsContext, InferGetServerSidePropsType, NextPage } from 'next'
import { axiosSSR } from 'request/interceptor'

export async function getServerSideProps() {
  // 用户列表
  var list: any[] = []
  // 请求
  const res: any = await axiosSSR.post(
    apHomeNav,
    {
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        'account': 'admin',
        'password': 'qaz@123456'
      }),
    }
  )
  list = res?.data?.list || []
  return {
    props: {
      list,
    }
  }
}

// 测试页面
export default function Search(
  {
    list
  }:InferGetServerSidePropsType<typeof getServerSideProps>
) {
  return (
    <>
      <main>
        <p>测试首页</p>
        <div className="container">
          {list?.map((item, index) => (
            <div key={`test-item-${index}`}>
              {item.name}
            </div>
          ))}
        </div>
        <PaginationDefault/>
      </main>
    </>
  )
}


