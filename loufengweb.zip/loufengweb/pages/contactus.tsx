import { HeaderDefault } from '@/components/Header'
import { MetaDefault } from '@/components/Meta'
import { HomeNav } from '@/types/base'
import { META_BASE } from '@/utils/const'

// 联系我们参数类型
type ContactUsProps = {
  list: HomeNav[],
}

// 联系我们
const ContactUs = (props: ContactUsProps) => {
  return (
    <>
      <MetaDefault props={META_BASE}/>
      <HeaderDefault list={props.list}/>
      <nav className="breadcrumb" aria-label="breadcrumbs">
        <ul>
          <li><a href="#">首页</a></li>
          <li className="is-active"><a href="#">联系我们</a></li>
        </ul>
      </nav>
    </>
  )
}

export default ContactUs
