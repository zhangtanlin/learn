import type { AppProps } from 'next/app'
import { wrapper } from '@/store'
import '@/styles/bulma.css'

// 使用 next-redux-wrapper 插件将redux store数据注入到next.js。
function MyApp({ Component, pageProps }: AppProps) {
  return <Component {...pageProps} />
}

export default wrapper.withRedux(MyApp)
