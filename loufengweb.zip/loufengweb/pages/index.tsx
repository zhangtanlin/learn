import Link from 'next/link'
import { HeaderDefault } from '@/components/Header'
import { apHomeNav } from '@/request/api'
import { axiosSSR } from '@/request/interceptor'
import { HomeNav } from '@/types/base'
import { META_BASE } from '@/utils/const'
import { MetaDefault } from '../components/Meta'

// 服务端-请求导航列表
export async function getServerSideProps() {
  var list: HomeNav[] = []
  const res = await axiosSSR.post(
    `${apHomeNav}`,
  )
  if (res.status) {
    list = res.data || []
  }
  return {
    props: {
      list,
    }
  }
}

// 首页参数类型
type HomePageProps = {
  list: HomeNav[],
}

// 首页
const Home = (props: HomePageProps) => {
  return (
    <>
      <MetaDefault props={META_BASE} />
      <HeaderDefault list={props.list} />
      <main>
        <Link href="/test/123">
          <span>text路由</span>
        </Link>
        <br />
        <Link href="/contactus">
          <span>联系我们</span>
        </Link>
        <h1 className="title is-1">标题 h1</h1>
        <h2 className="title is-2">标题 h2</h2>
        <h3 className="title is-3">标题 h3</h3>
        <h4 className="title is-4">标题 h4</h4>
        <h5 className="title is-5">标题 h5</h5>
        <h6 className="title is-6">标题 h6</h6>
        <br />
        <h1 className="subtitle is-1">副标题 h1</h1>
        <h2 className="subtitle is-2">副标题 h2</h2>
        <h3 className="subtitle is-3">副标题 h3</h3>
        <h4 className="subtitle is-4">副标题 h4</h4>
        <h5 className="subtitle is-5">副标题 h5</h5>
        <h6 className="subtitle is-6">副标题 h6</h6>
        <br />
        <h5 className="title is-6">标题h6和副标题h6同在一起间距会缩小</h5>
        <h5 className="subtitle is-6">标题h6和副标题h6同在一起间距会缩小</h5>
        <br />
        <h5 className="title is-5 is-spaced">
          标题h5和副标题h5同在一起,使用 is-spaced 间距会呈现常态
        </h5>
        <h5 className="subtitle is-5">
          标题h5和副标题h5同在一起,使用 is-spaced 间距会呈现常态
        </h5>
      </main>
    </>
  )
}

export default Home
