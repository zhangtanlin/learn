import PaginationDefault from '@/components/pagination'
import type { GetServerSidePropsContext, InferGetServerSidePropsType, NextPage } from 'next'
import { axiosSSR } from 'request/interceptor'

export async function getServerSideProps(
  context: GetServerSidePropsContext
) {
  // 用户列表
  var list: any[] = []
  // 请求
  const res: any = await axiosSSR.post(
    'http://10.211.55.3:3000/admin/user/list',
    {
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        'account': 'admin',
        'password': 'qaz@123456'
      }),
    }
  )
  list = res?.data?.list || []
  return {
    props: {
      list,
    }
  }
}

// 测试页面
export default function Test(
  {
    list
  }:InferGetServerSidePropsType<typeof getServerSideProps>
) {
  return (
    <>
      <main>
        <p>测试首页</p>
        <div className="container">
          {list?.map((item, index) => (
            <div key={`test-item-${index}`}>
              {item.name}
            </div>
          ))}
        </div>
        <PaginationDefault/>
      </main>
    </>
  )
}


