import { useRouter } from 'next/router'
import { useEffect, useState } from 'react'
import { Loading } from '@/components/Loading'
import { NoData } from '@/components/Nodata'
import { apiLogin } from '@/request/api'
import { axiosDynamic } from '@/request/interceptor'

function TextId() {
  const router = useRouter()
  const { id } = router.query
  const [loading, setLoading] = useState(true)
  const [page, setPage] = useState(1)
  const [limit, setLimit] = useState(10)
  const [data, setData] = useState(null)
  useEffect(() => {
    const getData = async() => {
      try {
        const res = await axiosDynamic.post(
          apiLogin,
          {
            headers: {
              'Content-Type': 'application/json',
            },
            method: 'POST',
            body: JSON.stringify({
              'account': 'admin',
              'password': 'qaz@123456'
            }),
          }
        )
        console.log('res', res)
        if (res?.status) {
          setData(res?.data)
          setLoading(false)
        }
      } catch (error) {
        console.log('error', error)
      }
    }
    getData()
  }, [])

  // 设置列表
  const buildData = () => {
    if (loading) {
      return <Loading />
    } else if (!data) {
      return <NoData />  
    } else {
      return <p className="container">
        {data['token']}
      </p>
    }
  }

  return (
    <div>
      <p>Post:{ id }</p>
      {buildData()}
    </div>
  )
}

// 动态路由
export default TextId