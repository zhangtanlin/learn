import { useRouter } from "next/router"
import { useEffect, useState } from "react";
import { Loading } from "@/components/Loading";
import { NoData } from "@/components/Nodata";

function TextId() {
  const router = useRouter();
  const { id } = router.query;
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(10);
  const [data, setData] = useState(null);
  useEffect(() => {
    const getData = async() => {
      try {
        const res = await fetch(
          `http://10.211.55.3:3000/admin/user/login`,
          {
            headers: {
              'Content-Type': 'application/json',
            },
            method: 'POST',
            body: JSON.stringify({
              "account": "admin",
              "password": "qaz@123456"
            }),
          }
        );
        const dataJSON = await res.json();
        console.log('dataJSON', dataJSON);
        if (dataJSON?.status === 200) {
          setData(dataJSON?.data);
          setLoading(false);
        }
      } catch (error) {
        console.log('error', error);
      }
    }
    getData();
  }, [])

  // 设置列表
  const buildData = () => {
    if (loading) {
      return <Loading />;
    } else if (!data) {
      return <NoData />  
    } else {
      return <p className="container">
        {data['token']}
      </p>;
    }
  }

  return (
    <div>
      <p>Post:{ id }</p>
      {buildData()}
    </div>
  );
}

// 动态路由
export default TextId;