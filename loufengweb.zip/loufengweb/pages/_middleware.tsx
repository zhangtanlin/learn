import { NextRequest } from 'next/server'

// 首页中间件
export async function middleware(req: NextRequest) {
  // return new Response(
  //   JSON.stringify({
  //     uuid: crypto.randomUUID(),
  //     randomValues: 'randomValues',
  //   }),
  //   { headers: { 'Content-Type': 'application/json' } }
  // )
}




