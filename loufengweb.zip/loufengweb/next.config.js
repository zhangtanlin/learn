/** @type {import('next').NextConfig} */

// 获取环境变量
const isProduction = process.env.NODE_ENV === 'production'

const nextConfig = {
  reactStrictMode: true,
  // 环境变量
  env: {
    text: 'text',
  },
  // 路由前缀
  basePath: '',
  // 重定向路由
  async rewrites() {
    return []
  },
  // 对给定路径传入自定义header
  async headers() {
    return []
  },
  // 静态资源配置cdn
  assetPrefix: isProduction ? '' : '',
  // 是否开启gzip压缩
  compress: true,
  // 是否取消解析尾部带有斜杠的路由
  trailingSlash: false,
  // 设置需要"next/Images"保护的远程图像地址
  images: {
    domains: [
      '10.211.55.3:3000',
    ]
  },
}

module.exports = nextConfig
