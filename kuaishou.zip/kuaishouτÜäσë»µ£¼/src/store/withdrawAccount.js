import { createStore } from 'react-hooks-global-state';

const initialState = {
  // 提现银行卡账号
  accountInfo: {},
};

const reducer = (state, action) => {
  if (action.type === 'replace') {
    return { ...state, accountInfo: action.payload };
  }
  return state;
};

const AccountStore = createStore(reducer, initialState);

export default AccountStore;
