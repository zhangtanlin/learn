import { createStore } from 'react-hooks-global-state';

// 整合接口需要保存的信息
const initialState = {
  config: {
    // tg地址
    tg: '',
    // 图片上传地址
    imgUploadUrl: '',
    // 观看次数
    watch_count: '',
    // token
    token: '',
  },
};

const reducer = (state, action) => {
  if (action.type === 'replace') {
    return { ...state, config: { ...state.config, ...action?.payload } };
  }
  return state;
};

const ConfigStore = createStore(reducer, initialState);

export default ConfigStore;
