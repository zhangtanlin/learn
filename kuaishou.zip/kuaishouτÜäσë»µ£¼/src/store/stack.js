import { createStore } from 'react-hooks-global-state';

const initialState = {
  stacks: [],
};

const reducer = (state, action) => {
  if (action.type === 'push') {
    return { ...state, stacks: state.stacks.concat([action.payload]) };
  } if (action.type === 'pop') {
    state.stacks.pop(); return { ...state, stacks: [...state.stacks] };
  } if (action.type === 'replace') {
    state.stacks[state.stacks.length - 1] = action.payload;
    return { ...state, stacks: [...state.stacks] };
  }
  return state;
};

const StackStore = createStore(reducer, initialState);

export default StackStore;
