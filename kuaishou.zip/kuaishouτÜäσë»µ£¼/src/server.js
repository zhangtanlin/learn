import React from "react";

export default class Server {
  // eslint-disable-next-line
  apply(serverHandler) {
    serverHandler.hooks.beforeHtmlRender.tapPromise(
      "DSNPreCache",
      async Application => {
        const {
          htmlProps: { head }
        } = Application;
        head.push(<script key={`script-${new Date().getTime()}`} async dangerouslySetInnerHTML={{
          __html: `
        (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
          (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
          m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
          })(window,document,'script','js/analytics.js','ga');

          ga('create', 'UA-137257734-1', {
              'storage': 'none',
              'clientId': localStorage.getItem('ga:clientId')
          });
          ga(function(tracker) {
              localStorage.setItem('ga:clientId', tracker.get('clientId'));
          });
          ga('set', 'checkProtocolTask', null);
          ga('set', 'page', 'index');
          ga('send', 'pageview');
        `}} />);
        // head.push(<link key="dns-precache-codefund" rel="preconnect" href="https://codefund.app" />);
        // head.push(<link key="dns-precache-google-analytics" rel="preconnect" href="https://www.google-analytics.com" />);
        // head.push(<link key="dns-precache-googletagmanager" rel="preconnect" href="https://www.googletagmanager.com" />);
        // head.push(<link key="dns-precache-cdn-codefund" rel="preconnect" href="https://cdn2.codefund.app" />);
        // head.push(<meta key="meta-theme-color" name="theme-color" content="#209cee" />);
        //
      }
    );

    serverHandler.hooks.beforeHtmlRender.tapPromise(
      "AddFavIcon",
      async Application => {
        const {
          htmlProps: { head }
        } = Application;
        head.push(
          <meta
            key="viewport"
            name="viewport"
            content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"
          />
        );
        head.push(<meta key="screen-orientation-1" name="screen-orientation" content="portrait" />);
        head.push(<meta key="x5-orientation" name="x5-orientation" content="portrait" />);
        head.push(<meta key="full-screen" name="full-screen" content="yes" />);
        head.push(<meta key="x5-fullscreen" name="x5-fullscreen" content="true" />);
        head.push(<meta key="screen-orientation-2" name="screen-orientation" content="portrait" />);
        return true;
      }
    );

    // serverHandler.hooks.beforeHtmlRender.tapPromise('AddCodeFundScript', async (Application) => {
    //   Application.htmlProps.footer.push(<script id="js-codefund" async key="codefund" data-src="https://codefund.app/properties/136/funder.js" />);
    // });

    // serverHandler.hooks.beforeHtmlRender.tapPromise('AddGoogleTracking', async (Application) => {
    //   Application.htmlProps.footer.push(<script async key="googleanalyticslink" src="https://www.googletagmanager.com/gtag/js?id=UA-108804791-2" />);
    //   Application.htmlProps.footer.push(<script
    //     key="googleanalyticsscript"
    //     // eslint-disable-next-line
    //     dangerouslySetInnerHTML={{
    //       __html: `window.dataLayer = window.dataLayer || [];
    //         function gtag(){dataLayer.push(arguments);}
    //         gtag('js', new Date());
    //         gtag('config', 'UA-108804791-2');`,
    //     }}
    //   />);
    // });
  }
}
