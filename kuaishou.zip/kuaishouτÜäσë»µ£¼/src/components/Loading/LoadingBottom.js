import React from "react";
import "../../resources/css/loading/loading_bottom.less";

// 底部loading
export default () => (
  <div className="loading_bottom">
    <div/>
  </div>
);
