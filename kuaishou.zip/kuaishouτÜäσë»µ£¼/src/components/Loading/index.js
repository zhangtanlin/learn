import React from "react";
import "../../resources/css/loading/index.less";

export default (props) => {
  const { text, show, overSize = true, size = 30 } = props;
  if (!show) {
    return "";
  }
  return (
    <div className={overSize ? "loading" : "loading-in-page"}>
      <div
        className="skCircleFade"
        style={{ width: `${size}px`, height: `${size}px` }}
      >
        {(() => {
          const ary = [];
          for (let i = 0; i < 12; i++) {
            ary.push(
              <div
                key={`loading-${i}`}
                className={`
                  skCircleFadeDot
                  ${overSize ? "" : "skCircleFadeDot1"}
                `}
              />
            );
          }
          return ary;
        })()}
      </div>
      <span>{text}</span>
    </div>
  );
};
