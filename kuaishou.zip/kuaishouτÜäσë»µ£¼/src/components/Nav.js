import React, { useMemo, useState } from "react";
import '../resources/css/nav.less';

import StackPage from "./StackPage";
import StackStore from "../store/stack";
import ClickBtn from "./ClickBtn";
import Simg from './Simg';
import Follow from "./Follow";
import Collection from "./Mv/Collection";
import Tag from "./Mv/Tag";
import Login from "./Login";
import Find from "./Mv/Find";

// 导航行(等分一行)
export const NavRow = (props) => {
  const { list } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const handle = (item) => {
    let tempName = 'Login';
    let tempStackKey = `Login-${new Date().getTime()}`;
    let tempPage = <Login stackKey={tempStackKey} />;
    switch (item?.type) {
      case 'follow':
        tempName = 'Follow';
        tempStackKey = `Follow-${new Date().getTime()}`;
        tempPage = <Follow stackKey={tempStackKey} />;
        break;
      case 'find-video':
        tempName = 'Find';
        tempStackKey = `Find-${new Date().getTime()}`;
        tempPage = <Find stackKey={tempStackKey} />;
        break;
      case 'topic':
        tempName = 'Collection';
        tempStackKey = `Collection-${new Date().getTime()}`;
        tempPage = <Collection stackKey={tempStackKey} />;
        break;
      case 'tag-video':
        tempName = 'Tag';
        tempStackKey = `Tag-${new Date().getTime()}`;
        tempPage = <Tag stackKey={tempStackKey} />;
        break;
      default:
        break;
    }
    StackStore.dispatch({
      type: "push",
      payload: {
        name: tempName,
        element: (
          <StackPage
            stackKey={tempStackKey}
            key={tempStackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            {tempPage}
          </StackPage>
        ),
      },
    });
  };
  return useMemo(() => (
    list?.length ? (
      <div className="nav-row">
        {list?.map((item, index) => (
          <ClickBtn
            key={`nav-row-item-${index}`}
            className="item"
            onTap={() => handle(item)}
          >
            <div className="icon-box">
              <Simg src={item?.icon} />
            </div>
            <div className="text">
              {item?.name}
            </div>
          </ClickBtn>
        ))}
      </div>
    ) : <></>
  ), [list]);
};

/**
 * 首页底部导航
 * @param {array} props.list 导航列表
 * @param {number} props.activeIndex 选中的序列号
 * @param {function} props.onTap 导航列表
 * @param {string} props.theme 主题{null:白色主题,black:黑色主题,}
 * @returns
 */
export const NavHome = (props) => {
  const { list, activeIndex, onTap, } = props;
  const [theme, setTheme] = useState('');
  return useMemo(() => (
    <div className={`nav-home ${theme ? 'black' : ''}`}>
      {list?.map((t, index) => (
        <ClickBtn
          key={`home-nav-item-${index}`}
          className={`
            item
            ${activeIndex === index ?
              "active" :
              ""
            }
          `}
          onTap={() => {
            if (index === 1) {
              setTheme('black')
            } else {
              setTheme('')
            };
            onTap && onTap(index);
          }}
        >
          <img
            src={
              activeIndex === index ?
                t.iconActive :
                t.icon
            }
          />
          <p>{t.name}</p>
        </ClickBtn>
      ))}
    </div>
  ), [list, activeIndex, theme]);
}
