import React, { useEffect, useRef } from "react";
import Hammer from "hammerjs";
import "../resources/css/click_btn.less";

// 点击事件
export default props => {
  const { onTap, children, className, styles } = props;
  const clickRef = useRef(null);
  const handle = (e) => {
    e.preventDefault();
    onTap && onTap();
  };
  useEffect(() => {
    if (!clickRef.current) return;
    const hammer = new Hammer(clickRef.current);
    hammer.on("tap", handle);
    return () => {
      hammer.off("tap", handle);
    };
  }, [clickRef.current]);
  return (
    <div
      className={`click_btn ${className}`}
      style={styles}
      ref={clickRef}
    >
      {children}
    </div>
  );
};
