import React, { useEffect, useState } from "react";
import "../resources/css/toast.less";

import emit from "../libs/eventEmitter";

export default () => {
  const [text, setText] = useState("");
  const [time, setTime] = useState(2000);
  const [isHide, setIsHide] = useState(true);
  let timer;
  useEffect(() => {
    emit.on("showToast", (data) => {
      setIsHide(false);
      data.text && setText(data.text);
      data.time && setTime(data.time);
      timer && clearTimeout(timer);
      timer = setTimeout(() => {
        setIsHide(true);
        // setText("");
        setTime(2000);
      }, time);
    });
    return () => {
      emit.off("showToast");
    };
  }, []);
  return (
    <div className={`toast ${isHide ? "toast-out" : "toast-in"}`}>
      <div>{text}</div>
    </div>
  );
};
