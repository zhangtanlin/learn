import React, { useEffect, useState, useRef, useMemo } from 'react';
import Compressor from 'compressorjs'
import "../../resources/css/help/service.less";

import UserStore from '../../store/user';
import ScrollArea from '../ScrollArea';
import HeaderBack from '../Header/HeaderBack';
import Simg from '../Simg';
import ClickBtn from '../ClickBtn';
import Loading from '../Loading';
import Emit from '../../libs/eventEmitter';
import Const from '../../libs/const';
import { NoData } from '../NoData';
import { UploadRequest } from '../../libs/uploadImg';
import {
  apiGetFeedList,
  apiSendFeed,
} from '../../libs/http';

import imgIcon from '../../resources/img/icon_img.png';
import iconLogo from '../../resources/img/icon_logo.png';
import sendIcon from '../../resources/img/icon_send.png';

// 在线客服
export default props => {
  const { stackKey } = props;
  const [UserInfo] = UserStore.useGlobalState('user');
  const [loadingImg, setLoadingImg] = useState(false);
  const [loading, setLoading] = useState(true);
  const [params, setParams] = useState({
    page: 1,
    isAll: false,
  });
  const [data, setData] = useState([]);
  const [loadingMore, setLoadingMore] = useState(true);
  const inputRef = useRef(null);
  const getData = async () => {
    if (params?.isAll) {
      return;
    }
    setLoadingMore(true);
    try {
      const res = await apiGetFeedList(params);
      if (res?.status) {
        if (params.page === 1) {
          setData(res?.data || []);
        } else {
          setData([...res?.data || [], ...data]);
        }
        if (!res?.data?.length) {
          setParams({ ...params, isAll: true });
        }
      } else {
        Emit.emit('showToast', {
          text: res?.msg || '请求消息列表失败',
          time: 5000
        });
      }
    } catch (error) {
      Emit.emit('showToast', {
        text: '请求失败',
        time: 5000
      });
    }
    setLoading(false);
    setLoadingMore(false);
  };
  const nextPage = () => {
    if (!params?.isAll) {
      setParams((tempParam) => ({
        ...tempParam,
        page: tempParam?.page + 1
      }));
    }
  };
  useEffect(() => {
    getData();
  }, [params]);
  const sendMsg = async (data) => {
    if (!data?.thumb && !data?.content) {
      Emit.emit("showToast", { text: "请输入内容！" });
      return;
    }
    try {
      const tempParam = {
        content: data?.content || '',
        thumb: data?.thumb || ''
      };
      const res = await apiSendFeed(tempParam);
      if (res?.status) {
        inputRef.current.value = '';
        setParams({
          page: 1,
          isAll: false,
        })
        Emit.emit('showToast', {
          text: res?.data?.msg || '发送消息成功',
          time: 5000
        });
      } else {
        Emit.emit('showToast', {
          text: res?.msg || '发送消息失败',
          time: 5000
        });
      }
    } catch (error) {
      Emit.emit('showToast', {
        text: '请求失败',
        time: 5000
      });
    }
    setLoadingImg(false); // 关闭发送图片的loading
  };

  const onSetCover = async ({ target }) => {
    setLoadingImg(true);
    const imgFile = new FileReader();
    const file = target.files[0]
    if (!file) return;
    new Compressor(file, {
      quality: 0.8,
      maxWidth: 1000,
      maxHeight: 1000,
      success(result) {
        if (result?.size / 1024 > 1024) {
          Emit.emit('showToast', {
            text: '图片压缩后大小仍超出限制，请上传1M以下的图片',
            time: 5000
          })
          return;
        }
        imgFile.readAsDataURL(result)
        imgFile.onload = () => {
          UploadRequest({
            id: new Date().getTime(),
            cover: imgFile.result
          }).then(res => {
            sendMsg({ thumb: res })
          }).catch(() => {
            setLoadingImg(false);
          });
        }
      }
    })
  };
  const leftDialog = (data) => (
    <div className="user-dialog-item">
      <p className="title">{data.addtime_str}</p>
      <div className="left_dialog">
        <div className="use_thumb">
          <img
            src={iconLogo}
            style={{
              objectFit: 'cover',
              width: '100%',
              height: '100%'
            }}
          />
        </div>
        <div className="left_content">
          {data?.reply_content}
        </div>
      </div>
    </div>
  );
  const rightDialog = (data) => (
    <div className="user-dialog-item">
      <p className="title">{data?.addtime_str}</p>
      <div className="right_dialog">
        <div className="right_content">
          {data?.content && <p>{data?.content}</p>}
          {data?.thumb_full && (
            <div style={{ width: '4rem' }}>
              <Simg objectFit="contain" isZoom src={data?.thumb_full} />
            </div>
          )}
        </div>
        <div className="use_thumb">
          <Simg src={UserInfo?.avatar_url} />
        </div>
      </div>
    </div>
  );
  return useMemo(() => (
    loading ? (
      <Loading show overSize={false} />
    ) : (
      <div className="positioned-container">
        <HeaderBack
          stackKey={stackKey}
          title={Const.titleOnlineService}
        />
        {data?.length ? (
          <ScrollArea
            ListData={data?.length}
            loadingMore={loadingMore}
            pullDonRefresh={nextPage}
            startToBottom
            noEndText
          >
            {data?.map((item, index) => (
              <div
                key={`user-dialog-box-${index}`}
                className="user-dialog-box"
              >
                {(item?.content || item?.thumb_full) && (
                  rightDialog(item)
                )}
                {item?.reply_content && (
                  leftDialog(item)
                )}
              </div>
            ))}
          </ScrollArea>
        ) : <NoData text="还没有聊天记录哦～" />}
        <div className="user-service-bottom">
          <div className="send-img-box">
            <input
              type="file"
              accept="image/*"
              onChange={onSetCover}
            />
            <img className="send-img" src={imgIcon} />
          </div>
          <div className="input-box">
            <input placeholder="请详细描述您的问题" ref={inputRef} />
          </div>
          <ClickBtn
            className="send-icon"
            onTap={() => {
              sendMsg({
                content: inputRef.current.value,
              });
            }}
          >
            <img src={sendIcon} />
          </ClickBtn>
        </div>
        {loadingImg && <Loading show />}
      </div>
    )
  ), [loading, data, loadingMore, loadingImg]);
};
