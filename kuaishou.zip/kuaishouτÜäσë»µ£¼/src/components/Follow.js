import React, { useMemo, useState, useEffect } from "react";

import Loading from './Loading';
import ScrollArea from './ScrollArea';
import Emit from "../libs/eventEmitter";
import { VideoFollowItem } from "./Card/CardVideo";
import { NoData, FollowHeaderNoData } from "./NoData";
import { apiFollowIndex } from "../libs/http";
import { ListRecommendUser } from "./List/User";
import HeaderBack from "./Header/HeaderBack";
import Const from "../libs/const";

// 关注
export default (props) => {
  const { stackKey } = props;
  const [loading, setLoading] = useState(true);
  const [params, setParams] = useState({
    page: 1,
    isAll: false,
  });
  const [data, setData] = useState([]);
  const [type, setType] = useState(0); // {0: 关注的用户的视频,1: 推荐用户}
  const [loadingMore, setLoadingMore] = useState(true);
  const getData = async () => {
    if (params?.isAll) {
      return;
    }
    setLoadingMore(true);
    try {
      const res = await apiFollowIndex(params);
      if (res?.status) {
        const tempMv = res?.data?.followMv || [];
        const tempRecommend = res?.data?.followRecommend || [];
        let tempList = [];
        if (tempMv?.length) {
          tempList = tempMv || [];
        } else {
          tempList = tempRecommend || [];
          setType(1);
        }
        if (params?.page === 1) {
          setData(tempList);
        } else {
          setData([...data, ...tempList]);
        }
        if (!tempList?.length) {
          setParams({ ...params, isAll: true });
        }
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
      });
    }
    setLoading(false);
    setLoadingMore(false);
  };
  const refresh = () => {
    setParams((tempParam) => ({
      ...tempParam,
      page: 1,
      isAll: false
    }));
  };
  const nextPage = () => {
    if (!params?.isAll) {
      setParams((tempParam) => ({
        ...tempParam,
        page: tempParam?.page + 1
      }));
    }
  };
  useEffect(() => {
    getData();
  }, [params]);
  return useMemo(() => (
    <div className="positioned-container">
      <HeaderBack
        stackKey={stackKey}
        title={Const.titleFollow}
      />
      {loading ? (
        <Loading show overSize={false} />
      ) : (
        data?.length ? (
          <ScrollArea
            loadingMore={loadingMore}
            onScrollEnd={nextPage}
            pullDonRefresh={refresh}
          >
            <List type={type} list={data} />
          </ScrollArea>
        ) : <NoData />
      )}
    </div>
  ), [loading, data, type, loadingMore]);
};

/**
 * 根据type加载不同的列表
 * @param {*} props.type {0: 关注的用户的视频,1: 推荐用户}
 */
export const List = (props) => {
  const { type, list } = props;
  return (
    type === 1 ? (
      <>
        <FollowHeaderNoData />
        <div className="public-padding">
          {list?.length ? (
            <ListRecommendUser list={list} />
          ) : <></>}
        </div>
      </>
    ) : (
      <div className="public-column2 public-padding">
        {list?.length ? list.map((item, index) => (
          <VideoFollowItem
            key={`FansItem-${index}`}
            item={item}
          />
        )) : <></>}
      </div>
    )
  );
};
