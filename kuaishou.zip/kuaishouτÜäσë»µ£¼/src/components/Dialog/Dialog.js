import React, { useEffect, useState } from "react";
import Emit from "../../libs/eventEmitter";
import "../../resources/css/dialog/index.less";

export default () => {
  const [show, setShow] = useState(false);
  const [children, setChildren] = useState(<></>);
  const [hideSelf, setHideSelf] = useState(true);
  useEffect(() => {
    Emit.on("changeDialog", ({
      _show,
      _children,
    }) => {
      setShow(_show || true);
      setChildren(_children);
    });
  }, []);
  useEffect(() => {
    if (show) {
      setHideSelf(false);
      setTimeout(() => {
        if (
          document &&
          document.getElementsByClassName("dialog_scaleLayer")[0]
        ) {
          document
            .getElementsByClassName("dialog_scaleLayer")[0]
            .classList.add("dialog_scale-in");
        }
      }, 100);
    } else {
      if (document && document.getElementsByClassName("dialog_scaleLayer")[0]) {
        document
          .getElementsByClassName("dialog_scaleLayer")[0]
          .classList.add("dialog_scale-out");
      }
      setTimeout(() => {
        setHideSelf(true);
      }, 300);
    }
  }, [show]);
  if (hideSelf) {
    return null;
  }
  return (
    <div className="dialog_scaleLayer">
      <div
        className="dialog_scaleLayer-close"
        onClick={() => {
          setShow(false);
        }}
      />
      <div className="dialog_scaleLayer-body">
        {children}
      </div>
    </div>
  );
};
