import React, { useMemo, useState, useEffect, useRef } from "react";
import "../../resources/css/dialog/captcha.less";

import ClickBtn from "../ClickBtn";
import Emit from "../../libs/eventEmitter";
import { apiGetImgCode } from '../../libs/http';

// 验证码弹出框(DialogCaptcha)
export default () => {
  const [show, setShow] = useState(false);
  const [imgCode, setImgCode] = useState(null);
  const [code, setCode] = useState(null);
  const [loading, setLoading] = useState(true);
  const submitFnRef = useRef(null);
  const cancelFnRef = useRef(null);
  const getcode = async () => {
    setLoading(true);
    try {
      const res = await apiGetImgCode();
      if (res?.status) {
        setImgCode(res?.data?.verifyUrl);
      } else {
        Emit.emit("showToast", {
          text: res?.msg || res?.data?.msg || "请求图形验证码失败",
          time: 3000
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
        time: 3000
      });
    }
    setLoading(false);
  };
  const handleSubmit = async () => {
    if (!code) {
      Emit.emit("showToast", { text: "验证码不能为空" });
      return;
    }
    try {
      if (submitFnRef?.current) {
        submitFnRef?.current && submitFnRef?.current(code);
      }
      handleCancel();
    } catch (error) {
      Emit.emit("showToast", { text: "请求失败" });
    }
  };
  const handleCancel = async () => {
    setShow(false);
    setImgCode('');
    setCode('');
  };
  useEffect(() => {
    Emit.on("changeCaptcha", async ({ show, onSubmit, onCancel }) => {
      if (show) {
        setShow(true);
        await getcode();
      } else {
        setShow(false);
        setImgCode('');
        setCode('');
      }
      if (onSubmit) {
        submitFnRef.current = onSubmit;
      }
      if (onCancel) {
        cancelFnRef.current = onCancel;
      }
    });
    return () => {
      Emit.off("changeCaptcha");
    };
  }, []);
  return useMemo(() => (
    <div className={`captcha_hide_box ${show ? "captcha_show_box" : ""}`}>
      <ClickBtn
        className="close_box"
        onTap={() => handleCancel()}
      />
      <div className="captcha_content">
        <div className="title">图形验证码</div>
        {loading ? (
          <div className="code_loading">正在加载图形码...</div>
        ) : (
          <ClickBtn
            className="code_img"
            onTap={() => {
              getcode();
            }}
          >
            <img src={imgCode} />
            <div className="code_img_btn">点击刷新</div>
          </ClickBtn>
        )}
        <div className="input_box">
          <input
            type="text"
            placeholder="请输入图形验证码"
            onChange={({ target }) => {
              const tempReplace = target.value.replace(/^\s+|\s+$/g, "");
              if (tempReplace.length > 10) {
                const tempCut = String(tempReplace).slice(0, 10);
                target.value = tempCut;
                setCode(tempCut);
                Emit.emit("showToast", {
                  text: "验证码不超过10位"
                });
              } else {
                target.value = tempReplace;
                setCode(tempReplace);
              }
            }}
          />
        </div>
        <ClickBtn
          className="submit_btn"
          onTap={() => handleSubmit()}
        >
          确定
        </ClickBtn>
      </div>
    </div>
  ), [show, loading, imgCode, code]);
};
