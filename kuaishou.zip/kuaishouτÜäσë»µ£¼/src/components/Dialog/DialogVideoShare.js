import React from "react";
import QRCode from "qrcode.react";
import "../../resources/css/dialog/video_share.less";

import Simg from "../Simg";
import Emit from "../../libs/eventEmitter";
import { copyText } from "../../libs/utils";

import logo from "../../resources/img/icon_logo.png";
import ClickBtn from "../ClickBtn";

// 视频分享弹出框内容部分
export default (props) => {
  const { data } = props;
  if (!data) {
    return <></>;
  }
  return (
    <div className="video_share">
      <div className="video_share_header">
        <img src={logo} />
        <p>{data?.title}</p>
      </div>
      <div className="video_share_cover">
        <Simg src={data?.thumbImg} />
        <div className="video_share_cover_playIcon">
          <div />
        </div>
      </div>
      <div className="video_share_tip">
        <div className="video_share_tip_qrcode">
          <QRCode
            style={{
              height: "100%",
              width: "100%",
            }}
            value={data?.shareUrl}
          />
        </div>
        <div className="video_share_tip_right">
          <div>
            <p>扫描二维码</p>
            <p>下载APP立即观看</p>
          </div>
          <div>
            若二维码无法打开请输入网址
            <span>{data?.shareUrl}</span>
          </div>
        </div>
      </div>
      <div className="video_share_bottom">
        <ClickBtn
          onTap={() => {
            Emit.emit(
              "showToast",
              { text: "请在本页面截图保存" },
            );
          }}
        >
          手动截图保存
        </ClickBtn>
        <ClickBtn
          onTap={() => {
            copyText(data?.shareUrl);
            Emit.emit(
              "showToast",
              { text: "复制成功！" },
            );
          }}
        >
          复制分享链接
        </ClickBtn>
      </div>
    </div>
  );
};
