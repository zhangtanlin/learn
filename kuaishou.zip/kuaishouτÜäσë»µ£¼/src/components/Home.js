import React, { useEffect, useMemo, useRef, useState } from "react";

import StackStore from "../store/stack";
import UserStore from "../store/user";
import VideoStore from "../store/video";
import ConfigStore from "../store/config";
import Featured from "./Featured";
import Mv from "./Mv";
import User from "./User";
import Announcement from "./Announcement";
import Alert from "./Alter";
import Toast from "./Toast";
import Sheet from "./Sheet/Sheet";
import Const from "../libs/const";
import DialogAd from "./Dialog/Ad";
import Dialog from "./Dialog/Dialog";
import Vip from "./Mv/Vip";
import Uploader from "./Mv/Uploader";
import Loading from "./Loading";
import GlobalVar from "../libs/GlobalVar";
import { stringToHtml } from '../libs/utils';
import { NavHome } from "./Nav";
import {
  apiGetHomeConfig,
  apiGetUserInfo,
} from "../libs/http";
import "../libs/defendCC";
import "../resources/orientationchange-fix.min.js";

import iconMv from "../resources/img/icon_home_mv.png";
import iconMvActive from "../resources/img/icon_home_mv_active.png";
import iconFeature from "../resources/img/icon_home_feature.png";
import iconFeatureActive from "../resources/img/icon_home_feature_active.png";
import iconVip from "../resources/img/icon_home_vip.png";
import iconVipActive from "../resources/img/icon_home_vip_active.png";
import iconUploader from "../resources/img/icon_home_uploader.png";
import iconUploaderActive from "../resources/img/icon_home_uploader_active.png";
import iconUser from "../resources/img/icon_home_user.png";
import iconUserActive from "../resources/img/icon_home_user_active.png";

export default () => {
  const [stacks] = StackStore.useGlobalState("stacks");
  const [user] = UserStore.useGlobalState("user");
  const [config] = ConfigStore.useGlobalState("config");
  const playerRef = useRef(null);
  const [loading, setLoading] = useState(true);
  const [initApp, setAppStatus] = useState(false); //初始化
  const [showNotice, setShowNotice] = useState(false); // 公告信息是否显示
  const [notice, setNotice] = useState(""); // 公告信息
  const [ad, setAd] = useState(); // 广告弹窗
  const [currentIndex, setCurrentIndex] = useState(0);
  const tabList = [
    {
      id: 1,
      name: Const.navMv,
      icon: iconMv,
      iconActive: iconMvActive,
    },
    {
      id: 2,
      name: Const.navFeatured,
      icon: iconFeature,
      iconActive: iconFeatureActive,
    },
    {
      id: 3,
      name: Const.navVip,
      icon: iconVip,
      iconActive: iconVipActive,
    },
    {
      id: 4,
      name: Const.navCreater,
      icon: iconUploader,
      iconActive: iconUploaderActive,
    },
    {
      id: 5,
      name: Const.navUser,
      icon: iconUser,
      iconActive: iconUserActive,
    },
  ];
  const getData = async () => {
    const getConfigInfo = await apiGetHomeConfig();
    if (getConfigInfo?.status) {
      console.log('整合接口', getConfigInfo?.data);
      const tempConfigData = {
        ...config,
        ...{
          tg: getConfigInfo?.data?.tg || '',
          imgUploadUrl: getConfigInfo?.data?.imgUploadUrl,
          watch_count: getConfigInfo?.data?.watch_count || '',
        }
      }; // 字段说明参考configStore
      ConfigStore.dispatch({
        type: "replace",
        payload: tempConfigData,
      });
      // 全局保存上传地址
      GlobalVar.imgUploadUrl = getConfigInfo?.data?.imgUploadUrl;
      // 公告信息
      setNotice(
        stringToHtml(
          getConfigInfo?.data?.maintain_tips
        )
      );
      setShowNotice(true);
      // 广告弹窗
      setAd({
        img_url: getConfigInfo?.data?.activity_thumb ?? "",
        url: getConfigInfo?.data?.activity_url ?? "",
        type: getConfigInfo?.data?.activity_type ?? "",
      });
    }
    // 用户信息
    const getUserInfo = await apiGetUserInfo();
    if (getUserInfo?.status) {
      console.log('用户信息', getUserInfo?.data);
      const tempUserData = {
        ...getUserInfo?.data,
      }; // 字段说明参考userStore
      UserStore.dispatch({
        type: "replace",
        payload: tempUserData,
      });
    }
    setLoading(false);
  };
  useEffect(() => {
    const token = localStorage.getItem(
      Const?.tokenKey
    );
    if (token) {
      const tempConfigData = {
        ...config,
        ...{ token }
      }; // 字段说明参考configStore
      ConfigStore.dispatch({
        type: "replace",
        payload: tempConfigData,
      });
    }
    if (!initApp) {
      setAppStatus(true);
    }
    document.body.addEventListener(
      "touchmove",
      (event) => {
        event.preventDefault();
      },
      { passive: false }
    );
    getData();
  }, []);
  return useMemo(() => (
    <div className="positioned-container">
      <div className="home-content">
        {loading ? (
          <Loading show overSize={false} />
        ) : (
          <>
            <Mv isVisible={currentIndex === 0}/>
            <Featured
              isVisible={currentIndex === 1}
              playerRef={playerRef}
            />
            <Vip isVisible={currentIndex === 2}/>
            <Uploader isVisible={currentIndex === 3} />
            <User isVisible={currentIndex === 4} />
          </>
        )}
      </div>
      <NavHome
        list={tabList}
        activeIndex={currentIndex}
        onTap={(index) => {
          setCurrentIndex(index);
          if (playerRef?.current) {
            playerRef?.current.pause();
            GlobalVar.videoPause = true;
            // 渲染状态
            const tempVideoData = {
              videoPause: false,
            };
            VideoStore.dispatch({
              type: "replace",
              payload: tempVideoData,
            });
          }
        }}
      />
      <div className="stack-pages-container">
        {stacks?.map((s) => s.element)}
      </div>
      <Alert />
      <Toast />
      {ad && ad?.img_url && ad?.url ? (
        <DialogAd
          imgUrl={ad?.img_url}
          imgLink={ad?.url}
          type={ad?.type}
        />
      ) : <></>}
      {notice ? (
        <Announcement
          show={showNotice}
          content={notice}
          onClose={setShowNotice}
        />
      ) : <></>}
      <Dialog />
      <Sheet />
    </div>
  ), [
    loading,
    tabList,
    currentIndex,
    stacks,
    notice,
    ad,
    showNotice,
    user,
  ]);
};
