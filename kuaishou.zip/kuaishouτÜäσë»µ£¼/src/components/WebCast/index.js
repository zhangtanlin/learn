import React, { useEffect, useMemo, useRef, useState } from "react";
import '../../resources/css/web_cast.less';

import StackStore from "../../store/stack";
import StackPage from "../StackPage";
import UserStore from "../../store/user";
import Loading from '../Loading';
// import Login from '../login';
import DiamondRecharge from '../User/DiamondRecharge';
import Emit from "../../libs/eventEmitter";
import { apiLiveGetToken } from '../../libs/http';

// 直播
export default (props) => {
  const { isVisible } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const [user] = UserStore.useGlobalState("user");
  const iframeRef = useRef(); // iframe
  const [loading, setLoading] = useState(true);
  const [origin, setOrigin] = useState('');
  const [token, setToken] = useState('');
  // 每次页面打开都获取最新的userInfo里面的直播信息
  const getData = async () => {
    try {
      const res = await apiLiveGetToken();
      if (res?.status) {
        setToken(res?.data?.zbToken); // postMessage发送的token
        localStorage.setItem('zb_tokenGetUrl', res?.data?.zbToken); // 本地存储供直播iframe识别
        setLoading(false);
      } else {
        Emit.emit("showToast", {
          text: "获取token失败",
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
      });
    }
  };
  // 发送消息到直播方的公共方法
  function sendPostMessage(methodName, data) {
    const iframe_node = iframeRef.current;
    if (iframe_node && iframe_node.contentWindow) {
      try {
        iframe_node.contentWindow.postMessage({ methodName, data }, '*');
      } catch (error) {
        iframe_node.contentWindow.postMessage({ methodName, data }, '*');
      }
    }
  }
  // 登录方法
  const loginFn = () => {
    if (!token) return;
    const methodName = 'login';
    const data = {
      baseUrl: user?.zbInfo?.base_api_url,
      appId: user?.zbInfo?.app_id,
      userId: user?.zbUid,
      userName: user?.nickname,
      sex: String(user?.sexType) || '1', // 性别{1: 男，2: 女}
      avatar: user?.zbDefaultThumb,
      token,
      isRisk: String(user?.isRisk) || '1', // 账号是否有风险(一定要为1才能进入直播间)
    };
    sendPostMessage(methodName, data);
  };
  useEffect(() => {
    if (isVisible) {
      setOrigin('./live/index.html');
      getData();
      setLoading(false);
      window.addEventListener("message", handleMessage, false);
    } else {
      setOrigin('');
      setLoading(true);
      window.removeEventListener("message", handleMessage);
    }
  }, [isVisible]);
  useEffect(() => {
    if (!loading && token) {
      loginFn();
    }
  }, [loading, token]);
  // 事件监听
  const handleMessage = (event) => {
    if (event?.data?.methodName == 'needLogin') {
      // console.log('监听直播返回');
    }
    // 余额不足=>跳转充值界面
    if (event?.data?.methodName == 'charge') {
      const stackKey = `DiamondRecharge-${new Date().getTime()}`;
      StackStore.dispatch({
        type: "push",
        payload: {
          name: "DiamondRecharge",
          element: (
            <StackPage
              stackKey={stackKey}
              key={stackKey}
              style={{ zIndex: stacks.length + 2 }}
            >
              <DiamondRecharge stackKey={stackKey} />
            </StackPage>
          ),
        },
      });
    }
    // // 直播全屏时
    // if (event?.data?.methodName == 'hideTab') {
    //   Emit.emit("TAB_SHOW", false);
    // }
    // // 直播取消全屏时
    // if (event?.data?.methodName == 'showTab') {
    //   Emit.emit("TAB_SHOW", true);
    // }
  };
  return useMemo(() => (
    <div
      className={`
        positioned-container
        ${isVisible ? "visible" : "hide"}
      `}
    >
      {loading ? (
        <Loading show overSize={false} />
      ) : (
        <iframe
          title="直播"
          ref={iframeRef}
          className="live-page-iframe"
          src={origin}
          scrolling="no"
          frameBorder="0"
        />
      )}
    </div>
  ), [isVisible, loading, origin]);
};
