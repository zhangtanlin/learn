import React, { useEffect, useMemo, useRef, useState } from "react";
import '../../resources/css/web_cast.less';

import UserStore from "../../store/user";
import Loading from '../Loading';
import ClickBtn from '../ClickBtn';
import Emit from "../../libs/eventEmitter";
import {
  apiLiveGetToken,
} from "../../libs/http";

// 直播中心
export default (props) => {
  const { stackKey } = props;
  const [user] = UserStore.useGlobalState("user");
  const [loading, setLoading] = useState(true);
  const [origin, setOrigin] = useState('');
  const [token, setToken] = useState('');
  const iframeRef = useRef(); // iframe
  // 每次页面打开都获取最新的userInfo里面的直播信息
  const getData = async () => {
    try {
      const res = await apiLiveGetToken();
      if (res?.status) {
        // 存储直播需要的信息
        setToken(res?.data?.zbToken); // postMessage发送的token
        localStorage.setItem('zb_tokenGetUrl', res?.data?.zbToken); // 本地存储供直播iframe识别
        setLoading(false);
      } else {
        Emit.emit("showToast", {
          text: "获取用户信息失败",
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
      });
    }
  };
  useEffect(() => {
    setOrigin('./live/index.html?to=mylive');
    getData();
  }, []);
  // 发送消息到直播方的公共方法
  function sendPostMessage(methodName, data) {
    const iframe_node = iframeRef.current;
    if (iframe_node && iframe_node.contentWindow) {
      try {
        iframe_node.contentWindow.postMessage({ methodName, data }, '*');
      } catch (error) {
        iframe_node.contentWindow.postMessage({ methodName, data }, '*');
      }
    }
  }
  // 登录方法
  const loginFn = () => {
    if (!token) return;
    const methodName = 'login';
    const data = {
      baseUrl: user?.zbInfo?.base_api_url,
      appId: user?.zbInfo?.app_id,
      userId: user?.zbUid,
      userName: user?.nickname,
      sex: String(user?.sexType) || '1', // 性别{1: 男，2: 女}
      avatar: user?.zbDefaultThumb,
      token,
      isRisk: String(user?.isRisk) || '1', // 账号是否有风险(一定要为1才能进入直播间)
    };
    sendPostMessage(methodName, data);
  };
  useEffect(() => {
    if (!loading && token) {
      loginFn();
    }
  }, [loading, token]);
  const handleBack = () => {
    Emit.emit(stackKey, stackKey);
  };
  return useMemo(() => (
    loading ? (
      <Loading show overSize={false} />
    ) : (
      <div className="positioned-container">
        <ClickBtn
          className="live-back-btn"
          onTap={handleBack}
        />
        <iframe
          title="直播-个人中心"
          ref={iframeRef}
          className="live-page-iframe"
          src={origin}
          scrolling="no"
          frameBorder="0"
        />
      </div>
    )
  ), [loading, origin]);
};
