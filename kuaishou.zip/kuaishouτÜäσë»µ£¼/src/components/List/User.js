import React, { useMemo } from "react";
import '../../resources/css/list.less';

import ScrollHorizontal from "../Scroll/ScrollHorizontal";
import {
  UserCreateItem,
  UserInfoItem,
  CardUserSet,
} from "../Card/CardUser";
import {
  CreaterScrollerList
} from "./Video";

// 创作达人-头部横向滚动列表
// type {0: 获赞, 1: 上传, 2: 收益}
export const ListUserCreater = (props) => {
  const { type, list } = props;
  return (
    list?.length ? (
      <div className="public-column1">
        {list?.length ? (
          list?.map((item, index) => (
            <UserCreateItem
              key={`user-create-item-${index}`}
              type={type}
              index={index}
              item={item}
            />
          ))
        ) : <></>}
      </div>
    ) : <></>
  );
};

// 关注-推荐用户
export const ListRecommendUser = (props) => {
  const { list } = props;
  return useMemo(() => (
    list?.length ? (
      <div className="public-column1">
        {list?.length ? (
          list?.map((item, index) => (
            <div
              key={`RecommendUser-${index}`}
              style={{ width: '100%', overflow: 'hidden', }}
            >
              <UserInfoItem item={item} />
              {item?.video?.length ? (
                <div style={{ paddingTop: '.125rem' }}>
                  <ScrollHorizontal>
                    <CreaterScrollerList
                      list={item?.video}
                    />
                  </ScrollHorizontal>
                </div>
              ) : <></>}
            </div>
          ))
        ) : <></>}
      </div>
    ) : <></>
  ), [list]);
};

// 粉丝/关注列表
export const ListUserFans = (props) => {
  const { list } = props;
  return useMemo(() => (
    list?.length ? (
      <div className="public-column1">
        {list?.length ? (
          list?.map((item, index) => (
            <UserInfoItem
              key={`FansItem-${index}`}
              item={item}
            />
          ))
        ) : <></>}
      </div>
    ) : <></>
  ), [list]);
};

// 设置列表
export const ListUserSet = (props) => {
  const { list } = props;
  return useMemo(() => (
    list?.length ? (
      <div className="public-column1">
        {list?.length ? (
          list?.map((item, index) => (
            <CardUserSet
              key={`FansItem-${index}`}
              item={item}
            />
          ))
        ) : <></>}
      </div>
    ) : <></>
  ), [list]);
};
