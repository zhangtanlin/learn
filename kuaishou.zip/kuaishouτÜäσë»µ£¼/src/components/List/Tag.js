import React, { useMemo } from "react";
import '../../resources/css/list.less';


import {
  ItemTagSearch,
  ItemTagSearchHot,
  TagItemMvHot,
  CardTagPlayer,
} from "../Card/CardTag";

// 搜索-标签列表
export const ListTagSearch = (props) => {
  const { list, onTap } = props;
  const handle = (keyword) => {
    onTap && onTap(keyword);
  }
  return useMemo(() => (
    <div className="public-column-wrap">
      {list?.length ? (
        list?.map((item, index) => (
          <ItemTagSearch
            key={`TagItemSearch-${index}`}
            item={item}
            onTap={(keyword) => {
              handle(keyword);
            }}
          />
        ))
      ) : <></>}
    </div>
  ), [list]);
};

// 搜索-热门标签列表
export const ListTagSearchHot = (props) => {
  const { list, onTap } = props;
  const handle = (keyword) => {
    onTap && onTap(keyword);
  }
  return useMemo(() => (
    <div className="public-column2">
      {list?.length ? (
        list?.map((item, index) => (
          <ItemTagSearchHot
            key={`TagItemHot-${index}`}
            index={index + 1}
            item={item}
            onTap={(keyword) => {
              handle(keyword);
            }}
          />
        ))
      ) : <></>}
    </div>
  ), [list]);
};

// 标签页-列表
export const ListTag = (props) => {
  const { list, onTap } = props;
  const handle = (keyword) => {
    onTap && onTap(keyword);
  }
  return useMemo(() => (
    <div className="public-column3">
      {list?.length ? (
        list?.map((item, index) => (
          <TagItemMvHot
            key={`TagItemHot-${index}`}
            item={item}
            onTap={(keyword) => {
              handle(keyword);
            }}
          />
        ))
      ) : <></>}
    </div>
  ), [list]);
};

// 视频播放页标签
export const ListTagPlayer = (props) => {
  const { list } = props;
  return useMemo(() => (
    <div className="public-column-wrap">
      {list?.length ? (
        list?.map((item, index) => (
          <CardTagPlayer
            key={`CardTagPlayer${index}`}
            item={item}
          />
        ))
      ) : <></>}
    </div>
  ), [list]);
};
