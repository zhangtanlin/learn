import React, { useMemo } from "react";
import '../../resources/css/list.less';

import { CardComment } from "../Card/CardComment";

// 创作达人-头部横向滚动列表
export const ListComment = (props) => {
  const { list } = props;
  return useMemo(() => (
    list?.length ? (
      <div className="public-column1">
        {list?.map((item, index) => (
          <>
            <CardComment
              key={`CardComment-${index}`}
              item={item}
            />
            {item?.child?.length ? (
              <div style={{ paddingLeft: '1.5rem' }}>
                {item?.child?.map((obj, i) => (
                  <CardComment
                    key={`CardComment-child-${i}`}
                    showClickBtn={false}
                    item={obj}
                  />
                ))}
              </div>
            ) : <></>}
          </>
        ))}
      </div>
    ) : <></>
  ), [list]);
};
