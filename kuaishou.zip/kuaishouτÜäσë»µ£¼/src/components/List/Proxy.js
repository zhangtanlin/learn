import React, { useMemo } from "react";
import '../../resources/css/list.less';

import { CardProxy } from "../Card/CardProxy";

// 列表-代理详情
export const ListProxy = (props) => {
  const { list } = props;
  return useMemo(() => (
    list?.length ? (
      <div className="public-column1">
        {list?.map((item, index) => (
          <CardProxy
            key={`creater-scroller-item-${index}`}
            item={item}
            onTap={() => { }}
          />
        ))}
      </div>
    ) : <></>
  ), [list]);
};
