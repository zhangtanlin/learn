import React, { useMemo } from "react";
import '../../resources/css/list.less';

import { CollectionItemHot } from "../Card/CardCollection";

// 合集-合集列表
export const ListCollection = (props) => {
  const { list } = props;
  const handle = () => {
    onTap && onTap();
  };
  return useMemo(() => (
    list?.length ? (
      <div className="public-column3">
        {list?.map((item, index) => (
          <CollectionItemHot
            key={`creater-scroller-item-${index}`}
            item={item}
            onTap={() => handle(item)}
          />
        ))}
      </div>
    ) : <></>
  ), [list]);
};
