import React, { useMemo } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import SwiperCore, { Controller } from "swiper";
import '../resources/css/banner.less';

import ClickBtn from "./ClickBtn";
import Simg from "./Simg";

SwiperCore.use([Controller]);

/**
 * banner列表
 * @param {array} props.list 列表
 * @param {array} props.imgStyle 图片样式
 * @param {array} props.style 列表框样式
 * @returns
 */
export const BannerAdList = (props) => {
  const {
    list,
    imgStyle, // {imgStyle : 图片样式}
    style,
  } = props;
  const handleLink = (url) => {
    if (url) {
      window.open(url, "_blank");
    }
  };
  return useMemo(() => (
    <div
      className="banner-ad"
      style={style}
    >
      {list?.length ? (
        <Swiper
          className="default-swiper"
          pagination
          loop
          autoplay={{
            delay: 3000,
            disableOnInteraction: false,
          }}
        >
          {list?.map((item, index) => (
            <SwiperSlide key={`banner-ad-${index}`}>
              <ClickBtn
                className="banner-item"
                onTap={() => handleLink(item?.url)}
                styles={imgStyle}
              >
                <Simg src={item?.img_url} />
              </ClickBtn>
            </SwiperSlide>
          ))}
        </Swiper>
      ) : <></>}
    </div>
  ), [list]);
};
