import React from "react";
import "../resources/css/tutorial.less";

import ScrollArea from "./ScrollArea";
import HeaderBack from "./Header/HeaderBack";

// 教程
export default (props) => {
  const { stackKey } = props;
  return (
    <div className="page-content-flex">
      <HeaderBack
        stackKey={stackKey}
        title="发布规则"
        right={() => (<div style={{ width: "1.2rem" }} />)}
      />

      <ScrollArea downRefresh={false} ListData={1}>
        <div className="publishRule">
          <p className="publishRule-title1">想看什么汤友帮你找！</p>
          <p className="publishRule-title2">
            仅会员用户可选择免费或赏金发布求片
          </p>
          <p className="publishRule-title2">1.发布规则：</p>
          <p className="publishRule-content">
            禁止求片内容包含未成年、真实强奸、广告等内容，违者封禁账号
          </p>
          <p className="publishRule-content">
            季度会议、年卡会员、永久会员发布求片无需审核，若发现违规内容则封禁账号取消会员资格
          </p>
          <p className="publishRule-title2">2.赏金求片：</p>
          <p className="publishRule-content">
            单次赏金求片最大期限为48小时，若48小时内无人接单，则悬赏失败，赏金返还赏主
          </p>
          <p className="publishRule-content">
            在有推荐者的推荐情况下赏金低于50汤币，发布者只可选择一个推荐者采纳，超过48小时未选择打赏，则所有剩余赏金全部归于第一个推荐者
          </p>
          <p className="publishRule-content">
            在有推荐者赏金高于50汤币，若推荐者视频不满足自己的需求，可选择不采纳，48小时候求片帖子失效，由平台审核后确认是否恶意不采纳，审核通过返回赏金给发布者，审核失败（恶意不采纳）则不返还赏金
          </p>
          <p className="publishRule-content">
            创作者接单有什么好处？除接单可获取赏金外，接单数量越高则有机会名列排行榜得到更多曝光
          </p>
          <p className="publishRule-title2">温馨提示：</p>
          <p className="publishRule-content">
            赏金越高，获得高质量视频回复的可能性越大~
          </p>
          <p className="publishRule-title2">3.推荐片：</p>
          <p className="publishRule-content">
            推荐片子可选择推荐自己作品视频或平台视频，可选择免费或收费视频，免费视频被采纳的机率更高~
          </p>
          <p className="publishRule-content">
            推荐者获取的赏金将会发放到钱包余额中，可用于消费或提现哟~~
          </p>
        </div>
      </ScrollArea>
    </div>
  );
};
