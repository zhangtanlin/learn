import React, { useEffect, useMemo, useRef } from "react";
import Hammer from "hammerjs";
import "../../resources/css/btn/btn_back.less";

import ClickBtn from "../ClickBtn";
import Emit from "../../libs/eventEmitter";

import iconBackWhite from "../../resources/img/icon_back_white.png";

/**
 * 单独的返回按钮(视频播放器左上角)
 * @param {*} props.stackKey 当前key
 * @param {*} props.isLight 是否亮色调
 * @param {*} props.onTap 点击事件
 * @returns
 */
export default (props) => {
  const {
    stackKey,
    onTap,
  } = props;
  const backRef = useRef(null);
  useEffect(() => {
    if (!backRef.current) return;
    const handle = () => {
      if (onTap) {
        onTap();
      }
      Emit.emit(stackKey, stackKey);
    };
    const hammer = new Hammer(backRef.current);
    hammer.on("tap", handle);
    return () => {
      hammer.off("tap", handle);
    };
  }, []);
  return useMemo(() => (
    <ClickBtn
      ref={backRef}
      className="btn-back"
    >
      <img src={iconBackWhite} />
    </ClickBtn>
  ), []);
};
