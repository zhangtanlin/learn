import React, { useMemo, useState } from "react";
import "../../resources/css/btn/btn_player.less";

import StackStore from "../../store/stack";
import StackPage from "../StackPage";
import UserStore from "../../store/user";
import Login from "../Login";
import Emit from "../../libs/eventEmitter";
import DialogVideoShare from "../Dialog/DialogVideoShare";
import ClickBtn from "../ClickBtn";
import Search from "../Search";
import {
  apiToggleLikeVideo,
} from '../../libs/http';

import iconLikeWhite from "../../resources/img/icon_check_white.png";
import iconLikeRed from "../../resources/img/icon_check_red.png";
import iconShare from "../../resources/img/icon_share.png";
import iconComment from "../../resources/img/icon_msg.png";
import VideoComment from "../Video/VideoComment";

/**
 * 视频播放器-喜欢/未喜欢按钮
 * @param {*} props.id 视频id
 * @param {*} props.status 是否喜欢{0/null: 未喜欢,1: 已喜欢}
 * @param {*} props.number 视频被喜欢的数量
 * @returns
 */
export const BtnPlayerLike = (props) => {
  const { id, status = 0, number = 0 } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const [user] = UserStore.useGlobalState("user");
  // 喜欢按钮是否被点击
  let likeBtnClick = true;
  // 是否喜欢
  const [isLike, setIsLike] = useState(status);
  // 喜欢数量
  const [isNumber, setIsNumber] = useState(number);
  const handle = async (id) => {
    if (!likeBtnClick || !id) return;
    if (!user?.is_reg) {
      const tempStackKey = `Login-${new Date().getTime()}`;
      StackStore.dispatch({
        type: "push",
        payload: {
          name: 'Manage',
          element: (
            <StackPage
              stackKey={tempStackKey}
              key={tempStackKey}
              style={{ zIndex: stacks.length + 2 }}
            >
              <Login stackKey={tempStackKey} />
            </StackPage>
          ),
        },
      });
      return;
    }
    try {
      likeBtnClick = false;
      const tempParam = { id };
      const res = await apiToggleLikeVideo(tempParam);
      if (res?.status) {
        if (isLike) {
          setIsNumber(isNumber - 1);
        } else {
          setIsNumber(isNumber + 1);
        }
        setIsLike(!isLike);
        Emit.emit(
          "showToast",
          { text: res?.data?.msg || "操作成功" }
        );
      } else {
        Emit.emit(
          "showToast",
          { text: res?.data?.msg || "操作失败" }
        );
      }
    } catch (error) {
      Emit.emit("showToast", { text: "请求失败" });
    }
    likeBtnClick = true;
  };
  return useMemo(() => (
    <ClickBtn
      className="btn_player_like"
      onTap={() => handle(id)}
    >
      <img src={isLike ? iconLikeRed : iconLikeWhite} />
      <span>{isNumber}</span>
    </ClickBtn>
  ), [id, isLike, isNumber, user]);
};

/**
 * 视频播放器-分享按钮
 * @param {*} props.id 视频id
 * @param {*} props.status 是否喜欢{0/null: 未喜欢,1: 已喜欢}
 * @param {*} props.number 视频被喜欢的数量
 * @returns
 */
export const BtnPlayerShare = (props) => {
  const { data } = props;
  const onShare = (data) => {
    Emit.emit(
      "changeDialog",
      {
        _show: true,
        _children: () => (
          <DialogVideoShare data={data} />
        )
      },
    );
  };
  return (
    <ClickBtn
      className="btn_player_share"
      onTap={() => onShare(data)}
    >
      <img src={iconShare} />
      <span>分享</span>
    </ClickBtn>
  );
};

/**
 * 视频播放器-评论按钮
 * @param {*} props.id 视频id
 * @param {*} props.status 是否喜欢{0/null: 未喜欢,1: 已喜欢}
 * @param {*} props.number 视频被喜欢的数量
 * @returns
 */
export const BtnPlayerComment = (props) => {
  const { data, } = props;
  const handle = () => {
    Emit.emit(
      "showSheet",
      {
        _show: true,
        _content: () => (
          <VideoComment info={data} />
        )
      },
    );
  };
  return useMemo(() => (
    <ClickBtn
      className="btn_player_comment"
      onTap={() => handle()}
    >
      <img src={iconComment} />
      <span>{data?.comment}</span>
    </ClickBtn>
  ), []);
};

/**
 * 视频播放器-播放按钮
 * @param {*} props.id 视频id
 * @param {*} props.status 是否喜欢{0/null: 未喜欢,1: 已喜欢}
 * @param {*} props.number 视频被喜欢的数量
 * @returns
 */
export const BtnPlayerPlay = (props) => {
  const { isShow } = props;
  return useMemo(() => (
    isShow ? (
      <div className="btn-player-play" />
    ) : <></>
  ), [isShow]);
};

/**
 * 视频播放器-搜索按钮
 * @returns
 */
 export const BtnPlayerSearch = () => {
  const [stacks] = StackStore.useGlobalState("stacks");
  const handle = () => {
    const tempStackKey = `Search-${new Date().getTime()}`;
      StackStore.dispatch({
        type: "push",
        payload: {
          name: 'Manage',
          element: (
            <StackPage
              stackKey={tempStackKey}
              key={tempStackKey}
              style={{ zIndex: stacks.length + 2 }}
            >
              <Search stackKey={tempStackKey} />
            </StackPage>
          ),
        },
      });
  };
  return (
    <ClickBtn
      className="btn-player-search"
      onTap={handle}
    />
  );
};
