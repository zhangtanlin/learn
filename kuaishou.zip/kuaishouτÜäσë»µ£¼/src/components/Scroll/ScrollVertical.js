import React, { useState, useEffect, useMemo, useRef } from "react";
import "../../resources/css/scroll/scroll_vertical.less";

import {
  CardScrollMvRank,
  CardScrollAdPlayer,
} from "../Card/CardScroll"

/**
 * 视频模块内的垂直滚动
 * @param {*} props.height 每次一滚动的高度
 * @param {*} props.list 列表
 * @param {*} props.type 类型{0/null:视频页排行榜,1:视频播放页底部广告}
 * @returns
 */
export default (props) => {
  const { height = 1, list, type, style } = props;
  const timer = useRef();
  const [params, setParams] = useState({
    top: 0, // 滚动方向
    upScroll: true, // 是否向上滚动
  });
  // 定时器
  useEffect(() => {
    // 滚动列表滚动动画
    if (list?.length > 1) {
      timer.current = setInterval(() => {
        var tempListHeight = height * (list?.length - 1);
        if (params?.top === -tempListHeight) {
          params.upScroll = false;
          setParams({ ...params });
        }
        if (params?.top === 0) {
          params.upScroll = true;
          setParams({ ...params });
        }
        if (params.upScroll) {
          params.top -= height;
          setParams({ ...params });
        } else {
          params.top += height;
          setParams({ ...params });
        }
      }, 2500);
    }
    return () => clearInterval(timer.current);
  }, []);
  // 设置盒子样式
  const setStype = () => {
    let tempStyle = { height: `${height}rem`, }
    if (style) {
      tempStyle = {
        ...tempStyle,
        ...style,
      }
    }
    return tempStyle;
  }
  return useMemo(() => (
    <div
      className="vertical-scroll-box"
      style={setStype()}
    >
      <div
        className="vertical-scroll-list"
        style={{
          top: params.top + 'rem'
        }}
      >
        {list?.length ? (
          list?.map((item, index) => {
            switch (type) {
              case 1:
                return (
                  <CardScrollAdPlayer
                    key={`CardAdPlayer${index}`}
                    item={item}
                  />
                )
              default:
                return (
                  <CardScrollMvRank
                    key={`CardScrollMvRank${index}`}
                    item={item}
                  />
                );
            }
          })
        ) : <></>}
      </div>
    </div>
  ), [params.top, list]);
};
