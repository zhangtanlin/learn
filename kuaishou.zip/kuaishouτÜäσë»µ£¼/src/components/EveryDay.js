import React, { useEffect, useMemo, useState } from "react";

import HeaderBack from "./Header/HeaderBack";
import ScrollArea from "./ScrollArea";
import Loading from "./Loading";
import Emit from "../libs/eventEmitter";
import { NoData } from "./NoData";
import { apiGetDailyRecommend } from "../libs/http";
import { EveryDayList } from "./List/EveryDay";

// 每日推荐
export default (props) => {
  const { stackKey } = props;
  const [loading, setLoading] = useState(true);
  const [params, setParams] = useState({
    page: 1,
    isAll: false,
  });
  const [data, setData] = useState([]);
  const [loadingMore, setLoadingMore] = useState(true);
  const getData = async () => {
    if (params?.isAll) {
      return;
    }
    setLoadingMore(true);
    try {
      const res = await apiGetDailyRecommend(params);
      if (res?.status) {
        if (params?.page === 1) {
          setData([res?.data]);
        } else {
          setData([...data, res?.data || []]);
        }
        if (!res?.data?.list?.length) {
          setParams({ ...params, isAll: true });
        }
      } else {
        Emit.emit("showToast", { text: "请求列表失败" });
      }
    } catch (error) {
      Emit.emit("showToast", { text: "请求失败" });
    }
    setLoading(false);
    setLoadingMore(false);
  };
  const nextPage = () => {
    if (!params?.isAll) {
      setParams((tempParam) => ({
        ...tempParam,
        page: tempParam?.page + 1
      }));
    }
  };
  const refresh = () => {
    setParams((tempParam) => ({
      ...tempParam,
      ...{
        page: 1,
        isAll: false,
      },
    }));
  };
  useEffect(() => {
    getData();
  }, [params]);
  return useMemo(() => (
    loading ? (
      <Loading show text="正在获取数据..." />
    ) : (
      <div className="positioned-container">
        <HeaderBack
          stackKey={stackKey}
          title="每日精选"
        />
        {
          data?.length > 0 ? (
            <ScrollArea
              ListData={data?.length}
              onScrollEnd={() => nextPage()}
              loadingMore={loadingMore}
              pullDonRefresh={() => refresh()}
            >
              <div className="public-padding">
                <EveryDayList list={data} />
              </div>
            </ScrollArea>
          ) : <NoData />
        }
      </div>
    )
  ), [loading, data, loadingMore]);
};
