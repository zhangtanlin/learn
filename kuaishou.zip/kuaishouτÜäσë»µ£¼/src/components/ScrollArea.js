import React, { useEffect, useMemo, useRef, useState } from "react";
import "../resources/css/scroll_area.less";

import BScroll from "@better-scroll/core";
import NestedScroll from "@better-scroll/nested-scroll";
import PullDown from "@better-scroll/pull-down";
// import Logo2Gray from "../resources/img/card/jujue.png";
import Emit from "../libs/eventEmitter";
import global from "../libs/globalVar";
import { throttle } from "../libs/utils";
// import lottie from "lottie-web";
// import animationData from "../resources/lottie/pull_refresh/data.json";
BScroll.use(PullDown);
BScroll.use(NestedScroll);
// let lottieContainer;
export default (props) => {
  const {
    children,
    ListData,
    downRefresh,
    pullDonRefresh,
    isRefresh,
    onScrollEnd,
    groupId,
    loadingMore,
    emitName,
    scrollChange,
    touchEnd,
    onScrollTop, //到达顶部
    sliverHead, //顶部展示的元素
    noEndText, // 隐藏底部文字
  } = props;
  const [tipText, setTipText] = useState("");
  const scrollerRef = useRef(null);
  const lottieRef = useRef(null);
  const scrollerHeadRef = useRef(null);
  const [bscroll, setBScroll] = useState(null);
  const [headOpacity, setHeadOpacity] = useState(1);
  const [headHeight, setHeadHeight] = useState(0);
  const [sliverHeight, setSliverHeight] = useState(0);
  // const newLottie = () => {
  //   lottieContainer = lottie.loadAnimation({
  //     container: lottieRef.current,
  //     renderer: "svg",
  //     loop: false,
  //     autoplay: false,
  //     animationData
  //   });
  // };
  useEffect(() => {
    if (!sliverHead || !scrollerHeadRef.current) return;
    setSliverHeight(scrollerHeadRef.current.clientHeight);
    setHeadHeight(scrollerHeadRef.current.clientHeight);
  }, [sliverHead, scrollerHeadRef.current]);
  const PHASE = {
    moving: {
      enter: "继续下拉可刷新页面",
      leave: "可以松手了",
    },
    fetching: "正在请求数据",
    succeed: "拿到数据啦",
  };
  const TIME_BOUNCE = 800;
  const REQUEST_TIME = 2000;
  const THRESHOLD = 50;
  const STOP = Math.floor(1.5 * global.bodyFontSize); // 此处需要取整，如果返回值带小数，在不同屏幕下可能会出现多余的横线
  // useEffect(() => {
  //   if (!lottieRef.current) return;
  //   newLottie();
  //   return () => {
  //     if (lottieContainer) {
  //       lottieContainer.destroy();
  //     }
  //   };
  // }, [lottieRef.current]);
  const pullingDownHandler = async () => {
    setTipText(PHASE.fetching);
    // lottieContainer.play();
    if (pullDonRefresh) {
      pullDonRefresh();
    }
    await new Promise((resolve) => {
      setTimeout(() => {
        // lottieContainer.stop();
        resolve(1);
      }, REQUEST_TIME);
    });
    setTipText(PHASE.succeed);
    bscroll.finishPullDown();
    setTimeout(() => {
      bscroll.refresh();
    }, TIME_BOUNCE);
  };
  useEffect(() => {
    let handler;
    const scrollTo = ({ y, time }) => {
      bscroll.scrollTo(0, y, time);
    };
    if (emitName && bscroll) {
      // bscroll.disable();
      handler = (bool) => {
        if (bool) {
          bscroll.enable();
        } else {
          bscroll.disable();
        }
      };
      Emit.on(emitName, handler);
      if (emitName.toLowerCase().indexOf("scrollto") !== -1) {
        Emit.on(emitName, scrollTo);
      }
    }
    return () => {
      if (emitName && bscroll) {
        Emit.off(emitName, handler);
        if (emitName.toLowerCase().indexOf("scrollto") !== -1) {
          Emit.off(emitName, scrollTo);
        }
      }
    };
  }, [emitName, bscroll]);
  useEffect(() => {
    setTimeout(() => {
      if (!bscroll && scrollerRef.current) {
        const bscrollPrams = {
          scrollY: true,
          bounceTime: TIME_BOUNCE,
          bounce: {
            top: (downRefresh == null || downRefresh == true) && pullDonRefresh,
            bottom: (downRefresh == null || downRefresh == true) && onScrollEnd,
            left: downRefresh == null || downRefresh == true,
            right: downRefresh == null || downRefresh == true,
          },
          useTransition: true,
          pullDownRefresh: {
            threshold: THRESHOLD,
            stop: STOP,
          },
        };
        if (groupId) {
          bscrollPrams.nestedScroll = {
            groupId,
          };
        }
        setBScroll(new BScroll(scrollerRef.current, { ...bscrollPrams }));
      } else if (bscroll) {
        if (sliverHead || scrollChange || onScrollTop) {
          bscroll.on("scroll", (e) => {
            if (scrollChange) {
              scrollChange(e, bscroll);
            }
            if (
              bscroll.movingDirectionY === -1 &&
              bscroll.y === bscroll.minScrollY &&
              onScrollTop
              // &&
              // global.scrollLoaction
            ) {
              onScrollTop();
            }
            if (sliverHead) {
              if (Math.abs(e.y) <= sliverHeight && e.y <= 0) {
                setHeadOpacity(1 - Math.abs(e.y) / sliverHeight);
                setHeadHeight(
                  sliverHeight * (1 - Math.abs(e.y) / sliverHeight)
                );
              }
            }
          });
        }
        // v2.4.0 supported
        if (pullDonRefresh) {
          bscroll.on("pullingDown", pullingDownHandler);
        }
        if (touchEnd) {
          bscroll.on("scrollEnd", touchEnd);
        }
        bscroll.on("enterThreshold", () => {
          // setInitPage(true);
          setTipText(PHASE.moving.enter);
        });
        bscroll.on("leaveThreshold", () => {
          setTipText(PHASE.moving.leave);
        });
        bscroll.on(
          "scroll",
          throttle(() => {
            Emit.emit("isInViewPortEvent");
          }, 1000)
        );
        bscroll.on("scrollEnd", () => {
          if (Math.abs(bscroll.y / bscroll.maxScrollY) > 0.8) {
            onScrollEnd && onScrollEnd();
          }
        });
      }
    }, 500);
    return () => {
      if (bscroll) {
        bscroll.destroy();
        setBScroll(null);
      }
    };
  }, [scrollerRef.current, bscroll, sliverHead, groupId]);
  useEffect(() => {
    if (bscroll) {
      bscroll.refresh();
    }
  }, [ListData, loadingMore, isRefresh]);

  return (
    <div className="full-column">
      <div ref={scrollerRef} className="scroller-wrapper">
        <div className="pulldown-scroller">
          {!pullDonRefresh ? (
            ""
          ) : (
            <div
              className="pulldown-wrapper"
              ref={lottieRef}
              style={{
                height: `${STOP}px`,
              }}
            >
              {/* <img
                src={Logo2Gray}
                className={
                  tipText === PHASE.fetching
                    ? "animate__animated animate__slow animate__infinite animate__pulse"
                    : ""
                }
              /> */}
              <div>{tipText}</div>
            </div>
          )}
          {sliverHead &&
            useMemo(
              () => (
                <div>
                  <div
                    style={{
                      height: `${sliverHeight - headHeight}px`,
                    }}
                  />
                  <div
                    className="scroller-sliver-head"
                    style={{
                      height: `${headHeight}px`,
                      opacity: `${headOpacity}`,
                      overflow: "hidden",
                    }}
                  >
                    <div
                      ref={scrollerHeadRef}
                      style={{
                        width: "100%",
                      }}
                    >
                      {sliverHead}
                    </div>
                  </div>
                </div>
              ),
              [
                sliverHead,
                headHeight,
                headOpacity,
                sliverHeight,
                scrollerHeadRef.current,
              ]
            )}
          {children}
          {!onScrollEnd || noEndText ? (
            ""
          ) : (
            <div className="loadmore">
              {loadingMore ? "正在加载更多..." : "-我也是有底线的-"}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
