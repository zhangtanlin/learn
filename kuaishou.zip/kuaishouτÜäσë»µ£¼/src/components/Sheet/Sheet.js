import React, { useEffect, useMemo, useState } from "react";
import "../../resources/css/sheet/sheet.less";

import Emit from "../../libs/eventEmitter";
import ClickBtn from "../ClickBtn";

// 底部上滑显示面板
export default () => {
  const [show, setShow] = useState(false);
  const [content, setContent] = useState();
  const [contentStyle, setContentStyle] = useState({});

  useEffect(() => {
    /**
     * @param {_show}    标题
     * @param {_content} 内容区
     * @param {_containSyle} 内容去样式
     */
    const changeSheel = ({
      _show,
      _content,
      _contentStyle,
    }) => {
      if (_show !== null) {
        setShow(_show);
      }
      if (_content) {
        setContent(_content);
      }
      if (_contentStyle) {
        setContentStyle(_contentStyle);
      }
    };
    Emit.on("showSheet", changeSheel);
    return () => {
      Emit.off("showSheet", changeSheel);
    };
  }, []);

  return useMemo(() => (
    <div
      className={`
        sheet
        ${show ? 'sheet-show' : 'sheet-hide'}
      `}
    >
      <ClickBtn
        className="sheet-mask"
        onTap={() => {
          Emit.emit('showSheet', {
            _show: false,
          });
        }}
      />
      <div
        className="sheet-content-box"
        style={contentStyle}
      >
        {content}
      </div>
    </div>
  ), [
    show,
    content,
    contentStyle,
  ]);
};
