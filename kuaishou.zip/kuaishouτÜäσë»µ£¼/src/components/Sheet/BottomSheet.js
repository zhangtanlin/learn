import React, { useEffect, useRef, useState, useMemo } from "react";
import closeIcon from "../../resources/img/icon_close_white.png";
import ClickBtn from "../ClickBtn";

export default props => {
  const {
    show,
    children,
    setShow,
    hideClose,
    onClose,
    onOpen,
    direction
  } = props;
  const showEl = useRef(null);
  const [contentHeight, setHeight] = useState(0);
  useEffect(() => {
    if (show) {
      onOpen && onOpen();
      showEl.current.setAttribute("style", `transform: translateY(0px);`);
    } else {
      onClose && onClose();
      showEl.current.setAttribute(
        "style",
        `transform: translateY(${direction === "top" ? -contentHeight : contentHeight
        }px);`
      );
    }
  }, [show]);
  useEffect(() => {
    if (!showEl.current) return;
    setHeight(showEl.current.clientHeight);
  }, [showEl.current, children]);
  return useMemo(
    () => (
      <div
        className={`bottom_sheet_box ${show ? "" : "bottom_sheet_box_hide"}`}
      >
        <div className="point_none" />
        {direction === "top" ? (
          ""
        ) : (
          <ClickBtn
            onTap={() => {
              setShow(false);
            }}
            className="content_flex"
          />
        )}
        <div className="sheet_content_box" ref={showEl}>
          {hideClose || direction ? (
            ""
          ) : (
            <ClickBtn
              className="sheet_close"
              onTap={() => {
                setShow(false);
              }}
            >
              <img src={closeIcon} />
            </ClickBtn>
          )}
          <div className="sheet_conetent">{children}</div>
        </div>
        {direction === "top" ? (
          <ClickBtn
            onTap={() => {
              setShow(false);
            }}
            className="content_flex"
          />
        ) : (
          ""
        )}
      </div>
    ),
    [show, children, showEl.current, hideClose]
  );
};
