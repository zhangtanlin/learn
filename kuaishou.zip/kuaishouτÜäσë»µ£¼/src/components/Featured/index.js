import React, { useMemo, useState, useEffect, forwardRef, } from "react";

import VideoStore from "../../store/video";
import Emit from "../../libs/eventEmitter";
import GlobalVar from "../../libs/GlobalVar";
import VideoShort from "../Video/VideoShort";
import { apiGetFeatured } from "../../libs/http";

// 精选
export default forwardRef((props, playerRef) => {
  const {
    isVisible,
    // playerRef,
  } = props;
  const [loading, setLoading] = useState(true);
  const [init, setInit] = useState(false); // 判定是否初次进入
  const [params, setParams] = useState({
    page: 1, // 页码
    limit: 5, // 每页显示的条数
    isAll: false, // 是否已加载全部列表
  });
  const [data, setData] = useState([]);
  // 请求数据
  const getData = async () => {
    if (params?.isAll) return;
    try {
      const res = await apiGetFeatured();
      if (res?.status) {
        if (params?.page === 1) {
          setData(res?.data);
          GlobalVar.videoPause = true;
          GlobalVar.videoLoading = true;
          const tempVideoData = {
            videoPause: true,
            videoLoading: true,
            videoUrl: res?.data[0].playURL,
          }; // 字段说明参考videoStore
          VideoStore.dispatch({
            type: "replace",
            payload: tempVideoData,
          });
        } else {
          setData([...data, ...res?.data]);
        }
        if (!res?.data?.length) {
          setParams({ ...params, isAll: true });
        }
      } else {
        Emit.emit("showToast", {
          text: "请求列表失败",
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
      });
    }
    setLoading(false);
  };
  useEffect(() => {
    if (isVisible) {
      setInit(true);
    }
    // 放置监听是否切换了底部选项卡,切换了选项卡就暂停视频并切换状态
    if (!isVisible) {
      if (playerRef?.current) {
        playerRef?.current.pause();
        GlobalVar.videoPause = true;
        const tempVideoData = {
          videoPause: true,
        };
        VideoStore.dispatch({
          type: "replace",
          payload: tempVideoData,
        });
      }
    }
  }, [isVisible]);
  useEffect(() => {
    if (init) {
      getData();
    }
  }, [init, params]);
  return useMemo(() => (
    <div
      className={`
        positioned-container black
        ${isVisible ? 'visible' : 'hide'}
      `}
    >
      <VideoShort
        playerRef={playerRef}
        data={data}
        params={params}
        onParams={setParams}
      />
    </div>
  ), [
    isVisible,
    loading,
    data,
  ]);
});
