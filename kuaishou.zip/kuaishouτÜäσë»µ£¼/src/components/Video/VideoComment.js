/**
 * 1.非会员 免费观看10(后端返回)部vip视频
 * 2.会员 无限观看vip视频
 * 3.在本地记录id,然后提交到后端
 * 4.过滤处理(当日看过的可以再看,不用计算次数,up自己的视频自己可以观看)
 * 5.钻石视频购买之后才能看,购买之后无限看不计算次数
 */
import React, { useEffect, useMemo, useRef, useState } from "react";
import "../../resources/css/video/video_comment.less";

import ScrollArea from "../ScrollArea";
import Clickbtn from "../ClickBtn";
import Emit from "../../libs/eventEmitter";
import Loading from "../Loading";
import { NoData } from "../NoData";
import { ListComment } from "../List/ListComment";
import {
  apiGetCommentsList,
  apiSetComment,
} from "../../libs/http";

/**
 * 评论列表
 * @param {*} props.info 信息
 * @returns
 */
export default (props) => {
  const { info } = props;
  const inputRef = useRef(null);
  const [loading, setLoading] = useState(true);
  const [params, setParams] = useState({
    page: 1,
    size: 5,
    isAll: false,
  });
  const [data, setData] = useState([]);
  const [loadingMore, setLoadingMore] = useState(true);
  const getData = async () => {
    if (params?.isAll) return;
    setLoading(true);
    try {
      const tempParam = {
        ...params,
        id: info?.id,
      };
      const res = await apiGetCommentsList(tempParam);
      if (res?.status) {
        if (params?.page === 1) {
          setData(res?.data);
        } else {
          setData([...data, ...res?.data]);
        }
        if (!res?.data?.length) {
          setParams({ ...params, isAll: true });
        }
      } else {
        Emit.emit("showToast", {
          text: res?.msg || res?.data?.msg || "请求列表失败",
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
      });
    }
    setLoading(false);
    setLoadingMore(false);
  };
  useEffect(() => {
    getData();
  }, [params]);
  const nextPage = () => {
    if (!params?.isAll) {
      setParams((tempParam) => ({
        ...tempParam,
        page: tempParam?.page + 1
      }));
    }
  };
  // 提交评论
  const handleSubmit = async () => {
    if (!inputRef.current.value) {
      Emit.emit(
        "showToast",
        { text: "评论不能为空" },
      );
      return;
    }
    const tempParam = {
      mv_id: info?.id,
      comment: inputRef?.current?.value,
    };
    let msg = '';
    const res = await apiSetComment(tempParam);
    if (res?.status) {
      setParams((tempParams) => ({
        ...tempParams,
        page: 1,
        isAll: false,
      }));
    } else {
      msg = res?.msg || res?.data?.msg || '评论失败';
    }
    inputRef.current.value = "";
    Emit.emit("showToast", { text: msg });
  };
  // 下面两个参数有待商榷
  let scrollTopTimer;
  let isTop = true;
  return useMemo(() => (
    <div className="video_comment">
      <div className="header">
        <span>
          {info?.num ? `全部${info?.num}条` : ''}评论
        </span>
        <div
          className="btn_close"
          onClick={() => {
          }}
        />
      </div>
      {loading ? (
        <Loading show type={1} />
      ) : (
        data.length > 0 ? (
          <ScrollArea
            ListData={data}
            onScrollEnd={nextPage}
            loadingMore={loadingMore}
            onScrollTop={() => {
              scrollTopTimer && clearTimeout(scrollTopTimer);
              scrollTopTimer = setTimeout(() => {
                isTop = true;
                Emit.emit("CHANGE_MOVE_STATUS", true);
              }, 200);
            }}
            scrollChange={() => {
              if (isTop) {
                Emit.emit("CHANGE_MOVE_STATUS", false);
                isTop = false;
              }
            }}
          >
            <ListComment list={data} />
          </ScrollArea>
        ) : <NoData />
      )}
      <div className="input_box">
        <div className="icon" />
        <input
          ref={inputRef}
          placeholder="观而不论非英雄，留下你的评论"
        />
        <Clickbtn
          className="btn_submit"
          onTap={() => {
            handleSubmit();
          }}
        >
          确定
        </Clickbtn>
      </div>
    </div>
  ), [loading, data, loadingMore]);
};
