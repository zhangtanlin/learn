import React, { useRef, useMemo, useState, useEffect } from "react";
import "../../resources/css/video/video_player.less";

/**
 * 视频播放器
 * @params durationChange 音视频数据发生变化时
 */
export default (props) => {
  const newVideoRef = useRef(null);
  const boxRef = useRef(null);
  const [loading, setLoading] = useState(true);
  const {
    src,
    isPlay = true,
    thumb,
    auto = false,
    loop = false,
    durationChange,
    onPause,
    onErr,
    onEnd,
    videoRef = newVideoRef,
    hideControls,
    style = {},
  } = props;

  useEffect(() => {
    if (!videoRef || !videoRef.current) return;
    const setWaiting = () => {
      setLoading(true);
    };
    const setPlaying = (e) => {
      if (loading) setLoading(false);
      durationChange && durationChange(e);
    };
    videoRef.current.addEventListener("timeupdate", setPlaying, false);
    onPause && videoRef.current.addEventListener("onPause", onPause, false);
    onErr && videoRef.current.addEventListener("onErr", onErr, false);
    onEnd && videoRef.current.addEventListener("onEnd", onEnd, false);
    videoRef.current.addEventListener("waiting", setWaiting, false);
    videoRef && videoRef.current.setAttribute("src", src);
    return () => {
      if (videoRef && videoRef.current) {
        videoRef && videoRef.current.pause();
        videoRef && videoRef.current.setAttribute("src", "");
        videoRef && videoRef.current.load();
        videoRef.current.removeEventListener("timeupdate", setPlaying);
        onPause && videoRef.current.removeEventListener("onPause", onPause);
        onErr && videoRef.current.removeEventListener("onErr", onErr);
        onEnd && videoRef.current.removeEventListener("onEnd", onEnd);
        videoRef.current.removeEventListener("waiting", setWaiting);
      }
    };
  }, [src, videoRef]);

  useEffect(() => {
    const _handler = e => {
      e.stopPropagation();
    };
    if (boxRef?.current) {
      boxRef?.current?.addEventListener("touchmove", _handler);
    }
    return () => {
      if (boxRef?.current) {
        boxRef?.current?.removeEventListener("touchmove", _handler);
      }
    };
  }, []);

  return useMemo(() => (
    <div ref={boxRef} className="web-video-box" style={style}>
      {isPlay ? (
        <video
          ref={videoRef}
          controls={!hideControls}
          autoPlay={auto}
          loop={loop}
          poster={thumb}
          playsInline
          webkit-playsinline="true"
          src={src}
          onLoadedMetadata={() => {
            setLoading(false);
          }}
        />
      ) : <></>}
    </div>
  ), [
    boxRef,
    style,
    isPlay,
    videoRef,
    hideControls,
    auto,
    loop,
    thumb,
    src,
    loading,
  ]);
};
