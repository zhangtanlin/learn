import React, { useState, useEffect, useMemo, forwardRef, } from "react";

import VideoStore from "../../store/video";
import BtnVideoBack from "../Btn/BtnVideoBack";
import RenderPlayer from "./VideoShortPlayer";
import RenderSwiper from "./VideoShortSwiper";
import ScrollVertical from "../Scroll/ScrollVertical";
import BottomLoading from "../Loading/LoadingBottom";
import LoadingCircle from "../Loading/LoadingCircle";
import GlobalVar from "../../libs/GlobalVar";
import { BtnPlayerSearch } from "../Btn/BtnPlayer";

/**
 * 短视频
 * @param {string} props.stackKey 页面key当有返回按钮时，用以返回上一级页面
 * @param {string} props.data 数据列表
 * @param {string} props.index 展示当前列表里面的第几个
 * @param {string} props.params 请求参数
 * @param {string} props.onParams 请求下一页数据,传递参数给父组件
 */
export default forwardRef((props, playerRef) => {
  const {
    stackKey,
    // playerRef,
    data,
    index,
    params,
    onParams,
  } = props;
  const [video] = VideoStore.useGlobalState("video");
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    // 初始化判定(GlobalVar用以保存实时更新的状态,VideoStore用以渲染)
    if (stackKey && data) {
      GlobalVar.videoPause = true;
      GlobalVar.videoLoading = true;
      const tempVideoData = {
        videoPause: true,
        videoLoading: true,
        videoSwiperIndex: index,
      };
      VideoStore.dispatch({
        type: "replace",
        payload: tempVideoData,
      });
    }
    setLoading(false);
  }, []);
  return useMemo(() => (
    <div className="positioned-container black">
      {stackKey ? (
        <BtnVideoBack
          stackKey={stackKey}
          isLight
          onTap={() => {
            if (playerRef?.current) {
              playerRef?.current.pause();
            }
          }}
        />
      ) : <></>}
      {!stackKey ? (
        <BtnPlayerSearch />
      ) : <></>}
      {/* 播放器在底部 */}
      <RenderPlayer
        playerRef={playerRef}
      />
      {/* 滚动列表 */}
      {loading ? (
        <LoadingCircle show />
      ) : (
        <RenderSwiper
          playerRef={playerRef}
          data={data}
          params={params}
          onParams={onParams}
        />
      )}
      {/* 底部loading线 */}
      {video?.videoLoading ? (
        <BottomLoading />
      ) : <></>}
      {/* 底部广告 */}
      {(
        data?.length > 0 &&
        data[0].hotAds?.length > 0
      ) ? (
        <div className="feature-bottom-ad">
          <ScrollVertical
            list={data[0].hotAds}
            height={1.36}
            type={1}
          />
        </div>
      ) : <></>}
    </div>
  ), [
    loading,
    data,
    video?.videoLoading,
  ]);
});
