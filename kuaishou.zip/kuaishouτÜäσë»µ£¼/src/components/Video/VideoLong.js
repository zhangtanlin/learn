import React, { useEffect, useMemo, useRef, useState, } from "react";

import Emit from "../../libs/eventEmitter";
import VideoLongPlayer from "./VideoLongPlayer";
import LoadingCircle from "../Loading/LoadingCircle";
import VideoLongSlide from "./VideoLongSlide";
import BtnVideoBack from "../Btn/BtnVideoBack";
import { apiGetLongVideoUrl } from "../../libs/http";

// 长视频播放器
export default (props) => {
  const { stackKey, id } = props;
  const playerRef = useRef(null);
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState('');
  const getData = async () => {
    try {
      const tempParams = { id };
      const res = await apiGetLongVideoUrl(tempParams);
      if (res?.status) {
        setData(res?.data || {});
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
      });
    }
    setLoading(false);
  };
  useEffect(() => {
    getData();
  }, []);
  return useMemo(() => (
    <div className="positioned-container black">
      <BtnVideoBack
        stackKey={stackKey}
        playerRef={playerRef}
        onTap={() => {
          if (playerRef?.current) {
            playerRef?.current.pause();
          }
        }}
      />
      {/* 播放器在底部 */}
      <VideoLongPlayer
        playerRef={playerRef}
        videoUrl={data?.playURL}
      />
      {/* 滚动列表 */}
      {loading ? (
        <LoadingCircle show />
      ) : (
        <VideoLongSlide
          playerRef={playerRef}
          item={data}
        />
      )}
    </div>
  ), [
    loading,
    data,
  ]);
};
