import React, { forwardRef, useMemo, useRef } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/swiper.min.css";

import StackStore from "../../store/stack";
import VideoStore from "../../store/video";
import RenderSlide from "./VideoShortSlide";
import VideoLong from "./VideoLong";
import SheetVideoBuy from "../Sheet/SheetVideoBuy";
import Emit from "../../libs/eventEmitter";
import { NoData } from "../NoData";
import GlobalVar from "../../libs/GlobalVar";

/**
 * 视频播放swiper
 * @param {useRef}   playerRef      播放器
 * @param {number}   index          当前序列号
 * @param {Array}    data           列表数据
 * @param {Function} onCurrentIndex 更改当前默认展示的视频序列号
 * @param {Function} onParams       请求列表参数是否改变
 * @param {Function} onVideoLoading 视频是否加载中
 * @param {Function} onChange       视频播是否切换中
 * @param {Function} onPause        暂停视频播放器事件
 * @param {Function} onVideoUrl     设置播放器url方法
 *
 */
export default forwardRef((props, playerRef) => {
  const {
    // playerRef,
    data,
    params,
    onParams,
  } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const [video] = VideoStore.useGlobalState("video");
  // 跳转长视频
  const handleLongVideo = (videoInfo) => {
    if (!videoInfo?.id) return;
    if (videoInfo?.hasBuy) {
      const stackKey = `VideoLong-${new Date().getTime()}`;
      StackStore.dispatch({
        type: "push",
        payload: {
          name: "VideoLong",
          element: (
            <StackPage
              stackKey={stackKey}
              key={stackKey}
              style={{ zIndex: stacks.length + 2 }}
            >
              <VideoLong
                stackKey={stackKey}
                id={id}
              />
            </StackPage>
          ),
        },
      });
    } else {
      Emit.emit("showSheet", {
        _show: true,
        _content: (
          <SheetVideoBuy videoInfo={videoInfo} />
        ),
        _contentStyle: {
          background: "transparent",
        },
      });
    }
  };
  return useMemo(() => (
    data?.length ? (
      <Swiper
        className="default-swiper"
        noSwipingClass="swiper-no-swiping"
        direction="vertical"
        initialSlide={video?.videoSwiperIndex}
        onSlideChange={(e) => {
          // 渲染状态
          GlobalVar.videoPause = false;
          GlobalVar.videoLoading = true;
          const tempVideoData = {
            videoPause: false,
            VideoLoading: true,
            videoUrl: data[e?.activeIndex].playURL,
          };
          VideoStore.dispatch({
            type: "replace",
            payload: tempVideoData,
          });
          // 播放视频/状态设置为不暂停
          if (playerRef?.current) {
            playerRef?.current.play();
          }
          // 滑到底部添加视频
          if (e?.activeIndex === data?.length - 2) {
            if (onParams) {
              onParams({
                ...params,
                page: params.page + 1,
              })
            }
          }
        }}
      >
        {data?.map((item, index) => (
          <SwiperSlide key={`video-slide-${index}`}>
            <RenderSlide
              playerRef={playerRef}
              item={item}
              onLongVideo={() => {
                handleLongVideo(item);
              }}
            />
          </SwiperSlide>
        ))}
      </Swiper>
    ) : <NoData />
  ), [
    data,
    video?.videoSwiperIndex,
  ]);
});
