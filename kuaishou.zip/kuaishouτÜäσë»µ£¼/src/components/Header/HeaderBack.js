import React, { useEffect, useRef } from "react";
import Hammer from "hammerjs";
import '../../resources/css/header/header_back.less';

import Emit from "../../libs/eventEmitter";

import iconBackWhite from "../../resources/img/icon_back_white.png";
import iconBackBlack from "../../resources/img/icon_back_black.png";

export default (props) => {
  const backRef = useRef(null);
  const {
    stackKey,
    left, // 左侧块（方法）
    leftIconIsLight, // 左侧是否使用浅色图标
    center, // 中部块（方法）
    title, // 中部文字
    right, // 右侧块（方法）
    rightBtn, // 右侧按钮块（方法）
    fixed = false, // 是否透明浮动在顶部
    style, // 全局样式
  } = props;

  useEffect(() => {
    if (!backRef.current) return;
    const handle = () => {
      Emit.emit(stackKey, stackKey);
    };
    const hammer = new Hammer(backRef.current);
    hammer.on("tap", handle);
    return () => {
      hammer.off("tap", handle);
    };
  }, [backRef.current]);

  return (
    <div
      className={`
        back-header
        ${leftIconIsLight ? 'white' : 'black'}
        ${fixed ? 'fixed' : ''}
      `}
      style={style}
    >
      {/* 左侧 */}
      {
        left ? left() : (
          <div className="back-header-left">
            <div
              ref={backRef}
              className="back-header-left-back"
            >
              <img src={leftIconIsLight ? iconBackWhite : iconBackBlack} />
            </div>
          </div>
        )
      }
      {/* 中部 */}
      {
        center ? center() : (
          <div className="back-header-title">
            {title}
          </div>
        )
      }
      {/* 右侧 */}
      {
        right ? right() : (
          <div className="back-header-right">
            <div className="back-header-right-box">
              {rightBtn ? rightBtn() : <></>}
            </div>
          </div>
        )
      }
    </div>
  );
};
