import React, { useMemo, useRef, useState } from "react";
import '../../resources/css/login.less';

import ClickBtn from '../ClickBtn';
import Emit from "../../libs/eventEmitter";
import {
  apiLogin,
  apiRegist,
} from '../../libs/http.js';

import iconLogo from '../../resources/img/icon_logo.png';
import iconPwdShow from '../../resources/img/icon_pwd_show.png';
import iconPwdHide from '../../resources/img/icon_pwd_hide.png';

/**
 * 登录注册
 * @param [] props.type 选项{0: 登录, 1: 注册}
 */
export default (props) => {
  const { stackKey, type } = props;
  const userNameRef = useRef(null); // 用户名
  const passwordRef = useRef(null); // 密码
  const promptList = [
    '1.请务必记住自己的账号密码',
    '2.不提供密码修改功能',
    '3.不提供密码找回功能',
  ];
  // 提交 {type: 类型{0/null: 登录, 1: 注册}}
  const onSubmit = async (type) => {
    const reg = /^\s*$/g;
    const tempName = userNameRef.current.value;
    const tempPwd = passwordRef.current.value;
    if (reg.test(tempName)) {
      Emit.emit("showToast", {
        text: "账号或手机号不能为空",
        time: 3000
      });
      return;
    }
    if (reg.test(tempPwd)) {
      Emit.emit("showToast", {
        text: "密码不能为空",
        time: 3000
      });
      return;
    }
    try {
      let tempParam = {
        username: tempName,
        password: tempPwd,
      };
      let res;
      switch (type) {
        case 1:
          res = await apiRegist(tempParam);
          break;
        default:
          res = await apiLogin(tempParam);
          break;
      }
      if (res?.status) {
        Emit.emit("showToast", {
          text: res?.msg || res?.data?.msg || "提交成功",
          time: 3000
        });
        userNameRef.current.value = "";
        passwordRef.current.value = "";
        window.location.reload();
      } else {
        Emit.emit("showToast", {
          text: res?.msg || res?.data?.msg || "提交失败",
          time: 3000
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
        time: 3000
      });
    }
  };
  return useMemo(() => (
    <div className="positioned-container">
      <ClickBtn
        className="login-back"
        onTap={() => {
          Emit.emit(stackKey, stackKey);
        }}
      />
      <div className="login-head">
        <div className="login-head-avatar">
          <img src={iconLogo} />
        </div>
        <div className="login-head-title">欢迎来到成人快手</div>
      </div>
      <div className="login-swiper-box">
        <InputText
          userNameRef={userNameRef}
        />
        <InputPwd
          passwordRef={passwordRef}
        />
        <div className="login-active-box">
          <ClickBtn
            className="submit-btn"
            onTap={() => onSubmit(1)}
          >
            注册
          </ClickBtn>
          <ClickBtn
            className="submit-btn"
            onTap={() => onSubmit(0)}
          >
            登录
          </ClickBtn>
        </div>
        <div className="prompt-box">
          <div className="title">提示</div>
          {promptList?.map((item, index) => (
            <div
              key={`prompt-item-${index}`}
              className="item"
            >
              {item}
            </div>
          ))}
        </div>
      </div>
    </div>
  ), [
    promptList,
    userNameRef,
    passwordRef,
  ]);
};

/**
 * 文本框
 * @param {*} props
 * @returns
 */
const InputText = (props) => {
  const { userNameRef, } = props;
  return useMemo(() => {
    return (
      <div className="login-input-box">
        <input
          ref={userNameRef}
          type="text"
          placeholder="请输入账号或手机号"
        />
      </div>
    )
  }, [userNameRef]);
}

/**
 * 密码文本框
 * @param {*} props
 * @returns
 */
const InputPwd = (props) => {
  const { passwordRef, } = props;
  const [pwdShow, setPwdShow] = useState(false);
  return useMemo(() => (
    <div className="login-input-box">
      <input
        ref={passwordRef}
        type={pwdShow ? "text" : "password"}
        placeholder="请输入密码"
      />
      <ClickBtn
        className="icon"
        onTap={() => setPwdShow(!tempShow)}
      >
        <img src={pwdShow ? iconPwdShow : iconPwdHide} />
      </ClickBtn>
    </div>
  ), [passwordRef, pwdShow]);
}
