import React, { useMemo, useState } from "react";

import ClickBtn from '../ClickBtn';
import HeaderBack from "../Header/HeaderBack";
import Emit from "../../libs/eventEmitter";
import Const from "../../libs/const";
import { apiUpdatePwd, } from '../../libs/http.js';

// 修改密码
export default (props) => {
  const { stackKey } = props;
  const [params, setParams] = useState({
    oldPwd: '', // 旧密码
    newPwd: '', // 新密码
    verifyPwd: '', // 确认密码
  });
  const handleSubmit = async () => {
    const reg = /^\s*$/g;
    if (reg.test(params?.oldPwd)) {
      Emit.emit("showToast", {
        text: "旧密码不能为空",
        time: 3000
      });
      return;
    }
    if (reg.test(params?.newPwd)) {
      Emit.emit("showToast", {
        text: "密码不能为空",
        time: 3000
      });
      return;
    }
    if (reg.test(params?.newPwd)) {
      Emit.emit("showToast", {
        text: "请确认新密码",
        time: 3000
      });
      return;
    }
    if (params?.newPwd !== params?.verifyPwd) {
      Emit.emit("showToast", {
        text: "新密码和确认密码不一致",
        time: 3000
      });
      return;
    }
    try {
      const tempParam = {
        oldPassword: params?.oldPwd,
        password: params?.newPwd,
      };
      const res = await apiUpdatePwd(tempParam);
      if (res?.status) {
        setParams(prevState => ({
          ...prevState,
          ...{
            username: '',
            password: '',
          },
        }));
        Emit.emit("showToast", {
          text: res?.msg || res?.data?.msg || "提交成功",
          time: 3000
        });
        window.location.reload();
      } else {
        Emit.emit("showToast", {
          text: res?.msg || res?.data?.msg || "提交失败",
          time: 3000
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
        time: 3000
      });
    }
  };
  return useMemo(() => (
    <div className="positioned-container">
      <HeaderBack
        stackKey={stackKey}
        title={Const.titleChangePwd}
      />
      <div className="public-padding">
        <div className="user-withdraw-input">
          <input
            type="text"
            placeholder="请输入旧密码"
            onInput={({ target }) => {
              const tempReplace = target.value.replace(/[^\d]/g, '');
              setParams({
                ...params,
                ...{ oldPwd: tempReplace },
              });
            }}
          />
        </div>
        <div className="user-withdraw-input">
          <input
            type="text"
            placeholder="请输入新密码"
            onInput={({ target }) => {
              const tempReplace = target.value.replace(/[^\d]/g, '');
              setParams({
                ...params,
                ...{ newPwd: tempReplace },
              });
            }}
          />
        </div>
        <div className="user-withdraw-input">
          <input
            type="text"
            placeholder="请确认新密码"
            onInput={({ target }) => {
              const tempReplace = target.value.replace(/[^\d]/g, '');
              setParams({
                ...params,
                ...{ verifyPwd: tempReplace },
              });
            }}
          />
        </div>
        <ClickBtn
          className="user-public-btn"
          onTap={() => handleSubmit()}
        >
          提交
        </ClickBtn>
      </div>
    </div>
  ), [params]);
};
