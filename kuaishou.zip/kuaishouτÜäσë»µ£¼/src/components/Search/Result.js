import React, { useEffect, useMemo, useState } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import SwiperCore, { Controller } from "swiper";
import "swiper/swiper.min.css";

import ScrollArea from '../ScrollArea';
import Loading from '../Loading';
import Emit from "../../libs/eventEmitter";
import { ListUserFans } from "../List/User";
import { ListVideoSearch } from "../List/Video";
import { TabsTwo } from '../Tab';
import { NoData } from '../NoData';
import {
  apiSearchUserList,
  apiSearchMvList,
} from '../../libs/http';

SwiperCore.use([Controller]);
export default (props) => {
  const { show, text } = props;
  const [loading, setLoading] = useState(true);
  const navList = [
    {
      name: "视频",
      type: "video",
    },
    {
      name: "用户",
      type: "user",
    },
  ];
  const [currentTab, setCurrentTab] = useState(0);
  const [controlledSwiper, setControlledSwiper] = useState(null);
  useEffect(() => {
    if (show) {
      setLoading(false);
    } else {
      setLoading(true);
    }
  }, [show]);
  return useMemo(() => (
    loading ? (
      <Loading show overSize={false} />
    ) : (
      <>
        <TabsTwo
          navs={navList}
          currentIndex={currentTab}
          onChange={(index) => {
            setCurrentTab(index);
            controlledSwiper && controlledSwiper.slideTo(index);
          }}
        />
        <Swiper
          className="default-swiper"
          controller={{ control: controlledSwiper }}
          onSwiper={setControlledSwiper}
          onSlideChange={(e) => {
            setCurrentTab(e.realIndex);
          }}
        >
          {navList.map((item, index) => (
            <SwiperSlide
              key={`search-swiper-slide-${index}`}
            >
              <List
                show={currentTab === index}
                type={item?.type}
                text={text}
              />
            </SwiperSlide>
          ))}
        </Swiper>
      </>
    )
  ), [loading, navList, text, currentTab]);
};

/**
 * 搜索返回列表[视频/用户列表]
 * @param {*} props.show 是否切换到当前选项卡
 * @param {*} props.type 类型{0: 视频,1: 用户,}
 * @param {*} props.text 关键字
 */
const List = (props) => {
  const { show, type, text } = props;
  const [init, setInit] = useState(false);
  const [loading, setLoading] = useState(true);
  const [params, setParams] = useState({
    page: 1,
    isAll: false,
  });
  const [data, setData] = useState([]);
  const [loadingMore, setLoadingMore] = useState(true);
  const getData = async () => {
    if (params?.isAll) {
      return;
    }
    setLoadingMore(true);
    try {
      const tempParams = {
        kwy: text,
        ...params,
      };
      let res;
      switch (type) {
        case 'user':
          res = await apiSearchUserList(tempParams);
          break;
        default:
          res = await apiSearchMvList(tempParams);
          break;
      }
      if (res?.status) {
        if (params?.page === 1) {
          setData(res?.data?.list || []);
        } else {
          setData([...data, ...res?.data?.list || []]);
        }
        if (!res?.data?.list?.length) {
          setParams({ ...params, isAll: true });
        }
      } else {
        Emit.emit("showToast", {
          text: res?.msg || "请求列表失败",
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
      });
    }
    setLoading(false);
    setLoadingMore(false);
  };
  const nextPage = () => {
    if (!params?.isAll) {
      setParams((tempParam) => ({
        ...tempParam,
        page: tempParam?.page + 1
      }));
    }
  };
  useEffect(() => {
    if (show) {
      setInit(true);
    }
  }, [show]);
  useEffect(() => {
    if (init) {
      getData();
    }
  }, [init, params]);
  const setList = (type, data) => {
    if (data?.length) {
      switch (type) {
        case 'user':
          return (
            <ListUserFans list={data} />
          );
        default:
          return (
            <ListVideoSearch list={data} />
          );
      }
    } else {
      return (<NoData />);
    }
  };
  return useMemo(() => (
    loading ? (
      <Loading show overSize={false} />
    ) : (
      data?.length ? (
        <ScrollArea
          ListData={data?.length}
          loadingMore={loadingMore}
          onScrollEnd={nextPage}
        >
          <div className="public-padding">
            {setList(type, data)}
          </div>
        </ScrollArea>
      ) : <></>
    )
  ), [type, loading, data, loadingMore]);
};
