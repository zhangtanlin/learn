import React, { useEffect, useMemo, useState, useRef } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import SwiperCore, { Controller } from "swiper";
import "swiper/swiper.min.css";
import "../../resources/css/search.less";

import ScrollArea from "../ScrollArea";
import Emit from "../../libs/eventEmitter";
import ClickBtn from "../ClickBtn";
import Loading from "../Loading";
import Const from "../../libs/const";
import { NoData } from "../NoData";
import { TabsTwo } from '../Tab';
import {
  ListTagSearch,
  ListTagSearchHot,
} from "../List/Tag";
import {
  ListSearchFind,
  ListSearchPlay,
  ListSearchUpload,
  ListSearchSale,
} from "../List/Search";
import {
  apiGetSearchConfig,
  apiSearchFindList,
  apiSearchUploadList,
  apiSearchPlayList,
  apiSearchSaleList,
} from "../../libs/http";

import iconDel from '../../resources/img/icon_del.png';

SwiperCore.use([Controller]);

// 搜索列表页
export default (props) => {
  const { show, chooseTag } = props;
  const [loading, setLoading] = useState(true);
  const [listHistory, setListHistory] = useState([]);
  const [listHot, setListHot] = useState([]);
  const navList = [
    { name: "发现", type: "find", },
    { name: "最新上传", type: "new", },
    { name: "热播榜", type: "play", },
    { name: "热购榜", type: "sale", },
  ];
  const [currentTab, setCurrentTab] = useState(0);
  const [controlledSwiper, setControlledSwiper] = useState(null);
  // 上拉吸顶
  const contentRef = useRef(null); // 外部滚动盒子
  const tabRef = useRef(null); // 内部选项卡盒子
  useEffect(() => {
    if (!contentRef.current || !tabRef.current) return;
    tabRef.current.setAttribute(
      "style",
      `height:${contentRef.current.clientHeight}px`
    );
  }, [contentRef.current, tabRef.current]);
  const init = async () => {
    try {
      const history = localStorage.getItem("SEARCH_HISTORY");
      if (history) {
        setListHistory(history.split(","));
      }
      const res = await apiGetSearchConfig();
      if (res?.status) {
        if (res?.data?.hotSearch?.length) {
          setListHot(res?.data?.hotSearch || []);
        }
      } else {
        Emit.emit("showToast", {
          text: "初始化搜索页失败",
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
      });
    }
    setLoading(false);
  };
  useEffect(() => {
    if (show) {
      init();
    } else {
      setLoading(true);
    }
  }, [show]);
  const clearHistory = () => {
    setListHistory([]);
    localStorage.setItem(
      Const.searchStorageKey, "",
    );
  };
  return useMemo(() => (
    loading ? (
      <Loading show overSize={false} />
    ) : (
      <div
        ref={contentRef}
        className="full-column"
      >
        <ScrollArea ListData={navList}>
          <div className="public-padding">
            <div className="search-title-box">
              <div className="search-title">
                搜索历史
              </div>
              <ClickBtn
                className="search-clear"
                onTap={clearHistory}
              >
                <img src={iconDel} />
              </ClickBtn>
            </div>
            {listHistory?.length ? (
              <ListTagSearch
                list={listHistory}
                onTap={(keyword) => {
                  chooseTag(keyword);
                }}
              />
            ) : (
              <div className="search-prompt">暂无</div>
            )}
            {listHot?.length > 0 ? (
              <>
                <div className="search-title-box">
                  <div className="search-title">
                    热门搜索
                  </div>
                </div>
                <ListTagSearchHot
                  list={listHot}
                  onTap={(keyword) => {
                    chooseTag(keyword);
                  }}
                />
              </>
            ) : <></>}
            <div ref={tabRef}>
              <TabsTwo
                navs={navList}
                currentIndex={currentTab}
                onChange={(index) => {
                  setCurrentTab(index);
                  controlledSwiper && controlledSwiper.slideTo(index);
                }}
              />
              <Swiper
                className="default-swiper"
                controller={{ control: controlledSwiper }}
                onSwiper={setControlledSwiper}
                onSlideChange={(e) => {
                  setCurrentTab(e.realIndex);
                }}
              >
                {navList.map((item, index) => (
                  <SwiperSlide
                    key={`search-swiper-slide-${index}`}
                  >
                    <RecommendList
                      show={currentTab === index}
                      type={item?.type}
                    />
                  </SwiperSlide>
                ))}
              </Swiper>
            </div>
          </div>
        </ScrollArea>
      </div>
    )
  ), [
    loading,
    listHistory,
    listHot,
    navList,
    currentTab,
    controlledSwiper,
  ]);
};

// 搜索推荐选项卡列表
export const RecommendList = (props) => {
  const { show, type } = props;
  const [init, setInit] = useState(false);
  const [loading, setLoading] = useState(true);
  const [params, setParams] = useState({
    page: 1,
    isAll: false,
  });
  const [data, setData] = useState([]);
  const [otherData, setOtherData] = useState([]); // 用于发现列表的人气榜单
  const [loadingMore, setLoadingMore] = useState(true);
  const getData = async () => {
    if (params?.isAll) {
      return;
    }
    setLoadingMore(true);
    try {
      const tempParams = {
        ...params,
      };
      let res = null;
      let tempDefaultList = [];
      let tempOtherList = [];
      switch (type) {
        case 'find':
          res = await apiSearchFindList(tempParams);
          tempDefaultList = res?.data?.wonderful?.list || [];
          tempOtherList = res?.data?.popularityList?.list || [];
          break;
        case 'new':
          res = await apiSearchUploadList(tempParams);
          tempDefaultList = res?.data || [];
          break;
        case 'play':
          res = await apiSearchPlayList(tempParams);
          tempDefaultList = res?.data || [];
          break;
        case 'sale':
          res = await apiSearchSaleList(tempParams);
          tempDefaultList = res?.data || [];
          break;
        default:
          break;
      }
      if (res?.status) {
        if (params?.page === 1) {
          setData(tempDefaultList);
          setOtherData(tempOtherList);
        } else {
          setData([...data, ...tempDefaultList || []]);
          setOtherData([...data, ...tempOtherList || []]);
        }
        if (!tempDefaultList?.length || type === 'find') {
          setParams({ ...params, isAll: true });
        }
      } else {
        Emit.emit("showToast", {
          text: res?.msg || "请求列表失败",
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
      });
    }
    setLoading(false);
    setLoadingMore(false);
  };
  const nextPage = () => {
    if (!params?.isAll) {
      setParams((tempParam) => ({
        ...tempParam,
        page: tempParam?.page + 1
      }));
    }
  };
  useEffect(() => {
    if (show) {
      setInit(true);
    }
  }, [show]);
  useEffect(() => {
    if (init) {
      getData();
    }
  }, [init, params]);
  // 根据选项卡类型设置列表
  const setList = (type, data, otherData) => {
    if (data?.length) {
      switch (type) {
        case 'find':
          return (
            <ListSearchFind
              key={`ListSearchFind-${type}`}
              list={data}
              listOther={otherData}
            />
          );
        case 'new':
          return (
            <ListSearchUpload
              key={`ListSearchUpload-${type}`}
              list={data}
            />
          );
        case 'play':
          return (
            <ListSearchPlay
              key={`ListSearchPlay-${type}`}
              list={data}
            />
          );
        case 'sale':
          return (
            <ListSearchSale
              key={`ListSearchSale-${type}`}
              list={data}
            />
          );
        default:
          break;
      }
    } else {
      return (<NoData />);
    }
  };
  return useMemo(() => (
    loading ? (
      <Loading show overSize={false} />
    ) : (
      data?.length > 0 ? (
        <ScrollArea
          ListData={data?.length}
          loadingMore={loadingMore}
          onScrollEnd={nextPage}
        >
          {setList(type, data, otherData,)}
        </ScrollArea>
      ) : <NoData />
    )
  ), [type, loading, data, otherData, loadingMore]);
};
