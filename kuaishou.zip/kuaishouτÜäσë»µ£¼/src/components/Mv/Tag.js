import React, { useEffect, useState, useMemo } from "react";
import "../../resources/css/collection.less";

import ScrollArea from '../ScrollArea';
import HeaderBack from '../Header/HeaderBack';
import Loading from '../Loading';
import Emit from "../../libs/eventEmitter";
import Const from "../../libs/const";
import { NoData } from '../NoData';
import { ListTag } from "../List/Tag";
import { apiTagList } from '../../libs/http';

/**
 * 标签列表
 * @param {string | number} props.id 标签id
 */
export default (props) => {
  const { stackKey } = props;
  const [loading, setLoading] = useState(true);
  const [params, setParams] = useState({
    page: 1,
    limit: 21,
    isAll: false,
  });
  const [data, setData] = useState([]); // 合集列表
  const [loadingMore, setLoadingMore] = useState(true);
  const getData = async () => {
    if (params?.isAll) return;
    setLoadingMore(true);
    try {
      const tempParam = { ...params };
      const res = await apiTagList(tempParam);
      if (res?.status) {
        if (params?.page === 1) {
          setData(res?.data);
        } else {
          setData([...data, ...res?.data]);
        }
        if (!res?.data?.length) {
          setParams({ ...params, isAll: true });
        }
      } else {
        Emit.emit("showToast", {
          text: "请求列表失败",
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
      });
    }
    setLoading(false);
    setLoadingMore(false);
  };
  const nextPage = () => {
    if (!params?.isAll) {
      setParams((tempParam) => ({
        ...tempParam,
        page: tempParam?.page + 1
      }));
    }
  };
  useEffect(() => {
    getData();
  }, [params]);
  return useMemo(() => (
    <div className="positioned-container">
      <HeaderBack
        stackKey={stackKey}
        title={Const.titleTag}
      />
      {loading ? (
        <Loading show />
      ) : (
        data?.length ? (
          <ScrollArea
            loadingMore={loadingMore}
            onScrollEnd={nextPage}
          >
            <div className="public-padding">
              <ListTag list={data} />
            </div>
          </ScrollArea>
        ) : <NoData />
      )}
    </div>
  ), [loading, data, loadingMore]);
};
