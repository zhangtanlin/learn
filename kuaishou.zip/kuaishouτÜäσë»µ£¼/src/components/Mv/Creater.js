import React, { useMemo, useState, useEffect } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import SwiperCore, { Controller } from "swiper";
import "swiper/swiper.min.css";

import Loading from '../Loading';
import ScrollArea from '../ScrollArea';
import HeaderBack from '../Header/HeaderBack';
import Emit from "../../libs/eventEmitter";
import Const from "../../libs/const";
import ScrollHorizontal from "../Scroll/ScrollHorizontal";
import ClickBtn from "../ClickBtn";
import BtnCreaterFollow from "../Btn/BtnCreaterFollow";
import { TabsTwo } from "../Tab";
import { CreaterScrollerList } from "../list/Video";
import { ListUserCreater } from "../list/User";
import {
  apiCreaterHeader,
  apiLikeRanking,
  apiMoneyRanking,
  apiUploadRanking,
} from "../../libs/http";

import iconLogo from "../../resources/img/icon_logo.png";

SwiperCore.use([Controller]);

// 创作达人
export default (props) => {
  const { stackKey, type = 0 } = props;
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState({
    author: {},
    mv_list: [],
  });
  const navList = [
    { id: 0, name: "获赞", },
    { id: 1, name: "上传", },
    { id: 2, name: "收益", },
  ];
  const [tabIndex, setTabIndex] = useState(type);
  const [controlledSwiper, setControlledSwiper] = useState(null);
  const getData = async () => {
    setLoading(true);
    try {
      const res = await apiCreaterHeader();
      if (res?.status) {
        setData(res?.data);
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
      });
    }
    setLoading(false);
  };
  const refresh = () => {
    getData();
  };
  useEffect(() => {
    getData();
  }, []);
  return useMemo(() => (
    <div className="positioned-container creater">
      <div className="creater-bg" />
      <HeaderBack
        leftIconIsLight
        title={Const.creativeTalent}
        stackKey={stackKey}
      />
      {loading ? (
        <Loading show />
      ) : (
        <ScrollArea
          loadingMore={false}
          pullDonRefresh={() => refresh()}
        >
          <div className="content">
            <div className="info-box">
              <div className="avatar">
                <img src={iconLogo} />
              </div>
              <div className="text-box">
                <div className="title">
                  {data?.author?.nickname}
                </div>
                <div className="subtitle">
                  {data?.author?.person_signnatrue}
                </div>
              </div>
              <BtnCreaterFollow
                radius
                active={data?.author?.is_attention}
                uid={data?.author?.uid}
              />
            </div>
            <div className="desc">代表作: 暂无</div>
            {data?.mv_list?.length ? (
              <ScrollHorizontal>
                <CreaterScrollerList
                  list={data?.mv_list}
                />
              </ScrollHorizontal>
            ) : <></>}
            <TabsTwo
              themeLight
              navs={navList}
              currentIndex={tabIndex}
              onChange={(index) => {
                setTabIndex(index);
                controlledSwiper && controlledSwiper.slideTo(index);
              }}
            />
            <Swiper
              className="default-swiper"
              initialSlide={tabIndex || 0}
              controller={{ control: controlledSwiper }}
              onSwiper={setControlledSwiper}
              onSlideChange={e => {
                setTabIndex(e.activeIndex);
              }}
            >
              {navList.map((item, index) => (
                <SwiperSlide key={`nav-item-${item?.id}`}>
                  <TabList
                    show={tabIndex === index}
                    type={index}
                  />
                </SwiperSlide>
              ))}
            </Swiper>
          </div>
        </ScrollArea>
      )}
    </div>
  ), [loading, navList, tabIndex, data, controlledSwiper]);
};

/**
 * 选项卡列表
 * @param {*} props.type {0: 获赞, 1: 上传, 2: 收益}
 */
const TabList = (props) => {
  const { show, type } = props;
  const [init, setInit] = useState(false);
  const [loading, setLoading] = useState(true);
  const tabList = [
    { id: 0, name: "日榜", },
    { id: 1, name: "周榜", },
    { id: 2, name: "月榜", },
  ];
  useEffect(() => {
    if (show) {
      setInit(true);
    }
  }, [show]);
  useEffect(() => {
    if (init) {
      setLoading(false);
    }
  }, [init]);
  const [tabIndex, setTabIndex] = useState(0);
  const [controlledSwiper, setControlledSwiper] = useState(null);
  return useMemo(() => (
    loading ? (
      <Loading show overSize={false} />
    ) : (
      <>
        <div className="creater-tab-header">
          <div
            className="mark"
            style={{ left: tabIndex * 1.5 + 'rem' }}
          />
          {tabList?.length ? (
            tabList?.map((item, index) => (
              <ClickBtn
                className={`
                  item ${tabIndex === index ? 'active' : ''}
                `}
                key={`nav-item-${index}`}
                onTap={() => {
                  setTabIndex(index);
                  controlledSwiper && controlledSwiper.slideTo(index);
                }}
              >
                {item?.name}
              </ClickBtn>
            ))
          ) : <></>}
        </div>
        <Swiper
          className="default-swiper"
          initialSlide={tabIndex || 0}
          controller={{ control: controlledSwiper }}
          onSwiper={setControlledSwiper}
          onSlideChange={e => {
            setTabIndex(e.activeIndex);
          }}
        >
          {tabList?.map((item, index) => (
            <SwiperSlide key={`nav-item-${index}`}>
              <InnerTabList
                show={tabIndex === index}
                type={type}
                listType={item?.id}
              />
            </SwiperSlide>
          ))}
        </Swiper>
      </>
    )
  ), [type, loading, tabList, tabIndex, controlledSwiper]);
};

/**
 * 内部选项卡列表
 * @param {*} props.type {0: 获赞, 1: 上传, 2: 收益}
 * @param {*} props.listType {0: 日榜, 1: 周榜, 2: 月榜}
 */
const InnerTabList = (props) => {
  const { show, type, listType } = props;
  const [init, setInit] = useState(false);
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState([]);
  const getData = async () => {
    try {
      let tempType = null;
      switch (listType) {
        case 1:
          tempType = 'week'
          break;
        case 2:
          tempType = 'moon'
          break;
        default:
          tempType = 'day';
          break;
      }
      const tempParam = {
        type: tempType
      }
      let res = null;
      switch (type) {
        case 1:
          res = await apiUploadRanking(tempParam);
          break;
        case 2:
          res = await apiMoneyRanking(tempParam);
          break;
        default:
          res = await apiLikeRanking(tempParam);
          break;
      }
      if (res?.status) {
        setData(res?.data);
      }
      setLoading(false);
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
      });
    }
  };
  useEffect(() => {
    if (show) {
      setInit(true);
    }
  }, [show]);
  useEffect(() => {
    if (init) {
      getData();
    }
  }, [init]);
  return useMemo(() => (
    loading ? (
      <Loading show />
    ) : (
      <ScrollArea
        ListData={data?.length}
      >
        <ListUserCreater
          type={type}
          list={data}
        />
      </ScrollArea>
    )
  ), [loading, data, type]);
}
