import React, { useMemo, useState, useEffect } from "react";

import StackPage from "../StackPage";
import StackStore from "../../store/stack";
import Loading from '../Loading';
import ScrollArea from '../ScrollArea';
import ClickBtn from '../ClickBtn';
import Simg from '../Simg';
import Emit from "../../libs/eventEmitter";
import Everyday from "../EveryDay";
import HotVideo from "./HotVideo";
import Collection from "./Collection";
import Tag from "./Tag";
import ScrollVertical from '../Scroll/ScrollVertical';
import HeaderSearch from "../Header/HeaderSearch";
import { NavRow } from '../Nav';
import { BannerAdList } from '../Banner';
import { VideoItem } from '../Card/CardVideo';
import { CollectionItemHot } from "../Card/CardCollection";
import { TagItemMvHot } from "../Card/CardTag";
import { ListVideoInfo } from "../List/Video";
import { apiMvIndex } from "../../libs/http";

// 视频
export default (props) => {
  const { isVisible } = props;
  const [loading, setLoading] = useState(true);
  const [init, setInit] = useState(false); // 判定是否初次进入
  const [params, setParams] = useState({
    page: 1,
    limit: 12,
  })
  const [data, setData] = useState({
    banner: [],
    body: [],
    icon: [],
    ranking: [],
  });
  const getData = async () => {
    try {
      const res = await apiMvIndex(params);
      if (res?.status) {
        setData(res?.data);
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
      });
    }
    setLoading(false);
  };
  const refresh = () => {
    getData();
  };
  useEffect(() => {
    if (isVisible) {
      setInit(true);
    }
  }, [isVisible]);
  useEffect(() => {
    if (init) {
      getData();
    }
  }, [init]);

  return useMemo(() => (
    <div
      className={`
        positioned-container
        ${isVisible ? 'visible' : 'hide'}
      `}
    >
      {loading ? (
        <Loading show overSize={false} />
      ) : (
        <>
          <HeaderSearch />
          <ScrollArea
            loadingMore={false}
            pullDonRefresh={() => refresh()}
          >
            <div className="public-padding">
              <BannerAdList
                list={data?.banner || []}
                style={{marginBottom: '.4rem'}}
              />
              {data?.ranking?.length ? (
                <ScrollVertical
                  height={1}
                  list={data?.ranking || []}
                />
              ) : <></>}
              <NavRow list={data?.icon || []} />
              {data?.body?.length ? (
                data?.body?.map((item, index) => (
                  <List
                    key={`BodyItem-${index}`}
                    item={item}
                  />
                ))
              ) : <></>}
            </div>
          </ScrollArea>
        </>
      )}
    </div>
  ), [isVisible, loading, data,]);
};

/// 列表
const List = (props) => {
  const { item } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const handleMore = () => {
    let tempName = '';
    let tempStackKey = '';
    let tempPage = '';
    switch (item?.type) {
      case 'mei_ri': // 每日推荐
        tempName = 'Everyday';
        tempStackKey = `Everyday-${new Date().getTime()}`;
        tempPage = <Everyday stackKey={tempStackKey} />;
        break;
      case 'dou_mai': // 大家都在买
        tempName = 'HotVideo';
        tempStackKey = `HotVideo-${new Date().getTime()}`;
        tempPage = <HotVideo stackKey={tempStackKey} type={1} />;
        break;
      case 'dou_xi_huan': // 大家都喜欢
        tempName = 'HotVideo';
        tempStackKey = `HotVideo-${new Date().getTime()}`;
        tempPage = <HotVideo stackKey={tempStackKey} type={0} />;
        break;
      case 'he_ji': // 合集
        tempName = 'Collection';
        tempStackKey = `Collection-${new Date().getTime()}`;
        tempPage = <Collection stackKey={tempStackKey} />;
        break;
      case 'biao_qian': // 标签
        tempName = 'Tag';
        tempStackKey = `Tag-${new Date().getTime()}`;
        tempPage = <Tag stackKey={tempStackKey} />;
        break;
      default:
        break;
    }
    if (!tempName) {
      Emit.emit("showToast", {
        text: "暂未开发",
      });
      return;
    };
    StackStore.dispatch({
      type: "push",
      payload: {
        name: tempName,
        element: (
          <StackPage
            stackKey={tempStackKey}
            key={tempStackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            {tempPage}
          </StackPage>
        ),
      },
    });
  }
  // 跳转视频详情页播放
  const handleVideoDetail = (id) => {
    if (!id) return;

  };
  // 根据类型设置不同的展示列表
  const setListByType = (type, data) => {
    switch (type) {
      case 'he_ji':
        return (
          <div className="list-box">
            {data?.map((obj, index) => (
              <CollectionItemHot
                key={`CollectionItem-${index}`}
                item={obj}
              />
            ))}
          </div>
        );
      case 'biao_qian':
        return (
          <div className="list-box">
            {data?.map((obj, index) => (
              <TagItemMvHot
                key={`CollectionItem-${index}`}
                item={obj}
              />
            ))}
          </div>
        );
      default:
        return (
          <ListVideoInfo list={data} />
        );
    }
  }
  return useMemo(() => (
    <div className="mv-body">
      <div className="head-box">
        <div className="icon">
          {item?.icon && <Simg noBg src={item?.icon} />}
        </div>
        <div className="title">{item?.name}</div>
        <div className="subtitle">{item?.subName}</div>
        <ClickBtn
          className="btn"
          onTap={handleMore}
        >更多</ClickBtn>
      </div>
      {setListByType(
        item?.type,
        item?.item,
      )}
    </div>
  ), [item]);
};
