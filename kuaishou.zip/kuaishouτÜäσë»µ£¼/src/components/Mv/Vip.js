import React, { useEffect, useState, useMemo, useRef } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import SwiperCore, { Controller } from "swiper";
import "swiper/swiper.min.css";

import ScrollArea from '../ScrollArea';
import HeaderSearch from '../Header/HeaderSearch';
import ScrollHorizontal from "../Scroll/ScrollHorizontal";
import Loading from '../Loading';
import Emit from "../../libs/eventEmitter";
import HeaderBack from "../Header/HeaderBack";
import { NoData } from '../NoData';
import { TabsTwo } from '../Tab';
import { BannerAdList } from '../Banner';
import { ListVideoSearch } from '../List/Video';
import {
  apiVipIndex,
  apiUploaderFollow,
  apiUploaderRecommend,
  apiUploaderTag,
} from '../../libs/http';

SwiperCore.use([Controller]);

// 钻石广场
export default (props) => {
  const { isVisible, stackKey, title = "" } = props;
  // 上拉吸顶
  const contentRef = useRef(null); // 外部滚动盒子
  const tabRef = useRef(null); // 内部选项卡盒子
  useEffect(() => {
    if (!contentRef.current || !tabRef.current) return;
    tabRef.current.setAttribute(
      "style",
      `height:${contentRef.current.clientHeight}px`
    );
  }, [contentRef.current, tabRef.current]);
  // 广告
  const [bannerData, setBannerData] = useState([]);
  const [navList, setNavList] = useState([]);
  const [init, setInit] = useState(false);
  const [tabIndex, setTabIndex] = useState(0);
  const [controlledSwiper, setControlledSwiper] = useState(null);
  const getData = async () => {
    try {
      const res = await apiVipIndex();
      if (res?.status) {
        setBannerData(res?.data?.ads || []);
        const tempNavList = [];
        if (res?.data?.tab?.length) {
          const tempTab = res?.data?.tab;
          tempTab?.forEach((element, index) => {
            tempNavList.push({
              id: index,
              type: element?.type,
              name: element?.name,
            });
          });
          setNavList(tempNavList);
        }
      } else {
        Emit.emit("showToast", {
          text: "请求列表失败",
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
      });
    }
  };
  useEffect(() => {
    if (isVisible) {
      setInit(true);
    }
  }, [isVisible])
  useEffect(() => {
    if (init) {
      getData();
    }
  }, [init]);
  // 设置头部文本
  const setHeaderTitle = () => {
    if (title) {
      return title || '';
    }
    return 'VIP专享';
  };
  return useMemo(() => (
    <div
      className={`
        positioned-container
        ${isVisible ? 'visible' : 'hide'}
      `}
    >
      {stackKey ? (
        <HeaderBack
          stackKey={stackKey}
          title={setHeaderTitle()}
        />
      ) : (
        <HeaderSearch />
      )}
      <div
        ref={contentRef}
        className="full-column"
      >
        <ScrollArea ListData={bannerData}>
          <div className="public-padding">
            <BannerAdList list={bannerData} />
            <div ref={tabRef}>
              <ScrollHorizontal>
                <TabsTwo
                  navs={navList}
                  currentIndex={tabIndex}
                  onChange={(index) => {
                    setTabIndex(index);
                    controlledSwiper && controlledSwiper.slideTo(index);
                  }}
                />
              </ScrollHorizontal>
              <Swiper
                className="default-swiper"
                initialSlide={tabIndex}
                controller={{ control: controlledSwiper }}
                onSwiper={setControlledSwiper}
                onSlideChange={e => {
                  setTabIndex(e.activeIndex);
                }}
              >
                {navList?.length ? (
                  navList?.map((item, index) => (
                    <SwiperSlide key={`nav-item-${item?.id}`}>
                      <List
                        show={tabIndex === index}
                        type={item?.type || ''}
                        tag={item?.name || ''}
                      />
                    </SwiperSlide>
                  ))
                ) : <></>}
              </Swiper>
            </div>
          </div>
        </ScrollArea>
      </div>
    </div>
  ), [isVisible, bannerData, title, navList, tabIndex]);
};

/**
 * 列表
 * @param {boolean} props.show 是否显示列表
 * @param {number}  props.type 类型{0:关注,1:推荐,2:标签}
 */
const List = (props) => {
  const { show, type, tag } = props;
  const [init, setInit] = useState(false); // 判定是否初次进入
  const [loading, setLoading] = useState(true);
  const [params, setParams] = useState({
    page: 1,
    limit: 6,
    isAll: false,
    tag,
  });
  const [data, setData] = useState([]);
  const [loadingMore, setLoadingMore] = useState(true);
  const getData = async () => {
    if (params?.isAll) {
      return;
    }
    setLoadingMore(true);
    try {
      const tempParam = { ...params };
      let res = null;
      let tempList = [];
      switch (type) {
        // 关注
        case 'follow':
          res = await apiUploaderFollow(tempParam);
          tempList = res?.data?.list || [];
          break;
        // 推荐
        case 'recommend':
          res = await apiUploaderRecommend(tempParam);
          tempList = res?.data?.list || [];
          break;
        // 标签相关
        default:
          res = await apiUploaderTag(tempParam);
          tempList = res?.data?.list || [];
          break;
      }
      if (res?.status) {
        if (params?.page === 1) {
          setData(tempList);
        } else {
          setData([...data, ...tempList]);
        }
        if (!tempList?.length) {
          setParams({ ...params, isAll: true });
        }
      } else {
        Emit.emit("showToast", {
          text: "请求列表失败",
          time: 3000
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
        time: 3000
      });
    }
    setLoading(false);
    setLoadingMore(false);
  };
  const nextPage = () => {
    if (!params?.isAll) {
      setParams((tempParam) => ({
        ...tempParam,
        page: tempParam?.page + 1
      }));
    }
  };
  useEffect(() => {
    if (show) {
      setInit(true);
    }
  }, [show]);
  useEffect(() => {
    if (init) {
      getData();
    }
  }, [init, params]);
  // 根据type的不同使用不同列表显示信息
  const setListByType = (data, type) => {
    switch (type) {
      case 'follow':
        return (
          <ListVideoSearch
            key={`ListVideoSearch-${type}`}
            list={data}
          />
        );
      case 'recommend':
        return (
          <ListVideoSearch
            key={`ListVideoSearch-${type}`}
            list={data}
          />
        );
      default:
        return (
          <ListVideoSearch
            key={`ListVideoSearch-${type}`}
            list={data}
          />
        );
    }
  };
  return useMemo(() => (
    loading ? (
      <Loading show overSize={false} />
    ) : (
      data?.length > 0 ? (
        <ScrollArea
          ListData={data?.length}
          loadingMore={loadingMore}
          onScrollEnd={nextPage}
        >
          {setListByType(data, type)}
        </ScrollArea>
      ) : <NoData />
    )
  ), [type, loading, data, loadingMore]);
};
