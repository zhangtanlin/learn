import React, { useMemo, useState } from "react";
import '../../resources/css/card/card_video.less';

// import StackStore from "../../store/stack";
// import StackPage from "../StackPage";
import ClickBtn from "../ClickBtn";
import Simg from "../Simg";
import Avatar from '../Avatar';
import Emit from "../../libs/eventEmitter";
import {
  apiSetFollowing
} from '../../libs/http';

import iconPlayTime from '../../resources/img/icon_play_time.png';
import iconLikeGray from '../../resources/img/icon_like_gray.png';
import iconWhiteComment from '../../resources/img/icon_white_comment.png';
import iconDiamond from '../../resources/img/icon_diamond.png';
import iconAdd from '../../resources/img/icon_add.png';

// 关注视频列表
export const VideoFollowItem = (props) => {
  const { item, onTap } = props;
  const handleDetail = () => {
    onTap && onTap();
  };
  return useMemo(() => (
    <ClickBtn
      className="video-follow-item"
      onTap={() => handleDetail()}
    >
      <div className="img-box">
        <div className="img-inner-box">
          <Simg src={item?.thumbImg} />
        </div>
      </div>
      <div className="title">
        {item?.person_signnatrue}
      </div>
      <div className="info-box">
        <Avatar
          src={item?.user?.thumb}
          uid={item?.uid}
        />
        <div className="desc">进入主页更精彩</div>
        <div className="statistics">
          <span className="mark" />
          <span className="text">{item?.like}</span>
        </div>
      </div>
    </ClickBtn>
  ), [item]);
};

// 默认视频列表项【封面上浮动播放次数,下附标题】
export const VideoItem = (props) => {
  const { item, onlyTheme = false, onTap } = props;
  const handleDetail = () => {
    onTap && onTap();
  };
  return useMemo(() => (
    <ClickBtn
      className="video-item"
      onTap={() => handleDetail()}
    >
      <div className="img-box">
        <Simg src={item?.thumbImg} />
        {!onlyTheme ? (
          <div className="img-bottom">
            <div className="img-bottom-item" />
            <div className="img-bottom-item">
              <img src={iconPlayTime} />
              {item?.like || 0}
            </div>
          </div>
        ) : <></>}
      </div>
      {!onlyTheme ? (
        <div className="title">{item?.title}</div>
      ) : <></>}
    </ClickBtn>
  ), [item]);
};

// 我的购买视频列表【含有金币价格的列表行】
export const VideoItemCoin = (props) => {
  const { item, onTap } = props;
  const handleDetail = () => {
    onTap && onTap();
  };
  return useMemo(() => (
    <ClickBtn
      className="video-buy-item"
      onTap={() => handleDetail()}
    >
      <div className="img-box">
        <Simg src={item?.cover_thumb_url} />
        <div className="img-bottom">
          <div className="img-bottom-item">
            {item?.rating || 0}次播放
          </div>
          <div className="img-bottom-item">
            <img src={iconPlayTime} />
            {item?.like || 0}
          </div>
        </div>
      </div>
      <div className="info-box">
        <div className="title">{item?.title}</div>
        <div className="avatar-row">
          <div className="avatar-box">
            <Simg src={item?.user?.avatar_url} />
          </div>
          <div className="text">{item?.user?.nickname}</div>
        </div>
        <div className="diamond-row">
          <img src={iconDiamond} />
          <div className="text">{item?.coins}</div>
        </div>
      </div>
    </ClickBtn>
  ), [item]);
};

// 带有关注按钮的列表
export const AttentionVideoList = (props) => {
  const { item } = props;
  // const [stacks] = StackStore.useGlobalState("stacks");
  let attentionBtnClick = true; // 关注按钮是否被点击
  const [attention, setAttention] = useState(
    item?.user?.is_attention || 0
  ); // 是否关注{0: 未关注,1:已关注}
  const toDetail = () => {};
  const handleAttention = async (uid) => {
    if (!attentionBtnClick || !uid) return; // 接口请求之后按钮禁止点击
    try {
      attentionBtnClick = false;
      const tempParams = { to_uid: uid };
      const res = await apiSetFollowing(tempParams);
      if (res?.status) {
        setAttention(attention === 1 ? 0 : 1);
        Emit.emit("showToast", {
          text: res?.data?.msg || "操作成功",
          time: 3000
        });
      } else {
        Emit.emit("showToast", {
          text: res?.data?.msg || "操作失败",
          time: 3000
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
        time: 3000
      });
    }
    attentionBtnClick = true;
  };
  return useMemo(() => (
    <div className="video-attention-item">
      <div className="head-box">
        <Avatar
          boxClass="avatar"
          img={item?.user?.avatar_url}
          uid={item?.user?.uid}
        />
        <div className="name">
          {item?.user?.nickname}
        </div>
        <ClickBtn
          className={`btn ${attention === 1 ? 'active' : ''}`}
          onTap={() => handleAttention(item?.uid)}
        >
          {attention === 1 ? '已关注' : (
            <>
              <img src={iconAdd} />
              关注
            </>
          )}
        </ClickBtn>
      </div>
      <ClickBtn
        className="cover-box"
        onTap={() => toDetail(item?.id)}
      >
        <Simg src={item?.cover_thumb_url} />
        <div className="info">
          <div className="item">{item?.rating || 0}次播放</div>
          <div className="item">
            <img className="icon" src={iconWhiteComment} />
            {item?.comment || 0}
          </div>
          <div className="item">
            <img className="icon" src={iconPlayTime} />
            {item?.is_like || 0}
          </div>
        </div>
      </ClickBtn>
      <div className="bottom-box">
        {item?.title}
      </div>
    </div>
  ), [item, attention]);
};

// 搜索-视频
export const VideoItemSearch = (props) => {
  const {
    item,
    hidePrice = false,
    onTap,
  } = props;
  const handleDetail = () => {
    onTap && onTap();
  };
  return useMemo(() => (
    <ClickBtn
      className="video-search-item"
      onTap={() => handleDetail()}
    >
      <div className="img-box">
        <div className="img-inner-box">
          <Simg src={item?.thumbImg} />
        </div>
        {!hidePrice ? (
          <div className="img-top-box">
            {item?.coins}
            <div className="icon" />
          </div>
        ) : <></>}
      </div>
      <div className="title">
        {item?.title}
      </div>
      <div className="info">
        <div className="left">
          <div className="avatar-box">
            <Avatar
              src={item?.user?.thumb}
              size=".75"
            />
          </div>
          <div className="text">
            {item?.user?.nickname}
          </div>
        </div>
        <div className="right">
          <div className="icon" />
          {item?.like}
        </div>
      </div>
    </ClickBtn>
  ), [item]);
};

/**
 * 视频热榜-热门点赞/热门购买
 * @param item 当前行信息
 * @param num  序号【1开始，如果没有则不显示左上侧序号标记】
 * @description ......
 */
export const VideoItemHotRank = (props) => {
  const { item, num, onTap } = props;
  const handleDetail = () => {
    onTap && onTap();
  };
  return useMemo(() => (
    <ClickBtn
      className="video-item-hot-rank"
      onTap={() => handleDetail()}
    >
      {num > 0 && num <= 3 ? (
        <div className={`mark-box mark-box${num}`}>
          TOP{num}
        </div>
      ) : <></>}
      <div className="img-box">
        <Simg src={item?.thumbImg} />
      </div>
      <div className="info-box">
        <div className="title">{item?.title}</div>
        <div className="avatar-row">
          <div className="avatar-box">
            <Simg src={item?.user?.thumb} />
          </div>
          <div className="text">
            {item?.user?.nickname}
          </div>
        </div>
        <div className="subtitle">
          <img className="icon" src={iconLikeGray} />
          {item?.like || 0}
        </div>
      </div>
    </ClickBtn>
  ), [item]);
};

/**
 * 合集详情列表行
 * @param item  当前行信息
 * @description 左右分栏：左侧栏为合集封面/底部有播放次数/喜欢数，
 *              右侧栏有名称/钻石数量/时常
 */
export const VideoCollection = (props) => {
  const { item, onTap } = props;
  const handleDetail = () => {
    onTap && onTap();
  };
  return useMemo(() => (
    <ClickBtn
      className="video-item-collection-detail"
      onTap={() => handleDetail()}
    >
      <div className="img-box">
        <Simg src={item?.thumbImg} />
        <div className="img-bottom">
          <div className="img-bottom-item">
            {item?.rating || 0}次播放
          </div>
          <div className="img-bottom-item">
            <img src={iconPlayTime} />
            {item?.like || 0}
          </div>
        </div>
      </div>
      <div className="info-box">
        <div className="title">{item?.title}</div>
        <div className="color-text">
          {item?.coins || 0}钻石
        </div>
        <div className="like-box">
          <div className="icon" />
          {item?.like}
        </div>
      </div>
    </ClickBtn>
  ), [item]);
};

// 视频列表项(只有视频封面)
export const CardVideoOnly = (props) => {
  const { item, onTap } = props;
  const handleDetail = () => {
    onTap && onTap();
  };
  return useMemo(() => (
    <ClickBtn
      className="video-item"
      onTap={() => handleDetail()}
    >
      <div className="img-box">
        <Simg src={item?.thumbImg} />
      </div>
    </ClickBtn>
  ), [item]);
};

// 发现-瀑布流-最新视频
export const CardFindNew = (props) => {
  const { item, onTap } = props;
  const handleDetail = () => {
    onTap && onTap();
  };
  return useMemo(() => (
    <ClickBtn
      className="card-find-new"
      onTap={() => handleDetail()}
    >
      <div className="title">
        {item?.title}
      </div>
      <div className="subtitle">
        {item?.desc}
      </div>
      {item?.imgList?.length ? (
        <div className="img-box">
          <div className="left">
            <div className="inner">
              <Simg src={item?.imgList[0]} />
            </div>
          </div>
          <div className="right">
            <div className="right-top">
              <div className="inner">
                <Simg src={item?.imgList[1]} />
              </div>
            </div>
            <div className="right-bottom">
              <div className="inner">
                <Simg src={item?.imgList[2]} />
              </div>
            </div>
          </div>
        </div>
      ) : <></>}
    </ClickBtn>
  ), [item]);
};
