import React, { useMemo } from "react";
import '../../resources/css/card/card_scroll.less';

import StackStore from "../../store/stack";
import StackPage from "../StackPage";
import ClickBtn from "../ClickBtn";
import Simg from "../Simg";
import Creater from "../Mv/Creater";
import HotVideo from "../Mv/HotVideo";
import EveryDay from "../EveryDay";
import Collection from "../Mv/Collection";
import Tag from "../Mv/Tag";
import Vip from "../Mv/Vip";
import Find from "../Mv/Find";

// 创作达人-头部横向滚动【只有一张3:2的封面图】
export const ScrollItem = (props) => {
  const { item, onTap } = props;
  const handle = () => {
    onTap && onTap();
  };
  return useMemo(() => (
    <ClickBtn
      className="scroll-item"
      onTap={() => handle()}
    >
      <Simg src={
        item?.cover_thumb_url ||
        item?.thumbImg
      } />
    </ClickBtn>
  ), [item]);
};

// 视频首页-排行榜-垂直滚动列表项
export const CardScrollMvRank = (props) => {
  const { item } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const handle = (type) => {
    let tempType = 0;
    switch (type) {
      case "up":
        tempType = 1;
        break;
      case "income":
        tempType = 2;
        break;
      default:
        tempType = 0;
        break;
    }
    const stackKey = `Creater-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "Creater",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <Creater stackKey={stackKey} type={tempType} />
          </StackPage>
        ),
      },
    });
  }
  return useMemo(() => (
    <ClickBtn
      className="card-scroll-mv-rank"
      onTap={() => handle(item?.type)}
    >
      <div className="left">
        <div className="mark" />
        <div className="title">{item?.name}</div>
      </div>
      <div className="right">
        {item?.item?.length ? (
          item?.item?.map((str, index) => (
            <div
              key={`avatar-box-${index}`}
              className="avatar-box"
            >
              <Simg src={str} />
            </div>
          ))
        ) : <></>}
      </div>
    </ClickBtn>
  ), [item]);
};

// 视频播放页-底部-推荐广告
/**
 *
 * @param {*} props
 * @descript {1:热购,2:热播,3:最新,4:专题、合集,5:标签,6:发现,7:内部链接,8:钻石视频播放}
 * @returns
 */
export const CardScrollAdPlayer = (props) => {
  const { item } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const handle = (type) => {
    let tempName = '';
    let tempStackKey = "";
    let tempPage = "";
    if (type === 1) {
      tempName = 'HotVideo';
      tempStackKey = `HotVideo${new Date().getTime()}`;
      tempPage = <HotVideo stackKey={tempStackKey} type={1} />;
    }
    if (type === 2) {
      tempName = 'HotVideo';
      tempStackKey = `HotVideo${new Date().getTime()}`;
      tempPage = <HotVideo stackKey={tempStackKey} />;
    }
    if (type === 3) {
      tempName = 'EveryDay';
      tempStackKey = `EveryDay${new Date().getTime()}`;
      tempPage = <EveryDay stackKey={tempStackKey} />;
    }
    if (type === 4) {
      tempName = 'Collection';
      tempStackKey = `Collection${new Date().getTime()}`;
      tempPage = <Collection stackKey={tempStackKey} />;
    }
    if (type === 5) {
      tempName = 'Tag';
      tempStackKey = `Tag${new Date().getTime()}`;
      tempPage = <Tag stackKey={tempStackKey} />;
    }
    if (type === 6) {
      tempName = 'Find';
      tempStackKey = `Find-${new Date().getTime()}`;
      tempPage = <Find stackKey={tempStackKey} />;
    }
    if (type === 7) {
      if (item?.link) {
        window.open(item?.link, "_blank");
      }
      return;
    }
    if (type === 8) {
      tempName = 'Vip';
      tempStackKey = `Vip${new Date().getTime()}`;
      tempPage = <Vip
        stackKey={tempStackKey}
        title="钻石视频广场"
        isVisible
      />;
    }
    if (!tempName) return;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: tempName,
        element: (
          <StackPage
            stackKey={tempStackKey}
            key={tempStackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            {tempPage}
          </StackPage>
        ),
      },
    });
  };
  return useMemo(() => (
    <div
      className="card-ad-video-player"
      onClick={() => handle(item?.type)}
    >
      <div className="icon">
        <Simg src={item?.icon} size=".75" />
      </div>
      <div className="info">
        {item?.tips}
      </div>
      <div className="icon-right" />
    </div>
  ), [item]);
};
