import React, { useMemo } from "react";
import QRCode from "qrcode.react";
import '../../resources/css/card/card_alert.less';

import StackStore from "../../store/stack";
import StackPage from "../StackPage";
import UserStore from "../../store/user";
import ClickBtn from '../ClickBtn';
import Simg from "../Simg";
import Share from "../User/Share";
import Recharge from "../User/Recharge";
import Emit from "../../libs/eventEmitter";
import { copyText } from '../../libs/utils';

import iconLogo from '../../resources/img/icon_logo.png';
import bgAlertVip from '../../resources/img/bg_alert_vip.png';

/**
 * 分享弹出框
 * @param {String} props.coverImg 封面图
 */
export const AlertShare = (props) => {
  const { title, coverImg } = props;
  const [UserInfo] = UserStore.useGlobalState("user");
  const shareQrcode = UserInfo?.share_url; // 二维码地址
  const shareCopy = UserInfo?.share_text; // 分享链接+文字
  const handleSaveLink = () => {
    copyText(shareCopy);
    Emit.emit("showToast", { text: "复制成功,快去分享吧！", });
  };
  const handleSaveImg = () => {
    Emit.emit("showToast", { text: "请自行截图分享二维码", time: 3000 });
  };
  return useMemo(() => (
    <div className="alert-share">
      <div className="head">
        <img className="logo" src={iconLogo} />
        <div className="text">{title}</div>
      </div>
      <div className="cover-img">
        <Simg src={coverImg} />
      </div>
      <div className="qrcode-box">
        <div className="qrcode">
          {shareQrcode ? (
            <QRCode
              style={{
                height: "100%",
                width: "100%"
              }}
              value={shareQrcode}
            />
          ) : <></>}
        </div>
        <div className="info">
          <div className="title">扫描二维码</div>
          <div className="title">下载APP立即观看</div>
          <div className="subtitle">若二维码无法打开请输入网址</div>
          <div className="btn">{shareQrcode}</div>
        </div>
      </div>
      <div className="bottom">
        <div className="item">
          <ClickBtn
            className="btn"
            onTap={() => handleSaveLink()}
          >
            复制链接分享
          </ClickBtn>
        </div>
        <div className="item">
          <ClickBtn
            className="btn"
            onTap={() => handleSaveImg()}
          >
            保存图片分享
          </ClickBtn>
        </div>
      </div>
    </div>
  ), [title, coverImg, UserInfo]);
};

// 视频详情页-视频播放结束弹框
export const AlertVip = () => {
  const [stacks] = StackStore.useGlobalState("stacks");
  const toShare = () => {
    const stackKey = `Share-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "Share",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <Share stackKey={stackKey} />
          </StackPage>
        ),
      },
    });
  };
  const toVip = () => {
    const stackKey = `Recharge-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "Recharge",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <Recharge stackKey={stackKey} />
          </StackPage>
        ),
      },
    });
  };
  return useMemo(() => (
    <div className="alert-vip-body">
      <img className="alert-vip-bg" src={bgAlertVip} />
      <div className="alert-vip-btn-box">
        <ClickBtn
          className="alert-vip-btn-cancel"
          onTap={() => toVip()}
        >
          开通VIP
        </ClickBtn>
        <ClickBtn
          className="alert-vip-btn-submit"
          onTap={() => toShare()}
        >
          邀请无限看
        </ClickBtn>
      </div>
    </div>
  ), []);
};
