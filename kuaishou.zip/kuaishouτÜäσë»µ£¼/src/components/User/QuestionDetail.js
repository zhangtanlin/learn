import React from "react";

import HeaderBack from "../Header/HeaderBack";
import ScrollArea from "../ScrollArea";
export default (props) => {
  const { stackKey, data } = props;
  return (
    <div className="page-content-flex">
      <HeaderBack
        stackKey={stackKey}
        title="问题详情"
        right={() => (
          <div style={{ width: "1.2rem" }} />
        )}
      />
      <ScrollArea>
        <div className="questionDetail">
          <p>{data.question}</p>
          <p>{data.answer}</p>
        </div>
      </ScrollArea>
    </div>
  );
};
