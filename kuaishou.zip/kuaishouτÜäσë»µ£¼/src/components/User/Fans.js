import React, { useEffect, useMemo, useState } from "react";

import HeaderBack from '../Header/HeaderBack';
import ScrollArea from "../ScrollArea";
import Loading from '../Loading';
import Emit from "../../libs/eventEmitter";
import { NoData } from '../NoData';
import { ListUserFans } from "../List/User";
import {
  apiGetFansList,
  apiGetLikeList,
} from '../../libs/http';

/**
 * 我的粉丝/我的关注
 * @param params.uid {uid: 传uid表示他人的列表，不传表示是自己的列表}
 * @param params.type {0/null: 粉丝列表，关注列表}
 */
export default (props) => {
  const { stackKey, type, uid } = props;
  const [loading, setLoading] = useState(true);
  const [params, setParams] = useState({
    page: 1,
    isAll: false,
  });
  const [data, setData] = useState([]);
  const [loadingMore, setLoadingMore] = useState(true);
  const getData = async () => {
    if (params?.isAll) return;
    setLoadingMore(true);
    try {
      const tempParam = { ...params, uid };
      let res = null;
      switch (type) {
        case 1:
          res = await apiGetLikeList(tempParam);
          break;
        default:
          res = await apiGetFansList(tempParam);
          break;
      }
      if (res?.status) {
        if (params?.page === 1) {
          setData(res?.data);
        } else {
          setData([...data, ...res?.data]);
        }
        if (!res?.data?.length) {
          setParams({ ...params, isAll: true });
        }
      } else {
        Emit.emit("showToast", {
          text: "请求列表失败",
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
      });
    }
    setLoading(false);
    setLoadingMore(false);
  };
  const nextPage = () => {
    if (!params?.isAll) {
      setParams((tempParam) => ({
        ...tempParam,
        page: tempParam?.page + 1
      }));
    }
  };
  useEffect(() => {
    getData();
  }, [params]);
  // 设置头部文本
  const setHeaderTitle = () => {
    if (type === 1) {
      return '关注';
    }
    return '粉丝';
  };
  return useMemo(() => (
    <div className="positioned-container">
      <HeaderBack
        stackKey={stackKey}
        title={setHeaderTitle()}
      />
      {loading ? (
        <Loading show overSize={false} />
      ) : (
        data?.length ? (
          <ScrollArea
            loadingMore={loadingMore}
            onScrollEnd={nextPage}
          >
            <div className="public-padding">
              <ListUserFans list={data} />
            </div>
          </ScrollArea>
        ) : (<NoData />)
      )}
    </div>
  ), [loading, data, loadingMore]);
};
