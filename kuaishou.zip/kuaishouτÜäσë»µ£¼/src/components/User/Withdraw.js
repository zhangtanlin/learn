import React, { useMemo, useState, useEffect } from "react";

import ScrollArea from "../ScrollArea";
import StackPage from "../StackPage";
import StackStore from "../../store/stack";
import UserStore from '../../store/user';
import AccountStore from '../../store/withdrawAccount';
import HeaderBack from '../Header/HeaderBack';
import ClickBtn from '../ClickBtn';
import WithdrawList from './WithdrawList';
import AccountList from './AccountList';
// eslint-disable-next-line import/no-self-import
import Withdraw from './Withdraw';
import Emit from "../../libs/eventEmitter";
import Const from "../../libs/const";
import {
  apiGetUserInfo,
  apiProxyUserMoney,
  apiProxyWithdraw,
} from "../../libs/http";

import iconRightGrey from '../../resources/img/icon_right_grey.png';

/**
 * 提现
 * @param type 类型{1: 妹币, 2: 代理, 3: mv收益}}
 */
export default (props) => {
  const { stackKey, type } = props;
  const [accountInfo] = AccountStore.useGlobalState("accountInfo");
  const [stacks] = StackStore.useGlobalState("stacks");
  const [info, setInfo] = useState({});
  // 提现金额
  const [params, setParams] = useState({
    number: '',
  });
  // 获取提现金币
  const initInfo = async () => {
    try {
      const res = await apiProxyUserMoney();
      if (res?.status) {
        if (res?.data?.withdraw_rules) {
          res.data.withdraw_rules = res?.data?.withdraw_rules?.split('#') || [];
        }
        setInfo(res?.data || {});
      } else {
        Emit.emit("showToast", {
          text: "请求信息失败",
          time: 3000
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
        time: 3000
      });
    }
  };
  // 用户信息
  const initUserInfo = async () => {
    try {
      const res = await apiGetUserInfo();
      if (res?.status) {
        const tempUserData = {
          ...res?.data || {},
        }; // 字段说明参考userStore
        UserStore.dispatch({
          type: "replace",
          payload: tempUserData,
        });
      } else {
        Emit.emit("showToast", {
          text: res?.msg || '更新用户信息失败',
          time: 3000
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: '请求失败',
        time: 3000
      });
    }
  };
  // 刷新当前页面
  const reload = () => {
    const stackKey = `user-withdraw-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "replace",
      payload: {
        name: "user-withdraw",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 1 }}
          >
            <Withdraw stackKey={stackKey} />
          </StackPage>
        ),
      },
    });
  };
  // 提现
  const handleWithdraw = async () => {
    try {
      if (Number(params?.number) <= 0) {
        Emit.emit("showToast", {
          text: "请输入提现金额",
          time: 3000
        });
        return;
      }
      if (!accountInfo?.account) {
        Emit.emit("showToast", {
          text: "请选择提现账户",
          time: 3000
        });
        return;
      }
      const tempParams = {
        withdraw_account: accountInfo.account, // 卡号
        withdraw_name: accountInfo.name, // 持卡人姓名
        withdraw_amount: params.number, // 金额
        withdraw_type: 1, // 类型{1: 银行卡}不传表示银行卡
        withdraw_from: type || 2 // 收益类型{1: 币, 2: 代理, 3: mv收益}
      };
      const res = await apiProxyWithdraw(tempParams);
      if (res?.status) {
        Emit.emit("showToast", {
          text: "提现成功",
          time: 3000
        });
        initUserInfo();
        reload();
      } else {
        Emit.emit("showToast", {
          text: res?.msg || '提现失败',
          time: 3000
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
        time: 3000
      });
    }
  };

  useEffect(() => {
    initInfo();
  }, []);
  // 提现记录
  const handleWithdrawList = () => {
    const stackKey = `WithdrawList-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "WithdrawList",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <WithdrawList stackKey={stackKey} />
          </StackPage>
        )
      }
    });
  };

  // 选择账号
  const handleAccount = () => {
    const stackKey = `SelectAcount-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "SelectAcount",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <AccountList stackKey={stackKey} />
          </StackPage>
        )
      }
    });
  };
  return useMemo(() => (
    <div className="positioned-container">
      <HeaderBack
        stackKey={stackKey}
        title={Const.titleWithdraw}
        right={() => (
          <ClickBtn
            className="back-header-btn"
            onTap={handleWithdrawList}
          >
            提现<br />
            记录
          </ClickBtn>
        )}
      />
      <ScrollArea>
        <div className="public-padding">
          <div className="user-withdraw-header">
            <div className="title">{info?.money || 0}</div>
            <div className="subtitle">妹币余额(1妹币=1元)</div>
          </div>
          <div className="user-withdraw-title">余额提现</div>
          <div className="user-withdraw-input">
            <input
              type="number"
              placeholder="输入大于100的整数,单笔最高1万元"
              onInput={({ target }) => {
                const tempReplace = target.value.replace(/[^\d]/g, '');
                if (Number(tempReplace) > info?.money) {
                  const strTemp = tempReplace.substr(
                    0,
                    String(tempReplace).length - 1
                  );
                  target.value = Number(strTemp);
                  setParams({
                    ...params,
                    ...{ number: Number(strTemp) },
                  });
                  Emit.emit("showToast", {
                    text: "当前输入大于可提现金额",
                    time: 3000
                  });
                } else {
                  target.value = Number(tempReplace);
                  setParams({
                    ...params,
                    ...{ number: Number(tempReplace) },
                  });
                }
              }}
            />
          </div>
          <ClickBtn
            className="account-box"
            onTap={handleAccount}
          >
            {accountInfo?.account || '请选择提现账户'}
            <img src={iconRightGrey} />
          </ClickBtn>
          {info?.withdraw_rules?.length ? (
            <div className="user-withdraw-rule">
              <div className="user-withdraw-prompt">
                提现规则
              </div>
              {info?.withdraw_rules?.map((item, index) => (
                <div
                  key={`user-withdraw-prompt-${index}}`}
                  className="user-withdraw-prompt"
                >{item}</div>
              ))}
            </div>
          ) : <></>}
          <ClickBtn
            className="user-public-btn"
            onTap={() => handleWithdraw()}
          >
            确认提现
          </ClickBtn>
        </div>
      </ScrollArea>
    </div>
  ), [info, accountInfo, params,]);
};
