import React, { useEffect, useMemo, useState } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import SwiperCore, { Controller } from "swiper";
import "swiper/swiper.min.css";

import StackStore from "../../store/stack";
import StackPage from "../StackPage";
import HeaderBack from "../Header/HeaderBack";
import Simg from "../Simg";
import ScrollArea from "../ScrollArea";
import Loading from '../Loading';
import ClickBtn from "../ClickBtn";
import Emit from "../../libs/eventEmitter";
import Set from "./Set";
import Fans from "./Fans";
import { TabsTwo } from '../Tab';
import { NoData } from '../NoData';
import { ListVideoInfo } from "../List/Video";
import {
  apiGetUserInfo,
  apiGetUserHome,
  apiMyVideoList,
  apiMyVideoLikeList,
  apiSetFollowing,
} from '../../libs/http';

import iconVip from "../../resources/img/icon_vip.png";
import iconVipGray from "../../resources/img/icon_vip_gray.png";
import iconDiamond from "../../resources/img/icon_diamond.png";

SwiperCore.use([Controller]);

/**
 * 用户信息
 * @param {number} params.uid 有uid表示是他人主页，没有uid表示是自己的主页
 */
export default props => {
  const { stackKey, uid } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const [isLoading, setIsLoading] = useState(true);
  const [data, setData] = useState({});
  let attentionBtnClick = true; // 关注按钮是否被点击
  const [isAttention, setIsAttention] = useState(false); // 是否关注
  const statisticsList = [{
    name: '粉丝',
    num: data?.fans_count || 0,
    onTap: () => {
      const stackKey = `Fans-${new Date().getTime()}`;
      StackStore.dispatch({
        type: "push",
        payload: {
          name: "Fans",
          element: (
            <StackPage
              stackKey={stackKey}
              key={stackKey}
              style={{ zIndex: stacks.length + 2 }}
            >
              <Fans stackKey={stackKey} uid={uid} />
            </StackPage>
          ),
        },
      });
    }
  }, {
    name: '关注',
    num: data?.likes_count || 0,
    onTap: () => {
      const stackKey = `Fans-${new Date().getTime()}`;
      StackStore.dispatch({
        type: "push",
        payload: {
          name: "Fans",
          element: (
            <StackPage
              stackKey={stackKey}
              key={stackKey}
              style={{ zIndex: stacks.length + 2 }}
            >
              <Fans stackKey={stackKey} type={1} uid={uid} />
            </StackPage>
          ),
        },
      });
    }
  }, {
    name: '妹币',
    num: data?.coins || 0,
    onTap: () => {}
  }];
  const getData = async () => {
    try {
      let res = null;
      let tempInfo = {};
      if (uid) {
        const tempParams = {
          to_uid: uid,
        };
        res = await apiGetUserHome(tempParams); // 别人的
        tempInfo = res?.data;
      } else {
        res = await apiGetUserInfo(); // 自己的
        tempInfo = res?.data;
      }
      if (res?.status) {
        setData(tempInfo);
        setIsAttention(tempInfo?.is_attention || 0);
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
        time: 3000
      });
    }
    setIsLoading(false);
  };
  useEffect(() => {
    getData();
  }, []);
  // 关注
  const handleLike = async (uid) => {
    if (!attentionBtnClick || !uid) return;
    try {
      attentionBtnClick = false;
      const tempParams = {
        to_uid: uid,
      };
      const res = await apiSetFollowing(tempParams);
      if (res?.status) {
        setIsAttention(isAttention === 1 ? 0 : 1);
        Emit.emit("showToast", {
          text: res?.data?.msg || "操作成功",
          time: 3000
        });
      } else {
        Emit.emit("showToast", {
          text: res?.data?.msg || "操作失败",
          time: 3000
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
        time: 3000
      });
    }
    attentionBtnClick = true;
  };
  // 设置头部文本
  const setHeaderTitle = () => {
    if (uid) {
      return data?.nickname || '';
    }
    return '进入主页更精彩';
  };
  // 设置操作按钮
  const setActiveBtn = () => {
    if (uid) {
      return (
        <div className="active-box">
          <ClickBtn
            className={`btn bg-red-linear ${isAttention ? 'active' : ''}`}
            onTap={() => handleLike(data?.uid)}
          >
            {isAttention ? '已关注' : '关注'}
          </ClickBtn>
        </div>
      );
    }
    return (
      <div className="active-box">
        <ClickBtn
          className="btn bg-white"
          onTap={() => {
            const stackKey = `SystemNotice-${new Date().getTime()}`;
            StackStore.dispatch({
              type: "push",
              payload: {
                name: "SystemNotice",
                element: (
                  <StackPage
                    stackKey={stackKey}
                    key={stackKey}
                    style={{ zIndex: stacks.length + 2 }}
                  >
                    <Set stackKey={stackKey} />
                  </StackPage>
                ),
              },
            });
          }}
        >
          编辑资料
        </ClickBtn>
      </div>
    );
  };

  return useMemo(() => (
    isLoading ? (
      <Loading show overSize={false} />
    ) : (
      <div className="positioned-container">
        <HeaderBack
          stackKey={stackKey}
          title={setHeaderTitle()}
        />
        <ScrollArea data={statisticsList}>
          <div className="public-padding">
            <div className="user-manage-head">
              <div className="avatar-box">
                <Simg src={data?.thumb} />
              </div>
              <div className="info-box">
                <div className="statistics-box">
                  {statisticsList?.length ? (
                    statisticsList.map((item, index) => (
                      <ClickBtn
                        key={`statistics-list-${index}`}
                        className="item"
                        onTap={item?.onTap}
                      >
                        <div className="title">
                          {item.num}
                        </div>
                        <div className="subtitle">
                          {item.name}
                        </div>
                      </ClickBtn>
                    ))
                  ) : <></>}
                </div>
                {setActiveBtn()}
              </div>
            </div>
            <div className="user-subtitle-box">
              <span className="user-id-box">
                {data?.uid}
              </span>
              <div className="user-vip-box">
                <img
                  src={data?.isVV ? iconVip : iconVipGray}
                />
              </div>
              <div className="user-diamonds-box">
                <img src={iconDiamond} />
                <span>{data?.vvLevel || 0}</span>
              </div>
            </div>
            <div className="user-manage-descript">
              简介：{data?.person_signnatrue || '手撸软了，啥都没留下~'}
            </div>
            <SetListByType uid={uid} />
          </div>
        </ScrollArea>
      </div>
    )
  ), [
    isLoading,
    uid,
    data,
    isAttention,
    data,
  ]);
};

// 根据类型的不同加载(自己的视频/点赞)或者(别人的视频)
const SetListByType = (props) => {
  const { uid } = props;
  const [currentTab, setCurrentTab] = useState(0);
  const [controlledSwiper, setControlledSwiper] = useState(null);
  const navList = [
    { id: 1, name: '视频', },
    { id: 2, name: '点赞', }
  ];
  if (uid) {
    return <VideoList uid={uid} />;
  }
  return (
    <>
      <TabsTwo
        navs={navList}
        currentIndex={currentTab}
        onChange={(index) => {
          setCurrentTab(index);
          controlledSwiper && controlledSwiper.slideTo(index);
        }}
      />
      <Swiper
        className="default-swiper"
        initialSlide={0}
        controller={{ control: controlledSwiper }}
        onSwiper={setControlledSwiper}
        onSlideChange={(e) => {
          setCurrentTab(e.realIndex);
        }}
      >
        {navList.map((item, index) => (
          <SwiperSlide key={`swiper-slide-${index}-${item.id}`}>
            <SwiperList type={index} />
          </SwiperSlide>
        ))}
      </Swiper>
    </>
  );
};

/**
 * 视频/点赞列表
 * @param {number} props.type 类型{0: 视频,1: 合集}
 * @param {number} props.uid  用户uid【查询视频传uuid,查询合集使用uid】
 */
const SwiperList = (props) => {
  const { type, uid } = props;
  const [loading, setLoading] = useState(true);
  const [params, setParams] = useState({
    page: 1,
    isAll: false,
    type: 'like', // 点赞视频
  });
  const [loadingMore, setLoadingMore] = useState(true);
  const [data, setData] = useState([]);
  const getData = async () => {
    if (params?.isAll) {
      return;
    }
    setLoadingMore(true);
    try {
      const tempParam = { ...params, uid };
      let res = null;
      let tempList = [];
      switch (type) {
        case 1:
          res = await apiMyVideoLikeList(tempParam); // 点赞列表
          tempList = res?.data?.list || [];
          break;
        default:
          res = await apiMyVideoList(tempParam); // 视频列表
          tempList = res?.data || [];
          break;
      }
      if (res?.status) {
        if (params?.page === 1) {
          setData(tempList);
        } else {
          setData([...data, ...tempList]);
        }
        if (!tempList || tempList?.length <= 0) {
          setParams({ ...params, isAll: true });
        }
      } else {
        Emit.emit("showToast", {
          text: "请求列表失败",
          time: 3000
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
        time: 3000
      });
    }
    setLoading(false);
    setLoadingMore(false);
  };
  const nextPage = () => {
    if (!params?.isAll) {
      setParams((tempParam) => ({
        ...tempParam,
        page: tempParam?.page + 1
      }));
    }
  };
  useEffect(() => {
    getData();
  }, [params]);
  return useMemo(() => (
    loading ? (
      <Loading show overSize={false} />
    ) : (
      data?.length > 0 ? (
        <ScrollArea
          ListData={data?.length}
          loadingMore={loadingMore}
          onScrollEnd={nextPage}
        >
          <ListVideoInfo list={data} />
        </ScrollArea>
      ) : <NoData />
    )
  ), [loading, data, loadingMore]);
};

// 视频列表[别人的视频所以需要uid]
const VideoList = (props) => {
  const { uid } = props;
  const [loading, setLoading] = useState(true);
  const [params, setParams] = useState({
    page: 1,
    isAll: false,
  });
  const [loadingMore, setLoadingMore] = useState(true);
  const [data, setData] = useState([]);
  const getData = async () => {
    if (params?.isAll) {
      return;
    }
    setLoadingMore(true);
    try {
      const tempParam = { ...params, uid };
      const res = await apiMyVideoList(tempParam);
      const tempList = res?.data || [];
      if (res?.status) {
        if (params?.page === 1) {
          setData(tempList);
        } else {
          setData([...data, ...tempList]);
        }
        if (!tempList || tempList?.length <= 0) {
          setParams({ ...params, isAll: true });
        }
      } else {
        Emit.emit("showToast", {
          text: "请求列表失败",
          time: 3000
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
        time: 3000
      });
    }
    setLoading(false);
    setLoadingMore(false);
  };
  const nextPage = () => {
    if (!params?.isAll) {
      setParams((tempParam) => ({
        ...tempParam,
        page: tempParam?.page + 1
      }));
    }
  };
  useEffect(() => {
    getData();
  }, [params]);
  return useMemo(() => (
    loading ? (
      <Loading show overSize={false} />
    ) : (
      data?.length > 0 ? (
        <ScrollArea
          ListData={data?.length}
          loadingMore={loadingMore}
          onScrollEnd={nextPage}
        >
          <ListVideoInfo list={data} />
        </ScrollArea>
      ) : <NoData />
    )
  ), [loading, data, loadingMore]);
};
