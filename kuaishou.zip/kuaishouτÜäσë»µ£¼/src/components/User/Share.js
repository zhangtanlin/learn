import React from "react";
import QRCode from "qrcode.react";

import StackPage from "../StackPage";
import StackStore from "../../store/stack";
import UserStore from "../../store/user";
import ScrollArea from "../ScrollArea";
import HeaderBack from '../Header/HeaderBack';
import ClickBtn from '../ClickBtn';
import ShareList from './ShareList';
import Emit from "../../libs/eventEmitter";
import Const from "../../libs/const";
import { copyText } from '../../libs/utils';

// 分享
export default (props) => {
  const { stackKey } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const [user] = UserStore.useGlobalState("user");

  const shareQrcode = user?.url;
  const shareCode = user?.aff;
  const shareCopy = user?.share_url;

  const handleInvite = () => {
    const stackKey = `ShareList-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "ShareList",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <ShareList stackKey={stackKey} />
          </StackPage>
        )
      }
    });
  };
  const handleSaveLink = () => {
    copyText(shareCopy);
    Emit.emit("showToast", { text: "复制成功,快去分享吧！", });
  };
  const handleSaveImg = () => {
    Emit.emit("showToast", { text: "请自行截图分享二维码", time: 3000 });
  };

  return (
    <div className="positioned-container">
      <HeaderBack
        stackKey={stackKey}
        title={Const.titleShare}
        right={() => (
          <ClickBtn
            className="back-header-btn"
            onTap={() => handleInvite()}
          >
            邀请<br />
            记录
          </ClickBtn>
        )}
      />
      <ScrollArea>
        <div className="my-share">
          <div className="content">
            <div className="qrcode-box">
              {shareQrcode ? (
                <QRCode
                  level="H"
                  style={{
                    height: "100%",
                    width: "100%"
                  }}
                  value={shareQrcode}
                />
              ) : <></>}
            </div>
            <div className="title">
              我的邀请码：{shareCode}
            </div>
            <div className="btn-box">
              <ClickBtn
                className="user-share-btn"
                onTap={() => handleSaveLink()}
              >
                复制链接分享
              </ClickBtn>
              <ClickBtn
                className="user-share-btn"
                onTap={() => handleSaveImg()}
              >
                保存图片分享
              </ClickBtn>
            </div>
          </div>
          <div className="share-bottom" />
        </div>
      </ScrollArea>
    </div>
  );
};
