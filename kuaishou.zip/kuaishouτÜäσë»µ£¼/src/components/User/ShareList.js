import React, { useEffect, useMemo, useState } from "react";

import ScrollArea from "../ScrollArea";
import HeaderBack from '../Header/HeaderBack';
import Loading from '../Loading';
import Emit from "../../libs/eventEmitter";
import Const from "../../libs/const";
import { ListTable } from '../List/Table';
import { NoData } from '../NoData';
import { apiGetInviteList } from '../../libs/http';

// 推广记录
export default (props) => {
  const { stackKey } = props;
  const [loading, setLoading] = useState(true);
  const [params, setParams] = useState({
    page: 1,
    isAll: false,
  });
  const [data, setData] = useState([]);
  const [loadingMore, setLoadingMore] = useState(true);
  const headerList = [
    { name: '昵称', value: 'nickname', },
    { name: '是否是vip', value: 'isVV' },
    { name: '加入时间', value: 'regdate_str' },
  ];
  const getData = async () => {
    if (params?.isAll) {
      return;
    }
    setLoadingMore(true);
    try {
      const tempParam = { ...params };
      const res = await apiGetInviteList(tempParam);
      if (res?.status) {
        const tempData = res?.data || [];
        if (tempData?.length) {
          tempData?.map((item) => {
            item.isVV = item?.isVV ? '是' : '不是';
            return item;
          });
        }
        if (params?.page === 1) {
          setData(tempData);
        } else {
          setData([...data, ...tempData]);
        }
        if (!tempData?.length) {
          setParams({ ...params, isAll: true });
        }
      } else {
        Emit.emit("showToast", {
          text: "请求列表失败",
          time: 3000
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
        time: 3000
      });
    }
    setLoading(false);
    setLoadingMore(false);
  };
  // 加载更多
  const nextPage = () => {
    if (!params?.isAll) {
      setParams((tempParam) => ({
        ...tempParam,
        page: tempParam?.page + 1
      }));
    }
  };
  useEffect(() => {
    getData();
  }, [params]);

  return useMemo(() => (
    <div className="positioned-container user-public-bg">
      <HeaderBack
        stackKey={stackKey}
        title={Const.titleShareList}
      />
      <ListTable
        isHeader
        headerList={headerList}
        list={[]}
      />
      {loading ? (
        <Loading show overSize={false} />
      ) : (
        <ScrollArea
          ListData={data?.length}
          loadingMore={loadingMore}
          onScrollEnd={nextPage}
        >
          {data?.length ? (
            <ListTable
              headerList={headerList}
              list={data}
            />
          ) : <NoData />}
        </ScrollArea>
      )}
    </div>
  ), [loading, data, loadingMore]);
};
