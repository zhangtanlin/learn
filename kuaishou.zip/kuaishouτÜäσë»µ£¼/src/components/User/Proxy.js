import React, { useEffect, useMemo, useState } from "react";

import StackPage from "../StackPage";
import StackStore from "../../store/stack";
import HeaderBack from '../Header/HeaderBack';
import UserStore from "../../store/user";
import Loading from '../Loading';
import Withdraw from './Withdraw';
import ScrollArea from "../ScrollArea";
import ClickBtn from "../ClickBtn";
import Emit from "../../libs/eventEmitter";
import Login from "../Login";
import Const from "../../libs/const";
import ProxyDetail from "./ProxyDetail";
import { apiProxyIndex } from '../../libs/http';

// 代理
export default (props) => {
  const { stackKey } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const [user] = UserStore.useGlobalState("user");
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState({});
  const getData = async () => {
    try {
      const res = await apiProxyIndex();
      if (res?.status) {
        setData(res?.data);
      } else {
        Emit.emit("showToast", {
          text: "请求列表失败",
          time: 3000
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
        time: 3000
      });
    }
    setLoading(false);
  };
  useEffect(() => {
    getData();
  }, []);
  const handleDetail = () => {
    let tempName = 'Login';
    let tempStackKey = `Login-${new Date().getTime()}`;
    let tempPage = <Login stackKey={tempStackKey} />;
    if (user?.is_reg) {
      tempName = 'ProxyDetail';
      tempStackKey = `ProxyDetail-${new Date().getTime()}`;
      tempPage = <ProxyDetail stackKey={tempStackKey} />;
    }
    StackStore.dispatch({
      type: "push",
      payload: {
        name: tempName,
        element: (
          <StackPage
            stackKey={tempStackKey}
            key={tempStackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            {tempPage}
          </StackPage>
        ),
      },
    });
  };
  // 代理提现
  const handleWithdraw = () => {
    let tempName = 'Login';
    let tempStackKey = `Login-${new Date().getTime()}`;
    let tempPage = <Login stackKey={tempStackKey} />;
    if (user?.is_reg) {
      tempName = 'Withdraw';
      tempStackKey = `Withdraw-${new Date().getTime()}`;
      tempPage = <Withdraw stackKey={tempStackKey} type={2} />;
    }
    StackStore.dispatch({
      type: "push",
      payload: {
        name: tempName,
        element: (
          <StackPage
            stackKey={tempStackKey}
            key={tempStackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            {tempPage}
          </StackPage>
        ),
      },
    });
  };
  return useMemo(() => (
    <div className="positioned-container">
      <HeaderBack
        stackKey={stackKey}
        title={Const.proxy}
      />
      {loading ? (
        <Loading show overSize={false} />
      ) : (
        <ScrollArea>
          <div className="public-padding">
            <div className="user-proxy-header">
              <div className="user-proxy-row white">
                <div className="item">
                  <div className="title">总业绩</div>
                  <div className="subtitle">
                    {data?.proxy_total || 0.00}
                  </div>
                </div>
                <div className="item">
                  <div className="title">总收益</div>
                  <div className="subtitle">
                    {data?.proxy_total_amount || 0.00}
                  </div>
                </div>
              </div>
              <ClickBtn
                className="user-proxy-btn"
                onTap={handleWithdraw}
              >
                提现
              </ClickBtn>
            </div>
            <div className="user-proxy-box">
              <div className="user-proxy-row">
                <div className="item">
                  <div className="title">当月收益(元)</div>
                  <div className="subtitle">
                    {data?.proxy_total_amount || 0.00}
                  </div>
                </div>
                <div className="item">
                  <div className="title">当月业绩</div>
                  <div className="subtitle">
                    {data?.month_proxy_total || 0.00}
                  </div>
                </div>
                <div className="item">
                  <div className="title">当月推广人数</div>
                  <div className="subtitle">
                    {data?.invite_num || 0}
                  </div>
                </div>
              </div>
            </div>
            <div className="user-proxy-title">推广人数统计</div>
            <div className="user-proxy-box">
              <div className="user-proxy-row">
                <div className="item">
                  <div className="subtitle">
                    {data?.proxy_data?.level_1 || 0}
                  </div>
                  <div className="title">一级推广</div>
                </div>
                <div className="item">
                  <div className="subtitle">
                    {data?.proxy_data?.level_2 || 0}
                  </div>
                  <div className="title">二级推广</div>
                </div>
                <div className="item">
                  <div className="subtitle">
                    {data?.proxy_data?.level_3 || 0}
                  </div>
                  <div className="title">三级推广</div>
                </div>
                <div className="item">
                  <div className="subtitle">
                    {data?.proxy_data?.level_4 || 0}
                  </div>
                  <div className="title">四级推广</div>
                </div>
              </div>
            </div>
            <ClickBtn
              className="user-public-btn red"
              onTap={handleDetail}
            >
              查看明细
            </ClickBtn>
          </div>
        </ScrollArea>
      )}
    </div>
  ), [loading, data]);
};
