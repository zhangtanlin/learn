import React, { useEffect, useMemo, useState } from "react";

import UserStore from "../../store/user";
import StackStore from "../../store/stack";
import StackPage from "../StackPage";
import ScrollArea from "../ScrollArea";
import HeaderBack from '../Header/HeaderBack';
import ClickBtn from '../ClickBtn';
import Loading from '../Loading';
import Simg from "../Simg";
import Login from "../login";
import RechargeList from "./RechargList";
import Emit from "../../libs/eventEmitter";
import Const from "../../libs/const";
import { NoData } from '../NoData';
import { SetPayWay } from './DiamondRecharge';
import { apiGetProductList } from '../../libs/http';

import iconAlipay from '../../resources/img/icon_alipay.png';
import iconWechat from '../../resources/img/icon_wechat.png';
import iconUnionPay from '../../resources/img/icon_unionPay.png';
import iconVisa from '../../resources/img/icon_visa.png';
import iconDigital from '../../resources/img/icon_digital.png';

import iconVipMonth from '../../resources/img/icon_vip_month.png';
import iconVipSeason from '../../resources/img/icon_vip_season.png';
import iconVipYear from '../../resources/img/icon_vip_year.png';
import iconVipForever from '../../resources/img/icon_vip_forever.png';

import bgDesc1 from "../../resources/img/bg_recharge_desc_1.jpg";
import bgDesc2 from "../../resources/img/bg_recharge_desc_2.jpg";
import bgDesc3 from "../../resources/img/bg_recharge_desc_3.jpg";
import bgDesc4 from "../../resources/img/bg_recharge_desc_4.jpg";

export default (props) => {
  const { stackKey } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const [userInfo] = UserStore.useGlobalState("user");
  const [loading, setLoading] = useState(true);
  const [list, setList] = useState([]);
  const [showLayer, setShowLayer] = useState(false);
  const [payWayList, setPayWayList] = useState([]);
  const [descList, setDescList] = useState([
    { name: '无限观看', icon: bgDesc1, },
    { name: '钻石福利', icon: bgDesc2, },
    { name: '专属铭牌', icon: bgDesc3, },
    { name: '钻石视频折扣', icon: bgDesc4, },
  ]);
  const getList = async () => {
    try {
      const tempParams = { type: 1 };
      const res = await apiGetProductList(tempParams);
      if (res?.status && res?.data?.list?.online?.length) {
        res?.data?.list?.online?.map(item => {
          const product_id = item?.id; // 产品id
          const product_name = item?.pname; // 产品名称
          const product_price = item?.p; // 新价格
          const product_price_old = item?.op; //老价格
          const product_price_type = item?.pt; // 类型
          if (item?.pw?.length) {
            item.pMethods = item?.pw?.map(item => {
              let pay_way_name = '';
              let pay_way_icon = '';
              let pw = '';
              switch (item) {
                case 'pa':
                  pay_way_name = '支付宝';
                  pay_way_icon = iconAlipay;
                  pw = item;
                  break;
                case 'pw':
                  pay_way_name = '微信';
                  pay_way_icon = iconWechat;
                  pw = item;
                  break;
                case 'ph':
                  pay_way_name = '花呗';
                  pay_way_icon = iconAlipay;
                  pw = item;
                  break;
                case 'pb':
                  pay_way_name = '银行卡';
                  pay_way_icon = iconUnionPay;
                  pw = item;
                  break;
                case 'pv':
                  pay_way_name = 'visa';
                  pay_way_icon = iconVisa;
                  pw = item;
                  break;
                case 'ps':
                  pay_way_name = '数字人民币';
                  pay_way_icon = iconDigital;
                  pw = item;
                  break;
                default:
                  pay_way_name = '';
                  pay_way_icon = '';
                  pw = '';
                  break;
              }
              const tempObj = {
                product_id,
                product_name,
                product_price,
                product_price_old,
                product_price_type,
                pay_way_name,
                pay_way_icon,
                pw,
              };
              return tempObj;
            });
          }
          return item;
        });
        setList(res?.data?.list?.online);
      } else {
        Emit.emit("showToast", {
          text: '获取产品列表失败'
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
        time: 3000
      });
    }
    setLoading(false);
  };
  useEffect(() => {
    if (!userInfo?.is_reg) {
      Emit.emit("changeAlter", {
        title: "温馨提示",
        content: (
          <div style={{ margin: '0 .4rem' }}>
            请先注册登录后再充值，避免因账号丢失，导致会员或钻石无法找回
          </div>
        ),
        submitText: "确认",
        submit: async () => { },
      });
    }
    getList();
  }, []);
  // 充值记录
  const handleRechargeList = () => {
    let tempName = 'Login';
    let tempStackKey = `Login-${new Date().getTime()}`;
    let tempPage = <Login stackKey={tempStackKey} />;
    if (userInfo?.is_reg) {
      tempName = 'RechargeList';
      tempStackKey = `RechargeList-${new Date().getTime()}`;
      tempPage = <RechargeList stackKey={tempStackKey} />;
    }
    StackStore.dispatch({
      type: "push",
      payload: {
        name: tempName,
        element: (
          <StackPage
            stackKey={tempStackKey}
            key={tempStackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            {tempPage}
          </StackPage>
        ),
      },
    });
  };
  // 选择产品
  const handleChooseProduct = (product) => {
    setPayWayList(product?.pMethods);
    setShowLayer(true);
  };
  // vip等级块
  const setVipLevelText = () => {
    let text = "";
    let icon = "";
    switch (userInfo?.vvLevel) {
      case 1:
        text = '月卡会员';
        icon = iconVipMonth;
        break;
      case 2:
        text = '季卡会员';
        icon = iconVipSeason;
        break;
      case 3:
        text = '年卡会员';
        icon = iconVipYear;
        break;
      case 4:
        text = '永久会员';
        icon = iconVipForever;
        break;
      default:
        text = '您还不是会员';
        icon = '';
        break;
    }
    return (icon ? (
      <img src={icon} />
    ) : (
      <div className="subtitle">{text}</div>
    ));
  };
  return useMemo(() => (
    <div className="positioned-container">
      <HeaderBack
        stackKey={stackKey}
        title={Const.titleVip}
        leftIconIsLight
        right={() => (
          <ClickBtn
            className="back-header-btn white"
            onTap={() => handleRechargeList()}
          >
            充值<br />
            记录
          </ClickBtn>
        )}
        style={{ background: '#1d0b37' }}
      />
      {loading ? (
        <Loading show overSize={false} />
      ) : (list?.length > 0 ? (
        <ScrollArea>
          <div className="user-recharge-content">
            <div className="user-recharge-top">
              <div className="user-recharge-top-box">
                <div className="avatar-box">
                  <Simg src={userInfo?.thumb} />
                </div>
                <div className="info-box">
                  <div className="title">{userInfo?.nickname}</div>
                  {setVipLevelText()}
                </div>
              </div>
            </div>
            {descList?.length ? (
              <div className="user-recharge-row">
                {descList?.map((item, index) => (
                  <div
                    key={`user-recharge-item-${index}`}
                    className="item"
                  >
                    <div className="img-box">
                      <img src={item?.icon} />
                    </div>
                    <div className="text">
                      {item?.name}
                    </div>
                  </div>
                ))}
              </div>
            ) : <></>}
            <div className="user-recharge-list">
              <div className="title">在线充值</div>
              {list?.length ? (
                list.map((item, index) => (
                  <ClickBtn
                    key={`user-recharge-item-${index}`}
                    className="user-recharge-item"
                    onTap={() => handleChooseProduct(item)}
                  >
                    <Simg src={item?.img} />
                  </ClickBtn>
                ))
              ) : <NoData />}
            </div>
          </div>
        </ScrollArea>
      ) : (
        <NoData />
      ))}
      <SetPayWay
        list={payWayList}
        show={showLayer}
        onChange={setShowLayer}
      />
    </div>
  ), [loading, list, showLayer, payWayList, descList]);
};
