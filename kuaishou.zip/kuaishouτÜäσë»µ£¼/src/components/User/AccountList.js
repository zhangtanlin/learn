import React, { useEffect, useState, useMemo, useRef } from 'react';

import AccountStore from "../../store/withdrawAccount";
import BackHead from '../Header/HeaderBack';
import ClickBtn from '../ClickBtn';
import Loading from '../Loading';
import Emit from '../../libs/eventEmitter';
import ScrollArea from '../ScrollArea';
import { NoData } from '../NoData';
import { apiAddAccount, apiDelAccount, apiGetAccount } from '../../libs/http';

import iconDel from '../../resources/img/icon_del.png';
import iconBank from '../../resources/img/icon_bank.png';

export default props => {
  const { stackKey } = props;
  const [loading, setLoading] = useState(true);
  const [accountList, setAccountList] = useState([]);
  const [accountInfo] = AccountStore.useGlobalState("accountInfo");
  const bankNameRef = useRef(""); // 银行名称
  const bankNumberRef = useRef(""); // 银行卡号
  const nameRef = useRef(""); // 持卡人
  const getList = async () => {
    try {
      const res = await apiGetAccount();
      if (res?.status) {
        setAccountList(res?.data);
      } else {
        Emit.emit("showToast", {
          text: "请求列表失败",
          time: 3000
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
        time: 3000
      });
    }
    setLoading(false);
  };
  useEffect(() => {
    getList();
  }, []);
  // 选中提现账号
  const handleChoose = (item) => {
    AccountStore.dispatch({
      type: "replace",
      payload: item,
    });
    Emit.emit(stackKey, stackKey);
  };
  // 添加
  const handleAdd = () => {
    Emit.emit("changeAlter", {
      title: "添加提现账户",
      content: (
        <div className="withdraw-alert-content">
          <div className="user-input-box">
            <input
              type="text"
              placeholder="请输入银行名称"
              onChange={({ target }) => {
                const tempReplace = target.value.replace(/^\s+|\s+$/g, "");
                target.value = tempReplace;
                bankNameRef.current = tempReplace;
              }}
            />
          </div>
          <div className="user-input-box" style={{ margin: '.25rem 0' }}>
            <input
              type="text"
              placeholder="请输入银行卡账号"
              onChange={({ target }) => {
                const tempReplace = target.value.replace(/^\s+|\s+$/g, "");
                target.value = tempReplace;
                bankNumberRef.current = tempReplace;
              }}
            />
          </div>
          <div className="user-input-box">
            <input
              type="text"
              placeholder="请输入持卡人姓名"
              onChange={({ target }) => {
                const tempReplace = target.value.replace(/^\s+|\s+$/g, "");
                target.value = tempReplace;
                nameRef.current = tempReplace;
              }}
            />
          </div>
        </div>
      ),
      submit: async () => {
        try {
          if (!bankNameRef.current) {
            Emit.emit("showToast", {
              text: "银行名称不能为空",
              time: 3000
            });
            return;
          }
          if (!bankNumberRef.current) {
            Emit.emit("showToast", {
              text: "银行卡号不能为空",
              time: 3000
            });
            return;
          }
          if (!nameRef.current) {
            Emit.emit("showToast", {
              text: "持卡人姓名不能为空",
              time: 3000
            });
            return;
          }
          const tempParam = {
            account_bank: bankNameRef.current,
            account: bankNumberRef.current,
            name: nameRef.current
          };
          const res = await apiAddAccount(tempParam);
          if (res?.status) {
            Emit.emit("showToast", {
              text: res?.data?.msg || "添加提现账户成功",
              time: 3000
            });
            getList();
          } else {
            Emit.emit("showToast", {
              text: res?.msg || "添加提现账户失败",
              time: 3000
            });
            return;
          }
        } catch (error) {
          Emit.emit("showToast", {
            text: "请求失败",
            time: 3000
          });
        }
      },
    });
  };
  // 删除
  const handleDel = (id) => {
    Emit.emit("changeAlter", {
      title: "删除提现账户",
      content: "是否删除当前账户",
      submit: async () => {
        try {
          const tempParam = { id };
          const res = await apiDelAccount(tempParam);
          if (res?.status) {
            Emit.emit("showToast", {
              text: res?.data?.msg || "删除提现账户成功",
              time: 3000,
            });
            getList();
          } else {
            Emit.emit("showToast", {
              text: res?.msg || "删除提现账户失败",
              time: 3000
            });
            return;
          }
        } catch (error) {
          Emit.emit("showToast", {
            text: "请求失败",
            time: 3000
          });
        }
      },
    });
  };
  return useMemo(() => (
    loading ? (
      <Loading show overSize={false} />
    ) : (
      <div className="positioned-container">
        <BackHead
          title="提现账号"
          stackKey={stackKey}
          rightBtn={() => (
            <ClickBtn
              className="back-header-btn"
              onTap={() => handleAdd()}
            >
              添加
            </ClickBtn>
          )}
        />
        {accountList?.length ? (
          <ScrollArea ListData={accountList?.length}>
            {accountList.map((item, index) => (
              <div
                className="account-item"
                key={`account-item_${index}`}
              >
                <ClickBtn
                  className={`radio-box ${item?.id === accountInfo?.id ? 'active' : ''}`}
                  onTap={() => handleChoose(item)}
                >
                  <div className="radio-box-inner">
                    <div className="radio-box-mark" />
                  </div>
                </ClickBtn>
                <div className="text-box">
                  <img src={iconBank} />
                  {item?.account}
                </div>
                <ClickBtn
                  className="active-btn"
                  onTap={() => handleDel(item?.id)}
                >
                  <img
                    src={iconDel}
                    className="active-btn"
                  />
                </ClickBtn>
              </div>
            ))}
          </ScrollArea>
        ) : <NoData />}
      </div>
    )
  ), [loading, accountList, accountInfo]);
};
