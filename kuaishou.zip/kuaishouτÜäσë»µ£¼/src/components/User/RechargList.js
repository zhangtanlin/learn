import React, { useEffect, useMemo, useState } from "react";

import ScrollArea from "../ScrollArea";
import HeaderBack from '../Header/HeaderBack';
import ClickBtn from '../ClickBtn';
import Loading from '../Loading';
import Emit from "../../libs/eventEmitter";
import Const from "../../libs/const";
import { NoData } from '../NoData';
import { copyText } from "../../libs/utils";
import { apiGetOrderList } from '../../libs/http';

export const RechargeListItem = (props) => {
  const { item } = props;
  const setPayType = () => {
    let tempPayType = '';
    switch (item?.payway) {
      case 'pa':
        tempPayType = '支付宝';
        break;
      case 'pw':
        tempPayType = '微信';
        break;
      case 'ph':
        tempPayType = '花呗';
        break;
      case 'pb':
        tempPayType = '银行卡';
        break;
      case 'pv':
        tempPayType = 'visa';
        break;
      case 'ps':
        tempPayType = '数字人名币';
        break;
      default:
        tempPayType = '暂无';
        break;
    }
    return tempPayType;
  };
  return useMemo(() => (
    <div className="user-recharg-list-item">
      <div className="inner-box">
        <div
          className="user-recharg-list-row"
          style={{ paddingBottom: '.25rem' }}
        >
          <div className="user-recharg-list-row-left">
            <div className="user-recharg-list-title-light">
              订单编号：{item?.order_id}
            </div>
          </div>
          <div className="user-recharg-list-row-right">
            <ClickBtn
              className="user-recharg-list-item-btn"
              onTap={() => {
                copyText(item?.order_id);
                Emit.emit("showToast", { text: `复制编号${item?.order_id}成功！`, });
              }}
            >
              复制
            </ClickBtn>
          </div>
        </div>
        <div className="user-recharg-list-row">
          <div className="user-recharg-list-row-left">
            <div className="user-recharg-list-title">
              {item?.descp}
            </div>
          </div>
          <div className="user-recharg-list-row-right">
            <div className="user-recharg-list-title">
              {item?.amount_rmb ? `¥${item?.amount_rmb}` : ''}
            </div>
          </div>
        </div>
        <div className="user-recharg-list-row">
          <div className="user-recharg-list-row-left">
            <div className="user-recharg-list-title-light">
              在线支付:{setPayType()}
            </div>
          </div>
          <div className="user-recharg-list-row-right">
            <div className="user-recharg-list-title-color">
              {item?.status || '未支付'}
            </div>
          </div>
        </div>
        <div className="user-recharg-list-row">
          <div className="user-recharg-list-row-left">
            <div className="user-recharg-list-title-small">
              {item?.created_str}
            </div>
          </div>
          <div className="user-recharg-list-row-right">
            <div className="user-recharg-list-title-small black">
              联系客服
            </div>
          </div>
        </div>
      </div>
    </div>
  ), []);
};

export default (props) => {
  const { stackKey } = props;
  const [loading, setLoading] = useState(true);
  const [params, setParams] = useState({
    page: 1,
    isAll: false,
  });
  const [data, setData] = useState([]);
  const [loadingMore, setLoadingMore] = useState(true);
  const getData = async () => {
    if (params?.isAll) {
      return;
    }
    setLoadingMore(true);
    try {
      const tempParam = { params };
      const res = await apiGetOrderList(tempParam);
      if (res?.status) {
        if (params?.page === 1) {
          setData(res?.data?.list);
        } else {
          setData([...data, ...res?.data?.list]);
        }
        if (!res?.data?.list?.length) {
          setParams({ ...params, isAll: true });
        }
      } else {
        Emit.emit("showToast", {
          text: "请求列表失败",
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
      });
    }
    setLoading(false);
    setLoadingMore(false);
  };
  const nextPage = () => {
    if (!params?.isAll) {
      setParams((tempParam) => ({
        ...tempParam,
        page: tempParam?.page + 1
      }));
    }
  };
  useEffect(() => {
    getData();
  }, [params]);

  return useMemo(() => (
    <div className="positioned-container">
      <HeaderBack
        stackKey={stackKey}
        title={Const.titleVipRechargList}
        leftIconIsDark
      />
      {loading ? (
        <Loading show overSize={false} />
      ) : (data?.length > 0 ? (
        <ScrollArea
          ListData={data?.length}
          loadingMore={loadingMore}
          onScrollEnd={nextPage}
        >
          {data.map((item, index) => (
            <RechargeListItem
              key={`user-recharge-List-item-${index}`}
              item={item}
            />
          ))}
        </ScrollArea>
      ) : (
        <NoData />
      ))}
    </div>
  ), [loading, data, loadingMore]);
};
