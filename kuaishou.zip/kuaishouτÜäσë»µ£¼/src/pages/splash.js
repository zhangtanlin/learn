export default [
  {
    path: '/',
    exact: true,
    component: () => import('../components/Splash'),
  },
];
