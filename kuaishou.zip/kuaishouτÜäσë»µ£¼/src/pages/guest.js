export default [
  {
    path: '/home',
    exact: true,
    component: () => import('../components/home'),
  },
];
