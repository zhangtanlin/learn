#!/bin/bash

# 主项目-安装依赖
echo '主项目-安装依赖'
npm install

# 主项目-删除dist目录
echo '主项目-删除dist目录'
rm -rf ./dist

# 主项目-构建
echo '主项目-构建'
npm run build

# 主项目-移动waiting.html和error.html到dist/目录
echo '主项目-移动waiting.html和error.html到dist/目录'
cp ./{waiting.html,error.html} ./dist/

# 主项目-移动analytics.js到dist/js/目录
echo '主项目-移动analytics.js到dist/js/目录'
cp ./afterDist/js/analytics.js ./dist/js/

# 定义需要监听的index.html的版本号+创建需要加入的代码
currentTimeStamp=`date +%s`
add_row="{ url: '\/index.html', revision: ${currentTimeStamp}},"


# 主项目-在dist/sw.js第二行插入{ url: '\/index.html', revision: 时间戳}
echo '主项目-修改sw.js头部'
sed -i "" -e $'1 a\\\n'"$add_row" "dist/sw.js"

# 主项目-在dist/sw.js文件中部的
# addEventListener("activate",yt))}([
# 后添加 add_row
echo '主项目-修改sw.js中部：方法一'
find_string_1='addEventListener("activate",yt))}(\['
sed -i "" "s/${find_string_1}/${find_string_1}${add_row}/g" "dist/sw.js"

# 主项目-在dist/sw.js文件中部的
# function(t){Wt().precache(t)}([
# 后添加 add_row
echo '主项目-修改sw.js中部：方法二'
find_string_2='function(t){Wt().precache(t)}(\['
sed -i "" "s/${find_string_2}/${find_string_2}${add_row}/g" "dist/sw.js"



# 把dist文件夹打包成zip
echo '主项目-把dist文件夹打包成zip'
now_time=`date +%Y-%m-%d\(%H\:%M\:%S\)`
zip -q -r ./kuaishou-pwa-$now_time.zip ./dist

# 打包结束
echo '打包结束'
