#!/bin/bash

# remove dist
echo 'start remove'
rm -rf ./dist

# build
echo 'start build'
npm run build

# move waiting.html and error.html
echo 'start move waiting.html and error.html'
cp ./{waiting.html,error.html} ./dist/

# finish
echo 'build finish'
