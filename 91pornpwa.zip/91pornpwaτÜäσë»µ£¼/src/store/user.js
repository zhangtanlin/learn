/*
 * @Author: Tom
 * @Date: 2021-11-04 21:28:00
 * @LastEditTime: 2021-11-08 20:29:36
 * @LastEditors: Tom
 * @Description:
 * @FilePath: /91avpwa/src/store/user.js
 */
import { createStore } from "react-hooks-global-state";
import { formatPhone } from "../libs/utils";

const initialState = {
  // 用户信息
  user: {
    aff: "", // 自己的邀请码
    affPage: "", // 自己的分享链接
    aff_num: "", // 和 aff一个意思
    age: 0, // 年龄
    birthday: "", // 生日
    buy_count: '', // 购买数量
    canWatchCount: 0, // 剩余观看次数
    chat_uid: '', //
    city: '', // 城市
    club_fans_num: '', // 粉丝团粉丝数
    club_video_count: '', // 粉丝团视频数量
    coins: 0, // 剩余金币数
    exp: '', // 社区经验值
    fabulous: '', // 被赞数量
    fans: 0, // 粉丝数
    followed: '', // 关注数量
    goldlist: [], // 购买过的视频列表
    interest: '', //
    invitedBy: "", // 被谁邀请 的邀请码
    invitedNum: 0, // 邀请数
    isChannel: false, // 是否是渠道用户
    isLogin: false, // 是否绑定
    isVip: true, // 是否是vip
    is_club: '', // 是否已有粉丝团
    is_login: '', // 是否登陆
    joined_club_count: '', // 粉丝团粉丝数量
    level: 1, // 社区等级 用不到
    level_page: '', // 社区等级规则【用不到】
    likelist: [], // 点赞视频列表
    likesCount: 0, // 点赞数量
    nickname: "", // 昵称
    originalLevel: 0, // 【用不到】
    person_signnatrue: "", // 个人签名【用不到】
    phone: "", // 电话
    photo_album: 0, // 相册
    role_id: '', // 角色{8:普通用户, 16:原创主, 17:up主
    sexType: 0, // 性别
    thumb: "", // 头像
    tikUrl: "", // 群链接
    upLevel: '', // 【用不到】
    username: '', // 和 phone 一个意思
    uuid: "", // 用户uuid
    videolist: [], // 自己的视频列表
    videosCount: 0, // 自己的视频数量
    vip_level: 2, // vip等级
    watchCount: 0, // 观看次数
    watchStr: "", // vip或者剩余观看次数描述
  },
};

const reducer = (state, action) => {
  if (action.type === "replace") {
    let newPayload = action?.payload;
    // 处理电话号码
    if (newPayload?.phone) {
      newPayload = {
        ...newPayload,
        ...{
          _phone: formatPhone(newPayload?.phone),
        }
      };
    }
    return { ...state, user: { ...state.user, ...newPayload } };
  }
  return state;
};

const UserStore = createStore(reducer, initialState);

export default UserStore;
