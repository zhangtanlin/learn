/*
 * @Author: Tom
 * @Date: 2021-11-18 19:08:45
 * @LastEditTime: 2021-12-31 13:51:24
 * @LastEditors: Tom
 * @Description:
 * @FilePath: /91pornpwa/src/components/videoDetail.js
 */
import React, { useEffect, useMemo, useRef, useState } from "react";
import "../resources/css/video_detail.less";
import StackStore from "../store/stack";
import Clickbtn from "./clickbtn";
import ScrollArea from "./scrollarea";
import Emit from "../libs/eventEmitter";
import Loading from "./loading";
import NoData from "./noData";
import Simg from "./simg";
import VideoPlayer from "./videoPlayer";
import VideoLoading from "./videoLoading";
import BottomLayer from "./bottomLayer";
import Dialog from "./dialog_scale";

import StackPage from "./stackpage";
import BuyCoins from "./user/buyCoins";

import globalVar from "../libs/globalVar";

import back from "../resources/img/search/back_white.png";
import warning from "../resources/img/public/warning.png";
import vip_not from "../resources/img/index/vip_not.png";
import vip_month from "../resources/img/index/vip_month.png";
import vip_ji from "../resources/img/index/vip_ji.png";
import vip_year from "../resources/img/index/vip_year.png";
import vip_forever from "../resources/img/index/vip_forever.png";
import woman from "../resources/img/index/icon_mine_woman.png";
import man from "../resources/img/index/icon_mine_man.png";
import zan from "../resources/img/index/zan_white.png";
import zanActive from "../resources/img/index/zan_yellow.png";
import penIcon from "../resources/img/index/pen.png";
import submitIcon from "../resources/img/index/submitIcon.png";

import {
  getMvDetail,
  buyVideo,
  sendVideoComment,
  setCommentZan,
  onlineFeedback,
} from "../libs/http";

export default (props) => {
  const { stackKey, id } = props;
  const videoRef = useRef(null);
  const inputRef = useRef(null);
  const [stacks] = StackStore.useGlobalState("stacks");
  const [vloading, setVLoading] = useState(true);
  const [loading, setLoading] = useState(true);
  const [overLoading, setOverLoading] = useState(false);
  const [detail, setDetail] = useState(null);
  const [videoUrl, setVideoUrl] = useState("");
  const [shouldPlay, setShouldPlay] = useState(false);
  const [showBottomLayer, setShowBottomLayer] = useState(false);
  const [showDialog, setShowDialog] = useState(false);
  const [choose, setChoose] = useState(-1);
  const [showBack, setShowBack] = useState(true);
  const mvFeedbackOption = ["点击播放后中断", "加载失败,无法观看", "其他"];
  useEffect(() => {
    getData();
  }, []);
  const getData = () => {
    getMvDetail({ id }).then((res) => {
      setLoading(false);
      if (res.data) {
        setDetail(res.data);
        // 需要购买
        if (res.data.coins != 0 && !res.data.hasBuy) {
          if (res.data.previewUrl) {
            setShouldPlay(true);
            getVideoUrl(res.data.previewUrl, (link) => {
              setVideoUrl(link);
              setVLoading(false);
            });
          } else {
            setVLoading(false);
            Emit.emit("changeAlert", {
              _title: "确认支付",
              _content: `观看该影片需要支付${res.data.coins}金币`,
              _submitText: "支付",
              _submit: toBuy,
            });
          }
        } else if (res.data.playUrl) {
          setShouldPlay(true);
          getVideoUrl(res.data.playUrl, (link) => {
            setVideoUrl(link);
            setVLoading(false);
          });
        }
      }
      // console.log("详情", res);
    });
  };

  const toBuy = () => {
    setOverLoading(true);
    buyVideo({ id }).then((res) => {
      // console.log("购买", res);
      setOverLoading(false);
      if (res.data && res.data.success) {
        setShouldPlay(true);
        setVLoading(true);
        getVideoUrl(res.data.playUrl, (link) => {
          setVideoUrl(link);
          setVLoading(false);
        });
        Emit.emit("showToast", { text: res.data.msg });
      } else {
        setShowBottomLayer(true);
      }
    });
  };
  const getVideoUrl = async (url, callBack) => {
    try {
      // let m3u8Res = await axios.get(url);
      // const m3u8 = CryptoData.DecryptVideo(m3u8Res.data);
      // const blob = new Blob([m3u8], {
      //   type: "application/x-mpegURL",
      // });
      // const link = URL.createObjectURL(blob);
      // callBack(link);
      callBack(url);
      // 更新用户次数
      // setUserData();
    } catch (error) {
      // console.log("error", error);
    }
  };
  const renderBack = () => {
    return (
      <div
        className={`video_detail_back ${showBack ? "pinduoduo-vd-back-show" : "pinduoduo-vd-back-hide"
          }`}
      >
        <Clickbtn
          className="video_detail_back_icon"
          onTap={() => {
            Emit.emit(stackKey, stackKey);
          }}
        >
          <img src={back} />
        </Clickbtn>
        {shouldPlay && detail && !!detail.title && (
          <div className="video_detail_back_title">{detail.title}</div>
        )}
      </div>
    );
  };
  const renderVideo = () => {
    const videoContent = () => {
      if (vloading) {
        return <VideoLoading />;
      }
      if (shouldPlay) {
        return videoUrl ? (
          <div
            style={{
              width: "100%",
              height: "100%",
            }}
          >
            <VideoPlayer
              auto={true}
              src={videoUrl}
              onPause={() => { }}
              videoRef={videoRef}
              durationChange={(e) => {
                if (parseInt(e.target.currentTime + 2) >= parseInt(e.target.duration)) {
                  if(detail.coins != 0 && !detail.hasBuy){
                    try {
                      Emit.emit("changeAlert", {
                        _title: "确认支付",
                        _content: `观看完整版需要支付${detail.coins}金币`,
                        _submitText: "支付",
                        _submit: toBuy,
                      });
                      setShouldPlay(false)
                    } catch (error) {
                      alert(error)
                    }
                  }
                }
              }}
            />
          </div>
        ) : (
          <VideoLoading />
        );
      }
      return videoCover();
    };

    return (
      <Clickbtn
        className="video_box"
        onTap={() => {
          if (shouldPlay) {
            setShowBack(!showBack);
          }
        }}
      >
        {renderBack()}
        {videoContent()}
      </Clickbtn>
    );
  };
  const videoCover = () => {
    if (!detail) return;
    return (
      <div className="video_cover">
        <p>{detail.title}</p>
        <p>需要支付{detail.coins}金币</p>
        <Clickbtn className="video_cover_btn" onTap={toBuy}>
          马上支付
        </Clickbtn>
      </div>
    );
  };
  const renderInfo = () => {
    return (
      <div className="video_info">
        <p className="video_info_title">{detail.title}</p>
        {detail.tags && detail.tags.length > 0 && (
          <div className="video_info_tags">
            {detail.tags.map((item, index) => {
              return <span key={index}>{item}</span>;
            })}
          </div>
        )}
        <Clickbtn
          className="video_info_warning"
          onTap={() => {
            setShowDialog(true);
          }}
        >
          <img src={warning} />
          无法播放
        </Clickbtn>
        <p className="video_info_desc">{detail.descriptions}</p>
      </div>
    );
  };
  const commentList = () => {
    return (
      <div className="video_commentList">
        <p>
          精彩评论<span>（{detail.comment}条）</span>
        </p>
        {detail.commentList && detail.commentList.length > 0 ? (
          <>
            {detail.commentList.map((item, index) => {
              return <CommentItem data={item} key={index} />;
            })}
            <div style={{ height: "3rem" }} />
          </>
        ) : (
          <div
            style={{
              marginTop: "2rem",
            }}
          >
            <NoData />
          </div>
        )}
      </div>
    );
  };
  const inputBox = () => {
    return (
      <div className="video_input_box">
        <div className="video_input">
          <img src={penIcon} />
          <input ref={inputRef} placeholder="留下你的影评" />
        </div>
        <img
          className="video_input_sub"
          src={submitIcon}
          onClick={() => {
            if (!inputRef.current.value) {
              Emit.emit("showToast", { text: "请输入内容" });
            } else {
              sendVideoComment({
                mv_id: detail.id,
                comment: inputRef.current.value,
              }).then((res) => {
                let msg;
                if (res.data && res.data.success) {
                  msg = res.data.msg;
                  getMvDetail({ id }).then((res) => {
                    setDetail({ ...res.data });
                  });
                } else {
                  msg = res.msg;
                }
                inputRef.current.value = "";
                Emit.emit("showToast", { text: msg });
              });
            }
          }}
        />
      </div>
    );
  };
  const renderComfirm = () => {
    return (
      <div className="video_detail_comfirm">
        <p className="video_detail_comfirm_title">确认支付</p>
        <p className="video_detail_comfirm_content">
          您的余额不足请前去充值再来观赏吧
        </p>
        <div className="video_detail_comfirm_btn">
          <Clickbtn
            onTap={() => {
              setShowBottomLayer(false);
            }}
          >
            取消
          </Clickbtn>
          <Clickbtn
            onTap={() => {
              setShowBottomLayer(false);
              // 跳钱包页面
              const stackKey = `BuyCoins-${new Date().getTime()}`;
              StackStore.dispatch({
                type: "push",
                payload: {
                  name: "BuyCoins",
                  element: (
                    <StackPage
                      stackKey={stackKey}
                      key={stackKey}
                      style={{ zIndex: stacks.length + 2 }}
                    >
                      <BuyCoins stackKey={stackKey} />
                    </StackPage>
                  ),
                },
              });
            }}
          >
            充值
          </Clickbtn>
        </div>
      </div>
    );
  };
  const renderCantPlay = () => {
    const lists = globalVar.mvFeedbackOption || mvFeedbackOption;
    return (
      <div className="video_detail_cantplay">
        <p className="video_detail_cantplay_title">无法播放原因</p>
        {lists.map((item, index) => {
          return (
            <Clickbtn
              className="video_detail_cantplay_item"
              key={index}
              onTap={() => {
                setChoose(index);
              }}
            >
              <span>{item}</span>
              <span
                className={
                  index == choose
                    ? "cantplay_item_choose"
                    : "cantplay_item_choose_not"
                }
              />
            </Clickbtn>
          );
        })}
        <Clickbtn
          className="video_detail_cantplay_btn"
          onTap={() => {
            if (choose == -1) {
              Emit.emit("showToast", { text: "请选择内容" });
              setShowDialog(false);
            } else {
              setOverLoading(true);
              onlineFeedback({
                content: lists[choose],
                message_type: 1,
                help_type: 1,
                mv_id: id,
              })
                .then((res) => {
                  setShowDialog(false);
                  setChoose(-1);
                  setOverLoading(false);
                  Emit.emit("showToast", {
                    text: "感谢您的反馈，我们会不断改进",
                  });
                })
                .catch(() => {
                  setShowDialog(false);
                  setChoose(-1);
                  setOverLoading(false);
                });
            }
          }}
        >
          提交
        </Clickbtn>
      </div>
    );
  };
  return (
    <div className="page-content-flex video_detail">
      {renderVideo()}
      {loading ? (
        <Loading show type={1} />
      ) : detail ? (
        <ScrollArea downRefresh={false}>
          {renderInfo()}
          {commentList()}
        </ScrollArea>
      ) : (
        <NoData />
      )}
      {detail && inputBox()}
      <BottomLayer
        show={showBottomLayer}
        onTap={() => {
          setShowBottomLayer(false);
        }}
      >
        {renderComfirm()}
      </BottomLayer>
      <Dialog
        show={showDialog}
        onClose={() => {
          setShowDialog(false);
        }}
      >
        {renderCantPlay()}
      </Dialog>
      {overLoading && <Loading show type={1} />}
    </div>
  );
};

const CommentItem = (props) => {
  const { data } = props;
  const [isLike, setIsLike] = useState(data.isLiked);
  const [zanNum, setZanNum] = useState(data.like);
  let vipIcon = vip_not;
  switch (data.vip_level) {
    case 0:
      vipIcon = vip_not;
      break;
    case 1:
      vipIcon = vip_month;
      break;
    case 2:
      vipIcon = vip_ji;
      break;
    case 3:
      vipIcon = vip_year;
      break;
    case 4:
      vipIcon = vip_forever;
      break;
    default:
      vipIcon = vip_forever;
      break;
  }
  return (
    <div className="video_comment">
      <div className="video_comment_avatar_box">
        <div className="video_comment_avatar">
          <Simg src={data.thumb} isAvatar />
        </div>
        <img className="video_comment_vip" src={vipIcon} />
      </div>
      <div className="video_comment_info">
        <div className="video_comment_info_top">
          <div className="video_comment_left">
            <p>
              {data.nickName}
              {!!data.sexType && <img src={data.sexType == 1 ? man : woman} />}
            </p>
            <span>{data.created_at}</span>
          </div>
          <div className="video_comment_right">
            <Clickbtn
              onTap={() => {
                setCommentZan({ comment_id: data.id }).then((res) => {
                  // console.log("点赞", res);
                });
                let num = isLike ? zanNum - 1 : zanNum + 1;
                setZanNum(num < 0 ? 0 : num);
                setIsLike(!isLike);
              }}
            >
              <img src={isLike ? zanActive : zan} />
              {zanNum}
            </Clickbtn>
          </div>
        </div>
        <p className="video_comment_info_content">{data.comment}</p>
      </div>
    </div>
  );
};
