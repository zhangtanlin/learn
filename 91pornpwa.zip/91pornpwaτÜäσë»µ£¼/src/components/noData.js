/*
 * @Author: Tom
 * @Date: 2021-08-02 16:42:46
 * @LastEditTime: 2021-11-18 17:29:20
 * @LastEditors: Tom
 * @Description:
 * @FilePath: /91pornpwa/src/components/noData.js
 */
import React, { useEffect, useRef, useState } from "react";
import noData_white from "../resources/img/public/noData.png";
import noData_black from "../resources/img/public/noData_black.png";

import "../resources/css/noData.less";

export default (props) => {
  const { text, guideText, type = "black" } = props;
  return (
    <div className={"noData"}>
      <img src={type == "black" ? noData_black : noData_white} />
      <span style={{ color: type == "black" ? "white" : "#686982" }}>
        {text || "受不了，快掏出来满足我！"}
      </span>
      {guideText && guideText()}
    </div>
  );
};
