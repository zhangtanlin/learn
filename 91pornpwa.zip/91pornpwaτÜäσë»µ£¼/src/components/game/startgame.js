import React, { useEffect, useMemo, useRef } from "react";
import "../../resources/css/game.less";
import BackHeader from "../../components/backHeader";
export default props => {
  const { url, stackKey } = props;
  const iframeRef = useRef(null);

  const requestFullScreen = element => {
    // 判断各种浏览器，找到正确的方法
    var requestMethod =
      element.requestFullScreen || //W3C
      element.webkitRequestFullScreen || //FireFox
      element.mozRequestFullScreen || //Chrome等
      element.msRequestFullScreen; //IE11
    if (requestMethod) {
      requestMethod.call(element);
    } else if (typeof window.ActiveXObject !== "undefined") {
      //for Internet Explorer
      var wscript = new ActiveXObject("WScript.Shell");
      if (wscript !== null) {
        wscript.SendKeys("{F11}");
      }
    }
  };
  //退出全屏 判断浏览器种类
  function exitFull() {
    // 判断各种浏览器，找到正确的方法
    var exitMethod =
      document.exitFullscreen || //W3C
      document.mozCancelFullScreen || //FireFox
      document.webkitExitFullscreen || //Chrome等
      document.webkitExitFullscreen; //IE11
    if (exitMethod) {
      exitMethod.call(document);
    } else if (typeof window.ActiveXObject !== "undefined") {
      //for Internet Explorer
      var wscript = new ActiveXObject("WScript.Shell");
      if (wscript !== null) {
        wscript.SendKeys("{F11}");
      }
    }
  }
  useEffect(() => {
    requestFullScreen(iframeRef.current);
    return () => {};
  }, []);
  return (
    <div className="pull-game-page" ref={iframeRef}>
      <div className="game-back">
      <BackHeader stackKey={stackKey} color={"rgba(0,0,0,0)"}/>
      </div>
      <iframe
        style={{
          width: "100%",
          height: "100%"
        }}
        src={url}
        scrolling="no"
        frameBorder="0"
      ></iframe>
    </div>
  );
};
