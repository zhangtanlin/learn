import React, { useEffect, useMemo, useRef, useState } from "react";
import BackHeader from "../../components/backHeader";
import ScrollArea from "../scrollarea";
import "../../resources/css/game.less";
import StackPage from "../stackpage";
import redPoint from "../../resources/img/game/redPoint.png";
import StackStore from "../../store/stack";
import RecordPage from "../../components/game/record";
import { drawGame } from "../../libs/http";
import emit from "../../libs/eventEmitter";

export default props => {
  const { stackKey, vipInfo } = props;
  const numberRef = useRef(null);
  const userRef = useRef(null);
  const cardRef = useRef(null);
  const btndef = useRef(null);
  const [isvip, setIsvip] = useState(false);
  const [questionArr, setquestionArr] = useState([
    "如多次支付失败请尝试其它支付方式或稍后再试。",
    "支付成功后一般10分钟内到账，若超过30分钟请联系客服。",
    "部分安卓手机支付时误报病毒，请选择忽略即可。"
  ]);
  const [numberValue, setNumberValue] = useState("");
  useEffect(() => {
    if (!vipInfo) return;
    if (vipInfo.isVip !== 0 && !isvip) {
      setIsvip(true);
    }
    console.log()
    let vipInfoText = vipInfo?.data.questions
    setquestionArr(vipInfoText);
  }, [vipInfo]);
  const userWithdra = async () => {
    let re = /^[0-9]*$/;
    if (!numberRef.current.value) {
      emit.emit("showToast", {
        text: "请输入提现金额",
        time: 3000
      });
      return;
    }
    if (!re.test(numberRef.current.value)) {
      emit.emit("showToast", {
        text: "提现金额必须是数字",
        time: 3000
      });
      
      if (!re.test(cardRef.current.value)) {
        emit.emit("showToast", {
          text: "输入的卡号必须是数字",
          time: 3000
        });
        return;
      }
    }
    if (Number(numberRef.current.value) < 100) {
      emit.emit("showToast", {
        text: "提现金额必须大于100",
        time: 3000
      });
      return;
    }
    if (Number(numberRef.current.value) % 100 !== 0) {
      emit.emit("showToast", {
        text: "提现金额必须是100整倍数",
        time: 3000
      });
      return;
    }

    if (!cardRef.current.value) {
      emit.emit("showToast", {
        text: "请输入提现卡号",
        time: 3000
      });
      return;
    }
    if (!userRef.current.value) {
      emit.emit("showToast", {
        text: "请输入收款人姓名",
        time: 3000
      });
      return;
    }
    drawGame({
      amount: numberRef.current.value,
      bankcard: cardRef.current.value,
      name: userRef.current.value
    }).then(res => {
      if (res.status !== 0) {
        emit.emit("showToast", {
          text: "您的提现申请已发送,请您耐心等待～",
          time: 3000
        });
        emit.emit(stackKey, stackKey);
        emit.emit("changeGameMoney");
      } else {
        emit.emit("showToast", {
          text: res.msg,
          time: 3000
        });
      }
    });
  };

  const [stacks] = StackStore.useGlobalState("stacks");
  const toRecord = () => {
    const stackKey = `recharge-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "recharge",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <RecordPage type={1} stackKey={stackKey} />
          </StackPage>
        )
      }
    });
  };
  return useMemo(
    () => (
      <div className="full-column background140" style={{ width: "100%" }}>
        <BackHeader
          stackKey={stackKey}
          title={"提现"}
          rightBtn={() => (
            <div
              style={{
                fontSize: "0.36rem"
              }}
              onTouchEndCapture={() => {
                toRecord();
              }}
            >
              提现记录
            </div>
          )}
        />
        <ScrollArea downRefresh={false}>
          <div className="withdraw-page">
            <div className="content-box">
              <p
                style={{
                  fontSize: "0.35rem",
                  color: "white"
                }}
              >
                账户余额：
                <span
                  style={{
                    fontSize: "0.426rem"
                  }}
                >
                  {vipInfo?.data?.balance}元
                </span>
              </p>

              <div className="withdraw-input-box">
                <input
                  placeholder="请输入提现金额"
                  type="number"
                  ref={numberRef}
                  onChange={e => {
                    if (
                      Number(numberRef.current && numberRef.current.value) < 0
                    ) {
                      emit.emit("showToast", {
                        text: "输入金额必须大于0",
                        time: 3000
                      });
                    } else {
                      if (
                        Number(numberRef.current && numberRef.current.value) >
                        Number(vipInfo?.data?.balance)
                      ) {
                        emit.emit("showToast", {
                          text: "您输入的金额已超出您可提现的金额",
                          time: 3000
                        });
                      } else {
                        setNumberValue(numberRef.current.value);
                      }
                    }
                  }}
                />
              </div>
              <div
                style={{
                  fontSize: "0.346rem",
                  color: "#666666"
                }}
                className="withdraw-pd-box"
              >
                到账合计:
                <span
                  style={{
                    color: "white"
                  }}
                >
                  {numberValue || 0}
                </span>
                元
              </div>
            </div>

            <div
              style={{
                height: "0.2rem"
              }}
            ></div>
            <div
              style={{
                padding: "0.3rem"
              }}
            >
              <p
                style={{
                  fontSize: "0.426rem",
                  color: "white"
                }}
              >
                填写收款人信息
              </p>
              <div className="withdraw-info-box">
                <div className="input_title">银行卡</div>
                <input
                  placeholder="请输入银行卡号"
                  type="number"
                  ref={cardRef}
                />
              </div>
              <div className="withdraw-info-box">
                <div className="input_title">收款人</div>
                <input
                  placeholder="请输入收款人信息"
                  type="text"
                  ref={userRef}
                />
              </div>
            </div>
            <div className="content-box">
              <div className="game_title_row">
                <span
                  style={{
                    color: "white",
                    fontSize: "0.39rem"
                  }}
                >
                  常见问题
                </span>
              </div>
              <div
                style={{
                  padding: "0.316rem",
                  background: "rgb(28, 3, 54)",
                  width: "100%"
                }}
              >
                {questionArr.map((n, index) => (
                  <div
                    className="question-box"
                    key={`withdraw-question-${index}`}
                  >
                    <div className="question_item">
                      <img className="red_point" src={redPoint} />
                      <div
                        style={{ flex: "1" }}
                        dangerouslySetInnerHTML={{ __html: n }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
              <div
                onClick={()=>{
                  userWithdra()
                }}
                className="game-start"
                style={{
                  marginTop: "0.4rem",
                  fontSize: "0.4rem",
                  lineHeight: "1rem",
                  width: "100%",
                  height: "1rem",
                  borderRadius: "0.5rem"
                }}
              >
                确定
              </div>
            </div>
          </div>
        </ScrollArea>
      </div>
    ),
    [numberValue, vipInfo, questionArr]
  );
};
