/*
 * @Author: Tom
 * @Date: 2021-11-19 13:56:45
 * @LastEditTime: 2021-12-08 09:39:55
 * @LastEditors: Tom
 * @Description:
 * @FilePath: /91pornpwa/src/components/fansDetail.js
 */
import React, { useEffect, useRef, useState } from "react";
import "../resources/css/fansDetail.less";
import StackStore from "../store/stack";
import Clickbtn from "./clickbtn";
import ScrollArea from "./scrollarea";
import Emit from "../libs/eventEmitter";
import Loading from "./loading";
import NoData from "./noData";
import Simg from "./simg";
import StackPage from "./stackpage";
import Dialog from "./dialog_scale";
import BottomLayer from "./bottomLayer";

import FansRule from "./fansRule";
import PersonPage from "./user/mine";

import back from "../resources/img/search/back_white.png";
import fanBg from "../resources/img/fans/fansBg.png";
import fans_ji from "../resources/img/fans/fans_ji.png";
import fans_month from "../resources/img/fans/fans_month.png";
import fans_year from "../resources/img/fans/fans_year.png";
import no1 from "../resources/img/fans/no1.png";
import no2 from "../resources/img/fans/no2.png";
import no3 from "../resources/img/fans/no3.png";
import rankIcon from "../resources/img/fans/rankIcon.png";
import videoIcon from "../resources/img/fans/videoIcon.png";
import rightIcon from "../resources/img/fans/rightIcon.png";
import tips1 from "../resources/img/fans/tips1.png";
import tips2 from "../resources/img/fans/tips2.png";
import reply from "../resources/img/fans/reply.png";
import zanIcon from "../resources/img/fans/zan.png";
import zan_active from "../resources/img/fans/zan_active.png";
import vip_not from "../resources/img/index/vip_not.png";
import vip_month from "../resources/img/index/vip_month.png";
import vip_ji from "../resources/img/index/vip_ji.png";
import vip_year from "../resources/img/index/vip_year.png";
import vip_forever from "../resources/img/index/vip_forever.png";
import closeIcon from "../resources/img/public/ic_dialog_close.png";
import jika from "../resources/img/fans/icon_shop_jika.png";
import yueka from "../resources/img/fans/icon_shop_month.png";
import nianka from "../resources/img/fans/icon_shop_year.png";
import coinIcon from "../resources/img/search/coin.png";

import {
  getFansDetail,
  getFansMsg,
  getFansRank,
  sendFansMsg,
  fansMsgZan,
  joinFans,
} from "../libs/http";

let initFansRank = [];
let initMsg = [];
export default (props) => {
  const { stackKey, clubId } = props;
  const textareaRef = useRef(null);
  const [loading, setLoading] = useState(true);
  const navs = ["粉丝排行", "留言板"];
  const [tabIndex, setTabIndex] = useState(0);
  const [stacks] = StackStore.useGlobalState("stacks");
  const _width = document.body.clientWidth;
  const [detail, setDetail] = useState(null);
  const [list, setList] = useState([]);
  const [loadingMore, setLoadingMore] = useState({ a: true });
  const [showDialog, setShowDialog] = useState(false);
  const [parent_id, setParent_id] = useState(0);
  const [showBottomLayer, setShowBottomLayer] = useState(false);
  let page = 2;
  useEffect(() => {
    if (detail) {
      // if (
      //   (tabIndex == 0 && initFansRank.length < 4) ||
      //   (tabIndex == 1 && initMsg.length < 4)
      // ) {
      //   return;
      // }
      page = 2;
      loadingMore.a = true;
      setLoadingMore({ ...loadingMore });
      setList(tabIndex == 0 ? initFansRank : initMsg);
      // getList();
    }
  }, [tabIndex]);
  useEffect(() => {
    getData();
  }, []);
  const getData = () => {
    getFansDetail({ id: clubId }).then((res) => {
      // console.log("粉丝团", res);
      setLoading(false);
      if (!res.data || !res.data.name) {
        Emit.emit("showToast", { text: "粉丝团不存在" });
        Emit.emit(stackKey, stackKey);
      } else {
        setDetail(res.data);
        initFansRank = res.data.fans_ranks;
        initMsg = res.data.message_board;
        if (res.data.fans_ranks && res.data.fans_ranks.length > 0) {
          setList(res.data.fans_ranks);
        }
      }
    });
  };
  const getList = async () => {
    if (!loadingMore.a) return;
    let res;
    let tlist = tabIndex == 0 ? initFansRank : initMsg;
    if (tabIndex == 0) {
      res = await getFansRank({ page, id: clubId });
    } else {
      res = await getFansMsg({ page, id: clubId });
    }
    // console.log("列表", res.data.item, tlist);
    if (res.data.item.length > 0) {
      if (page == 2) {
        setList([...tlist, ...res.data.item]);
      } else {
        setList((pre) => [...pre, ...res.data.item]);
      }
      page++;
    } else {
      loadingMore.a = false;
      setLoadingMore({ ...loadingMore });
    }
  };
  const renderHeader = () => {
    return (
      <div className="fansDetail_header">
        <Clickbtn
          className="fansDetail_header_back"
          onTap={() => {
            Emit.emit(stackKey, stackKey);
          }}
        >
          <img src={back} />
        </Clickbtn>
        <div className="fansDetail_header_title">{detail?.name || ""}</div>
      </div>
    );
  };

  const renderExp = (type) => {
    switch (type) {
      case "month":
        return <img src={fans_month} />;
      case "quarter":
        return <img src={fans_ji} />;
      case "year":
        return <img src={fans_year} />;
      default:
        return <></>;
    }
  }

  const personInfo = () => {
    return (
      <div className="fansDetail_info">
        <img className="fansDetail_info_bg" src={fanBg} />
        <div className="fansDetail_info_wrap">
          <div className="fansDetail_info_head">
            <div className="fansDetail_info_cover">
              {detail && <Simg src={detail?.thumb} isAvatar />}
            </div>
            <div>
              <p className="fansDetail_info_name">{detail?.name || ""}</p>
              {detail && detail.hasJoin && (
                <div className="fansDetail_info_fanstime">
                  {renderExp(detail.type)}
                  {detail.add_day}
                </div>
              )}
            </div>
          </div>
          <div className="fansDetail_info_middle">
            <div>
              <img src={rankIcon} />
              <span>粉丝团排名</span>
              <span>NO.{detail?.rank || 0}</span>
            </div>
            <div>
              <img src={videoIcon} />
              <span>专属视频</span>
              <span>{detail?.videos_count || 0}</span>
            </div>
          </div>
          <div className="fansDetail_info_desc">{detail?.notice || ""}</div>
        </div>
      </div>
    );
  };
  const tipBox = () => {
    return (
      <div className="fansDetail_tipbox">
        <div className="fansDetail_tipbox_left">
          <span>入团特权</span>
          <Clickbtn
            onTap={() => {
              const stackKey = `FansRule-${new Date().getTime()}`;
              StackStore.dispatch({
                type: "push",
                payload: {
                  name: "FansRule",
                  element: (
                    <StackPage
                      stackKey={stackKey}
                      key={stackKey}
                      style={{ zIndex: stacks.length + 2 }}
                    >
                      <FansRule stackKey={stackKey} />
                    </StackPage>
                  ),
                },
              });
            }}
          >
            粉丝团介绍
            <img src={rightIcon} />
          </Clickbtn>
        </div>
        <div className="fansDetail_tipbox_right">
          <img src={tips1} />
          <img src={tips2} />
        </div>
      </div>
    );
  };
  const renderTab = (className) => {
    return (
      <div className={className}>
        <div className="fansDetail_tab">
          <Clickbtn
            className={tabIndex == 0 ? "active" : ""}
            onTap={() => {
              setTabIndex(0);
            }}
          >
            粉丝排行
          </Clickbtn>
          <Clickbtn
            className={tabIndex == 1 ? "active" : ""}
            onTap={() => {
              setTabIndex(1);
            }}
          >
            留言板
          </Clickbtn>
        </div>
        {tabIndex == 1 && (
          <div className="fansDetail_tab_bottom">
            <span>留言板</span>
            <Clickbtn
              onTap={() => {
                setShowDialog(true);
                setParent_id(0);
              }}
            >
              我要留言
            </Clickbtn>
          </div>
        )}
      </div>
    );
  };
  const toPerson = (uuid) => {
    const stackKey = `PersonPage-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "PersonPage",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <PersonPage stackKey={stackKey} uuid={uuid} />
          </StackPage>
        ),
      },
    });
  };
  const renderList = () => {
    if (list.length == 0) {
      return (
        <div style={{ marginTop: "1rem" }}>
          <NoData />
        </div>
      );
    }
    return (
      <div>
        {list.map((v, i) => {
          if (tabIndex == 1) {
            return (
              <CommentItem
                data={v}
                key={i}
                index={i}
                onReply={(id) => {
                  setShowDialog(true);
                  setParent_id(id);
                }}
                onJump={(uuid) => {
                  toPerson(uuid);
                }}
              />
            );
          }
          return (
            <RankItem
              data={v}
              key={i}
              index={i}
              onJump={(uuid) => {
                toPerson(uuid);
              }}
            />
          );
        })}
      </div>
    );
  };
  const renderInput = () => {
    return (
      <div className="fansDetail_textarea">
        <textarea ref={textareaRef} placeholder="输入留言" />
        <div>
          <span
            onClick={() => {
              setShowDialog(false);
            }}
          >
            取消
          </span>
          <span
            onClick={() => {
              if (!textareaRef.current.value) {
                Emit.emit("showToast", { text: "请输入留言内容" });
              } else {
                sendFansMsg({
                  id: clubId,
                  message: textareaRef.current.value,
                  parent_id: parent_id,
                }).then((res) => {
                  let msg;
                  if (res.status) {
                    msg = '提交留言成功';
                  } else {
                    msg = '提交留言失败';
                  }
                  textareaRef.current.value = "";
                  Emit.emit("showToast", { text: msg });
                });
                setShowDialog(false);
              }
            }}
          >
            确定
          </span>
        </div>
      </div>
    );
  };
  const renderBottom = () => {
    if (!detail) {
      return null;
    }
    return (
      <div className="fansDetail_bottom">
        {detail.hasJoin ? (
          <Clickbtn className="fansDetail_bottom_join" onTap={() => {
            setShowBottomLayer(true);
          }}>
            <span>{detail.expired_str}</span>
            <div>续费</div>
          </Clickbtn>
        ) : (
          <Clickbtn
            className="fansDetail_bottom_notjoin"
            onTap={() => {
              setShowBottomLayer(true);
            }}
          >
            加入粉丝团
          </Clickbtn>
        )}
      </div>
    );
  };
  const renderJoinList = () => {
    const lItem = (type) => {
      let kaIcon;
      let name;
      let coinNum;
      switch (type) {
        case "month":
          kaIcon = yueka;
          name = "粉丝团月票";
          coinNum = detail.clubInfo.month;
          break;
        case "quarter":
          kaIcon = jika;
          name = "粉丝团季票";
          coinNum = detail.clubInfo.quarter;
          break;
        case "year":
          kaIcon = nianka;
          name = "粉丝团年票";
          coinNum = detail.clubInfo.year;
          break;
        default:
          break;
      }
      return (
        <Clickbtn
          className="fansDetail_joinList_item"
          onTap={() => {
            setLoading(true);
            setShowBottomLayer(false);
            joinFans({ id: clubId, type }).then((res) => {
              // console.log("加入粉丝团", res);
              setLoading(false);
              Emit.emit("showToast", { text: res.msg });
              if (res.data && res.data.success) {
                getData();
              }
            });
          }}
        >
          <div>
            <img src={kaIcon} />
            <span>{name}</span>
          </div>
          <span>
            <img src={coinIcon} />
            {coinNum}金币
          </span>
        </Clickbtn>
      );
    };
    return (
      <div className="fansDetail_joinList">
        <div className="fansDetail_joinList_title">
          <img src={closeIcon} style={{ opacity: 0 }} />
          <p>{detail.hasJoin ? "续费粉丝团" : "加入粉丝团"}</p>
          <img
            src={closeIcon}
            onClick={() => {
              setShowBottomLayer(false);
            }}
          />
        </div>
        {lItem("month")}
        {lItem("quarter")}
        {lItem("year")}
      </div>
    );
  };
  return (
    <div className="page-content-flex fansDetail">
      {renderHeader()}
      <ScrollArea
        downRefresh={false}
        ListData={list}
        onScrollEnd={getList}
        loadingMore={loadingMore.a}
        scrollChange={(e) => {
          if (_width * 1.19 + e.y < 0) {
            document
              .getElementsByClassName("fansDetail_tab1")[0]
              .setAttribute("style", "opacity:0");
            document
              .getElementsByClassName("fansDetail_tab2")[0]
              .setAttribute("style", "opacity:1");
          } else {
            document
              .getElementsByClassName("fansDetail_tab1")[0]
              .setAttribute("style", "opacity:1");
            document
              .getElementsByClassName("fansDetail_tab2")[0]
              .setAttribute("style", "opacity:0");
          }
        }}
        paddingBottom={"2rem"}
      >
        {personInfo()}
        {tipBox()}
        {renderTab("fansDetail_tab1")}
        {renderList()}
      </ScrollArea>
      {renderTab("fansDetail_tab2")}
      <Dialog
        show={showDialog}
        onClose={() => {
          setShowDialog(false);
        }}
      >
        {renderInput()}
      </Dialog>
      {renderBottom()}
      {loading && <Loading show type={1} />}
      <BottomLayer
        show={showBottomLayer}
        onTap={() => {
          setShowBottomLayer(false);
        }}
      >
        {detail && renderJoinList()}
      </BottomLayer>
    </div>
  );
};

const RankItem = (props) => {
  const { data, index, onJump } = props;
  let imgSrc;
  if (index == 0) {
    imgSrc = no1;
  } else if (index == 1) {
    imgSrc = no2;
  } else if (index == 2) {
    imgSrc = no3;
  }
  let vipIcon;
  let fansIcon;
  switch (data.vip_level) {
    case 0:
      vipIcon = vip_not;
      break;
    case 1:
      vipIcon = vip_month;
      break;
    case 2:
      vipIcon = vip_ji;
      break;
    case 3:
      vipIcon = vip_year;
      break;
    case 4:
      vipIcon = vip_forever;
      break;
    default:
      vipIcon = vip_forever;
      break;
  }

  switch (data.type) {
    case "month":
      fansIcon = fans_month;
      break;
    case "quarter":
      fansIcon = fans_ji;
      break;
    case "year":
      fansIcon = fans_year;
      break;
    default:
      break;
  }
  return (
    <Clickbtn
      className="fansDetail_rankItem"
      onTap={() => {
        onJump(data.uuid);
      }}
    >
      <div className="fansDetail_rankItem_left">
        {imgSrc ? (
          <img className="fansDetail_rankItem_rank" src={imgSrc} />
        ) : (
          <span className="fansDetail_rankItem_rankNum">{index + 1}</span>
        )}
        <div className="fansDetail_rankItem_avatar">
          <Simg isAvatar src={data.thumb} />
        </div>
        <div className="fansDetail_rankItem_info">
          <p>{data.nickname}</p>
          <div>
            <img className="fansDetail_rankItem_vip" src={vipIcon} />
            <img className="fansDetail_rankItem_fans" src={fansIcon} />
          </div>
        </div>
      </div>
      <span className="fansDetail_rankItem_right">{data.exp}点亲密度</span>
    </Clickbtn>
  );
};

const CommentItem = (props) => {
  const { data, onReply, onJump } = props;
  const [zan, setZan] = useState(!!data.is_like);
  const [zanNum, setZanNum] = useState(parseInt(data.like_count) || 0);
  let vipIcon = vip_not;
  let fansIcon;
  switch (data.vip_level) {
    case 0:
      vipIcon = vip_not;
      break;
    case 1:
      vipIcon = vip_month;
      break;
    case 2:
      vipIcon = vip_ji;
      break;
    case 3:
      vipIcon = vip_year;
      break;
    case 4:
      vipIcon = vip_forever;
      break;
    default:
      vipIcon = vip_forever;
      break;
  }

  switch (data.fans_type) {
    case "month":
      fansIcon = fans_month;
      break;
    case "quarter":
      fansIcon = fans_ji;
      break;
    case "year":
      fansIcon = fans_year;
      break;
    default:
      break;
  }
  return (
    <div className="fansDetail_comment">
      <Clickbtn
        className="fansDetail_comment_cover"
        onTap={() => {
          onJump(data.uuid);
        }}
      >
        <Simg isAvatar src={data.thumb} />
      </Clickbtn>
      <div className="fansDetail_comment_right">
        <div className="fansDetail_comment_right_top">
          <div className="fansDetail_comment_namebox">
            <p>{data.nickname}</p>
            <div>
              <img className="fansDetail_rankItem_vip" src={vipIcon} />
              {fansIcon && (
                <img className="fansDetail_rankItem_fans" src={fansIcon} />
              )}
              {data.created_at}
            </div>
          </div>
          <Clickbtn
            className="fansDetail_comment_zan"
            styles={{ color: zan ? "#ff4bac" : "#bfc0da" }}
            onTap={() => {
              const a = zan ? zanNum - 1 : zanNum + 1;
              setZan(!zan);
              setZanNum(a < 0 ? 0 : a);
              fansMsgZan({ id: data.id });
            }}
          >
            <img src={zan ? zan_active : zanIcon} />
            {zanNum}
          </Clickbtn>
        </div>
        <span className="fansDetail_comment_content">
          {data.message}
          <Clickbtn
            onTap={() => {
              onReply && onReply(data.id);
            }}
          >
            <img src={reply} />
            回复
          </Clickbtn>
        </span>
        {data.child && data.child.length > 0 ? (
          <div className="fansDetail_comment_reply">
            {data.child.map((item, index) => {
              return (
                <span key={index}>
                  @{item?.nickname || ""}:{item?.message || ""}
                </span>
              );
            })}
          </div>
        ) : (
          <div style={{ height: "0.4rem" }} />
        )}
      </div>
    </div>
  );
};
