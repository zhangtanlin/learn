/*
 * @Author: Tom
 * @Date: 2021-08-12 09:52:53
 * @LastEditTime: 2021-11-17 21:14:01
 * @LastEditors: Tom
 * @Description:
 * @FilePath: /91pornpwa/src/components/toast.js
 */
import React, { useEffect, useRef, useState } from "react";
import "../resources/css/toast.less";
import emit from "../libs/eventEmitter";

export default (props) => {
  const [text, setText] = useState("");
  const [time, setTime] = useState(2000);
  const [isHide, setIsHide] = useState(true);
  const [type, setType] = useState("white"); // 主题黑或白
  let timer;
  useEffect(() => {
    emit.on("showToast", (data) => {
      setIsHide(false);
      data.text && setText(data.text);
      data.time && setTime(data.time);
      setType(data.type || "white");
      timer && clearTimeout(timer);
      timer = setTimeout(() => {
        setIsHide(true);
        // setText("");
        setTime(2000);
      }, time);
    });
    return () => {
      emit.off("showToast");
    };
  }, []);
  return (
    <div
      className={`toast ${isHide ? "toast-out" : "toast-in"} ${
        type == "white" ? "" : "toast_black"
      }`}
    >
      <div>{text}</div>
    </div>
  );
};
