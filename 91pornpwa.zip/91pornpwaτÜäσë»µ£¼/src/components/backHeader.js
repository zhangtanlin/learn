import React, { useEffect, useRef } from "react";
import Hammer from "hammerjs";
import "../resources/css/backHeader.less";

import Emit from "../libs/eventEmitter";

import backWhite from "../resources/img/public/backWhite.png";
import backBlack from "../resources/img/public/backBlack.png";

export default props => {
  const backRef = useRef(null);
  const {
    stackKey,
    left, // 左侧块（方法）
    leftIconIsDark, // 左侧是否使用深色图标
    center, // 中部块（方法）
    title, // 中部文字
    right, // 右侧块（方法）
    rightBtn, // 右侧按钮块（方法）
    style // 全局样式
  } = props;

  // useEffect(() => {
  //   if (!backRef.current) return;
  //   const go_back = () => {
  //     Emit.emit(stackKey, stackKey);
  //   };
  //   const hammer = new Hammer(backRef.current);
  //   hammer.on("tap", go_back);
  //   return () => {
  //     hammer.off("tap", go_back);
  //   };
  // }, [backRef.current]);

  return (
    <div className="back-header" style={style}>
      {/* 左侧 */}
      {left ? (
        left()
      ) : (
        <div className="back-header-left">
          <div onClick={(e)=>{
            Emit.emit(stackKey, stackKey);
          }} className="back-header-left-back">
            <img src={leftIconIsDark ? backBlack : backWhite} />
          </div>
        </div>
      )}
      {/* 中部 */}
      {center ? center() : <div className="back-header-title">{title}</div>}
      {/* 右侧 */}
      {right ? (
        right()
      ) : (
        <div className="back-header-right">
          <div className="back-header-right-box">
            {rightBtn ? rightBtn() : <></>}
          </div>
        </div>
      )}
    </div>
  );
};
