import React, { useEffect, useMemo, useState } from "react";

import UserStore from "../../store/user";
import BackHeader from "../backHeader";
import ScrollArea from "../scrollarea";
import Simg from '../simg';
import NoData from '../noData';
import Loading from '../loading';
import { apiPrivilegeList } from '../../libs/http';
import Emit from "../../libs/eventEmitter";

import iconUper from "../../resources/img/index/upIcon.png";
import iconCreator from "../../resources/img/index/creator.png";
import iconFans from "../../resources/img/index/fans.png";
import vipNot from "../../resources/img/index/vip_not.png";
import vipMonth from "../../resources/img/index/vip_month.png";
import vipJi from "../../resources/img/index/vip_ji.png";
import vipYear from "../../resources/img/index/vip_year.png";
import vipForever from "../../resources/img/index/vip_forever.png";

export default (props) => {
  const { stackKey } = props;
  const [user] = UserStore.useGlobalState("user");
  const [loading, setLoading] = useState(true);
  const [list, setList] = useState([]);
  const getInfo = async () => {
    try {
      const res = await apiPrivilegeList();
      if (res?.status) {
        setList(res?.data?.privilege || []);
      } else {
        Emit.emit("showToast", {
          text: "特权信息请求失败，请重试",
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败，请重试",
      });
    }
    setLoading(false);
  };
  useEffect(() => {
    getInfo();
  }, []);

  // 用户信息
  const setUserInfoItem = () => {
    let levelImg = vipNot;
    switch (user?.vip_level) {
      case 1:
        levelImg = vipMonth;
        break;
      case 2:
        levelImg = vipJi;
        break;
      case 3:
        levelImg = vipYear;
        break;
      case 4:
        levelImg = vipForever;
        break;
      default:
        levelImg = vipNot;
        break;
    }
    if (user?.vip_level > 4) {
      levelImg = vipForever;
    }
    // 设置头部标记
    const setHeadMark = () => {
      let icon = null;
      switch (user?.role_id) {
        case 16:
          icon = iconUper;
          break;
        case 17:
          icon = iconCreator;
          break;
        default:
          icon = '';
          break;
      }
      return (icon ? <div className="mark-box"><img src={icon} /></div> : <></>);
    };
    return (
      <div className="user-recharge-box">
        <div className="user-recharge-row">
          <div className="user-recharge-head">
            <Simg src={user?.thumb} />
            {setHeadMark()}
          </div>
          <div className="user-recharge-info">
            <div className="user-recharge-info-title">{user?.nickname}</div>
            <div className="user-recharge-info-level">
              {levelImg ? <img src={levelImg} /> : <></>}
              {user?.is_club ? <img src={iconFans} /> : <></>}
            </div>
          </div>
        </div>
      </div>
    );
  };
  return useMemo(() => (
    <div className="positioned-container user-public-bg">
      <BackHeader
        stackKey={stackKey}
        title="会员专属特权"
      />
      {
        loading ? (
          <Loading show type={1} />
        ) : (
          <ScrollArea>
            <div className="user-vip-descript">
              {setUserInfoItem()}
              <p className="user-vip-descript-title">·会员专属特权·</p>
              {
                list?.length ? (
                  list.map((item, index) => (
                    <div
                      key={`user-vip-descript-item-${index}`}
                      className="user-vip-descript-item"
                    >
                      <div className="icon">
                        <Simg className="icon" src={item?.img_url} />
                      </div>
                      <div className="info">
                        <div className="title">
                          {item?.title}
                        </div>
                        <div className="subtitle">
                          {item?.description}
                        </div>
                      </div>
                    </div>
                  ))
                ) : <NoData />
              }
            </div>
            )
          </ScrollArea>
        )
      }
    </div>
  ), [user, loading, list]);
};
