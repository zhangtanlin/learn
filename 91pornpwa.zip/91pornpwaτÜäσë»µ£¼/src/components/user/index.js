/*
 * @Author: Tom
 * @Date: 2021-11-15 20:48:32
 * @LastEditTime: 2021-12-08 16:33:11
 * @LastEditors: Tom
 * @Description:
 * @FilePath: /91pornpwa/src/components/user/index.js
 */
import React, { useEffect, useMemo, useRef, useState, useImperativeHandle } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import StackStore from "../../store/stack";
import StackPage from "../stackpage";
import ScrollArea from "../scrollarea";
import ClickBtn from "../clickbtn";
import UserStore from "../../store/user";
import Set from "./set";
import Simg from "../simg";
import Tabs from "./tabs";
import BindPhone from "./bindPhoneNew";
import MyShare from "./myShare";
import BuyCoins from "./buyCoins";
import Recharge from "./recharge";
import MakeMoney from "./makeMoney";
import MyRelated from "./myRelated";
import MyClub from "./myClub";
import NoData from "../noData";
import Account from "./account";
import Loading from "../loading";
import ShortVideoList from "../index/shortVideoList";
import Emit from "../../libs/eventEmitter";
import {
  getMyInfo,
  apiVideoList,
  getLikeList,
  getBuyList,
  apiGetClubVideos
} from '../../libs/http';

import iconUper from "../../resources/img/index/upIcon.png";
import iconCreator from "../../resources/img/index/creator.png";
import iconFans from "../../resources/img/index/fans.png";
import vipNot from "../../resources/img/index/vip_not.png";
import vipMonth from "../../resources/img/index/vip_month.png";
import vipJi from "../../resources/img/index/vip_ji.png";
import vipYear from "../../resources/img/index/vip_year.png";
import vipForever from "../../resources/img/index/vip_forever.png";

import bgUser from '../../resources/img/user/bg_user.png';

import iconLocation from "../../resources/img/public/icon_location.png";

import iconActiveShare from "../../resources/img/user/icon_active_share.png";
import iconActiveCoins from "../../resources/img/user/icon_active_coins.png";
import iconActiveDiamond from "../../resources/img/user/icon_active_diamond.png";
import iconActiveWallet from "../../resources/img/user/icon_active_wallet.png";
import iconActiveGroup from "../../resources/img/user/icon_active_group.png";

// import iconActiveShare from "../../resources/img/user/mine.png";
// import iconActiveCoins from "../../resources/img/user/mine1.png";
// import iconActiveDiamond from "../../resources/img/user/mine2.png";
// import iconActiveWallet from "../../resources/img/user/mine3.png";
// import iconActiveGroup from "../../resources/img/user/mine4.png";

import iconCheckedWhite from '../../resources/img/public/icon_detail_smart_checked_white.png';
import iconPlayNum from '../../resources/img/public/icon_play_num_tag.png';

/**
 * 列表（含有喜欢数量/播放次数）
 * @param {*} props.isFans 是否是粉丝专属
 */
export const UserVideoItem = (props) => {
  const { list, item, page, isFans, uuid } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const handle = () => {
    let currentIndex = null;
    list.forEach((obj, index) => {
      if (obj?.id === item?.id) currentIndex = index;
    });
    const stackKey = `user-short-video-list-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "user-short-video-list",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <ShortVideoList
              stackKey={stackKey}
              list={list}
              _page={page}
              _current={currentIndex}
              pageUuid={uuid}
            />
          </StackPage>
        )
      }
    });
  };
  return useMemo(() => (
    <ClickBtn
      className="user-video-item"
      onTap={(e) => {
        e.stopPropagation()
        handle()
      }}
    >
      <div className="cover-box">
        <Simg src={item?.thumbImg} />
      </div>
      <div className="bottom-info">
        <div className="bottom-item">
          <img src={iconCheckedWhite} />
          {item?.like || 0}
        </div>
        <div className="bottom-item">
          <img src={iconPlayNum} />
          {item?.play_count || 0}
        </div>
      </div>
      {isFans ? (
        <div className="is-fans">
          粉丝专属
        </div>
      ) : <></>}
    </ClickBtn>
  ), [list, item, page]);
};

/**
 * 作品/喜欢/购买/粉丝专属列表
 * @param {*} props.show 是否显示/是否切换到当前页
 * @param {*} props.type 类型 {1: 作品, 2: 喜欢/点赞, 3: 购买, 4:粉丝专属}
 * @param {*} props.uuid 传uuid表示别人的，不传表示自己的
 */
export const UserVideoList = (props) => {
  const { show, type, uuid, handleRefresh } = props;
  const [init, setInit] = useState(false);
  const [loading, setLoading] = useState(true);
  const [params, setParams] = useState({
    page: 1,
    isAll: false,
  });
  const [data, setData] = useState([]);
  const [loadingMore, setLoadingMore] = useState(true);

  useEffect(() => {
    Emit.on("refresh",()=>{
      refreshAll()
    })
  
    return () => {
      Emit.off("refresh")
    }
  }, [])

  const refreshAll = async () => {
    setParams((prev) => ({
      ...prev,
      ...{ page: 1, },
      ...{ isAll: false }
    }));
    setData([])
    const tempParam = { ...params, uuid };
    let res = null;
    let tempDate = [];
    switch (type) {
      case 2:
          res = await getLikeList(tempParam);
          tempDate = res?.data || [];
          break;
        case 3:
          res = await getBuyList(tempParam);
          tempDate = res?.data || [];
          break;
      default:
        break;
    }
    if (res?.status) {
      if (params?.page === 1) {
        setData(tempDate);
      } else {
        setData(prev => [...prev, ...tempDate]);
      }
      if (!tempDate?.length) {
        setParams({ ...params, isAll: true });
      }
    } else {
      Emit.emit("showToast", {
        text: "请求列表失败",
        time: 3000
      });
    }
  }

  const getData = async () => {
    if (params?.isAll) {
      return;
    }
    // setLoadingMore(true);
    try {
      const tempParam = { ...params, uuid };
      let res = null;
      let tempDate = [];
      switch (type) {
        case 1:
          res = await apiVideoList(tempParam);
          tempDate = res?.data || [];
          break;
        case 2:
          res = await getLikeList(tempParam);
          tempDate = res?.data || [];
          break;
        case 3:
          res = await getBuyList(tempParam);
          tempDate = res?.data || [];
          break;
        case 4:
          res = await apiGetClubVideos(tempParam);
          tempDate = res?.data?.item || [];
          break;
        default:
          break;
      }
      if (res?.status) {
        if (params?.page === 1) {
          setData(tempDate);
        } else {
          setData(prev => [...prev, ...tempDate]);
        }
        if (!tempDate?.length) {
          setParams({ ...params, isAll: true });
        }
      } else {
        Emit.emit("showToast", {
          text: "请求列表失败",
          time: 3000
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败，请重试",
        time: 3000
      });
    }
    setLoading(false);
    setLoadingMore(false);
    handleRefresh && handleRefresh(true);
  };
  const nextPage = () => {
    if (!params?.isAll) {
      setParams((prev) => ({
        ...prev,
        ...{ page: prev.page + 1 }
      }));
    }
  };
  useEffect(() => {
    if (show) {
      setInit(true);
    }
  }, [show]);
  useEffect(() => {
    if (init) {
      getData();
    }
  }, [init, params,]);

  return useMemo(() => (
    loading ? (
      <div className="user-video-loading">数据加载中...</div>
    ) : (
      data?.length > 0 ? (
        <ScrollArea
          ListData={data?.length}
          loadingMore={loadingMore}
          onScrollEnd={nextPage}
          groupId="mine"
        >
          <div className="user-video-list">
            {data?.map((item, index) => (
              <UserVideoItem
                key={`user-video-item-${index}`}
                list={data}
                item={item}
                page={params?.page}
                isFans={type === 4}
                uuid={uuid}
              />
            ))}
          </div>
        </ScrollArea>
      ) : <NoData />
    )
  ), [loading, data, loadingMore]);
};

export default (props) => {
  const { isVisible, uuid } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  // const [user] = UserStore.useGlobalState("user");
  const [refresh, setRefresh] = useState(false);
  const [init, setInit] = useState(false);
  const [user, setUser] = useState({})
  const contentRef = useRef(null); // 外部滚动盒子
  const tabRef = useRef(null); // 内部选项卡盒子
  // console.log(user)
  const activeList = [
    {
      name: "分享得无限",
      icon: iconActiveShare,
      onTap: () => {
        const stackKey = `user-share-${new Date().getTime()}`;
        StackStore.dispatch({
          type: "push",
          payload: {
            name: "user-share",
            element: (
              <StackPage
                stackKey={stackKey}
                key={stackKey}
                style={{ zIndex: stacks.length + 2 }}
              >
                <MyShare stackKey={stackKey} />
              </StackPage>
            ),
          },
        });
      },
    },
    {
      name: "金币充值",
      icon: iconActiveCoins,
      onTap: () => {
        const stackKey = `user-buy-coins-${new Date().getTime()}`;
        StackStore.dispatch({
          type: "push",
          payload: {
            name: "user-buy-coins",
            element: (
              <StackPage
                stackKey={stackKey}
                key={stackKey}
                style={{ zIndex: stacks.length + 2 }}
              >
                <BuyCoins stackKey={stackKey} />
              </StackPage>
            ),
          },
        });
      },
    },
    {
      name: "VIP充值",
      icon: iconActiveDiamond,
      onTap: () => {
        const stackKey = `user-buy-coins-${new Date().getTime()}`;
        StackStore.dispatch({
          type: "push",
          payload: {
            name: "user-buy-coins",
            element: (
              <StackPage
                stackKey={stackKey}
                key={stackKey}
                style={{ zIndex: stacks.length + 2 }}
              >
                <Recharge stackKey={stackKey} />
              </StackPage>
            ),
          },
        });
      },
    },
    {
      name: "代理赚钱",
      icon: iconActiveWallet,
      onTap: () => {
        const stackKey = `user-make-money-${new Date().getTime()}`;
        StackStore.dispatch({
          type: "push",
          payload: {
            name: "user-make-money",
            element: (
              <StackPage
                stackKey={stackKey}
                key={stackKey}
                style={{ zIndex: stacks.length + 2 }}
              >
                <MakeMoney stackKey={stackKey} />
              </StackPage>
            ),
          },
        });
      },
    },
    {
      name: "加官方群",
      icon: iconActiveGroup,
      onTap: () => {
        if (user?.tikUrl) {
          window.open(user?.tikUrl, "_blank");
        }
      },
    },
  ];
  const infoList = [
    {
      name: '粉丝',
      num: user?.fans || 0,
      onTap: () => {
        const stackKey = `user-related-${new Date().getTime()}`;
        StackStore.dispatch({
          type: "push",
          payload: {
            name: "user-related",
            element: (
              <StackPage
                stackKey={stackKey}
                key={stackKey}
                style={{ zIndex: stacks.length + 2 }}
              >
                <MyRelated stackKey={stackKey} type={1} />
              </StackPage>
            ),
          },
        });
      }
    },
    {
      name: '关注',
      num: user?.followed || 0,
      onTap: () => {
        const stackKey = `user-related-${new Date().getTime()}`;
        StackStore.dispatch({
          type: "push",
          payload: {
            name: "user-related",
            element: (
              <StackPage
                stackKey={stackKey}
                key={stackKey}
                style={{ zIndex: stacks.length + 2 }}
              >
                <MyRelated stackKey={stackKey} />
              </StackPage>
            ),
          },
        });
      }
    },
    {
      name: '被赞',
      num: user?.fabulous || 0,
      onTap: () => { }
    },
    {
      name: '粉丝团',
      num: user?.joined_club_count || 0,
      onTap: () => {
        const stackKey = `user-related-${new Date().getTime()}`;
        StackStore.dispatch({
          type: "push",
          payload: {
            name: "user-related",
            element: (
              <StackPage
                stackKey={stackKey}
                key={stackKey}
                style={{ zIndex: stacks.length + 2 }}
              >
                <MyClub stackKey={stackKey} />
              </StackPage>
            ),
          },
        });
      }
    },
  ];
  // 喜欢/购买
  const navList = [
    {
      name: '喜欢',
      count: user?.likesCount || 0,
    },
    {
      name: '购买',
      count: user?.buy_count || 0,
    },
  ];
  const [currentTab, setCurrentTab] = useState(0);
  const [controlledSwiper, setControlledSwiper] = useState(null);

  useEffect(() => {
    if (isVisible && !user.phone && init) {
      Emit.emit("showToast", { text: "请登录或注册,以免账号丢失无法找回！" });
    }
    if (isVisible && !init) {
      getMyInfo().then((userData) => {
        if (userData.status && userData.data && userData.data.info) {
          // console.log("用户信息", userData?.data?.info);
          if (userData?.status) {
            const tempObject = {
              ...userData?.data?.info,
            }; // 字段说明参考userStore
            setUser(tempObject)
            UserStore.dispatch({
              type: "replace",
              payload: tempObject,
            });
          }
        }
        setInit(true);
      })
    }
  }, [isVisible]);
  // 下拉刷新
  const handleRefresh = async () => {
    setRefresh(true);
    try {
      const res = await getMyInfo();
      if (res?.status) {
        const tempObject = {
          ...res?.data?.info,
        }; // 字段说明参考userStore
        UserStore.dispatch({
          type: "replace",
          payload: tempObject,
        });
        setCurrentTab(0)
        controlledSwiper && controlledSwiper.slideTo(0);
        Emit.emit("refresh")
      } else {
        Emit.emit("showToast", {
          text: "请求个人信息失败",
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败，请重试",
      });
    }
  };
  // 设置
  const handleSite = () => {
    if (user?.phone) {
      const stackKey = `user-set-${new Date().getTime()}`;
      StackStore.dispatch({
        type: "push",
        payload: {
          name: "user-set",
          element: (
            <StackPage
              stackKey={stackKey}
              key={stackKey}
              style={{ zIndex: stacks.length + 2 }}
            >
              <Set stackKey={stackKey} />
            </StackPage>
          ),
        },
      });
    } else {
      toLogin();
    }
  };
  const toLogin = () => {
    const stackKey = `BindPhone-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "bindPhone",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <BindPhone stackKey={stackKey} />
          </StackPage>
        ),
      },
    });
  };
  // 头像操作
  const handleHead = () => {
    const stackKey = `user-head-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "user-head",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            {
              user?.phone ?
                <Account stackKey={stackKey} /> :
                <BindPhone stackKey={stackKey} />
            }
          </StackPage>
        ),
      },
    });
  };
  // 用户信息
  const setVipLevel = () => {
    let levelImg = vipNot;
    switch (user?.vip_level) {
      case 1:
        levelImg = vipMonth;
        break;
      case 2:
        levelImg = vipJi;
        break;
      case 3:
        levelImg = vipYear;
        break;
      case 4:
        levelImg = vipForever;
        break;
      default:
        levelImg = vipNot;
        break;
    }
    if (user?.vip_level > 4) {
      levelImg = vipForever;
    }
    return (
      <div className="user-info-level">
        <img src={levelImg} />
        {user?.club_id > 0 ? <img src={iconFans} /> : <></>}
      </div>
    );
  };
  // 上拉吸顶
  useEffect(() => {
    if (!contentRef.current || !tabRef.current) return;
    tabRef.current.setAttribute(
      "style",
      `height:${contentRef.current.clientHeight}px`
    );
  }, [contentRef.current, tabRef.current]);
  // 设置头部标记
  const setHeadMark = () => {
    let icon = null;
    switch (user?.role_id) {
      case 16:
        icon = iconUper;
        break;
      case 17:
        icon = iconCreator;
        break;
      default:
        icon = '';
        break;
    }
    return (icon ? <div className="mark-box"><img src={icon} /></div> : <></>);
  };
  return useMemo(() => (
    <div
      className={`positioned-container user-public-bg ${isVisible ? "visible" : "hide"}`}
      style={{
        opacity: isVisible ? "1" : "0",
      }}
    >
      {init ?
        <div
          ref={contentRef}
          className="full-column"
        >
          <ScrollArea pullDonRefresh={() => handleRefresh()} groupId="mine">
            <ClickBtn
              className="user-head-btn"
              onTap={() => handleSite()}
            />
            <div className="user-top">
              <div className="user-top-img">
                <img src={bgUser} />
              </div>
              <div className="user-top-info">
                <ClickBtn
                  className="user-info-head"
                  onTap={() => handleHead()}
                >
                  <Simg src={user?.thumb} />
                  {setHeadMark()}
                </ClickBtn>
                <div className="user-info-box">
                  <div className="user-info-box-row">
                    <div className="user-info-box-nickname"><p className="user-info-title">{user?.nickname}</p></div>
                    <div>{setVipLevel()}</div>
                  </div>
                  {/* <p className="user-info-subtitle">{user?.watchStr}</p> */}
                  <div className="user-info-box-row">
                    {!user.phone && <ClickBtn className="user-info-box-bind" onTap={() => { toLogin() }}>登录/注册</ClickBtn>}
                    <ClickBtn className="user-info-box-bind" onTap={() => { Emit.emit("showToast", { text: "请在电脑或安卓端上传" }); }}>上传视频</ClickBtn>
                  </div>
                </div>
              </div>
              <div className="user-top-count">
                {infoList.map((item, index) => (
                  <ClickBtn
                    key={`user-top-count-item-${index}`}
                    className="user-top-count-item"
                    onTap={() => item?.onTap()}
                  >
                    <div className="title">{item?.num}</div>
                    <div className="subtitle">{item?.name}</div>
                  </ClickBtn>
                ))}
              </div>
              <div className="user-top-user">
                <img src={iconLocation} />
                <div className="title">{user?.city || '暂无'}</div>
                <div className="title">{user?.age || 0}岁</div>
                <div className="title">91号:{user?.aff_num}</div>
              </div>
              <div className="user-top-desc">
                {user?.person_signnatrue || '这家伙很懒，什么都没有留下！'}
              </div>
            </div>
            <div className="user-active-box">
              {activeList.map((item, index) => (
                <ClickBtn
                  key={`user-active-item-${index}`}
                  className="user-active-item"
                  onTap={() => item.onTap()}
                >
                  <img className="user-active-icon" src={item.icon} />
                  <p className="user-active-title">{item.name}</p>
                </ClickBtn>
              ))}
            </div>
            <div className="user-tab-swiper" ref={tabRef}>
              <Tabs
                navItems={navList}
                currentIndex={currentTab}
                onChangeTab={(index) => {
                  setCurrentTab(index);
                  controlledSwiper && controlledSwiper.slideTo(index);
                }}
              />
              <div className="user-tab-swiper-content">
                <Swiper
                  className="user-swiper"
                  initialSlide={0}
                  controller={controlledSwiper}
                  onSwiper={setControlledSwiper}
                  autoplay={false}
                  onSlideChange={e => {
                    setCurrentTab(e.realIndex);
                  }}
                >
                  {navList.map((item, index) => (
                    <SwiperSlide key={`user-swiper-${index}`}>
                      <UserVideoList
                        show={currentTab === index}
                        type={index + 2}
                        refresh={refresh}
                        handleRefresh={setRefresh}
                        uuid={uuid}
                      />
                    </SwiperSlide>
                  ))}
                </Swiper>
              </div>
            </div>
          </ScrollArea>
        </div> : <Loading />}
    </div>
  ), [isVisible, user, navList, init]);
};
