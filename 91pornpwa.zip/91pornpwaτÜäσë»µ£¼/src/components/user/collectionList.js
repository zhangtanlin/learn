import React, { useEffect, useMemo, useState } from "react";

import Emit from "../../libs/eventEmitter";
import ScrollArea from "../scrollarea";
import BackHeader from '../backHeader';
import Loading from '../loading';
import NoData from '../noData';
import { Heji } from '../index/search';
import { getCollectionList } from '../../libs/http';

export default (props) => {
  const { stackKey, uuid } = props;
  const [loading, setLoading] = useState(true);
  const [loadMore, setLoadMore] = useState(true);
  const [page, setPage] = useState(1);
  const size = 10;
  const [list, setList] = useState([]);
  const getList = async () => {
    setLoadMore(true);
    try {
      const tempParam = {
        page,
        size,
        uuid,
      };
      const res = await getCollectionList(tempParam);
      if (res?.status) {
        if (page === 1) {
          setList(res?.data);
        } else {
          setList([...list, ...res?.data]);
        }
      } else {
        Emit.emit("showToast", {
          text: "请求列表失败",
          time: 3000
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败，请重试",
        time: 3000
      });
    }
    setLoading(false);
    setLoadMore(false);
  };
  const loadMoreData = async () => {
    setPage((page) => (page + 1));
  };
  useEffect(() => {
    getList();
  }, [page]);

  return useMemo(() => (
    <div className="positioned-container user-public-bg">
      <BackHeader
        stackKey={stackKey}
        title="合集列表"
        right={() => <div style={{ width: '1.5rem', height: '0.1rem' }} />}
      />
      {
        loading ? (
          <Loading show type={1} />
        ) : (
          list?.length > 0 ? (
            <ScrollArea
              downRefresh={false}
              ListData={list}
              loadingMore={loadMore}
              onScrollEnd={loadMoreData}
            >
              <div style={{ padding: '0 .4rem .4rem .4rem' }}>
                {list.map((item, index) => (
                  <Heji
                    key={`user-recharge-List-item-${index}`}
                    data={item}
                  />
                ))}
              </div>
            </ScrollArea>
          ) : (
            <NoData />
          )
        )
      }
    </div>
  ), [loading, loadMore, list]);
};
