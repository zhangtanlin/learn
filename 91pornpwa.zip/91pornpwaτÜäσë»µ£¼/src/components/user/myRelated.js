import React, { useEffect, useMemo, useState } from "react";

import StackStore from "../../store/stack";
import StackPage from "../stackpage";
import BackHeader from '../backHeader';
import Loading from '../loading';
import NoData from '../noData';
import ScrollArea from "../scrollarea";
import ClickBtn from '../clickbtn';
import Simg from '../simg';
import Mine from './mine';
import Emit from "../../libs/eventEmitter";
import {
  apiMyFansList,
  apiMyFollowList,
  setFollowUser,
} from '../../libs/http';

export default (props) => {
  const { stackKey, type } = props; // type 类型 {null/空: 我的关注, 1: 我的粉丝,}
  const [stacks] = StackStore.useGlobalState("stacks");
  const [loading, setLoading] = useState(true);
  const [loadMore, setLoadMore] = useState(true);
  const [page, setPage] = useState(1);
  const limit = 10;
  const [list, setList] = useState([]);
  const getList = async () => {
    setLoadMore(true);
    try {
      setLoadMore(true);
      const tempParam = { page, limit };
      let res = null;
      switch (type) {
        case 1:
          res = await apiMyFansList(tempParam);
          break;
        default:
          res = await apiMyFollowList(tempParam);
          break;
      }
      if (res?.status) {
        if (page === 1) {
          setList(res?.data);
        } else {
          setList([...list, ...res?.data]);
        }
      } else {
        Emit.emit("showToast", {
          text: "请求列表失败",
          time: 3000
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败，请重试",
        time: 3000
      });
    }
    setLoading(false);
    setLoadMore(false);
  };
  // 查看详情
  const handleDetail = (uuid) => {
    if (uuid) {
      const stackKey = `user-main-${new Date().getTime()}`;
      StackStore.dispatch({
        type: "push",
        payload: {
          name: "user-main",
          element: (
            <StackPage
              stackKey={stackKey}
              key={stackKey}
              style={{ zIndex: stacks.length + 2 }}
            >
              <Mine stackKey={stackKey} uuid={uuid} />
            </StackPage>
          ),
        },
      });
    }
  };
  // 点击操作
  const handle = async (uuid) => {
    if (uuid) {
      try {
        const res = await setFollowUser({ uuid });
        if (res?.status) {
          const tempList = list.map((item) => {
            if (item?.uuid === uuid) {
              item.doubleFollow = !item.doubleFollow;
            }
            return item;
          });
          setList(tempList);
          Emit.emit("showToast", {
            text: res?.data?.msg || "操作成功",
          });
          setPage(1); // 刷洗页面
        } else {
          Emit.emit("showToast", {
            text: res?.data?.msg || "操作失败",
          });
        }
      } catch (error) {
        Emit.emit("showToast", {
          text: "请求失败，请重试",
        });
      }
    }
  };
  const itemFn = (item, index) => {
    let text = '';
    let tempClass = '';
    if (item?.doubleFollow) {
      text = '已关注';
      tempClass = 'active';
    } else {
      text = '关注';
      tempClass = '';
    }
    return (
      <ClickBtn
        key={`user-related-item-${index}`}
        className="user-related-item"
        onTap={() => handleDetail(item?.uuid)}
      >
        <div className="avatar">
          <Simg src={item?.thumb} />
        </div>
        <div className="info">
          <div className="title">{item?.nickname}</div>
        </div>
        <ClickBtn
          className={`btn ${tempClass}`}
          onTap={() => handle(item?.uuid)}
        >
          {text}
        </ClickBtn>
      </ClickBtn>
    );
  };
  const setHeadText = () => {
    let text = null;
    switch (type) {
      case 1:
        text = '我的粉丝';
        break;
      default:
        text = '我的关注';
        break;
    }
    return text;
  };
  const loadMoreData = async () => {
    setPage((page) => (page + 1));
  };
  useEffect(() => {
    getList();
  }, [page, limit]);
  return useMemo(() => (
    <div className="positioned-container user-public-bg">
      <BackHeader
        stackKey={stackKey}
        title={setHeadText()}
      />
      {
        loading ? (
          <Loading show type={1} />
        ) : (
          list?.length > 0 ? (
            <ScrollArea
              loadingMore={loadMore}
              onScrollEnd={loadMoreData}
            >
              {list.map((item, index) => itemFn(item, index))}
            </ScrollArea>
          ) : (
            <NoData />
          )
        )
      }
    </div>
  ), [loading, loadMore, list]);
};
