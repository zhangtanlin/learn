import React, { useEffect, useMemo, useState } from "react";

import StackStore from "../../store/stack";
import UserStore from "../../store/user";
import StackPage from "../stackpage";
import BackHeader from "../backHeader";
import ScrollArea from "../scrollarea";
import ClickBtn from "../clickbtn";
import Simg from '../simg';
import NoData from '../noData';
import Loading from '../loading';
import RechargeList from "./rechargeList";
import VipDescript from "./vipDescript";
import Emit from "../../libs/eventEmitter";
import { SetPayWay } from "./buyCoins";
import { getProductList } from '../../libs/http';

import iconUper from "../../resources/img/index/upIcon.png";
import iconCreator from "../../resources/img/index/creator.png";
import iconFans from "../../resources/img/index/fans.png";
import vipNot from "../../resources/img/index/vip_not.png";
import vipMonth from "../../resources/img/index/vip_month.png";
import vipJi from "../../resources/img/index/vip_ji.png";
import vipYear from "../../resources/img/index/vip_year.png";
import vipForever from "../../resources/img/index/vip_forever.png";

import iconPlay from "../../resources/img/user/icon_recharge_play.png";
import iconChat from "../../resources/img/user/icon_recharge_chat.png";
import iconLove from "../../resources/img/user/icon_recharge_love.png";
import iconBoth from "../../resources/img/user/icon_recharge_both.png";

export default (props) => {
  const { stackKey } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const [user] = UserStore.useGlobalState("user");
  const [loading, setLoading] = useState(true);
  const [list, setList] = useState([]);
  const [showLayer, setShowLayer] = useState(false);
  const [payWayList, setPayWayList] = useState([]);

  const descList = [
    { name: '视频特权', icon: iconPlay, },
    { name: '私聊特权', icon: iconChat, },
    { name: '社区特权', icon: iconLove, },
    { name: '互动特权', icon: iconBoth, },
  ];

  // 用户信息
  const setUserInfoItem = () => {
    let levelImg = vipNot;
    switch (user?.vip_level) {
      case 1:
        levelImg = vipMonth;
        break;
      case 2:
        levelImg = vipJi;
        break;
      case 3:
        levelImg = vipYear;
        break;
      case 4:
        levelImg = vipForever;
        break;
      default:
        levelImg = vipNot;
        break;
    }
    if (user?.vip_level > 4) {
      levelImg = vipForever;
    }
    // 设置头部标记
    const setHeadMark = () => {
      let icon = null;
      switch (user?.role_id) {
        case 16:
          icon = iconUper;
          break;
        case 17:
          icon = iconCreator;
          break;
        default:
          icon = '';
          break;
      }
      return (icon ? <div className="mark-box"><img src={icon} /></div> : <></>);
    };
    return (
      <div className="user-recharge-box">
        <div className="user-recharge-row">
          <div className="user-recharge-head">
            <Simg src={user?.thumb} />
            {setHeadMark()}
          </div>
          <div className="user-recharge-info">
            <div className="user-recharge-info-title">{user?.nickname}</div>
            <div className="user-recharge-info-level">
              {levelImg ? <img src={levelImg} /> : <></>}
              {user?.is_club ? <img src={iconFans} /> : <></>}
            </div>
          </div>
        </div>
        <div className="title-box">
          <p className="title">会员专属特权</p>
          <ClickBtn
            className="subtitle"
            onTap={() => handleVipDescript()}
          >
            查看更多会员特权
          </ClickBtn>
        </div>
        <div className="list">
          {
            descList.map((item, index) => (
              <div
                key={`recharge-dec-item-box-${index}`}
                className="item"
              >
                <img src={item.icon} />
                <p className="text">{item.name}</p>
              </div>
            ))
          }
        </div>
      </div>
    );
  };
  // 产品列表
  const productList = async () => {
    try {
      const params = {
        type: 1,
        pay_type: 'online',
      };
      const res = await getProductList(params);
      if (res?.status && res?.data?.lists?.length) {
        res?.data?.lists?.map((item) => {
          const product_id = item?.id;
          const product_name = item?.pname;
          const product_coins = item?.coins;
          const product_price = item?.promo_price;
          item?.pMethods.map((obj) => {
            obj.product_coins = product_coins;
            obj.product_price = product_price;
            obj.product_id = product_id;
            obj.product_name = product_name;
            obj.pay_type = 'online';
            return obj;
          });
          return item;
        });
        setList(res?.data?.lists);
      } else {
        Emit.emit("showToast", {
          text: '获取产品列表失败'
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: '请求失败，请重试'
      });
    }
    setLoading(false);
  };
  useEffect(() => {
    productList();
  }, []);
  // 选择产品
  const handleChooseProduct = (product) => {
    setPayWayList(product?.pMethods);
    setShowLayer(true);
  };
  // 充值明细
  const handleRecharge = () => {
    const stackKey = `user-recharge-list-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "user-recharge-list",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <RechargeList stackKey={stackKey} type={1} />
          </StackPage>
        )
      }
    });
  };
  // 查看会员特权
  const handleVipDescript = () => {
    const stackKey = `user-vip-descript-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "user-vip-descript",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <VipDescript stackKey={stackKey} />
          </StackPage>
        )
      }
    });
  };
  return useMemo(() => (
    <div className="positioned-container user-public-bg">
      <BackHeader
        stackKey={stackKey}
        title="VIP会员"
        rightBtn={() => (
          <ClickBtn
            className="user-header-btn white"
            onTap={() => handleRecharge()}
          >
            充值明细
          </ClickBtn>
        )}
      />
      {
        loading ? (
          <Loading show type={1} />
        ) : (
          <ScrollArea>
            <div className="user-recharge-content">
              {setUserInfoItem()}
              {
                list.length ? (
                  list.map((item, index) => (
                    <ClickBtn
                      key={`user-recharge-card-${index}`}
                      className="user-recharge-card"
                      onTap={() => handleChooseProduct(item)}
                    >
                      <div className="user-recharge-card-img">
                        <Simg src={item?.img} />
                      </div>
                      <div className="user-recharge-card-item">
                        <div className="user-recharge-card-info">
                          <div className="user-recharge-card-title">
                            {item?.pname}
                          </div>
                          <div className="user-recharge-card-text">
                            {item?.description}
                          </div>
                        </div>
                        <div className="user-recharge-card-price">
                          <div className="user-recharge-card-text">
                            ¥
                            <span className="user-recharge-card-text-big">
                              {item?.promo_price}
                            </span>
                          </div>
                          <div className="user-recharge-card-text user-recharge-card-line">
                            原价${item?.price}
                          </div>
                        </div>
                      </div>
                    </ClickBtn>
                  ))
                ) : <NoData />
              }
            </div>
          </ScrollArea>
        )
      }
      <SetPayWay
        list={payWayList}
        show={showLayer}
        onChange={setShowLayer}
      />
    </div>
  ), [user, loading, list, showLayer, payWayList]);
};
