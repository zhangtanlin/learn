import React, { useState } from "react";
import "swiper/swiper.min.css";
import UserStore from "../../store/user";
import globalVar from '../../libs/globalVar';
import ClickBtn from '../clickbtn';
import Emit from "../../libs/eventEmitter";
import { accountLogin } from '../../libs/http'
import logos from '../../resources/img/index/icon_share_top_logo.png';

export default (props) => {
  const { stackKey } = props;
  const [swich, setSwich] = useState(true);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const onSubmit = (type) => {
    if (!username) {
      Emit.emit("showToast", {
        text: "请输入账号或手机号"
      });
      return
    }
    if (!password) {
      Emit.emit("showToast", {
        text: "请输入密码"
      });
      return
    }
    try {
      accountLogin({ account: username, password, type: type }).then(res => {
        if (res?.status) {
          Emit.emit("showToast", {
            text: type == "reg" ? "注册成功" : "登录成功",
            time: 3000
          });
          globalVar.firstData = null;
          window.location.reload();
        } else {
          Emit.emit("showToast", {
            text: res?.msg || "登录失败",
            time: 3000
          });
        }
      }).catch(() => {
        Emit.emit("showToast", {
          text: "请求超时，请重试",
          time: 3000
        });
      });
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败，请重试",
        time: 3000
      });
    }
  }

  return (
    <div className="login-new-container">
      <ClickBtn className="login-new-close" onTap={() => {
        Emit.emit(stackKey, stackKey);
      }} />
      <div className="login-new-content">
        <div className="login-new-header">
          <div className="logo"><img src={logos} /></div>
          <div className="title">欢迎来到91短视频</div>
        </div>
        <div className="login-new-input">
          <input type="text" placeholder="请输入帐号或手机号" onChange={({ target }) => {
            setUsername(target.value)
          }} />
        </div>
        <div className="login-new-input row">
          <input type={swich ? 'password' : 'text'} placeholder="请输入密码" onChange={({ target }) => {
            setPassword(target.value)
          }} />
          <ClickBtn onTap={() => { setSwich(!swich) }} className={swich ? "login-new-eye active" : "login-new-eye"} />
        </div>
        <div className="login-new-button">
          <ClickBtn className="login-new-action" onTap={() => { onSubmit('reg') }}>注册</ClickBtn>
          <div style={{ width: '1.5rem' }}></div>
          <ClickBtn className="login-new-action" onTap={() => { onSubmit('login') }}>登录</ClickBtn>
        </div>
        <div className="login-new-tips">
          <div>提示</div>
          <p>1.请务必记住自己的帐号密码</p>
          <p>2.不提供密码修改功能</p>
          <p>3.不提供密码找回功能</p>
        </div>
      </div>
    </div>
  )
}