import React, { useEffect, useMemo, useState } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/swiper.min.css";
import "swiper/components/pagination/pagination.min.css";

import Emit from "../../libs/eventEmitter";
import ScrollArea from "../scrollarea";
import BackHeader from '../backHeader';
import Loading from '../loading';
import Clickbtn from '../clickbtn'
import Simg from '../simg'
import NoData from '../noData';

import AppCard from '../card/appCard';
import { getApps } from '../../libs/http';

export default (props) => {
  const { stackKey } = props;
  const [loading, setLoading] = useState(true);
  const [loadMore, setLoadMore] = useState(true);
  const [listData, setList] = useState({});
  const [banner, setBanner] = useState([]);
  const getList = async () => {
    setLoadMore(true);
    try {
      const res = await getApps();
      if (res?.status) {
        const filterData = res?.data.filter(item=>item.type == "best")
        const bannerData = res?.data.filter(item=>item.type == "banner")
        if(filterData.length > 0){
          setList(filterData[0]);
        }
        if(bannerData.length > 0){
          setBanner(bannerData[0].items);
        }
      } else {
        Emit.emit("showToast", {
          text: "请求列表失败",
          time: 3000
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败，请重试",
        time: 3000
      });
    }
    setLoading(false);
  };

  useEffect(() => {
    getList();
  }, []);

  return useMemo(() => (
    <div className="positioned-container user-public-bg">
      <BackHeader
        stackKey={stackKey}
        title="应用中心"
        right={() => <div style={{ width: '1.5rem', height: '0.1rem' }} />}
      />
      {
        loading ? (
          <Loading show type={1} />
        ) : (
          listData?.items?.length > 0 ? (
            <ScrollArea
            pullDonRefresh={()=>{
                getList()
              }}
              ListData={listData}
            >
              <div>
                <Swiper
                  initialSlide={0}
                  className="featured-swiper"
                  noSwipingClass={"noSwiper-container"}
                  loop
                  autoplay={{
                    delay: 3000,
                    disableOnInteraction: false
                  }}
                >
                  {banner.map((item, index) => {
                    return <SwiperSlide key={`${item}-${index}`}>
                      <Clickbtn onTap={() => {
                         window.open(item.url,"_blank")
                      }}>
                        <Simg className="appCenter-banner-slide" src={item.banner} />
                      </Clickbtn>
                    </SwiperSlide>
                  })}
                </Swiper>
                <div className="appCenter-app-list-desc">{listData.desc}</div>
                {listData.items.map((item, index) => (
                  <AppCard
                    key={`user-recharge-List-item-${index}`}
                    data={item}
                  />
                ))}
              </div>
              <div style={{height: '30px'}}></div>
            </ScrollArea>
          ) : (
            <NoData />
          )
        )
      }
    </div>
  ), [loading, loadMore, banner, listData]);
};
