import React, { useEffect, useMemo, useState } from "react";

import StackStore from "../../store/stack";
import StackPage from "../stackpage";
import BackHeader from '../backHeader';
import Loading from '../loading';
import NoData from '../noData';
import ScrollArea from "../scrollarea";
import ClickBtn from '../clickbtn';
import Simg from '../simg';
import Mine from './mine';
import Emit from "../../libs/eventEmitter";
import { myJoinedClub } from '../../libs/http';

export default (props) => {
  const { stackKey } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const [loading, setLoading] = useState(true);
  const [loadMore, setLoadMore] = useState(true);
  const [page, setPage] = useState(1);
  const limit = 10;
  const [list, setList] = useState([]);
  const getList = async () => {
    setLoadMore(true);
    try {
      setLoadMore(true);
      const tempParam = { page, limit };
      let res = null;
      res = await myJoinedClub(tempParam);
      // console.log(res)
      if (res?.status) {
        if (page === 1) {
          setList(res?.data?.item);
        } else {
          setList([...list, ...res?.data?.item]);
        }
      } else {
        Emit.emit("showToast", {
          text: "请求列表失败",
          time: 3000
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败，请重试",
        time: 3000
      });
    }
    setLoading(false);
    setLoadMore(false);
  };
  // 查看详情
  const handleDetail = (uuid) => {
    if (uuid) {
      const stackKey = `user-main-${new Date().getTime()}`;
      StackStore.dispatch({
        type: "push",
        payload: {
          name: "user-main",
          element: (
            <StackPage
              stackKey={stackKey}
              key={stackKey}
              style={{ zIndex: stacks.length + 2 }}
            >
              <Mine stackKey={stackKey} uuid={uuid} />
            </StackPage>
          ),
        },
      });
    }
  };

  const clubItem = (item, index) => {
    return (
      <ClickBtn key={`user-club-item-${index}`} className="user-club-item-container" onTap={()=>{
        handleDetail(item?.user?.uuid)
      }}>
        <div className="avatar"><Simg src={item?.user?.thumb} /></div>
        <div>
          <div className="nickname">{item?.user?.nickname}</div>
          <div>粉丝团共{item?.club?.count}人</div>
        </div>
        <div className="join-time">{item?.joined_time}</div>
      </ClickBtn>
    );
  }

  const loadMoreData = async () => {
    setPage((page) => (page + 1));
  };
  useEffect(() => {
    getList();
  }, [page, limit]);

  return useMemo(() => (
    <div className="positioned-container user-public-bg">
      <BackHeader
        stackKey={stackKey}
        title="我加入的粉丝团"
      />
      {
        loading ? (
          <Loading show type={1} />
        ) : (
          list?.length > 0 ? (
            <ScrollArea
              loadingMore={loadMore}
              onScrollEnd={loadMoreData}
            >
              {list.map((item, index) => clubItem(item, index))}
            </ScrollArea>
          ) : (
            <NoData />
          )
        )
      }
    </div>
  ), [loading, loadMore, list]);
};
