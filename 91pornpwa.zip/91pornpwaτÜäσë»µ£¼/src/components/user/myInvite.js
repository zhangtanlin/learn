import React, { useEffect, useMemo, useState } from "react";

import ScrollArea from "../scrollarea";
import BackHeader from '../backHeader';
import CommonList, { CommonListHeader } from './commonList';
import Loading from '../loading';
import NoData from '../noData';

import { getInvitedLog } from '../../libs/http';
import Emit from "../../libs/eventEmitter";

// 推广记录
export default (props) => {
  const { stackKey } = props;

  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(true);
  const [params, setParams] = useState({
    page: 1,
    isAll: false,
  });
  const [data, setData] = useState([]);
  const headerList = [
    { name: '推广码', value: 'aff', },
    { name: '手机号', value: 'phone' },
    { name: '状态', value: 'status' },
  ];
  const getData = async () => {
    if (params?.isAll) {
      return;
    }
    setLoadingMore(true);
    try {
      const tempParam = { page: params?.page };
      const res = await getInvitedLog(tempParam);
      if (res?.status) {
        if (params?.page === 1) {
          setData(res?.data || []);
        } else {
          setData([...data, ...res?.data || []]);
        }
        if (!res?.data?.length) {
          setParams({ ...params, isAll: true });
        }
      } else {
        Emit.emit("showToast", {
          text: "请求列表失败",
          time: 3000
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败，请重试",
        time: 3000
      });
    }
    setLoading(false);
    setLoadingMore(false);
  };
  // 加载更多
  const nextPage = () => {
    if (!params?.isAll) {
      setParams((tempParam) => ({
        ...tempParam,
        page: tempParam?.page + 1
      }));
    }
  };
  useEffect(() => {
    getData();
  }, [params]);

  return useMemo(() => (
    <div className="positioned-container user-public-bg">
      <BackHeader
        stackKey={stackKey}
        title="邀请记录"
      />
      <CommonListHeader list={headerList} />
      {
        loading ? (
          <Loading show type={1} />
        ) : (
          <ScrollArea
            ListData={data?.length}
            loadingMore={loadingMore}
            onScrollEnd={nextPage}
          >
            {
              data?.length ? (
                data.map((item, index) => (
                  <CommonList
                    key={`user-invite-${index}`}
                    headerList={headerList}
                    item={item}
                  />
                ))
              ) : (<NoData />)
            }
          </ScrollArea>
        )
      }

    </div>
  ), [loading, loadingMore, data]);
};
