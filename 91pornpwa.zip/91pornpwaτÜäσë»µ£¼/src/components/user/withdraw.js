import React, { useMemo, useState, useEffect } from "react";

import StackPage from "../stackpage";
import StackStore from "../../store/stack";
import UserStore from '../../store/user';
import ScrollArea from "../scrollarea";
import BackHeader from '../backHeader';
import ClickBtn from '../clickbtn';
import GlobalVar from '../../libs/globalVar';
import Withdraw from './withdraw';

import Emit from "../../libs/eventEmitter";
import {
  getMyInfo,
  apiProxyWithdrawInfo,
  apiProxyWithdraw,
  apiUserWithdraw,
} from "../../libs/http";

export default (props) => {
  const { stackKey, type } = props; // type 类型{null: 代理提现, 1: 金币提现}
  const [stacks] = StackStore.useGlobalState("stacks");
  const [user] = UserStore.useGlobalState("user");
  const [ruleList, setRuleList] = useState(GlobalVar?.withdrawRules.split('#') || []); // 默认使用金币提现规则
  const [canWithdraw, setCanWithdraw] = useState(user?.coins || 0); // 默认使用金币的金额
  // 提现金额/银行卡/姓名
  const [params, setParams] = useState({
    number: '',
    bankCard: '',
    name: '',
  });
  // 代理提现时初始化信息【注意：只有代理提现才会请求这个接口，金币提现使用默认值（默认值是取的金币相关信息）】
  const init = async () => {
    if (type === 1) {
      return;
    }
    try {
      const res = await apiProxyWithdrawInfo();
      if (res?.status) {
        setCanWithdraw(res?.data?.money);
        if (res?.data?.withdraw_rules) {
          const tempArr = res?.data?.withdraw_rules.split('#');
          setRuleList(tempArr);
        }
      } else {
        Emit.emit("showToast", {
          text: "未获取提现额度",
          time: 3000
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "获取提现额度失败",
        time: 3000
      });
    }
  };
  // 用户信息
  const initMyInfo = async () => {
    try {
      const res = await getMyInfo();
      if (res?.status) {
        const tempObject = {
          ...res?.data?.info,
        }; // 字段说明参考userStore
        UserStore.dispatch({
          type: "replace",
          payload: tempObject,
        });
      } else {
        Emit.emit("showToast", {
          text: res?.msg || '更新用户信息失败',
          time: 3000
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: '请求失败，请重试',
        time: 3000
      });
    }
  };
  // 刷新当前页面
  const reload = () => {
    const stackKey = `user-withdraw-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "replace",
      payload: {
        name: "user-withdraw",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 1 }}
          >
            <Withdraw stackKey={stackKey} type={type} />
          </StackPage>
        ),
      },
    });
  };
  // 提现
  const withdraw = async () => {
    const reg = /^\s*$/g;
    if (Number(params.number) <= 0) {
      Emit.emit("showToast", {
        text: "请输入提现金额",
        time: 3000
      });
      return;
    }
    if (reg.test(params.bankCard)) {
      Emit.emit("showToast", {
        text: "请输入银行卡号",
        time: 3000
      });
      return;
    }
    if (reg.test(params.name)) {
      Emit.emit("showToast", {
        text: "请输入姓名",
        time: 3000
      });
      return;
    }
    try {
      const tempParams = {
        withdraw_account: params.bankCard,
        withdraw_name: params.name,
        withdraw_amount: params.number,
      };
      let res = null;
      if (type === 1) {
        res = await apiUserWithdraw(tempParams); // 金币提现
      } else {
        res = await apiProxyWithdraw(tempParams); // 代理提现
      }
      if (res?.status) {
        Emit.emit("showToast", {
          text: res?.data?.msg || "提现成功",
          time: 3000
        });
        initMyInfo();
        reload();
      } else {
        Emit.emit("showToast", {
          text: res?.msg || '提现失败',
          time: 3000
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败，请重试",
        time: 3000
      });
    }
  };

  useEffect(() => {
    init();
  }, []);

  return useMemo(() => (
    <div className="positioned-container user-public-bg">
      <BackHeader
        stackKey={stackKey}
        title={type ? '金币提现' : '代理提现'}
        right={() => <div style={{ width: '1.5rem', height: '0.1rem' }} />}
      />
      <ScrollArea>
        <div className="user-withdraw-content">
          <div className="user-withdraw-item">
            <div className="user-withdraw-key">
              {type ? '视频收益' : '代理收益'}
              <span className="user-withdraw-point">{canWithdraw || 0}</span>
              元
            </div>
          </div>
          <div className="user-input-box" style={{ marginBottom: '0.6rem' }}>
            <input
              type="number"
              placeholder="输入大于100的整数,单笔最大提取1万元"
              onInput={({ target }) => {
                const tempReplace = target.value.replace(/[^\d]/g, '');
                if (Number(tempReplace) > canWithdraw) {
                  const strTemp = String(tempReplace).substr(
                    0,
                    String(tempReplace).length - 1
                  );
                  target.value = Number(strTemp);
                  setParams({
                    ...params,
                    number: Number(strTemp),
                  });
                  Emit.emit("showToast", {
                    text: "当前输入大于可提现金额",
                    time: 3000
                  });
                } else {
                  target.value = Number(tempReplace);
                  setParams({
                    ...params,
                    number: Number(tempReplace),
                  });
                }
              }}
            />
          </div>
          <div className="user-withdraw-form">
            <div className="user-withdraw-key">
              银行卡
            </div>
            <div className="user-withdraw-value">
              <input
                type="number"
                placeholder="请输入银行卡号"
                onInput={({ target }) => {
                  const tempReplace = String(target.value).replace(/[^\d]/g, '');
                  if (tempReplace?.length > 19) {
                    const tempString = tempReplace.slice(0, 19);
                    target.value = tempString;
                    setParams({
                      ...params,
                      bankCard: tempString,
                    });
                  } else {
                    setParams({
                      ...params,
                      bankCard: tempReplace,
                    });
                  }
                }}
              />
            </div>
          </div>
          <div className="user-withdraw-form">
            <div className="user-withdraw-key">
              收款人
            </div>
            <div className="user-withdraw-value">
              <input
                type="text"
                placeholder="请输入收款人姓名"
                onChange={({ target }) => {
                  const tempReplace = target.value.replace(/^\s+|\s+$/g, '');
                  target.value = tempReplace;
                  setParams({
                    ...params,
                    name: tempReplace,
                  });
                }}
              />
            </div>
          </div>
          <div
            className="user-withdraw-item"
            style={{ marginTop: '0.75rem' }}
          >
            <div className="user-withdraw-key">
              提现规则
            </div>
          </div>
          {
            ruleList.length ? (
              ruleList.map((item, index) => (
                <div
                  key={`user-withdraw-subtitle-${index}`}
                  className="user-withdraw-subtitle"
                >
                  {item}
                </div>
              ))
            ) : <></>
          }
          <ClickBtn
            className="user-public-btn"
            onTap={() => withdraw()}
          >
            确认提现
          </ClickBtn>
        </div>
      </ScrollArea>
    </div>
  ), [ruleList, params, canWithdraw]);
};
