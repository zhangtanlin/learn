import React, { useEffect, useMemo, useState } from "react";

import StackStore from "../../store/stack";
import StackPage from "../stackpage";
import UserStore from "../../store/user";
import BackHeader from "../backHeader";
import ScrollArea from "../scrollarea";
import Withdraw from "./withdraw";
import RechargeList from "./rechargeList";
import CoinsDetail from "./coinsDetail";
import ClickBtn from "../clickbtn";
import Simg from '../simg';
import Loading from '../loading';
import NoData from "../noData";
import BottomLayer from "../bottomLayer";
import BindPhone from "./bindPhoneNew";
import Emit from "../../libs/eventEmitter";
import { getProductList, createPaying } from '../../libs/http';

import iconMoneyGet from '../../resources/img/user/icon_money_get.png';
import iconMoneyPut from '../../resources/img/user/icon_money_put.png';
import iconMoneyCoin from '../../resources/img/user/icon_money_coin.png';

// 底部弹出框
export const SetPayWay = (props) => {
  const { show, list, onChange } = props;
  const [payWayList, setPayWayList] = useState([]);
  const [choosePayWay, setChoosePayWay] = useState({});
  useEffect(() => {
    setPayWayList(list);
  }, [list]);
  // 重置支付选择和底部弹出框
  const reset = () => {
    setPayWayList([]);
    setChoosePayWay({});
    onChange(false);
  };
  // 发送图形验证码
  const onSubmitImgCode = async (code) => {
    try {
      onSubmit(code);
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败，请重试",
        time: 3000
      });
    }
  };
  // 创建订单
  let winRef;
  const origin = `${window.location.origin}/`;
  const onSubmit = async (code) => {
    if (!choosePayWay?.value) {
      Emit.emit("showToast", {
        text: "请选择支付方式",
        time: 3000
      });
      return;
    }
    winRef = window.open(`${origin}waiting.html`, "_blank");
    try {
      const tempParam = {
        pay_way: choosePayWay?.value,
        pay_type: "online",
        product_id: choosePayWay?.product_id,
        verify_code: code,
      };
      const res = await createPaying(tempParam);
      if (res?.status) {
        if (res?.data?.needVerifyCode) {
          Emit.emit("changeCaptcha", {
            show: true,
            onSubmit: async (code) => {
              await onSubmitImgCode(code);
            }
          }); // 判定需要使用图形验证码
          return;
        }
        reset();
        Emit.emit("changeAlert", {
          _title: "温馨提示",
          _theme: 'black',
          _content:
            "1、充值高峰期间到账可能存在延迟，请稍作等待；\n2、如遇充值多次失败、长时间未到账且消费金额未返还情况，请在“充值记录”中选择该订单说明情况，我们会尽快处理。",
          _submitText: "知道了",
          _notDouble: true,
        });
        if (res?.data?.pay_type === "url" && res?.data?.payUrl) {
          winRef.location = res?.data?.payUrl;
        } else {
          Emit.emit("changeAlert", {
            _title: "温馨提示",
            _theme: 'black',
            _content: "获取支付地址失败",
            _submitText: "知道了",
            _notDouble: true,
          });
          winRef.location = `${origin}error.html`;
        }
      } else {
        Emit.emit("changeAlert", {
          _title: "温馨提示",
          _theme: 'black',
          _content: res?.msg || "请求支付失败",
          _submitText: "知道了",
          _notDouble: true,
        });
      }
    } catch (error) {
      Emit.emit("changeAlert", {
        _title: "温馨提示",
        _theme: 'black',
        _content: "请求支付失败",
        _submitText: "知道了",
        _notDouble: true,
      });
      winRef.location = `${origin}error.html`;
    }
  };

  return useMemo(() => (
    <BottomLayer
      show={show}
      onTap={() => {
        onChange(false);
        setChoosePayWay({});
      }}
      notList
    >
      <div className="user-recharge-layer">
        <div className="user-recharge-layer-head">选择支付方式</div>
        <div className="user-recharge-layer-content">
          <p className="user-recharge-layer-title">
            已选择{payWayList[0]?.product_name || ''}
            <span className="color">¥{payWayList[0]?.product_price || 0}</span>
          </p>
          {payWayList.length ? (
            payWayList.map((item, index) => (
              <ClickBtn
                key={`user-recharge-layer-row-${index}`}
                className="user-recharge-layer-row"
                onTap={() => {
                  setChoosePayWay(item);
                }}
              >
                <div className="user-recharge-layer-key">
                  <div className="icon-box">
                    <Simg alwaysShow src={item?.imageurl} />
                  </div>
                  {item?.name}
                </div>
                <div
                  className={`
                    user-recharge-layer-value
                    ${item?.value === choosePayWay?.value ? 'choosed' : ''}
                  `}
                />
              </ClickBtn>
            ))
          ) : (
            <Loading show type={1} />
          )}
          <ClickBtn className="user-public-btn" onTap={() => onSubmit()}>
            立即充值
          </ClickBtn>
        </div>
      </div>
    </BottomLayer>
  ), [show, payWayList, choosePayWay]);
};

export default (props) => {
  const { stackKey } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const [user] = UserStore.useGlobalState("user");
  const [loading, setLoading] = useState(true);
  const [list, setList] = useState([]);
  const [showLayer, setShowLayer] = useState(false);
  const [payWayList, setPayWayList] = useState([]);
  // 充值记录
  const handleRechargeList = () => {
    const stackKey = `user-recharge-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "user-recharge",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <RechargeList stackKey={stackKey} type={2} />
          </StackPage>
        ),
      },
    });
  };
  // 金币提现
  const handleWithdraw = () => {
    const stackKey = `user-withdraw-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "user-withdraw",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            {user?.phone ? (
              <Withdraw stackKey={stackKey} type={1} />
            ) : (
              <BindPhone stackKey={stackKey} />
            )}
          </StackPage>
        ),
      },
    });
  };
  // 金币明细
  const handleCoinsList = () => {
    const stackKey = `user-coins-detail-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "user-coins-detail",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <CoinsDetail stackKey={stackKey} />
          </StackPage>
        ),
      },
    });
  };
  // 产品列表
  const productList = async () => {
    try {
      const params = {
        type: 2,
        pay_type: 'online',
      };
      const res = await getProductList(params);
      if (res?.status && res?.data?.lists?.length) {
        res?.data?.lists?.map((item) => {
          const product_id = item?.id;
          const product_name = item?.pname;
          const product_coins = item?.coins;
          const product_price = item?.price;
          item?.pMethods.map((obj) => {
            obj.product_coins = product_coins;
            obj.product_price = product_price;
            obj.product_id = product_id;
            obj.product_name = product_name;
            obj.pay_type = 'online';
            return obj;
          });
          return item;
        });
        setList(res?.data?.lists);
      } else {
        Emit.emit("showToast", {
          text: '获取产品列表失败'
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: '请求失败，请重试'
      });
    }
    setLoading(false);
  };
  useEffect(() => {
    productList();
  }, []);
  // 选择产品
  const handleChooseProduct = (product) => {
    setPayWayList(product?.pMethods);
    setShowLayer(true);
  };
  return useMemo(() => (
    <div className="positioned-container user-public-bg">
      <BackHeader
        stackKey={stackKey}
        title="我的金币"
        rightBtn={() => (
          <ClickBtn
            className="user-header-btn white"
            onTap={() => handleRechargeList()}
          >
            充值明细
          </ClickBtn>
        )}
      />
      <ScrollArea downRefresh={false}>
        <div className="user-buy-coins-content">
          <div className="user-buy-coins-head">
            <div className="title">账户余额(金币)</div>
            <div className="subtitle">{user?.coins || 0}</div>
          </div>
          <div className="user-buy-coins-active">
            <ClickBtn
              className="btn"
              onTap={() => handleWithdraw()}
            >
              <img className="" src={iconMoneyGet} />
              提现
            </ClickBtn>
            <ClickBtn
              className="btn"
              onTap={() => handleCoinsList()}
            >
              <img className="" src={iconMoneyPut} />
              金币明细
            </ClickBtn>
          </div>
          {
            loading ? (
              <Loading show type={1} />
            ) : (
              list.length ? (
                <div className="user-buy-coins-list">
                  {
                    list.map((item, index) => (
                      <ClickBtn
                        key={`user-buy-coins-${index}`}
                        className="item"
                        onTap={() => handleChooseProduct(item)}
                      >
                        <img className="item-icon" src={iconMoneyCoin} />
                        <div className="item-title">{item?.coins}</div>
                        <div className="item-subtitle">{item?.description}</div>
                        <div className="item-text">{`${item?.price ? `¥${item?.price}` : ''}`}</div>
                      </ClickBtn>
                    ))
                  }
                </div>
              ) : <NoData />
            )

          }
        </div>
      </ScrollArea>
      <SetPayWay
        list={payWayList}
        show={showLayer}
        onChange={setShowLayer}
      />
    </div>
  ), [user, loading, list, showLayer, payWayList]);
};
