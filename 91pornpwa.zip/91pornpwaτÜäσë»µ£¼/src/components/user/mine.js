import React, { useEffect, useMemo, useRef, useState } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/swiper.min.css";

import StackStore from "../../store/stack";
import StackPage from "../stackpage";
import ScrollArea from "../scrollarea";
import BackHeader from "../backHeader";
import ClickBtn from "../clickbtn";
import Simg from "../simg";
import Tabs from "./tabs";
import Emit from "../../libs/eventEmitter";
import Loading from "../loading";
import FansDetail from "../fansDetail";
import CollectionList from "./collectionList";
import HejiList from "../hejiList";
import { UserVideoList } from "./index";
import { apiGetOtherUserInfo } from "../../libs/http";

import iconUper from "../../resources/img/index/upIcon.png";
import iconCreator from "../../resources/img/index/creator.png";
import iconFans from "../../resources/img/index/fans.png";
import vipNot from "../../resources/img/index/vip_not.png";
import vipMonth from "../../resources/img/index/vip_month.png";
import vipJi from "../../resources/img/index/vip_ji.png";
import vipYear from "../../resources/img/index/vip_year.png";
import vipForever from "../../resources/img/index/vip_forever.png";

import bgUser from "../../resources/img/user/bg_user.png";
import iconLocation from "../../resources/img/public/icon_location.png";
import iconArrowRight from "../../resources/img/hot/arrow-right.png";
import iconCollectionBox from "../../resources/img/public/icon_collection_box.png";

/**
 * 个人信息
 * @param props.uuid 用户的uuid
 */
export default (props) => {
  const { stackKey, uuid } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const contentRef = useRef(null); // 外部滚动盒子
  const tabRef = useRef(null); // 内部选项卡盒子
  const [backHeaderShow, setBackHeaderShow] = useState(true);
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState({});
  const infoList = [
    {
      name: "粉丝",
      num: data?.fans || 0,
      onTap: () => { },
    },
    {
      name: "关注",
      num: data?.followed || 0,
      onTap: () => { },
    },
    {
      name: "被赞",
      num: data?.fabulous || 0,
      onTap: () => { },
    },
  ];
  const [navList, setNavList] = useState([]); // tab列表
  const [currentTab, setCurrentTab] = useState(0);
  const [controlledSwiper, setControlledSwiper] = useState(null);
  // 用户信息
  const setVipLevel = () => {
    let levelImg = vipNot;
    switch (data?.vip_level) {
      case 1:
        levelImg = vipMonth;
        break;
      case 2:
        levelImg = vipJi;
        break;
      case 3:
        levelImg = vipYear;
        break;
      case 4:
        levelImg = vipForever;
        break;
      default:
        levelImg = vipNot;
        break;
    }
    if (data?.vip_level > 4) {
      levelImg = vipForever;
    }
    return (
      <div className="user-info-level">
        <img src={levelImg} />
        {data?.club_id > 0 ? <img src={iconFans} /> : <></>}
      </div>
    );
  };
  // 设置头部标记
  const setHeadMark = () => {
    let icon = null;
    switch (data?.role_id) {
      case 16:
        icon = iconCreator;
        break;
      case 17:
        icon = iconUper;
        break;
      default:
        icon = "";
        break;
    }
    return icon ? (
      <div className="mark-box">
        <img src={icon} />
      </div>
    ) : (
      <></>
    );
  };
  // 获取用户信息
  const getDate = async () => {
    try {
      const res = await apiGetOtherUserInfo({ uuid });
      if (res?.status) {
        if (res?.data) {
          setData(res?.data);
        } else {
          Emit.emit("showToast", {
            text: res?.msg,
          });
        }
      } else {
        Emit.emit("showToast", {
          text: "请求用户信息失败",
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败，请重试",
      });
    }
    setLoading(false);
  };
  useEffect(() => {
    getDate();
  }, []);
  useEffect(() => {
    const navAllList = [{
      id: 1,
      name: "作品",
      count: data?.videosCount || 0,
      status: 1
    }, {
      id: 2,
      name: "喜欢",
      count: data?.likesCount || 0,
      status: 1
    }, {
      id: 3,
      name: "购买",
      count: data?.buy_count || 0,
      status: !data?.club_id
    }, {
      id: 4,
      name: "粉丝专属",
      count: data?.club_video_count || 0,
      status: !!data?.club_id
    }];
    const tempNavList = navAllList.filter(item => item.status);
    setNavList(tempNavList);
  }, [data]);
  // 上拉吸顶
  useEffect(() => {
    if (!contentRef.current || !tabRef.current) return;
    tabRef.current.setAttribute(
      "style",
      `height:${contentRef.current.clientHeight}px`
    );
  }, [contentRef.current, tabRef.current]);
  // 进入粉丝团
  const handleEnterCloub = () => {
    const stackKey = `FansDetail-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "FansDetail",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <FansDetail stackKey={stackKey} clubId={data.club_id} />
          </StackPage>
        ),
      },
    });
  };
  // 滚动事件【控制头部返回按钮是否显示】
  const scrollChange = (e) => {
    if (e?.y < -100) {
      setBackHeaderShow(false);
    } else {
      setBackHeaderShow(true);
    }
  };
  // 设置合集列表
  const setCollection = () => {
    if (data?.collects_list.length) {
      return data.collects_list.map((item, index) => {
        if (index < 2) {
          return (
            <ClickBtn
              key={`user-collection-item-${index}`}
              className="user-collection-item"
              onTap={() => handleCollection(item?.id)}
            >
              <img className="icon" src={iconCollectionBox} />
              <div className="text">{item?.title}</div>
            </ClickBtn>
          );
        }
        return <div key={`user-collection-item-${index}`} />;
      });
    }
    return <></>;
  };
  // 合集列表(传了合集id跳转详情，未传合集id跳转合集列表)
  const handleCollection = (id) => {
    const stackKey = `collection-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "collection",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            {id ? (
              <HejiList stackKey={stackKey} id={id} />
            ) : (
              <CollectionList stackKey={stackKey} uuid={uuid} />
            )}
          </StackPage>
        ),
      },
    });
  };
  return useMemo(() => (
    <div className="positioned-container user-public-bg">
      <BackHeader
        stackKey={stackKey}
        style={{
          opacity: backHeaderShow ? 1 : 0,
          pointerEvents: backHeaderShow ? "auto" : "none",
          background: "transparent",
          position: "fixed",
          top: 0,
          zIndex: 2,
        }}
      />
      <div ref={contentRef} className="full-column">
        {loading ? (
          <Loading show type={1} />
        ) : (
          <ScrollArea scrollChange={scrollChange} groupId="mine">
            <div className="user-top">
              <div className="user-top-img">
                <img src={bgUser} />
              </div>
              <div className="user-top-info">
                <div className="user-info-head">
                  <Simg src={data?.thumb} />
                  {setHeadMark()}
                </div>
                <div className="user-info-box">
                  <p className="user-info-title">{data?.nickname}</p>
                  <p className="user-info-subtitle">{data?.watchStr}</p>
                  {setVipLevel()}
                </div>
              </div>
              <div className="user-top-count">
                {infoList.map((item, index) => (
                  <ClickBtn
                    key={`user-top-count-item-${index}`}
                    className="user-top-count-item"
                    onTap={() => item?.onTap()}
                  >
                    <div className="title">{item?.num}</div>
                    <div className="subtitle">{item?.name}</div>
                  </ClickBtn>
                ))}
              </div>
              <div className="user-top-user">
                <img src={iconLocation} />
                <div className="title">{data?.city || "暂无"}</div>
                <div className="title">{data?.age || 0}岁</div>
                <div className="title">91号:{data?.aff_num}</div>
              </div>
              <div className="user-top-desc">
                {data?.person_signnatrue || "这家伙很懒，什么都没有留下！"}
              </div>
            </div>
            {!!data.club_id && (
              <div className="user-fans-cloub">
                {data?.club_thumbs?.length ? (
                  <div className="head-box">
                    {data.club_thumbs.map((item, index) => (
                      <div
                        key={`head-box-item-${index}`}
                        className="head-box-item"
                      >
                        <Simg src={item} />
                      </div>
                    ))}
                  </div>
                ) : <></>}
                <div className="info-box">
                  <div className="title">{data?.club_fans_num}</div>
                  <div className="subtitle">加入他的粉丝团</div>
                </div>
                <ClickBtn className="btn" onTap={() => handleEnterCloub()}>
                  进入粉丝团
                </ClickBtn>
              </div>
            )}
            {data?.collects_list?.length > 0 && (
              <div className="user-collection-box">
                <div className="user-collection-left">
                  {setCollection()}
                </div>
                <ClickBtn
                  className="user-collection-right"
                  onTap={() => handleCollection()}
                >
                  <img className="icon" src={iconArrowRight} />
                  更多
                </ClickBtn>
              </div>
            )}
            <div className="user-tab-swiper" ref={tabRef}>
              <Tabs
                navItems={navList}
                currentIndex={currentTab}
                onChangeTab={(index) => {
                  controlledSwiper?.slideTo(index);
                  setCurrentTab(index);
                }}
              />
              <Swiper
                className="user-swiper"
                initialSlide={0}
                controller={controlledSwiper}
                onSwiper={setControlledSwiper}
                autoplay={false}
                onSlideChange={(e) => {
                  setCurrentTab(e.activeIndex);
                }}
              >
                {navList?.map((item, index) => (
                  <SwiperSlide key={`user-mine-swiper-${item?.id}`}>
                    <UserVideoList
                      show={currentTab === index}
                      type={item?.id}
                      uuid={uuid}
                    />
                  </SwiperSlide>
                ))}
              </Swiper>
            </div>
          </ScrollArea>
        )}
      </div>
    </div>
  ), [
    loading,
    data,
    navList,
    currentTab,
    backHeaderShow,
    controlledSwiper,
  ]);
};
