import React, { useEffect, useMemo, useState } from "react";

import ScrollArea from "../scrollarea";
import BackHeader from '../backHeader';
import ClickBtn from '../clickbtn';
import Loading from '../loading';
import NoData from '../noData';

import { apiCoinsDetail } from '../../libs/http';
import Emit from "../../libs/eventEmitter";

// 收入支出明细
export default (props) => {
  const { stackKey } = props;

  // 下拉菜单
  const filterOptions = [
    {
      name: '全部明细',
      value: 0,
    },
    {
      name: '收入',
      value: 1,
    },
    {
      name: '支出',
      value: 2,
    }
  ];
  const [optionsShow, setOptionsShow] = useState(false);
  const changeOptions = (obj) => {
    setLoading(true);
    setParams((tempParam) => ({
      ...tempParam,
      page: 1,
      type: obj?.value || 0,
      isAll: false,
    }));
    setOptionsShow(false);
  };
  // 参数
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(true);
  const [params, setParams] = useState({
    page: 1,
    size: 10,
    type: 0, // 类型{0: 全部,1: 收入, 2: 支出}
    isAll: false,
  });
  const [data, setData] = useState([]);
  const getData = async () => {
    if (params?.isAll) {
      return;
    }
    setLoadingMore(true);
    try {
      const tempParam = {
        page: params?.page,
        size: params?.size,
        type: params?.type,
      };
      const res = await apiCoinsDetail(tempParam);
      if (res?.status) {
        if (params?.page === 1) {
          setData(res?.data || []);
        } else {
          setData([...data, ...res?.data || []]);
        }
        if (!res?.data?.length) {
          setParams({ ...params, isAll: true });
        }
      } else {
        Emit.emit("showToast", {
          text: "请求列表失败",
          time: 3000
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败，请重试",
        time: 3000
      });
    }
    setLoading(false);
    setLoadingMore(false);
  };
  // 加载更多
  const nextPage = () => {
    if (!params?.isAll) {
      setParams((tempParam) => ({
        ...tempParam,
        page: tempParam?.page + 1
      }));
    }
  };
  useEffect(() => {
    getData();
  }, [params]);
  return useMemo(() => (
    <div className="positioned-container user-public-bg">
      <BackHeader
        stackKey={stackKey}
        title="金币明细"
        right={() => <div style={{ width: '1.5rem', height: '0.1rem' }} />}
      />
      <div className="user-income-expenses-filter">
        <ClickBtn
          className="user-income-expenses-filter-inner"
          onTap={() => {
            setOptionsShow(!optionsShow);
          }}
        >
          <div className="user-income-expenses-filter-key">筛选</div>
          <div className="user-income-expenses-filter-value">
            {filterOptions[params?.type].name}
          </div>
        </ClickBtn>
        <div
          className="user-income-expenses-filter-options"
          style={{
            transform: `translateX(${optionsShow ? 0 : '200%'})`
          }}
        >
          <div className="user-income-expenses-filter-options-inner">
            {
              filterOptions.map((item, index) => (
                <ClickBtn
                  key={`user-income-expenses-filter-options-item-${index}`}
                  className="user-income-expenses-filter-options-item"
                  onTap={() => changeOptions(item)}
                >
                  {item?.name}
                </ClickBtn>
              ))
            }
          </div>
        </div>
      </div>
      {
        loading ? (
          <Loading show type={1} />
        ) : (
          data?.length ? (
            <ScrollArea
              ListData={data?.length}
              loadingMore={loadingMore}
              onScrollEnd={nextPage}
            >
              {
                data.map((item, index) => (
                  <div
                    key={`user-income-expenses-item-${index}`}
                    className="user-income-expenses-item"
                  >
                    <div className="user-income-expenses-item-row">
                      <div className="user-income-expenses-item-left">
                        <div className="title">{item?.project}</div>
                      </div>
                      <div className="user-income-expenses-item-right">
                        <div className="big-title">
                          {item?.coins}
                        </div>
                      </div>
                    </div>
                    <div className="user-income-expenses-item-row">
                      <div className="user-income-expenses-item-left">
                        <div className="subtitle">{item?.memo}</div>
                      </div>
                      <div className="user-income-expenses-item-right">
                        <div className="subtitle">{item?.created_at}</div>
                      </div>
                    </div>
                  </div>
                ))
              }
            </ScrollArea>
          ) : (<NoData />)
        )
      }
    </div>
  ), [loading, loadingMore, data, optionsShow, params]);
};
