import React, { useEffect, useMemo, useRef, useState } from "react";
import globalVar from '../../libs/globalVar';
import StackPage from "../stackpage";
import StackStore from "../../store/stack";
import UserStore from "../../store/user";
import BackHeader from '../backHeader';
import ClickBtn from '../clickbtn';
import Simg from "../simg";
import Emit from "../../libs/eventEmitter";
import BindPhone from "./bindPhoneNew";
import ScrollArea from "../scrollarea";
import BottomLayer from "../bottomLayer";
import {
  updateUserInfo,
  setInvitationCode,
} from "../../libs/http";

// 修改性别
export const BottomSex = (props) => {
  const { show, onChange } = props;
  const list = [
    { name: '男', num: 1, },
    { name: '女', num: 2, },
  ];
  const [choose, setChoose] = useState({});
  const reset = () => {
    setChoose({});
    onChange(false);
  };
  const handleSubmit = async (item) => {
    setChoose(item);
    try {
      const tempParam = { sexType: item?.num };
      const res = await updateUserInfo(tempParam);
      if (res?.status) {
        UserStore.dispatch({
          type: "replace",
          payload: { sexType: item?.num },
        });
        reset();
        Emit.emit("showToast", {
          text: "修改成功",
          time: 3000
        });
      } else {
        Emit.emit("showToast", {
          text: res?.msg || "修改失败",
          time: 3000
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败，请重试",
        time: 3000
      });
    }
  };
  return useMemo(() => (
    <BottomLayer
      show={show}
      onTap={() => {
        setChoose({});
        onChange(false);
      }}
      notList
    >
      <div className="user-account-sex">
        <div className="title">请选择性别</div>
        {list.map((item, index) => (
          <ClickBtn
            key={`user-account-sex-item-${index}`}
            className={`item ${item.num === choose?.num ? 'item-active' : ''}`}
            onTap={() => handleSubmit(item)}
          >
            {item.name}
          </ClickBtn>
        ))}
      </div>
    </BottomLayer>
  ), [show, choose]);
};

export default (props) => {
  const { stackKey } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const [user] = UserStore.useGlobalState("user");

  const writeRef = useRef(''); // 签名
  const nicknameRef = useRef(''); // 昵称
  const inviteCodeRef = useRef(''); // 邀请码
  const [showLayer, setShowLayer] = useState(false); // 是否显示底部弹出框
  // 签名
  const handleWrite = async () => {
    Emit.emit("changeAlert", {
      _title: "签名",
      _theme: 'black',
      _content: (
        <div
          className="user-input-box center"
          style={{ width: "6rem" }}
        >
          <input
            type="text"
            placeholder="请签名"
            onChange={({ target }) => {
              const tempReplace = target.value.replace(/^\s+|\s+$/g, "");
              if (tempReplace.length > 20) {
                const tempCut = String(tempReplace).slice(0, 20);
                target.value = tempCut;
                writeRef.current = tempCut;
                Emit.emit("showToast", { text: "签名长度不大于20位" });
              } else {
                target.value = tempReplace;
                writeRef.current = tempReplace;
              }
            }}
          />
        </div>
      ),
      _submitText: "确定",
      _submit: async () => {
        const reg = /^\s*$/g;
        if (reg.test(writeRef.current)) {
          Emit.emit("showToast", {
            text: "签名不能为空",
            time: 3000
          });
          return;
        }
        try {
          const tempParam = { person_signnatrue: writeRef.current };
          const res = await updateUserInfo(tempParam);
          if (res?.status) {
            UserStore.dispatch({
              type: "replace",
              payload: { person_signnatrue: writeRef.current },
            });
            writeRef.current = ''; // 重置
            Emit.emit("showToast", {
              text: "修改成功",
              time: 3000
            });
          } else {
            Emit.emit("showToast", {
              text: res?.msg || "修改失败",
              time: 3000
            });
          }
        } catch (error) {
          Emit.emit("showToast", {
            text: "请求失败，请重试",
            time: 3000
          });
        }
      },
      _notDouble: true,
    });
  };
  // 昵称
  const handleNickname = async () => {
    Emit.emit("changeAlert", {
      _title: "昵称",
      _theme: 'black',
      _content: (
        <div
          className="user-input-box center"
          style={{ width: "6rem" }}
        >
          <input
            type="text"
            placeholder="请输入昵称"
            onChange={({ target }) => {
              const tempReplace = target.value.replace(/^\s+|\s+$/g, "");
              if (tempReplace.length > 20) {
                const tempCut = String(tempReplace).slice(0, 20);
                target.value = tempCut;
                nicknameRef.current = tempCut;
                Emit.emit("showToast", { text: "昵称不大于20位" });
              } else {
                target.value = tempReplace;
                nicknameRef.current = tempReplace;
              }
            }}
          />
        </div>
      ),
      _submitText: "确定",
      _submit: async () => {
        const reg = /^\s*$/g;
        if (reg.test(nicknameRef.current)) {
          Emit.emit("showToast", {
            text: "昵称不能为空",
            time: 3000
          });
          return;
        }
        try {
          const tempParam = { nickname: nicknameRef.current };
          const res = await updateUserInfo(tempParam);
          if (res?.status) {
            UserStore.dispatch({
              type: "replace",
              payload: { nickname: nicknameRef.current },
            });
            Emit.emit("showToast", {
              text: "修改成功",
              time: 3000
            });
          } else {
            Emit.emit("showToast", {
              text: res?.msg || "修改失败",
              time: 3000
            });
          }
        } catch (error) {
          Emit.emit("showToast", {
            text: "请求失败，请重试",
            time: 3000
          });
        }
        nicknameRef.current = ''; // 重置
      },
      _notDouble: true,
    });
  };
  // 手机号
  const handlePhone = () => {
    let tempType = '';
    if (user?.phone) {
      tempType = 6;
    }
    const stackKey = `user-phone-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "user-phone",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <BindPhone stackKey={stackKey} type={tempType} />
          </StackPage>
        ),
      },
    });
  };
  // 推广码
  const handleInvite = () => {
    if (user?.invitedBy) {
      Emit.emit("showToast", {
        text: "已经填写过邀请码了～",
        time: 3000,
      });
    } else {
      Emit.emit("changeAlert", {
        _title: "推广码",
        _theme: 'black',
        _content: (
          <div className="user-input-box center" style={{ width: "6rem" }}>
            <input
              type="text"
              placeholder="请输入推广码"
              onChange={({ target }) => {
                inviteCodeRef.current = target.value;
              }}
            />
          </div>
        ),
        _submitText: "确定",
        _submit: async () => {
          const reg = /^\s*$/g;
          if (reg.test(inviteCodeRef.current)) {
            Emit.emit("showToast", {
              text: "推广码不能为空",
              time: 3000
            });
            return;
          }
          try {
            const tempParam = { aff: inviteCodeRef.current, };
            const res = await setInvitationCode(tempParam);
            if (res?.status) {
              UserStore.dispatch({
                type: "replace",
                payload: { invitedBy: inviteCodeRef.current },
              });
              Emit.emit("showToast", { text: "绑定成功" });
            } else {
              Emit.emit("showToast", { text: res?.msg || "绑定失败" });
            }
          } catch (error) {
            Emit.emit("showToast", { text: "请求失败，请重试" });
          }
          inviteCodeRef.current = ''; // 重置
        },
        _notDouble: true,
      });
    }
  };
  // 绑定城市
  const onSubmitCity = async (city) => {
    try {
      const tempParam = { city };
      const res = await updateUserInfo(tempParam);
      if (res?.status) {
        UserStore.dispatch({
          type: "replace",
          payload: { city },
        });
        Emit.emit("showToast", { text: "城市更新成功，等待审核" });
      } else {
        Emit.emit("showToast", { text: res?.msg || "城市更新失败" });
      }
    } catch (error) {
      Emit.emit("showToast", { text: "请求失败，请重试" });
    }
  };
  // 解除绑定
  const unBind = () => {
    Emit.emit("changeAlert", {
      _title: "温馨提示",
      _theme: 'black',
      _content: '确认退出当前账号?',
      _submitText: "确定",
      _notDouble: true,
      _submit: () => {
        localStorage.setItem("91pwa_pron_oauth_id", "");
        UserStore.dispatch({
          type: "replace",
          payload: {},
        });
        globalVar.firstData = null
        window.location.reload()
      },
    });
  };

  // 监听城市选择
  useEffect(() => {
    Emit.on("choosePicker", (data) => {
      if (data) {
        onSubmitCity(data);
      }
    });
    return () => {
      Emit.off("choosePicker");
    };
  }, []);

  // 设置性别
  const setSex = () => {
    let text = '';
    if (user?.sexType === 1) {
      text = '男';
    } else if (user?.sexType === 2) {
      text = '女';
    } else {
      text = '未设置';
    }
    return text;
  };

  return useMemo(() => (
    <div className="positioned-container user-public-bg">
      <BackHeader
        stackKey={stackKey}
        title="账号管理"
        right={() => <div style={{ width: "1.5rem", height: "auto" }} />}
      />
      <ScrollArea downRefresh={false}>
        <div className="user-account-avatar">
          <Simg src={user?.thumb} />
        </div>
        <div className="user-account-box">
          <ClickBtn
            className="user-account-item"
            onTap={() => handleWrite()}
          >
            <div className="user-account-item-left">
              <div className="user-account-item-title">签名</div>
            </div>
            <div className="user-account-item-right">
              {user?.person_signnatrue || '这家伙很懒，什么都没有留下!'}
            </div>
          </ClickBtn>
        </div>
        <div className="user-account-box">
          <ClickBtn
            className="user-account-item"
            onTap={() => handleNickname()}
          >
            <div className="user-account-item-left">
              <div className="user-account-item-title">昵称</div>
            </div>
            <div className="user-account-item-right">
              {user?.nickname}
            </div>
          </ClickBtn>
          <ClickBtn
            className="user-account-item"
            onTap={() => {
              setShowLayer(true);
            }}
          >
            <div className="user-account-item-left">
              <div className="user-account-item-title">性别</div>
            </div>
            <div className="user-account-item-right">
              {setSex()}
            </div>
          </ClickBtn>
        </div>
        <div className="user-account-box">
          <ClickBtn
            className="user-account-item"
            onTap={() => handlePhone()}
          >
            <div className="user-account-item-left">
              <div className="user-account-item-title">账号</div>
            </div>
            <div className="user-account-item-right">
              {user?._phone}
            </div>
          </ClickBtn>
          <ClickBtn
            className="user-account-item"
            onTap={() => {
              Emit.emit("showPicker");
            }}
          >
            <div className="user-account-item-left">
              <div className="user-account-item-title">城市</div>
            </div>
            <div className="user-account-item-right">
              {user?.city || '暂无'}
            </div>
          </ClickBtn>
        </div>
        <div className="user-account-box">
          <ClickBtn
            className="user-account-item"
            onTap={() => handleInvite()}
          >
            <div className="user-account-item-left">
              <div className="user-account-item-title">推广码</div>
            </div>
            <div className="user-account-item-right">
              {user?.invitedBy}
            </div>
          </ClickBtn>
        </div>
        <div style={{ padding: '0 0.4rem' }}>
          {
            user?.phone ? (
              <ClickBtn
                className="user-public-btn"
                onTap={() => unBind()}
              >
                退出账号
              </ClickBtn>
            ) : <></>
          }
        </div>
      </ScrollArea>
      <BottomSex show={showLayer} onChange={setShowLayer} />
    </div>
  ), [user, showLayer]);
};
