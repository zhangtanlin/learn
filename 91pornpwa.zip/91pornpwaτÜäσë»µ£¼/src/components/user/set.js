import React, { useMemo, useRef } from "react";

import UserStore from "../../store/user";
import BackHeader from '../backHeader';
import ClickBtn from '../clickbtn';
import Emit from "../../libs/eventEmitter";
import ScrollArea from "../scrollarea";
import {
  getMyInfo,
  setInvitationCode,
  setExchangeCode,
} from "../../libs/http";

import iconSetTg from '../../resources/img/user/icon_set_tg.png';
import iconSetExchange from '../../resources/img/user/icon_set_exchange.png';
import iconSetRules from '../../resources/img/user/icon_set_rules.png';
import GlobalVar from "../../libs/globalVar";

export default (props) => {
  const { stackKey } = props;
  const [user] = UserStore.useGlobalState("user");

  const inviteCodeRef = useRef('');
  const exchangeCodeRef = useRef('');
  const list = [
    {
      name: '输入邀请码',
      icon: iconSetTg,
      text: user?.invitedBy,
      onTap: () => {
        if (user?.invitedBy) {
          Emit.emit("showToast", {
            text: "已经填写过邀请码了～",
            time: 3000,
          });
        } else {
          Emit.emit("changeAlert", {
            _title: "邀请码",
            _theme: 'black',
            _boxStyle: { background: "#fff", color: "#000" },
            _content: (
              <div className="user-input-box center" style={{ width: "6rem" }}>
                <input
                  type="text"
                  placeholder="请输入邀请码"
                  onChange={({ target }) => {
                    inviteCodeRef.current = target.value;
                  }}
                />
              </div>
            ),
            _submitText: "确定",
            _submit: async () => {
              const reg = /^\s*$/g;
              if (reg.test(inviteCodeRef.current)) {
                Emit.emit("showToast", {
                  text: "邀请码不能为空",
                  time: 3000
                });
                return;
              }
              try {
                const tempParam = { aff: inviteCodeRef.current, };
                const res = await setInvitationCode(tempParam);
                if (res?.status) {
                  UserStore.dispatch({
                    type: "replace",
                    payload: { invitedBy: inviteCodeRef.current },
                  });
                  Emit.emit("showToast", { text: "绑定成功" });
                } else {
                  Emit.emit("showToast", { text: res?.msg || "绑定失败" });
                }
              } catch (error) {
                Emit.emit("showToast", { text: "请求失败，请重试" });
              }
              inviteCodeRef.current = '';
            },
            _notDouble: true,
          });
        }
      }
    },
    {
      name: '填写兑换码',
      icon: iconSetExchange,
      text: '',
      onTap: () => {
        Emit.emit("changeAlert", {
          _title: "兑换码",
          _theme: 'black',
          _boxStyle: { background: "#fff", color: "#000" },
          _content: (
            <div className="user-input-box center" style={{ width: "6rem" }}>
              <input
                type="text"
                placeholder="请输入兑换码"
                onChange={({ target }) => {
                  exchangeCodeRef.current = target.value;
                }}
              />
            </div>
          ),
          _submitText: "确定",
          _submit: async () => {
            const reg = /^\s*$/g;
            if (reg.test(exchangeCodeRef.current)) {
              Emit.emit("showToast", {
                text: "兑换码不能为空",
                time: 3000
              });
              return;
            }
            try {
              const tempParam = { exchangeCode: exchangeCodeRef.current, };
              const res = await setExchangeCode(tempParam);
              if (res?.status) {
                Emit.emit("showToast", {
                  text: res?.msg || "兑换成功",
                });
                refresh();
              } else {
                Emit.emit("showToast", {
                  text: res?.msg || "兑换失败",
                });
              }
            } catch (error) {
              Emit.emit("showToast", { text: "请求失败，请重试" });
            }
            exchangeCodeRef.current = '';
          },
          _notDouble: true,
        });
      }
    },
    {
      name: '用户使用规范',
      icon: iconSetRules,
      text: '',
      onTap: () => {
        if (GlobalVar?.useStandarts) {
          window.open(GlobalVar?.useStandarts, "_blank");
        } else {
          Emit.emit("showToast", { text: "使用规范未配置" });
        }
      }
    },
  ];
  // 刷新用户信息
  const refresh = async () => {
    try {
      const res = await getMyInfo();
      if (res?.status) {
        const tempObject = {
          ...res.data?.info,
        }; // 字段说明参考userStore
        UserStore.dispatch({
          type: "replace",
          payload: tempObject,
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败，请重试",
      });
    }
  };
  // 解除绑定
  const unBind = () => {
    Emit.emit("changeAlert", {
      _title: "温馨提示",
      _theme: 'black',
      _content: '确认退出当前账号?',
      _submitText: "确定",
      _notDouble: true,
      _submit: () => {
        window.localStorage.removeItem('91pwa_pron_oauth_id');
        UserStore.dispatch({
          type: "replace",
          payload: {},
        });
        GlobalVar.firstData = null
        window.location.reload();
      },
    });
  };
  return useMemo(() => (
    <div className="positioned-container user-public-bg">
      <BackHeader
        stackKey={stackKey}
        title="设置"
        right={() => <div style={{ width: "1.5rem", height: "auto" }} />}
      />
      <ScrollArea downRefresh={false}>
        {list.map((item, index) => (
          <ClickBtn
            key={`user-set-item-${index}`}
            className="user-set-item"
            onTap={() => item.onTap()}
          >
            <div className="user-set-item-left">
              <img className="user-set-item-icon" src={item.icon} />
              <div className="user-set-item-title">{item.name}</div>
            </div>
            <div className="user-set-item-right">{item.text}</div>
          </ClickBtn>
        ))}
        <div style={{ padding: '0 0.4rem' }}>
          {
            user?.phone ? (
              <ClickBtn
                className="user-public-btn"
                onTap={() => unBind()}
              >
              退出账号
              </ClickBtn>
            ) : <></>
          }
        </div>
      </ScrollArea>
    </div>
  ), [user, list]);
};
