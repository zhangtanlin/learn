import React, { useEffect, useMemo, useState } from "react";
import QRCode from "qrcode.react";

import StackPage from "../stackpage";
import StackStore from "../../store/stack";
import ScrollArea from "../scrollarea";
import BackHeader from '../backHeader';
import ClickBtn from '../clickbtn';
import MyInvite from './myInvite';
import MakeMoney from './makeMoney'
import Loading from "../loading";
import Simg from '../simg'
import UserStore from '../../store/user'
import { copyText } from '../../libs/utils';
import Emit from "../../libs/eventEmitter";
import { apiMyShare } from '../../libs/http';
import sharetitle from '../../resources/img/user/share_title2.png'
import sharebg from '../../resources/img/user/qrcode_bg2.png'
import invitetips from '../../resources/img/user/invite_tips4.png'
import arrowDown from '../../resources/img/user/arrow_down.png'

export default (props) => {
  const { stackKey } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const [user] = UserStore.useGlobalState("user");
  const [shareQrcode, setShareQrcode] = useState('');
  const [shareCode, setShareCode] = useState('');
  const [shareCopy, setShareCopy] = useState('');
  const [title, setTitle] = useState(' ');
  const [textList, setTextList] = useState([]);
  const [loading, setLoading] = useState(true);

  const handleInvite = () => {
    const stackKey = `user-wallet-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "user-wallet",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <MyInvite stackKey={stackKey} />
          </StackPage>
        )
      }
    });
  };

  const handleMakeMoney = ()=>{
    const stackKey = `user-make-money-${new Date().getTime()}`;
        StackStore.dispatch({
          type: "push",
          payload: {
            name: "user-make-money",
            element: (
              <StackPage
                stackKey={stackKey}
                key={stackKey}
                style={{ zIndex: stacks.length + 2 }}
              >
                <MakeMoney stackKey={stackKey} />
              </StackPage>
            ),
          },
        });
  }

  const handleSaveLink = () => {
    copyText(shareCopy);
    Emit.emit("showToast", { text: "复制成功,快去分享吧！", type: "black" });
  };
  const handleSaveImg = () => {
    Emit.emit("showToast", { text: "请自行截图分享二维码", type: "black" });
  };

  const init = async () => {
    try {
      const res = await apiMyShare();
      if (res?.status) {
        setShareQrcode(res?.data?.aff_url);
        setShareCode(res?.data?.aff_code);
        setShareCopy(res?.data?.aff_url_copy);
        if (res?.data?.text?.length) {
          for (const i of res?.data?.text) {
            if (i?.title === '推广福利') {
              setTitle(i?.content);
            }
            if (i?.title === '推广说明') {
              setTextList(i?.content?.split('#'));
            }
          }
        }
      } else {
        Emit.emit("showToast", {
          text: "请求分享信息失败",
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败，请重试",
      });
    }
    setLoading(false);
  };
  useEffect(() => {
    init();
  }, []);

  const renderAvatar = () => {
    return <div className="custom-user-avatar-share" >
      <Simg src={user?.thumb} />
    </div>
  }

  return useMemo(() => (
    <div className="positioned-container user-share">
      <BackHeader
        stackKey={stackKey}
        leftIconIsLight
        rightBtn={() => (
          <ClickBtn
            className="user-header-btn white"
            onTap={() => handleInvite()}
          >
            邀请记录
          </ClickBtn>
        )}
        style={{ background: 'transparent', position: 'absolute', zIndex: 3 }}
      />
      {
        loading ? (
          <Loading show type={1} />
        ) : (
          <ScrollArea downRefresh={false}>
            <div className="user-share-head" style={{ marginTop: '0.75rem' }}>
              <img src={sharetitle} />
            </div>
            <div className="user-qrcode-box">
              <div className="user-qrcode-box-content">
                <p className="user-qrcode-box-name">我的推广码</p>
                <p className="user-qrcode-box-text">{shareCode}</p>
                <div className="user-qrcode-box-inner">
                  {
                    shareQrcode ? (
                      <QRCode
                        style={{
                          height: "100%",
                          width: "100%"
                        }}
                        value={shareQrcode}
                      />
                    ) : <></>
                  }
                </div>
                <p className="user-qecode-box-version">最新版</p>
              </div>
              <img className="user-qrcode-box-share-bg" src={sharebg} />
            </div>

            <div className="user-qrcode-action-flex">
              <ClickBtn
                className="user-share-btn"
                onTap={() => handleSaveLink()}
              >
                复制链接分享
              </ClickBtn>
              <ClickBtn
                className="user-share-btn"
                onTap={() => handleSaveImg()}
              >
                手动截图保存
              </ClickBtn>
            </div>
            <div className="user-share-describe">
              <div className="user-share-describ-title">邀请步骤</div>
              <div className="user-share-arrow-down"><img src={arrowDown} /></div>
              <div className="user-share-text">{title}</div>
              {/* {
                textList?.length ? (
                  textList.map((item, index) => (
                    <div
                      key={`user-share-describ-${index}`}
                      className={
                        index % 2 === 0 ?
                          'user-share-describ-text' :
                          'user-share-describ-subtext'
                      }
                    >
                      {item}
                    </div>
                  ))
                ) : <div style={{ textAlign: 'center', }}>暂无</div>
              } */}
              <ClickBtn className="user-share-invite-tips" onTap={()=>{
                handleMakeMoney()
              }}>
                <img src={invitetips}/>
              </ClickBtn>
            </div>
          </ScrollArea>
        )
      }
    </div>
  ), [loading, shareQrcode, shareCode, shareCopy, title, textList]);
};
