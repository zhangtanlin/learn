import React, { useEffect, useMemo, useState } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/swiper.min.css";

import StackPage from "../stackpage";
import StackStore from "../../store/stack";
import UserStore from "../../store/user";
import ClickBtn from '../clickbtn';
import Country from "./country";
import Emit from "../../libs/eventEmitter";
import GlobalVar from '../../libs/globalVar';
import { formatPhone } from "../../libs/utils";
import {
  apiVerifyPhone,
  apiSendMsg,
  apiBindPhone,
  apiUpdatePhone,
  apiUpdatePwd,
  apiLogin,
  apiFindPwd,
} from '../../libs/http';

// 手机号验证行
const VerifyPhoneItem = (props) => {
  const { prefix, phone, onChangePrefix, onChangePhone } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const [selfPrefix, setSelfPrefix] = useState(prefix);
  const [selfPhone, setSelfPhone] = useState(phone);
  useEffect(() => {
    setSelfPrefix(prefix);
  }, [prefix]);
  useEffect(() => {
    setSelfPhone(phone);
  }, [phone]);
  const handleChooseCountry = () => {
    const stackKey = `user-country-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "user-country",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <Country
              stackKey={stackKey}
              onSubmit={data => onChangePrefix(data)}
            />
          </StackPage>
        )
      }
    });
  };
  return useMemo(() => (
    <div className="user-form-item">
      <ClickBtn
        className="user-form-key"
        onTap={() => handleChooseCountry()}
      >
        <div className="user-bind-country-btn">
          {selfPrefix ? `+${selfPrefix}` : ''}
        </div>
      </ClickBtn>
      <div className="user-form-value">
        <input
          type="number"
          autoComplete="off"
          placeholder="请输入手机号"
          defaultValue={selfPhone}
          onChange={({ target }) => {
            const cutTemp = target.value.replace(/[^\d]/g, "");
            if (cutTemp.length > 11) {
              const strTemp = String(cutTemp).slice(0, 11);
              target.value = strTemp;
              onChangePhone(strTemp);
              Emit.emit("showToast", {
                text: "手机号不能超过11位"
              });
            } else {
              target.value = cutTemp;
              onChangePhone(cutTemp);
            }
          }}
        />
      </div>
    </div>
  ), [selfPrefix, selfPhone]);
};
// 密码文本框行
const PasswordItem = (props) => {
  const { password, placeholder, onChangePassword } = props;
  const [selfPassword, setSelfPassword] = useState(password);
  useEffect(() => {
    setSelfPassword(password);
  }, [password]);
  return useMemo(() => (
    <div className="user-input-box border-bottom">
      <input
        type="password"
        autoComplete="off"
        placeholder={placeholder}
        defaultValue={selfPassword}
        onChange={({ target }) => {
          const tempReplace = target.value.replace(/^\s+|\s+$/g, "");
          if (tempReplace.length > 20) {
            const tempCut = String(tempReplace).slice(0, 20);
            target.value = tempCut;
            onChangePassword(tempCut);
            Emit.emit("showToast", { text: "密码不大于20位" });
          } else {
            target.value = tempReplace;
            onChangePassword(tempReplace);
          }
        }}
      />
    </div>
  ), [selfPassword]);
};
// 短信验证码行
const CaptchaItem = (props) => {
  const { prefix, phone, isSend, placeholder, onChangeCode } = props;
  const [selfPrefix, setSelfPrefix] = useState(prefix);
  const [selfPhone, setSelfPhone] = useState(phone);
  const [selfCode, setSelfCode] = useState('');
  const [selfIsSend, setSelfIsSend] = useState(isSend);
  const [countdownStart, setCountdownStart] = useState(false); // 倒计时是否开始
  const [countdownText, setCountdownText] = useState('获取验证码'); // 倒计时提示文字
  const handleSendCode = () => {
    setSelfIsSend(true);
  };
  const verifyShowImgCode = async () => {
    const reg = /^\s*$/g;
    if (reg.test(selfPhone)) {
      Emit.emit("showToast", {
        text: "手机号不能为空～",
        time: 3000
      });
      return;
    }
    if (GlobalVar?.needVerifyCode) {
      Emit.emit("changeCaptcha", {
        show: true,
        onSubmit: async (code) => {
          await onSendCode(code);
        },
        onCancel: () => {
          setSelfIsSend(false);
        }
      }); // 需要使用图形验证码
      return;
    }
    await onSendCode(); // 不需要使用图形验证码
  };
  const onSendCode = async (code) => {
    try {
      const tempParam = {
        mobile_prefix: selfPrefix,
        phone: selfPhone,
        verify_code: code,
      };
      const res = await apiSendMsg(tempParam);
      if (res?.status) {
        Emit.emit("showToast", {
          text: "验证码发送成功",
          time: 3000
        });
        setCountdownStart(true);
      } else {
        Emit.emit("showToast", {
          text: res?.msg || "验证码发送失败",
          time: 3000
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败，请重试",
        time: 3000
      });
    }
  };
  useEffect(() => {
    setSelfPrefix(prefix);
  }, [prefix]);
  useEffect(() => {
    setSelfPhone(phone);
  }, [phone]);
  useEffect(() => {
    setSelfIsSend(isSend);
    if (isSend) {
      verifyShowImgCode();
    }
  }, [isSend]);
  useEffect(() => {
    if (selfIsSend && !countdownStart) {
      verifyShowImgCode();
    }
  }, [selfIsSend]);
  let countdownFn = null;
  useEffect(() => {
    if (countdownStart) {
      let timeNum = 120;
      countdownFn = setInterval(() => {
        timeNum--;
        setCountdownText(`${timeNum.toString()}s`);
        if (timeNum === 0) {
          setCountdownStart(false);
          setSelfIsSend(false);
          setCountdownText("重新获取");
          clearInterval(countdownFn);
        }
      }, 1000);
    } // 如果countdownStart之前的状态和改变之后的状态一致时=>不会执行
    return () => {
      if (countdownFn) {
        clearInterval(countdownFn);
      }
    };
  }, [countdownStart]);

  return useMemo(() => (
    <div className="user-form-item">
      <div className="user-form-value">
        <input
          type="number"
          autoComplete="off"
          placeholder={`${placeholder || '请输入验证码'}`}
          defaultValue={selfCode}
          onChange={({ target }) => {
            const cutTemp = target.value.replace(/[^\d]/g, "");
            if (cutTemp.length > 10) {
              const strTemp = String(cutTemp).slice(0, 8);
              target.value = strTemp;
              onChangeCode(strTemp);
              setSelfCode();
              Emit.emit("showToast", {
                text: "验证码不超过10位"
              });
            } else {
              target.value = cutTemp;
              onChangeCode(cutTemp);
            }
          }}
        />
      </div>
      <ClickBtn
        className="user-form-key"
        onTap={() => handleSendCode()}
      >
        <div className="user-band-verify-btn">
          {countdownText}
        </div>
      </ClickBtn>
    </div>
  ), [placeholder, countdownText]);
};

export default (props) => {
  const { stackKey, type } = props; // type: 类型{0/null: 登录/验证手机号, 5: 更换密码, 6: 更改绑定手机,}
  const [user] = UserStore.useGlobalState("user");
  const [currentTab, setCurrentTab] = useState(type || 0);
  const [controlledSwiper, setControlledSwiper] = useState('');
  const [params, setParams] = useState({
    oldPrefix: user?.isBind ? user?._prefix : '86', // 验证手机时使用的手机前缀/密码登录时的手机前缀
    oldPhone: user?.isBind ? user?._phone : '', // 验证手机时使用的手机/密码登录时的手机
    oldPhoneCut: user?.isBind ? user?._starPhone : '', // 验证手机时使用的手机/密码登录时的手机
    oldCode: '', // 登录时的验证码/忘记密码时发送的验证码
    newPrefix: '86',
    newPhone: "",
    newCode: "",
    password: "",
    verifyPassword: "",
    loginPassword: ""
  });
  // 验证手机号
  const verifyPhone = () => (
    <div className="user-band-box-inner">
      <div className="user-band-title">登录绑定</div>
      <div className="user-band-subtitle">记录幸福生活</div>
      <VerifyPhoneItem
        prefix={params.oldPrefix}
        phone={params.oldPhone}
        onChangePrefix={(data) => {
          setParams(prevState => ({
            ...prevState,
            ...{ oldPrefix: String(data?.value) },
          }));
        }}
        onChangePhone={(data) => {
          setParams(prevState => ({
            ...prevState,
            ...{ oldPhone: data },
          }));
        }}
      />
      <ClickBtn
        className="user-public-btn"
        onTap={async () => {
          try {
            const tempParam = {
              mobile_prefix: params.oldPrefix,
              phone: params.oldPhone,
            };
            const res = await apiVerifyPhone(tempParam); // 是否已经注册
            if (res?.status) {
              setParams(prevState => ({
                ...prevState,
                ...{ oldPhoneCut: formatPhone(params.oldPhone) },
              }));
              if (res?.data?.hasUser) {
                controlledSwiper && controlledSwiper.slideTo(1); // 密码登录
              } else {
                setCurrentTab(2);
                controlledSwiper && controlledSwiper.slideTo(2); // 绑定手机+设置密码
              }
            } else {
              Emit.emit("showToast", { text: res?.msg || '手机号验证失败' });
            }
          } catch (error) {
            Emit.emit("showToast", { text: "请求失败，请重试" });
          }
        }}
      >
        下一步
      </ClickBtn>
    </div>
  );
  // 密码登录
  const loginByPwd = () => (
    <div className="user-band-box-inner">
      <div className="user-band-title">登录</div>
      <PasswordItem
        password={params.loginPassword}
        placeholder="请输入密码"
        onChangePassword={(data) => {
          setParams(prevState => ({
            ...prevState,
            ...{ loginPassword: data },
          }));
        }}
      />
      <ClickBtn
        className="user-band-prompt"
        onTap={() => {
          controlledSwiper && controlledSwiper.slideTo(3); // 忘记了密码
        }}
      >
        忘记密码
      </ClickBtn>
      <ClickBtn
        className="user-public-btn"
        onTap={async () => {
          const reg = /^\s*$/g;
          if (reg.test(params.loginPassword)) {
            Emit.emit("showToast", {
              text: "密码不能为空～",
              time: 3000
            });
            return;
          }
          try {
            const tempParam = {
              mobile_prefix: params.oldPrefix,
              phone: params.oldPhone,
              password: params.loginPassword,
            };
            const res = await apiLogin(tempParam);
            if (res?.status) {
              Emit.emit("showToast", {
                text: "登录成功",
                time: 3000
              });
              window.location.reload();
            } else {
              Emit.emit("showToast", {
                text: res?.msg || "登录失败",
                time: 3000
              });
            }
          } catch (error) {
            Emit.emit("showToast", {
              text: "请求失败，请重试",
              time: 3000
            });
          }
        }}
      >
        登录
      </ClickBtn>
    </div>
  );
  // 验证码绑定+设置密码+登录
  const loginByCode = () => (
    <div className="user-band-box-inner">
      <div className="user-band-title">绑定手机</div>
      <CaptchaItem
        prefix={params.oldPrefix}
        phone={params.oldPhone}
        isSend={currentTab === 2}
        placeholder="请输入验证码"
        onChangeCode={(code) => {
          setParams(prevState => ({
            ...prevState,
            ...{ oldCode: code },
          }));
        }}
      />
      <PasswordItem
        password={params.password}
        placeholder="请输入密码"
        onChangePassword={(data) => {
          setParams(prevState => ({
            ...prevState,
            ...{ password: data },
          }));
        }}
      />
      <PasswordItem
        password={params.verifyPassword}
        placeholder="确认密码"
        onChangePassword={(data) => {
          setParams(prevState => ({
            ...prevState,
            ...{ verifyPassword: data },
          }));
        }}
      />
      <ClickBtn
        className="user-public-btn"
        onTap={async () => {
          const reg = /^\s*$/g;
          if (reg.test(params.oldCode)) {
            Emit.emit("showToast", {
              text: "验证码不能为空～",
              time: 3000
            });
            return;
          }
          if (reg.test(params.password)) {
            Emit.emit("showToast", {
              text: "密码不能为空～",
              time: 3000
            });
            return;
          }
          if (reg.test(params.verifyPassword)) {
            Emit.emit("showToast", {
              text: "请确认密码～",
              time: 3000
            });
            return;
          }
          if (params.verifyPassword !== params.password) {
            Emit.emit("showToast", {
              text: "两次输入的密码不一致",
              time: 3000
            });
            return;
          }
          try {
            const tempParam = {
              mobile_prefix: params.oldPrefix,
              phone: params.oldPhone,
              password: params.password,
              identify: params.oldCode
            };
            const res = await apiBindPhone(tempParam);
            if (res?.status) {
              Emit.emit("showToast", {
                text: "绑定成功",
                time: 3000
              });
              window.location.reload();
            } else {
              Emit.emit("showToast", {
                text: res?.msg || "绑定失败",
                time: 3000
              });
            }
          } catch (error) {
            Emit.emit("showToast", {
              text: "请求失败，请重试",
              time: 3000
            });
          }
        }}
      >
        绑定并登录
      </ClickBtn>
    </div>
  );
  // 忘记密码-验证手机
  const lostPwd = () => (
    <div className="user-band-box-inner">
      <div className="user-band-title">忘记密码</div>
      <p className="user-band-subtitle">手机号码：{params.oldPhoneCut}</p>
      <CaptchaItem
        prefix={params.oldPrefix}
        phone={params.oldPhone}
        placeholder="请输入验证码"
        onChangeCode={(code) => {
          setParams(prevState => ({
            ...prevState,
            ...{ oldCode: code },
          }));
        }}
      />
      <ClickBtn
        className="user-public-btn"
        onTap={() => {
          const reg = /^\s*$/g;
          if (reg.test(params.oldPhone)) {
            Emit.emit("showToast", {
              text: "手机号不能为空～",
              time: 3000
            });
            return;
          }
          if (reg.test(params.oldCode)) {
            Emit.emit("showToast", {
              text: "验证码不能为空～",
              time: 3000
            });
            return;
          }
          controlledSwiper && controlledSwiper.slideTo(4);
        }}
      >
        下一步
      </ClickBtn>
    </div>
  );
  // 忘记密码-设置密码
  const setPwd = () => (
    <div className="user-band-box-inner">
      <div className="user-band-title">设置密码</div>
      <PasswordItem
        password={params.password}
        placeholder="设置新密码"
        onChangePassword={(data) => {
          setParams(prevState => ({
            ...prevState,
            ...{ password: data },
          }));
        }}
      />
      <PasswordItem
        password={params.verifyPassword}
        placeholder="确认密码"
        onChangePassword={(data) => {
          setParams(prevState => ({
            ...prevState,
            ...{ verifyPassword: data },
          }));
        }}
      />
      <ClickBtn
        className="user-public-btn"
        onTap={async () => {
          const reg = /^\s*$/g;
          if (reg.test(params.password)) {
            Emit.emit("showToast", {
              text: "密码不能为空～",
              time: 3000
            });
            return;
          }
          if (reg.test(params.verifyPassword)) {
            Emit.emit("showToast", {
              text: "验证密码不能为空～",
              time: 3000
            });
            return;
          }
          try {
            const tempParam = {
              mobile_prefix: params.oldPrefix,
              phone: params.oldPhone,
              password: params.password,
              identify: params.oldCode,
            };
            const res = await apiFindPwd(tempParam);
            if (res?.status) {
              Emit.emit("showToast", {
                text: "找回密码成功,请重新登录",
                time: 3000
              });
              controlledSwiper && controlledSwiper.slideTo(1);
            } else {
              Emit.emit("showToast", {
                text: res?.msg || "找回密码失败",
                time: 3000
              });
            }
          } catch (error) {
            Emit.emit("showToast", {
              text: "请求失败，请重试",
              time: 3000
            });
          }
        }}
      >
        修改并登录
      </ClickBtn>
    </div>
  );
  // 修改密码
  const changePwd = () => (
    <div className="user-band-box-inner">
      <div className="user-band-title">修改密码</div>
      <p className="user-band-subtitle">手机号码：{params.oldPhoneCut}</p>
      <PasswordItem
        password={params.loginPassword}
        placeholder="输入旧密码"
        onChangePassword={(data) => {
          setParams(prevState => ({
            ...prevState,
            ...{ loginPassword: data },
          }));
        }}
      />
      <PasswordItem
        password={params.password}
        placeholder="设置新密码"
        onChangePassword={(data) => {
          setParams(prevState => ({
            ...prevState,
            ...{ password: data },
          }));
        }}
      />
      <PasswordItem
        password={params.verifyPassword}
        placeholder="确认密码"
        onChangePassword={(data) => {
          setParams(prevState => ({
            ...prevState,
            ...{ verifyPassword: data },
          }));
        }}
      />
      <ClickBtn
        className="user-public-btn"
        onTap={async () => {
          const reg = /^\s*$/g;
          if (reg.test(params.loginPassword)) {
            Emit.emit("showToast", {
              text: "旧密码不能为空～",
              time: 3000
            });
            return;
          }
          if (reg.test(params.password)) {
            Emit.emit("showToast", {
              text: "密码不能为空～",
              time: 3000
            });
            return;
          }
          if (reg.test(params.verifyPassword)) {
            Emit.emit("showToast", {
              text: "请确认密码～",
              time: 3000
            });
            return;
          }
          if (params.verifyPassword !== params.password) {
            Emit.emit("showToast", {
              text: "两次输入的密码不一致",
              time: 3000
            });
            return;
          }
          try {
            const tempParam = {
              oldPassword: params.loginPassword,
              password: params.password,
            };
            const res = await apiUpdatePwd(tempParam);
            if (res?.status) {
              Emit.emit("showToast", {
                text: "修改密码成功",
                time: 3000
              });
              window.location.reload();
            } else {
              Emit.emit("showToast", {
                text: res?.msg || "修改密码失败",
                time: 3000
              });
            }
          } catch (error) {
            Emit.emit("showToast", {
              text: "请求失败，请重试",
              time: 3000
            });
          }
        }}
      >
        确定
      </ClickBtn>
    </div>
  );
  // 更换手机
  const changePhone = () => (
    <div className="user-band-box-inner">
      <div className="user-band-title">更换绑定</div>
      <p className="user-band-subtitle">手机号码：{params.oldPhoneCut}</p>
      <VerifyPhoneItem
        prefix={params.newPrefix}
        phone={params.newPhone}
        onChangePrefix={(data) => {
          setParams(prevState => ({
            ...prevState,
            ...{ newPrefix: String(data?.value) },
          }));
        }}
        onChangePhone={(data) => {
          setParams(prevState => ({
            ...prevState,
            ...{ newPhone: data },
          }));
        }}
      />
      <CaptchaItem
        phone={params.newPhone}
        prefix={params.newPrefix}
        placeholder="请输入验证码"
        onChangeCode={(code) => {
          setParams(prevState => ({
            ...prevState,
            ...{ newCode: code },
          }));
        }}
      />
      <ClickBtn
        className="user-public-btn"
        onTap={async () => {
          const reg = /^\s*$/g;
          if (reg.test(params.newPhone)) {
            Emit.emit("showToast", {
              text: "新手机号不能为空～",
              time: 3000
            });
          }
          if (reg.test(params.newCode)) {
            Emit.emit("showToast", {
              text: "验证码不能为空～",
              time: 3000
            });
          }
          try {
            const tempParam = {
              mobile_prefix: params.newPrefix,
              phone: params.newPhone,
              identify: params.newCode,
            };
            const res = await apiUpdatePhone(tempParam);
            if (res?.status) {
              Emit.emit("showToast", {
                text: "更换手机成功",
                time: 3000
              });
              window.location.reload();
            } else {
              Emit.emit("showToast", {
                text: res?.msg || "更换手机失败",
                time: 3000
              });
            }
          } catch (error) {
            Emit.emit("showToast", {
              text: "请求失败，请重试",
              time: 3000
            });
          }
        }}
      >
        确定
      </ClickBtn>
    </div>
  );
  return useMemo(() => (
    <div className="positioned-container user-bind">
      <ClickBtn
        className="user-band-back"
        onTap={() => {
          Emit.emit(stackKey, stackKey);
        }}
      />
      <div className="user-band-box">
        <Swiper
          className="swiper-no-swiping"
          initialSlide={type || 0}
          controller={controlledSwiper}
          onSwiper={setControlledSwiper}
          autoplay={false}
          loop={false}
        >
          <SwiperSlide>{verifyPhone()}</SwiperSlide>
          <SwiperSlide>{loginByPwd()}</SwiperSlide>
          <SwiperSlide>{loginByCode()}</SwiperSlide>
          <SwiperSlide>{lostPwd()}</SwiperSlide>
          <SwiperSlide>{setPwd()}</SwiperSlide>
          <SwiperSlide>{changePwd()}</SwiperSlide>
          <SwiperSlide>{changePhone()}</SwiperSlide>
        </Swiper>
      </div>
    </div>
  ), [
    type,
    user,
    currentTab,
    controlledSwiper,
    params,
  ]);
};
