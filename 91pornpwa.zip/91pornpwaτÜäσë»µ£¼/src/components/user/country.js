import React, { useEffect, useMemo, useState, useRef } from "react";

import ScrollArea from "../scrollarea";
import BackHeader from '../backHeader';
import ClickBtn from "../clickbtn";
import Loading from "../loading";
import NoData from '../noData';

import Emit from "../../libs/eventEmitter";
import { getCountryCode } from "../../libs/http";

import '../../resources/css/country.less';

import iconChoose from '../../resources/img/public/icon_choose_ountry.png';

export default (props) => {
  const { stackKey, onSubmit } = props;

  const [loading, setLoading] = useState(true);
  const [list, setList] = useState({});
  const chooseDataRef = useRef(null);
  const arrayToObject = (data) => {
    const tempObject = {};
    if (data?.length) {
      data.forEach((item) => {
        const tempObjectKeys = Object.keys(tempObject);
        if (tempObjectKeys.includes(item.codeGroup)) {
          tempObject[item.codeGroup].push(item);
        } else {
          tempObject[item.codeGroup] = [item];
        }
      });
    }
    return tempObject;
  };
  const getList = async () => {
    try {
      const res = await getCountryCode();
      if (res?.status) {
        const list = res?.data || [];
        list.map((item) => {
          item.codeGroup = (item.name).slice(0, 1);
          item.choose = false;
          return item;
        });
        const newList = arrayToObject(list);
        setList(newList);
      } else {
        Emit.emit("showToast", {
          text: '请求国家列表失败'
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: '请求失败，请重试'
      });
    }
    setLoading(false);
  };
  useEffect(() => {
    getList();
  }, []);
  const onChoose = (data) => {
    chooseDataRef.current = data; // 选中的国家
    const tempList = {};
    const tempKeys = Object.keys(list);
    const tempValues = Object.values(list).map((item) => {
      item.map((obj) => {
        if (obj.choose) {
          obj.choose = false;
        }
        if (obj.value === data.value) {
          obj.choose = true;
        }
        return obj;
      });
      return item;
    });
    tempKeys.forEach((item, index) => {
      tempList[item] = tempValues[index];
    });
    setList(tempList);
  };
  return useMemo(() => (
    <div className="positioned-container user-public-bg">
      <BackHeader
        stackKey={stackKey}
        rightBtn={() => (
          <ClickBtn
            className="user-country-head-btn"
            onTap={() => {
              if (onSubmit) {
                onSubmit(chooseDataRef.current);
              }
              Emit.emit(stackKey, stackKey);
            }}
          >
            确定
          </ClickBtn>
        )}
      />
      {
        loading ? (
          <Loading show type={1} />
        ) : (
          <ScrollArea emitName="international-scrollto">
            <div className="user-country-content">
              {
                Object.keys(list).length ? (
                  Object.keys(list).map((item, index) => (
                    <div
                      key={`user-country-item-${index}`}
                      className={`user-country-item user-country-item-${item}`}
                    >
                      <div className="user-country-item-head">
                        {item}
                      </div>
                      {
                        list[item]?.length ? (
                          list[item].map((data, i) => (
                            <ClickBtn
                              key={`user-country-item-inner-${i}`}
                              className="user-country-item-inner"
                              onTap={() => onChoose(data)}
                            >
                              <div className="user-country-item-inner-mark">
                                {
                                  data?.choose ? (
                                    <img src={iconChoose} />
                                  ) : (<></>)
                                }
                              </div>
                              <div className="user-country-item-inner-key">
                                {data?.label}
                              </div>
                              <div className="user-country-item-inner-value">
                                {data?.value ? `+${data.value}` : ''}
                              </div>
                            </ClickBtn>
                          ))
                        ) : <></>
                      }
                    </div>
                  ))
                ) : (<NoData />)
              }
            </div>
          </ScrollArea>
        )
      }
    </div>
  ), [loading, list]);
};
