import React, { useEffect, useMemo, useState } from "react";

import Emit from "../../libs/eventEmitter";
import { copyText } from "../../libs/utils";
import ScrollArea from "../scrollarea";
import BackHeader from '../backHeader';
import ClickBtn from '../clickbtn';
import Loading from '../loading';
import NoData from '../noData';
import { apiOrderList } from '../../libs/http';

export const RechargeListItem = (props) => {
  const { item } = props;
  return useMemo(() => (
    <div className="user-recharg-list-item">
      <div className="user-recharg-list-row">
        <div className="user-recharg-list-row-left">
          <div className="user-recharg-list-title">
            在线支付:{item?.payway}
          </div>
        </div>
        <div className="user-recharg-list-row-right">
          <div className="user-recharg-list-title-color">
            {item?.status}
          </div>
        </div>
      </div>
      <div className="user-recharg-list-row">
        <div className="user-recharg-list-row-left">
          <div className="user-recharg-list-title-light">
            订单编号：{item?.order_id}
          </div>
        </div>
        <div className="user-recharg-list-row-right">
          <div className="user-recharg-list-subtitle">
            {item?.amount ? `¥${item?.amount}` : ''}
          </div>
        </div>
      </div>
      <div className="user-recharg-list-row">
        <div className="user-recharg-list-row-left">
          <div className="user-recharg-list-title-small">
            {item?.updated_at}
          </div>
        </div>
        <div className="user-recharg-list-row-right">
          <ClickBtn
            className="user-recharg-list-item-btn"
            onTap={() => {
              copyText(item?.order_id);
              Emit.emit("showToast", { text: `复制编号${item?.order_id}成功！`, });
            }}
          >
            复制编号
          </ClickBtn>
        </div>
      </div>
    </div>
  ), []);
};

/**
 * 充值明细
 * @param props.type 类型{1: vip订单列表, 2: 金币订单列表}
 */
export default (props) => {
  const { stackKey, type } = props;
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(true);
  const [params, setParams] = useState({
    page: 1,
    isAll: false,
  });
  const [data, setData] = useState([]);
  const getData = async () => {
    if (params?.isAll) {
      return;
    }
    setLoadingMore(true);
    try {
      const tempParam = {
        page: params?.page,
        type,
      };
      const res = await apiOrderList(tempParam);
      if (res?.status) {
        if (params?.page === 1) {
          setData(res?.data?.list || []);
        } else {
          setData([...data, ...res?.data?.list || []]);
        }
        if (!res?.data?.list?.length) {
          setParams({ ...params, isAll: true });
        }
      } else {
        Emit.emit("showToast", {
          text: "请求列表失败",
          time: 3000
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败，请重试",
        time: 3000
      });
    }
    setLoading(false);
    setLoadingMore(false);
  };
  const nextPage = () => {
    if (!params?.isAll) {
      setParams((tempParam) => ({
        ...tempParam,
        page: tempParam?.page + 1
      }));
    }
  };
  useEffect(() => {
    getData();
  }, [params]);

  return useMemo(() => (
    <div className="positioned-container user-public-bg">
      <BackHeader
        stackKey={stackKey}
        title="充值明细"
        right={() => <div style={{ width: '1.5rem', height: '0.1rem' }} />}
      />
      {
        loading ? (
          <Loading show type={1} />
        ) : (
          data?.length > 0 ? (
            <ScrollArea
              ListData={data?.length}
              loadingMore={loadingMore}
              onScrollEnd={nextPage}
            >
              {
                data.map((item, index) => (
                  <RechargeListItem
                    key={`user-recharge-List-item-${index}`}
                    item={item}
                  />
                ))
              }
            </ScrollArea>
          ) : (
            <NoData />
          )
        )
      }
    </div>
  ), [loading, loadingMore, data]);
};
