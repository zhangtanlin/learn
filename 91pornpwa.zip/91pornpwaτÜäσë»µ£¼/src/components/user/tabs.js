import React, { useMemo } from "react";

import ClickBtn from "../clickbtn";

export default props => {
  const {
    navItems,
    keyName,
    currentIndex,
    onChangeTab,
    style,
  } = props;

  const handleChange = (index) => {
    onChangeTab && onChangeTab(index);
  }

  return useMemo(() => (
    <div className="user-tab" style={style}>
      {navItems && navItems.length ? (
        navItems.map((item, index) => (
          <ClickBtn
            key={`user-tab-item-${index}`}
            onTap={() => handleChange(index)}
            className={`
              user-tab-item
              ${currentIndex == index ? 'user-tab-active' : ''}
            `}
          >
            <div className="text-box">
              <span className="title">
                {keyName ? item[keyName] : item?.name}
              </span>
              {item?.count ? (
                <span className="subtitle">{item?.count || ''}</span>
              ) : <></>}
            </div>
            <div className="mark" />
          </ClickBtn>
        ))
      ) : <></>}
    </div>
  ), [
    style,
    navItems,
    currentIndex,
    keyName,
    onChangeTab,
  ]);
};
