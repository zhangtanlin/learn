import axios from "axios";
import React, { useEffect, useMemo, useRef, useState, useLayoutEffect } from "react";
import { useInView } from 'react-intersection-observer'
import CryptoData from "../libs/CryptoData";
import logoWhite from "../resources/img/public/imgBg_white.png";
import logoBlack from "../resources/img/public/imgBg_black.png";

import avatarBgIcon from "../resources/img/public/icon_header_default.png";
const inviewTimer = {};
export default (props) => {
  // noBg 不需要预加载图和背景 imgFinish图片准备完成
  // isAvatar 是否是头像
  // theme 默认黑色
  const {
    className,
    src,
    noBg,
    imgFinish,
    objectFit = "cover",
    isHorizontal,
    refreshScroll,
    isAvatar,
    theme = "black",
    alwaysShow = false,
    bgColor,
    preViewSize,
    track = true,
    noThumb
  } = props;
  const defaultBg = isAvatar
    ? avatarBgIcon
    : theme == "black"
      ? logoBlack
      : logoWhite;
  const defaultBgColor = theme == "black" ? "rgb(23,2,36)" : "rgb(238,238,238)";
  const [src_state, setSrc] = useState(defaultBg);
  const imgRef = useRef(null);
  const [ref, inView] = useInView({
    threshold: 0,
    trackVisibility: true,
    delay: 100,
  });
  useEffect(() => {
    inviewTimer[src] = null;
    return () => {
      delete inviewTimer[src];
    };
  }, []);

  useLayoutEffect(() => {
    if (!imgRef.current) return;
    if ((!src && !alwaysShow) || (src_state && src_state != defaultBg)) return;
    if (!inView) {
      inviewTimer[src] && clearTimeout(inviewTimer[src]);
    } else {
      const setImg = () => {
        const arraybufferToBase64 = function (t) {
          return new Promise((function (e) {
            const n = new Blob([t]);
            const r = new FileReader();
            r.onload = function (t) {
              const n = t.target.result;
              const r = n.substring(n.indexOf(",") + 1);
              e(r);
            };
            r.readAsDataURL(n);
          }));
        };
        let SrcOfPwaDomain = src;
        let SrcOfPwaDomainThumb;
        if (src.lastIndexOf("?") + 1 == src.length) {
          SrcOfPwaDomain = SrcOfPwaDomain.substring(0, src.length - 1);
        }
        let ext = SrcOfPwaDomain.substring(SrcOfPwaDomain.lastIndexOf(".") + 1);
        ext = ext === "jpg" ? "jpeg" : ext;
        if ("jpg,jpeg,png,gif".indexOf(ext) == -1) return;
        // console.log("SrcOfPwaDomain", SrcOfPwaDomain);
        if (!noThumb && "jpg,jpeg,png".indexOf(ext) != -1) {
          const _pr = 0.6 * (window.devicePixelRatio ?? 1) * 2;
          const filename = SrcOfPwaDomain.substring(0, SrcOfPwaDomain.lastIndexOf("."));
          if (imgRef.current.width * _pr < 180) {
            SrcOfPwaDomainThumb = `${filename}!180x0.${ext}`;
          }
          if (imgRef.current.width * _pr > 180 && imgRef.current.width * _pr < 600) {
            SrcOfPwaDomainThumb = `${filename}!360x0.${ext}`;
          }
          if (imgRef.current.width * _pr > 600 && imgRef.current.width * _pr < 900) {
            SrcOfPwaDomainThumb = `${filename}!720x0.${ext}`;
          }
          if (imgRef.current.width * _pr > 900) {
            SrcOfPwaDomainThumb = `${filename}.${ext}`;
          }
        }
        try {
          axios
            .get(noThumb ? SrcOfPwaDomain : SrcOfPwaDomainThumb, { responseType: 'arraybuffer' })
            .then((res) => {
              arraybufferToBase64(res.data).then(base64str => {
                let decryptStr = CryptoData.DecryptImage(base64str);
                fetch(`data:image/${ext};base64,${decryptStr}`)
                  .then((res) => res.blob())
                  .then((blob) => {
                    setSrc(URL.createObjectURL(blob));
                    decryptStr = null;
                  });
                imgFinish && imgFinish();
              });
            })
            .catch(() => {
              if (noThumb) return;
              axios
                .get(SrcOfPwaDomain, { responseType: 'arraybuffer' })
                .then((res) => {
                  arraybufferToBase64(res.data).then(base64str => {
                    let decryptStr = CryptoData.DecryptImage(base64str);
                    fetch(`data:image/${ext};base64,${decryptStr}`)
                      .then((res) => res.blob())
                      .then((blob) => {
                        setSrc(URL.createObjectURL(blob));
                        decryptStr = null;
                      });
                    imgFinish && imgFinish();
                  });
                });
            });
        } catch (error) {
          console.warn(error);
        }
      };
      inviewTimer[src] = setTimeout(setImg, 400);
    }

  }, [imgRef, src, inView, alwaysShow, noThumb]);

  return useMemo(
    () => (
      <div
        ref={ref}
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          flexDirection: "row",
          justifyContent: "center",
          alignItems: "center",
          background: bgColor ? bgColor : noBg ? "transparent" : defaultBgColor,
        }}
      >
        {track ? src_state ? <img
          ref={imgRef}
          className={className}
          src={src_state}
          style={{
            objectFit:
              src_state !== defaultBg || isAvatar ? objectFit : "contain",
            width:
              src_state !== defaultBg || isAvatar
                ? "100%"
                : preViewSize || "60%",

            height:
              src_state !== defaultBg || isAvatar
                ? "100%"
                : preViewSize || "60%",
            opacity: noBg && src_state === defaultBg ? 0 : 1,
            transition: 'all 0.2s'
          }}
        /> : <div style={{ backgroundColor: '#261238', width: '100%', height: '100%' }} /> : src_state && inView ? <img
          ref={imgRef}
          className={className}
          src={src_state}
          style={{
            objectFit:
              src_state !== defaultBg || isAvatar ? objectFit : "contain",
            width:
              src_state !== defaultBg || isAvatar
                ? "100%"
                : preViewSize || "60%",

            height:
              src_state !== defaultBg || isAvatar
                ? "100%"
                : preViewSize || "60%",
            opacity: noBg && src_state === defaultBg ? 0 : 1,
            transition: 'all 0.2s'
          }}
        /> : <div style={{ backgroundColor: '#261238', width: '100%', height: '100%' }} />}
      </div>
    ),
    [src_state, inView]
  );
};
