import React from "react";
export default (props) => {
  const { onTap, children, className, styles } = props;
  return (
    <div
      className={`${className}`}
      style={styles}
      onClick={
        (e) => {
          onTap && onTap(e);
        }
      }
    >
      {children}
    </div>
  );
};
