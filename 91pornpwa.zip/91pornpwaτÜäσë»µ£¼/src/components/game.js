import React, { useEffect, useMemo, useRef, useState } from "react";
import "../resources/css/game.less";
import czIcon from "../resources/img/game/recharge.png";
import txIcon from "../resources/img/game/tixian.png";
import homeIcon from "../resources/img/games/game_home.png";
import zhuceIcon from "../resources/img/games/zhuce.png";
import activityIcon from "../resources/img/games/activity.png";
import ScrollArea from "./scrollarea";
import StackPage from "./stackpage";
import Gamecard from "./game/gameCard";
import BackHead from "./backHeader";
import StackStore from "../store/stack";
import GameRecharge from "./game/recharge";
import GameWithdraw from "./game/withdraw";
import BindPhone from "./user/bindPhoneNew";
import KefuDetail from "./message/kefuDetail";
import {
  rechargeValueGame,
  getGameList,
  enterGame,
} from "../libs/http";
import StartGame from "./game/startgame";
import czTips from "../resources/img/game/gameVip.png";
import txTips from "../resources/img/games/money.png";
import ClickBtn from "./clickbtn";
import KefuIcon from "../resources/img/game/kefu.png";
import emit from "../libs/eventEmitter";
import UserStore from "../store/user";
import speaker from "../resources/img/games/speaker.png";
import Loading from "./loading";
import Marquee from "./marquee";
import global from "../libs/globalVar";

export default (props) => {
  const [stacks] = StackStore.useGlobalState("stacks");
  const { isVisible } = props;
  const [initPage, setPage] = useState(false);
  const [gameBalance, setGameBalance] = useState(0);
  const [user] = UserStore.useGlobalState("user");
  const [gameList, setGameList] = useState([]);
  const [gameInfo, setGameInfo] = useState({});
  const [tips, seTips] = useState("");
  const [Conin, setConin] = useState(0);
  const [vipInfo, setvipInfo] = useState(null);
  const [openTransfer, setOpenTransfer] = useState({});

  const toRecharge = () => {
    const stackKey = `recharge-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "recharge",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <GameRecharge stackKey={stackKey} transfer={openTransfer}/>
          </StackPage>
        ),
      },
    });
  };
  const toGame = () => {
    if (!global.isBindMobile) {
      const stackKey = `bindphone-${new Date().getTime()}`;
      StackStore.dispatch({
        type: "push",
        payload: {
          name: "bindphone",
          element: (
            <StackPage
              stackKey={stackKey}
              key={stackKey}
              style={{ zIndex: stacks.length + 2 }}
            >
              <BindPhone stackKey={stackKey} />
            </StackPage>
          ),
        },
      });
      return;
    }
    enterGame({ id: 0 }).then((res) => {
      const stackKey = `recharge-${new Date().getTime()}`;
      StackStore.dispatch({
        type: "push",
        payload: {
          name: "recharge",
          element: (
            <StackPage
              stackKey={stackKey}
              key={stackKey}
              style={{ zIndex: stacks.length + 2 }}
            >
              <StartGame stackKey={stackKey} url={res.data.url} />
            </StackPage>
          ),
        },
      });
    });
  };
  const toWithdraw = () => {
    const stackKey = `withdraw-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "withdraw",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <GameWithdraw stackKey={stackKey} vipInfo={vipInfo} />
          </StackPage>
        ),
      },
    });
  };
  const toActivity = () => {
    if (gameInfo?.noticeH5Url) {
      window.open(gameInfo.noticeH5Url, "_blank");
    }
  };
  const getGameMoney = () => {
    getGameList().then((res) => {
      setGameList(res.data.moreGame);
      seTips(res.data.tips);
      setGameBalance(res.data.balance);
      setOpenTransfer(res.data.openTransfer );
      UserStore.dispatch({
          type: "game",
          payload: {
            money: res.data.balance,
          },
        });
      if (res.data.notice.length != 0 && !initPage) {
        emit.emit("gameAlert", {
          _title: "游戏公告",
          _content: res.data.notice,
          _submit: () => {
            if (res.data.noticeH5Url) {
              window.open(res.data.noticeH5Url, "_blank");
            }
          },
          _submitText: res.data.noticeH5Url ? "查看详情" : "知道了",
        });
      }
      setGameInfo(res.data);
      setPage(true);
    });
  };
  const initPageFunc = () => {
    rechargeValueGame().then((res) => {
      setvipInfo(res);
      if (res.status !== 0 && res?.data?.activity) {
        setConin(res.data.activity.value);
      }
    });
    getGameMoney();
  };

  useEffect(() => {
    emit.on("changeGameMoney", getGameMoney);
    if (isVisible && !initPage) {
      initPageFunc();
    }
    return () => {
      emit.off("changeGameMoney", getGameMoney);
    };
  }, [isVisible, initPage]);
  const renderBtn = (title, img, onTap, rightIcon) => {
    return (
      <ClickBtn
        className="icon-box"
        key={img}
        onTap={() => {
          onTap && onTap();
        }}
      >
        <div
          key={title}
          style={{
            position: "relative",
            width: "0.93rem",
            height: "0.93rem",
            backgroundImage: `url(${img})`,
            backgroundRepeat: "no-repeat",
            backgroundSize: "cover",
          }}
        >
          {rightIcon ? (
            <div
              style={{
                position: "absolute",
                right: "-0.91rem",
                top: "0",
                width: "0.91rem",
                height: "0.4rem",
                textAlign: "center",
                lineHeight: "0.4rem",
                fontSize: "0.213rem",
                color: "white",
                backgroundImage: `url(${rightIcon})`,
                backgroundRepeat: "no-repeat",
                backgroundSize: "cover",
              }}
            ></div>
          ) : (
            ""
          )}
        </div>
        <span
          style={{
            fontSize: "0.32rem",
            color: "#808080",
          }}
        >
          {title}
        </span>
      </ClickBtn>
    );
  };

  const handleServer = () => {
    const stackKey = `recharge-${new Date().getTime()}`;
      StackStore.dispatch({
        type: "push",
        payload: {
          name: "recharge",
          element: (
            <StackPage
              stackKey={stackKey}
              key={stackKey}
              style={{ zIndex: stacks.length + 2 }}
            >
              <KefuDetail stackKey={stackKey} />
            </StackPage>
          ),
        },
      });
  }

  return (
    <div
      className={`positioned-container background140 ${isVisible ? "visible" : "hide"}`}
      style={{
        opacity: isVisible ? "1" : "0",
        position: "relative",
      }}
    >
      <BackHead title="游戏大厅" left={()=>{ <div></div> }} right={()=>{<div></div>}}/>
      {!tips ? (
        ""
      ) : (
        <div
          style={{
            display: "flex",
            flexDirection: "row",
            height: "0.67rem",
            alignItems: "center",
            background: "#ffe38f",
            color: "#6b000c",
            fontSize: "0.32rem",
          }}
        >
          <img
            src={speaker}
            style={{
              margin: "0 0.2rem",
              width: "0.4rem",
            }}
          />
          <Marquee
            style={{
              height: "0.67rem",
              lineHeight: "0.67rem",
            }}
            width={global.bodyFontSize * 10 - 0.8 * global.bodyFontSize}
          >
            <div>{tips}</div>
          </Marquee>
        </div>
      )}

      <ClickBtn
        onTap={() => {
          // 跳转路由
          handleServer()
        }}
        styles={{
          position: "absolute",
          width: "1.54rem",
          height: "1.54rem",
          backgroundImage: `url(${KefuIcon})`,
          backgroundRepeat: "no-repeat",
          backgroundSize: "cover",
          bottom: "1rem",
          right: "0.2rem",
          zIndex: "99",
        }}
      ></ClickBtn>
      {initPage ? (
        <ScrollArea pullDonRefresh={()=>{
          initPageFunc()
        }}>
          <div className="wallet-box">
            <div className="wallet-info-box">
              <p className="wallet-text">钱包余额</p>
              <p className="wallet-number">{gameBalance}</p>
            </div>
            <div className="game-nav-box">
              {[
                renderBtn(
                  "充值",
                  czIcon,
                  toRecharge,
                  gameInfo.vipIcon ? czTips : ""
                ),
                renderBtn("提现", txIcon, toWithdraw),
                renderBtn(
                  Conin == 0 ? "进入大厅" : `注册送${Conin}元`,
                  Conin == 0 ? homeIcon : zhuceIcon,
                  toGame,
                  gameInfo.iconIcon ? txTips : ""
                ),
                renderBtn("活动", activityIcon, toActivity, ""),
              ]}
            </div>
          </div>
          <p className="game-title" style={{ padding: "0 0.2rem" }}>
            更多游戏
          </p>
          <div className="game-list-box">
            {gameList.map((item, index) => (
              <Gamecard data={item} key={`game-card-${item.id}`} />
            ))}
          </div>
        </ScrollArea>
      ) : (
        <Loading show={true} text="正在为您加载..." />
      )}
    </div>
  );
};
