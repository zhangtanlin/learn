import React, { useEffect, useRef, useState } from "react";
import ScrollH from "./horizontal_scroller";
import Simg from "./simg";
import "../resources/css/scrolltabs.less";

export default (props) => {
  const { avatar, onTap } = props;
  return (
    <div className="avatar-tab">
      <ScrollH>
        {avatar.map((item, index) => {
          return (
            <TabItem
              item={item}
              key={index}
              index={index}
              onTap={(i) => {
                onTap && onTap(i);
              }}
            />
          );
        })}
      </ScrollH>
    </div>
  );
};

const TabItem = (props) => {
  const { item, index, onTap } = props;
  const itemRef = useRef(null);
  useEffect(() => {
    if (!itemRef.current) {
      return;
    }
    const itemHammer = new Hammer(itemRef.current);
    itemHammer.on("tap", onClick);
    return () => {
      itemHammer.off("tap", onClick);
    };
  }, [itemRef.current]);
  const onClick = () => {
    // console.log(tabIndex, index);
    onTap && onTap(item);
  };
  return (
    <div
      className={"avatar-tab-item"}
      key={index}
      ref={itemRef}
    >
      <div className={"avatar-tab-item-img"}><Simg src={item.cover}/></div>
      <div className={"avatar-tab-item-name"}>{item.name}</div>
    </div>
  );
};
