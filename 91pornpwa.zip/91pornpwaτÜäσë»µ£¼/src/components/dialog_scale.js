/*
 * @Author: Tom
 * @Date: 2021-11-05 15:24:39
 * @LastEditTime: 2021-11-05 15:39:55
 * @LastEditors: Tom
 * @Description:
 * @FilePath: /91avpwa/src/components/dialog_scale.js
 */
import React, { useEffect, useRef, useState } from "react";
import emit from "../libs/eventEmitter";
import "../resources/css/dialog_scale.less";
export default (props) => {
  const { show, onClose, children } = props;
  const [hideSelf, setHideSelf] = useState(true);
  useEffect(() => {
    if (show) {
      setHideSelf(false);
      setTimeout(() => {
        if (
          document &&
          document.getElementsByClassName("dialog_scaleLayer")[0]
        ) {
          document
            .getElementsByClassName("dialog_scaleLayer")[0]
            .classList.add("dialog_scale-in");
        }
      }, 100);
    } else {
      if (document && document.getElementsByClassName("dialog_scaleLayer")[0]) {
        document
          .getElementsByClassName("dialog_scaleLayer")[0]
          .classList.add("dialog_scale-out");
      }
      setTimeout(() => {
        setHideSelf(true);
      }, 300);
    }
  }, [show]);
  if (hideSelf) {
    return null;
  }
  return (
    <div className="dialog_scaleLayer">
      <div
        className="dialog_scaleLayer-close"
        onClick={() => {
          onClose();
        }}
      />
      <div className="dialog_scaleLayer-body">{children}</div>
    </div>
  );
};
