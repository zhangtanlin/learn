import React, { useEffect, useState } from "react";
import { getHomeData } from '../libs/utils';
import "../resources/css/home.less";
import WebView from "./webview";
import StackStore from "../store/stack";
import StackPage from "./stackpage";
import globalVar from "../libs/globalVar";
import splashpng from '../resources/img/user/share_title2.png';

export default (props) => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [stacks] = StackStore.useGlobalState("stacks");
  const [seconed, setSeconed] = useState({ a: 5 });
  const [showBtn, setShowBtn] = useState(false);

  const getQueryString = (name) => {
    let reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
    let r = window.location.search.substr(1).match(reg);
    if (r != null) {
      return decodeURIComponent(r[2]);
    }
    return null;
  };

  useEffect(() => {
    getImg();
    if(!globalVar?.firstData){
      getHomeData()
    }
    let affCode = getQueryString("aff_code");
    if (affCode) {
      globalVar.affCode = affCode
    }
  }, []);



  const getImg = () => {
    const _obj = localStorage.getItem("WELCOME_AD_91PRON");
    // console.log("getImg", JSON.parse(_obj));
    if (_obj) {
      setData(JSON.parse(_obj));
      imgFinish();
    } else {
      setLoading(false)
      setTimeout(function () {
        props.history.replace("/home");
      }, 3000)
    }
  };
  const imgFinish = () => {
    setShowBtn(true);
    let timer;
    timer = setInterval(() => {
      seconed.a -= 1;
      setSeconed({ ...seconed });
      if (seconed.a == 0) {
        props.history.replace("/home");
        clearInterval(timer);
      }
    }, 1000);
  };
  const toWebView = (url, title) => {
    const stackKey = `webview-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "webview",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            isReplace
            style={{
              zIndex: stacks.length + 1,
            }}
          >
            <WebView title={title} url={url} stackKey={stackKey} />
          </StackPage>
        ),
      },
    });
  };

  return (
    <div className="container">
      {loading && data && data.img && seconed.a != 0 ? (
        <div className="welcome-ad">
          <img style={{ width: "100%", height: "100%" }} src={data.img} />
          <div
            onClick={() => {
              if (data.url) {
                window.open(data.url, "_blank");
                // toWebView(data.url, "广告");
              }
            }}
            className="welcome-ad-layer"
          />
          {showBtn && <div className="welcome-ad-btn">{seconed.a}</div>}
        </div>
      ) : <div className="welcome-ad">
        <img style={{ width: "80%" }} src={splashpng} />
      </div>
      }
    </div>
  );
};
