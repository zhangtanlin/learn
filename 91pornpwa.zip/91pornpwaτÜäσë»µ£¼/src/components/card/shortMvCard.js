/*
 * @Author: Tom
 * @Date: 2021-11-19 10:00:33
 * @LastEditTime: 2021-11-27 10:01:40
 * @LastEditors: Tom
 * @Description:
 * @FilePath: /91pornpwa/src/components/card/shortMvCard.js
 */
import React, { useEffect, useMemo, useRef, useState } from "react";
import "../../resources/css/search.less";
import StackStore from "../../store/stack";
import Clickbtn from "../clickbtn";
import Simg from "../simg";

import creatorIcon from "../../resources/img/search/creatorIcon.png";
import coin from "../../resources/img/search/coin.png";
import playIcon from "../../resources/img/search/playIcon.png";
import likeIcon from "../../resources/img/public/icon_detail_smart_checked_white.png";
export default (props) => {
  const { data, theme = "black", toDetail } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  return useMemo(() => (
    <Clickbtn
      className="search_video"
      onTap={() => {
        toDetail();
      }}
    >
      <Simg theme={theme} src={data.thumbImg} />
      <div className="search_video_layer">
        {data.is_original && (
          <img className="search_video_creator" src={creatorIcon} />
        )}
        <div className="search_video_bottom">
          <div>{data.title}</div>
          <div className="search_video_bottom_num">
            <div className="search_video_bottom_num_left">
              <div>
                <img src={likeIcon} />
                {data.like}
              </div>
              <div>
                <img src={playIcon} />
                {data.play_count}
              </div>
            </div>
            {!!data.coins && (
              <div className="search_video_bottom_num_right">
                <img src={coin} />
                {data.coins}
              </div>
            )}
          </div>
        </div>
      </div>
    </Clickbtn>
  ), [data, theme]);
};
