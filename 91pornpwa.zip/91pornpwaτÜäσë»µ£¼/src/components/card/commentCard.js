/*
 * @Author: Tom
 * @Date: 2021-11-17 11:49:22
 * @LastEditTime: 2021-12-08 09:40:42
 * @LastEditors: Tom
 * @Description:
 * @FilePath: /91pornpwa/src/components/card/commentCard.js
 */
import React, { useEffect, useMemo, useRef, useState } from "react";
import "../../resources/css/index.less";
import StackStore from "../../store/stack";
import Clickbtn from "../clickbtn";
import StackPage from "../stackpage";
import Simg from "../simg";
import report from "../../resources/img/index/report.png";
import likeIcon from "../../resources/img/index/comment_like.png";
import likeActiveIcon from "../../resources/img/index/comment_like_active.png";
import vip_not from "../../resources/img/index/vip_not.png";
import vip_month from "../../resources/img/index/vip_month.png";
import vip_ji from "../../resources/img/index/vip_ji.png";
import vip_year from "../../resources/img/index/vip_year.png";
import vip_forever from "../../resources/img/index/vip_forever.png";
import woman from "../../resources/img/index/icon_mine_woman.png";
import man from "../../resources/img/index/icon_mine_man.png";
import { setCommentZan, setCommentReport } from "../../libs/http";
import Emit from "../../libs/eventEmitter";

export default (props) => {
  const { data } = props;
  const [isLike, setIslike] = useState(data.isLiked);
  const [likeNum, setLikeNum] = useState(data.like);
  const [stacks] = StackStore.useGlobalState("stacks");
  let vipIcon = vip_not;
  let flag = 0;

  const _touchStart = () => {
    flag = setTimeout(() => {
      flag = 0
    }, 400);
  }

  const _touchMove = () => {
    clearTimeout(flag)
    flag = 0;
  }

  const _touchEnd = () => {
    clearTimeout(flag)
    if(flag !=0){
      _onClick()
    }
  }

  const _onClick = () => {
    Emit.emit("changeAlert", {
      _title: "提示",
      _content: "确定要举报该评论吗",
      _submitText: "确定",
      _submit: () => {
        setCommentReport({ id: data.id });
        Emit.emit("showToast", { text: "举报成功" });
      },
    });
  }

  switch (data.vip_level) {
    case 0:
      vipIcon = vip_not;
      break;
    case 1:
      vipIcon = vip_month;
      break;
    case 2:
      vipIcon = vip_ji;
      break;
    case 3:
      vipIcon = vip_year;
      break;
    case 4:
      vipIcon = vip_forever;
      break;
    default:
      vipIcon = vip_forever;
      break;
  }

  return useMemo(() => (
    <div className="comment_card">
      <div className="comment_card_avatar_box">
        <div className="comment_card_avatar">
          <Simg src={data.thumb} isAvatar />
        </div>
        <img className="comment_card_vip" src={vipIcon} />
      </div>
      <div className="comment_card_info">
        <div className="comment_card_info_top">
          <div className="comment_card_left">
            <p>
              {data.nickName}
              {!!data.sexType && <img src={data.sexType == 1 ? man : woman} />}
            </p>
            <span>{data.created_at}</span>
          </div>
          <div className="comment_card_right">
            <div
              // onTouchStart={()=>{
              //   _touchStart()
              // }}
              // onTouchMove={()=>{
              //   _touchMove()
              // }}
              // onTouchEnd={()=>{
              //   _touchEnd()
              // }}
              onClick={()=>{
                _onClick()
              }}
            >
              <img src={report} />
              举报
            </div>
            <div
              onClick={() => {
                setCommentZan({ comment_id: data.id }).then((res) => {
                  // console.log("点赞", res);
                });
                let num = isLike ? likeNum - 1 : likeNum + 1;
                setLikeNum(num < 0 ? 0 : num);
                setIslike(!isLike);
              }}
            >
              <img src={isLike ? likeActiveIcon : likeIcon} />
              {likeNum || "点赞"}
            </div>
          </div>
        </div>
        <p className="comment_card_info_content">{data.comment}</p>
      </div>
    </div>
  ), [data, vipIcon]);
};
