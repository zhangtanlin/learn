import React,{ useMemo } from "react";
import Simg from '../simg'
import Clickbtn from "../clickbtn";
import "../../resources/css/index.less";

export default (props) => {
    const { data } = props;
    return useMemo(() => (
      <Clickbtn
        className="app-center-box"
        onTap={() => {
          window.open(data.apk,"_blank")
        }}
      >
        <div className="app-center-cover">
          <Simg theme="white" src={data.icon} noThumb noBg/>
        </div>
        <div className="app-center-info">
          <div>
            <p>{data.title}</p>
          </div>
          <div className="app-center-lll"></div>
          <p>{data.download_count}</p>
          <p>{data.desc}</p>
        </div>
        <div className="app-center-down">下载</div>
      </Clickbtn>
    ), [data]);
};