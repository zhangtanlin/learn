import React, { useState, useEffect } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/swiper.min.css";
import "swiper/components/pagination/pagination.min.css";
import BackHeader from '../../backHeader'
import Clickbtn from '../../clickbtn'
import ScrollArea from '../../scrollarea'
import Loading from '../../loading'
import NoData from '../../noData'
import Simg from '../../simg'
import Tabsbar from "../../tabsbar";
import StackPage from "../../stackpage";
import StackStore from "../../../store/stack";
import '../../../resources/css/hot.less'
import Areacard from '../card/areacard'
import { apiHotLists } from '../../../libs/http'
import Emit from '../../../libs/eventEmitter'
import ShortVideoList from '../../index/shortVideoList'

export default (props) => {
    const { stackKey, title, type } = props;
    const [stacks] = StackStore.useGlobalState("stacks");
    const [tabIndex, setTabIndex] = useState(0);
    const [controlledSwiper, setControlledSwiper] = useState(null);
    const [loading, setLoading] = useState(true);
    const [loadingMore, setLoadingMore] = useState({ a: true });
    const [data, setData] = useState([]);
    let page = 1;

    useEffect(() => {
        getMoreData()
    }, [])

    const getMoreData = () => {
        apiHotLists({ type: type }).then((res) => {
            setLoading(false)
            setData(res.data)
            if(res.data.length < 24){
                setLoadingMore({ a: false })
            }
        }).catch(() => {
            Emit.emit("showToast", {
                text: "请求失败，请重试",
                time: 3000
            });
        })
    }

    const onGetMoreData = () => {
        if (!loadingMore.a) return;
        page++
        apiHotLists({ type: type, page: page }).then((res) => {
            let result = res.data;
            if (result.length == 0) {
                setLoadingMore({ a: false })
                return
            }
            setData(prevArray => [...prevArray, ...result])
        }).catch(() => {
            Emit.emit("showToast", {
                text: "请求失败，请重试",
                time: 3000
            });
        })
    }

    const onToTheCompetition = () => {
        const stackKey = `competition-${new Date().getTime()}`;
        StackStore.dispatch({
            type: "push",
            payload: {
                name: "Competition",
                element: (
                    <StackPage
                        stackKey={stackKey}
                        key={stackKey}
                        style={{ zIndex: stacks.length + 2 }}
                    >
                        <Competition stackKey={stackKey} />
                    </StackPage>
                ),
            },
        });
    }

    const handleRoutes = (_index) => {
        const stackKey = `ShortVideoList-${new Date().getTime()}`;
        StackStore.dispatch({
            type: "push",
            payload: {
                name: "ShortVideoList",
                element: (
                    <StackPage
                        stackKey={stackKey}
                        key={stackKey}
                        style={{ zIndex: stacks.length + 2 }}
                    >
                        <ShortVideoList
                            stackKey={stackKey}
                            list={data}
                            _page={page}
                            _current={_index}
                            pramas={{
                                mod: "index",
                                code: "hotLists",
                                type: type
                            }}
                        />
                    </StackPage>
                ),
            },
        });
    }

    return (
        <div className={"positioned-container background140"} >
            <BackHeader
                stackKey={stackKey}
                title={title}
            />
            {loading ? (
                <Loading show text={"正在获取数据..."} overSize={false} size={25} />
            ) : data.length > 0 ? (
                <ScrollArea
                    ListData={data}
                    onScrollEnd={onGetMoreData}
                    loadingMore={loadingMore.a}
                    pullDonRefresh={() => {
                        page = 1;
                        loadingMore.a = true;
                        setData([]);
                        setLoading(true);
                        setLoadingMore({ ...loadingMore });
                        getMoreData();
                    }}
                >
                    <div className={"other-list-container"}>
                        {data.map((item, index) => {
                            return <Areacard data={item} key={index} onTap={()=>{
                                handleRoutes(index)
                            }}/>
                        })}
                    </div>
                    <div style={{ height: "30px" }} />
                </ScrollArea>
            ) : (
                <NoData />
            )}

        </div>
    )
}

