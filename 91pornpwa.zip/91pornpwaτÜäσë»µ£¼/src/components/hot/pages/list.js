import React, { useState, useEffect } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/swiper.min.css";
import "swiper/components/pagination/pagination.min.css";
import BackHeader from '../../backHeader'
import Clickbtn from '../../clickbtn'
import ScrollArea from '../../scrollarea'
import Loading from '../../loading'
import NoData from '../../noData'
import Simg from '../../simg'
import Tabsbar from "../../tabsbar";
import StackPage from "../../stackpage";
import StackStore from "../../../store/stack";
import '../../../resources/css/hot.less'
import Emit from '../../../libs/eventEmitter'
import Areacard from '../card/areacard'
import ShortVideoList from '../../index/shortVideoList'
import { getListByTag } from '../../../libs/http'

export default (props) => {
    const { stackKey, tag } = props;
    const [currentType, setCurrentType] = useState("new");
    const [tabIndex, setTabIndex] = useState(0);
    const [tabsObject, setTabsObject] = useState([]);
    const [controlledSwiper, setControlledSwiper] = useState(null);
    let page = 1;

    useEffect(() => {
        getListData()
    }, [])

    const getListData = () => {
        getListByTag({ tags: tag, type: currentType }).then((res) => {
            let result = res.data;
            // console.log(result)

            let category = result.category;
            let newCategory = [];
            category.forEach(element => {
                newCategory.push({
                    name: element.title,
                    type: element.type
                })
            });
            setTabsObject(newCategory)
        }).catch(() => {
            Emit.emit("showToast", {
                text: "请求失败，请重试",
                time: 3000
            });
        })
    }

    const getSelect = (select) => {
        setTabIndex(select.index);
        setCurrentType(select.value.type)
        controlledSwiper.slideTo(select.index);
    };

    return (
        <div className={"positioned-container background140"} >
            <BackHeader
                stackKey={stackKey}
                center={() => tabsObject.length > 0 ? <div className={"header-tabsbar"}><Tabsbar onChange={getSelect} arr={tabsObject} current={tabIndex} /></div> : <></>}
            />
            <Swiper
                className={"featured-swiper"}
                controller={controlledSwiper}
                onSwiper={setControlledSwiper}
                onSlideChange={(e) => {
                    setTabIndex(e.activeIndex);
                    setCurrentType(tabsObject[e.activeIndex].type)
                }}
            >
                {tabsObject && tabsObject.map((item, index) => (
                    <SwiperSlide key={`list-slide-${index}`}>
                        <StudioPage current={tabIndex} index={index} type={item.type} tag={tag} />
                    </SwiperSlide>
                ))}
            </Swiper>

        </div>
    )
}

const StudioPage = (props) => {
    const { current, index, type, tag } = props;
    const [stacks] = StackStore.useGlobalState("stacks");
    const [loading, setLoading] = useState(true);
    const [loadingMore, setLoadingMore] = useState({ a: true });
    const [dataState, setDataState] = useState([]);
    let page = 1

    useEffect(() => {
        if (index == current && dataState.length == 0) {
            getMoreData()
        }
    }, [index, current])

    const getMoreData = () => {
        getListByTag({ tags: tag, type: type }).then((res) => {
            let result = res.data;
            setLoading(false)
            if(result){
                setDataState(result.items)
            }
        }).catch(() => {
            Emit.emit("showToast", {
                text: "请求失败，请重试",
                time: 3000
            });
        })
    }

    const onGetMoreData = () => {
        if (!loadingMore.a) return;
        page++
        getListByTag({ tags: tag, type: type, page }).then((res) => {
            let result = res.data;
            if(result.items.length == 0){
                setLoadingMore({a:false})
                return
              }
            setDataState(prevArray => [...prevArray,...result.items])
        }).catch(() => {
            Emit.emit("showToast", {
                text: "请求失败，请重试",
                time: 3000
            });
        })
    }

    const onToTheCompetition = () => {
        const stackKey = `competition-${new Date().getTime()}`;
        StackStore.dispatch({
            type: "push",
            payload: {
                name: "Competition",
                element: (
                    <StackPage
                        stackKey={stackKey}
                        key={stackKey}
                        style={{ zIndex: stacks.length + 2 }}
                    >
                        <Competition stackKey={stackKey} />
                    </StackPage>
                ),
            },
        });
    }

    const handleRoutes = (_index) => {
        const stackKey = `ShortVideoList-${new Date().getTime()}`;
        StackStore.dispatch({
            type: "push",
            payload: {
                name: "ShortVideoList",
                element: (
                    <StackPage
                        stackKey={stackKey}
                        key={stackKey}
                        style={{ zIndex: stacks.length + 2 }}
                    >
                        <ShortVideoList
                            stackKey={stackKey}
                            list={dataState}
                            _page={page}
                            _current={_index}
                            pramas={{
                                mod: "index",
                                code: "listByTag",
                                tags: tag,
                                type: type
                            }}
                        />
                    </StackPage>
                ),
            },
        });
    }

    return (
        <div className={"positioned-container"}>
            {loading ? (
                <Loading show text={"正在获取数据..."} overSize={false} size={25} />
            ) : dataState?.length > 0 ? (
                <ScrollArea
                    ListData={dataState}
                onScrollEnd={onGetMoreData}
                loadingMore={loadingMore.a}
                pullDonRefresh={() => {
                    page = 1;
                    loadingMore.a = true;
                    setDataState([]);
                    setLoading(true);
                    setLoadingMore({ ...loadingMore });
                    getMoreData();
                }}
                >
                    <div className={"other-list-container"}>
                        {dataState.map((item, index) => {
                            return <Areacard data={item} key={index} onTap={()=>{ handleRoutes(index) }}/>
                        })}
                    </div>
                    <div style={{ height: "30px" }} />
                </ScrollArea>
            ) : (
                <NoData />
            )}
        </div>
    )
}

