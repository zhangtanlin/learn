import React, { useState, useEffect } from "react";
import BackHeader from '../../backHeader'
import Clickbtn from '../../clickbtn'
import ScrollArea from '../../scrollarea'
import Loading from '../../loading'
import NoData from '../../noData'
import Simg from '../../simg'
import StackPage from "../../stackpage";
import StackStore from "../../../store/stack";
import '../../../resources/css/hot.less'
import { activityHistory } from '../../../libs/http'
import Competition from '../pages/competition'
import Emit from '../../../libs/eventEmitter'

export default (props) => {
    const { stackKey, title } = props;
    const [stacks] = StackStore.useGlobalState("stacks");
    const [loading, setLoading] = useState(true);
    const [loadingMore, setLoadingMore] = useState({ a: true });
    const [data, setData] = useState([]);
    let page = 1;

    useEffect(() => {
        getMoreData()
    }, [])

    const getMoreData = () => {
        activityHistory().then((res) => {
            let result = res.data
            setLoading(false)
            if (result.length < 24) {
                setLoadingMore({ a: false })
            }
            setData(result)
        }).catch(() => {
            Emit.emit("showToast", {
                text: "请求失败，请重试",
                time: 3000
            });
        })
    }

    const onGetMoreData = () => {
        if (!loadingMore.a) return;
        page++
        activityHistory({ page: page }).then((res) => {
            let result = res.data;
            if (result.length == 0) {
                setLoadingMore({ a: false })
                return
            }
            setData(prevArray => [...prevArray, ...result])
        }).catch(() => {
            Emit.emit("showToast", {
                text: "请求失败，请重试",
                time: 3000
            });
        })
    }

    const onToTheCompetition = (item) => {
        const stackKey = `competition-${new Date().getTime()}`;
        StackStore.dispatch({
            type: "push",
            payload: {
                name: "Competition",
                element: (
                    <StackPage
                        stackKey={stackKey}
                        key={stackKey}
                        style={{ zIndex: stacks.length + 2 }}
                    >
                        <Competition stackKey={stackKey} id={item.id} title={item.title}/>
                    </StackPage>
                ),
            },
        });
    }

    return (
        <div className="positioned-container competition" >
            <BackHeader
                stackKey={stackKey}
                title={"往届大赛"}
            />
            {loading ? (
                <Loading show text={"正在获取数据..."} overSize={false} size={25} />
            ) : data.length > 0 ? (
                <ScrollArea
                    ListData={data}
                    onScrollEnd={onGetMoreData}
                    loadingMore={loadingMore.a}
                    pullDonRefresh={() => {
                        page = 1;
                        loadingMore.a = true;
                        setData([]);
                        setLoading(true);
                        setLoadingMore({ ...loadingMore });
                        getMoreData()
                    }}
                >
                    <div className="history-list">
                        {data.map((item, index) => {
                            return <Clickbtn key={index} onTap={() => onToTheCompetition(item)} className="activity-container"><Simg src={item.thumb} /></Clickbtn>
                        })}
                    </div>
                    <div style={{ height: "30px" }} />
                </ScrollArea>
            ) : (
                <NoData />
            )}
        </div>
    )
}



