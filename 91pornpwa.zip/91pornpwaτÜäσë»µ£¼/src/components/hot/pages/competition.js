import React, { useState, useEffect } from "react";
import BackHeader from '../../backHeader'
import Clickbtn from '../../clickbtn'
import ScrollArea from '../../scrollarea'
import Loading from '../../loading'
import NoData from '../../noData'
import Simg from '../../simg'
import StackPage from "../../stackpage";
import StackStore from "../../../store/stack";
import ShortVideoList from '../../index/shortVideoList'
import History from '../pages/history'
import '../../../resources/css/hot.less'
import Competitioncard from '../card/competitioncard'
import { getActivityDetail } from '../../../libs/http'

export default (props) => {
    const { stackKey, title, id, showRight } = props;
    const [stacks] = StackStore.useGlobalState("stacks");
    const [loading, setLoading] = useState(true);
    const [tabType, setTabType] = useState('original');
    const [loadingMore, setLoadingMore] = useState({ a: true, b: true });
    const [activityInfo, setActivityInfo] = useState({})
    const [data, setData] = useState({
        original: [],
        up: []
    })
    const [activeTab, setActiveTab] = useState(0);
    let page = 1;
    let page2 = 2;

    let tabs = [
        { name: '原创榜', type: 'original' },
        { name: 'UP主榜', type: 'up' }
    ]

    useEffect(() => {
        getMoreData()
    }, [])

    useEffect(() => {
        if (data.original.length == 0 || data.up.length == 0) {
            getMoreData()
        }
    }, [activeTab])

    const hanldeTabsOnChange = (index) => {
        setActiveTab(index);
        setTabType(tabs[index].type)
    }

    const getMoreData = () => {
        getActivityDetail({ activity_id: id, type: activeTab == 0 ? "original" : "up" }).then((res) => {
            let result = res.data
            setLoading(false)

            setActivityInfo(result.activity)
            if (activeTab == 0) {
                setData(prev => ({
                    ...prev,
                    ...{ original: result.rankList },
                }))
            }
            if (activeTab == 1) {
                setData(prev => ({
                    ...prev,
                    ...{ up: result.rankList }
                }))
            }

        }).catch(() => {
            Emit.emit("showToast", {
                text: "请求失败，请重试",
                time: 3000
            });
        })
    }

    const onGetMoreData = () => {
        if (activeTab == 1) {
            if (!loadingMore.b) return;
        } else {
            if (!loadingMore.a) return;
        }
        activeTab == 0 ? page++ : page2++
        getActivityDetail({ activity_id: id, type: activeTab == 0 ? "original" : "up", page: activeTab == 0 ? page : page2 }).then((res) => {
            let result = res.data
            if (activeTab == 0) {
                setData(prev => ({
                    ...prev,
                    ...{ original: [...prev.original, ...result.rankList] }
                }))
                if (result.rankList.length == 0) {
                    setLoadingMore(prev => ({
                        ...prev,
                        ...{ a: false }
                    }))
                }
            }
            if (activeTab == 1) {
                setData(prev => ({
                    ...prev,
                    ...{ up: [...prev.up, ...result.rankList] }
                }))
                if (result.rankList.length == 0) {
                    setLoadingMore(prev => ({
                        ...prev,
                        ...{ b: false }
                    }))
                }
            }
        }).catch(() => {
            Emit.emit("showToast", {
                text: "请求失败，请重试",
                time: 3000
            });
        })
    }

    const TimeLeftBox = (props) => {
        const { endtime } = props;
        const [timeLeft, setTimeLeft] = useState(null);

        useEffect(() => {
            const timer = setTimeout(() => {
                setTimeLeft(calculateTimeLeft());
            }, 1000);
            return () => clearTimeout(timer);
        }, [timeLeft]);

        const calculateTimeLeft = () => {
            let times = endtime * 1000;
            let difference = +new Date(times) - +new Date();
            let timeLeft = {};
            if (difference > 0) {
                timeLeft = {
                    days: Math.floor(difference / (1000 * 60 * 60 * 24)),
                    hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
                    minutes: Math.floor((difference / 1000 / 60) % 60),
                    seconds: Math.floor((difference / 1000) % 60),
                    status: true
                };
            } else {
                timeLeft = {
                    days: 0,
                    hours: 0,
                    minutes: 0,
                    seconds: 0,
                    status: false
                };
            }
            return timeLeft;
        }

        return (
            <>
                {timeLeft && timeLeft.status && <div className={"time-left-box"}>
                    <div className="time-left-tip-text" style={{ marginBottom: "0.1rem" }}>{timeLeft.status ? "活动结束倒计时" : ""}</div>
                    <div className={"time-left-container"}>
                        <div className="time-left-number">{timeLeft.days}</div>
                        <div className="time-left-placeholder">:</div>
                        <div className="time-left-number">{timeLeft.hours}</div>
                        <div className="time-left-placeholder">:</div>
                        <div className="time-left-number">{timeLeft.minutes}</div>
                        <div className="time-left-placeholder">:</div>
                        <div className="time-left-number">{timeLeft.seconds}</div>
                    </div>
                </div>}
            </>
        )
    }

    const handleRoutes = (_index) => {
        const stackKey = `ShortVideoList-${new Date().getTime()}`;
        StackStore.dispatch({
            type: "push",
            payload: {
                name: "ShortVideoList",
                element: (
                    <StackPage
                        stackKey={stackKey}
                        key={stackKey}
                        style={{ zIndex: stacks.length + 2 }}
                    >
                        <ShortVideoList
                            stackKey={stackKey}
                            list={data.original}
                            _page={page}
                            _current={_index}
                            pramas={{
                                mod: "activity",
                                code: "detail",
                                type: 'original',
                                activity_id: id
                            }}
                        />
                    </StackPage>
                ),
            },
        });
    }

    const handleRoutes2 = (_index) => {
        const stackKey = `ShortVideoList-${new Date().getTime()}`;
        StackStore.dispatch({
            type: "push",
            payload: {
                name: "ShortVideoList",
                element: (
                    <StackPage
                        stackKey={stackKey}
                        key={stackKey}
                        style={{ zIndex: stacks.length + 2 }}
                    >
                        <ShortVideoList
                            stackKey={stackKey}
                            list={data.up}
                            _page={page2}
                            _current={_index}
                            pramas={{
                                mod: "activity",
                                code: "detail",
                                type: 'up',
                                activity_id: id
                            }}
                        />
                    </StackPage>
                ),
            },
        });
    }

    return (
        <div className="positioned-container competition" >
            <BackHeader
                stackKey={stackKey}
                title={title}
                right={() => showRight ? <div><RenderRight /></div> : <div className="competition-right-button"></div>}
            />
            {loading ? (
                <Loading show text={"正在获取数据..."} overSize={false} size={25} />
            ) : <ScrollArea
                ListData={data}
                onScrollEnd={onGetMoreData}
                loadingMore={loadingMore.a}
                pullDonRefresh={() => {
                    page = 1;
                    loadingMore.a = true;
                    loadingMore.b = true;
                    setData({
                        original: [],
                        up: []
                    });
                    setLoading(true);
                    setLoadingMore({ ...loadingMore });
                    getMoreData()
                }}
            >

                <div className="competition-header-thumb-container">
                    <div className="competition-header-thumb">
                        <Simg src={activityInfo.thumb_detail} />
                        <div className="competition-header-thumb-timeleft"><TimeLeftBox endtime={activityInfo.end_time} /></div>
                    </div>
                    <div className="competition-header-content">
                        <div>{activityInfo.description}</div>
                    </div>
                </div>

                <RenderTabs onChange={(e) => hanldeTabsOnChange(e)} activeTab={activeTab} />
                <div className="featured-swiper-item">
                    {activeTab == 0 && (
                        <div className="competition-list">
                            {data.original.map((item, index) => {
                                return <Competitioncard data={item} key={index} rank={index + 1} onTap={() => { handleRoutes(index) }} />
                            })}
                            {data.original.length == 0 && <NoData />}
                        </div>
                    )}
                    {activeTab == 1 && (
                        <div className="competition-list">
                            {data.up.map((item, index) => {
                                return <Competitioncard data={item} key={index} rank={index + 1} onTap={() => { handleRoutes2(index) }} />
                            })}
                            {data.up.length == 0 && <NoData />}
                        </div>
                    )}
                </div>
                <div style={{ height: "30px" }} />
            </ScrollArea>}
        </div>
    )
}



const RenderRight = () => {
    const [stacks] = StackStore.useGlobalState("stacks");

    const handleOnTap = () => {
        const stackKey = `History-${new Date().getTime()}`;
        StackStore.dispatch({
            type: "push",
            payload: {
                name: "History",
                element: (
                    <StackPage
                        stackKey={stackKey}
                        key={stackKey}
                        style={{ zIndex: stacks.length + 2 }}
                    >
                        <History stackKey={stackKey} />
                    </StackPage>
                ),
            },
        });
    }

    return (
        <Clickbtn className={"competition-right-button"} onTap={() => handleOnTap()}>往届大赛</Clickbtn>
    )
}

const RenderTabs = (props) => {
    const { onChange, activeTab } = props;

    const handleOnChange = (index) => {
        onChange && onChange(index)
    }

    return <div className={'city-tabs'}>
        <Clickbtn
            className={activeTab == 0 ? "active" : ""}
            onTap={() => {
                handleOnChange(0)
            }}
        >
            原创榜
        </Clickbtn>
        <Clickbtn
            className={activeTab == 1 ? "active" : ""}
            onTap={() => {
                handleOnChange(1)
            }}
        >
            UP主榜
        </Clickbtn>
    </div>
}
