import React, { useState, useEffect } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/swiper.min.css";
import "swiper/components/pagination/pagination.min.css";
import BackHeader from '../../backHeader'
import ScrollArea from '../../scrollarea'
import Loading from '../../loading'
import NoData from '../../noData'
import Tabsbar from "../../tabsbar";
import StackStore from "../../../store/stack";
import '../../../resources/css/hot.less'
import Emit from '../../../libs/eventEmitter'
import sharetitle2 from '../../../resources/img/user/share_title2.png'
import StudioBigCard from '../card/studiobigcard'
import { getZpcMvList } from '../../../libs/http'

export default (props) => {
    const { stackKey, title } = props;
    const [stacks] = StackStore.useGlobalState("stacks");
    const [tabIndex, setTabIndex] = useState(0);
    const [controlledSwiper, setControlledSwiper] = useState(null);
    const tabs = [
        { name: "最新", type: 'new' },
        { name: "最热", type: 'hot' },
    ];

    const getSelect = (select) => {
        setTabIndex(select.index);
        controlledSwiper.slideTo(select.index);
    };

    return (
        <div className={"positioned-container background140"} >
            <BackHeader
                stackKey={stackKey}
                // title={"往届大赛"}
                center={() => <div className={"header-tabsbar"}><Tabsbar onChange={getSelect} arr={tabs} current={tabIndex} /></div>}
            />
            <Swiper
                className={"featured-swiper"}
                controller={controlledSwiper}
                onSwiper={setControlledSwiper}
                onSlideChange={(e) => {
                    setTabIndex(e.activeIndex);
                }}
            >
                {tabs.map((item, index) => (
                    <SwiperSlide key={index}>
                        <StudioPage current={tabIndex} index={index} type={item.type} />
                    </SwiperSlide>
                ))}
            </Swiper>

        </div>
    )
}

const StudioPage = (props) => {
    const { current, index, type } = props;
    const [loading, setLoading] = useState(true);
    const [data, setData] = useState([]);
    const [loadingMore, setLoadingMore] = useState({ a: true });
    let page = 1;

    useEffect(() => {
        if (current == index && data.length == 0) {
            onGetCategory()
        }
    }, [current, index, type])

    const onGetCategory = () => {
        getZpcMvList({ type: type }).then((res) => {
            let result = res.data;
            setLoading(false)
            setData(result.items)
        }).catch(() => {
            Emit.emit("showToast", {
                text: "请求失败，请重试",
                time: 3000
            });
        })
    }

    const getMoreData = () => {
        page++
        getZpcMvList({ type: type, page }).then((res) => {
            let result = res.data;
            setLoading(false)
            if(result){
                if(result.items.length > 0){
                    setData(prevArray => [...prevArray, ...result.items])
                }else{
                    loadingMore.a = false
                    setLoadingMore({...loadingMore})
                }
            }
        }).catch(() => {
            Emit.emit("showToast", {
                text: "请求失败，请重试",
                time: 3000
            });
        })
    }

    return <div className={"positioned-container"}>
        {loading ? (
            <Loading show text={"正在获取数据..."} overSize={false} size={25} />
        ) : data.length > 0 ? (
            <ScrollArea
                ListData={data}
                loadingMore={loadingMore.a}
                onScrollEnd={getMoreData}
                pullDonRefresh={() => {
                    page = 1;
                    setData([]);
                    setLoading(true);
                    onGetCategory()
                }}

            >
                <div className="album-detail-header">
                        <div className="album-detail-header-linear"></div>
                        <img className="album-detail-header-thumb" src={sharetitle2}/>
                    </div>
                {data.map((item, index) => {
                    return <StudioBigCard title={item.name} data={item} key={index} categoryId={item.category_id} />
                })}
                <div style={{ height: "30px" }} />
            </ScrollArea>
        ) : (
            <NoData />
        )}
    </div>
}

