import React, { useState, useEffect, useRef } from "react";
import Clickbtn from '../../clickbtn';
import ScrollArea from '../../scrollarea';
import Loading from '../../loading';
import NoData from '../../noData';
import Simg from '../../simg';
import Emit from "../../../libs/eventEmitter";
import Hammer from "hammerjs";
import StackPage from "../../stackpage";
import StackStore from "../../../store/stack";
import '../../../resources/css/hot.less';
import backWhite from "../../../resources/img/public/backWhite.png";
import StudioBigCard from '../card/studiobigcard';
import StudioSmallCard from '../card/studiosmallcard';
import sharetitle2 from '../../../resources/img/user/share_title2.png'
import { getZpcMvList } from '../../../libs/http'

export default (props) => {
    const { stackKey, id } = props;
    const backRef = useRef(null);
    const [stacks] = StackStore.useGlobalState("stacks");
    const [loading, setLoading] = useState(true);
    const [loadingMore, setLoadingMore] = useState({ a: true });
    const [dataState, setDataState] = useState([]);
    const [category, setCategory] = useState({});

    let page = 1;

    useEffect(() => {
        getMoreData()
    }, [id])

    useEffect(() => {
        if (!backRef.current) return;
        const go_back = () => {
            Emit.emit(stackKey, stackKey);
        };
        const hammer = new Hammer(backRef.current);
        hammer.on("tap", go_back);
        return () => {
            hammer.off("tap", go_back);
        };
    }, [backRef.current]);

    const getMoreData = () => {
        getZpcMvList().then((res) => {
            let result = res.data;
            if(result?.items?.length > 0){
                setDataState(result.items)
                setLoading(false)
            }
        }).catch(() => {
            Emit.emit("showToast", {
                text: "请求失败，请重试",
                time: 3000
            });
        })
    }

    const onGetMoreData = () => {
        if (!loadingMore.a) return;
        page++
        getZpcMvList({ page }).then((res) => {
            let result = res.data;
            if (result?.items?.length == 0) {
                setLoadingMore({ a: false })
                return
            }
            setDataState(prevArray => [...prevArray, ...result.items])
        }).catch(() => {
            Emit.emit("showToast", {
                text: "请求失败，请重试",
                time: 3000
            });
        })
    }

    return (
        <div className="positioned-container background140" >
            <div className="back-header-left album-detail">
                <div ref={backRef} className="back-header-left-back">
                    <img src={backWhite} />
                </div>
            </div>
            {loading ? (
                <Loading show text={"正在获取数据..."} overSize={false} size={25} />
            ) : dataState?.length > 0 ? (
                <ScrollArea
                    ListData={dataState}
                    onScrollEnd={onGetMoreData}
                    loadingMore={loadingMore.a}
                    pullDonRefresh={() => {
                        page = 1;
                        loadingMore.a = true;
                        setDataState([]);
                        setLoading(true);
                        setLoadingMore({ ...loadingMore });
                        getMoreData();
                    }}
                >
                    <div className="album-detail-header">
                        <div className="album-detail-header-linear"></div>
                        <img className="album-detail-header-thumb" src={sharetitle2}/>
                    </div>
                    {dataState.map((item, index) => {
                        return <StudioBigCard data={item} key={index} />
                        // if (index == 0) {
                        //     return <StudioBigCard data={item} key={index} />
                        // } else {
                        //     return <StudioSmallCard data={item} key={index} index={index} />
                        // }
                    })}
                </ScrollArea>
            ) : (
                <NoData />
            )}

        </div>
    )
}

