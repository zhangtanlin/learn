import React, { useState, useEffect } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/swiper.min.css";
import "swiper/components/pagination/pagination.min.css";
import BackHeader from '../../backHeader'
import Clickbtn from '../../clickbtn'
import ScrollArea from '../../scrollarea'
import Loading from '../../loading'
import NoData from '../../noData'
import Simg from '../../simg'
import Tabsbar from "../../tabsbar";
import StackPage from "../../stackpage";
import StackStore from "../../../store/stack";
import '../../../resources/css/hot.less'
import Emit from '../../../libs/eventEmitter'

import StudioBigCard from '../card/studiobigcard'
import StudioSmallCard from '../card/studiosmallcard'
import { getCategory } from '../../../libs/http'

export default (props) => {
    const { stackKey, title } = props;
    const [stacks] = StackStore.useGlobalState("stacks");
    const [tabIndex, setTabIndex] = useState(0);
    const [controlledSwiper, setControlledSwiper] = useState(null);
    const tabs = [
        { name: "国产", type: 2 },
        { name: "综艺", type: 4 },
    ];

    const getSelect = (select) => {
        setTabIndex(select.index);
        controlledSwiper.slideTo(select.index);
    };

    return (
        <div className={"positioned-container background140"} >
            <BackHeader
                stackKey={stackKey}
                // title={"往届大赛"}
                center={() => <div className={"header-tabsbar"}><Tabsbar onChange={getSelect} arr={tabs} current={tabIndex} /></div>}
            />
            <Swiper
                className={"featured-swiper"}
                controller={controlledSwiper}
                onSwiper={setControlledSwiper}
                onSlideChange={(e) => {
                    setTabIndex(e.activeIndex);
                }}
            >
                {tabs.map((item, index) => (
                    <SwiperSlide key={index}>
                        <StudioPage current={tabIndex} index={index} type={item.type} />
                    </SwiperSlide>
                ))}
            </Swiper>

        </div>
    )
}

const StudioPage = (props) => {
    const { current, index, type } = props;
    const [loading, setLoading] = useState(true);
    const [data, setData] = useState([]);
    let page = 1;

    useEffect(() => {
        if (current == index && data.length == 0) {
            onGetCategory()
        }
    }, [current, index, type])

    const onGetCategory = () => {
        getCategory({ type: type }).then((res) => {
            let result = res.data;
            setLoading(false)
            setData(result.category)
        }).catch(() => {
            Emit.emit("showToast", {
                text: "请求失败，请重试",
                time: 3000
            });
        })
    }

    const getMoreData = () => {
        getCategory({ type: type }).then((res) => {
            let result = res.data;
            setLoading(false)
            setData(result.category)
        }).catch(() => {
            Emit.emit("showToast", {
                text: "请求失败，请重试",
                time: 3000
            });
        })
    }

    const onToTheCompetition = () => {
        const stackKey = `competition-${new Date().getTime()}`;
        StackStore.dispatch({
            type: "push",
            payload: {
                name: "Competition",
                element: (
                    <StackPage
                        stackKey={stackKey}
                        key={stackKey}
                        style={{ zIndex: stacks.length + 2 }}
                    >
                        <Competition stackKey={stackKey} />
                    </StackPage>
                ),
            },
        });
    }
    return <div className={"positioned-container"}>
        {loading ? (
            <Loading show text={"正在获取数据..."} overSize={false} size={25} />
        ) : data.length > 0 ? (
            <ScrollArea
                ListData={data}
                pullDonRefresh={() => {
                    page = 1;
                    setData([]);
                    setLoading(true);
                    getMoreData()
                }}
            >
                {data.map((item, index) => {
                   return <div key={index}>
                        {item.mvlist.map((item2, index2) => {
                            if (index2 == 0) {
                                return <StudioBigCard showMore title={item.name} data={item2} key={index2} categoryId={item.category_id}/>
                            } else {
                                return <StudioSmallCard data={item2} key={index2} index={index2}/>
                            }
                        })}
                    </div>
                })}
                <div style={{ height: "30px" }} />
            </ScrollArea>
        ) : (
            <NoData />
        )}
    </div>
}

