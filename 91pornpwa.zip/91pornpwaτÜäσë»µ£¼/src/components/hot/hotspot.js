import React, { useEffect, useMemo, useRef, useState } from "react";
import { useInView } from 'react-intersection-observer'
import Simg from '../simg';
import Loading from '../loading';
import ScrollArea from '../scrollarea';
import NoData from '../noData';
import Competition from './pages/competition';
import AlbumDetails from './pages/albumdetails';
// import Studio from './pages/studio';
import Studio from './pages/studionew';
import StackPage from "../stackpage";
import StackStore from "../../store/stack";
import Clickbtn from '../clickbtn';
import ListPage from './pages/list'
import SimpleList from './pages/simplelist'
import History from './pages/history'
import RankList from './pages/ranklist'
import likeicon from '../../resources/img/hot/like-icon.png'
import goldaspng from '../../resources/img/hot/gold_as.png'
import renqiicon from '../../resources/img/hot/renqiicon.png'
import hot91png from '../../resources/img/hot/hot91.png'
import dasaimvpng from '../../resources/img/hot/dasaimv.png'
import discoverjc from '../../resources/img/hot/discoverjc.png'
import HorizontalScroller from '../horizontal_scroller'
import Emit from '../../libs/eventEmitter'
import { getHotData } from '../../libs/http'
import { formatNumber } from '../../libs/utils'

export default (props) => {
    const { index, current, show } = props;
    const [loading, setLoading] = useState(true);
    const [stacks] = StackStore.useGlobalState("stacks");
    const [pageData, setPageData] = useState(null);
    const [ref, inView] = useInView({
        threshold: 0,
      })
    useEffect(() => {
        if (index == current && pageData == null && show) {
            getListData()
        }
    }, [index, current, show])

    const getListData = () => {
        getHotData().then((res) => {
            let result = res.data;
            setPageData(result)
            setLoading(false);
        }).catch((e) => {
            Emit.emit("showToast", {
                text: "请求失败，请重试",
                time: 3000
            });
        })
    }

    const onToTheCompetition = (id, title) => {
        const stackKey = `competition-${new Date().getTime()}`;
        StackStore.dispatch({
            type: "push",
            payload: {
                name: "Competition",
                element: (
                    <StackPage
                        stackKey={stackKey}
                        key={stackKey}
                        style={{ zIndex: stacks.length + 2 }}
                    >
                        <Competition stackKey={stackKey} id={id} title={title} showRight={true} />
                    </StackPage>
                ),
            },
        });
    }

    const onToTheStudio = () => {
        const stackKey = `studio-${new Date().getTime()}`;
        StackStore.dispatch({
            type: "push",
            payload: {
                name: "studio",
                element: (
                    <StackPage
                        stackKey={stackKey}
                        key={stackKey}
                        style={{ zIndex: stacks.length + 2 }}
                    >
                        <Studio stackKey={stackKey} />
                    </StackPage>
                ),
            },
        });
    }

    const handleMoreActivity = () => {
        const stackKey = `History-${new Date().getTime()}`;
        StackStore.dispatch({
            type: "push",
            payload: {
                name: "History",
                element: (
                    <StackPage
                        stackKey={stackKey}
                        key={stackKey}
                        style={{ zIndex: stacks.length + 2 }}
                    >
                        <History stackKey={stackKey} />
                    </StackPage>
                ),
            },
        });
    }

    const handleAd = (url) => {
        window.open(url, "_blank");
    }

    return (
        <div className="featured-swiper-item">
            {loading ? (
                <Loading show text={"正在获取数据..."} overSize={false} size={25} />
            ) : pageData ? (
                <ScrollArea
                    groupId="hotspot"
                    ListData={pageData}
                    pullDonRefresh={() => {
                        setPageData(null)
                        setLoading(true);
                        getListData();
                    }}
                >
                    <div className={"hot-main"}>
                        {pageData.activityIn && <Clickbtn onTap={() => { onToTheStudio() }} className={"ad-header-container"}><Simg src={pageData.activityIn.thumb} noThumb/></Clickbtn>}
                        {pageData.activityData && pageData.activityData.activity && (
                            <Clickbtn onTap={() => onToTheCompetition(pageData.activityData.activity.id, pageData.activityData.activity.title)} className={"activity-container"}>
                                <Simg src={pageData.activityData.activity.thumb} noThumb/>
                               <div ref={ref}> { inView && <TimeLeftBox endtime={pageData.activityData.activity.end_time} /> }</div>
                            </Clickbtn>
                        )}
                        {pageData.activityData && pageData.activityData.rankList.length >= 3 && (
                            <div className={"hot-session"}>
                                <Clickbtn onTap={() => onToTheCompetition(pageData.activityData.activity.id, pageData.activityData.activity.title)} className={"hot-rank-box hot-flex-row hot-justify-between"}>
                                    <div className={"hot-rank-item"}>
                                        <div className={"hot-rank-number"}>TOP.2</div>
                                        <div className={"hot-rank-like-number hot-flex-row"}>
                                            <img src={likeicon} />
                                            <div className={"hot-rank-playnumber"}>{formatNumber(pageData.activityData.rankList[1].like)}</div>
                                        </div>
                                        <div className={"hot-rank-play-thumb"}><Simg src={pageData.activityData.rankList[1].thumbImg} noThumb/></div>
                                    </div>
                                    <div className={"hot-rank-item"}>
                                        <div className={"hot-rank-number"}>TOP.1</div>
                                        <div className={"hot-rank-like-number hot-flex-row"}>
                                            <img src={likeicon} />
                                            <div className={"hot-rank-playnumber"}>{formatNumber(pageData.activityData.rankList[0].like)}</div>
                                        </div>
                                        <div className={"hot-rank-play-thumb"}><Simg src={pageData.activityData.rankList[0].thumbImg} noThumb/></div>
                                    </div>
                                    <div className={"hot-rank-item"}>
                                        <div className={"hot-rank-number"}>TOP.3</div>
                                        <div className={"hot-rank-like-number hot-flex-row"}>
                                            <img src={likeicon} />
                                            <div className={"hot-rank-playnumber"}>{formatNumber(pageData.activityData.rankList[2].like)}</div>
                                        </div>
                                        <div className={"hot-rank-play-thumb"}><Simg src={pageData.activityData.rankList[2].thumbImg} noThumb/></div>
                                    </div>
                                </Clickbtn>
                            </div>
                        )}
                        {pageData.rank.length > 0 && (
                            <div className={"hot-session"}>
                                <div className={"hot-title-box hot-title-margin"}>
                                    <img src={renqiicon} />
                                    <div>人气榜单</div>
                                </div>
                                <div className="noSwiper-container">
                                    <RenderRankCard list={pageData.rank} />
                                </div>
                            </div>
                        )}
                        {pageData.hot.length > 0 && (
                            <div className={"hot-session"}>
                                <div className={"hot-title-box hot-title-margin"}>
                                    <img src={hot91png} />
                                    <div>91热搜</div>
                                </div>
                                <div>
                                    <RenderHotSearchCard list={pageData.hot} />
                                </div>
                            </div>
                        )}
                        {pageData.activity.length > 0 && (
                            <div className={"hot-session"}>
                                <div className={"hot-flex-row hot-justify-between hot-title-margin"}>
                                    <div className={"hot-title-box"}>
                                        <img src={dasaimvpng} />
                                        <div>大赛精选视频</div>
                                    </div>
                                    <Clickbtn onTap={() => handleMoreActivity()} className={"watch-more"}>更多精彩</Clickbtn>
                                </div>
                                <div className={"dasai-container hot-flex-row hot-justify-between"}>
                                    {pageData.activity.map((item, index) => (
                                        <Clickbtn onTap={() => onToTheCompetition(item.id, item.title)} key={index} className={"dasai-item"}><Simg src={item.thumb_index} /></Clickbtn>
                                    ))}
                                </div>
                            </div>
                        )}

                        {pageData.banner.length > 0 && <div className={"hot-session"}>
                            <div className={"hot-title-box hot-title-margin"}>
                                <img src={discoverjc} />
                                <div>发现精彩</div>
                            </div>
                            <Clickbtn onTap={() => handleAd(pageData.banner[0].url)} className={"ad-banner-box"}><Simg src={pageData.banner[0].img_url} noThumb/></Clickbtn>
                            <div>
                                <RenderFindWonderful list={pageData.find} />
                            </div>
                        </div>}
                    </div>
                </ScrollArea>
            ) : (
                <NoData />
            )}

        </div>
    )
}

const TimeLeftBox = (props) => {
    const { endtime } = props;
    const [timeLeft, setTimeLeft] = useState(null);

    useEffect(() => {
        const timer = setTimeout(() => {
            setTimeLeft(calculateTimeLeft());
        }, 1000);
        return () => clearTimeout(timer);
    }, [timeLeft]);

    const calculateTimeLeft = () => {
        let times = endtime * 1000;
        let difference = +new Date(times) - +new Date();
        let timeLeft = {};
        if (difference > 0) {
            timeLeft = {
                days: Math.floor(difference / (1000 * 60 * 60 * 24)),
                hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
                minutes: Math.floor((difference / 1000 / 60) % 60),
                seconds: Math.floor((difference / 1000) % 60),
                status: true,
            };
        } else {
            timeLeft = {
                days: 0,
                hours: 0,
                minutes: 0,
                seconds: 0,
                status: false
            };
        }
        return timeLeft;
    }

    return <div className={"time-left-box"}>
        <div style={{ marginBottom: "0.1rem" }}>{timeLeft && timeLeft.status ? "结束还有" : ""}</div>
        {timeLeft && <div className={"time-left-container"}>
            <div className="time-left-number">{timeLeft.days}</div>
            <div className="time-left-placeholder">:</div>
            <div className="time-left-number">{timeLeft.hours}</div>
            <div className="time-left-placeholder">:</div>
            <div className="time-left-number">{timeLeft.minutes}</div>
            <div className="time-left-placeholder">:</div>
            <div className="time-left-number">{timeLeft.seconds}</div>
        </div>}
    </div>
}


const RenderHotSearchCard = (props) => {
    const { list } = props;
    const [stacks] = StackStore.useGlobalState("stacks");

    const onToTheList = (item) => {
        const stackKey = `SimpleList-${new Date().getTime()}`;
        StackStore.dispatch({
            type: "push",
            payload: {
                name: "SimpleList",
                element: (
                    <StackPage
                        stackKey={stackKey}
                        key={stackKey}
                        style={{ zIndex: stacks.length + 2 }}
                    >
                        <SimpleList stackKey={stackKey} title={item.name} type={item.type} />
                    </StackPage>
                ),
            },
        });
    }

    return useMemo(() => (
        <div className={'a91hot-search-box'}>
            {list.map((item, index) => <Clickbtn onTap={() => { onToTheList(item) }} key={index} className={'a91hot-search-item'}>
                <div className={"a91hot-search-label"}>{item.name}</div><Simg className={"a91hot-search-image"} src={item.img_url} /></Clickbtn>)}</div>
    ), [list])
}

const RenderFindWonderful = (props) => {
    const { list } = props;
    const [stacks] = StackStore.useGlobalState("stacks");

    const onToTheList = (item) => {
        const stackKey = `listpage-${new Date().getTime()}`;
        StackStore.dispatch({
            type: "push",
            payload: {
                name: "ListPage",
                element: (
                    <StackPage
                        stackKey={stackKey}
                        key={stackKey}
                        style={{ zIndex: stacks.length + 2 }}
                    >
                        <ListPage stackKey={stackKey} tag={item.name} />
                    </StackPage>
                ),
            },
        });
    }

    return useMemo(() => (
        <div className={'find-wonderful-box'}>
            {list.map((item, index) => <Clickbtn onTap={() => onToTheList(item)} key={index} className={'find-wonderful-item'}>
                <div className={"find-wonderful-label"}>{item.label}</div><Simg noThumb className={"find-wonderful-image"} src={item.img_url} /></Clickbtn>)}</div>
    ), [list])
}

const RenderRankCard = (props) => {
    const { list } = props
    const [stacks] = StackStore.useGlobalState("stacks");

    const onToTheList = (item) => {
        const stackKey = `RankList-${new Date().getTime()}`;
        StackStore.dispatch({
            type: "push",
            payload: {
                name: "RankList",
                element: (
                    <StackPage
                        stackKey={stackKey}
                        key={stackKey}
                        style={{ zIndex: stacks.length + 2 }}
                    >
                        <RankList stackKey={stackKey} title={item.name} type={item.type} />
                    </StackPage>
                ),
            },
        });
    }

    return useMemo(() => (
        <HorizontalScroller>
            {list.map((item, index) => (
                <Clickbtn onTap={() => onToTheList(item)} className="rank-list-card-item" key={index}>
                    <div className="rank-list-card-content">
                        <div className="rank-list-card-name hot-flex-row">
                            <div>{item.name}</div>
                            <div>&gt;</div>
                        </div>
                        <div className="rank-list-card-info hot-flex-row">
                            <div className={"rank-list-card-avatar"}><Simg key={index} src={item.thumb} noThumb/></div>
                            <div className="rank-list-card-top">
                                <div className="rank-list-card-top-value">{item.top}</div>
                                <div className="rank-list-card-top-nickname">{item.nickname}</div>
                            </div>
                        </div>
                    </div>
                    <Simg className={"rank-list-card-backgroud"} key={index} src={item.thumb_backgroud} noThumb/>
                </Clickbtn>
            ))}
        </HorizontalScroller>
    ), [list])
}
