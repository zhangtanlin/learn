import React, { useState, useEffect } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/swiper.min.css";
import "swiper/components/pagination/pagination.min.css";
import "../../resources/css/hot.less";
import Tabsbar from "../tabsbar";
import NoData from "../noData";
import StackPage from "../stackpage";
import StackStore from "../../store/stack";
import Hotspot from './hotspot'
import Original from './original'
import Loading from '../loading'
import City from './city'

export default (props) => {
  const { isVisible } = props;
  const [init, setInit] = useState(false)
  const [tabIndex, setTabIndex] = useState(0);
  const [controlledSwiper, setControlledSwiper] = useState(null);
  const [stacks] = StackStore.useGlobalState("stacks");

  useEffect(() => {
    if (isVisible && !init) {
      setInit(true)
    }
  }, [isVisible])

  const tabs = [
    { name: "专区", id: 1 },
    { name: "原创", id: 2 },
    { name: "同城", id: 3 },
  ];

  const getSelect = (select) => {
    setTabIndex(select.index);
    controlledSwiper.slideTo(select.index);
  };

  const toSearch = () => {
    // const stackKey = `Search-${new Date().getTime()}`;
    // StackStore.dispatch({
    //   type: "push",
    //   payload: {
    //     name: "Search",
    //     element: (
    //       <StackPage
    //         stackKey={stackKey}
    //         key={stackKey}
    //         style={{ zIndex: stacks.length + 2 }}
    //       >
    //         <Search stackKey={stackKey} />
    //       </StackPage>
    //     ),
    //   },
    // });
  };

  return (
    <div
      className={`positioned-container ${isVisible ? "visible" : "hide"} hot-body`}
      style={{
        opacity: isVisible ? "1" : "0",
      }}
    >
      {init ? <>
        <div className={"tabs-header-container"}>
          <Tabsbar onChange={getSelect} arr={tabs} current={tabIndex} />
        </div>
        <Swiper
          initialSlide={0}
          className={"featured-swiper"}
          noSwipingClass={"noSwiper-container"}
          controller={controlledSwiper}
          onSwiper={setControlledSwiper}
          onSlideChange={(e) => {
            setTabIndex(e.activeIndex);
          }}
        >
          {tabs.map((item, index) => {
            switch (index) {
              case 0:
                return <SwiperSlide key={`${item.name}-${index}`}><Hotspot name={item.name} index={index} current={tabIndex} show={isVisible} /></SwiperSlide>
              case 1:
                return <SwiperSlide key={`${item.name}-${index}`}><Original name={item.name} index={index} current={tabIndex} show={isVisible} /></SwiperSlide>
              case 2:
                return <SwiperSlide key={`${item.name}-${index}`}><City name={item.name} index={index} current={tabIndex} show={isVisible} /></SwiperSlide>
              default:
                return <div></div>;
            }
          })}
        </Swiper>
      </> : <Loading />}
    </div>
  );
};
