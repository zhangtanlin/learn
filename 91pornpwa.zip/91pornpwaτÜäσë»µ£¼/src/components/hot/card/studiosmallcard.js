import React, { useMemo } from "react";
import Simg from '../../simg';
import hoticon from '../../../resources/img/hot/hot2x.png';
import smallbi from '../../../resources/img/hot/smallbi.png';
import playicon from '../../../resources/img/hot/playicon.png';
import newicon from '../../../resources/img/hot/new2x.png';
import StackPage from '../../stackpage'
import StackStore from '../../../store/stack'
import VideoDetail from '../../videoDetail'
import Clickbtn from '../../clickbtn'


export default (props) => {
    const { data, index } = props;
    const [stacks] = StackStore.useGlobalState("stacks");

    const toMvDetail = () => {
        const stackKey = `Search-${new Date().getTime()}`;
        StackStore.dispatch({
          type: "push",
          payload: {
            name: "Search",
            element: (
              <StackPage
                stackKey={stackKey}
                key={stackKey}
                style={{ zIndex: stacks.length + 2 }}
              >
                <VideoDetail stackKey={stackKey} id={data.id} />
              </StackPage>
            ),
          },
        });
      };


    return useMemo(() => (
        <Clickbtn onTap={()=>{ toMvDetail() }} className={"studio-small-card-container"}>
            <div className={"studio-small-card-thumb"}>
                { index && index == 1 &&  <img className={"studio-small-card-thumb-new"} src={newicon} />}
                { index && index > 1 && index < 4 && <img className={"studio-small-card-thumb-new"} src={hoticon} /> }
                <img className={"studio-small-card-thumb-play"} src={playicon} />
                <Simg src={data.thumbImg} className={"studio-small-card-thumb-pic"} />
            </div>
            <div className={"studio-small-card-title"}>
                <div className={"studio-small-card-title-text"}>{data.title}</div>
                <div className={"studio-small-card-content-text"}>{data.descriptions}</div>
                <div className={"studio-small-card-content-time"}>
                    <div className={"studio-small-card-content-time-value"}>{data.created_at}</div>
                    {data.coins > 0 && <div className={"studio-small-card-content-time-price"}><img src={smallbi} /><div>{data.coins}</div></div>}
                </div>
            </div>
        </Clickbtn>
    ), [data])
}