import React, { useMemo } from "react";
import Simg from '../../simg';
import likeicon from '../../../resources/img/hot/like-icon.png';
import { formatNumber } from '../../../libs/utils'
import Clickbtn from '../../clickbtn'

export default (props) => {
    const { data, rank, onTap } = props;
    
    return useMemo(() => (
        <Clickbtn onTap={()=>{
            onTap && onTap()
        }} className={"competition-card-container"}>
            <div className={"competition-card-thum"}><Simg src={data.thumbImg}/></div>
            <div className={"competition-card-info"}>
                <div className={"competition-card-rank"}>TOP.{rank}</div>
                <div className={"competition-card-content"}>{data.title}</div>
                <div className={"competition-card-nickname"}>作者：{data.nickName}</div>
                <div className={"competition-card-like-number"}>
                    <img src={likeicon}/>
                    <div>{formatNumber(data.like)}</div>
                </div>
            </div>
        </Clickbtn>
    ), [data])
}