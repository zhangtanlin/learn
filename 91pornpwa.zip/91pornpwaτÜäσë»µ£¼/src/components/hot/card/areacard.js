import React, { useMemo } from "react";
import Simg from '../../simg';
import smallbi from '../../../resources/img/hot/smallbi.png';
import playnumber from '../../../resources/img/hot/playnumber.png';
import likewhiteicon from '../../../resources/img/hot/likewhiteicon.png';
import yuanchuang from '../../../resources/img/hot/yuanchuang.png';
import { formatNumber } from '../../../libs/utils'
import Clickbtn from '../../clickbtn'

export default (props) => {
    const { data, index, onTap } = props;

    return useMemo(() => (
        <Clickbtn onTap={() => { onTap && onTap() }} className="area-card-container">
            <div className="area-card-movie-information">
                <div className="area-card-movie-is-original">{data.is_original && <img src={yuanchuang} />}</div>
                <div className="area-card-movie-is-tags">
                    {data.title}
                </div>
                <div className="area-card-movie-is-value">
                    <div className="flex-row">
                        <div className="flex-row">
                            <img className="small-img" src={likewhiteicon} />
                            <div>{formatNumber(data.like)}</div>
                        </div>
                        <div className="flex-row">
                            <img className="small-img play" src={playnumber} />
                            <div>{data.play_count}</div>
                        </div>
                    </div>
                    {data.coins > 0 && <div className="coins"><img src={smallbi} /><div>{data.coins}</div></div>}
                </div>
                <div className="area-card-movie-thumb"><Simg src={data.thumbImg} track={false}/></div>
            </div>
        </Clickbtn>
    ), [data])
}