import React, { useEffect, useMemo, useRef, useState } from "react";
import Simg from '../../simg';
import Clickbtn from '../../clickbtn'
import smallbi from '../../../resources/img/hot/smallbi.png';
import playnumber from '../../../resources/img/hot/playnumber.png';
import yuanchuang from '../../../resources/img/hot/yuanchuang.png';
import StackPage from '../../stackpage'
import StackStore from '../../../store/stack'
import ShortVideoList from '../../index/shortVideoList'

export default (props) => {
    const { data } = props;
    const [stacks] = StackStore.useGlobalState("stacks");

    const handleRoutes = (_index) => {
        const stackKey = `ShortVideoList-${new Date().getTime()}`;
        StackStore.dispatch({
            type: "push",
            payload: {
                name: "ShortVideoList",
                element: (
                    <StackPage
                        stackKey={stackKey}
                        key={stackKey}
                        style={{ zIndex: stacks.length + 2 }}
                    >
                        <ShortVideoList
                            stackKey={stackKey}
                            list={data.mvlist}
                            _current={_index}
                        />
                    </StackPage>
                ),
            },
        });
    }

    return useMemo(() => (
        <div className={"feature-card-container"}>
            <div className={"feature-card-title"}>
                <div className={"feature-card-title-month"}>{data.desc}</div>
                <div className={"feature-card-title-content"}>{data.name}</div>
            </div>
            <div className={"feature-card-movie-list"}>
                {data.mvlist.map((item,index)=>(
                    <Clickbtn onTap={()=>{
                        handleRoutes(index)
                    }} className={"feature-card-movie-item"} key={index}>
                        <div className={"feature-card-movie-play-info"}>
                        {item.is_original && <div className={"feature-card-movie-is-original"}><img src={yuanchuang} /></div>}
                            <div className={"feature-card-movie-play-row"}>
                                <div className={"feature-card-movie-play-number"}><img src={playnumber} /><div>{item.play_count}</div></div>
                                { item.coins > 0 &&<div className={"feature-card-movie-play-price"}><img src={smallbi} /><div>{item.coins}</div></div>}
                            </div>
                        </div>
                        <div className={"feature-card-movie-thumb"}><Simg src={item.thumbImg} /></div>
                    </Clickbtn>
                ))}
            </div>
        </div>
    ), [data])
}