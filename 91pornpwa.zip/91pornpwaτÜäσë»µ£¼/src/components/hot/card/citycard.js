import React, { useMemo } from "react";
import Simg from '../../simg';
import smallbi from '../../../resources/img/hot/smallbi.png';
import playnumber from '../../../resources/img/hot/playnumber.png';
import yuanchuang from '../../../resources/img/hot/yuanchuang.png';
import Clickbtn from '../../clickbtn'

export default (props) => {
    const { data, onTaps } = props;
    
    return useMemo(() => (
        <Clickbtn onTap={()=>{
            onTaps && onTaps()
        }} className={"city-card-container"}>
            <div className={"city-card-movie-information"}>
                <div className={"city-card-movie-play-info"}>
                    {data.is_original && <div className={"city-card-movie-is-original"}><img src={yuanchuang} /></div>}
                    <div className={"city-card-movie-play-row"}>
                        <div className={"hot-flex-row"}>
                            <div className={"city-card-movie-play-number"}><img src={playnumber} /><div>{data.play_count}</div></div>
                            {data.coins > 0 && <div className={"city-card-movie-play-price"}><img src={smallbi} /><div>{data.coins}</div></div>}
                        </div>
                        <div className={"city-card-user-avatar"}>
                            <Simg src={data.thumb} />
                        </div>
                    </div>
                </div>
                <div className={"city-card-movie-thumb"}><Simg src={data.thumbImg} track/></div>
            </div>
            <div className={"city-card-title"}>{data.title}</div>
        </Clickbtn>
    ),[data])
}