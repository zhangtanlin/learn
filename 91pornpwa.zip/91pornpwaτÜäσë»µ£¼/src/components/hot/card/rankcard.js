import React, { useEffect, useMemo, useRef, useState } from "react";
import Simg from '../../simg';
import rank1 from '../../../resources/img/hot/rank1.png';
import rank2 from '../../../resources/img/hot/rank2.png';
import rank3 from '../../../resources/img/hot/rank3.png';
import Clickbtn from '../../clickbtn'
import StackPage from '../../stackpage'
import StackStore from '../../../store/stack'
import Mine from '../../user/mine'


export default (props) => {
    const { data, index } = props;
    const [stacks] = StackStore.useGlobalState("stacks");

    const handleDetail = (uuid) => {
        if (uuid) {
            const stackKey = `user-main-${new Date().getTime()}`;
            StackStore.dispatch({
                type: "push",
                payload: {
                    name: "user-main",
                    element: (
                        <StackPage
                            stackKey={stackKey}
                            key={stackKey}
                            style={{ zIndex: stacks.length + 2 }}
                        >
                            <Mine stackKey={stackKey} uuid={uuid} />
                        </StackPage>
                    ),
                },
            });
        }
    };

    const RenderRankIconUrl = (props) => {
        const { index } = props
        switch (index) {
            case 0:
                return <img className="rank-list-card-icon" src={rank1} />;
            case 1:
                return <img className="rank-list-card-icon" src={rank2} />;
            case 2:
                return <img className="rank-list-card-icon" src={rank3} />;
            default:
                return <div className="rank-list-card-icon">{index+1}</div>;
        }
    }

    return useMemo(() => (
        <Clickbtn onTap={()=>handleDetail(data.uuid)} className="rank-list-card-container">
            <RenderRankIconUrl index={index}/>
            <div className="rank-list-card-avatar"><Simg src={data.thumb} /></div>
            <div>
                <div className="rank-list-card-nickname">{data.nickname}</div>
                <div>{data.text}</div>
            </div>
        </Clickbtn>
    ), [data, index])
}