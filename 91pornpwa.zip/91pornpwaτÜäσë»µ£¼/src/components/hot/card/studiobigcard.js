import React, { useMemo } from "react";
import Simg from '../../simg';
import Clickbtn from '../../clickbtn'
import StackPage from "../../stackpage";
import StackStore from "../../../store/stack";
import AlbumDetails from '../pages/albumdetails'
import hoticon from '../../../resources/img/hot/hot2x.png';
import newicon from '../../../resources/img/hot/new2x.png';
import arrowright from '../../../resources/img/hot/arrow-right.png';
import smallbi from '../../../resources/img/hot/smallbi.png';
import playicon from '../../../resources/img/hot/playicon.png';
import VideoDetail from '../../videoDetail'

export default (props) => {
    const { title, data, showMore, categoryId } = props;
    const [stacks] = StackStore.useGlobalState("stacks");

    const onToTheMore = (id) => {
        const stackKey = `competition-${new Date().getTime()}`;
        StackStore.dispatch({
            type: "push",
            payload: {
                name: "Competition",
                element: (
                    <StackPage
                        stackKey={stackKey}
                        key={stackKey}
                        style={{ zIndex: stacks.length + 2 }}
                    >
                        <AlbumDetails stackKey={stackKey} id={categoryId}/>
                    </StackPage>
                ),
            },
        });
    }

    const toMvDetail = () => {
        const stackKey = `Search-${new Date().getTime()}`;
        StackStore.dispatch({
          type: "push",
          payload: {
            name: "Search",
            element: (
              <StackPage
                stackKey={stackKey}
                key={stackKey}
                style={{ zIndex: stacks.length + 2 }}
              >
                <VideoDetail stackKey={stackKey} id={data.id} />
              </StackPage>
            ),
          },
        });
      };

    return useMemo(() => (
        <div className={"studio-big-card-container"}>
            <div className={"studio-big-card-title"}>
                <div className={"studio-big-card-title-text"}>{title}</div>
                {showMore && <Clickbtn onTap={() => onToTheMore(data.id)} className={"studio-big-card-title-more"}>
                    <div>更多</div>
                    <img src={arrowright} />
                </Clickbtn>}
            </div>
            <Clickbtn onTap={()=>{ toMvDetail() }} className={"studio-big-card-thumb"}>
                {data.isHotOrNew == 1 && <img className={"studio-big-card-thumb-new"} src={newicon} />}
                {data.isHotOrNew == 2 && <img className={"studio-big-card-thumb-new"} src={hoticon} />}
                <img className={"studio-big-card-thumb-play"} src={playicon} />
                <Simg src={data.thumbImg} className={"studio-big-card-thumb-pic"} />
            </Clickbtn>
            <Clickbtn onTap={()=>{ toMvDetail() }} className={"studio-big-card-content"}>
                <div className={"studio-big-card-content-text"}>{data.title}</div>
                <div className={"studio-big-card-content-time"}>
                    <div className={"studio-big-card-content-time-value"}>{data.created_at}</div>
                    { data.coins > 0 && <div className={"studio-big-card-content-time-price"}><img src={smallbi} /><div>{data.coins}</div></div> }
                </div>
            </Clickbtn>
        </div>
    ), [data,title])
}