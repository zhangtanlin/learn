import React, { useEffect, useMemo, useRef, useState } from "react";
import Simg from '../../simg';
import Clickbtn from '../../clickbtn';
import newmsg from '../../../resources/img/hot/newmsg.png';
import smallbi from '../../../resources/img/hot/smallbi.png';
import playnumber from '../../../resources/img/hot/playnumber.png';
import yuanchuang from '../../../resources/img/hot/yuanchuang.png';
import StackPage from '../../stackpage'
import StackStore from '../../../store/stack'
import ShortVideoList from '../../index/shortVideoList'
import HejiList from '../../hejiList'
import Mine from '../../user/mine'
import Emit from '../../../libs/eventEmitter'
import { setFollowUser } from '../../../libs/http'

export default (props) => {
    const { data } = props
    const [stacks] = StackStore.useGlobalState("stacks");
    const [isFollow, setIsFollow] = useState(data.user.is_follow);

    useEffect(() => {
        setIsFollow(data.user.is_follow)
    }, [data.user.is_follow])

    const handleDetail = (uuid) => {
        if (uuid) {
            const stackKey = `user-main-${new Date().getTime()}`;
            StackStore.dispatch({
                type: "push",
                payload: {
                    name: "user-main",
                    element: (
                        <StackPage
                            stackKey={stackKey}
                            key={stackKey}
                            style={{ zIndex: stacks.length + 2 }}
                        >
                            <Mine stackKey={stackKey} uuid={uuid} />
                        </StackPage>
                    ),
                },
            });
        }
    };

    const hanleFollow = () => {
        setFollowUser({uuid:data.user.uuid}).then((res)=>{
            Emit.emit("showToast", { text: res.msg });
            setIsFollow(!isFollow)
        })
    }

    const handleRoutes = (_index) => {
        const stackKey = `ShortVideoList-${new Date().getTime()}`;
        StackStore.dispatch({
            type: "push",
            payload: {
                name: "ShortVideoList",
                element: (
                    <StackPage
                        stackKey={stackKey}
                        key={stackKey}
                        style={{ zIndex: stacks.length + 2 }}
                    >
                        <ShortVideoList
                            stackKey={stackKey}
                            list={data.video_lists}
                            _current={_index}
                        />
                    </StackPage>
                ),
            },
        });
    }

    const handleHeji = () => {
        const stackKey = `HejiList-${new Date().getTime()}`;
        StackStore.dispatch({
          type: "push",
          payload: {
            name: "HejiList",
            element: (
              <StackPage
                stackKey={stackKey}
                key={stackKey}
                style={{ zIndex: stacks.length + 2 }}
              >
                <HejiList stackKey={stackKey} id={data.id} />
              </StackPage>
            ),
          },
        });
    }

    return useMemo(() => (
        <div className="original-card-container">
            <div className="original-card-user-info">
                <Clickbtn onTap={()=>handleDetail(data.user.uuid)} className="original-card-user-avatar"><Simg src={data.user.thumb} /></Clickbtn>
                <div className="original-card-user-number">
                    <div className="original-card-user-nickname">{data.user.nickname}</div>
                    <div>{data.user.person_attr}</div>
                </div>
                {isFollow ? <Clickbtn onTap={()=>hanleFollow()} className="original-card-like-status active">已關注</Clickbtn> : <Clickbtn onTap={()=>hanleFollow()} className="original-card-like-status">關注</Clickbtn>}
            </div>
            <Clickbtn onTap={()=>{ handleHeji() }} className="original-card-title">
                <div className="original-card-title-content">
                    {/* <img src={newmsg} /> */}
                    <div className="original-card-list-title">{data.title}</div>
                </div>
                <div className="original-card-movie-total">共{data.video_num}集 &gt;</div>
            </Clickbtn>
            <div className="original-card-movie-list">
                {data.video_lists.map((item,index) => {
                    return (
                        <Clickbtn onTap={()=>{
                            handleRoutes(index)
                        }} className="original-card-movie-item" key={index}>
                            <div className="original-card-movie-info">
                                <div className="original-card-movie-play-info">
                                    {item.is_original && <div className="original-card-movie-is-original"><img src={yuanchuang} /></div> }
                                    <div className="original-card-movie-play-row">
                                        <div className="original-card-movie-play-number"><img src={playnumber} /><span>{item.play_count}</span></div>
                                        { item.coins > 0 && <div className="original-card-movie-play-price"><img src={smallbi} /><span>{item.coins}</span></div> }
                                    </div>
                                </div>
                                <div className="original-card-movie-thumb"><Simg src={item.thumbImg} track={false}/></div>
                            </div>
                            <div className="original-card-movie-title">{item.title}</div>
                        </Clickbtn>
                    )
                })}
            </div>
        </div>
    ), [data, isFollow])
}
