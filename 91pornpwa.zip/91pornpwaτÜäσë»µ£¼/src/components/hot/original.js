import React, { useEffect, useMemo, useRef, useState } from "react";
import Simg from '../simg'
import Loading from '../loading'
import ScrollArea from '../scrollarea'
import NoData from '../noData'
import Emit from '../../libs/eventEmitter'
import Clickbtn from '../clickbtn'
import Originalcard from './card/originalcard'
import Featurecard from './card/featurecard'
import weekgod from '../../resources/img/hot/weekgod.png'
import jinbiicon from '../../resources/img/hot/jinbi.png'
import { getHotOriginal, getCollectRecommed } from '../../libs/http'
import Mine from '../user/mine'
import StackPage from "../stackpage";
import StackStore from "../../store/stack";

export default (props) => {
    const { index, current, show } = props;
    const [stacks] = StackStore.useGlobalState("stacks");
    const [data, setData] = useState({
        originalData: [],
        featureData: []
    });
    const [loading, setLoading] = useState(true);
    const [activeTab, setActiveTab] = useState(0);
    const [banner, setBanner] = useState({});
    const [upRankList, setUpRankList] = useState([])
    const [loadingMore, setLoadingMore] = useState({ a: true, b: true });
    let page = 1;
    let page2 = 1;
    useEffect(() => {
        if (index == current && data.originalData.length == 0 && show) {
            getListData()
        }
    }, [index, current, show])

    const getListData = () => {
        getHotOriginal().then((res) => {
            let result = res.data;
            setLoading(false);
            setBanner(result.banner);
            setUpRankList(result.upRankList)
            setData(prev => ({
                ...prev,
                ...{ originalData: result.recommend_video_list },
                ...{ featureData: result.items }
            }))
        }).catch(() => {
            Emit.emit("showToast", {
                text: "请求失败，请重试",
                time: 3000
            });
        })
    }

    const onGetMoreData = () => {
        if (activeTab == 0 && loadingMore.b) {
            page2++
            getCollectRecommed({ page: page2 }).then((res) => {
                let result = res.data;
                setLoading(false);
                setData(prev => ({
                    ...prev,
                    ...{ originalData: [...prev.originalData, ...result.item] },
                }))
                if (result.item.length < 24) {
                    loadingMore.b == false;
                    setLoadingMore({ ...loadingMore })
                }
            }).catch(() => {
                Emit.emit("showToast", {
                    text: "请求失败，请重试",
                    time: 3000
                });
            })
        } else {
            if (!loadingMore.a) return
            page++
            getHotOriginal({ page: page }).then((res) => {
                let result = res.data;
                setLoading(false);
                setData(prev => ({
                    ...prev,
                    ...{ featureData: [...prev.featureData, ...result.items] }
                }))
                if (result.items.length < 24) {
                    loadingMore.a == false;
                    setLoadingMore({ ...loadingMore })
                }
            }).catch(() => {
                Emit.emit("showToast", {
                    text: "请求失败，请重试",
                    time: 3000
                });
            })
        }

    }

    const hanldeTabsOnChange = (index) => {
        setActiveTab(index);
        page = 1;
        page2 = 1;
    }

    const handleAd = () => {
        window.open(banner.url, "_blank");
    }

    // 查看详情
    const handleDetail = (uuid) => {
        if (uuid) {
            const stackKey = `user-main-${new Date().getTime()}`;
            StackStore.dispatch({
                type: "push",
                payload: {
                    name: "user-main",
                    element: (
                        <StackPage
                            stackKey={stackKey}
                            key={stackKey}
                            style={{ zIndex: stacks.length + 2 }}
                        >
                            <Mine stackKey={stackKey} uuid={uuid} />
                        </StackPage>
                    ),
                },
            });
        }
    };

    return (
        <div className={"featured-swiper-item"}>
            {loading ? (
                <Loading show text={"正在获取数据..."} overSize={false} size={25} />
            ) : <ScrollArea
            groupId="original"
                ListData={data || activeTab}
                onScrollEnd={onGetMoreData}
                loadingMore={activeTab == 0 ? loadingMore.b : loadingMore.a}
                pullDonRefresh={() => {
                    page = 1;
                    page2 = 2;
                    loadingMore.a == true;
                    loadingMore.b == true;
                    setLoadingMore({ ...loadingMore })
                    setData({
                        originalData: [],
                        featureData: []
                    });
                    setLoading(true);
                    getListData();
                }}
            >
                <div className={"hot-main"}>
                    {banner && <Clickbtn onTap={() => handleAd()} className={"ad-header-container original"}> <Simg src={banner.img_url} noThumb/></Clickbtn>}
                    <div className={"week-god-container"}><img src={weekgod} /></div>
                    <div className={"hot-session"}>
                        {upRankList.length >= 3 && <div className={"original-rank-box hot-flex-row hot-justify-between"}>
                            <Clickbtn onTap={() => handleDetail(upRankList[1].uuid)} className={"original-rank-item"}>
                                <div className={"original-rank-number"}>TOP.2</div>
                                <div className={"original-rank-avatar"}><Simg src={upRankList[1].thumb} noThumb/></div>
                                <div className={"original-rank-nickname"}>
                                    <div>{upRankList[1].nickname}</div>
                                    <div>{upRankList[1].mv_count}个视频</div>
                                    <div>奖励</div>
                                </div>
                                <div className={"original-rank-like-number hot-flex-row"}>
                                    <img src={jinbiicon} />
                                    <div className={"original-rank-play-number"}>{upRankList[1].coins}</div>
                                </div>
                            </Clickbtn>
                            <Clickbtn onTap={() => handleDetail(upRankList[0].uuid)} className={"original-rank-item"}>
                                <div className={"original-rank-number"}>TOP.1</div>
                                <div className={"original-rank-avatar"}><Simg src={upRankList[0].thumb} noThumb/></div>
                                <div className={"original-rank-nickname"}>
                                    <div>{upRankList[0].nickname}</div>
                                    <div>{upRankList[0].mv_count}个视频</div>
                                    <div>奖励</div>
                                </div>
                                <div className={"original-rank-like-number hot-flex-row"}>
                                    <img src={jinbiicon} />
                                    <div className={"original-rank-play-number"}>{upRankList[0].coins}</div>
                                </div>
                            </Clickbtn>
                            <Clickbtn onTap={() => handleDetail(upRankList[2].uuid)} className={"original-rank-item"}>
                                <div className={"original-rank-number"}>TOP.3</div>
                                <div className={"original-rank-avatar"}><Simg src={upRankList[2].thumb} noThumb/></div>
                                <div className={"original-rank-nickname"}>
                                    <div>{upRankList[2].nickname}</div>
                                    <div>{upRankList[2].mv_count}个视频</div>
                                    <div>奖励</div>
                                </div>
                                <div className={"original-rank-like-number hot-flex-row"}>
                                    <img src={jinbiicon} />
                                    <div className={"original-rank-play-number"}>{upRankList[2].coins}</div>
                                </div>
                            </Clickbtn>
                        </div>}

                    </div>

                </div>
                <div className={"hot-session"} >
                    <RenderTabs onChange={(e) => hanldeTabsOnChange(e)} activeTab={activeTab} />
                    <div>
                        {activeTab == 0 ? <div>
                            {data.originalData.map((item, index) => (
                                <Originalcard data={item} key={index} />
                            ))}
                        </div>
                            :
                            <div>
                                {data.featureData.map((item, index) => (
                                    <Featurecard data={item} key={index} />
                                ))}
                            </div>
                        }
                    </div>
                </div>
                <div style={{ height: "30px" }} />
            </ScrollArea>}
        </div>
    )
}


const RenderTabs = (props) => {
    const { onChange, activeTab } = props;

    const handleOnChange = (index) => {
        onChange && onChange(index)
    }

    return <div className={'original-tabs noSwiper-container'} >
        <Clickbtn
            className={activeTab == 0 ? "active" : ""}
            onTap={() => {
                handleOnChange(0)
            }}
        >
            原创推荐
        </Clickbtn>
        <Clickbtn
            className={activeTab == 1 ? "active" : ""}
            onTap={() => {
                handleOnChange(1)
            }}
        >
            每日精选
        </Clickbtn>
    </div>
}
