import React, { useEffect, useMemo, useRef, useState } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/swiper.min.css";
import "swiper/components/pagination/pagination.min.css";
import Simg from '../simg'
import Loading from '../loading'
import ScrollArea from '../scrollarea'
import NoData from '../noData'
import Clickbtn from '../clickbtn'
import Citycard from './card/citycard'
import weekgod from '../../resources/img/hot/weekgod.png'
import jinbiicon from '../../resources/img/hot/jinbi.png'
import downicon from '../../resources/img/hot/downicon.png'
import Emit from "../../libs/eventEmitter";
import StackPage from "../stackpage";
import StackStore from "../../store/stack";
import ShortVideoList from '../index/shortVideoList'
import { getCity } from '../../libs/http'

export default (props) => {
    const { index, current, show } = props;
    const [controlledSwiper, setControlledSwiper] = useState(null);
    const [activeTab, setActiveTab] = useState(0);
    const [cityValue, setCityValue] = useState('火星')
    const [loadingPage, setLoadingPage] = useState(true)
    let tabs = [
        { name: '最新', type: 'new' },
        { name: '最热', type: 'hot' }
    ]

    useEffect(() => {
        Emit.on("choosePicker", (res)=>{
            setCityValue(res)
        })
        return () => {
            Emit.off("choosePicker")
        }
    }, [])

    useEffect(() => {
        if (index == current && show) {
            setLoadingPage(false)
        }
    }, [index, current])

    const hanldeTabsOnChange = (index) => {
        setActiveTab(index);
        controlledSwiper.slideTo(index);
    }

    const handleCityPicker = () => {
        Emit.emit("showPicker")
    }

    return (
        <div className={"featured-swiper-item"}>
            <div className={"city-header-picker-container noSwiper-container"}>
                <RenderTabs tabs={tabs} onChange={(e) => hanldeTabsOnChange(e)} activeTab={activeTab} />
                <Clickbtn onTap={() => handleCityPicker()} className={"city-header-picker-value"}>
                    <div>{cityValue}</div>
                    <img src={downicon} />
                </Clickbtn>
            </div>
            {loadingPage ? <Loading show text={"正在获取数据..."} overSize={false} size={25} /> :
                <Swiper
                    className={"featured-swiper"}
                    controller={controlledSwiper}
                    onSwiper={setControlledSwiper}
                    onSlideChange={(e) => {
                        setActiveTab(e.activeIndex);
                    }}
                >
                    {tabs.map((item, index) => (
                        <SwiperSlide key={index}>
                            <RenderList current={activeTab} index={index} type={item.type} show={show} city={cityValue} />
                        </SwiperSlide>
                    ))}
                </Swiper>
            }
        </div>
    )
}

const RenderList = (props) => {
    const { current, index, show, city, type } = props;
    const [stacks] = StackStore.useGlobalState("stacks");
    const [data, setData] = useState({
        even: [],
        odd: []
    });
    const [ backupData, setBackUpdata ] = useState([]);
    const [loading, setLoading] = useState(true);
    const [loadingMore, setLoadingMore] = useState({ a: true });

    let page = 1
    useEffect(() => {
        if (index === current && data.even.length == 0 && show) {
            getListData()
        }
    }, [current])

    useEffect(() => {
        if (index == current){
            page = 1
            setLoading(true)
            getListData()
        }
    }, [city])

    const getListData = () => {
        getCity({ city_id: city, sort: type }).then((res) => {
            let result = res.data;
            setLoading(false);
            let arrayList = result.list;
            setBackUpdata(arrayList)
            let even = []
            let odd = []
            even = arrayList.filter(function(v,i){
                return i % 2 == 0
            })
            odd = arrayList.filter(function(v,i){
                return i % 2 == 1
            })
            setData(prev => ({
                ...prev,
                ...{ even: even },
                ...{ odd: odd }
            }))
        }).catch(() => {
            Emit.emit("showToast", {
                text: "请求失败,请重试",
                time: 3000
            });
        })
    }

    const onGetMoreData = () => {
        if (!loadingMore.a) return;
        page++
        getCity({ city_id: city, sort: type, page: page }).then((res) => {
            let result = res.data;
            if (result.length == 0) {
                setLoadingMore({ a: false })
                return
            }
            let arrayList = result.list;
            setBackUpdata(prev => [ ...prev, ...arrayList])
            let even = []
            let odd = []
            even = arrayList.filter(function(v,i){
                return i % 2 == 0
            })
            odd = arrayList.filter(function(v,i){
                return i % 2 == 1
            })
            setData(prev => ({
                ...prev,
                ...{ even: [...prev.even, ...even] },
                ...{ odd: [...prev.odd, ...odd] }
            }))
        }).catch(() => {
            Emit.emit("showToast", {
                text: "请求失败，请重试",
                time: 3000
            });
        })
    }

    const handleRoutes = (_index) => {
        const stackKey = `ShortVideoList-${new Date().getTime()}`;
        StackStore.dispatch({
            type: "push",
            payload: {
                name: "ShortVideoList",
                element: (
                    <StackPage
                        stackKey={stackKey}
                        key={stackKey}
                        style={{ zIndex: stacks.length + 2 }}
                    >
                        <ShortVideoList
                            stackKey={stackKey}
                            list={backupData}
                            _page={page}
                            _current={_index}
                            pramas={{
                                mod: "activity",
                                code: "detail",
                                city_id: city,
                                sort: type,
                            }}
                        />
                    </StackPage>
                ),
            },
        });
    }

    return (
        <div className="positioned-container">
            {loading ? (
                <Loading show text={"正在获取数据..."} overSize={false} size={25} />
            ) : current == 0 && data.even.length > 0 || current == 1 && data.odd.length > 0 ? (
                <ScrollArea
                    ListData={data}
                    onScrollEnd={onGetMoreData}
                    loadingMore={loadingMore.a}
                    pullDonRefresh={() => {
                        page = 1;
                        loadingMore.a = true;
                        setData({
                            even: [],
                            odd: []
                        });
                        setLoading(true);
                        setLoadingMore({ ...loadingMore });
                        getListData();
                    }}
                >
                    <div className="waterfall-list">
                        <div className="waterfall-list-even">
                            {data.even.map((item,index)=>(
                                <Citycard data={item} key={index} onTaps={ ()=>{ handleRoutes(index * 2) } }/>
                            ))}
                        </div>
                        <div className="waterfall-list-odd">
                            {data.odd.map((item,index)=>(
                                <Citycard data={item} key={index} onTaps={ ()=>{ handleRoutes(index * 2 +1) } }/>
                            ))}
                        </div>
                    </div>
                    <div className={"hot-session"}></div>
                </ScrollArea>
            ) : (
                <NoData />
            )}
        </div>
    )
}

const RenderTabs = (props) => {
    const { onChange, activeTab, tabs } = props;

    const handleOnChange = (index) => {
        onChange && onChange(index)
    }

    return <div className={'city-tabs noSwiper-container'}>
        {tabs.map((item, index) => (
            <Clickbtn
                key={index}
                className={activeTab == index ? "active" : ""}
                onTap={() => {
                    handleOnChange(index)
                }}
            >
                {item.name}
            </Clickbtn>
        ))}
    </div>
}
