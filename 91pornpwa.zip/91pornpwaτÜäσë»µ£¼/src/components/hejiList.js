/*
 * @Author: Tom
 * @Date: 2021-11-26 15:48:26
 * @LastEditTime: 2021-12-08 17:54:30
 * @LastEditors: Tom
 * @Description:
 * @FilePath: /91pornpwa/src/components/hejiList.js
 */
import React, { useEffect, useMemo, useRef, useState } from "react";
import "../resources/css/hejiList.less";
import StackStore from "../store/stack";
import UserStore from "../store/user";
import Clickbtn from "./clickbtn";
import ScrollArea from "./scrollarea";
import Emit from "../libs/eventEmitter";
import Loading from "./loading";
import NoData from "./noData";
import Simg from "./simg";
import StackPage from "./stackpage";
import Dialog from "./dialog_scale";
import back from "../resources/img/search/back_white.png";
import fansIcon from "../resources/img/public/fansIcon.png";
import coinIcon from "../resources/img/search/coin.png";
import ShortVideoList from "./index/shortVideoList";
import { getHejiDetail } from "../libs/http";

export default (props) => {
  const { stackKey, id } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState(null);
  const [list, setList] = useState([]);
  const [loadingMore, setLoadingMore] = useState({ a: true });
  let page = 1;
  useEffect(() => {
    getData();
  }, []);
  const getData = async () => {
    try {
      let res = await getHejiDetail({ id });
      // console.log("数据时代精神", res.data);
      setLoading(false);
      if (res.data) {
        setData(res.data);
        setList(res.data.list);
      }
    } catch (error) {
      setLoading(false);
    }
  };

  const onGetMoreData = async () => {
    if (!loadingMore.a) return;
    page++;
    try {
      let res = await getHejiDetail({ id, page });
      if (res.data.list.length > 0) {
        setList((pre) => [...pre, ...res.data.list]);
      } else {
        loadingMore.a = false;
        setLoadingMore({ ...loadingMore });
      }
    } catch (error) {}
  };

  const toShortVideo = (_index) => {
    const stackKey = `ShortVideoList-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "ShortVideoList",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <ShortVideoList
              stackKey={stackKey}
              list={data.list}
              _page={1}
              _current={_index}
            />
          </StackPage>
        ),
      },
    });
  };
  const renderHeader = () => {
    return (
      <div className="fansDetail_header">
        <Clickbtn
          className="fansDetail_header_back"
          onTap={() => {
            Emit.emit(stackKey, stackKey);
          }}
        >
          <img src={back} />
        </Clickbtn>
        <div className="fansDetail_header_title">合集详情</div>
      </div>
    );
  };
  const hejiHeader = () => {
    if (!data) {
      return null;
    }
    return (
      <div className="hejiList_info">
        <div className="hejiList_info_cover">
          <Simg src={data.cover} />
        </div>
        <div className="hejiList_info_right">
          <p className="hejiList_title">{data.title}</p>
          <div className="hejiList_text">
            <span>{data.play_num} 播放</span>
            <span>{data.like} 点赞</span>
          </div>
          <p className="hejiList_title">共{data.video_num}集</p>
        </div>
      </div>
    );
  };

  const hejiItem = (item, index) => {
    return (
      <Clickbtn
        className="hejiList_card"
        key={index}
        onTap={() => {
          toShortVideo(index);
        }}
      >
        <div className="hejiList_card_cover">
          <Simg src={item.thumbImg} />
          <div className="hejiList_card_layer">
            <img
              style={{ opacity: item.is_club_fans ? 1 : 0 }}
              src={fansIcon}
            />
            {!!item.coins && (
              <span>
                <img src={coinIcon} />
                <span>{item.coins}</span>
              </span>
            )}
          </div>
        </div>
        <div className="hejiList_info_right">
          <p className="hejiList_title">{item.title}</p>
          <div className="hejiList_text">
            <span>{item.play_count} 播放</span>
            <span>{item.like} 点赞</span>
          </div>
          {!!item.total_coins && (
            <div className="hejiList_card_bttom">
              总收益
              <img src={coinIcon} />
              <span>{item.total_coins}</span>
            </div>
          )}
        </div>
      </Clickbtn>
    );
  };
  return (
    <div className="page-content-flex hejiList">
      {renderHeader()}
      {hejiHeader()}
      {loading ? (
        <Loading show type={1} />
      ) : list.length > 0 ? (
        <ScrollArea
          downRefresh={false}
          ListData={list}
          onScrollEnd={onGetMoreData}
          paddingBottom={"0.8rem"}
          loadingMore={loadingMore.a}
        >
          {list.map((item, index) => {
            return hejiItem(item, index);
          })}
        </ScrollArea>
      ) : (
        <NoData />
      )}
    </div>
  );
};
