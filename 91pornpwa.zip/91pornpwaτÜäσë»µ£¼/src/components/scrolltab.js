import React, { useEffect, useRef, useState } from "react";
import ScrollH from "./horizontal_scroller";
import "../resources/css/scrolltabs.less";

export default (props) => {
  const { tabs, onTap } = props;
  const [tabIndex, setTabIndex] = useState(0);

  const handleOnTap = (value) => {
    onTap && onTap(value)
  }

  return (
    <div className="common-tab">
      <ScrollH>
        {tabs.map((item, index) => {
          return (
            <TabItem
              item={item}
              key={index}
              index={index}
              tabIndex={tabIndex}
              onTap={(i) => {
                setTabIndex(i);
                handleOnTap(item)
              }}
            />
          );
        })}
      </ScrollH>
    </div>
  );
};

const TabItem = (props) => {
  const { item, index, tabIndex, onTap } = props;
  const itemRef = useRef(null);
  useEffect(() => {
    if (!itemRef.current) {
      return;
    }
    const itemHammer = new Hammer(itemRef.current);
    itemHammer.on("tap", onClick);
    return () => {
      itemHammer.off("tap", onClick);
    };
  }, [itemRef.current, tabIndex]);
  const onClick = () => {
    // console.log(tabIndex, index);
    if (tabIndex != index) {
      onTap && onTap(index);
    }
  };
  return (
    <span
      className={`tab-item ${index == tabIndex ? "tab-item-active" : ""
        }`}
      key={index}
      ref={itemRef}
    >
      {item.label}
    </span>
  );
};
