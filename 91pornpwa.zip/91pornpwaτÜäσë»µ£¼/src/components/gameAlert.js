import React, { useEffect, useRef, useState } from "react";
import emit from "../libs/eventEmitter";
import "../resources/css/gameAlert.less";
import Scrollarea from './scrollarea'
import closeIcon from "../resources/img/game/close.png";
import gameheaderIcon from "../resources/img/game/game-header.png";
export default (props) => {
  const [show, setShow] = useState(false);
  const [isHide, setIsHide] = useState(true);
  const [noBtn, setNobtn] = useState(false);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [funcs, setFuncs] = useState({
    cancel: null,
    submit: null,
  });
  const [submitText, setSubmitText] = useState("确认");

  let timer;
  let timer1;
  useEffect(() => {
    emit.on(
      "gameAlert",
      ({ _title, _content, _cancel, _submit, _submitText, _Nobtn }) => {
        // timer && clearTimeout(timer);
        timer1 && clearTimeout(timer1);
        timer1 = setTimeout(() => {
          setIsHide(false);
        }, 100);
        // setIsHide(false);
        setShow(true);
        setNobtn(!!_Nobtn);
        _title && setTitle(_title);
        _content && setContent(_content);
        setFuncs({
          cancel: _cancel,
          submit: _submit,
        });
        _submitText && setSubmitText(_submitText);
      }
    );
    return () => {
      emit.off("gameAlert");
    };
  }, []);
  const onClose = () => {
    hideSelf();
    funcs.cancel && funcs.cancel();
  };
  const onSubmit = () => {
    hideSelf();
    funcs.submit && funcs.submit();
  };
  const hideSelf = () => {
    setIsHide(true);
    timer && clearTimeout(timer);
    timer = setTimeout(() => {
      setShow(false);
      setTitle("");
      setContent("");
      setFuncs({
        cancel: null,
        submit: null,
      });
      setNobtn(false);
      setSubmitText("确认");
    }, 300);
  };
  if (!show) {
    return "";
  }

  return (
    <div
      className={`gameAlert ${isHide ? "gameAlert-out" : "gameAlert-in"}`}
      onTouchEndCapture={noBtn ? onClose : () => { }}
    >
      <div className={"gameAlert-body"}>
        <img className="gameAlert-header" src={gameheaderIcon} />
        <img className={"gameAlert-close"} src={closeIcon} onTouchEndCapture={onClose} />
        <span className={"gameAlert-title"}>{title}</span>
        <div className={"gameAlert-content"}>
          <div
            style={{
              lineHeight: "1.5"
            }}
            dangerouslySetInnerHTML={{
              __html: content.replaceAll("\n", "<br/>")
            }}
          ></div>
        </div>
        {noBtn ? (
          ""
        ) : (
          <div className={"gameAlert-btn-box"}>
            <div className={"gameAlert-btn-submit"} onTouchEndCapture={onSubmit}>
              {submitText}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
