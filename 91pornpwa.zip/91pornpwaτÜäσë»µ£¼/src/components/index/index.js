/*
 * @Author: Tom
 * @Date: 2021-11-15 20:48:32
 * @LastEditTime: 2022-01-15 10:14:00
 * @LastEditors: Tom
 * @Description:
 * @FilePath: /91pornpwa/src/components/index/index.js
 */
import React, { useEffect, useMemo, useRef, useState } from "react";
// import Hammer from "hammerjs";
// import CryptoData from "../../libs/CryptoData";
// import axios from "axios";
import QRCode from "qrcode.react";
import { Swiper, SwiperSlide } from "swiper/react";
import "../../resources/css/index.less";
import "swiper/swiper.min.css";

import StackStore from "../../store/stack";
import UserStore from "../../store/user";
import ScrollArea from "../scrollarea";
import Clickbtn from "../clickbtn";
import Simg from "../simg";
import Loading from "../loading";
import NoData from "../noData";
import Dialog from "../dialog_scale";
import Emit from "../../libs/eventEmitter";
import { copyText } from "../../libs/utils";
import globalVar from "../../libs/globalVar";

import videologo from "../../resources/img/index/videologo.png";
import searchIcon from "../../resources/img/index/search.png";
import hotIcon from "../../resources/img/index/hot.png";
import yellowRight from "../../resources/img/index/yellowRight.png";
import likeIcon from "../../resources/img/index/like.png";
import likeActiveIcon from "../../resources/img/index/likeActive.png";
import commentIcon from "../../resources/img/index/comment.png";
import shareIcon from "../../resources/img/index/share.png";
import locationIcon from "../../resources/img/index/icon_video_location.png";
import playIcon from "../../resources/img/index/icon_home_play_status.png";
import videoDetailIcon from "../../resources/img/index/icon_video_play_detail_white.png";
import followIcon from "../../resources/img/index/icon_home_follow_red.png";
import closeIcon from "../../resources/img/index/icon_friend_close.png";
import hejiIcon from "../../resources/img/index/hejiIcon.png";
import logo from "../../resources/img/index/icon_share_top_logo.png";
import coinIcon from "../../resources/img/search/coin.png";

import AlbumDetails from '../../components/hot/pages/albumdetails'
import Studio from '../../components/hot/pages/studionew'

import VideoPlayer from "../videoPlayer";
import BottomLayer from "../bottomLayer";
import CommentCard from "../card/commentCard";
import BottomLoading from "../bottomLoading";
import StackPage from "../stackpage";
import Search from "./search";
import Hot91 from "./hot91New";
// import Hot91 from "./hot91";
import TagList from "./tagList";
import BigMv from "../hot/pages/studio";
import PersonPage from "../user/mine";
import MyShare from "../user/myShare";
import Recharge from "../user/recharge";
import BindPhone from "../user/bindPhoneNew";
import LongVideo from "./longVideo";
import ShortVideoList from "./ShortVideoList";
import {
  getIndexList,
  getIndexFollowList,
  setVideoLike,
  getCommentList,
  setFollowUser,
  sendVideoComment,
  getHejiDetail,
  sendWatchList,
} from "../../libs/http";

let playAlertState = true

export default (props) => {
  const { isVisible } = props;
  const navs = ["关注", "推荐"];
  const [tabIndex, setTabIndex] = useState(1);
  const [controlledSwiper, setControlledSwiper] = useState(null);
  const [stacks] = StackStore.useGlobalState("stacks");
  const toLogin = () => {
    Emit.emit("showToast", { text: "请先登录或注册！" });
    const stackKey = `BindPhone-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "bindPhone",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <BindPhone stackKey={stackKey} />
          </StackPage>
        ),
      },
    });
  };
  const toSearch = () => {
    // if (!globalVar.isBindMobile) {
    //   toLogin();
    // } else {
    const stackKey = `Search-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "Search",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <Search stackKey={stackKey} />
          </StackPage>
        ),
      },
    });
    // }
  };
  const toBigMv = () => {
    // if (!globalVar.isBindMobile) {
    //   toLogin();
    // } else {
    const stackKey = `competition-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "Competition",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <Studio stackKey={stackKey} />
          </StackPage>
        ),
      },
    });
    // const stackKey = `BigMv-${new Date().getTime()}`;
    // StackStore.dispatch({
    //   type: "push",
    //   payload: {
    //     name: "BigMv",
    //     element: (
    //       <StackPage
    //         stackKey={stackKey}
    //         key={stackKey}
    //         style={{ zIndex: stacks.length + 2 }}
    //       >
    //         <AlbumDetails stackKey={stackKey} />
    //       </StackPage>
    //     ),
    //   },
    // });

    // }
  };
  const renderHeader = () => {
    return (
      <div className="index_header">
        <img src={videologo} onClick={toBigMv} />
        <div className="index_header_tab">
          {navs.map((item, index) => {
            return (
              <Clickbtn
                key={index}
                className={tabIndex == index ? "active" : ""}
                onTap={() => {
                  setTabIndex(index);
                  controlledSwiper.slideTo(index);
                }}
              >
                {item}
              </Clickbtn>
            );
          })}
        </div>
        <img src={searchIcon} onClick={toSearch} />
      </div>
    );
  };
  return useMemo(
    () => (
      <div
        className={`positioned-container ${isVisible ? "visible" : "hide"
          } index_container`}
        style={{
          opacity: isVisible ? "1" : "0",
        }}
      >
        {renderHeader()}
        <Swiper
          initialSlide={1}
          className={"featured-swiper"}
          onSwiper={setControlledSwiper}
          controller={controlledSwiper}
          onSlideChange={(e) => {
            setTabIndex(e.activeIndex);
          }}
        >
          {navs.map((item, index) => {
            return (
              <SwiperSlide key={`index_swiper${index}`}>
                <IndexItem
                  currentTab={tabIndex}
                  tabIndex={index}
                  isVisible={isVisible}
                />
              </SwiperSlide>
            );
          })}
        </Swiper>
      </div>
    ),
    [isVisible, tabIndex, controlledSwiper, stacks]
  );
};

let loadingTimer;
let isPlaying = false;
let isFirst = true;
let isAddVideo = false;
let isChange = false;
const IndexItem = (props) => {
  const { tabIndex, currentTab, isVisible } = props;
  const videoRef = useRef(null);
  const sourceRef = useRef(null);
  const [stacks] = StackStore.useGlobalState("stacks");
  const [user] = UserStore.useGlobalState("user");
  const [isVip, setIsVip] = useState(false);
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isPause, setIsPause] = useState(true);
  const [current, setCurrent] = useState(0);
  const [isTouch, setIsTouch] = useState(false);
  const [showBottomLayer, setShowBottomLayer] = useState(false);
  const [bottomLayerType, setBottomLayerType] = useState(1); // 1显示评论，2显示合集
  const [showDialog, setShowDialog] = useState(false);
  const [videoLoading, setVideoLoading] = useState(true);
  const [shouldPlay, setShouldPlay] = useState(true);
  const [videoUrl, setVideoUrl] = useState("");
  const [commentInfo, setCommentInfo] = useState(null);
  const [hejiInfo, setHejiInfo] = useState(null);
  const [page, setPage] = useState({ page: 1 });
  const [isAll, setIsAll] = useState(false);
  useEffect(() => {
    if (currentTab == tabIndex && data.length == 0) {
      getData();
    }
    // 切换tab后初始化状态
    setIsTouch(false);
    setIsPause(true);
    setVideoLoading(true);
    isFirst = true;
  }, [currentTab]);

  useEffect(() => {
    if (page.page > 1) {
      getData();
    }
  }, [page]);

  const getData = async () => {
    let res;
    if (tabIndex == 1) {
      if (page.page == 1) {
        res = {
          data: globalVar.firstData,
        }
      } else {
        res = await getIndexList({ page: page.page, limit: 20 });
      }
    } else {
      res = await getIndexFollowList({ page: page.page, limit: 20 });
    }
    if (loading) {
      setLoading(false);
    }
    if (res.data && res.data.length > 0) {
      if (isAll) {
        setIsAll(false);
      }
      if (page.page == 1) {
        getVideoUrl(res.data[0].playUrl, (link) => {
          setVideoUrl(link);
        });
        // setVideoUrl(videosList[0]);
      }
      setData((pre) => [...pre, ...res.data]);
    } else {
      setIsAll(true);
    }
    // console.log(`首页${tabIndex}`, res.data);
  };

  const getVideoUrl = async (url, callBack) => {
    try {
      // let m3u8Res = await axios.get(url);
      // const m3u8 = CryptoData.DecryptVideo(m3u8Res.data);
      // const blob = new Blob([m3u8], {
      //   type: "application/x-mpegURL",
      // });
      // const link = URL.createObjectURL(blob);
      // callBack(link);
      callBack(url);
      // 更新用户次数
      // setUserData();
    } catch (error) {
      // console.log("获取播放链接失败", error);
      // alert(typeof error);
    }
  };

  const toShare = () => {
    const stackKey = `myshare-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "myshare",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <MyShare stackKey={stackKey} />
          </StackPage>
        ),
      },
    });
  };

  const toVip = () => {
    const stackKey = `recharge-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "recharge",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <Recharge stackKey={stackKey} />
          </StackPage>
        ),
      },
    });
  };

  const toLongVideo = (index) => {
    const stackKey = `LongVideo-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "LongVideo",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <LongVideo stackKey={stackKey} _data={data[index]} />
          </StackPage>
        ),
      },
    });
  };

  const watchPost = (videoIndex) => {
    let res = localStorage.getItem("91PRON_DAILY_VIEW");
    if (!res) {
      globalVar.daily_view = 5;
      let dailyData = {
        daily_view: 5,
        day: new Date().getDate(),
        ids: [data[videoIndex].id],
      };
      localStorage.setItem("91PRON_DAILY_VIEW", JSON.stringify(dailyData));
    } else {
      let result = JSON.parse(res);
      // 没看过，扣次数
      result.daily_view = result.daily_view - 1;
      result.ids.push(data[videoIndex].id);
      globalVar.daily_view = result.daily_view;
      localStorage.setItem("91PRON_DAILY_VIEW", JSON.stringify(result));
      if (globalVar.daily_view <= 1) {
        // 上报观看次数
        sendWatchList({
          timestamp: new Date(new Date().toLocaleDateString()).getTime(),
          items: result.ids.join(","),
        }).then(() => {
          localStorage.setItem("91PRON_DAILY_VIEW", '');
        });
      }
    }
  }

  const checkShouldPlay = (videoIndex) => {
    // console.log("globalVar.daily_view", globalVar.daily_view);
    if (user.isVip) {
      // 会员免费
      setShouldPlay(true);
    } else if (globalVar.daily_view < 1) {
      // 次数用完
      setShouldPlay(false);
      Emit.emit("changeAlert", {
        _title: "提示",
        _content: globalVar.shareText,
        _cancelText: "去充值VIP",
        _submitText: "去分享视频",
        _cancel: toVip,
        _submit: toShare,
        _notDouble: false,
        _theme: "black",
      });
    } else {
      // 有次数，还能看
      setShouldPlay(true);
      let res = localStorage.getItem("91PRON_DAILY_VIEW");
      if (!res) {
        globalVar.daily_view = 5;
        let dailyData = {
          daily_view: 5,
          day: new Date().getDate(),
          ids: [data[videoIndex].id],
        };
        localStorage.setItem("91PRON_DAILY_VIEW", JSON.stringify(dailyData));
      } else {
        let result = JSON.parse(res);
        // 去重
        const hasId = result.ids.filter((e) => e == data[videoIndex].id);
        // 没看过，扣次数
        if (hasId.length == 0) {
          result.daily_view = result.daily_view - 1;
          result.ids.push(data[videoIndex].id);
          globalVar.daily_view = result.daily_view;
          localStorage.setItem("91PRON_DAILY_VIEW", JSON.stringify(result));
          if (globalVar.daily_view < 1) {
            // 上报观看次数
            sendWatchList({
              timestamp: new Date(new Date().toLocaleDateString()).getTime(),
              items: result.ids.join(","),
            }).then((rr) => {
              console.log(rr)
            });
          }
        }
      }
    }
  };

  const renderList = () => {
    return (
      <Swiper
        noSwipingClass={"swiper-no-swiping"}
        className={"featured-swiper index_swiper"}
        direction="vertical"
        onSlideChange={(e) => {
          watchPost(e.activeIndex)
          // if (!isFirst) {
          //   checkShouldPlay(e.activeIndex);
          // }
          playAlertState = true
          isChange = true;
          setCurrent(e.activeIndex);
          loadingTimer && clearTimeout(loadingTimer);
          videoRef.current && videoRef.current.pause();
          setIsPause(true);
          setVideoLoading(true);
          // if (!isTouch) {
          //   setIsTouch(true);
          // }
          shouldPlay &&
            getVideoUrl(data[e.activeIndex].playUrl, (link) => {
              setVideoUrl(link);
              //   document.getElementById("pron_video").innerHTML = `
              // <source src=${link} ref=${sourceRef} type="application/x-mpegURL" />
              // `;
              if (!isFirst) {
                if (videoRef.current) {
                  setTimeout(function () {
                    videoRef.current.play();
                  }, 500)
                }
                setIsPause(false);
              }
              isChange = false;
            });
          isPlaying = false;
          // 滑到底部添加视频
          if (!isAddVideo && e.activeIndex == data.length - 2 && !isAll) {
            page.page = page.page + 1;
            setPage({ ...page });
          }
        }}
        onSliderMove={(e,e2) => {
          if (!isTouch && e.touches.diff > 1 || !isTouch && e.touches.diff < -1) {
            setIsTouch(true);
          }
        }}
        onTransitionEnd={() => {
          // setVideoUrl("");
          if (isTouch) {
            setIsTouch(false);
          }
        }}
      >
        {data.map((item, index) => {
          return (
            <SwiperSlide key={index}>
              {Math.abs(current - index) > 1 ? (
                <></>
              ) : (
                <SwiperItem
                  shouldPlay={shouldPlay}
                  item={item}
                  isTouch={isTouch}
                  current={current}
                  index={index}
                  pause={isPause}
                  tabIndex={tabIndex}
                  onComment={() => {
                    setCommentInfo({ id: item.id, num: item.comment });
                    Emit.emit("HIDE_BOTTOM", true);
                    setShowBottomLayer(true);
                    setBottomLayerType(1);
                  }}
                  onHeji={() => {
                    setHejiInfo({
                      id: item.collect_id,
                      title: item.collect.title,
                    });
                    Emit.emit("HIDE_BOTTOM", true);
                    setShowBottomLayer(true);
                    setBottomLayerType(2);
                  }}
                  onLongVideo={() => {
                    if (!user.isVip) {
                      Emit.emit("vipAlert", {
                        _submit: toShare,
                        _cancel: toVip,
                      });
                    } else {
                      toLongVideo(index);
                    }
                  }}
                  onShare={() => {
                    setShowDialog(true);
                  }}
                  loading={videoLoading}
                  onTap={() => {
                    if (!isPause) {
                      videoRef.current && videoRef.current.pause();
                      setIsPause(true);
                    } else {
                      // if (isFirst) {
                      //   checkShouldPlay(current);
                      // }
                      isFirst = false;
                      if (videoRef.current) {
                        setTimeout(function () {
                          videoRef.current.play();
                        }, 500)
                      }
                      setIsPause(false);
                      setVideoLoading(isPlaying ? 1 : true);
                    }
                    setTimeout(() => {
                      loadingTimer && clearTimeout(loadingTimer);
                    }, 500);
                  }}
                />
              )}
            </SwiperSlide>
          );
        })}
      </Swiper>
    );
  };
  const renderVideo = () => {
    if (!videoUrl || !shouldPlay) {
      return null;
    }
    return (
      <div
        className="index_video"
        style={{ opacity: isTouch || videoLoading === true ? 0 : 1 }}
      >
        <VideoPlayer
          style={{ zIndex: 1, backgroundColor: "transparent" }}
          loop
          auto
          hideControls
          videoRef={videoRef}
          src={videoUrl}
          onPause={() => { }}
          durationChange={(e) => {
            // if (isTouch) {
            //   setIsTouch(false);
            // }
            loadingTimer && clearTimeout(loadingTimer);
            if (!isPlaying) {
              isPlaying = true;
            }
            if (videoLoading) setVideoLoading(false);
            loadingTimer = setTimeout(() => {
              setVideoLoading(1);
            }, 3000);
            if (parseInt(e.target.currentTime + 2) >= parseInt(e.target.duration) && playAlertState) {
              if (!user.isVip) {
                Emit.emit("vipAlert", {
                  _submit: toShare,
                  _cancel: toVip,
                });
                playAlertState = false
              }
            }
            if (isPause) {
              setIsPause(false);
            }
            if (isChange || e.target.currentTime < 0.5) {
              return;
            }
          }}
        />
      </div>
    );
  };
  const renderShare = () => {
    if (!data[current]) {
      return null;
    }
    return (
      <div className="index_share">
        <div className="index_share_header">
          <img src={logo} />
          <p>{data[current].title}</p>
        </div>
        <div className="index_share_cover">
          <Simg src={data[current].thumbImg} />
          <div className="index_share_cover_playIcon">
            <div />
          </div>
        </div>
        <div className="index_share_tip">
          <div className="index_share_tip_qrcode">
            <QRCode
              style={{
                height: "100%",
                width: "100%",
              }}
              value={data[current].shareUrl}
            />
          </div>
          <div className="index_share_tip_right">
            <div>
              <p>扫描二维码</p>
              <p>下载APP立即观看</p>
            </div>
            <div>
              若二维码无法打开请输入网址
              <span>{data[current].shareUrl}</span>
            </div>
          </div>
        </div>
        <div className="index_share_bottom">
          <div
            onClick={() => {
              Emit.emit("showToast", { text: "请在本页面截图保存" });
            }}
          >
            手动截图保存
          </div>
          <div
            onClick={() => {
              copyText(data[current].shareUrl);
              Emit.emit("showToast", { text: "复制成功！" });
            }}
          >
            复制分享链接
          </div>
        </div>
      </div>
    );
  };
  return (
    <div className="featured-swiper-item">
      {loading ? (
        <Loading show type="1" />
      ) : data.length > 0 ? (
        renderList()
      ) : (
        <NoData />
      )}
      {currentTab == tabIndex &&
        isVisible &&
        stacks.length == 0 &&
        renderVideo()}
      <BottomLayer
        show={showBottomLayer}
        onTap={() => {
          setShowBottomLayer(false);
          Emit.emit("HIDE_BOTTOM", false);
        }}
      >
        {bottomLayerType === 1 ? (
          <CommentList
            show={showBottomLayer}
            info={commentInfo}
            onTap={() => {
              setShowBottomLayer(false);
              Emit.emit("HIDE_BOTTOM", false);
            }}
          />
        ) : (
          <HejiDialog
            show={showBottomLayer}
            info={hejiInfo}
            onTap={() => {
              setShowBottomLayer(false);
              Emit.emit("HIDE_BOTTOM", false);
            }}
          />
        )}
      </BottomLayer>
      <Dialog
        show={showDialog}
        onClose={() => {
          setShowDialog(false);
        }}
      >
        {renderShare()}
      </Dialog>
      {videoLoading && !loading && data.length > 0 && (
        <BottomLoading className="index_bottomLoading" />
      )}
    </div>
  );
};

const SwiperItem = (props) => {
  const {
    shouldPlay,
    item,
    onTap,
    current,
    index,
    pause,
    loading,
    isTouch,
    onComment,
    onHeji,
    onLongVideo,
    onShare,
    tabIndex,
  } = props;
  const [isLike, setIslike] = useState(item.isLiked);
  const [isFollow, setIsFollow] = useState(item.isFollowed);
  const [stacks] = StackStore.useGlobalState("stacks");
  const [user] = UserStore.useGlobalState("user");
  // useEffect(() => {
  //   Emit.on("SETFOLLOW", (_uuid) => {
  //     if (_uuid === item.uuid) {
  //       setIsFollow(true);
  //     }
  //   });
  //   return () => {
  //     Emit.off("SETFOLLOW");
  //   };
  // }, []);
  const toLogin = () => {
    Emit.emit("showToast", { text: "请先登录或注册！" });
    const stackKey = `BindPhone-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "bindPhone",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <BindPhone stackKey={stackKey} />
          </StackPage>
        ),
      },
    });
  };
  const toHot91 = () => {
    // if (!globalVar.isBindMobile) {
    //   toLogin();
    // } else {
    const stackKey = `Hot91-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "Hot91",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <Hot91 stackKey={stackKey} />
          </StackPage>
        ),
      },
    });
    // }
  };
  const toTagList = (title) => {
    // if (!globalVar.isBindMobile) {
    //   toLogin();
    // } else {
    const stackKey = `TagList-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "TagList",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <TagList stackKey={stackKey} title={title} />
          </StackPage>
        ),
      },
    });
    // }
  };
  const toPerson = () => {
    if (!globalVar.isBindMobile) {
      toLogin();
    } else {
      const stackKey = `PersonPage-${new Date().getTime()}`;
      StackStore.dispatch({
        type: "push",
        payload: {
          name: "PersonPage",
          element: (
            <StackPage
              stackKey={stackKey}
              key={stackKey}
              style={{ zIndex: stacks.length + 2 }}
            >
              <PersonPage stackKey={stackKey} uuid={item.uuid} />
            </StackPage>
          ),
        },
      });
    }
  };
  const renderBottom = () => {
    if (item.collect_id > 0) {
      return (
        <Clickbtn
          className="index_item_bottom"
          onTap={() => {
            onHeji();
          }}
        >
          <img src={hejiIcon} />
          <p>{item.collect.title}</p>
          <img src={yellowRight} />
        </Clickbtn>
      );
    }
    if (item.topics && item.topics.title) {
      return (
        <Clickbtn className="index_item_bottom" onTap={toHot91}>
          <img src={hotIcon} />
          <p>{item.topics.title}</p>
          <img src={yellowRight} />
        </Clickbtn>
      );
    }
    return <div className="index_item_bottom" />;
  };
  const renderRight = () => {
    return (
      <div className="index_item_right">
        <div className="index_item_right_avatar">
          <Clickbtn className="right_avatar" onTap={(e) => {
            e.stopPropagation()
            toPerson()
          }}>
            <Simg alwaysShow src={item.thumb} isAvatar />
          </Clickbtn>
          {!isFollow && tabIndex == 1 && (
            <Clickbtn
              className="right_follow"
              onTap={(e) => {
                e.stopPropagation()
                if (!globalVar.isBindMobile) {
                  toLogin();
                } else {
                  setFollowUser({ uuid: item.uuid }).then((res) => {
                    setIsFollow(true);
                    Emit.emit("showToast", { text: res.msg });
                  });
                  Emit.emit("SETFOLLOW", item.uuid);
                }

              }}
            >
              <img src={followIcon} />
            </Clickbtn>
          )}
        </div>
        <Clickbtn
          className="right_item"
          onTap={(e) => {
            e.stopPropagation()
            if (!globalVar.isBindMobile) {
              toLogin();
            } else {
              setVideoLike({ id: item.id });
              setIslike(!isLike);
            }

          }}
        >
          <img src={isLike ? likeActiveIcon : likeIcon} />
          <span>{item.like}</span>
        </Clickbtn>
        <Clickbtn
          className="right_item"
          onTap={(e) => {
            e.stopPropagation()
            onComment();
          }}
        >
          <img src={commentIcon} />
          <span>{item.comment}</span>
        </Clickbtn>
        <Clickbtn
          className="right_item"
          onTap={(e) => {
            e.stopPropagation()
            onShare();
          }}
        >
          <img src={shareIcon} />
          <span>分享</span>
        </Clickbtn>
      </div>
    );
  };

  const renderDurationStr = (sec, duration) => {
    if (sec && sec > 10 && duration != 0) {
      return <span>{duration}</span>;
    } else {
      return <span></span>;
    }
  };

  const renderInfo = (user) => {
    return (
      <div className="index_item_info">
        {item.club_id > 0 && !item.is_club_fans && (
          <Clickbtn className="item_info_join" onTap={(e) => {
            e.stopPropagation()
            toPerson()
          }}>
            加入粉丝团，视频免费看
          </Clickbtn>
        )}
        {item.tags && item.tags.length > 0 && (
          <div className="item_info_tags">
            {item.tags.map((v, i) => {
              return (
                <Clickbtn
                  key={i}
                  onTap={(e) => {
                    e.stopPropagation()
                    toTagList(v);
                  }}
                >
                  #{v}
                </Clickbtn>
              );
            })}
          </div>
        )}
        <div className="item_info_name_box">
          {!!item.cityName && (
            <span className="item_info_location" onClick={(e) => {
              e.stopPropagation()
            }}>
              <img src={locationIcon} />
              {item.cityName}
            </span>
          )}
          <span className="item_info_name" onClick={(e) => {
            e.stopPropagation()
          }}>@{item.nickName}</span>
        </div>
        <p className="item_info_title" onClick={(e) => {
          e.stopPropagation()
        }}>{item.title}</p>
        <div className="index_info_bottom_vip_tips">
          {!!item.coins && (
            <Clickbtn
              className="index_info_bottom_coin"
              onTap={(e) => {
                e.stopPropagation()
                onLongVideo();
              }}
            >
              <img src={coinIcon} />
              {item.coins}
            </Clickbtn>
          )}
          {item?.path == "openOut" ? <></> :
            item.hasLongVideo ? (
              !user.isVip ? (
                <Clickbtn
                  className="item_info_time"
                  onTap={(e) => {
                    e.stopPropagation()
                    onLongVideo();
                  }}
                >
                  <span style={{ backgroundColor: "#ff538d" }}>
                    <img src={videoDetailIcon} />
                    预览10秒,充值VIP观看完整版
                  </span>
                  {renderDurationStr(item.duration, item.durationStr)}
                </Clickbtn>
              ) : (
                <Clickbtn
                  className="item_info_time"
                  onTap={(e) => {
                    e.stopPropagation()
                    onLongVideo();
                  }}
                >
                  <span>
                    <img src={videoDetailIcon} />
                    观看完整版
                  </span>
                  {renderDurationStr(item.duration, item.durationStr)}
                </Clickbtn>
              )
            ) : !user.isVip ? (
              <Clickbtn
                className="item_info_time"
                onTap={(e) => {
                  e.stopPropagation()
                  onLongVideo();
                }}
              >
                <span style={{ backgroundColor: "#ff538d" }}>
                  <img src={videoDetailIcon} />
                  预览10秒,充值VIP观看完整版
                </span>
                {renderDurationStr(item.duration, item.durationStr)}
              </Clickbtn>
            ) : (
              <div></div>
            )}
        </div>
      </div>
    );
  };
  if (Math.abs(current - index) > 1) {
    // return <div className="featured-swiper-item index_swiper_item" />;
    return <></>;
  }
  return (
    <Clickbtn
      className="featured-swiper-item index_swiper_item"
      onTap={() => {
        if (item?.path == "openOut") {
          onTap && onTap();
          window.open(item?.url, "_blank")
        } else {
          onTap && onTap();
        }

      }}
    >
      {current == index && pause && (
        <div className="index_item_layer">
          <img src={playIcon} />
        </div>
      )}
      <div
        className="index_item_cover_box"
        style={{
          opacity:
            current == index &&
              !isTouch &&
              (loading === 1 || !loading) &&
              shouldPlay
              ? 0
              : 1,
        }}
      >
        <div className="index_item_cover">
          <Simg
            bgColor={"#140123"}
            preViewSize="40%"
            alwaysShow
            src={item.thumbImg}
          />
        </div>
      </div>
      {renderBottom()}
      <div className="index_item_bottom_bg" />
      {renderRight()}
      {renderInfo(user)}
    </Clickbtn>
  );
};

const CommentList = (props) => {
  const { show, info, onTap } = props;
  const inputRef = useRef(null);
  const [stacks] = StackStore.useGlobalState("stacks");
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState([]);
  const [loadingMore, setLoadingMore] = useState({ a: true });
  let page = 1;
  let size = 5;
  useEffect(() => {
    if (show && info) {
      getData("init");
    }
  }, [show, info]);
  const getData = (status) => {
    if (!loadingMore.a) return;
    if (!status) {
      page++;
    }
    getCommentList({ id: info.id, page })
      .then((res) => {
        // console.log("getCommentList=>", page, res);
        setLoading(false);
        if (res.data && res.data.length > 0) {
          setData((pre) => [...pre, ...res.data]);
          if (res.data.length < size) {
            loadingMore.a = false;
            setLoadingMore({ ...loadingMore });
          }
        } else {
          if (page == 1) {
            setData([]);
          }
          loadingMore.a = false;
          setLoadingMore({ ...loadingMore });
        }
      })
      .catch(() => {
        setLoading(false);
      });
  };
  let scrollTopTimer;
  let isTop = true;
  return (
    <div className="index_comment">
      <div className="index_comment_header">
        <img style={{ opacity: 0 }} src={closeIcon} />
        <span>全部{info.num}条评论</span>
        <img
          src={closeIcon}
          onClick={() => {
            onTap && onTap();
          }}
        />
      </div>
      <div className="index_comment_list">
        {loading ? (
          <Loading show type={1} />
        ) : data.length > 0 ? (
          <ScrollArea
            downRefresh={false}
            ListData={data}
            onScrollEnd={getData}
            loadingMore={loadingMore.a}
            onScrollTop={() => {
              scrollTopTimer && clearTimeout(scrollTopTimer);
              scrollTopTimer = setTimeout(() => {
                // console.log("onScrollTop");
                Emit.emit("CHANGE_MOVE_STATUS", true);
                isTop = true;
              }, 200);
            }}
            scrollChange={() => {
              // console.log("scrollChange");
              if (isTop) {
                Emit.emit("CHANGE_MOVE_STATUS", false);
                isTop = false;
              }
            }}
          >
            {data.map((item, index) => {
              return <CommentCard data={item} key={index} />;
            })}
            <div style={{ height: "1.76rem" }} />
          </ScrollArea>
        ) : (
          <NoData />
        )}
      </div>
      <div className="index_comment_input">
        <input ref={inputRef} placeholder="观而不论非英雄，留下你的评论" />
        <Clickbtn
          onTap={() => {
            if (!inputRef.current.value) {
              Emit.emit("showToast", { text: "请输入内容" });
            } else {
              sendVideoComment({
                mv_id: info.id,
                comment: inputRef.current.value,
              }).then((res) => {
                // console.log(res);
                let msg;
                if (res.data && res.data.success) {
                  msg = res.data.msg;
                  page = 1;
                  setLoading(true);
                  loadingMore.a = true;
                  setLoadingMore({ ...loadingMore });
                  getData("init");
                } else {
                  msg = res.msg;
                }
                inputRef.current.value = "";
                Emit.emit("showToast", { text: msg });
              });
            }
          }}
        >
          确定
        </Clickbtn>
      </div>
    </div>
  );
};

const HejiDialog = (props) => {
  const { show, info, onTap } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState([]);
  useEffect(() => {
    if (show && info) {
      getData();
    }
  }, [show, info]);
  const getData = () => {
    getHejiDetail({ id: info.id })
      .then((res) => {
        // console.log("getHejiDetail=>", res);
        setLoading(false);
        if (res.data && res.data.list.length > 0) {
          setData(res.data.list);
        }
      })
      .catch(() => {
        setLoading(false);
      });
  };
  const toLogin = () => {
    Emit.emit("showToast", { text: "请先登录或注册！" });
    const stackKey = `BindPhone-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "bindPhone",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <BindPhone stackKey={stackKey} />
          </StackPage>
        ),
      },
    });
  };
  const toShortVideo = (_index) => {
    onTap && onTap();
    if (!globalVar.isBindMobile) {
      toLogin();
    } else {
      const stackKey = `ShortVideoList-${new Date().getTime()}`;
      StackStore.dispatch({
        type: "push",
        payload: {
          name: "ShortVideoList",
          element: (
            <StackPage
              stackKey={stackKey}
              key={stackKey}
              style={{ zIndex: stacks.length + 2 }}
            >
              <ShortVideoList
                stackKey={stackKey}
                list={data}
                _page={1}
                _current={_index}
              />
            </StackPage>
          ),
        },
      });
    }
  };
  let scrollTopTimer;
  let isTop = true;
  return (
    <div className="index_comment">
      <div className="index_comment_header">
        <img style={{ opacity: 0 }} src={closeIcon} />
        <span style={{ color: "#f2b55f" }}>{info.title}</span>
        <img
          src={closeIcon}
          onClick={() => {
            onTap && onTap();
          }}
        />
      </div>
      <div className="index_comment_list">
        {loading ? (
          <Loading show type={1} />
        ) : data.length > 0 ? (
          <ScrollArea
            downRefresh={false}
            ListData={data}
            onScrollTop={() => {
              scrollTopTimer && clearTimeout(scrollTopTimer);
              scrollTopTimer = setTimeout(() => {
                // console.log("onScrollTop");
                Emit.emit("CHANGE_MOVE_STATUS", true);
                isTop = true;
              }, 200);
            }}
            scrollChange={() => {
              if (isTop) {
                isTop = false;
                Emit.emit("CHANGE_MOVE_STATUS", false);
              }
            }}
          >
            {data.map((item, index) => {
              return (
                <HejiItem
                  data={item}
                  key={index}
                  onTap={() => {
                    toShortVideo(index);
                  }}
                />
              );
            })}
          </ScrollArea>
        ) : (
          <NoData />
        )}
      </div>
    </div>
  );
};

const HejiItem = (props) => {
  const { data, onTap } = props;

  let flag = 0;

  const _touchStart = () => {
    flag = setTimeout(() => {
      flag = 0
    }, 400);
  }

  const _touchMove = () => {
    clearTimeout(flag)
    flag = 0;
  }

  const _touchEnd = () => {
    clearTimeout(flag)
    if (flag != 0) {
      _onClick()
    }
  }

  const _onClick = () => {
    onTap && onTap();
  }

  return (
    <div
      className="index_heji_card"
      // onTouchStart={()=>{
      //   _touchStart()
      // }}
      // onTouchMove={()=>{
      //   _touchMove()
      // }}
      // onTouchEnd={()=>{
      //   _touchEnd()
      // }}
      onClick={() => {
        onTap && onTap();
      }}
    >
      <div className="index_heji_card_cover">
        <Simg src={data.thumbImg} />
      </div>
      <div className="index_heji_info_right">
        <p className="index_heji_title">{data.title}</p>
        <div className="index_heji_text">
          <span>{data.play_count} 播放</span>
          <span>{data.like} 点赞</span>
        </div>
      </div>
    </div>
  );
};
