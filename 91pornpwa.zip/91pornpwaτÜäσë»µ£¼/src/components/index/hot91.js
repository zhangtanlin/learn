/*
 * @Author: Tom
 * @Date: 2021-11-18 17:19:20
 * @LastEditTime: 2021-12-08 09:40:55
 * @LastEditors: Tom
 * @Description:
 * @FilePath: /91pornpwa/src/components/index/hot91.js
 */
import React, { useEffect, useState } from "react";
import "../../resources/css/hot91.less";
import StackStore from "../../store/stack";
import Clickbtn from "../clickbtn";
import ScrollArea from "../scrollarea";
import Emit from "../../libs/eventEmitter";
import Loading from "../loading";
import NoData from "../noData";
import banner from "../../resources/img/index/hot91Banner.png";
import fire from "../../resources/img/index/fire.png";
import back from "../../resources/img/search/back_white.png";
import VideoDetail from "../videoDetail";
import StackPage from "../stackpage";
import { get91Hot } from "../../libs/http";

export default (props) => {
  const { stackKey } = props;
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [stacks] = StackStore.useGlobalState("stacks");
  useEffect(() => {
    get91Hot().then((res) => {
      setLoading(false);
      if (res.data) {
        setData(res.data);
      }
      // console.log("热点", res.data);
    });
  }, []);
  const renderBack = () => {
    return (
      <Clickbtn
        className="hot91_back"
        onTap={() => {
          Emit.emit(stackKey, stackKey);
        }}
      >
        <img src={back} />
      </Clickbtn>
    );
  };
  const renderHeader = () => {
    return (
      <div className="hot91_header">
        <img src={banner} />
        <span>更新于：{data?.subject?.lastUpdated || ""}</span>
      </div>
    );
  };

  const toMvDetail = (value) => {
    const stackKey = `Search-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "Search",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <VideoDetail stackKey={stackKey} id={value} />
          </StackPage>
        ),
      },
    });
  };

  const item = (v, i) => {
    return (
      <Clickbtn
        className="hot91_item"
        key={i}
        onTap={() => {
          switch (v.path) {
            case "movieDetail":
              toMvDetail(v.value);
              break;
            case "openOut":
              if (v.url) window.open(v.url, "_blank");
              break;
            default:
              break;
          }
        }}
      >
        <div className="hot91_item_left">
          {i < 3 ? <i>{i + 1}.</i> : <span>{i + 1}.</span>}
          <p>{v.title}</p>
        </div>
        <span className="hot91_item_right">
          <img src={fire} />
          {v.hot_num}
        </span>
      </Clickbtn>
    );
  };

  return (
    <div className="page-content-flex hot91_wrap">
      {renderBack()}
      {loading ? (
        <Loading show type="1" />
      ) : data && data.list.length > 0 ? (
        <ScrollArea downRefresh={false}>
          {renderHeader()}
          {data.list.map((v, i) => {
            return item(v, i);
          })}
        </ScrollArea>
      ) : (
        <NoData />
      )}
    </div>
  );
};
