/*
 * @Author: Tom
 * @Date: 2021-11-19 09:41:57
 * @LastEditTime: 2021-12-08 09:42:06
 * @LastEditors: Tom
 * @Description:
 * @FilePath: /91pornpwa/src/components/index/tagList.js
 */
import React, { useEffect, useState } from "react";
import "../../resources/css/tagList.less";
import StackStore from "../../store/stack";
import Clickbtn from "../clickbtn";
import ScrollArea from "../scrollarea";
import Emit from "../../libs/eventEmitter";
import Loading from "../loading";
import NoData from "../noData";
import back from "../../resources/img/search/back_white.png";
import StackPage from "../stackpage";
import ShortMvCard from "../card/shortMvCard";
import ShortVideoList from "./shortVideoList";

import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/swiper.min.css";
import { getTagVideoList } from "../../libs/http";

export default (props) => {
  const { stackKey, title } = props;
  const navs = ["最新", "最热"];
  const [tabIndex, setTabIndex] = useState(0);
  const [controlledSwiper, setControlledSwiper] = useState(null);
  const renderHeader = () => {
    return (
      <div className="tagList_header">
        <Clickbtn
          className="tagList_header_back"
          onTap={() => {
            Emit.emit(stackKey, stackKey);
          }}
        >
          <img src={back} />
        </Clickbtn>
        <div className="tagList_header_title"># {title}</div>
      </div>
    );
  };
  const renderTab = () => {
    return (
      <div className="tagList_tab">
        {navs.map((item, index) => {
          return (
            <Clickbtn
              className={tabIndex == index ? "active" : ""}
              key={index}
              onTap={() => {
                setTabIndex(index);
                controlledSwiper.slideTo(index);
              }}
            >
              <span>{item}</span>
            </Clickbtn>
          );
        })}
      </div>
    );
  };
  return (
    <div className="page-content-flex tagList">
      {renderHeader()}
      {renderTab()}
      <Swiper
        className={"featured-swiper"}
        onSwiper={setControlledSwiper}
        controller={controlledSwiper}
        onSlideChange={(e) => {
          setTabIndex(e.activeIndex);
        }}
      >
        {navs.map((item, index) => {
          return (
            <SwiperSlide key={`tagList_swiper${index}`}>
              <SwiperItem
                show={index === tabIndex}
                index={index}
                title={title}
              />
            </SwiperSlide>
          );
        })}
      </Swiper>
    </div>
  );
};
const SwiperItem = (props) => {
  const { show, index, title } = props;
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState([]);
  const [loadingMore, setLoadingMore] = useState({ a: true });
  const [stacks] = StackStore.useGlobalState("stacks");
  let page = 1;
  useEffect(() => {
    if (show && data.length == 0) {
      getData("init");
    }
  }, [show]);
  const getData = (status) => {
    if (!loadingMore.a) return;
    if (!status) {
      page++;
    }
    getTagVideoList({
      page: page,
      tags: title,
      type: index == 0 ? "new" : "hot",
    })
      .then((res) => {
        // console.log("getTagVideoList=>", res);
        setLoading(false);
        if (res.data && res.data.items && res.data.items.length > 0) {
          if (res.data.items.length < 5) {
            loadingMore.a = false;
            setLoadingMore({ ...loadingMore });
          }
          setData((pre) => [...pre, ...res.data.items]);
        } else {
          if (page == 1) {
            setData([]);
          }
          loadingMore.a = false;
          setLoadingMore({ ...loadingMore });
        }
      })
      .catch(() => {
        setLoading(false);
      });
  };
  return (
    <div className={"featured-swiper-item"}>
      {loading ? (
        <Loading show type={1} />
      ) : data.length > 0 ? (
        <ScrollArea
          downRefresh={false}
          ListData={data}
          onScrollEnd={getData}
          loadingMore={loadingMore.a}
        >
          <div className="tagList_list">
            {data.map((item, i) => {
              return (
                <ShortMvCard
                  data={item}
                  key={i}
                  toDetail={() => {
                    const stackKey = `ShortVideoList-${new Date().getTime()}`;
                    StackStore.dispatch({
                      type: "push",
                      payload: {
                        name: "ShortVideoList",
                        element: (
                          <StackPage
                            stackKey={stackKey}
                            key={stackKey}
                            style={{ zIndex: stacks.length + 2 }}
                          >
                            <ShortVideoList
                              stackKey={stackKey}
                              list={data}
                              _page={page}
                              _current={i}
                              pramas={{
                                mod: "index",
                                code: "listByTag",
                                tags: title,
                                type: index == 0 ? "new" : "hot",
                              }}
                            />
                          </StackPage>
                        ),
                      },
                    });
                  }}
                />
              );
            })}
          </div>
        </ScrollArea>
      ) : (
        <NoData />
      )}
    </div>
  );
};
