/*
 * @Author: Tom
 * @Date: 2021-11-17 17:54:32
 * @LastEditTime: 2021-12-16 21:07:09
 * @LastEditors: Tom
 * @Description:
 * @FilePath: /91pornpwa/src/components/index/search.js
 */
import React, { useEffect, useMemo, useRef, useState } from "react";
import "../../resources/css/search.less";
import StackStore from "../../store/stack";
import UserStore from "../../store/user";
import Clickbtn from "../clickbtn";
import ScrollArea from "../scrollarea";
import Emit from "../../libs/eventEmitter";
import Loading from "../loading";
import NoData from "../noData";
import Simg from "../simg";
import ShortMvCard from "../card/shortMvCard";

import backIcon from "../../resources/img/search/back.png";
import searchIcon from "../../resources/img/search/search.png";
import closeIcon from "../../resources/img/search/close.png";
import close1Icon from "../../resources/img/search/close1.png";
import historyIcon from "../../resources/img/search/history.png";
import deleteIcon from "../../resources/img/search/delete.png";
import hotIcon from "../../resources/img/search/hotSearch.png";
import hot91Icon from "../../resources/img/search/91hot.png";
import creator from "../../resources/img/search/creator.png";
import creatorIcon from "../../resources/img/search/creatorIcon.png";
import coin from "../../resources/img/search/coin.png";
import playIcon from "../../resources/img/search/playIcon.png";
import rightIcon from "../../resources/img/search/right.png";
import likeIcon from "../../resources/img/public/icon_detail_smart_checked_white.png";

import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/swiper.min.css";
import { getSearchIndex, getSearch } from "../../libs/http";
import Hot91 from "./hot91New";
import HejiList from "../hejiList";
import ShortVideoList from "./shortVideoList";
import StackPage from "../stackpage";
import VideoDetail from "../videoDetail";

export default (props) => {
  const { stackKey } = props;
  const inputRef = useRef(null);
  const [stacks] = StackStore.useGlobalState("stacks");
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState(null);
  const [history, setHistory] = useState([]);
  const [searching, setSearching] = useState(false);
  const [showClose, setShowClose] = useState(false);
  const [searchText, setSearchText] = useState("");
  useEffect(() => {
    getInitData();
    const history = localStorage.getItem("SEARCH_HISTORY");
    // console.log("history", history);
    if (history) {
      setHistory(history.split(","));
    }
  }, []);
  const clearHistory = () => {
    setHistory([]);
    localStorage.setItem("SEARCH_HISTORY", "");
  };
  const getInitData = () => {
    getSearchIndex()
      .then((res) => {
        setLoading(false);
        if (res.data) {
          setData(res.data);
        }
        // console.log("搜索", res);
      })
      .catch(() => {
        setLoading(false);
      });
  };
  const renderHeader = () => {
    return (
      <div className="search_header">
        <div className="search_header_back">
          <img
            src={backIcon}
            onClick={() => {
              Emit.emit(stackKey, stackKey);
            }}
          />
        </div>
        <div className="search_header_input">
          <img src={searchIcon} />
          <input
            ref={inputRef}
            placeholder="搜视频、搜用户、搜帖子"
            onChange={() => {
              if (inputRef.current.value && !showClose) {
                setShowClose(true);
              } else if (!inputRef.current.value && showClose) {
                setShowClose(false);
                setSearching(false);
              }
            }}
          />
          {showClose && (
            <img
              src={closeIcon}
              onClick={() => {
                inputRef.current.value = "";
                setShowClose(false);
                setSearching(false);
              }}
            />
          )}
        </div>
        <span
          className="search_header_sub"
          onClick={() => {
            if (inputRef.current.value) {
              if (
                typeof searchText === "string"
                  ? inputRef.current.value !== searchText
                  : inputRef.current.value !== searchText.value
              ) {
                if (history.indexOf(inputRef.current.value) == -1) {
                  if (history.length > 5) {
                    history.shift();
                  }
                  localStorage.setItem(
                    "SEARCH_HISTORY",
                    [...history, inputRef.current.value].toString()
                  );
                  setHistory([...history, inputRef.current.value]);
                }
                setSearchText(
                  searching
                    ? { value: inputRef.current.value }
                    : inputRef.current.value
                );
                setSearching(true);
              }
            } else {
              Emit.emit("showToast", { text: "请输入关键字", type: "black" });
            }
          }}
        >
          搜索
        </span>
      </div>
    );
  };
  const renderHistory = () => {
    return (
      <div
        className="search_history"
        style={{ paddingTop: history.length == 0 ? "0.3rem" : "0.1rem" }}
      >
        {history.map((item, index) => {
          return historyItem(item, index);
        })}
        <Clickbtn className="search_history_bottom" onTap={clearHistory}>
          <img src={deleteIcon} />
          清除搜索记录
        </Clickbtn>
      </div>
    );
  };
  const historyItem = (item, index) => {
    return (
      <div className="search_history_item" key={index}>
        <Clickbtn
          className="search_history_item_left"
          onTap={() => {
            inputRef.current.value = item;
            setSearchText(item);
            setSearching(true);
            setShowClose(true);
          }}
        >
          <img src={historyIcon} />
          <span>{item}</span>
        </Clickbtn>
        <Clickbtn
          className="search_history_item_right"
          onTap={() => {
            const list = history.filter((e) => e != item);
            localStorage.setItem("SEARCH_HISTORY", list.toString());
            setHistory([...list]);
          }}
        >
          <img src={close1Icon} />
        </Clickbtn>
      </div>
    );
  };
  const hotSearch = () => {
    if (data && data.hotSearch && data.hotSearch.length > 0) {
      return (
        <div className="search_column">
          <div className="search_column_title">
            <div className="search_column_title_left">
              <img src={hotIcon} />
              热搜词
            </div>
          </div>
          <div className="search_flex_wrap">
            {data.hotSearch.map((item, index) => {
              return (
                <Clickbtn
                  className="search_hot_item"
                  key={index}
                  onTap={() => {
                    inputRef.current.value = item;
                    setSearchText(item);
                    setSearching(true);
                    setShowClose(true);
                  }}
                >
                  {item}
                </Clickbtn>
              );
            })}
          </div>
        </div>
      );
    }
    return null;
  };
  const hot91 = () => {
    if (data && data.hotTopic && data.hotTopic.length > 0) {
      return (
        <div className="search_column">
          <div className="search_column_title">
            <div className="search_column_title_left">
              <img src={hot91Icon} />
              91热点
            </div>
            <Clickbtn
              className="search_column_title_right"
              onTap={() => {
                const stackKey = `hot91-${new Date().getTime()}`;
                StackStore.dispatch({
                  type: "push",
                  payload: {
                    name: "hot91",
                    element: (
                      <StackPage
                        stackKey={stackKey}
                        key={stackKey}
                        style={{ zIndex: stacks.length + 2 }}
                      >
                        <Hot91 stackKey={stackKey} />
                      </StackPage>
                    ),
                  },
                });
              }}
            >
              更多
              <img src={rightIcon} />
            </Clickbtn>
          </div>
          {data.hotTopic.map((item, index) => {
            return (
              <Clickbtn
                className="search_hot91_item"
                key={index}
                onTap={() => {
                  const stackKey = `Search-${new Date().getTime()}`;
                  StackStore.dispatch({
                    type: "push",
                    payload: {
                      name: "Search",
                      element: (
                        <StackPage
                          stackKey={stackKey}
                          key={stackKey}
                          style={{ zIndex: stacks.length + 2 }}
                        >
                          <VideoDetail stackKey={stackKey} id={item.value} />
                        </StackPage>
                      ),
                    },
                  });
                }}
              >
                <div>
                  <i>{index + 1}.</i>
                  <p>{item.title}</p>
                </div>
                <span>{item.hot_num} 浏览</span>
              </Clickbtn>
            );
          })}
        </div>
      );
    }
    return null;
  };
  const creatorList = (item, index) => {
    if (!item.mvlist || item.mvlist.length == 0) return null;
    return (
      <div className="search_column" key={index}>
        <div className="search_column_title">
          <div className="search_column_title_left">
            <img src={creator} />
            {item.jump_desc}
          </div>
        </div>
        <div className="search_flex_wrap" style={{ paddingLeft: 5 }}>
          {item.mvlist.map((v, i) => {
            return creatorItem(v, i);
          })}
        </div>
      </div>
    );
  };
  const creatorItem = (item, index) => {
    return (
      <Clickbtn
        className="search_creator_item"
        key={index}
        onTap={() => {
          const stackKey = `ShortVideoList-${new Date().getTime()}`;
          StackStore.dispatch({
            type: "push",
            payload: {
              name: "ShortVideoList",
              element: (
                <StackPage
                  stackKey={stackKey}
                  key={stackKey}
                  style={{ zIndex: stacks.length + 2 }}
                >
                  <ShortVideoList
                    stackKey={stackKey}
                    list={data.category[0].mvlist}
                    _page={1}
                    _current={index}
                  />
                </StackPage>
              ),
            },
          });
        }}
      >
        <Simg theme="white" src={item.thumbImg} />
        <div className="search_creator_item_layer">
          <img className="search_creator_item_creator" src={creatorIcon} />
          <div className="search_creator_item_layer_bottom">
            <div>
              <img src={playIcon} />
              {item.play_count}
            </div>
            {!!item.coins && (
              <div>
                <img src={coin} />
                {item.coins}
              </div>
            )}
          </div>
        </div>
      </Clickbtn>
    );
  };
  const beforeSearch = () => {
    return (
      <ScrollArea
        downRefresh={false}
        ListData={
          history.length + data?.hotTopic?.length ||
          0 + data?.category?.length ||
          0
        }
      >
        {renderHistory()}
        {loading ? (
          <Loading show type="1" />
        ) : (
          <>
            {hotSearch()}
            {hot91()}
            {data &&
              data.category &&
              data.category.length > 0 &&
              data.category.map((item, index) => {
                return creatorList(item, index);
              })}
          </>
        )}
        <div style={{ height: "0.4rem" }} />
      </ScrollArea>
    );
  };
  return (
    <div className="page-content-flex search_wrap">
      {renderHeader()}
      {searching && searchText ? (
        <SearchResult value={searchText} />
      ) : (
        beforeSearch()
      )}
    </div>
  );
};

const SearchResult = (props) => {
  const { value } = props;
  const navs = ["短视频", "合集"];
  const [tabIndex, setTabIndex] = useState(0);
  const [controlledSwiper, setControlledSwiper] = useState(null);
  return (
    <div className="search-result">
      <div className="search-tab">
        {navs.map((item, index) => (
          <Clickbtn
            key={`nav_item_${index}`}
            className={tabIndex == index ? "active" : ""}
            onTap={() => {
              setTabIndex(index);
              controlledSwiper.slideTo(index);
            }}
          >
            {item}
          </Clickbtn>
        ))}
      </div>
      <Swiper
        className={"featured-swiper"}
        onSwiper={setControlledSwiper}
        controller={controlledSwiper}
        onSlideChange={(e) => {
          setTabIndex(e.activeIndex);
        }}
      >
        {navs.map((item, index) => {
          return (
            <SwiperSlide key={`search_swiper${index}`}>
              <SwiperItem
                show={index === tabIndex}
                index={index}
                value={value}
              />
            </SwiperSlide>
          );
        })}
      </Swiper>
    </div>
  );
};
const SwiperItem = (props) => {
  const { show, index, value } = props;
  const [loading, setLoading] = useState(true);
  const [initList, setInitList] = useState(false);
  const [listData, setListData] = useState({
    data: [],
  });
  const [page, setPage] = useState({
    num: 1,
  });
  const [isAll, setIsAll] = useState(false);
  const [stacks] = StackStore.useGlobalState("stacks");
  const size = 5;
  let isGetData = false;
  useEffect(() => {
    if (show && !initList) {
      setInitList(true);
    }
  }, [show, initList]);
  useEffect(() => {
    if (typeof value === "object" && show) {
      page.num = 1;
      setLoading(true);
      setListData({ data: [] });
      setIsAll(false);
      setPage({ ...page });
      initListData();
    }
  }, [value, show]);
  const initListData = async (_page) => {
    isGetData = true;
    try {
      let res = await getSearch({
        type: index == 0 ? 1 : 5,
        key: typeof value === "object" ? value.value : value,
        page: _page || page.num,
      });
      isGetData = false;
      // console.log(res.data, index, page.num);
      if (res.data && res.data.length > 0) {
        if (page.num === 1) {
          listData.data = [...res.data];
        } else {
          listData.data = [...listData.data, ...res.data];
        }
        if (res.data.length < size) {
          setIsAll(true);
        }
        setListData({ ...listData });
      } else {
        setIsAll(true);
      }
      setLoading(false);
    } catch (error) {
      // console.log(error);
      Emit.emit("changeAlert", {
        _title: "提示",
        _content: "请求失败，请重试！请稍后重试！",
        _submitText: "确定",
        _notDouble: true,
      });
    }
  };
  const _loadMoreData = () => {
    if (isAll || isGetData) return;
    page.num = page.num + 1;
    setPage({ ...page });
    initListData(page.num);
  };
  useEffect(() => {
    if (initList) {
      initListData();
    }
  }, [initList]);
  const toShortVideo = (_index) => {
    const stackKey = `ShortVideoList-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "ShortVideoList",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <ShortVideoList
              stackKey={stackKey}
              list={listData.data}
              _page={page.num}
              _current={_index}
              pramas={{
                mod: "index",
                code: "search",
                type: 1,
                key: value,
              }}
            />
          </StackPage>
        ),
      },
    });
  };
  return (
    <div className={"featured-swiper-item"}>
      {loading ? (
        <Loading show type="1" />
      ) : listData.data.length > 0 ? (
        <ScrollArea
          downRefresh={false}
          ListData={listData}
          onScrollEnd={_loadMoreData}
          loadingMore={!isAll}
        >
          <div
            className={index == 0 ? "search_video_list" : "search_heji_list"}
          >
            {listData.data.map((v, i) => {
              if (index == 0) {
                return (
                  <ShortMvCard
                    data={v}
                    theme="white"
                    key={`short-mv-card-${i}-${v.id}`}
                    toDetail={() => {
                      toShortVideo(i);
                    }}
                  />
                );
              } else {
                return <Heji data={v} key={i} />;
              }
            })}
          </div>

          <div style={{ height: "30px" }} />
        </ScrollArea>
      ) : (
        <NoData type="white" />
      )}
    </div>
  );
};

export const Heji = (props) => {
  const { data } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  return (
    <Clickbtn
      className="search_heji"
      onTap={() => {
        const stackKey = `HejiList-${new Date().getTime()}`;
        StackStore.dispatch({
          type: "push",
          payload: {
            name: "HejiList",
            element: (
              <StackPage
                stackKey={stackKey}
                key={stackKey}
                style={{ zIndex: stacks.length + 2 }}
              >
                <HejiList stackKey={stackKey} id={data.id} />
              </StackPage>
            ),
          },
        });
      }}
    >
      <div className="search_heji_cover">
        <Simg theme="white" src={data.cover} />
      </div>
      <div className="search_heji_info">
        <p>{data.title}</p>
        <div>
          <span>{data.play_num} 播放</span>
          <span>{data.like} 点赞</span>
        </div>
        <p>共{data.video_num}集</p>
      </div>
    </Clickbtn>
  );
};
