/*
 * @Author: Tom
 * @Date: 2021-11-27 15:22:41
 * @LastEditTime: 2022-01-15 13:40:47
 * @LastEditors: Tom
 * @Description:
 * @FilePath: /91pornpwa/src/components/index/longVideo.js
 */
import React, { useEffect, useRef, useState } from "react";
import QRCode from "qrcode.react";
import "../../resources/css/index.less";
import "../../resources/css/shortVideoList.less";

import StackStore from "../../store/stack";
import ScrollArea from "../scrollarea";
import Clickbtn from "../clickbtn";
import Simg from "../simg";
import Loading from "../loading";
import NoData from "../noData";
import Dialog from "../dialog_scale";
import Emit from "../../libs/eventEmitter";
import { copyText } from "../../libs/utils";

import playIcon from "../../resources/img/index/icon_home_play_status.png";
import likeIcon from "../../resources/img/index/like.png";
import likeActiveIcon from "../../resources/img/index/likeActive.png";
import commentIcon from "../../resources/img/index/comment.png";
import shareIcon from "../../resources/img/index/share.png";
import closeIcon from "../../resources/img/index/icon_friend_close.png";
import logo from "../../resources/img/index/icon_share_top_logo.png";
import back from "../../resources/img/search/back_white.png";

import VideoPlayer from "../videoPlayer";
import BottomLayer from "../bottomLayer";
import CommentCard from "../card/commentCard";
import BottomLoading from "../bottomLoading";
import StackPage from "../stackpage";
import Recharge from "../user/recharge";

import {
  setVideoLike,
  getCommentList,
  sendVideoComment,
  getLongVideo,
} from "../../libs/http";

let loadingTimer;
export default (props) => {
  const { stackKey, _data, longUrl = "" } = props;
  const videoRef = useRef(null);
  const [stacks] = StackStore.useGlobalState("stacks");
  const [data, setData] = useState(_data);
  const [overLoading, setOverLoading] = useState(false);
  const [isPause, setIsPause] = useState(true);
  const [showBottomLayer, setShowBottomLayer] = useState(false);
  const [showDialog, setShowDialog] = useState(false);
  const [videoLoading, setVideoLoading] = useState(true);
  const [videoUrl, setVideoUrl] = useState(longUrl);
  const [showPause, setShowPause] = useState(true);
  let isPlaying = false;

  useEffect(() => {
    if (!longUrl) {
      getLongVideo({ id: data.id }).then((res) => {
        // console.log("长视频", res.data);
        if (res.data && res.data.playUrl) {
          setVideoUrl(res.data.playUrl)
          setTimeout(() => {
            videoRef && videoRef.current.play()
          }, 100);
          // getVideoUrl(res.data.playUrl, (link) => {
          //   setVideoUrl(link);
          // });
        }
      });
    }
  }, [longUrl]);

  const getVideoUrl = async (url, callBack) => {
    try {
      // let m3u8Res = await axios.get(url);
      // const m3u8 = CryptoData.DecryptVideo(m3u8Res.data);
      // const blob = new Blob([m3u8], {
      //   type: "application/x-mpegURL",
      // });
      // const link = URL.createObjectURL(blob);
      // callBack(link);
      callBack(url);
      // 更新用户次数
      // setUserData();
    } catch (error) {
      // console.log("error", error);
      Emit.emit("showToast", { text: "获取播放链接失败" });
    }
  };

  const toVip = () => {
    const stackKey = `recharge-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "recharge",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <Recharge stackKey={stackKey} />
          </StackPage>
        ),
      },
    });
  };
  const renderHeader = () => {
    return (
      <div className="shortVideoList_header">
        <Clickbtn
          className="shortVideoList_header_back"
          onTap={() => {
            Emit.emit(stackKey, stackKey);
          }}
        >
          <img src={back} />
        </Clickbtn>
      </div>
    );
  };

  const renderVideo = () => {
    if (!videoUrl) {
      return null;
    }
    return (
      <div
        className="long_video"
        style={{ opacity: videoLoading === true ? 0 : 1 }}
      >
        <VideoPlayer
          style={{ zIndex: 1, backgroundColor: "transparent" }}
          loop
          auto
          // hideControls
          videoRef={videoRef}
          src={videoUrl}
          onPause={() => {
            setShowPause(true)
          }}
          durationChange={() => {
            loadingTimer && clearTimeout(loadingTimer);
            if (!isPlaying) {
              isPlaying = true;
            }
            if(showPause) setShowPause(false)
            if (videoLoading) setVideoLoading(false);
            loadingTimer = setTimeout(() => {
              setVideoLoading(1);
            }, 3000);
          }}
        />
      </div>
    );
  };
  const renderShare = () => {
    if (!data) {
      return null;
    }
    return (
      <div className="index_share">
        <div className="index_share_header">
          <img src={logo} />
          <p>{data.title}</p>
        </div>
        <div className="index_share_cover">
          <Simg src={data.thumbImg} />
          <div className="index_share_cover_playIcon">
            <div />
          </div>
        </div>
        <div className="index_share_tip">
          <div className="index_share_tip_qrcode">
            <QRCode
              style={{
                height: "100%",
                width: "100%",
              }}
              value={data.shareUrl}
            />
          </div>
          <div className="index_share_tip_right">
            <div>
              <p>扫描二维码</p>
              <p>下载APP立即观看</p>
            </div>
            <div>
              若二维码无法打开请输入网址
              <span>{data.shareUrl}</span>
            </div>
          </div>
        </div>
        <div className="index_share_bottom">
          <div
            onClick={() => {
              Emit.emit("showToast", { text: "请在本页面截图保存" });
            }}
          >
            手动截图保存
          </div>
          <div
            onClick={() => {
              copyText(data.shareUrl);
              Emit.emit("showToast", { text: "复制成功！" });
            }}
          >
            复制分享链接
          </div>
        </div>
      </div>
    );
  };
  return (
    <div className="page-content-flex index_container">
      {renderHeader()}
      {
        showPause && (
        <Clickbtn onTap={()=>{
          videoRef && videoRef.current.play()
        }} className="index_item_layer shortVideo_item_layer">
          <img src={playIcon} />
        </Clickbtn>
      )
      }
      <VideoCover
        item={data}
        pause={isPause}
        onComment={() => {
          setShowBottomLayer(true);
        }}
        onShare={() => {
          setShowDialog(true);
        }}
        loading={videoLoading}
        onTap={() => {
          setTimeout(() => {
            loadingTimer && clearTimeout(loadingTimer);
          }, 500);
        }}
      />
      {renderVideo()}
      <BottomLayer
        show={showBottomLayer}
        onTap={() => {
          setShowBottomLayer(false);
        }}
      >
        <CommentList
          show={showBottomLayer}
          info={{ id: data.id, num: data.comment }}
          onTap={() => {
            setShowBottomLayer(false);
          }}
        />
      </BottomLayer>
      <Dialog
        show={showDialog}
        onClose={() => {
          setShowDialog(false);
        }}
      >
        {renderShare()}
      </Dialog>
      {videoLoading && data && (
        <BottomLoading className="index_bottomLoading shortVideo_bottomLoading" />
      )}
      {overLoading && <Loading show type={1} />}
    </div>
  );
};

const VideoCover = (props) => {
  const { item, loading, onComment, onShare } = props;
  const [isLike, setIslike] = useState(item.isLiked);
  const renderBottom = () => {
    return null;
  };
  const renderRight = () => {
    return (
      <div
        className="index_item_right shortVideo_item_right"
        style={{ pointerEvents: "auto" }}
      >
        <Clickbtn
          className="right_item"
          onTap={() => {
            setVideoLike({ id: item.id });
            setIslike(!isLike);
          }}
        >
          <img src={isLike ? likeActiveIcon : likeIcon} />
          <span>{item.like}</span>
        </Clickbtn>
        <Clickbtn
          className="right_item"
          onTap={() => {
            onComment();
          }}
        >
          <img src={commentIcon} />
          <span>{item.comment}</span>
        </Clickbtn>
        <Clickbtn
          className="right_item"
          onTap={() => {
            onShare();
          }}
        >
          <img src={shareIcon} />
          <span>分享</span>
        </Clickbtn>
      </div>
    );
  };
  const renderInfo = () => {
    return (
      <div
        className="index_item_info shortVideo_item_info"
        style={{ pointerEvents: "auto" }}
      >
        <div className="item_info_name_box">
          <span className="item_info_name">@{item.nickName}</span>
        </div>
        <p className="item_info_title">{item.title}</p>
      </div>
    );
  };
  return (
    <div className="longVideo_Cover" style={{ pointerEvents: "none" }}>
      <div
        className="index_item_cover_box "
        style={{
          opacity: loading === 1 || !loading ? 0 : 1,
          pointerEvents: "none",
          marginTop: "1.5rem",
          marginBottom: "0.4rem",
        }}
      >
        <div className="index_item_cover">
          <Simg
            bgColor={"#140123"}
            preViewSize="40%"
            alwaysShow
            src={item.thumbImg}
          />
        </div>
      </div>
      {renderBottom()}
      {renderRight()}
      {renderInfo()}
    </div>
  );
};

const CommentList = (props) => {
  const { show, info, onTap } = props;
  const inputRef = useRef(null);
  const [stacks] = StackStore.useGlobalState("stacks");
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState([]);
  const [loadingMore, setLoadingMore] = useState({ a: true });
  let page = 1;
  let size = 5;
  useEffect(() => {
    if (show && info) {
      getData("init");
    }
  }, [show, info]);
  const getData = (status) => {
    if (!loadingMore.a) return;
    if (!status) {
      page++;
    }
    getCommentList({ id: info.id, page })
      .then((res) => {
        // console.log("getCommentList=>", page, res);
        setLoading(false);
        if (res.data && res.data.length > 0) {
          setData((pre) => [...pre, ...res.data]);
          if (res.data.length < size) {
            loadingMore.a = false;
            setLoadingMore({ ...loadingMore });
          }
        } else {
          if (page == 1) {
            setData([]);
          }
          loadingMore.a = false;
          setLoadingMore({ ...loadingMore });
        }
      })
      .catch(() => {
        setLoading(false);
      });
  };
  let scrollTopTimer;
  let isTop = true;
  return (
    <div className="index_comment">
      <div className="index_comment_header">
        <img style={{ opacity: 0 }} src={closeIcon} />
        <span>全部{info.num}条评论</span>
        <img
          src={closeIcon}
          onClick={() => {
            onTap && onTap();
          }}
        />
      </div>
      <div className="index_comment_list">
        {loading ? (
          <Loading show type={1} />
        ) : data.length > 0 ? (
          <ScrollArea
            downRefresh={false}
            ListData={data}
            onScrollEnd={getData}
            loadingMore={loadingMore.a}
            onScrollTop={() => {
              scrollTopTimer && clearTimeout(scrollTopTimer);
              scrollTopTimer = setTimeout(() => {
                // console.log("onScrollTop");
                Emit.emit("CHANGE_MOVE_STATUS", true);
                isTop = true;
              }, 200);
            }}
            scrollChange={() => {
              if (isTop) {
                Emit.emit("CHANGE_MOVE_STATUS", false);
                isTop = false;
              }
            }}
          >
            {data.map((item, index) => {
              return <CommentCard data={item} key={index} />;
            })}
            <div style={{ height: "1.76rem" }} />
          </ScrollArea>
        ) : (
          <NoData />
        )}
      </div>
      <div className="index_comment_input">
        <input ref={inputRef} placeholder="观而不论非英雄，留下你的评论" />
        <Clickbtn
          onTap={() => {
            if (!inputRef.current.value) {
              Emit.emit("showToast", { text: "请输入内容" });
            } else {
              sendVideoComment({
                mv_id: info.id,
                comment: inputRef.current.value,
              }).then((res) => {
                // console.log(res);
                let msg;
                if (res.data && res.data.success) {
                  msg = res.data.msg;
                  page = 1;
                  setLoading(true);
                  loadingMore.a = true;
                  setLoadingMore({ ...loadingMore });
                  getData("init");
                } else {
                  msg = res.msg;
                }
                inputRef.current.value = "";
                Emit.emit("showToast", { text: msg });
              });
            }
          }}
        >
          确定
        </Clickbtn>
      </div>
    </div>
  );
};
