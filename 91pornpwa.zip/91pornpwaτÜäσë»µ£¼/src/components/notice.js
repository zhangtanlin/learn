/*
 * @Author: Tom
 * @Date: 2021-11-05 15:24:39
 * @LastEditTime: 2021-11-05 15:39:55
 * @LastEditors: Tom
 * @Description:
 * @FilePath: /91avpwa/src/components/dialog_scale.js
 */
import React, { useEffect, useRef, useState } from "react";

import Emit from "../libs/eventEmitter";
import Clickbtn from './clickbtn'
import "../resources/css/notice.less";

import noticeheader from '../resources/img/index/notice_header.png'
import globalVar from "../libs/globalVar";
import StackStore from '../store/stack';
import StackPage from './stackpage';
import Appcenter from './user/appcenter'

export default () => {
  const [hideSelf, setHideSelf] = useState(true);
  const [stacks] = StackStore.useGlobalState("stacks");
  useEffect(() => {
    Emit.on(
      "noticeAlert",
      () => {
        setHideSelf(false);
        setTimeout(() => {
          if (
            document &&
            document.getElementsByClassName("dialog_scaleLayer")[0]
          ) {
            document
              .getElementsByClassName("dialog_scaleLayer")[0]
              .classList.add("dialog_scale-in");
          }
        }, 100);
      })
    return () => {
      Emit.off("noticeAlert");
    };
  }, []);

  const onCloseNotice = () => {
    if (document && document.getElementsByClassName("dialog_scaleLayer")[0]) {
      document
        .getElementsByClassName("dialog_scaleLayer")[0]
        .classList.add("dialog_scale-out");
    }
    setTimeout(() => {
      setHideSelf(true);
    }, 300);
  }

  const orderContent = (text) => {
    return globalVar.notice.content.replace(/#/g, "\n")
  }

  const handleAppCenter = () => {
    const stackKey = `competition-${new Date().getTime()}`;
    StackStore.dispatch({
        type: "push",
        payload: {
            name: "Competition",
            element: (
                <StackPage
                    stackKey={stackKey}
                    key={stackKey}
                    style={{ zIndex: stacks.length + 2 }}
                >
                    <Appcenter stackKey={stackKey} />
                </StackPage>
            ),
        },
    });
    onCloseNotice()
  }

  if (hideSelf) {
    return null;
  }
  return (
    <div className="dialog_scaleLayer">
      <Clickbtn
        className="dialog_scaleLayer-close"
        onTap={() => {
          onCloseNotice();
        }}
      />
      <div className="dialog_scaleLayer-body">
        <div className="notice-container">
          <div className="notice-header"><img src={noticeheader} /></div>
          <div className="notice-content">
            {orderContent()}
          </div>
          <div className="notice-app-center-box"><Clickbtn onTap={() => { handleAppCenter() }} className="notice-app-center">应用中心</Clickbtn></div>
        </div>
      </div>
    </div>
  );
};
