/*
 * @Author: Tom
 * @Date: 2021-12-18 15:41:23
 * @LastEditTime: 2022-01-15 11:52:37
 * @LastEditors: Tom
 * @Description:
 * @FilePath: /91pornpwa/src/components/stackpage.js
 */
import React, { useEffect, useRef, useState } from "react";
import Emit from "../libs/eventEmitter";
import StackStore from "../store/stack";

export default (props) => {
  const { style, children, stackKey } = props;
  const rootRef = useRef(null);
  const initialStyle = `z-index: ${style.zIndex};`;
  let moveX = 0;
  let timer;
  useEffect(() => {
    Emit.on(stackKey, (sKey) => {
      rootRef.current.setAttribute(
        "style",
        `transform: translateX(0px); transition: all 0.5s;${initialStyle}`
      );
      timer && clearTimeout(timer);
      timer = setTimeout(() => {
        StackStore.dispatch({
          type: "pop",
        });
      }, 500);
      Emit.removeListener(stackKey);
    });
  }, []);
  useEffect(() => {
    if (!rootRef.current) {
      return;
    }
    rootRef.current.setAttribute(
      "style",
      `transform: translateX(${-document.body
        .clientWidth}px); transition: all 0.5s;${initialStyle}`
    );
  }, [rootRef.current]);
  
  return (
    <div ref={rootRef} className="stack-page" style={style}>
      <div
        className="stack-page-slide-back"
        onTouchEnd={() => {
          let DURATION = 0.25;
          if (document.body.clientWidth > 400) {
            DURATION = 0.2;
          }
          const MOVEPERCENT = moveX / document.body.clientWidth;
          if (MOVEPERCENT > DURATION) {
            rootRef.current.setAttribute(
              "style",
              `transform: translateX(0px); transition: all ${
                0.3 - DURATION * MOVEPERCENT
              }s;${initialStyle}`
            );
            setTimeout(() => {
              StackStore.dispatch({
                type: "pop",
              });
            }, (0.3 - DURATION * MOVEPERCENT) * 1000);
          } else {
            rootRef.current.setAttribute(
              "style",
              `transform: translateX(${-document.body
                .clientWidth}px); transition: all ${
                0.3 - DURATION * MOVEPERCENT
              }s;${initialStyle}`
            );
          }
        }}
        onTouchMove={(e) => {
          moveX = e.touches[0].pageX;
          if (moveX > 0) {
            rootRef.current &&
              rootRef.current.setAttribute(
                "style",
                `transform: translateX(${
                  moveX - document.body.clientWidth
                }px);${initialStyle}`
              );
          }
        }}
      />
      {children}
    </div>
  );
};
