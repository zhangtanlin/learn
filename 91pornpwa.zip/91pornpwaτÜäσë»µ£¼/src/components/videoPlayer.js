/*
 * @Author: Tom
 * @Date: 2021-11-04 11:17:26
 * @LastEditTime: 2021-12-18 15:28:28
 * @LastEditors: Tom
 * @Description:
 * @FilePath: /91pornpwa/src/components/videoPlayer.js
 */
import React, { useEffect, useRef, useMemo, useState } from "react";
import "../resources/css/video.less";
export default (props) => {
  const newVideoRef = useRef(null);
  const boxRef = useRef(null);
  const newSourceRef = useRef(null);
  const [loading, setLoading] = useState(true);
  const {
    src,
    isPlay = true,
    thumb,
    auto = false,
    durationChange,
    onPause,
    onErr,
    onEnd,
    videoRef = newVideoRef,
    sourceRef = newSourceRef,
    hideControls,
    style = {},
    loop = false,
  } = props;
  useEffect(() => {
    if (!videoRef || !videoRef.current) return;
    const setWaiting = () => {
      setLoading(true);
    };
    const setPlaying = (e) => {
      if (loading) setLoading(false);
      durationChange && durationChange(e);
    };
    videoRef.current.addEventListener("timeupdate", setPlaying, false);
    onPause && videoRef.current.addEventListener("onPause", onPause, false);
    onErr && videoRef.current.addEventListener("onErr", onErr, false);
    onEnd && videoRef.current.addEventListener("onEnd", onEnd, false);
    videoRef.current.addEventListener("waiting", setWaiting, false);
    videoRef && videoRef.current.setAttribute("src", src);
    return () => {
      if (videoRef && videoRef.current) {
        videoRef && videoRef.current.removeEventListener("timeupdate", setPlaying);
        onPause && videoRef.current.removeEventListener("onPause", onPause);
        onErr && videoRef.current.removeEventListener("onErr", onErr);
        onEnd && videoRef.current.removeEventListener("onEnd", onEnd);
        videoRef && videoRef.current.removeEventListener("waiting", setWaiting);
        videoRef && videoRef.current.pause();
        videoRef && videoRef.current.removeAttribute("src");
        videoRef && videoRef.current.load();
      }
    };
  }, [src]);
  useEffect(() => {
    function _handler(e) {
      e.stopPropagation();
    }
    if(boxRef && boxRef.current){
      boxRef.current.addEventListener("touchmove", _handler);
    }
    return () => {
      boxRef?.current?.removeEventListener("touchmove", _handler);
    }
  }, []);
  return useMemo(() => {
    return (
      <div ref={boxRef} className="web-video-box" style={style}>
        {isPlay ? (
          <video
            preload="auto"
            autoPlay={auto}
            loop={loop}
            ref={videoRef}
            controls={!hideControls}
            poster={thumb}
            playsInline
            webkit-playsinline="true"
            id="pron_video"
          // src="http://clips.vorwaerts-gmbh.de/big_buck_bunny.mp4"
          >
            {/* <source ref={sourceRef} src={src} type="application/x-mpegURL" /> */}
          </video>
        ) : (
          ""
        )}
        {/* {loading || !src ? (
          <div className="video_thumb">
            <Simg src={thumb} />
          </div>
        ) : (
          ""
        )}
        {loading || !src ? (
          <div className="video_center_text">视频加载中...</div>
        ) : (
          ""
        )} */}
      </div>
    );
  }, [isPlay]);
};
