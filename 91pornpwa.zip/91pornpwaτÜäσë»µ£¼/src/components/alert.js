import React, { useEffect, useRef, useState } from "react";
import emit from "../libs/eventEmitter";
import "../resources/css/alert.less";

export default (props) => {
  const [show, setShow] = useState(false);
  const [isHide, setIsHide] = useState(true);
  const [noBtn, setNobtn] = useState(false);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [funcs, setFuncs] = useState({
    cancel: null,
    submit: null,
  });
  const [notDouble, setNotDouble] = useState(false);
  const [cancelText, setCancelText] = useState("取消");
  const [submitText, setSubmitText] = useState("确认");
  const [boxStyle, setBoxStyle] = useState({});
  const [theme, setTheme] = useState("white");

  let timer;
  let timer1;
  useEffect(() => {
    emit.on(
      "changeAlert",
      ({
        _title,
        _content,
        _cancel,
        _submit,
        _notDouble,
        _cancelText,
        _submitText,
        _Nobtn,
        _boxStyle,
        _theme,
      }) => {
        // timer && clearTimeout(timer);
        timer1 && clearTimeout(timer1);
        timer1 = setTimeout(() => {
          setIsHide(false);
        }, 100);
        // setIsHide(false);
        setShow(true);
        setNobtn(!!_Nobtn);
        _title && setTitle(_title);
        _content && setContent(_content);
        setFuncs({
          cancel: _cancel,
          submit: _submit,
        });
        _notDouble && setNotDouble(_notDouble);
        _cancelText && setCancelText(_cancelText);
        _submitText && setSubmitText(_submitText);
        _boxStyle ? setBoxStyle(_boxStyle) : setBoxStyle({});
        _theme && setTheme(_theme);
      }
    );
    return () => {
      emit.off("changeAlert");
    };
  }, []);
  const onClose = () => {
    hideSelf();
    funcs.cancel && funcs.cancel();
  };
  const onSubmit = () => {
    hideSelf();
    funcs.submit && funcs.submit();
  };
  const hideSelf = () => {
    setIsHide(true);
    timer && clearTimeout(timer);
    timer = setTimeout(() => {
      setShow(false);
      setTitle("");
      setContent("");
      setFuncs({
        cancel: null,
        submit: null,
      });
      setNotDouble(false);
      setCancelText("取消");
      setSubmitText("确认");
      setTheme("white");
    }, 300);
  };
  if (!show) {
    return "";
  }
  return (
    <div
      className={`alert ${isHide ? "alert-out" : "alert-in"}`}
      // onClick={noBtn ? onClose : () => {}}
    >
      <div className="alert-layer" 
      onClick={hideSelf} 
      />
      <div
        className={`alert-body ${theme == "white" ? "" : "alertBlack"}`}
        style={boxStyle}
      >
        <span className={"alert-title"}>{title}</span>
        <div className={"alert-content"}>{content}</div>
        {noBtn ? (
          ""
        ) : (
          <div className={"alert-btn-box"}>
            {notDouble ? (
              ""
            ) : (
              <div className={"alert-btn-cancel"} onClick={onClose}>
                {cancelText}
              </div>
            )}
            <div
              className={notDouble ? "alert-btn-submit1" : "alert-btn-submit"}
              onClick={onSubmit}
            >
              {submitText}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
