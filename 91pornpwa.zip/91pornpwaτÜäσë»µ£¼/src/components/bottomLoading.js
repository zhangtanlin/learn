/*
 * @Author: Tom
 * @Date: 2021-11-17 15:31:51
 * @LastEditTime: 2021-11-22 11:50:48
 * @LastEditors: Tom
 * @Description:
 * @FilePath: /91pornpwa/src/components/bottomLoading.js
 */
import React, { useEffect, useMemo, useRef, useState } from "react";
import "../resources/css/bottomLoading.less";

export default (props) => {
  const { className = "" } = props;
  return (
    <div className={`bottomLoading ${className}`}>
      <div />
    </div>
  );
};
