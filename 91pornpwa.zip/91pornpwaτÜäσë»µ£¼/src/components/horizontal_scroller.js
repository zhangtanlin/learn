import React, { useEffect, useRef, useState } from "react";
import BScroll from "@better-scroll/core";
import { throttle } from "../libs/utils";
import Emit from "../libs/eventEmitter";
import "../resources/css/scrolltabs.less";

export default props => {
  const { children } = props;
  const scrollerRef = useRef(null);
  const [bscroll, setBscroll] = useState(null);
  useEffect(() => {
    setTimeout(() => {
      if (scrollerRef.current && !bscroll) {
        setBscroll(
          new BScroll(scrollerRef.current, {
            scrollY: false,
            scrollX: true,
            useTransition: true,
            probeType: 2
          })
        );
      }
    }, 500);
    return () => {
      if (bscroll) {
        bscroll.destroy();
      }
    };
  }, [scrollerRef.current, bscroll]);
  return (
    <div className="tab-nav-list ">
      <div ref={scrollerRef} className="scroll_box" >
        <div className="tab-slide-content">{children}</div>
      </div>
    </div>
  );
};
