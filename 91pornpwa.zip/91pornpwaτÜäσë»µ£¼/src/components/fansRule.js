/*
 * @Author: Tom
 * @Date: 2021-11-24 13:57:41
 * @LastEditTime: 2021-12-08 09:39:59
 * @LastEditors: Tom
 * @Description:
 * @FilePath: /91pornpwa/src/components/fansRule.js
 */
import React, { useEffect, useMemo, useRef, useState } from "react";
import "../resources/css/fansDetail.less";
import Clickbtn from "./clickbtn";
import ScrollArea from "./scrollarea";
import Emit from "../libs/eventEmitter";
import Loading from "./loading";
import NoData from "./noData";
import back from "../resources/img/search/back_white.png";
import { fansIntroduce } from "../libs/http";

export default (props) => {
  const { stackKey } = props;
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    fansIntroduce().then((res) => {
      // console.log("res", res);
      setLoading(false);
      if (res.data && res.data.items.length > 0) {
        setData(res.data.items);
      }
    });
  }, []);
  const renderHeader = () => {
    return (
      <div className="fansDetail_header">
        <Clickbtn
          className="fansDetail_header_back"
          onTap={() => {
            Emit.emit(stackKey, stackKey);
          }}
        >
          <img src={back} />
        </Clickbtn>
        <div className="fansDetail_header_title">粉丝团规则</div>
      </div>
    );
  };
  const renderItem = (item, index) => {
    return (
      <div key={index}>
        <div className="fansDetail_title">
          <span />
          {item.title}
        </div>
        <p className="fansDetail_body">{item.content}</p>
      </div>
    );
  };
  return (
    <div className="page-content-flex fansDetail">
      {renderHeader()}
      {loading ? (
        <Loading show type={1} />
      ) : data.length > 0 ? (
        <ScrollArea downRefresh={false}>
          {data.map((item, index) => {
            return renderItem(item, index);
          })}
        </ScrollArea>
      ) : (
        <NoData />
      )}
      {data.length > 0 && (
        <div
          className="fansDetail_btn"
          onClick={() => {
            Emit.emit(stackKey, stackKey);
          }}
        >
          我已阅读并知晓
        </div>
      )}
    </div>
  );
};
