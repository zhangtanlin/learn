import React, { useEffect, useRef, useState } from "react";
import axios from "axios";
import CryptoData from "../libs/CryptoData";
import "intersection-observer";
import Hammer from "hammerjs";
import StackStore from "../store/stack";
import UserStore from "../store/user";

import Index from "./index";
import Hot from "./hot";
import User from "./user";
import Message from "./message";
import Game from './game';

import IndexIcon from "../resources/img/tabIcons/index.png";
import IndexIconActive from "../resources/img/tabIconsActive/index.png";
import HotIcon from "../resources/img/tabIcons/hot.png";
import HotIconActive from "../resources/img/tabIconsActive/hot.png";
import MessageIcon from "../resources/img/tabIcons/message.png";
import MessageIconActive from "../resources/img/tabIconsActive/message.png";
import UserIcon from "../resources/img/tabIcons/user.png";
import UserIconActive from "../resources/img/tabIconsActive/user.png";
import GameIcon from "../resources/img/tabIcons/game.png";
import GameIconActive from "../resources/img/tabIconsActive/game.png";

// import IndexIcon from "../resources/img/tabIconsActive/index0.png";
// import IndexIconActive from "../resources/img/tabIconsActive/index0.png";
// import HotIcon from "../resources/img/tabIconsActive/index1.png";
// import HotIconActive from "../resources/img/tabIconsActive/index1.png";
// import MessageIcon from "../resources/img/tabIconsActive/index2.png";
// import MessageIconActive from "../resources/img/tabIconsActive/index2.png";
// import UserIcon from "../resources/img/tabIconsActive/index3.png";
// import UserIconActive from "../resources/img/tabIconsActive/index3.png";

import "../resources/orientationchange-fix.min.js";
import BindPhone from "./user/bindPhoneNew";
import Alert from "./alert";
import GameAlert from './gameAlert';
import AlertVIP from './alertVip';
import Activity from './activity';
import Toast from "./toast";
import Notice from "./notice";
import CityPicker from "./cityPicker";
import { getHomeConfig, getNoticeAll, apiSetInvite } from "../libs/http";
import { getHomeData } from '../libs/utils';

import globalVar from "../libs/globalVar";
import Emit from "../libs/eventEmitter";
import "../libs/defendCC";
import StackPage from "./stackpage";
import Loading from "./loading";

export default (props) => {
  const [stacks] = StackStore.useGlobalState("stacks");
  const [initApp, setAppStatus] = useState(false); //初始化
  // eslint-disable-next-line no-unused-vars
  const [horizontalScreen, setScreen] = useState(false); //是否横屏
  const [pageStatus, setPageStatus] = useState(0);
  const [hideBottom, setHideBottom] = useState(false);
  const [tabs, setTabs] = useState([
    {
      name: "首页",
      icon: IndexIcon,
      iconActive: IndexIconActive,
    },
    {
      name: "热点",
      icon: HotIcon,
      iconActive: HotIconActive,
    },
    {
      name: "消息",
      icon: MessageIcon,
      iconActive: MessageIconActive,
    },
    {
      name: "我的",
      icon: UserIcon,
      iconActive: UserIconActive,
    },
  ])

  const [selectName, setSelectName] = useState("首页");
  const [loading, setLoading] = useState(true);
  // const detectionScreen = () => {
  //   if (window.orientation == 180 || window.orientation == 0) {
  //     setPortrait(true);
  //   }
  //   if (window.orientation == 90 || window.orientation == -90) {
  //     setPortrait(false);
  //   }
  // };
  const getData = async () => {
    try {
      if (globalVar?.firstData) {
        handleCheckData()
      } else {
        getHomeData().then((res) => {
          if (res) {
            handleCheckData()
          } else {
            handleChageAlert(`请求错误！请检查网络后重试！\n Home:${res.data}`)
          }
        }).catch((error) => {
          handleChageAlert(`请求超时！请检查网络后重试！\n Home:${error}`)
        })
      }

    } catch (error) {
      Emit.emit("changeAlert", {
        _title: "提示",
        _content: `请求失败！请稍后重试！home:${error}`,
        _submitText: "重试",
        _notDouble: true,
        _submit: () => {
          getData();
        },
      });
    }
  };

  const handleCheckData = () => {
    if (globalVar.bottomShowGames) {
      tabs.splice(2, 0, {
        name: "游戏",
        icon: GameIcon,
        iconActive: GameIconActive,
      })
    }
    if (globalVar.screen && globalVar.screen.img_url) {
      setImg(globalVar.screen.img_url, globalVar.screen.url);
    }
    if (globalVar?.affCode) {
      apiSetInvite({
        aff_code: globalVar.affCode,
      })
    }
    setLoading(false)
    getNoticeAll().then((noticeList) => {
      if (noticeList?.data?.notice?.length > 0) {
        let newList = noticeList?.data?.notice.filter(item => item.type == 1)
        if (newList.length > 0) {
          globalVar.activity = newList; // 活动弹窗
          setTimeout(() => {
            Emit.emit("activityAlert");
          }, 500);
        }
      }
      if (globalVar?.notice?.content) {
        Emit.emit("noticeAlert");
      }
    });
  }

  const handleChageAlert = (text) => {
    Emit.emit("changeAlert", {
      _title: "提示",
      _content: `${text}`,
      _submitText: "重试",
      _notDouble: true,
      _submit: () => {
        getData();
      },
    });
  }

  const setImg = (img, url) => {
    const SrcOfPwaDomain = img;
    // .replace(
    //   /^http(s)?:\/\/(.*?)\//,
    //   "http://images.ycyj365.cn/"
    // );
    let ext = SrcOfPwaDomain.substring(SrcOfPwaDomain.lastIndexOf(".") + 1);
    ext = ext === "jpg" ? "jpeg" : ext;
    if ("jpg,jpeg,png,gif".indexOf(ext) == -1) return;
    const arraybufferToBase64 = function (t) {
      return new Promise((function (e) {
        const n = new Blob([t]);
        const r = new FileReader();
        r.onload = function (t) {
          const n = t.target.result;
          const r = n.substring(n.indexOf(",") + 1);
          e(r);
        };
        r.readAsDataURL(n);
      }));
    };
    axios.get(SrcOfPwaDomain, { responseType: 'arraybuffer' }).then((res) => {
      arraybufferToBase64(res.data).then(base64str => {
        const decryptStr = CryptoData.DecryptImage(base64str);
        const _obj = {
          img: `data:image/${ext};base64,${decryptStr}`,
          url,
        };
        localStorage.setItem("WELCOME_AD_91PRON", JSON.stringify(_obj));
      })
    });
  };

  useEffect(() => {
    getData();
    // initDaily_view();
  }, []);
  useEffect(() => {
    // 解绑手机后回到首页的监听
    Emit.on("backHome", () => {
      setSelectName("每日");
    });
    // 隐藏底部tab的监听
    Emit.on("HIDE_BOTTOM", (status) => {
      setHideBottom(status);
    });
    return () => {
      Emit.off("backHome");
      Emit.off("HIDE_BOTTOM");
    };
  }, []);
  useEffect(() => {
    if (!globalVar.bodyFontSize) {
      globalVar.bodyFontSize = parseInt(
        document.documentElement.style.fontSize.replace("px", "")
      );
    }
    setPageStatus(2);
    if (!initApp) {
      setAppStatus(true);
      // detectionScreen();
      window.addEventListener(
        "orientationchange",
        function () {
          // console.log(document.body.clientWidth);
          if (window.neworientation.current === "portrait") {
            // console.log("-------------竖屏--------------");
            setScreen(false);
          } else {
            // console.log("**************横屏*************");
            setScreen(true);
          }
        },
        false
      );
    }
    document.body.addEventListener(
      "touchmove",
      (event) => {
        event.preventDefault();
      },
      {
        passive: false,
      }
    );
  }, []);
  const homeTabBarRef = useRef(null);
  useEffect(() => {
    if (!homeTabBarRef.current) return;
    const hometabitems =
      Array.from(homeTabBarRef.current.getElementsByClassName("home-tab-item"));
    const hammers = [];
    hometabitems.forEach((hti) => {
      const hammer = new Hammer(hti);
      hammer.on("tap", () => {
        Emit.emit("coloseSearch");
        const name = hti.getAttribute("data-name");
        if (
          !globalVar.isBindMobile &&
          (name == "我的"
            // || name == "消息" 
            // || name == "热点"
          )
        ) {
          // Emit.emit("showToast", { text: "请先登录或注册！" });
          const stackKey = `BindPhone-${new Date().getTime()}`;
          StackStore.dispatch({
            type: "push",
            payload: {
              name: "bindPhone",
              element: (
                <StackPage
                  stackKey={stackKey}
                  key={stackKey}
                  style={{ zIndex: stacks.length + 2 }}
                >
                  <BindPhone stackKey={stackKey} />
                </StackPage>
              ),
            },
          });
        } else {
          setSelectName(name);
        }
      });
      hammers.push(hammer);
    });
    return () => {
      hammers.forEach((hammer) => {
        hammer.off("tap");
      });
    };
  }, [homeTabBarRef.current, pageStatus]);
  // 初始化观看次数
  const initDaily_view = () => {
    let daily_view = 10;
    const SET = () => {
      const data = {
        daily_view: 10,
        day: new Date().getDate(),
        ids: [],
      };
      localStorage.setItem("91PRON_DAILY_VIEW", JSON.stringify(data));
    };
    let res = localStorage.getItem("91PRON_DAILY_VIEW");
    // console.log("DAILY_VIEW", res);
    if (!res) {
      SET();
    } else {
      const result = JSON.parse(res);
      if (result.day != new Date().getDate()) {
        SET();
      } else {
        daily_view = result.daily_view;
      }
    }
    globalVar.daily_view = daily_view;
  };
  return pageStatus === 0 ? null : (
    <div className="container">
      {/* {horizontalScreen && (
        <div className="swich_dialog">
          <div className="swich_dialog_content">
            系统检测到横屏，为了您更好的体验请您切换为竖屏浏览
          </div>
        </div>
      )} */}
      <div className="full-column">
        {loading ? (
          <div
            style={{
              display: "flex",
              flex: 1,
              backgroundColor: "#140123",
            }}
          >
            <Loading show type="1" />
          </div>
        ) : (
          <>
            <Index isVisible={selectName === "首页"} />
            <Hot isVisible={selectName === "热点"} />
            <Game isVisible={selectName === "游戏"} />
            <Message isVisible={selectName === "消息"} />
            <User isVisible={selectName === "我的"} />
          </>
        )}
      </div>
      <div
        className="home-tab-bar"
        style={{ display: hideBottom ? "none" : "flex" }}
        ref={homeTabBarRef}
      >
        {tabs.map((t) => (
          <div
            data-name={t.name}
            className={`home-tab-item ${selectName === t.name ? "selected" : ""
              }`}
            key={`home-tab-item-${t.name}`}
          >
            <img src={selectName === t.name ? t.iconActive : t.icon} />
            <p>{t.name}</p>
          </div>
        ))}
      </div>
      <div className="stack-pages-container">
        {stacks.map((s) => s.element)}
      </div>
      <Alert />
      <GameAlert />
      <AlertVIP />
      <Toast />
      <Notice />
      <Activity />
      <CityPicker />
    </div>
  );
};

