/*
 * @Author: Tom
 * @Date: 2021-12-22 14:04:07
 * @LastEditTime: 2021-12-22 14:47:58
 * @LastEditors: Tom
 * @Description:
 * @FilePath: /91pornpwa/src/components/message/index.js
 */
import React, { useEffect, useMemo, useRef, useState } from "react";
import StackStore from "../../store/stack";
import "../../resources/css/message.less";
import logoIcon from "../../resources/img/message/icon_kefu_tag.png";
import guanfangIcon from "../../resources/img/message/icon_guanfang_tag.png";
import KefuDetail from "./kefuDetail";
import Clickbtn from "../clickbtn";
import StackPage from "../stackpage";
import Loading from '../loading'

export default (props) => {
  const { isVisible } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const [init, setInit] = useState(false)
  const renderItem = () => {
    return (
      <Clickbtn
        className="message_item"
        onTap={() => {
          const stackKey = `kefuDetail-${new Date().getTime()}`;
          StackStore.dispatch({
            type: "push",
            payload: {
              name: "kefuDetail",
              element: (
                <StackPage
                  stackKey={stackKey}
                  key={stackKey}
                  style={{ zIndex: stacks.length + 2 }}
                >
                  <KefuDetail stackKey={stackKey} />
                </StackPage>
              ),
            },
          });
        }}
      >
        <div className="message_item_avatar">
          <img src={logoIcon} />
          <img src={guanfangIcon} />
        </div>
        <div className="message_desc">
          <p>91客服</p>
          <span>有什么问题你跟我说，我马上就来帮你</span>
        </div>
      </Clickbtn>
    );
  };

  useEffect(()=>{
    if(isVisible && !init){
      setInit(true)
    }
  },[isVisible])

  return (
    <div
      className={`positioned-container message_container ${
        isVisible ? "visible" : "hide"
      }`}
      style={{
        opacity: isVisible ? "1" : "0",
      }}
    >
      <div className="message_title">消息中心</div>
      {/* <div className="thin-line" /> */}
      { init ? renderItem() : <Loading />}
    </div>
  );
};
