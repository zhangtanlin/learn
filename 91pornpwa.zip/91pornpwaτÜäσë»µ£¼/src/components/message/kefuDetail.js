/*
 * @Author: Tom
 * @Date: 2021-12-22 14:39:50
 * @LastEditTime: 2021-12-23 15:39:26
 * @LastEditors: Tom
 * @Description:
 * @FilePath: /91pornpwa/src/components/message/kefuDetail.js
 */
import React, { useEffect, useMemo, useRef, useState } from "react";

import BackHeader from "../backHeader";
import ScrollArea from "../scrollarea";
import StackStore from "../../store/stack";
import { feedbackDetail, sendFeedback } from "../../libs/http";
import ClickBtn from "../clickBtn";
import Emit from "../../libs/eventEmitter";
import "../../resources/css/kefu.less";
import Loading from "../loading";
import Simg from "../simg";
import mineIcon from "../../resources/img/message/icon_message_me.png";
import imgIcon from "../../resources/img/message/message_img.png";
import iconLogo from "../../resources/img/message/icon_message_kefu.png";
import { UploadRequest } from "../../libs/uploadImg";

let getting = false;
export default (props) => {
  const { stackKey } = props;
  const inputRef = useRef(null);
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState({ a: true });
  const [stacks] = StackStore.useGlobalState("stacks");
  let page = 1;
  useEffect(() => {
    getData("init");
  }, []);
  const getData = (status) => {
    if (!loadingMore.a || getting) return;
    if (!status) {
      page++;
    }
    getting = true;
    feedbackDetail({ page })
      .then((res) => {
        // console.log("getFeedbackList=>", page, res.data);
        if (res.data.length > 0) {
          if (res.data.length < 5) {
            loadingMore.a = false;
            setLoadingMore({ ...loadingMore });
          }
          if (status) {
            setData(res.data.reverse());
          } else {
            setData((pre) => [...res.data.reverse(), ...pre]);
          }
        } else {
          if (page == 1) {
            setData([]);
          }
          loadingMore.a = false;
          setLoadingMore({ ...loadingMore });
        }
        setLoading(false);
        getting = false;
      })
      .catch(() => {
        setLoading(false);
        getting = false;
      });
  };
  const onSetCover = async ({ target }) => {
    setLoading(true);
    const imgFile = new FileReader();
    imgFile.readAsDataURL(target.files[0]);
    imgFile.onload = () => {
      UploadRequest({
        id: new Date().getTime(),
        cover: imgFile.result.toString(),
      })
        .then((res) => {
          if (res) {
            sendMsg(res);
          } else {
            Emit.emit("changeAlert", {
              _title: "提示",
              _content: "图片上传失败，请稍后再试",
              _submitText: "确定",
              _submit: () => {},
              _notDouble: true,
            });
            setLoading(false);
          }
        })
        .catch(() => {
          setLoading(false);
          Emit.emit("changeAlert", {
            _title: "提示",
            _content: "图片上传失败，请稍后再试",
            _submitText: "确定",
            _submit: () => {},
            _notDouble: true,
          });
        });
    };
  };
  const sendMsg = (imgUrl) => {
    if (!imgUrl && !inputRef.current.value) {
      Emit.emit("showToast", { text: "请输入内容！" });
      return;
    }
    sendFeedback({
      content: imgUrl || inputRef.current.value,
      message_type: imgUrl ? 2 : 1,
    })
      .then((res) => {
        setLoading(false);
        // console.log("发送", res);
        Emit.emit("showToast", { text: res.data.msg });
        page = 1;
        loadingMore.a = true;
        getting = false;
        setLoadingMore({ ...loadingMore });
        getData("init");
        inputRef.current.value = "";
      })
      .catch(() => {
        setLoading(false);
        Emit.emit("changeAlert", {
          _title: "提示",
          _content: "反馈信息上传失败，请稍后再试",
          _submitText: "确定",
          _submit: () => {},
          _notDouble: true,
        });
      });
  };
  const mineItem = (item, index) => {
    return (
      <div key={index} className="kefuDetail-mineItem">
        <div className="kefuDetail-msg-time">{item.createdAt}</div>
        <div className="kefuDetail-msg">
          {item.messageType == 1 ? (
            <div className="kefuDetail-msg-content">{item.message}</div>
          ) : (
            <div className="kefuDetail-img">
              <Simg src={item.message} objectFit="contain" alwaysShow />
            </div>
          )}
          <img className="kefuDetail-avatar" src={mineIcon} />
        </div>
      </div>
    );
  };
  const hisItem = (item, index) => {
    return (
      <div key={index} className="kefuDetail-hisItem">
        <div className="kefuDetail-msg-time">{item.createdAt}</div>
        <div className="kefuDetail-msg">
          <img className="kefuDetail-avatar" src={iconLogo} />
          {item.messageType == 1 ? (
            <div className="kefuDetail-msg-content">{item.message}</div>
          ) : (
            <div className="kefuDetail-img">
              <Simg src={item.message} objectFit="contain" alwaysShow />
            </div>
          )}
        </div>
      </div>
    );
  };
  return (
    <div className="page-content-flex kefuDetail">
      <BackHeader
        stackKey={stackKey}
        style={{ color: "white" }}
        title="客服回复"
        right={() => {
          return <div style={{ width: "1.2rem" }} />;
        }}
      />
      {data.length > 0 && (
        <ScrollArea
          ListData={data}
          onScrollTop={() => {
            getData();
          }}
          startToBottom
        >
          {data.map((item, index) => {
            if (item.status == 1) {
              return mineItem(item, index);
            }
            return hisItem(item, index);
          })}
          <div style={{ height: "1.5rem" }} />
        </ScrollArea>
      )}
      <div className="kefuDetail-btn">
        <div className="kefuDetail-uploadImg">
          <img src={imgIcon} />
          <input type="file" accept="image/*" onChange={onSetCover} />
        </div>
        <div className="kefuDetail-btn-input">
          <input ref={inputRef} type="text" placeholder="输入回复内容" />
        </div>

        <div
          className="kefuDetail-btn-send"
          onClick={() => {
            sendMsg();
          }}
        >
          发送
        </div>
      </div>
      {loading && <Loading show type={1} />}
    </div>
  );
};
