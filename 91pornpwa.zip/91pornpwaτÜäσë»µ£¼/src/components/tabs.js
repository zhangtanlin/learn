/*
 * @Author: Tom
 * @Date: 2021-11-11 14:45:38
 * @LastEditTime: 2021-11-11 20:36:57
 * @LastEditors: Tom
 * @Description:
 * @FilePath: /91avpwa/src/components/tabs.js
 */
import React, { useEffect, useMemo, useRef, useState } from "react";
import "../resources/css/tabs.less";
import Clickbtn from './clickbtn'

export default (props) => {
  const { onChange, arr, current } = props;
  // const [selected, setSelected] = useState(0);

  const select = (item, index) => {
    // setSelected(item);
    onChange({value:item, index});
  }

  // useEffect(()=>{
  //   setSelected(current)
  // },[current])

  return (
    <div className={'selectWrapper'}>
      {Array.isArray(arr) &&
        arr.map((item, index) => (
          <Clickbtn
            key={index}
            className={index === current ? 'active' : 'un_active'}
            onClick={() => select(item, index)}
          >
            {item.name}
          </Clickbtn>
        ))
      }
    </div>
  );
};

