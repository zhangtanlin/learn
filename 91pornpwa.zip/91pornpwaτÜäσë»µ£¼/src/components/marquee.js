import React, { useRef, useState, useEffect } from "react";
import "../resources/css/marquee.less";
export default (props) => {
  const contentRef = useRef(null);
  const [duration, setDuration] = useState("");
  useEffect(() => {
    const dom = contentRef.current;
    if (dom) {
      const { width } = dom.getBoundingClientRect();
      if (width > props.width) {
        // 我这边取的速度是按一个字的大小
        setDuration(width / 50 + "s");
      } else {
        // 小于宽度的时候清掉时间
        setDuration("");
      }
    } else {
      setDuration("");
    }
  }, [props.children]);
  useEffect(() => {
    return () => {
      setDuration("");
    };
  }, []);
  return (
    <div
      style={{ width: props.width, ...props.style }}
      className={"marquee-wrapper"}
    >
      <div
        className={"marquee-textContent"}
        ref={contentRef}
        // 计算好动画时间传过去
        style={{
          animationDuration: duration,
          // 第二个动画等第一个执行之后执行
          animationDelay: duration ? `0s, ${duration}` : "",
        }}
      >
        {props.children}
      </div>
    </div>
  );
};
