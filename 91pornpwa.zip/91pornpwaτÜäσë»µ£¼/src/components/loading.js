/*
 * @Author: Tom
 * @Date: 2021-08-02 14:08:32
 * @LastEditTime: 2021-11-24 20:21:37
 * @LastEditors: Tom
 * @Description:
 * @FilePath: /91pornpwa/src/components/loading.js
 */
import React, { useEffect, useRef, useState } from "react";
import "../resources/css/loading.less";

export default (props) => {
  const {
    type = "normal",
    text = "",
    show,
    overSize = false,
    size = 30,
  } = props;

  if (!show) {
    return "";
  }
  if (type != "normal") {
    return (
      <div
        className="loading"
        style={{ backgroundColor: "transparent", position: "absolute" }}
      >
        <span className="circle-animeted"></span>
      </div>
    );
  }
  return (
    <div className={overSize ? "loading" : "loading-inPage"}>
      <div
        className="loading"
        style={{ backgroundColor: "transparent", position: "absolute" }}
      >
        <span className="circle-animeted"></span>
      </div>
      <span>{text}</span>
    </div>
  );
};
