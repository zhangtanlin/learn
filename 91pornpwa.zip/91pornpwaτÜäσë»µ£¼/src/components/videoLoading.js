import React, { useEffect, useRef, useMemo, useState } from "react";
import "../resources/css/videoLoading.less";
export default (props) => {
  return (
    <div className="videoLoading">
      <div className={"skCircleFade"}>
        {(() => {
          let ary = [];
          for (let i = 0; i < 12; i++) {
            ary.push(<div className="skCircleFadeDot" key={i} />);
          }
          return ary;
        })()}
      </div>
    </div>
  );
};
