import React, { useEffect, useRef, useState } from "react";
import emit from "../libs/eventEmitter";
import "../resources/css/alertvip.less";
import alertvip from '../resources/img/user/alertvip4.png'
import alert_b1 from '../resources/img/user/alertvip_b1.png'
import alert_b2 from '../resources/img/user/alertvip_b2.png'

export default (props) => {
  const [show, setShow] = useState(false);
  const [isHide, setIsHide] = useState(true);
  const [funcs, setFuncs] = useState({
    cancel: null,
    submit: null,
  });

  let timer;
  let timer1;
  useEffect(() => {
    emit.on(
      "vipAlert",
      ({
        _cancel,
        _submit,
      }) => {
        // timer && clearTimeout(timer);
        timer1 && clearTimeout(timer1);
        timer1 = setTimeout(() => {
          setIsHide(false);
        }, 100);
        // setIsHide(false);
        setShow(true);
        setFuncs({
          cancel: _cancel,
          submit: _submit,
        });
      }
    );
    return () => {
      emit.off("vipAlert");
    };
  }, []);
  const onClose = () => {
    hideSelf();
    funcs.cancel && funcs.cancel();
  };
  const onSubmit = () => {
    hideSelf();
    funcs.submit && funcs.submit();
  };
  const hideSelf = () => {
    setIsHide(true);
    timer && clearTimeout(timer);
    timer = setTimeout(() => {
      setShow(false);
      setFuncs({
        cancel: null,
        submit: null,
      });
    }, 300);
  };
  if (!show) {
    return "";
  }
  return (
    <div
      className={`alertvip ${isHide ? "alertvip-out" : "alertvip-in"}`}
    >
      <div className="alertvip-layer" onClick={hideSelf} />
      <div
        className={`alertvip-body "alertvipBlack"}`}
      >
        <img className="alertvip-bg" src={alertvip} />
        <div className={"alertvip-btn-box"}>
          <img src={alert_b1} onClick={onClose}/>
          <img src={alert_b2} onClick={onSubmit}/>
          {/* <div className={"alertvip-btn-cancel"} onClick={onClose}>
            开通VIP
          </div>
          <div
            className={"alertvip-btn-submit"}
            onClick={onSubmit}
          >
            邀请无限看
          </div> */}
        </div>
      </div>
    </div>
  );
};
