import React, { createRef, useEffect, useMemo, useRef, useState } from "react";
import "../resources/css/tabsbar.less";
import Clickbtn from './clickbtn'

export default (props) => {
  const { onChange, arr, current } = props;
  const itemsUl = useRef(null);
  const [barWidth, setBarWidth] = useState(0);
  const [position, setPosition] = useState(0);

  useEffect(()=>{
    setBarWidth(itemsUl?.current.children[0].getBoundingClientRect().width)
  },[arr])

  useEffect(()=>{
    let preWidth = 0;
    for (let i = 0; i < current; i++) {
      preWidth += itemsUl?.current.children[i].offsetWidth
      
    }
    const barWidth = itemsUl?.current.children[current].offsetWidth
    setBarWidth(barWidth)
    setPosition(preWidth)
  },[current])

  const select = (item, index) => {
    onChange({ value: item, index });
  }

  return (
    <div className={'tabs_bar_container'} >
      <div className={'tabs_item'} ref={itemsUl}>
        {Array.isArray(arr) &&
          arr.map((item, index) => (
            <Clickbtn
              key={index}
              className={index === current ? 'active' : 'unactive'}
              onTap={() => select(item, index)}
            >
              {item.name}
            </Clickbtn>
          ))
        }
      </div>
      <div className={'tabs_bar'} style={{ width: `${barWidth}px`,transform: `translate3d(${position}px, 0px, 0px)`, }}></div>
    </div>
  );
};

