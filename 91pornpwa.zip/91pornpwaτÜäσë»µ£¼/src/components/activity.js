import React, { useEffect, useRef, useState } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import SwiperCore, { Autoplay } from "swiper/core";
import emit from "../libs/eventEmitter";
import Clickbtn from './clickbtn'
import "../resources/css/activity.less";
import "swiper/swiper.min.css";
import "swiper/components/pagination/pagination.min.css";
import Simg from '../components/simg'
import closeicon from '../resources/img/index/icon_friend_close.png'
import globalVar from "../libs/globalVar";
import StackStore from '../store/stack';
import StackPage from './stackpage';
import Competition from './hot/pages/competition'

SwiperCore.use([Autoplay]);
export default () => {
  const [hideSelf, setHideSelf] = useState(true);
  const [stacks] = StackStore.useGlobalState("stacks");

  useEffect(() => {
    emit.on(
      "activityAlert",
      () => {
        setHideSelf(false);
        setTimeout(() => {
          if (
            document &&
            document.getElementsByClassName("dialog_scaleLayer-02")[0]
          ) {
            document
              .getElementsByClassName("dialog_scaleLayer-02")[0]
              .classList.add("dialog_scale-in-02");
          }
        }, 100);
      })
    return () => {
      emit.off("activityAlert");
    };
  }, []);

  const onCloseNotice = () => {
    if (document && document.getElementsByClassName("dialog_scaleLayer-02")[0]) {
      document
        .getElementsByClassName("dialog_scaleLayer-02")[0]
        .classList.add("dialog_scale-out-02");
    }
    setTimeout(() => {
      setHideSelf(true);
    }, 300);
  }

  const onToTheCompetition = (id, title) => {
    const stackKey = `competition-${new Date().getTime()}`;
    StackStore.dispatch({
        type: "push",
        payload: {
            name: "Competition",
            element: (
                <StackPage
                    stackKey={stackKey}
                    key={stackKey}
                    style={{ zIndex: stacks.length + 2 }}
                >
                    <Competition stackKey={stackKey} id={id} title={title} showRight={true} />
                </StackPage>
            ),
        },
    });
}

  const onTapUrl = (item) => {
    if (item.path == "openOut") {
      window.open(item.url, "_blank");
    }
    if(item.path == "videoActivity"){
      onToTheCompetition(item.value,"活动详情")
      onCloseNotice()
    }
    if(item.path == "movieDetail"){
      onCloseNotice()
    }
  }

  if (hideSelf) {
    return null;
  }
  return (
    <div className="dialog_scaleLayer-02">
      <div
        className="dialog_scaleLayer-close-02"

      />
      <div className="dialog_scaleLayer-body-02">
        <div className="notice-container-02">
          
          <div className="notice-content-02" style={{ backgroundColor: 'transparent' }}>
            <Swiper
              initialSlide={0}
              className="featured-swiper"
              noSwipingClass={"noSwiper-container"}
              loop
              autoplay={{
                delay: 3000,
                disableOnInteraction: false
              }}
            >
              {globalVar.activity.map((item, index) => {
                return <SwiperSlide key={`${item}-${index}`}>
                <Clickbtn onTap={() => {
                  onTapUrl(item)
                }}>
                  <Simg className="swiper-img" src={item.img_url} noBg noThumb/>
                </Clickbtn>
              </SwiperSlide>
              })}
            </Swiper>
          </div>
          <Clickbtn className="notice-header-02" onTap={() => {
            onCloseNotice();
          }}>
            <img src={closeicon} />
          </Clickbtn>
        </div>
      </div>
    </div>
  );
};
