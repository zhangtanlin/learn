# 项目须知
1. flutter版本2.10.2，使用fvm确保自己的版本OK
2. 基于chrome调试，由于chrome最小字号是12像素，可能会有一定的显示偏差，如果是要看准确效果，可以build之后，使用http-server生成本地静态站点用safari访问。
3. App端没有 dart:html,只有web端才有，所以在用到 html 的地方需使用 universal_html 兼容。
运行调试命令：fvm flutter run -d chrome --web-renderer html --web-port=9999
构建release命令：fvm flutter build web --web-renderer html --release（输出路径在build/web目录下面）
fvm flutter build web --web-renderer canvaskit --release
http-server --cors -p 8888 -o

## Tips

Error: Cannot run with sound null safety, because the following dependencies
don't support null safety:
run
flutter run --no-sound-null-safety
build
flutter build apk --no-sound-null-safety


## 解决web端全屏问题
cd ~/.pub-cache/hosted/pub.dartlang.org/video_player_web_hls-0.1.11+3/lib  
(video_player_web.dart所在目录，运行命令即可，然后运行命令“open .”打开该目录)

在_VideoPlayer类中添加
void requestFullScreen() {
  videoElement.enterFullscreen();
}
void exitFullScreen() {
  videoElement.exitFullscreen();
}
在VideoPlayerPlugin类中添加
@override
void requestFullScreen(int textureId) {
  _videoPlayers[textureId]!.requestFullScreen();
}
@override
void exitFullScreen(int textureId) {
  _videoPlayers[textureId]!.exitFullScreen();
}
2. video_player_platform_interface.dart的VideoPlayerPlatform类中添加以下代码：
void requestFullScreen(int textureId) {
  throw UnimplementedError('requestFullScreen() has not been implemented.');
}
void exitFullScreen(int textureId) {
  throw UnimplementedError('exitFullScreen() has not been implemented.');
}
3. video_player.dart的VideoPlayerController类中添加以下代码: 
void requestFullScreen() async {
  _videoPlayerPlatform.requestFullScreen(_textureId);
}
void exitFullScreen() async {
  _videoPlayerPlatform.exitFullScreen(_textureId);
}
4. video_player_web_hls.dart
void changeVideo(String newUri) {
  uri = newUri;
  if (isSupported() &&
      (uri.toString().contains("m3u8") || await _testIfM3u8())) {
        _hls.loadSource(uri.toString())
  } else {
    videoElement.src = uri.toString();
    videoElement.load();
  }
}