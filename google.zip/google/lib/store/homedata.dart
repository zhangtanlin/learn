import 'package:flutter/foundation.dart';
import 'package:iaimei/model/config.dart';

class HomeData with ChangeNotifier, DiagnosticableTreeMixin {
  late Config _data; // 整合接口全部数据

  Config get data => _data;

  void setData(Config data) {
    _data = data;
    notifyListeners();
  }

  void setVersion(Version version) {
    _data.version = version;
    notifyListeners();
  }
}
