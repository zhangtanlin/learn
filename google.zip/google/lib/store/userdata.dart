import 'package:flutter/foundation.dart';
import 'package:iaimei/model/user_info_model.dart';

class UserData with ChangeNotifier, DiagnosticableTreeMixin {
  UserInfoModel _userInfo = UserInfoModel(); // 个人信息

  UserInfoModel get userInfo => _userInfo;

  void setData(UserInfoModel data) {
    _userInfo = data;
    notifyListeners();
  }

  /// 设置昵称
  void setNickname(String? data) {
    _userInfo.nickname = data;
    notifyListeners();
  }

  /// 设置性别
  void setSexType(int? data) {
    _userInfo.sex = data;
    notifyListeners();
  }

  /// 设置生日
  void setBirthday(String? data) {
    _userInfo.birthday = data;
    notifyListeners();
  }

  /// 设置消息信息
  void setMessageTip(int? data) {
    _userInfo.messageTip = data;
    notifyListeners();
  }
}
