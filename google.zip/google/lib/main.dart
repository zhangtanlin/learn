import 'dart:io';

import 'package:bot_toast/bot_toast.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:iaimei/app_const.dart';
import 'package:iaimei/global.dart';
import 'package:iaimei/res/string_res.dart';
import 'package:iaimei/router/routers.dart';
import 'package:iaimei/store/homedata.dart';
import 'package:iaimei/store/userdata.dart';
import 'package:iaimei/utils/bar_util.dart';
import 'package:iaimei/utils/common.dart';
import 'package:iaimei/utils/crypto.dart';
import 'package:iaimei/utils/log_util.dart';
import 'package:isolated_worker/worker_delegator.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:provider/provider.dart';

void main() async {
  // 强制竖屏

  await Hive.initFlutter();
  AppGlobal.appBox =
      await Hive.openBox(AppConst.appHiveBoxName); // 用于存储一些简单的键值对
  AppGlobal.imageCacheBox =
      await Hive.openBox(AppConst.imgCacheHiveBoxName); // 图片缓存
  AppGlobal.imageAssetBox = await Hive.openBox('HiveBox_ImageAsset'); //图集
  AppGlobal.videoWatchRecordBox =
      await Hive.openBox(AppConst.videoWatchRecordBoxName); // 长视频
  AppGlobal.smallVideoWatchRecordBox =
      await Hive.openBox(AppConst.shortVideoWatchRecordBoxName); // 小视频
  AppGlobal.comicsWatchRecordBox =
      await Hive.openBox(AppConst.comicsReadRecordBoxName); // 漫画
  AppGlobal.novelWatchRecordBox =
      await Hive.openBox(AppConst.novelReadRecordBoxName); // 小说
  AppGlobal.initStorageBrowseHistory();

  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);

  // 注册图片加载线程
  DefaultDelegate<dynamic, dynamic> fooDelegate =
      const DefaultDelegate(callback: PlatformAwareCrypto.decryptImage);
  JsDelegate fooJsDelegate = const JsDelegate(callback: 'decryptImage');
  List<WorkerDelegate<dynamic, dynamic>> wds = List.generate(
      5,
      (index) => WorkerDelegate(
            key: 'decryptImage$index',
            defaultDelegate: fooDelegate,
            jsDelegate: fooJsDelegate,
          ));
  WorkerDelegator().addAllDelegates(wds);
  await WorkerDelegator().importScripts(const <String>[
    'js/aware.js?v=2',
    'https://cdnjs.cloudflare.com/ajax/libs/crypto-js/4.1.1/crypto-js.min.js?v=2'
  ]);

  // 禁用图片缓存
  PaintingBinding.instance?.imageCache?.maximumSize = 0;
  PaintingBinding.instance?.imageCache?.maximumSizeBytes = 0;

  AppGlobal.apiToken = AppGlobal.appBox?.get('apiToken') ?? "";
  AppGlobal.firstVisitTime =
      AppGlobal.appBox?.get('firstVisitTime') ?? DateTime.now();
  AppGlobal.appBox?.put('firstVisitTime', DateTime.now());
  String tempOauthId =
      '${Method.randomId(32)}_${DateTime.now().millisecondsSinceEpoch.toString()}';
  LogUtil.i("tempOauthId--------->"+tempOauthId);
  AppGlobal.appinfo = {
    "oauth_id": AppGlobal.appBox?.get('oauth_id') ?? tempOauthId,
    "bundle_id": AppConst.bundleId,
    "version": AppConst.appVersion,
    "oauth_type": "web",
    "language": 'zh',
    "via": 'pwa',
  };
  if (!kIsWeb) {
    PackageInfo packageInfo = await PackageInfo.fromPlatform();
    DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
    if (Platform.isAndroid) {
      AndroidDeviceInfo androidInfo = await deviceInfo.androidInfo;
      AppGlobal.appinfo = {
        "oauth_id": androidInfo.androidId,
        "bundle_id": packageInfo.packageName,
        "version": packageInfo.version,
        "oauth_type": "android",
      };
    } else {
      IosDeviceInfo iosInfo = await deviceInfo.iosInfo;
      AppGlobal.appinfo = {
        "oauth_id": iosInfo.identifierForVendor,
        "bundle_id": packageInfo.packageName,
        "version": "2.0.0",
        "oauth_type": "ios",
      };
    }
  } else {
    AppGlobal.appBox?.put('oauth_id', AppGlobal.appinfo['oauth_id']);
  }

  BarUtil.setBarUi(color: Colors.transparent);

  runApp(MultiProvider(
    providers: [
      ChangeNotifierProvider(create: (_) => HomeData()),
      // 个人信息
      ChangeNotifierProvider(create: (_) => UserData()),
    ],
    child: const MyApp(),
  ));
}

class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  State<MyApp> createState() => _MyAppState();
}

final _router = AppGlobal.appRouter = Routes.init();

class _MyAppState extends State<MyApp> {
  @override
  Widget build(BuildContext context) {
    final botToastBuilder = BotToastInit();
    if (!kIsWeb && Platform.isIOS) {
      SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle.light);
    }
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      builder: (context, child) => ScreenUtilInit(
          designSize: const Size(375, 667),
          builder: (context, child) => MaterialApp.router(
                routeInformationParser: _router.routeInformationParser,
                routerDelegate: _router.routerDelegate,
                builder: (context, widget) {
                  widget = botToastBuilder(context, widget);
                  widget = MediaQuery(
                    //设置文字大小不随系统设置改变
                    data: MediaQuery.of(context).copyWith(textScaleFactor: 1.0),
                    child: widget,
                  );
                  return widget;
                },
                debugShowCheckedModeBanner: false,
                theme: ThemeData(
                  primarySwatch: Colors.purple,
                  splashColor: Colors.transparent,
                  highlightColor: Colors.transparent,
                ),
                color: Colors.transparent,
                title: StringRes.str_app_name,
              )),
    )

        //   ScreenUtilInit(
        //   designSize: const Size(375, 667),
        //   minTextAdapt: true,
        //   splitScreenMode: true,
        //   builder: (context, child) {
        //     return MaterialApp.router(
        //       routeInformationParser: _router.routeInformationParser,
        //       routerDelegate: _router.routerDelegate,
        //       builder: (context, widget) {
        //         widget = botToastBuilder(context, widget);
        //         widget = MediaQuery(
        //           //设置文字大小不随系统设置改变
        //           data: MediaQuery.of(context).copyWith(textScaleFactor: 1.0),
        //           child: widget,
        //         );
        //         return widget;
        //       },
        //       debugShowCheckedModeBanner: false,
        //       theme: ThemeData(
        //         primarySwatch: Colors.purple,
        //         textTheme: Typography.englishLike2018.apply(fontSizeFactor: 1.sp),
        //         splashColor: Colors.transparent,
        //         highlightColor: Colors.transparent,
        //       ),
        //       color: Colors.transparent,
        //       title: StringRes.str_app_name,
        //     );
        //   },
        // )
        ;
  }
}
