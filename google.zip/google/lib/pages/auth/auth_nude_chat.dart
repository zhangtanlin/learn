import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:iaimei/router/routers.dart';
import 'package:iaimei/widget/buttom_widget.dart';
import 'package:iaimei/widget/convenient_mixin.dart';

class AuthNudeChat extends StatefulWidget {
  const AuthNudeChat({Key? key}) : super(key: key);

  @override
  State<AuthNudeChat> createState() => _AuthNudeChatState();
}

class _AuthNudeChatState extends State<AuthNudeChat> with ConvenientMixin {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(top: 80.w),
      child: Column(
        children: [
          Text(
            '官方裸聊招募妹妹啦～\n可露脸可不露脸～\n有补助，送订单赚钱快来吧～',
            style: TextStyle(fontSize: 13.sp, color: color_84, height: 1.5),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 49.w),
          ButtonWidget.build('联系官方',
              onTap: (() => context.push('/${Routes.contact}'))),
        ],
      ),
    );
  }
}
