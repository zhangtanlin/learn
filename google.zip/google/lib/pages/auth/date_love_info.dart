import 'package:bot_toast/bot_toast.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_picker/Picker.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:iaimei/components/citypicker/city_picker_page.dart';
import 'package:iaimei/components/common/commonelements.dart';
import 'package:iaimei/model/dating_city_model.dart';
import 'package:iaimei/net/http_helper.dart';
import 'package:iaimei/pages/auth/date_love_list.dart';
import 'package:iaimei/pages/creator/upload_picker_mixin.dart';
import 'package:iaimei/router/routers.dart';
import 'package:iaimei/utils/common.dart';
import 'package:iaimei/widget/buttom_widget.dart';
import 'package:iaimei/widget/convenient_mixin.dart';

class DateLoveInfo extends StatefulWidget {
  const DateLoveInfo({Key? key, this.origin = 1}) : super(key: key);
  final int origin; // 0 经纪人(第一版经纪人无发布) 1 个人
  @override
  State<DateLoveInfo> createState() => _DateLoveInfoState();
}

class _DateLoveInfoState extends State<DateLoveInfo>
    with ConvenientMixin, UploadPickerMixin {
  //
  final nickVc = TextEditingController();
  String age = '';
  String cup = '';
  String height = '';
  CityItemModel? city;
  final addrVc = TextEditingController();
  List<String> pricing = [];
  String selectedCls = '';
  List<String> service = [];
  List<String> feature = [];
  final descVc = TextEditingController();

  /* ********************************* */
  List<String> tempService = [];
  List<String> tempFeature = [];
  final onePVc = TextEditingController();
  final twoPVc = TextEditingController();
  final allPVc = TextEditingController();
  /* ********************************* */

  int maxVideo = 1;
  int maxImage = 5;
  int isPublish = 0; // 初始状态
  Map<String, dynamic> json = {};
  bool isLoading = true;
  bool isError = false;
  void initLoadingData() {
    HttpHelper.dateLoveInfo((data) {
      json = data;
      maxVideo = json['max_video'] ?? 1;
      maxImage = json['max_image'] ?? 5;
      isPublish = json['person_release'] ?? 0;
      isLoading = false;
      isError = false;
      setState(() {});
    }, (error) {
      isError = true;
      isLoading = false;
      debugPrint(error.toString());
    });
  }

  @override
  void initState() {
    super.initState();
    initLoadingData();

    actionSize = Size(104.w, 104.w);
    commonInitUploadCallback();
  }

  // 失去焦点
  void onDismissfocus() {
    FocusScope.of(context).requestFocus(FocusNode());
  }

  @override
  void onUploadAction(bool isVideo) {
    onDismissfocus(); // 失去焦点
    if (isVideo && videoPathMap.isNotEmpty) {
      Method.showText('最多可上传 $maxVideo 视频');
      return;
    }
    if (isVideo == false && imagePathMap.length >= maxImage) {
      Method.showText('最多可上传 $maxImage 图片');
      return;
    }
    uploadIndex += 1;
    isVideo ? showVideoAssets() : showImageAssets();
  }

  void onSubmitDateInfo() {
    if (imagePathMap.values.isEmpty) {
      Method.showText('请上传封面');
      return;
    }
    // if (videoPathMap.values.isEmpty) {
    //   Method.showText('请上传视频');
    //   return;
    // }

    if (nickVc.text.isEmpty || nickVc.text.length > 8) {
      Method.showText('请输入昵称，最多8个中文字符');
      return;
    }
    if (age.isEmpty) {
      Method.showText('请选择年龄');
      return;
    }
    if (cup.isEmpty) {
      Method.showText('请选择罩杯');
      return;
    }
    if (height.isEmpty) {
      Method.showText('请选择身高');
      return;
    }
    if (city == null) {
      Method.showText('请输入您的地点');
      return;
    }
    if (pricing.isEmpty || pricing.length != 3) {
      Method.showText('请设置完整的价格');
      return;
    }
    if (widget.origin == 0 && selectedCls.isEmpty) {
      Method.showText('请选择类型');
      return;
    }
    if (service.isEmpty) {
      Method.showText('请选择3个服务项目');
      return;
    }
    if (feature.isEmpty) {
      Method.showText('请选择特征');
      return;
    }

    var param = {
      'girl_pics': imagePathMap.values.map((e) => e['url']).join(','),
      'videos': videoPathMap.values.join(','),
      'title': nickVc.text,
      'girl_age': age,
      'girl_cup': cup,
      'girl_height': height,
      'city_code': city?.id,
      'city_name': city?.areaname,
      'girl_price': pricing
          .asMap()
          .keys
          .map((i) => i != 2 ? '${i + 1}P${pricing[i]}' : '包夜${pricing[i]}')
          .join('、'),
      'type': selectedCls,
      'girl_service_type': service.join(','),
      'girl_tags': feature.join(','),
      'desc': descVc.text,
      'origin': widget.origin, // 0-经纪人发布 1-个人
    };
    BotToast.showLoading();
    HttpHelper.submitDateLoveInfo(param, (data) {
      BotToast.closeAllLoading();
      debugPrint(data.toString());
      Method.showText(data);
      imagePathMap = {};
      videoPathMap = {};
      localImageMap = {};
      nickVc.text = '';
      age = '';
      cup = '';
      height = '';
      city = null;
      pricing = [];
      selectedCls = '';
      service = [];
      feature = [];
      descVc.text = '';
      setState(() {}); //
    }, (error) {
      Method.showText(error.message ?? '');
      debugPrint(error.toString());
    });
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) return loadingWiget();
    if (isError) return errorWidget();
    return isPublish != 1
        ? _buildPublishWidget()
        : const DateLoveHistory(type: 0, origin: 1);
  }

  Widget _buildPublishWidget() {
    return SingleChildScrollView(
      child: GestureDetector(
        behavior: HitTestBehavior.translucent,
        onTap: () => onDismissfocus(),
        child: Column(
          children: [
            SizedBox(height: 10.w),
            _buildUploadsWidget(),
            SizedBox(height: 15.w),
            _buildRowItemWidget('昵称：', _buildInputWidget(nickVc, '请输入您的昵称')),
            SizedBox(height: 15.w),
            _buildRowPushWidget(1), // 年龄
            SizedBox(height: 15.w),
            _buildRowPushWidget(2), // 罩杯
            SizedBox(height: 15.w),
            _buildRowPushWidget(3), // 身高
            SizedBox(height: 15.w),
            _buildRowPushWidget(7), // 城市
            SizedBox(height: 15.w),
            _buildRowPushWidget(4), // 价格
            Offstage(
              offstage: widget.origin == 1,
              child: SizedBox(height: 15.w),
            ),
            Offstage(
              offstage: widget.origin == 1,
              child: _buildRowItemWidget('类型：', _buildClassWidget()),
            ),
            SizedBox(height: 15.w),
            _buildRowPushWidget(5), // 服务项目
            SizedBox(height: 15.w),
            _buildRowPushWidget(6), // 特征
            SizedBox(height: 15.w),
            _buildRowDescWidget(),
            SizedBox(height: 50.w),
            ButtonWidget.build('提交', onTap: onSubmitDateInfo),
            ButtonWidget.transparent(
                text: '联系官方',
                color: rColor,
                onTap: () => context.push('/${Routes.contact}')),
            _buildCheckInWidget(),
            SizedBox(height: 20.w),
          ],
        ),
      ),
    );
  }

  List<Widget> _buildActionWidget() {
    List<Widget> list = [];
    if (videoPathMap.length < maxVideo) {
      list.add(uploadActionWidget(84.w, 84.w, true));
    }
    if (imagePathMap.length < maxImage) {
      list.add(uploadActionWidget(84.w, 84.w, false));
    }
    return list;
  }

  Widget _buildUploadsWidget() {
    return Container(
      padding: EdgeInsets.fromLTRB(16.w, 0, 16.w, 5.w),
      child: Align(
        alignment: Alignment.topLeft,
        child: Wrap(
          spacing: 15.w,
          runSpacing: 15.w,
          children: [
            ...localImageMap.values
                .map((data) => buildContainerWidget(
                    width: 104.w,
                    height: 104.w,
                    child: imageMemoryWidget(data)))
                .toList(),
            ..._buildActionWidget(),
          ],
        ),
      ),
    );
  }

  Widget _buildRowItemWidget(title, Widget rightWidget) {
    var padding = EdgeInsets.only(left: 10.w);
    return buildContainerWidget(
      padding: padding,
      // margin: EdgeInsets.only(top: 15.w),
      width: 343.w,
      height: 44.w,
      child: Row(
        children: [
          Text('$title', style: TextStyle(color: wColor, fontSize: 15.sp)),
          rightWidget,
        ],
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
      ),
    );
  }

  Widget _buildRowDescWidget() {
    return buildContainerWidget(
      padding: EdgeInsets.all(10.w),
      height: 120.w,
      width: 343.w,
      child: Container(
        alignment: Alignment.topCenter,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.all(Radius.circular(6.w)),
          color: const Color(0x1f000000),
        ),
        child: TextField(
          textAlignVertical: TextAlignVertical.center,
          controller: descVc,
          cursorColor: color_84,
          maxLines: 5,
          cursorHeight: 15.w,
          textInputAction: TextInputAction.done,
          style: TextStyle(color: color_84, fontSize: 13.sp),
          decoration: InputDecoration(
            hintText: '自我描述，如特征、优势',
            hintStyle: TextStyle(color: color_64, fontSize: 13.sp),
            border: InputBorder.none,
            contentPadding: EdgeInsets.all(8.w),
          ),
        ),
      ),
    );
  }

  Widget _buildInputWidget(TextEditingController controller, String hintText) {
    return Expanded(
      child: TextField(
        textAlign: TextAlign.end,
        controller: controller,
        cursorColor: color_84,
        maxLines: 1,
        cursorHeight: 15.w,
        style: TextStyle(color: color_84, fontSize: 13.sp),
        decoration: InputDecoration(
          hintText: hintText,
          hintStyle: TextStyle(color: color_64, fontSize: 13.sp),
          border: InputBorder.none,
          contentPadding: EdgeInsets.symmetric(horizontal: 10.w),
        ),
      ),
    );
  }

  Widget _buildClassWidget() {
    if (json.isEmpty) return Container();
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 5.w),
      height: 28.w,
      margin: EdgeInsets.only(right: 10.w),
      decoration: BoxDecoration(
          color: Colors.black.withOpacity(0.24),
          borderRadius: BorderRadius.circular(14.sp)),
      clipBehavior: Clip.hardEdge,
      child: Row(
        children: (json['type'] as Map)
            .entries
            .toList()
            .map((item) => GestureDetector(
                onTap: () => setState(() => selectedCls = item.key),
                child: Padding(
                  padding: EdgeInsets.symmetric(horizontal: 5.w),
                  child: Text(
                    item.value ?? '',
                    style: TextStyle(
                      color: item.key == selectedCls ? rColor : color_54,
                      fontSize: 13.sp,
                    ),
                  ),
                )))
            .toList(),
      ),
    );
  }

  Widget _buildColetWidget(List<dynamic> tags) {
    var style = TextStyle(color: color_84, fontSize: 13.sp);
    return Text.rich(
      TextSpan(
        children: tags
            .map((item) => WidgetSpan(
                  child: Padding(
                    padding: EdgeInsets.only(left: 10.w),
                    child: Text(item, style: style),
                  ),
                ))
            .toList(),
      ),
      maxLines: 1,
      overflow: TextOverflow.ellipsis,
    );
  }

  // type：1-年龄，2-罩杯，3-身高，4-价格，5-服务，6-特征
  Widget _buildRowPushWidget(int type) {
    bool offstage = false;
    String title = '';
    List<dynamic> tags = [];
    Widget content(int type) {
      switch (type) {
        case 1:
          title = '年龄';
          tags = json['age'] ?? [];
          offstage = age.isNotEmpty;
          return Text(age, style: TextStyle(color: color_84, fontSize: 13.sp));
        case 2:
          title = '罩杯';
          tags = json['cup'] ?? [];
          offstage = cup.isNotEmpty;
          return Text(cup, style: TextStyle(color: color_84, fontSize: 13.sp));
        case 3:
          title = '身高';
          tags = json['height'] ?? [];
          offstage = height.isNotEmpty;
          var txt = height + (offstage ? 'cm' : '');
          return Text(txt, style: TextStyle(color: color_84, fontSize: 13.sp));
        case 4:
          title = '价格';
          offstage = pricing.isNotEmpty;
          var txt = pricing
              .asMap()
              .keys
              .map((i) => i != 2 ? '${i + 1}P${pricing[i]}' : '包夜${pricing[i]}')
              .join('、');
          return Text(txt, style: TextStyle(color: color_84, fontSize: 13.sp));
        case 5:
          title = '服务项目';
          tags = json['service'] ?? [];
          offstage = service.isNotEmpty;
          return _buildColetWidget(service);
        case 6: // 特征
          title = '特征';
          tags = json['tags'] ?? [];
          offstage = feature.isNotEmpty;
          return _buildColetWidget(feature);
        case 7: // 地址
          title = '地点';
          offstage = city != null;
          var txt = city?.areaname ?? '';
          return Text(txt, style: TextStyle(color: color_84, fontSize: 13.sp));
        default:
          return Container();
      }
    }

    var rWidget = Row(children: [
      content(type),
      Offstage(
        offstage: offstage,
        child: Image.asset('assets/images/upload/upload_push.png', scale: 2),
      ),
      SizedBox(width: 10.w),
    ]);

    return GestureDetector(
      behavior: HitTestBehavior.translucent,
      onTap: () {
        onDismissfocus(); // 失去焦点
        switch (type) {
          case 7:
            selectedCity();
            break;
          default:
            if (type == 5) tempService = [...service];
            if (type == 6) tempFeature = [...feature];
            showSelectedLabelSheet(type, title, tags);
        }
      },
      child: _buildRowItemWidget(title + '：', rWidget),
    );
  }

  void selectedCity() async {
    final CityItemModel? result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => const CityPickerPage(),
      ),
    );
    city = result;
    setState(() {});
  }

  Widget _buildCheckInWidget() {
    return Container(
      padding: EdgeInsets.fromLTRB(16.w, 18.w, 16.w, 20.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Text(
          //   '温馨提示：',
          //   style: TextStyle(fontSize: 16.sp, color: wColor, fontWeight: fontM),
          // ),
          ...(json['tips'] ?? '')
              .split('##')
              .map((str) => Padding(
                    padding: EdgeInsets.only(top: 11.w),
                    child: Text(
                      str,
                      style: TextStyle(color: color_64, fontSize: 12.sp),
                    ),
                  ))
              .toList(),
        ],
      ),
    );
  }

  /* present modal view */
  Widget _buildSubmitWidget([void Function()? onTap]) {
    var bottom =
        ScreenUtil().bottomBarHeight == 0 ? 20.w : ScreenUtil().bottomBarHeight;
    return Container(
      margin: EdgeInsets.only(top: 20.w, bottom: bottom),
      child: ButtonWidget.build('确定', onTap: () {
        onTap?.call();
        Navigator.of(context).pop();
      }),
    );
  }

  void showSelectedLabelSheet(int type, String title, List tags) {
    var bottom =
        ScreenUtil().bottomBarHeight == 0 ? 20.w : ScreenUtil().bottomBarHeight;
    var height = ([1, 2, 3].contains(type) ? 360.w : 330.w) + bottom;
    height = [5, 6].contains(type)
        ? 54.w + 45.w * (tags.length / 4).ceil() + 31.w + 70.w + bottom
        : height;
    height = height > ScreenUtil().screenHeight * 0.8
        ? ScreenUtil().screenHeight * 0.8
        : height;
    showModalBottomSheet(
      isScrollControlled: true,
      context: context,
      backgroundColor: Colors.transparent,
      builder: (builder) {
        return StatefulBuilder(builder: (cnt, sheetState) {
          return AnimatedPadding(
              padding: MediaQuery.of(builder).viewInsets,
              duration: const Duration(milliseconds: 0), // 100s
              child: Container(
                height: height,
                decoration: const BoxDecoration(
                  color: Color.fromRGBO(26, 21, 47, 1),
                  borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
                ),
                clipBehavior: Clip.hardEdge,
                child:
                    Column(mainAxisSize: MainAxisSize.min, children: <Widget>[
                  Container(
                    padding: EdgeInsets.only(top: 14.w),
                    height: 54.w,
                    color: const Color(0x15ffffff),
                    child: CustomHeader(lMargin: 16.w, title: title),
                  ),
                  Expanded(
                    child: [5, 6].contains(type)
                        ? _buildTagsWidget(type, tags, sheetState)
                        : (type == 4
                            ? _buildPriceWidget()
                            : _buildPickerWidget(type, tags)),
                  ),
                ]),
              ));
        });
      },
    );
  }

  Widget _buildPickerWidget(int type, List<dynamic> tags) {
    if (tags.isEmpty) return Container();
    var stateText = '${tags.first}';
    return Column(
      children: [
        Picker(
          looping: true,
          hideHeader: true,
          itemExtent: 44.w,
          height: 230.w,
          backgroundColor: Colors.transparent,
          containerColor: Colors.transparent,
          textStyle:
              TextStyle(color: color_54, fontSize: 15.sp, fontWeight: fontM),
          selectedTextStyle: TextStyle(color: wColor),
          adapter: PickerDataAdapter(pickerdata: tags),
          selectionOverlay: Container(
            margin: EdgeInsets.symmetric(horizontal: 16.w),
            width: 343.w,
            height: 44.w,
            padding: EdgeInsets.only(left: type == 1 ? 60.w : 80.w),
            decoration: BoxDecoration(
                color: const Color(0x14ffffff),
                borderRadius: BorderRadius.circular(22.w)),
            child: Center(
              child: Text(
                type == 1 ? '岁' : (type == 2 ? '罩杯' : 'cm'),
                style: TextStyle(color: wColor, fontSize: 15.sp),
              ),
            ),
          ),
          onSelect: (Picker picker, int index, List<int> selected) {
            stateText = '${picker.adapter.getSelectedValues().first}';
          },
        ).makePicker(),
        _buildSubmitWidget(() {
          type == 1
              ? age = stateText
              : (type == 2 ? cup = stateText : height = stateText);
          setState(() {});
        }),
      ],
    );
  }

  Widget _buildPriceWidget() {
    Widget rowWidget(String text, TextEditingController controller) {
      return Container(
        padding: EdgeInsets.only(left: 20.w, right: 10.w),
        margin: EdgeInsets.symmetric(horizontal: 16.w),
        width: 343.w,
        height: 44.w,
        decoration: BoxDecoration(
            color: const Color(0x14ffffff),
            borderRadius: BorderRadius.circular(22.w)),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(text, style: TextStyle(color: wColor, fontSize: 15.sp)),
            SizedBox(
              width: 77.w,
              child: Stack(alignment: AlignmentDirectional.center, children: [
                Container(
                  margin: EdgeInsets.symmetric(vertical: 8.w),
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(14.w),
                    color: Colors.black.withOpacity(0.24),
                  ),
                ),
                TextField(
                  textAlign: TextAlign.center,
                  controller: controller,
                  keyboardType: TextInputType.number,
                  maxLines: 1,
                  style: TextStyle(color: rColor, fontSize: 13.sp),
                  decoration: InputDecoration(
                    hintText: '0',
                    hintStyle: TextStyle(color: color_64, fontSize: 13.sp),
                    border: InputBorder.none,
                    contentPadding: EdgeInsets.symmetric(horizontal: 10.w),
                  ),
                ),
              ]),
            ),
          ],
        ),
      );
    }

    onePVc.text = pricing.isNotEmpty ? pricing[0] : '';
    twoPVc.text = pricing.length > 1 ? pricing[1] : '';
    allPVc.text = pricing.length > 2 ? pricing[2] : '';

    return GestureDetector(
      behavior: HitTestBehavior.translucent,
      onTap: onDismissfocus,
      child: Column(children: [
        SizedBox(height: 20.w),
        rowWidget('1P价格：', onePVc),
        SizedBox(height: 15.w),
        rowWidget('2P价格：', twoPVc),
        SizedBox(height: 15.w),
        rowWidget('包夜价格：', allPVc),
        SizedBox(height: 20.w),
        _buildSubmitWidget(() {
          if (onePVc.text.isEmpty) {
            Method.showText('请输入1P价格');
            return;
          }
          if (twoPVc.text.isEmpty) {
            Method.showText('请输入2P价格');
            return;
          }
          if (allPVc.text.isEmpty) {
            Method.showText('请输入包夜价格');
            return;
          }
          pricing = [onePVc.text, twoPVc.text, allPVc.text];
          setState(() {});
        }),
      ]),
    );
  }

  Widget _buildTagsWidget(int type, List tags, StateSetter sheetState) {
    var selectedTags = type == 5 ? tempService : tempFeature;
    return Column(mainAxisSize: MainAxisSize.min, children: [
      Expanded(
        child: SingleChildScrollView(
          child: GridView.builder(
            padding: EdgeInsets.fromLTRB(16.w, 20.w, 16.w, 20.w),
            itemCount: tags.length,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 4,
              childAspectRatio: 79 / 36,
              mainAxisSpacing: 9.w,
              mainAxisExtent: 36.w,
              crossAxisSpacing: 9.w,
            ),
            itemBuilder: (ctx, index) {
              var isSelected = selectedTags.contains(tags[index]);
              var path =
                  'assets/images/upload/upload_tag_${isSelected ? 'sel' : 'nor'}.png';
              return GestureDetector(
                onTap: () {
                  if (selectedTags.contains(tags[index])) {
                    selectedTags.remove(tags[index]);
                  } else {
                    selectedTags.add(tags[index]);
                  }
                  sheetState(() {});
                },
                child: _buildTagWidget(tags[index], path),
              );
            },
          ),
        ),
      ),
      _buildSubmitWidget(() {
        if (selectedTags.length > 3) {
          Method.showText('${type == 5 ? '服务项目' : '特征'}最多选3项');
          return;
        }
        if (selectedTags.isEmpty) {
          Method.showText('请选择${type == 5 ? '服务项目' : '特征'}');
          return;
        }
        type == 5 ? service = selectedTags : feature = selectedTags;
        setState(() {});
      }),
    ]
        // ),
        );
  }

  Widget _buildTagWidget(String tag, String bgPath) {
    return Container(
      height: 36.w,
      width: 79.w,
      child: Center(
        child: Text(
          tag,
          style: TextStyle(color: wColor, fontSize: 13.sp, fontWeight: fontM),
        ),
      ),
      decoration: BoxDecoration(
        image: DecorationImage(image: AssetImage(bgPath)),
      ),
    );
  }
}
