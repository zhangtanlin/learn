import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:iaimei/model/auth_pre_model.dart';
import 'package:iaimei/net/http_helper.dart';
import 'package:iaimei/pages/creator/upload_picker_mixin.dart';
import 'package:iaimei/router/routers.dart';
import 'package:iaimei/utils/common.dart';
import 'package:iaimei/widget/buttom_widget.dart';
import 'package:iaimei/widget/convenient_mixin.dart';

class AuthDateLove extends StatefulWidget {
  const AuthDateLove({
    Key? key,
    this.type = 1,
    this.hasApply = true,
    this.callback,
  }) : super(key: key);

  final int type; // 0 经纪人 1 个人
  final bool hasApply;
  final void Function(bool)? callback;

  @override
  State<AuthDateLove> createState() => _AuthDateLoveState();
}

class _AuthDateLoveState extends State<AuthDateLove>
    with ConvenientMixin, UploadPickerMixin {
  bool numberStatus = true;
  bool wechatStatus = true;
  late TextEditingController numberVc;
  late TextEditingController wechatVc;

  @override
  void initState() {
    super.initState();
    hasApply = widget.hasApply;
    initLoadingData();
    numberVc = TextEditingController();
    wechatVc = TextEditingController();

    actionSize = Size(104.w, 104.w);
    commonInitUploadCallback();

    numberVc.addListener(() {
      numberStatus = numberVc.text.isEmpty;
      setState(() {});
    });
    wechatVc.addListener(() {
      wechatStatus = wechatVc.text.isEmpty;
      setState(() {});
    });
  }

  @override
  void didUpdateWidget(covariant AuthDateLove oldWidget) {
    super.didUpdateWidget(oldWidget);
    hasApply = widget.hasApply;
    setState(() {});
  }

  @override
  void activate() {
    super.activate();
    debugPrint('-----------> ${widget.hasApply}');
  }

  // 失去焦点
  void onDismissfocus() {
    FocusScope.of(context).requestFocus(FocusNode());
  }

  @override
  void onUploadAction(bool isVideo) {
    onDismissfocus(); // 失去焦点
    if (widget.type == 0 && preModel.coins < (preModel.bail ?? 0)) {
      Method.showText('余额不足, 请先充值');
      return;
    }
    if (isVideo && videoPathMap.length >= preModel.maxVideo) {
      Method.showText('视频最多可上传 ${preModel.maxVideo}');
      return;
    }
    if (isVideo == false && imagePathMap.length >= preModel.maxImage) {
      Method.showText('图片最多可上传 ${preModel.maxImage}');
      return;
    }
    uploadIndex += 1;
    isVideo ? showVideoAssets() : showImageAssets();
  }

  bool hasApply = true;
  bool isLoaded = false;
  AuthPreModel preModel = AuthPreModel();
  void initLoadingData() {
    HttpHelper.preVerify({'origin': widget.type}, (data) {
      try {
        var json = data[widget.type == 0 ? 'team' : 'personal'];
        preModel = AuthPreModel.fromJsom(json);
        hasApply = data['has_apply'] ?? true;
        widget.callback?.call(hasApply);
        isLoaded = true;
        setState(() {});
      } catch (err) {
        debugPrint(err.toString());
      }
    }, (error) {
      debugPrint(error.message);
      Method.showText(error.message ?? '');
    });
  }

  void onSubmitDateLoveAuth() {
    if (imagePathMap.values.isEmpty) {
      Method.showText('请上传封面');
      return;
    }

    // if (videoPathMap.values.isEmpty) {
    //   Method.showText('请上传视频');
    //   return;
    // }

    if (numberVc.text.isEmpty) {
      Method.showText('请输入手机号');
      return;
    }

    if (wechatVc.text.isEmpty) {
      Method.showText('请输入微信号');
      return;
    }

    var param = {
      'type': widget.type == 0 ? 21 : 20,
      'phone': numberVc.text,
      'contact': wechatVc.text,
      'coins': preModel.bail,
      'images': imagePathMap.values.map((e) => e['url']).toList().join(','),
      'videos': videoPathMap.isNotEmpty ? videoPathMap.values.join(',') : '',
    };

    if (widget.type == 1) {
      param['verify_code'] = preModel.verifyCode;
    }

    HttpHelper.submitDateLoveAuth(param, (data) {
      Method.showText('$data');
      hasApply = true;
      widget.callback?.call(true);
      setState(() {});
    }, (error) {
      debugPrint(error.message);
      Method.showText(error.message ?? '');
    });
  }

  @override
  Widget build(BuildContext context) {
    if (isLoaded == false) {
      return loadingWiget();
    }
    if (hasApply) {
      return Center(
        child: Text(
          "认证信息已提交，审核中…",
          style: TextStyle(color: wColor, fontSize: 13.sp),
        ),
      );
    }
    return SingleChildScrollView(
      child: GestureDetector(
        behavior: HitTestBehavior.translucent,
        onTap: onDismissfocus,
        child: Column(
          children: [
            _buildUploadsWidget(),
            _buildDescriptionWidget(preModel.upload),

            ///
            _buildContactWidget(),
            _buildDescriptionWidget(preModel.contact),
            Offstage(
              offstage: widget.type == 1,
              child: _buildDepositWidget(),
            ),
            _buildCheckInWidget(),
            SizedBox(height: 50.w),
            ButtonWidget.build('${widget.type == 0 ? '支付并' : ''}提交',
                onTap: onSubmitDateLoveAuth),
            ButtonWidget.transparent(
                text: '联系官方',
                color: rColor,
                onTap: () => context.push('/${Routes.contact}')),
            SizedBox(height: 20.w),
          ],
        ),
      ),
    );
  }

  List<Widget> _buildActionWidget() {
    List<Widget> list = [];
    if (videoPathMap.length < preModel.maxVideo) {
      list.add(uploadActionWidget(84.w, 84.w, true));
    }
    if (imagePathMap.length < preModel.maxImage) {
      list.add(uploadActionWidget(84.w, 84.w, false));
    }
    return list;
  }

  Widget _buildUploadsWidget() {
    return Container(
      margin: EdgeInsets.only(top: 10.w),
      padding: EdgeInsets.symmetric(horizontal: 16.w),
      child: Align(
        alignment: Alignment.topLeft,
        child: Wrap(
          spacing: 15.w,
          runSpacing: 15.w,
          children: [
            ...localImageMap.values
                .map((data) => buildContainerWidget(
                      width: 104.w,
                      height: 104.w,
                      child: imageMemoryWidget(data),
                    ))
                .toList(),
            ..._buildActionWidget(),
            // imagePathMap.length < preModel.maxImage
            //     ? uploadActionWidget(84.w, 84.w, false)
            //     : const SizedBox(),
            // videoPathMap.length < preModel.maxVideo
            //     ? uploadActionWidget(84.w, 84.w, true)
            //     : const SizedBox(),
          ],
        ),
      ),
    );
  }

  Widget _buildInputWidget(
      TextEditingController controller, bool status, String hintText) {
    return Container(
      alignment: Alignment.center,
      decoration: BoxDecoration(
        border: Border(
          bottom: BorderSide(width: 0.5, color: Colors.white.withOpacity(0.2)),
        ),
      ),
      height: 33.w,
      child: TextField(
        textAlign: TextAlign.center,
        maxLines: 1,
        cursorColor: wColor,
        controller: controller,
        style: TextStyle(color: wColor, fontSize: 13.sp),
        decoration: InputDecoration(
          contentPadding: EdgeInsets.fromLTRB(10.w, 5.w, 10.w, 0),
          hintText: hintText,
          hintStyle: TextStyle(color: color_64, fontSize: 13.sp),
          suffixIcon: Offstage(
            offstage: status,
            child: Padding(
              padding: EdgeInsets.all(7.w),
              child: GestureDetector(
                onTap: () => controller.clear(),
                child: Image.asset(
                  'assets/images/income/income_close.png',
                  scale: 2,
                ),
              ),
            ),
          ),
          border: InputBorder.none
        ),
      ),
    );
  }

  Widget _buildContactWidget() {
    return buildContainerWidget(
      width: 343.w,
      height: 80.w,
      margin: EdgeInsets.only(top: 20.w),
      padding: EdgeInsets.symmetric(horizontal: 10.w),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.only(top: 12.w),
            child: Text(
              '联系方式：',
              style: TextStyle(fontSize: 15.sp, color: wColor),
            ),
          ),
          Expanded(
            child: Column(
              children: [
                SizedBox(height: 3.w),
                _buildInputWidget(numberVc, numberStatus, '请输入手机号码'),
                _buildInputWidget(wechatVc, wechatStatus, '请输入微信号'),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDescriptionWidget(String desc) {
    return Container(
      margin: EdgeInsets.only(top: 10.w),
      width: 343.w,
      child: Text(
        desc,
        style: TextStyle(color: color_54, fontSize: 12.sp),
      ),
    );
  }

  Widget _buildDepositWidget() {
    return buildContainerWidget(
      margin: EdgeInsets.only(top: 20.w),
      width: 343.w,
      height: 44.w,
      padding: EdgeInsets.symmetric(horizontal: 10.w),
      child: Row(
        children: [
          Text('保证金：', style: TextStyle(fontSize: 15.sp, color: wColor)),
          Expanded(
            child: Center(
              child: Text(
                '¥ ${preModel.bail}',
                style: TextStyle(
                    fontSize: 13.sp, color: rColor, fontWeight: fontB),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCheckInWidget() {
    return Container(
      width: double.infinity,
      margin: EdgeInsets.only(top: 30.w),
      padding: EdgeInsets.fromLTRB(16.w, 18.w, 16.w, 20.w),
      color: const Color(0x3d000000),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '温馨提示：',
            style: TextStyle(fontSize: 16.sp, color: wColor, fontWeight: fontM),
          ),
          ...preModel.tips
              .split('##')
              .map(
                (str) => Padding(
                  padding: EdgeInsets.only(top: 11.w),
                  child: Text(
                    str,
                    style: TextStyle(color: color_64, fontSize: 12.sp),
                  ),
                ),
              )
              .toList(),
        ],
      ),
    );
  }
}
