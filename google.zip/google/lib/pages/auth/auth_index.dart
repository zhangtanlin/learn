import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:iaimei/components/common/commonelements.dart';
import 'package:iaimei/components/common/pageviewmixin.dart';
import 'package:iaimei/components/common/stackpage.dart';
import 'package:iaimei/pages/auth/auth_date_love.dart';
import 'package:iaimei/pages/auth/auth_nude_chat.dart';
import 'package:iaimei/pages/auth/date_love_info.dart';
import 'package:iaimei/pages/auth/date_love_list.dart';
import 'package:iaimei/pages/mv/nav_tab_bar_mixin.dart';
import 'package:iaimei/store/userdata.dart';
import 'package:iaimei/widget/convenient_mixin.dart';
import 'package:iaimei/widget/tab_bar_view_ext.dart';
import 'package:provider/provider.dart';

import '../../model/user_info_model.dart';

class AuthIndex extends StatefulWidget {
  const AuthIndex({Key? key}) : super(key: key);

  @override
  State<AuthIndex> createState() => _AuthIndexState();
}

class _AuthIndexState extends State<AuthIndex>
    with TickerProviderStateMixin, ConvenientMixin {
  late UserInfoModel? user;
  int selectedIndex = 0;
  late TabController tabController;
  List<String> items = ['经纪人', '个人', '裸聊'];

  @override
  void initState() {
    super.initState();
    user = Provider.of<UserData>(context, listen: false).userInfo;
    tabController = TabController(
      length: items.length,
      vsync: this,
      initialIndex: selectedIndex,
    );

    tabController.addListener(() {
      setState(() => selectedIndex = tabController.index);
    });
    //
    callbackAction = (isTrue) {
      hasApply = isTrue;
      setState(() {}); //
    };
  }

  @override
  void dispose() {
    tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return StackPage(
      header: CustomHeader(
        titleWidget: Center(child: _buildTabBarWidget()),
        rListWidget: [
          Container(
            width: 42.w,
          )
        ],
      ),
      child: _buildTabBarViewWidget(),
    );
  }

  Widget _buildTabBarWidget() {
    return NavTabBarWidget(
      tabVc: tabController,
      tabs: items,
      textPadding: EdgeInsets.symmetric(horizontal: 15.w),
      norTextStyle: TextStyle(
          color: wColor, fontSize: 14.sp, fontWeight: FontWeight.w400),
      selTextStyle:
          TextStyle(color: rColor, fontSize: 18.sp, fontWeight: fontM),
      selectedIndex: selectedIndex,
    );
  }

  bool hasApply = true;
  void Function(bool)? callbackAction;
  Widget _buildTabBarViewWidget() {
    var borker = user?.maker != null && user?.maker['is_jjren'] == 1;
    var person = user?.maker != null && user?.maker['is_lfeng'] == 1;
    return TabBarViewExt(
      controller: tabController,
      children: items.asMap().keys.map<Widget>((index) {
        switch (index) {
          case 0:
            return PageViewMixin(
                child: borker == false
                    ? AuthDateLove(
                        type: 0, hasApply: hasApply, callback: callbackAction)
                    : const DateLoveList(origin: 0));
          case 1:
            return PageViewMixin(
                child: person == false
                    ? AuthDateLove(
                        type: 1, hasApply: hasApply, callback: callbackAction)
                    : const DateLoveInfo(origin: 1));
          default:
            return PageViewMixin(child: const AuthNudeChat());
        }
      }).toList(),
    );
  }
}
