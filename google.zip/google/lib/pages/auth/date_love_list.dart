import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:iaimei/components/common/pageviewmixin.dart';
import 'package:iaimei/components/common/pullrefreshlist.dart';
import 'package:iaimei/model/dating_girl_info_model.dart';
import 'package:iaimei/net/http_helper.dart';
import 'package:iaimei/pages/auth/date_love_info.dart';
import 'package:iaimei/pages/mv/nav_tab_bar_mixin.dart';
import 'package:iaimei/utils/common.dart';
import 'package:iaimei/widget/buttom_widget.dart';
import 'package:iaimei/widget/convenient_mixin.dart';
import 'package:iaimei/widget/network_img_container.dart';
import 'package:iaimei/widget/state_mixin.dart';
import 'package:iaimei/widget/tab_bar_view_ext.dart';

class DateLoveList extends StatefulWidget {
  const DateLoveList({Key? key, this.origin = 1}) : super(key: key);
  final int origin; // 0 经纪人 1 个人
  @override
  State<DateLoveList> createState() => _DateLoveListState();
}

class _DateLoveListState extends State<DateLoveList>
    with TickerProviderStateMixin, ConvenientMixin {
  int selectedIndex = 0;
  late TabController tabController;
  List<String> items = [
    '已通过',
    '未通过', /*'发布'*/
  ];

  @override
  void initState() {
    super.initState();
    tabController = TabController(length: items.length, vsync: this);
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildTabBarWidget(),
        Expanded(child: _buildTabBarViewWidget())
      ],
    );
  }

  Widget _buildTabBarWidget() {
    return NavTabBarWidget(
      tabVc: tabController,
      tabs: items,
      textPadding: EdgeInsets.symmetric(horizontal: 16.w),
      norTextStyle: TextStyle(
          color: wColor, fontSize: 14.sp, fontWeight: FontWeight.w400),
      selTextStyle:
          TextStyle(color: rColor, fontSize: 14.sp, fontWeight: fontM),
    );
  }

  Widget _buildTabBarViewWidget() {
    return TabBarViewExt(
      controller: tabController,
      children: items.asMap().keys.map<Widget>((index) {
        switch (index) {
          case 0:
            return PageViewMixin(
                child: DateLoveHistory(type: index, origin: widget.origin));
          case 1:
            return PageViewMixin(
                child: DateLoveHistory(type: index, origin: widget.origin));
          default:
            return PageViewMixin(child: DateLoveInfo(origin: widget.origin));
        }
      }).toList(),
    );
  }
}

class DateLoveHistory extends StatefulWidget {
  const DateLoveHistory({Key? key, this.type = 0, this.origin = 1})
      : super(key: key);
  final int type;
  final int origin; // 0 经纪人 1 个人
  @override
  State<DateLoveHistory> createState() => _DateLoveHistoryState();
}

class _DateLoveHistoryState extends State<DateLoveHistory>
    with ConvenientMixin, StateMixin {
  @override
  Widget noDataWidget() {
    if (widget.origin == 1) {
      return buildDataWidget(
        top: 150.w,
        content: '信息审核中, 请耐心等待...',
        tipHidden: true,
      );
    } else {
      return buildDataWidget(
        icon: 'assets/images/common/ic_load_error.png',
        content: '暂无数据',
        tipHidden: true,
      );
    }
  }

  @override
  void initLoadingData() {
    var param = this.param;
    param['type'] = widget.type == 0 ? 'pass' : 'reject';
    param['origin'] = widget.origin;
    HttpHelper.dateLoveList(param, (data) {
      var list = [];
      try {
        list = (data['list'] as List)
            .map((item) => DatingGirlInfoModel.fromJson(item))
            .toList();
      } catch (err) {
        debugPrint(err.toString());
      }
      updateListAndWidgetState(list);
    }, dealWithErrorsWidgetState);
  }

  void onTap(DatingGirlInfoModel item) {
    var param = {'info_id': item.id};
    if (widget.type == 1) {
      HttpHelper.dateLoveDelete(param, (data) {
        currentPage = 1;
        initLoadingData();
        Method.showText('操作成功');
      }, (error) {
        Method.showText(error.message ?? '');
      });
    } else {
      HttpHelper.dateLoveUpDown(param, (data) {
        item.setStatus = data['is_listed'] ?? 0;
        setState(() {});
      }, (error) {
        Method.showText(error.message ?? '');
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (widgetState != WidgetState.finish &&
        widgetState != WidgetState.noData) {
      return placeholderWidget();
    }

    return PullRefreshList(
      isAll: isAll,
      onLoading: onLoading,
      onRefresh: onRefresh,
      child: _buildListViewWidget(widget.type),
    );
  }

  Widget _buildListViewWidget(int idx) {
    return ListView.builder(
      padding: EdgeInsets.only(top: widget.origin == 1 ? 10.w : 0),
      itemCount: dataList.length,
      itemBuilder: (ctx, index) {
        DatingGirlInfoModel item = dataList[index];
        var isTrue = item.thumbUrl?.isNotEmpty ?? false;
        var thumb = isTrue
            ? item.thumbUrl
            : (item.girlPicsUrl?.isNotEmpty ?? false
                ? item.girlPicsUrl?.first
                : '');
        return buildContainerWidget(
          width: 343.w,
          height: 215.w,
          margin: EdgeInsets.fromLTRB(16.w, 0, 16.w, 20.w),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildCoverWidget(thumb!),
              SizedBox(width: 15.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(height: 20.w),
                    _buildNickNameWidget(item.title ?? ''),
                    SizedBox(height: 15.w),
                    _buildAgeCupWidget(
                        '类型：', item.typeStr, '城市：', item.cityName),
                    SizedBox(height: 15.w),
                    _buildAgeCupWidget(
                        '年龄：', '${item.girlAge}岁', '罩杯：', item.girlCup),
                    SizedBox(height: 10.w),
                    _buildRowTextWidget('服务项目：', item.girlServiceType ?? ''),
                    SizedBox(height: 10.w),
                    _buildRowTextWidget('价格：', item.girlPrice ?? ''),
                    SizedBox(height: 15.w),
                    ButtonWidget.build(
                        idx == 0 ? (item.status == 0 ? '上架' : '下架') : '删除',
                        style: IconStyle.pink_60_34,
                        onTap: () => onTap(item)) // 删除
                  ],
                ),
              ),
              SizedBox(width: 10.w),
            ],
          ),
        );
      },
    );
  }

  Widget _buildCoverWidget(String url) {
    return Container(
      height: 128.w,
      width: 96.w,
      margin: EdgeInsets.only(left: 10.w, top: 10.w),
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(6.w)),
      clipBehavior: Clip.hardEdge,
      child: NetworkImgContainer(url: url, fit: BoxFit.cover),
    );
  }

  Widget _buildNickNameWidget(String nickname) {
    return Text(
      nickname,
      style: TextStyle(color: rColor, fontSize: 16.sp, fontWeight: fontM),
    );
  }

  Widget _buildAgeCupWidget(tAge, age, tCup, cup) {
    return Row(children: [
      SizedBox(width: 100.w, child: _buildTextRichWidget(tAge, '$age')),
      Expanded(child: _buildTextRichWidget(tCup, '$cup')),
    ]);
  }

  Widget _buildTextRichWidget(String title, String content) {
    return Text.rich(
      TextSpan(children: [
        TextSpan(text: title, style: TextStyle(color: color_64)),
        TextSpan(
          text: content,
          style: TextStyle(color: wColor, fontWeight: fontB),
        )
      ], style: TextStyle(fontSize: 12.sp)),
      maxLines: 1,
      overflow: TextOverflow.ellipsis,
    );
  }

  Widget _buildRowTextWidget(String title, String content) {
    return Row(
      children: [
        Text(
          title,
          style: TextStyle(color: color_64, fontSize: 12.sp),
        ),
        Expanded(
          child: FittedBox(
            alignment: Alignment.centerLeft,
            fit: BoxFit.scaleDown,
            child: Text(
              content,
              style:
                  TextStyle(color: wColor, fontSize: 12.sp, fontWeight: fontB),
            ),
          ),
        ),
      ],
    );
  }
}
