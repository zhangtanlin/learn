import 'package:flick_video_player/flick_video_player.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:iaimei/model/video_model.dart';
import 'package:iaimei/pages/video/flick_long_video_controls.dart';
import 'package:iaimei/res/color_res.dart';
import 'package:iaimei/utils/log_util.dart';
import 'package:iaimei/utils/unlock_check_util.dart';
import 'package:iaimei/utils/video_util.dart';
import 'package:iaimei/widget/network_img_widget.dart';
import 'package:video_player/video_player.dart';
import 'package:visibility_detector/visibility_detector.dart';

/// 定义控制器函数返回类型
typedef SetControllerCallback = void Function(
  VideoPlayerController controller,
);

/// 简单的视频播放器
class LongVideoPlayer extends StatefulWidget {
  final Function? setVideoUrl;
  final bool isCardAuto;
  final bool isHideBackIcon;
  final bool isFull;
  final bool hideControl;
  final bool autoPlay;
  final bool loop;
  final bool noVolume;
  final VideoPlayerController? controller;
  final SetControllerCallback? setController;
  final VideoModel? data;
  final bool isLocal;
  final bool isPreview;
  final Function? changeVideo;

  const LongVideoPlayer({
    Key? key,
    this.setVideoUrl, // 改变父组件url
    this.isHideBackIcon = false,
    this.isCardAuto = false, //是否为卡片形式的自动方法
    this.isFull = false, //在全屏状态
    this.hideControl = false, //是否隐藏控制器
    this.autoPlay = true, //自动播放
    this.loop = false, //循环播放
    this.noVolume = false, //是否静音
    this.controller,
    this.setController, //返回参数是本视频的 controller
    this.data,
    this.isLocal = false, // 是否为本地视频
    this.isPreview = false,
    this.changeVideo,
  }) : super(key: key);

  @override
  _LongVideoPlayerState createState() => _LongVideoPlayerState();
}

class _LongVideoPlayerState extends State<LongVideoPlayer> {
  VideoModel? _videoModel;
  FlickManager? flickManager;

  @override
  void initState() {
    super.initState();
    _videoModel = widget.data ?? VideoModel();
    _initVideoAction(_videoModel);
  }

  Future<void> _initVideoAction(VideoModel? videoModel,
      {bool isChange = false}) async {
    String url =
        await VideoUtil.getRealVideoUrl(videoModel, isLocal: widget.isLocal);
    initVideo(url, isChange: isChange);
  }

  initVideo(String url, {bool isChange = false}) {
    if (!isChange) {
      flickManager = FlickManager(
          videoPlayerController: VideoPlayerController.network(url),
          onVideoEnd: () {
            if (!VideoUtil.isFreeVideo(_videoModel) &&
                flickManager!.flickControlManager!.isFullscreen) {
              flickManager?.flickControlManager?.exitFullscreen();
            }
          });
    } else {
      //更改播放地址
      flickManager!.handleChangeVideo(VideoPlayerController.network(url));
    }
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return flickManager == null
        ? _buildLoadingSection()
        : VisibilityDetector(
            key: ObjectKey(flickManager),
            onVisibilityChanged: (VisibilityInfo visibility) {
              if (visibility.visibleFraction == 0 && mounted) {
                flickManager!.flickControlManager!.autoPause();
              } else if (visibility.visibleFraction == 1) {
                flickManager!.flickControlManager!.autoResume();
              }
            },
            child: _buildVideoPlayer(),
          );
  }

  _buildVideoPlayer() {
    return FlickVideoPlayer(
      flickManager: flickManager!,
      flickVideoWithControls: FlickVideoWithControls(
        backgroundColor: Colors.black87,
        videoFit: BoxFit.contain,
        playerLoadingFallback: _buildLoadingSection(),
        playerErrorFallback: Container(),
        controls: FlickLongVideoControls(
          data: _videoModel,
          onBuyVipOrPay: () {
            _videoUnlockAction();
          },
        ),
      ),
    );
  }

  Stack _buildLoadingSection() {
    return Stack(
      children: [
        SizedBox(
          width: double.infinity,
          height: double.infinity,
          child: NetworkImgWidget(
            fit: BoxFit.cover,
            url: _videoModel?.coverThumbUrl ?? '',
          ),
        ),
        const Center(
          child: SpinKitFadingCircle(
            color: ColorRes.color_ff00b3,
            size: 45.0,
          ),
        )
      ],
    );
  }

  void _videoUnlockAction() {
    LogUtil.i('-----videoUnlockAction-----');
    UnlockCheckUtil.videoCheck(
        context, '${_videoModel?.id}', _videoModel?.payData,
        paySuccessFunc: (data) {
      try {
        VideoModel tempVideo = VideoModel.fromJson(data);
        setState(() {
          _videoModel = tempVideo;
          widget.changeVideo?.call(_videoModel);
          _initVideoAction(_videoModel, isChange: true);
        });
      } catch (e) {
        e.toString();
      }
    });
  }

  @override
  void dispose() {
    if (flickManager != null) {
      flickManager?.dispose();
    }
    super.dispose();
  }
}
