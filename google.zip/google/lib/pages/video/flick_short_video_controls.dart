import 'package:flick_video_player/flick_video_player.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:iaimei/model/video_model.dart';
import 'package:iaimei/res/color_res.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/res/img_res.dart';
import 'package:iaimei/style/app_text_style.dart';
import 'package:iaimei/utils/string_util.dart';
import 'package:iaimei/utils/video_util.dart';
import 'package:iaimei/widget/app_back_widget.dart';
import 'package:iaimei/widget/app_img_widget.dart';
import 'package:iaimei/widget/app_text_with_img_bg_widget.dart';
import 'package:iaimei/widget/network_img_widget.dart';
import 'package:iaimei/widget/space_widget.dart';
import 'package:iaimei/widget/text_widget.dart';
import 'package:provider/provider.dart';

class FlickShortVideoControls extends StatelessWidget {
  final double iconSize;

  final double fontSize;

  final double space;

  final FlickProgressBarSettings? progressBarSettings;

  final VideoModel? data;

  final Function? onBuyVipOrPay;
  final Function? onLike;
  final Function? onJumpToHomePage;
  final Function? onJumpToShare;
  final Function? onJumpToSearch;
  final Function? onDownload;

  const FlickShortVideoControls(
      {Key? key,
      this.iconSize = 24,
      this.fontSize = 14,
      this.space = 15,
      this.progressBarSettings,
      this.data,
      this.onBuyVipOrPay,
      this.onLike,
      this.onJumpToHomePage,
      this.onJumpToShare,
      this.onDownload,
      this.onJumpToSearch})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    FlickVideoManager videoManager = Provider.of<FlickVideoManager>(context);
    FlickControlManager controlManager =
        Provider.of<FlickControlManager>(context);
    if (kIsWeb) {
      controlManager.unmute();
    }
    double aspectRatio = videoManager.videoPlayerValue?.aspectRatio ?? 1.0;
    return Stack(
      children: [
        Positioned.fill(
          child: FlickShowControlsAction(
            child: Center(
              child: !videoManager.videoPlayerValue!.isInitialized ||
                      (videoManager.videoPlayerValue!.isBuffering &&
                          videoManager.videoPlayerValue!.isPlaying)
                  ? const SpinKitFadingCircle(
                      color: ColorRes.color_ff00b3,
                      size: 45.0,
                    )
                  : FlickPlayToggle(
                      replayChild: AppImgWidget(
                        path: ImgRes.IC_VIDEO_PLAY,
                        width: 50,
                        height: 50,
                      ),
                      playChild: Container(
                        color: Colors.transparent,
                        height: double.infinity,
                        width: double.infinity,
                        child: Center(
                          child: AppImgWidget(
                            path: ImgRes.IC_VIDEO_PLAY,
                            width: 50,
                            height: 50,
                          ),
                        ),
                      ),
                      pauseChild: Container(
                        color: Colors.transparent,
                        height: double.infinity,
                        width: double.infinity,
                      ),
                    ),
            ),
          ),
        ),
        Positioned.fill(
            child: SizedBox(
          height: double.infinity,
          width: double.infinity,
          child: Stack(
            children: [
              Positioned(
                child: _buildVideoPlayerTopWidget(context),
                left: DimenRes.dimen_10,
                right: DimenRes.dimen_15,
                top: DimenRes.statusBarHeight + 10,
              ),
              !kIsWeb && aspectRatio > 1
                  ? Container(
                      padding: EdgeInsets.only(
                          top: DimenRes.screenWidth / aspectRatio +
                              DimenRes.statusBarHeight +
                              DimenRes.dimen_50),
                      alignment: Alignment.center,
                      child: FlickFullScreenToggle(
                        size: 18,
                        enterFullScreenChild: AppImgWidget(
                          path: ImgRes.IC_FULL_SCREEN_S,
                          height: DimenRes.dimen_28,
                        ),
                        exitFullScreenChild: AppImgWidget(
                          path: ImgRes.IC_EXIT_FULL_SCREEN,
                          width: 18,
                        ),
                      ),
                    )
                  : const SizedBox(),
              Positioned(
                  left: 15,
                  right: 15,
                  bottom: 40,
                  child: _buildVideoPlayerBottomWidget(context))
            ],
          ),
        ))
      ],
    );
  }

  _buildVideoPlayerBottomWidget(BuildContext context) {
    return Column(
      children: [
        Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Expanded(child: _buildUserInfoSection()),
            const SizedBox(width: 60),
            _buildRightFunSection(context)
          ],
        ),
        _buildBottomBar(),
      ],
    );
  }

  _buildBottomBar() {
    return Container(
      margin: const EdgeInsets.only(top: 40),
      child: Row(
        children: <Widget>[
          // kIsWeb
          //     ? FlickSoundToggle(
          //         size: iconSize,
          //       )
          //     : const SizedBox(),
          // SizedBox(
          //   width: kIsWeb ? space : 0,
          // ),
          Expanded(
            child: FlickVideoProgressBar(
              flickProgressBarSettings: progressBarSettings ??
                  FlickProgressBarSettings(
                    height: 3,
                    handleRadius: 5,
                    curveRadius: 0,
                    backgroundColor: Colors.white.withOpacity(0.12),
                    bufferedColor: const Color.fromRGBO(255, 54, 218, 0.3),
                    playedColor: const Color.fromRGBO(255, 54, 218, 0.8),
                    handleColor: const Color.fromRGBO(255, 54, 218, 0.8),
                  ),
            ),
          ),
          const SizedBox(
            width: 18,
          ),
          FlickCurrentPosition(
            fontSize: fontSize,
          ),
          Text(
            ' / ',
            style: TextStyle(color: Colors.white, fontSize: fontSize),
          ),
          FlickTotalDuration(
            fontSize: fontSize,
          ),
        ],
      ),
    );
  }

  _buildUserInfoSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        TextWidget.buildSingleLineText(
          data != null &&
                  data?.user != null &&
                  StringUtil.isNotEmpty(data?.user.nickname)
              ? '@${data?.user.nickname}'
              : '',
          AppTextStyle.white_s16_bold,
        ),
        const SizedBox(height: 10),
        SizedBox(
          width: double.infinity,
          child: Text(
            data?.title ?? '',
            style: AppTextStyle.white_s13,
            maxLines: 3,
            softWrap: true,
            overflow: TextOverflow.ellipsis,
          ),
        ),
        VideoUtil.isFreeVideo(data ?? VideoModel())
            ? const SizedBox()
            : Container(
                margin: const EdgeInsets.only(top: 15),
                child: AppTextWithImgBgWidget(
                  alignment: Alignment.topLeft,
                  bgImgPath: ImgRes.BG_UNLOCK_WATCH_WHOLE,
                  text: VideoUtil.getVideoTips(data ?? VideoModel()),
                  textStyle: AppTextStyle.white_s12,
                  top: 0,
                  bottom: 0,
                  left: 10,
                  right: 10,
                  bgImgHeight: 28,
                  onTap: () {
                    if (onBuyVipOrPay != null) {
                      onBuyVipOrPay?.call();
                    }
                  },
                ),
              ),
      ],
    );
  }

  _buildRightFunSection(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(bottom: 50),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          GestureDetector(
            onTap: () {
              if (onJumpToHomePage != null) {
                onJumpToHomePage?.call();
              }
            },
            child: ClipRRect(
              borderRadius: const BorderRadius.all(
                Radius.circular(
                  10,
                ),
              ),
              child: SizedBox(
                width: 40,
                height: 40,
                child: NetworkImgWidget(
                  fit: BoxFit.cover,
                  background: Colors.white12,
                  url: data?.user.avatarUrl ?? "",
                ),
              ),
            ),
          ),
          const SizedBox(height: 30),
          GestureDetector(
            onTap: () {
              if (onLike != null) {
                onLike?.call();
              }
            },
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                AppImgWidget(
                  path: data?.isLike == 1 ? ImgRes.IC_LIKED : ImgRes.IC_NO_LIKE,
                  width: 30,
                  height: 30,
                ),
              ],
            ),
          ),
          const SpaceWidget(vSpace: 25),
          GestureDetector(
            onTap: () {
              if (onJumpToShare != null) {
                onJumpToShare?.call();
              }
            },
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                AppImgWidget(
                  path: ImgRes.IC_SHARE,
                  width: 30,
                  height: 30,
                ),
              ],
            ),
          ),
          const SpaceWidget(vSpace: 25),
          GestureDetector(
            onTap: () {
              if (onDownload != null) {
                onDownload?.call();
              }
            },
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                AppImgWidget(
                  path: ImgRes.IC_DOWNLOAD,
                  width: 30,
                  height: 30,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  _buildVideoPlayerTopWidget(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        const AppBackWidget(
          width: 35,
          height: 35,
        ),
        AppImgWidget(
          path: ImgRes.IC_SEARCH,
          width: 35,
          height: 35,
          onTap: () {
            if (onJumpToSearch != null) {
              onJumpToSearch?.call();
            }
          },
        )
      ],
    );
  }
}
