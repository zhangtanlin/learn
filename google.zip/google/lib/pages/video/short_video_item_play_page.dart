import 'package:flick_video_player/flick_video_player.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:iaimei/base/app_base_widget_state.dart';
import 'package:iaimei/global.dart';
import 'package:iaimei/mixin/video_related_mixin.dart';
import 'package:iaimei/model/video_model.dart';
import 'package:iaimei/net/http_helper.dart';
import 'package:iaimei/pages/video/flick_short_video_controls.dart';
import 'package:iaimei/pages/video/flick_short_video_full_controls.dart';
import 'package:iaimei/res/color_res.dart';
import 'package:iaimei/res/string_res.dart';
import 'package:iaimei/utils/date_util.dart';
import 'package:iaimei/utils/download_video.dart';
import 'package:iaimei/utils/page_jump_util.dart';
import 'package:iaimei/utils/unlock_check_util.dart';
import 'package:iaimei/utils/video_util.dart';
import 'package:iaimei/widget/network_img_widget.dart';
import 'package:iaimei/widget/toast_widget.dart';
import 'package:video_player/video_player.dart';
import 'package:visibility_detector/visibility_detector.dart';

class ShortVideoItemPlayPage extends StatefulWidget {
  final VideoModel? data;
  final FlickManager? flickManager;
  final Function()? itemDispose;

  const ShortVideoItemPlayPage({
    Key? key,
    required this.data,
    this.flickManager,
    this.itemDispose,
  }) : super(key: key);

  @override
  State<ShortVideoItemPlayPage> createState() => _ShortVideoItemPlayPageState();
}

class _ShortVideoItemPlayPageState
    extends AppBaseWidgetState<ShortVideoItemPlayPage> with VideoRelatedMixin {
  VideoModel? _videoModel;
  FlickManager? flickManager;

  @override
  void initState() {
    super.initState();
    VideoModel videoModel = widget.data ?? VideoModel();
    flickManager = widget.flickManager;
    WidgetsBinding.instance?.addPostFrameCallback((timeStamp) {
      getVideoDetail(videoModel.id);
    });
  }

  getVideoDetail(int id) {
    HttpHelper.getVideoDetail(id, (data) {
      _videoModel = VideoModel.fromJson(data);
      // 播放记录
      if (_videoModel != null) {
        AppGlobal.storeHistory(BrowseKey.video, _videoModel!.toJson());
      }
      initVideo(_videoModel, isChange: !kIsWeb);
    }, (error) {});
  }

  void initVideo(VideoModel? videoModel, {bool isChange = false}) async {
    VideoPlayerController? controller;
    if (controller == null || flickManager == null || isChange) {
      controller = await initController(videoModel);
    }
    if (!isChange) {
      flickManager ??= FlickManager(
          autoPlay: !kIsWeb,
          videoPlayerController: controller!
            ..setLooping(VideoUtil.isFreeVideo(videoModel)));
    } else {
      //更改播放地址
      flickManager!.handleChangeVideo(
          controller!..setLooping(VideoUtil.isFreeVideo(videoModel)));
    }
    flickManager!.onVideoEnd = () {
      if (!VideoUtil.isFreeVideo(_videoModel) &&
          flickManager!.flickControlManager!.isFullscreen) {
        flickManager?.flickControlManager?.exitFullscreen();
        return;
      }
      _videoUnlockAction();
    };
    if (!kIsWeb) {
      flickManager!.flickControlManager!.play();
    }
    setState(() {});
  }

  _buildLoadingSection() {
    return Stack(
      children: [
        SizedBox(
          width: double.infinity,
          height: double.infinity,
          child: NetworkImgWidget(
            fit: BoxFit.fitWidth,
            url: _videoModel?.coverThumbUrl ?? '',
          ),
        ),
        const Center(
          child: SpinKitFadingCircle(
            color: ColorRes.color_ff00b3,
            size: 45.0,
          ),
        )
      ],
    );
  }

  @override
  void dispose() {
    if (flickManager != null) {
      flickManager?.dispose();
    }
    if (widget.itemDispose != null) widget.itemDispose!();
    super.dispose();
  }

  @override
  Widget buildPageLayout() {
    return flickManager == null
        ? _buildLoadingSection()
        : VisibilityDetector(
            key: ObjectKey(flickManager),
            onVisibilityChanged: (VisibilityInfo visibility) {
              if (visibility.visibleFraction == 0 && mounted) {
                flickManager!.flickControlManager!.autoPause();
              } else if (visibility.visibleFraction == 1) {
                flickManager!.flickControlManager!.autoResume();
              }
            },
            child: Container(
              width: double.infinity,
              height: double.infinity,
              color: Colors.transparent,
              child: FlickVideoPlayer(
                flickManager: flickManager!,
                flickVideoWithControls: FlickVideoWithControls(
                  backgroundColor: Colors.transparent,
                  videoFit: BoxFit.contain,
                  playerLoadingFallback: _buildLoadingSection(),
                  playerErrorFallback: const SizedBox(),
                  controls: FlickShortVideoControls(
                    data: _videoModel,
                    onBuyVipOrPay: () {
                      _videoUnlockAction();
                    },
                    onLike: () {
                      _videoLikeAction();
                    },
                    onJumpToSearch: () {
                      PageJumpUtil.forwardToSearchPage(context);
                    },
                    onJumpToHomePage: () {
                      PageJumpUtil.forwardToUserHomePage(
                          context, _videoModel?.user.uid);
                    },
                    onJumpToShare: () {
                      PageJumpUtil.forwardToSharePage(context);
                    },
                    onDownload: _downloadLimitAction,
                  ),
                ),
                flickVideoWithControlsFullscreen: FlickVideoWithControls(
                  videoFit: BoxFit.contain,
                  playerLoadingFallback: _buildLoadingSection(),
                  playerErrorFallback: const SizedBox(),
                  backgroundColor: Colors.transparent,
                  controls: FlickShortVideoFullControls(
                    data: _videoModel,
                  ),
                ),
              ),
            ),
          );
  }

  void _videoLikeAction() {
    HttpHelper.likeVideoAction(_videoModel!.id, (data) {
      setState(() {
        if (_videoModel!.isLike == 1) {
          _videoModel!.isLike = 0;
        } else {
          _videoModel!.isLike = 1;
        }
      });
    }, (error) {
      ToastWidget.showToast(error.message ?? StringRes.str_operate_fail);
    });
  }

  void _videoUnlockAction() {
    UnlockCheckUtil.videoCheck(
        context, '${_videoModel?.id}', _videoModel?.payData,
        paySuccessFunc: (data) {
      try {
        VideoModel tempVideo = VideoModel.fromJson(data);
        setState(() {
          _videoModel = tempVideo;
          initVideo(_videoModel, isChange: true);
        });
      } catch (e) {
        e.toString();
      }
    });
  }

  void _downloadLimitAction() {
    HttpHelper.downloadLimit({'id': _videoModel!.id, 'type': 'mv'}, (data) {
      if (data['is_permit'] == 1) {
        _downloadOperateAction(url: data['resource_download']);
      } else {
        ToastWidget.showToast(data['message']);
      }
    }, (error) {
      ToastWidget.showToast(error.message ?? StringRes.str_operate_fail);
    });
  }

  void _downloadOperateAction({String? url}) {
    if (kIsWeb) {
      ToastWidget.showToast("请安装APP使用下载功能");
      return;
    }
    UnlockCheckUtil.check(_videoModel!.payData, freeCallback: () {
      if (_videoModel == null) {
        ToastWidget.showToast('下载视频不能为空');
        return;
      }
      ToastWidget.showToast(StringRes.str_start_download);
      Map taskInfo = {
        "id": "${_videoModel?.id}",
        "urlPath": url ?? _videoModel?.payUrlFull,
        "title": _videoModel?.title,
        "thumbCover": _videoModel?.coverThumbUrl,
        "date": DateUtil.dateToStr(DateTime.now()),
        "tags": _videoModel?.tags,
        "contentType": 2,
        "downloading": false,
        "isWaiting": true
      };
      DownloadUtil.createDownloadTask(taskInfo);
    }, buyVipCallback: (info) {
      ToastWidget.showToast('开通VIP后即可下载哦');
    }, payCallback: (info) {
      ToastWidget.showToast('购买后即可下载哦');
    });
  }

  @override
  bool isShowSafeArea() {
    return false;
  }
}
