import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:iaimei/model/video_model.dart';
import 'package:iaimei/net/http_helper.dart';
import 'package:iaimei/pages/video/long_video_player.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/res/img_res.dart';
import 'package:iaimei/res/string_res.dart';
import 'package:iaimei/utils/download_video.dart';
import 'package:iaimei/utils/page_jump_util.dart';
import 'package:iaimei/utils/unlock_check_util.dart';
import 'package:iaimei/widget/app_img_widget.dart';
import 'package:iaimei/widget/frosted_glass_box.dart';
import 'package:iaimei/widget/space_widget.dart';
import 'package:iaimei/widget/toast_widget.dart';

class LongVideoPlayPage extends StatefulWidget {
  const LongVideoPlayPage({Key? key, required this.videoDetail})
      : super(key: key);
  final VideoModel videoDetail;

  @override
  State<LongVideoPlayPage> createState() => _LongVideoPlayPageState();
}

class _LongVideoPlayPageState extends State<LongVideoPlayPage> {
  bool isLike = false;
  late VideoModel _videoModel;

  @override
  void initState() {
    super.initState();
    _videoModel = widget.videoDetail;
    isLike = _videoModel.isLike == 1;
  }

  void likeAction() {
    HttpHelper.likeVideoAction(_videoModel.id, (data) {
      setState(() {
        isLike = !isLike;
      });
    }, (error) {
      ToastWidget.showToast(error.message ?? StringRes.str_operate_fail);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.black.withOpacity(0.9),
        body: Stack(
          children: [
            Container(
              width: double.infinity,
              height: double.infinity,
              color: Colors.transparent,
              child: GestureDetector(
                onTap: () {
                  Navigator.pop(context);
                },
                behavior: HitTestBehavior.translucent,
              ),
            ),
            _buildLongVideoPlayer(),
            _buildBottomFun(context)
          ],
        ));
  }

  Positioned _buildBottomFun(BuildContext context) {
    return Positioned(
        bottom: DimenRes.dimen_60,
        left: 0,
        right: 0,
        child: FrostedGlassDeepBox(
          width: double.infinity,
          margin: EdgeInsets.only(
              left: DimenRes.dimen_15, right: DimenRes.dimen_15),
          padding: EdgeInsets.all(DimenRes.dimen_10),
          borderRadius: BorderRadius.all( Radius.circular(24)),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              MenuItem(
                url: ImgRes.IC_DOWNLOAD,
                text: StringRes.str_download,
                onTap: () {
                  if (kIsWeb) {
                    ToastWidget.showToast("请下载APP使用下载功能");
                  } else {
                    UnlockCheckUtil.check(_videoModel.payData,
                        freeCallback: () {
                      if (_videoModel.payUrlFull == '') {
                        ToastWidget.showToast('${_videoModel.id} 播放地址为空');
                        return;
                      }
                      _createDownloadTask();
                    }, buyVipCallback: (info) {
                      ToastWidget.showToast('开通VIP后即可下载哦');
                    }, payCallback: (info) {
                      ToastWidget.showToast('购买后即可下载哦');
                    });
                  }
                },
              ),
              MenuItem(
                url: isLike ? ImgRes.IC_LIKED : ImgRes.IC_NO_LIKE,
                text: isLike ? StringRes.str_collected : StringRes.str_collect,
                onTap: () {
                  likeAction();
                },
              ),
              MenuItem(
                url: ImgRes.IC_SHARE,
                text: StringRes.str_share,
                onTap: () {
                  PageJumpUtil.forwardToSharePage(context);
                },
              ),
            ],
          ),
        ));
  }

  Center _buildLongVideoPlayer() {
    return Center(
      child: LayoutBuilder(
        builder: (BuildContext context, BoxConstraints constraints) {
          double tempWidth = constraints.maxWidth;
          double tempHeight = tempWidth * 9 / 16;
          return Container(
            color: Colors.white12,
            width: double.infinity,
            height: tempHeight,
            child: LongVideoPlayer(
              data: _videoModel,
              changeVideo: (videoModel) {
                _videoModel = videoModel;
              },
            ),
          );
        },
      ),
    );
  }

  void _createDownloadTask() {
    Map taskInfo = {
      "id": "${_videoModel.id}",
      "urlPath": _videoModel.payUrlFull,
      "title": _videoModel.title,
      "thumbCover": _videoModel.coverThumbUrl,
      "date": _videoModel.createdStr,
      "tags": _videoModel.tags,
      "contentType": 1,
      "downloading": false,
      "isWaiting": true
    };
    DownloadUtil.createDownloadTask(taskInfo);
  }
}

class MenuItem extends StatelessWidget {
  const MenuItem({
    Key? key,
    required this.url,
    required this.text,
    required this.onTap,
  }) : super(key: key);

  final String url;
  final String text;
  final GestureTapCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          AppImgWidget(
            path: url,
            width: 30,
            height: 30,
          ),
          SpaceWidget(
            vSpace: DimenRes.dimen_3,
          ),
          Text(
            text,
            style: TextStyle(
              color: Colors.white.withOpacity(0.84),
              fontWeight: FontWeight.w400,
              fontStyle: FontStyle.normal,
              fontSize: DimenRes.sp(10),
              decoration: TextDecoration.none,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}
