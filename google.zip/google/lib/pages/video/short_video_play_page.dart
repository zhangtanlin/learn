import 'package:flick_video_player/flick_video_player.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/physics.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:iaimei/mixin/video_related_mixin.dart';
import 'package:iaimei/model/video_model.dart';
import 'package:iaimei/pages/video/short_video_item_play_page.dart';
import 'package:iaimei/res/color_res.dart';
import 'package:iaimei/utils/list_util.dart';

class ShortVideoPlayPage extends StatefulWidget {
  final int? curIndex;
  final List<VideoModel>? dataList;

  const ShortVideoPlayPage({Key? key, this.curIndex, this.dataList})
      : super(key: key);

  @override
  State<ShortVideoPlayPage> createState() => _ShortVideoPlayPageState();
}

class _ShortVideoPlayPageState extends State<ShortVideoPlayPage>
    with VideoRelatedMixin {
  List<VideoModel> videoList = [];
  late PageController _pageController;
  List<Map<int, FlickManager?>> videoManagers = [];
  int loadMoreCount = 3;
  int preloadCount = 2;
  int _curIndex = 0;

  @override
  void initState() {
    super.initState();
    _curIndex = widget.curIndex ?? 0;
    _pageController = PageController(initialPage: _curIndex);
    videoList = widget.dataList!;
    initVideoManagerList(videoList);
  }

  int getMinIndex(int curIndex, int length) {
    int tempMinIndex = 0;
    if (length > 0) {
      if (curIndex == 0) {
        tempMinIndex = 0;
      } else if (curIndex < length - 1) {
        tempMinIndex = curIndex - 1;
      } else if (curIndex == length - 1) {
        if (curIndex >= preloadCount) {
          tempMinIndex = curIndex - preloadCount;
        } else {
          tempMinIndex = 0;
        }
      }
    }
    return tempMinIndex;
  }

  int getMaxIndex(int curIndex, int length) {
    int tempMaxIndex = 0;
    if (length > 0) {
      if (curIndex == 0) {
        if (length > preloadCount) {
          tempMaxIndex = preloadCount;
        } else {
          tempMaxIndex = length - 1;
        }
      } else if (curIndex < length - 1) {
        tempMaxIndex = curIndex + 1;
      } else if (curIndex == length - 1) {
        tempMaxIndex = length - 1;
      }
    }
    return tempMaxIndex;
  }

  initVideoManagerList(List videoList) async {
    if (!kIsWeb) {
      List<Map<int, FlickManager?>> tempVideoManagerList = [];
      int videoLength = videoList.length;
      for (var i = 0; i < videoLength; i++) {
        //只初始化前3个数据
        tempVideoManagerList.add({
          i: (i >= getMinIndex(_curIndex, videoLength) &&
                  i <= getMaxIndex(_curIndex, videoLength))
              ? FlickManager(
                  autoPlay: false,
                  videoPlayerController: await initController(videoList[i])!)
              : null
        });
      }
      videoManagers = tempVideoManagerList;
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    return PageView.builder(
        scrollDirection: Axis.vertical,
        itemCount: videoList.length,
        controller: _pageController,
        physics: const QuickerScrollPhysics(),
        itemBuilder: (context, index) {
          return kIsWeb
              ? ShortVideoItemPlayPage(
                  data: videoList[index],
                  itemDispose: () {

                  },
                )
              : videoList.length == videoManagers.length
                  ? ShortVideoItemPlayPage(
                      data: videoList[index],
                      flickManager: videoManagers[index][index],
                      itemDispose: () {
                        if (ListUtil.isNotEmpty(videoManagers)) {
                          videoManagers[index][index] = null;
                          var _curPage = _pageController.page!;
                          if (_curPage % 1 == 0) {
                            int tempPage = _curPage ~/ 1;
                            loadIndex(tempPage);
                          }
                        }
                      },
                    )
                  : _buildLoadingSection();
        });
  }

  _buildLoadingSection() {
    return const Center(
      child: SpinKitFadingCircle(
        color: ColorRes.color_ff00b3,
        size: 45.0,
      ),
    );
  }

  void loadIndex(int target) async {
    var newIndex = target;
    //快速滑动取消缓存
    if (videoManagers[newIndex][newIndex] == null) {
      if (videoList.length - newIndex <= loadMoreCount + 1) {
        //page添加
      }
      return;
    }
    for (var i = 0; i < videoList.length; i++) {
      if (i < newIndex - preloadCount || i > newIndex + preloadCount) {
        if (videoManagers[i][i] != null) {
          videoManagers[i][i]?.dispose();
          videoManagers[i][i] = null;
        }
      }
    }

    for (var j = 1; j <= preloadCount; j++) {
      int sub = newIndex - j;
      if (sub >= 0) {
        if (videoManagers[sub][sub] == null) {
          videoManagers[sub][sub] = FlickManager(
              autoPlay: false,
              videoPlayerController: await initController(videoList[sub])!);
        }
      }

      int add = newIndex + j;
      if (add < videoList.length) {
        if (videoManagers[add][add] == null) {
          videoManagers[add][add] = FlickManager(
              autoPlay: false,
              videoPlayerController: await initController(videoList[add])!);
        }
      }
    }
  }

  @override
  void dispose() {
    videoList = [];
    if (_pageController != null) {
      _pageController.dispose();
    }
    super.dispose();
  }
}

class QuickerScrollPhysics extends BouncingScrollPhysics {
  const QuickerScrollPhysics({ScrollPhysics? parent}) : super(parent: parent);

  @override
  QuickerScrollPhysics applyTo(ScrollPhysics? ancestor) {
    return QuickerScrollPhysics(parent: buildParent(ancestor));
  }

  @override
  SpringDescription get spring => SpringDescription.withDampingRatio(
        mass: 0.2,
        stiffness: 300.0,
        ratio: 1.2,
      );
}
