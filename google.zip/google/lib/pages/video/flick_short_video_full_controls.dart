import 'package:flick_video_player/flick_video_player.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:iaimei/model/video_model.dart';
import 'package:iaimei/res/color_res.dart';
import 'package:iaimei/res/img_res.dart';
import 'package:iaimei/style/app_text_style.dart';
import 'package:iaimei/utils/video_util.dart';
import 'package:iaimei/widget/app_img_widget.dart';
import 'package:iaimei/widget/app_text_with_img_bg_widget.dart';
import 'package:provider/provider.dart';

class FlickShortVideoFullControls extends StatelessWidget {
  final double iconSize;

  final double fontSize;

  final double space;

  final FlickProgressBarSettings? progressBarSettings;

  final VideoModel? data;

  final Function? onBuyVipOrPay;

  final Function? onRePlay;

  const FlickShortVideoFullControls(
      {Key? key,
      this.iconSize = 24,
      this.fontSize = 14,
      this.progressBarSettings,
      this.space = 15,
      this.data,
      this.onBuyVipOrPay,
      this.onRePlay})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    FlickVideoManager videoManager = Provider.of<FlickVideoManager>(context);
    FlickControlManager controlManager =
        Provider.of<FlickControlManager>(context);
    if (kIsWeb) {
      controlManager.unmute();
    }
    return Stack(
      children: <Widget>[
        const Positioned.fill(
          child: FlickShowControlsAction(
              child: FlickSeekVideoAction(
            child: SizedBox(
              width: double.infinity,
              height: double.infinity,
            ),
          )),
        ),
        VideoUtil.isFreeVideo(data)
            ? const SizedBox()
            : videoManager.isVideoEnded && !controlManager.isFullscreen
                ? Positioned.fill(
                    child: AbsorbPointer(
                    absorbing: false,
                    child: Center(
                      child: SizedBox(
                        width: double.infinity,
                        child: AppTextWithImgBgWidget(
                          bgImgPath: ImgRes.BG_UNLOCK_WATCH_WHOLE,
                          text: VideoUtil.getVideoTips(data),
                          textStyle: AppTextStyle.white_s13,
                          top: 0,
                          bottom: 0,
                          left: 10,
                          right: 10,
                          bgImgHeight: 30,
                          onTap: () {
                            if (controlManager.isFullscreen) {
                              controlManager.exitFullscreen();
                            } else {
                              onBuyVipOrPay?.call();
                            }
                          },
                        ),
                      ),
                    ),
                  ))
                : const SizedBox(),
        Positioned.fill(
          child: FlickAutoHideChild(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  height: 12,
                ),
                Container(
                  decoration: const BoxDecoration(
                      gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                        Colors.transparent,
                        Colors.black38,
                      ])),
                  padding: const EdgeInsets.symmetric(
                      horizontal: 15.0, vertical: 15.0),
                  child: Row(
                    children: <Widget>[
                      FlickPlayToggle(
                        togglePlay: () {
                          if (videoManager.isVideoEnded) {
                            controlManager.replay();
                            onRePlay?.call();
                          } else {
                            controlManager.togglePlay();
                          }
                        },
                        pauseChild: AppImgWidget(
                          path: ImgRes.IC_PAUSE,
                          width: 18,
                        ),
                        playChild: AppImgWidget(
                          path: ImgRes.IC_PLAY,
                          width: 18,
                        ),
                        replayChild:
                            AppImgWidget(path: ImgRes.IC_REPLAY, width: 18),
                      ),
                      SizedBox(
                        width: space,
                      ),
                      // kIsWeb
                      //     ? FlickSoundToggle(
                      //         size: iconSize,
                      //       )
                      //     : const SizedBox(),
                      // SizedBox(
                      //   width: kIsWeb ? space : 0,
                      // ),
                      Expanded(
                        child: FlickVideoProgressBar(
                          flickProgressBarSettings: progressBarSettings ??
                              FlickProgressBarSettings(
                                height: 3,
                                handleRadius: 5,
                                curveRadius: 0,
                                backgroundColor: Colors.white.withOpacity(0.12),
                                bufferedColor:
                                    const Color.fromRGBO(255, 54, 218, 0.3),
                                playedColor:
                                    const Color.fromRGBO(255, 54, 218, 0.8),
                                handleColor:
                                    const Color.fromRGBO(255, 54, 218, 0.8),
                              ),
                        ),
                      ),
                      const SizedBox(
                        width: 18,
                      ),
                      FlickCurrentPosition(
                        fontSize: fontSize,
                      ),
                      FlickAutoHideChild(
                        child: Text(
                          ' / ',
                          style: TextStyle(
                              color: Colors.white, fontSize: fontSize),
                        ),
                      ),
                      FlickTotalDuration(
                        fontSize: fontSize,
                      ),
                      SizedBox(
                        width: space,
                      ),
                      videoManager.isVideoInitialized
                          ? FlickFullScreenToggle(
                              enterFullScreenChild: AppImgWidget(
                                path: ImgRes.IC_FULL_SCREEN,
                                width: 18,
                              ),
                              exitFullScreenChild: AppImgWidget(
                                path: ImgRes.IC_EXIT_FULL_SCREEN,
                                width: 18,
                              ),
                            )
                          : const SizedBox(),
                    ],
                  ),
                )
              ],
            ),
          ),
        ),
        Center(
            child: AnimatedOpacity(
          opacity: !videoManager.isVideoInitialized || videoManager.isBuffering
              ? 1.0
              : 0.0,
          duration: const Duration(milliseconds: 100),
          child: const SpinKitFadingCircle(
            color: ColorRes.color_ff00b3,
            size: 45.0,
          ),
        ))
      ],
    );
  }
}
