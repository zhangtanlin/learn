import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:iaimei/components/card/card_pictures.dart';
import 'package:iaimei/components/card/card_video.dart';
import 'package:iaimei/components/common/commonelements.dart';
import 'package:iaimei/components/common/pagestatus.dart';
import 'package:iaimei/components/common/pullrefreshlist.dart';
import 'package:iaimei/components/common/stackpage.dart';
import 'package:iaimei/model/atlas_item_model.dart';
import 'package:iaimei/model/basic.dart';
import 'package:iaimei/model/comics_item_model.dart';
import 'package:iaimei/model/model_filter.dart';
import 'package:iaimei/model/novel_item_model.dart';
import 'package:iaimei/model/video_model.dart';
import 'package:iaimei/pages/comics/comics_list_item_widget.dart';
import 'package:iaimei/pages/novel/novel_item_widget.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/res/img_res.dart';
import 'package:iaimei/utils/api.dart';
import 'package:iaimei/utils/page_jump_util.dart';
import 'package:iaimei/utils/video_util.dart';
import 'package:iaimei/widget/list_widget.dart';

/// 视频筛选
class FilterPage extends StatefulWidget {
  const FilterPage({Key? key}) : super(key: key);

  @override
  State<FilterPage> createState() => _FilterPageState();
}

class _FilterPageState extends State<FilterPage> with TickerProviderStateMixin {
  late Animation<double> animation;
  late AnimationController controller;
  int tabIndex = 0;

  // 全局加载中
  bool loading = true;

  // 筛选条件列表
  List<Category> _categoryData = [];

  // 筛选参数
  final dynamic _params = {
    "category": "vlog",
    "tags": "",
    "fee": "",
    "order": "",
  };

  // 列表加载中
  bool _dataLoading = true;
  int _page = 1;
  final int _limit = 10;
  bool _isAll = false;
  List _data = [];

  /// 请求列表
  Future<void> _getData() async {
    if (_isAll) return;
    Basic? res = await apiMvFilter(
      page: _page,
      limit: _limit,
      category: _params["category"],
      tags: _params["tags"],
      fee: _params["fee"],
      order: _params["order"],
    );
    if (res?.status == 1) {
      if (_categoryData.isEmpty) {
        List<Category> tempCategory = (res?.data['category'] as List)
            .map((item) => Category.fromJson(item))
            .toList();
        // 设置_params
        for (var i = 0; i < tempCategory.length; i++) {
          _params[tempCategory[i].name] = tempCategory[i].items![0].value ?? '';
        }
        // 设置筛选列表
        _categoryData = tempCategory;
      }
      List tempData = [];
      switch (_params["category"]) {
        // 长视频
        case "mv":
          tempData = (res?.data['list'] as List)
              .map((item) => VideoModel.fromJson(item))
              .toList();
          break;
        // 漫画
        case "mh":
          tempData = (res?.data['list'] as List)
              .map((item) => ComicsItemModel.fromJson(item))
              .toList();
          break;
        // 图集
        case "image":
          tempData = (res?.data['list'] as List)
              .map((item) => AtlasItemModel.fromJson(item))
              .toList();
          break;
        // 小说
        case "story":
          tempData = (res?.data['list'] as List)
              .map((item) => NovelItemModel.fromJson(item))
              .toList();
          break;
        // 短视频
        default:
          tempData = (res?.data['list'] as List)
              .map((item) => VideoModel.fromJson(item))
              .toList();
      }
      if (_page == 1) {
        _data = tempData;
      } else {
        _data.addAll(tempData);
      }
      if (tempData.length < _limit) {
        _isAll = true;
      }
      setState(() {});
    }
  }

  /// 初始化请求列表
  Future<void> _initListData() async {
    setState(() {
      _dataLoading = true;
    });
    await _getData();
    setState(() {
      _dataLoading = false;
    });
  }

  /// 初始化请求
  Future<void> _initData() async {
    await _initListData();
    setState(() {
      loading = false;
    });
  }

  @override
  void initState() {
    super.initState();
    controller = AnimationController(
      duration: const Duration(milliseconds: 0),
      vsync: this,
    );
    animation = Tween<double>(
      begin: ScreenUtil().setWidth(188),
      end: 0.0,
    ).animate(controller)
      ..addListener(() {
        setState(() {});
      });
    _initData();
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  /// 收缩/扩展-筛选列表
  void onSubmitFunction(bool value) {
    if (value) {
      animation = Tween<double>(
        begin: 0.0,
        end: 0.0,
      ).animate(controller);
      controller.forward();
    } else {
      animation = Tween<double>(
        begin: ScreenUtil().setWidth(188),
        end: 0.0,
      ).animate(controller);
      controller.reverse();
    }
  }

  @override
  Widget build(BuildContext context) {
    return StackPage(
      header: FilterHeader(
        onChange: onSubmitFunction,
      ),
      child: _buildInit(),
    );
  }

  /// 初始化构建
  Widget _buildInit() {
    if (loading) {
      return PageStatus.loading(loading);
    }
    return Column(
      children: [
        SizedBox(
          width: double.infinity,
          height: animation.value,
          child: Padding(
            padding: EdgeInsets.symmetric(
              vertical: ScreenUtil().setWidth(10),
              horizontal: ScreenUtil().setWidth(16),
            ),
            child: _setCategoryData(),
          ),
        ),
        Container(
          width: double.infinity,
          margin: EdgeInsets.symmetric(
            horizontal: ScreenUtil().setWidth(16),
          ),
          height: ScreenUtil().setWidth(0.5),
          color: const Color.fromRGBO(255, 255, 255, 0.2),
        ),
        Expanded(
          child: _setListWidget(),
        ),
      ],
    );
  }

  /// 构建筛选列表
  Widget _setCategoryData() {
    if (_categoryData.isNotEmpty) {
      for (var i = 0; i < _categoryData.length; i++) {}
      return Column(
        children: [
          for (var i = 0; i < _categoryData.length; i++) ...[
            FilterContainer(
              filterTags: _categoryData[i].items,
              tabIndex: tabIndex,
              hideBottomMargin: i == _categoryData.length - 1,
              onTab: (index) {
                _params[_categoryData[i].name] =
                    _categoryData[i].items![index].value;
                _page = 1;
                _isAll = false;
                _initListData();
              },
            ),
          ]
        ],
      );
    }
    return const SizedBox();
  }

  /// 构建列表
  Widget _setListWidget() {
    if (_dataLoading) {
      return PageStatus.loading(_dataLoading);
    }
    if (_data.isNotEmpty) {
      return PullRefreshList(
        onRefresh: () {
          _page = 1;
          _isAll = false;
          _initListData();
        },
        onLoading: () {
          if (!_isAll) {
            _page++;
            _getData();
          }
        },
        child: _setListByType(),
      );
    } else {
      return PageStatus.noData();
    }
  }

  /// 根据类型不同选择不同的列表展示
  Widget _setListByType() {
    Widget tempWidget = const SizedBox();
    switch (_params["category"]) {
      // 长视频
      case "mv":
        tempWidget = ListWidget.buildGridView(
          itemCount: _data.length,
          childRatio: 1.18,
          crossCount: 2,
          mainSpace: DimenRes.dimen_15,
          crossSpace: DimenRes.dimen_15,
          itemBuilder: (BuildContext context, int index) {
            double width =
                (DimenRes.screenWidth - ScreenUtil().setWidth(45)) / 2;
            return InkWell(
              onTap: () {
                VideoUtil.jumpToVideoPlayer(
                    context, _data as List<VideoModel>, curIndex: index);
              },
              child: CardVideoFilter(
                width: width,
                type: 1,
                videoModel: _data[index] as VideoModel,
              ),
            );
          },
        );
        break;
      // 漫画
      case "mh":
        tempWidget = ListWidget.buildGridView(
          itemCount: _data.length,
          itemBuilder: (context, index) {
            double width = (DimenRes.screenWidth - DimenRes.dimen_60) / 3;
            double height = width * 7 / 5;
            return InkWell(
              child: ComicsListItemWidget(
                itemData: _data[index],
                imgWidth: width,
                imgHeight: height,
              ),
              onTap: () {
                PageJumpUtil.forwardToComicsDetailPage(
                  context,
                  _data[index],
                );
              },
            );
          },
          childRatio: 0.62,
          mainSpace: DimenRes.dimen_15,
          crossSpace: DimenRes.dimen_15,
          crossCount: 3,
        );
        break;
      // 图集
      case "image":
        tempWidget = ListWidget.buildGridView(
          itemCount: _data.length,
          childRatio: 0.625,
          crossCount: 2,
          mainSpace: DimenRes.dimen_3,
          crossSpace: DimenRes.dimen_3,
          itemBuilder: (BuildContext context, int index) {
            return InkWell(
              onTap: () {
                PageJumpUtil.forwardToAtlasDetailPage(
                    context, _data[index] as AtlasItemModel);
              },
              child: CardPicturesFilter(
                atlasModel: _data[index],
              ),
            );
          },
        );
        break;
      // 小说
      case "story":
        tempWidget = ListWidget.buildGridView(
          itemCount: _data.length,
          itemBuilder: (context, index) {
            double width = (DimenRes.screenWidth - DimenRes.dimen_60) / 3;
            double height = width * 7 / 5;
            return InkWell(
              child: NovelItemWidget(
                itemData: _data[index],
                imgWidth: width,
                imgHeight: height,
              ),
              onTap: () {
                PageJumpUtil.forwardToNovelDetailPage(
                  context,
                  _data[index],
                );
              },
            );
          },
          childRatio: 0.62,
          mainSpace: DimenRes.dimen_15,
          crossSpace: DimenRes.dimen_15,
          crossCount: 3,
        );
        break;
      default:
        tempWidget = ListWidget.buildGridView(
          itemCount: _data.length,
          childRatio: 0.625,
          crossCount: 2,
          mainSpace: DimenRes.dimen_3,
          crossSpace: DimenRes.dimen_3,
          itemBuilder: (
            BuildContext context,
            int index,
          ) {
            double width =
                (DimenRes.screenWidth - ScreenUtil().setWidth(33)) / 2;
            return InkWell(
              onTap: () {
                VideoUtil.jumpToVideoPlayer(context, _data as List<VideoModel>,
                    curIndex: index);
              },
              child: CardVideoFilter(
                width: width,
                type: 2,
                videoModel: _data[index] as VideoModel,
              ),
            );
          },
        );
        break;
    }
    return Container(
      margin: EdgeInsets.symmetric(
        horizontal: DimenRes.dimen_15,
        vertical: DimenRes.dimen_10,
      ),
      child: tempWidget,
    );
  }
}

/// 筛选按钮盒子
class FilterContainer extends StatelessWidget {
  const FilterContainer({
    Key? key,
    this.filterTags,
    this.tabIndex,
    this.hideBottomMargin = false,
    this.onTab,
  }) : super(key: key);

  final List<Item>? filterTags;
  final int? tabIndex;
  final bool hideBottomMargin;
  final Function? onTab;

  /// 设置底部外边距
  double setMarginBottom() {
    if (hideBottomMargin) {
      return 0.0;
    }
    return ScreenUtil().setWidth(8);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      alignment: Alignment.centerLeft,
      margin: EdgeInsets.only(
        bottom: setMarginBottom(),
      ),
      padding: EdgeInsets.all(
        ScreenUtil().setWidth(6),
      ),
      height: ScreenUtil().setWidth(36),
      decoration: BoxDecoration(
        color: const Color.fromRGBO(0, 0, 0, 0.24),
        borderRadius: BorderRadius.circular(
          ScreenUtil().setWidth(18),
        ),
      ),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: FilterTabsContainer(
          tabs: filterTags,
          selectTabIndex: tabIndex,
          onTabs: (index) {
            if (onTab != null) {
              onTab!(index);
            }
          },
        ),
      ),
    );
  }
}

/// tab按钮列表
class FilterTabsContainer extends StatefulWidget {
  final List<Item>? tabs;
  final int? selectTabIndex;
  final Function onTabs;

  const FilterTabsContainer({
    Key? key,
    required this.tabs,
    required this.selectTabIndex,
    required this.onTabs,
  }) : super(key: key);

  @override
  _FilterTabsContainerState createState() => _FilterTabsContainerState();
}

class _FilterTabsContainerState extends State<FilterTabsContainer> {
  int index = 0;

  @override
  void initState() {
    super.initState();
    index = widget.selectTabIndex ?? 0;
  }

  onTapTabsItem(int i) {
    setState(() {
      index = i;
    });
    widget.onTabs(i);
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        for (var i = 0; i < widget.tabs!.length; i++) ...[
          TabsItem(
            title: widget.tabs![i].label.toString(),
            index: index,
            keys: i,
            onTap: () {
              onTapTabsItem(i);
            },
          )
        ]
      ],
    );
  }
}

/// tab按钮
/// [title]文字
/// [index]选中的序列号
/// [keys]序列号
class TabsItem extends StatelessWidget {
  final String title;
  final int index;
  final int keys;
  final GestureTapCallback onTap;

  const TabsItem({
    Key? key,
    required this.title,
    this.index = 0,
    required this.onTap,
    required this.keys,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: ScreenUtil().setWidth(66),
        height: ScreenUtil().setWidth(30),
        color: Colors.transparent,
        alignment: Alignment.center,
        child: Stack(
          alignment: Alignment.center,
          children: <Widget>[
            Offstage(
              offstage: index != keys,
              child: Container(
                width: double.infinity,
                alignment: Alignment.center,
                decoration: const BoxDecoration(
                  image: DecorationImage(
                    image: AssetImage(
                      "assets/images/button/btn_gradient.png",
                    ),
                    fit: BoxFit.fill,
                  ),
                ),
              ),
            ),
            Text(
              title,
              textAlign: TextAlign.center,
              style: index == keys
                  ? TextStyle(
                      color: Colors.white,
                      fontSize: ScreenUtil().setSp(12),
                      fontWeight: FontWeight.w700,
                    )
                  : TextStyle(
                      color: const Color(0xa3ffffff),
                      fontSize: ScreenUtil().setSp(12),
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

/// 筛选页面头部
class FilterHeader extends StatefulWidget {
  final Function onChange;

  const FilterHeader({
    Key? key,
    required this.onChange,
  }) : super(key: key);

  @override
  State<FilterHeader> createState() => _FilterHeaderState();
}

class _FilterHeaderState extends State<FilterHeader>
    with TickerProviderStateMixin {
  late AnimationController controller;
  late Animation<double> animation;

  @override
  void initState() {
    super.initState();

    controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    );

    setRotation(90);
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  void setRotation(int degrees) {
    final angle = degrees * pi / 180;
    animation = Tween<double>(
      begin: 0,
      end: angle,
    ).animate(controller);
  }

  void handleChange(bool value) {
    widget.onChange.call(value);
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        ActionIcon(
          onTap: () {
            Navigator.pop(context);
          },
          url: ImgRes.IC_ARROW_BACK,
        ),
        SizedBox(
          width: ScreenUtil().setWidth(10),
        ),
        Expanded(
          child: Text(
            "筛选",
            style: TextStyle(
              color: Colors.white,
              fontSize: ScreenUtil().setSp(18),
            ),
          ),
        ),
        SizedBox(
          width: ScreenUtil().setWidth(10),
        ),
        AnimatedBuilder(
          animation: animation,
          builder: (context, child) => Transform.rotate(
            angle: animation.value,
            child: child,
          ),
          child: ActionIcon(
            onTap: () {
              if (animation.status == AnimationStatus.completed) {
                controller.reverse();
                handleChange(false);
              } else {
                setRotation(180);
                controller.forward();
                handleChange(true);
              }
            },
            url: "assets/images/common/action_hide_tabs.png",
          ),
        )
      ],
    );
  }
}
