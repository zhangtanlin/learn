import 'package:flutter/material.dart';
import 'package:iaimei/base/base_widget_state.dart';
import 'package:iaimei/mixin/list_page_load_mixin.dart';
import 'package:iaimei/model/comics_index_list_model.dart';
import 'package:iaimei/model/comics_item_model.dart';
import 'package:iaimei/model/tab_data.dart';
import 'package:iaimei/net/http_helper.dart';
import 'package:iaimei/pages/comics/comics_list_item_widget.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/res/img_res.dart';
import 'package:iaimei/style/app_text_style.dart';
import 'package:iaimei/utils/list_util.dart';
import 'package:iaimei/utils/page_jump_util.dart';
import 'package:iaimei/widget/app_img_widget.dart';
import 'package:iaimei/widget/list_widget.dart';
import 'package:iaimei/widget/refresh_load_list_widget.dart';
import 'package:iaimei/widget/space_widget.dart';
import 'package:iaimei/widget/text_widget.dart';

class ComicsHomeSortListPage extends StatefulWidget {
  final int id;

  final SubTab tab;

  const ComicsHomeSortListPage({Key? key, required this.id, required this.tab})
      : super(key: key);

  @override
  State<ComicsHomeSortListPage> createState() => _ComicsHomeSortListPageState();
}

class _ComicsHomeSortListPageState
    extends BaseWidgetState<ComicsHomeSortListPage> with ListPageLoadMixin {
  @override
  void initState() {
    super.initState();
    onLoadData();
  }

  @override
  onLoadData() {
    onRefreshList();
  }

  @override
  void requestListData(bool isRefresh) {
    HttpHelper.getComicsIndexList(
        '${widget.id}', widget.tab.value!, getCurPage, getPageSize, (data) {
      ComicsIndexListModel listModel = ComicsIndexListModel.fromJson(data);
      setListPageState(isRefresh, ListUtil.isNotEmpty(listModel.list), () {
        updatePageList(isRefresh, listModel.list!);
      });
    }, (error) {
      setListPageErrorState(isRefresh, error);
    });
  }

  @override
  Widget buildPageLayout() {
    return handlePageStateView();
  }

  @override
  Widget successView() {
    return RefreshLoadListWidget(
      enableLoad: isEnableLoad(),
      enableRefresh: isEnableRefresh(),
      onRefresh: onRefreshList,
      onLoad: onLoadList,
      refreshController: refreshController,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [_buildComicListSection(getResultList)],
      ),
    );
  }

  _buildComicListSection(List dataList) {
    return ListWidget.buildVerticalListView(
        itemCount: dataList.length,
        itemBuilder: (context, index) {
          return _buildListItemSection(
              index, dataList[index] as ComicsListModel);
        },
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics());
  }

  _buildListItemSection(int index, ComicsListModel comicsListModel) {
    return Column(
      children: [
        index == 0
            ? const SizedBox()
            : SpaceWidget(
                vSpace: DimenRes.dimen_10,
              ),
        Container(
          color: Colors.white.withOpacity(0.04),
          padding: EdgeInsets.only(
              left: DimenRes.dimen_15,
              top: DimenRes.dimen_15,
              right: DimenRes.dimen_15,
              bottom: DimenRes.dimen_15),
          child: InkWell(
            onTap: () {
              PageJumpUtil.forwardToComicsSeriesPage(context, comicsListModel);
            },
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Expanded(
                  child: TextWidget.buildSingleLineText(
                      '${comicsListModel.name}', AppTextStyle.white_s18),
                ),
                AppImgWidget(
                    path: ImgRes.IC_ARROW_RIGHT,
                    fit: BoxFit.contain,
                    height: DimenRes.dimen_18)
              ],
            ),
          ),
        ),
        Container(
            height: DimenRes.convert(175),
            width: DimenRes.screenWidth,
            color: Colors.white.withOpacity(0.04),
            padding: EdgeInsets.only(
                left: DimenRes.dimen_15, bottom: DimenRes.dimen_15),
            child: ListWidget.buildHorizontalListView(
                itemCount: comicsListModel.list!.length,
                itemBuilder: (context, index) =>
                    _buildSortListItem(comicsListModel.list![index])))
      ],
    );
  }

  _buildSortListItem(ComicsItemModel item) {
    return Row(
      children: [
        InkWell(
          onTap: () {
            PageJumpUtil.forwardToComicsDetailPage(context, item);
          },
          child: _buildComicsItem(item),
        ),
        const SpaceWidget(
          hSpace: 12,
        )
      ],
    );
  }

  _buildComicsItem(ComicsItemModel item) {
    return ComicsListItemWidget(
        itemData: item,
        imgWidth: DimenRes.dimen_100,
        imgHeight: DimenRes.dimen_135);
  }
}
