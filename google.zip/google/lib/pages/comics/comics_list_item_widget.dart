import 'package:flutter/material.dart';
import 'package:iaimei/model/comics_item_model.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/style/app_text_style.dart';
import 'package:iaimei/utils/badge_util.dart';
import 'package:iaimei/widget/network_img_container.dart';
import 'package:iaimei/widget/space_widget.dart';
import 'package:iaimei/widget/text_widget.dart';

class ComicsListItemWidget extends StatelessWidget {
  final ComicsItemModel itemData;
  final double imgWidth;
  final double imgHeight;

  const ComicsListItemWidget(
      {Key? key,
      required this.itemData,
      required this.imgWidth,
      required this.imgHeight})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: imgWidth,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Stack(
            children: [
              NetworkImgContainer(
                width: double.infinity,
                height: imgHeight,
                url: '${itemData.imgUrlFull}',
                radius: BorderRadius.circular(5),
              ),
              itemData.isType != 0
                  ? Positioned(
                      child: Image.asset(
                        BadgeUtil.getVideoTypeBadgeImgPath(itemData.isType??0),
                        fit: BoxFit.contain,
                        width: DimenRes.dimen_36,
                        height: DimenRes.dimen_18,
                      ),
                      right: DimenRes.dimen_5,
                      top: DimenRes.dimen_5,
                    )
                  : const SizedBox()
            ],
          ),
          const SpaceWidget(vSpace: 5),
          TextWidget.buildSingleLineText(
              '${itemData.title}', AppTextStyle.white_s12)
        ],
      ),
    );
  }
}
