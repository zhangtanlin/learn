import 'package:flutter/material.dart';
import 'package:iaimei/base/app_base_widget_state.dart';
import 'package:iaimei/mixin/list_page_load_mixin.dart';
import 'package:iaimei/model/comics_index_list_model.dart';
import 'package:iaimei/model/comics_item_model.dart';
import 'package:iaimei/model/comics_series_model.dart';
import 'package:iaimei/net/http_helper.dart';
import 'package:iaimei/pages/comics/comics_list_item_widget.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/utils/list_util.dart';
import 'package:iaimei/utils/page_jump_util.dart';
import 'package:iaimei/widget/app_page_title_bar.dart';
import 'package:iaimei/widget/list_widget.dart';
import 'package:iaimei/widget/refresh_load_list_widget.dart';

class ComicsSeriesListPage extends StatefulWidget {
  final ComicsListModel data;

  const ComicsSeriesListPage({Key? key, required this.data}) : super(key: key);

  @override
  State<ComicsSeriesListPage> createState() => _ComicsSeriesListPageState();
}

class _ComicsSeriesListPageState
    extends AppBaseWidgetState<ComicsSeriesListPage> with ListPageLoadMixin {
  @override
  buildAppBar() {
    return AppPageTitleBar.getNormalAppBar(title: widget.data.name);
  }

  @override
  void initState() {
    super.initState();
    onLoadData();
  }

  @override
  onLoadData() {
    onRefreshList();
  }

  @override
  int setPageSize() {
    return 12;
  }

  @override
  void requestListData(bool isRefresh) {
    HttpHelper.getComicsSeriesList('${widget.data.id}', getCurPage, getPageSize,
        (data) {
      ComicsSeriesModel comicsSeriesModel = ComicsSeriesModel.fromJson(data);
      setListPageState(isRefresh, ListUtil.isNotEmpty(comicsSeriesModel.list),
          () {
        updatePageList(isRefresh, comicsSeriesModel.list!);
      });
    }, (error) {
      setPageErrorState(error);
    });
  }

  @override
  Widget successView() {
    return RefreshLoadListWidget(
        enableLoad: isEnableLoad(),
        enableRefresh: isEnableRefresh(),
        onRefresh: onRefreshList,
        onLoad: onLoadList,
        child: Padding(
          padding: EdgeInsets.only(
              left: DimenRes.dimen_15,
              right: DimenRes.dimen_15,
              top: DimenRes.dimen_5),
          child: _buildSeriesGridView(getResultList),
        ),
        refreshController: refreshController);
  }

  @override
  Widget buildPageLayout() {
    return handlePageStateView();
  }

  _buildSeriesGridView(List resultList) {
    return ListWidget.buildGridView(
        itemCount: resultList.length,
        itemBuilder: (context, index) =>
            _buildComicsSeriesItem(resultList[index] as ComicsItemModel),
        childRatio: 0.618,
        mainSpace: DimenRes.dimen_15,
        crossSpace: DimenRes.dimen_15,
        crossCount: 3);
  }

  _buildComicsSeriesItem(ComicsItemModel itemModel) {
    double width = (DimenRes.screenWidth - DimenRes.dimen_60) / 3;
    double height = width * 7 / 5;
    return InkWell(
      onTap: () {
        PageJumpUtil.forwardToComicsDetailPage(context, itemModel);
      },
      child: ComicsListItemWidget(
          itemData: itemModel, imgWidth: width, imgHeight: height),
    );
  }
}
