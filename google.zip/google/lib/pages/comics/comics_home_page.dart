import 'package:flutter/material.dart';
import 'package:iaimei/base/app_base_widget_state.dart';
import 'package:iaimei/mixin/page_load_mixin.dart';
import 'package:iaimei/model/comics_index_model.dart';
import 'package:iaimei/net/http_error.dart';
import 'package:iaimei/net/http_helper.dart';
import 'package:iaimei/pages/comics/comics_home_sort_page.dart';
import 'package:iaimei/res/color_res.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/res/img_res.dart';
import 'package:iaimei/style/app_text_style.dart';
import 'package:iaimei/utils/list_util.dart';
import 'package:iaimei/utils/page_jump_util.dart';
import 'package:iaimei/widget/app_back_widget.dart';
import 'package:iaimei/widget/app_img_widget.dart';
import 'package:iaimei/widget/top_tab_navigator.dart';

import '../../model/tab_data.dart';

class ComicsHomePage extends StatefulWidget {
  const ComicsHomePage({Key? key}) : super(key: key);

  @override
  State<ComicsHomePage> createState() => _ComicsHomePageState();
}

class _ComicsHomePageState extends AppBaseWidgetState<ComicsHomePage>
    with PageLoadMixin {
  late TopTabNavConfig _tabNavConfig;
  late List<TabData> tabList;

  @override
  void initState() {
    super.initState();
    _tabNavConfig = TopTabNavConfig(
        tabHeight: DimenRes.dimen_44,
        selectedTextColor: ColorRes.color_30313f,
        isScrollable: false,
        textColor: ColorRes.color_30313f,
        navMargin:
            EdgeInsets.only(left: DimenRes.dimen_15, right: DimenRes.dimen_15),
        navTabMargin:
            EdgeInsets.only(left: DimenRes.dimen_20, right: DimenRes.dimen_20),
        textStyle: AppTextStyle.white_s14,
        selectedTextStyle: AppTextStyle.cff00b3_s18_bold,
        rightWidget: _buildSearchBtn(),
        leftWidget: _buildBackBtn());

    onLoadData();
  }

  _buildSearchBtn() {
    return AppImgWidget(
      path: ImgRes.IC_SEARCH,
      width: DimenRes.dimen_35,
      height: DimenRes.dimen_35,
      onTap: () {
        PageJumpUtil.forwardToSearchPage(context);
      },
    );
  }

  _buildBackBtn() {
    return const AppBackWidget();
  }

  @override
  Widget buildPageLayout() {
    return handlePageStateView();
  }

  @override
  onLoadData() {
    HttpHelper.getComicsIndex((data) {
      try {
        ComicsIndexModel comicsIndexModel = ComicsIndexModel.fromJson(data);
        tabList = comicsIndexModel.data!;
        setPageState(ListUtil.isNotEmpty(tabList));
      } catch (e) {
        setPageErrorState(HttpError());
      }
    }, (error) {
      setPageErrorState(error);
    });
  }

  @override
  Widget successView() {
    return TopTabNavigator(
      pages: tabList
          .map((item) => ComicsHomeSortPage(
                data: item,
              ))
          .toList(),
      config: _tabNavConfig,
      tabItems: tabList.map((item) => '${item.name}').toList(),
    );
  }
}
