import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:iaimei/app_const.dart';
import 'package:iaimei/base/app_base_widget_state.dart';
import 'package:iaimei/event/comics_read_config_change_event.dart';
import 'package:iaimei/global.dart';
import 'package:iaimei/mixin/page_load_mixin.dart';
import 'package:iaimei/model/comics_brief_model.dart';
import 'package:iaimei/model/comics_content_model.dart';
import 'package:iaimei/net/http_error.dart';
import 'package:iaimei/net/http_helper.dart';
import 'package:iaimei/pages/comics/comics_read_setting_page.dart';
import 'package:iaimei/res/color_res.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/res/img_res.dart';
import 'package:iaimei/res/string_res.dart';
import 'package:iaimei/style/app_text_style.dart';
import 'package:iaimei/utils/dialog_util.dart';
import 'package:iaimei/utils/eventbus_util.dart';
import 'package:iaimei/utils/list_util.dart';
import 'package:iaimei/utils/loading_util.dart';
import 'package:iaimei/utils/log_util.dart';
import 'package:iaimei/utils/page_jump_util.dart';
import 'package:iaimei/utils/unlock_check_util.dart';
import 'package:iaimei/widget/app_back_widget.dart';
import 'package:iaimei/widget/app_img_widget.dart';
import 'package:iaimei/widget/network_img_widget.dart';
import 'package:iaimei/widget/space_widget.dart';
import 'package:iaimei/widget/text_widget.dart';
import 'package:iaimei/widget/toast_widget.dart';
import 'package:iaimei/widget/transition_widget.dart';

enum LoadType { init, last, next }

class ComicsReader extends StatefulWidget {
  final ComicsBriefModel item;

  const ComicsReader({
    Key? key,
    required this.item,
  }) : super(key: key);

  @override
  State<ComicsReader> createState() => _ComicsReaderState();
}

class _ComicsReaderState extends AppBaseWidgetState<ComicsReader>
    with PageLoadMixin {
  List<ComicsContentItem> comicsContentList = [];

  bool isShow = true; //控制器的隐藏显示
  ScrollController? _controller;
  double _statusBarHeight = 0;

  late int _comicsId;
  late String _comicsTitle;
  late int _curEpisode;
  late int _totalEpisode;
  late String _updateInfo;

  int _curPage = 0;
  double _pageOffSet = 0;
  bool isAutoRead = false;
  Timer? _autoReadTimer;
  Timer? _watchRecordTimer;
  double _scrollOffset = 0;
  bool isReset = false;
  StreamSubscription<ComicsReadConfigChangeEvent>? _configChangeSubscription;
  int _readTime = 0;

  @override
  void initState() {
    super.initState();
    _statusBarHeight = ScreenUtil().statusBarHeight;

    _comicsId = widget.item.id;
    _comicsTitle = widget.item.title;
    _curEpisode = widget.item.episode;
    _totalEpisode = widget.item.totalEpisode;
    _updateInfo = widget.item.updateInfo;

    Map<dynamic, dynamic> readWayMap = AppGlobal.appBox!
        .get(AppConst.comicsReadWayKey, defaultValue: {
      AppConst.readTypeKey: AppConst.typeManualRead,
      AppConst.readTimeKey: 5
    });

    if (readWayMap[AppConst.readTypeKey] == AppConst.typeManualRead) {
      isAutoRead = false;
    } else {
      isAutoRead = true;
      _readTime = int.parse(readWayMap[AppConst.readTimeKey].toString());
    }

    _configChangeSubscription = EventBusUtil.listen((event) {
      if (event.way == TypeReadWay.auto) {
        isAutoRead = true;
        _readTime = event.time ?? 5;
        setState(() {});
      } else {
        isAutoRead = false;
        setState(() {});
      }
    });

    onLoadData();
  }

  @override
  onLoadData() {
    _getComicsContentAction();
  }

  void _getComicsContentAction(
      {LoadType loadType = LoadType.init, bool isShowLoad = false}) {
    if (isShowLoad) {
      LoadingUtil.showLoading();
    }
    HttpHelper.getComicContentImg('$_comicsId', '$_curEpisode', (data) {
      if (isShowLoad) {
        LoadingUtil.closeLoading();
      }
      try {
        ComicsContentModel contentModel = ComicsContentModel.fromJson(data);
        UnlockCheckUtil.comicsCheck(context, '$_comicsId', contentModel.payData,
            freeFunc: () {
          comicsContentList = contentModel.list!;
          setPageState(ListUtil.isNotEmpty(comicsContentList));
          if (ListUtil.isNotEmpty(comicsContentList)) {
            _curPage = 0;
            _pageOffSet = 0;
            _scrollOffset = 0;
            isReset = true;
            if (_controller != null) {
              _controller!.jumpTo(0);
            }
            _createScrollController();
            _watchRecordTimer ??= _createWatchRecordTimer();
          }
        }, buyVipFunc: () {
          _resetEpisode(loadType);
        }, payFunc: () {
          _resetEpisode(loadType);
        }, payFail: () {
          _quitRead(loadType);
        }, paySuccess: () {
          _quitRead(loadType);
        }, payCancel: () {
          _quitRead(loadType);
        });
      } catch (e) {
        setPageErrorState(HttpError());
      }
    }, (error) {
      if (isShowLoad) {
        LoadingUtil.closeLoading();
      }
      _resetEpisode(loadType);
      setPageErrorState(error);
    });
  }

  void _quitRead(LoadType loadType) {
    if (loadType == LoadType.init) {
      context.pop();
    }
  }

  void _resetEpisode(LoadType loadType) {
    if (loadType == LoadType.last) {
      _curEpisode = _curEpisode + 1;
    } else if (loadType == LoadType.next) {
      _curEpisode = _curEpisode - 1;
    }
  }

  void _createScrollController() {
    double recordOffSet = 0;
    try {
      dynamic recordData =
          AppGlobal.comicsWatchRecordBox?.get('$_comicsId', defaultValue: '');
      if (recordData == '') {
        recordOffSet = 0;
      } else {
        if (recordData['episode'] == _curEpisode) {
          recordOffSet = recordData['offset'];
        }
      }
    } catch (e) {
      e.toString();
    }
    _controller = ScrollController(
      initialScrollOffset: recordOffSet,
    );
    _scrollOffset = recordOffSet;
    //监听滚动事件，打印滚动位置
    _controller!.addListener(() {
      if (isShow) {
        if (isReset) {
          isReset = false;
          return;
        }
        setState(() {
          isShow = false;
        });
      }
      _scrollOffset = _controller!.offset;
      // LogUtil.i("-----_scrollOffset------$_scrollOffset");
    });
  }

  @override
  bool isShowSafeArea() {
    return false;
  }

  @override
  Widget successView() {
    return Stack(
      children: [
        InkWell(
          child: _buildContentListView(),
          onTap: () {
            _toggleStateAction();
          },
        ),
        _buildContentAboveSection()
      ],
    );
  }

  void _toggleStateAction() {
    setState(() {
      isShow = !isShow;
      if (isShow) {
        if (isAutoRead && _autoReadTimer != null && _autoReadTimer!.isActive) {
          _autoReadTimer!.cancel();
        }
      } else {
        if (isAutoRead) {
          _autoReadTimer = _createAutoReadTimer();
        }
      }
    });
  }

  double getContentImgHeight(List<ComicsContentItem> imgList, int index) {
    double imgHeight = 0;
    int size = ListUtil.size(imgList);
    if (size > 0 && index < size) {
      ComicsContentItem comicsContentItem = imgList[index];

      double imgWidth = DimenRes.screenWidth;

      String tempWidthStr = comicsContentItem.imgWidth == null ||
              comicsContentItem.imgWidth == '' ||
              comicsContentItem.imgWidth == '0'
          ? '${DimenRes.screenWidth}'
          : comicsContentItem.imgWidth!;

      String tempHeightStr = comicsContentItem.imgHeight == null ||
              comicsContentItem.imgHeight == '' ||
              comicsContentItem.imgHeight == '0'
          ? '${DimenRes.screenHeight}'
          : comicsContentItem.imgHeight!;

      imgHeight =
          imgWidth * double.parse(tempHeightStr) / double.parse(tempWidthStr);
    }
    return imgHeight;
  }

  int getCurIndex(List<ComicsContentItem> imgList, double offset) {
    int curIndex = 0;
    double totalHeight = 0;
    bool geFirst;
    bool leLast;
    for (int i = 0; i < ListUtil.size(imgList); i++) {
      geFirst = false;
      leLast = false;
      if (offset >= totalHeight) {
        geFirst = true;
      }
      totalHeight = totalHeight + getContentImgHeight(imgList, i);
      if (offset <= totalHeight) {
        leLast = true;
      }
      if (geFirst && leLast) {
        curIndex = i;
      }
    }
    return curIndex;
  }

  double getCurOffset(List<ComicsContentItem> imgList, int curPage) {
    double offset = 0;
    for (int i = 0; i < curPage; i++) {
      offset = offset + getContentImgHeight(imgList, i);
    }
    return offset;
  }

  Timer _createAutoReadTimer() {
    return Timer.periodic(Duration(seconds: _readTime), (timer) {
      if (_pageOffSet != _scrollOffset) {
        _curPage = getCurIndex(comicsContentList, _scrollOffset);
        _pageOffSet = getCurOffset(comicsContentList, _curPage);
      }

      if (_curPage + 1 < ListUtil.size(comicsContentList)) {
        _curPage++;
        double imgHeight = getContentImgHeight(comicsContentList, _curPage);
        _pageOffSet = _pageOffSet + imgHeight;
        _controller!.animateTo(_pageOffSet,
            duration: const Duration(seconds: 1), curve: Curves.ease);
        // _controller.jumpTo(_pageOffSet);
        LogUtil.i("_pageOffSet-----$_pageOffSet------");
        LogUtil.i("_curPage-----$_curPage------");
      } else {
        if (_autoReadTimer!.isActive) {
          _autoReadTimer!.cancel();
        }
      }
    });
  }

  Timer _createWatchRecordTimer() {
    return Timer.periodic(const Duration(seconds: 2), (timer) {
      Map readRecordMap = {
        'id': _comicsId,
        'title': _comicsTitle,
        'episode': _curEpisode,
        'offset': _scrollOffset
      };
      LogUtil.i("readRecordMap-------->$readRecordMap");
      AppGlobal.comicsWatchRecordBox!.put('$_comicsId', readRecordMap);
    });
  }

  @override
  void dispose() {
    //为了避免内存泄露，需要调用_controller.dispose
    if (_controller != null) {
      _controller!.dispose();
    }
    if (_configChangeSubscription != null) {
      _configChangeSubscription!.cancel();
    }
    if (_watchRecordTimer != null && _watchRecordTimer!.isActive) {
      _watchRecordTimer!.cancel();
    }
    if (_autoReadTimer != null && _autoReadTimer!.isActive) {
      _autoReadTimer!.cancel();
    }
    super.dispose();
  }

  _buildContentAboveSection() {
    return Positioned(
        bottom: 0,
        left: 0,
        right: 0,
        top: 0,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            TransitionWidget(
                height: DimenRes.dimen_50 + _statusBarHeight,
                top: isShow ? 0 : -(DimenRes.dimen_50 + _statusBarHeight),
                opacity: isShow ? 1 : 0,
                child: _buildTitleSection(),
                time: 500),
            isShow
                ? isAutoRead
                    ? AppImgWidget(
                        path: ImgRes.IC_COMICS_PLAY,
                        width: DimenRes.dimen_50,
                        height: DimenRes.dimen_50,
                        onTap: () {
                          _toggleStateAction();
                        },
                      )
                    : const SizedBox()
                : const SizedBox(),
            TransitionWidget(
              height: DimenRes.dimen_150,
              bottom: isShow ? 0 : -DimenRes.dimen_150,
              opacity: isShow ? 1 : 0,
              time: 500,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [_buildLikeAndShareBtn(), _buildBottomMenu()],
              ),
            )
          ],
        ));
  }

  _buildTitleSection() {
    return Container(
      height: DimenRes.dimen_50 + _statusBarHeight,
      width: DimenRes.screenWidth,
      color: ColorRes.color_d71a152f,
      alignment: Alignment.centerLeft,
      padding: EdgeInsets.only(top: _statusBarHeight),
      child: Row(
        children: [
          Padding(
            padding: EdgeInsets.symmetric(horizontal: DimenRes.dimen_10),
            child: const AppBackWidget(),
          ),
          Expanded(
              child: Container(
                  alignment: Alignment.center,
                  child: TextWidget.buildSingleLineText(
                      _comicsTitle, AppTextStyle.white_s16))),
          SizedBox(
            width: DimenRes.dimen_50,
          )
        ],
      ),
    );
  }

  _buildBottomMenu() {
    return Container(
      height: DimenRes.dimen_90,
      width: DimenRes.screenWidth,
      color: ColorRes.color_d71a152f,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          InkWell(
            child: TextWidget.buildSingleLineText(
              StringRes.str_last_episode,
              AppTextStyle.white_s12,
            ),
            onTap: () {
              if (_curEpisode == 1) {
                ToastWidget.showToast(StringRes.str_already_first_episode,
                    align: Alignment.center);
                return;
              }
              _curEpisode = _curEpisode - 1;
              _getNewEpisodeData(loadType: LoadType.last);
            },
          ),
          InkWell(
            child: TextWidget.buildSingleLineText(
              StringRes.str_catalog,
              AppTextStyle.white_s14_bold,
            ),
            onTap: () {
              DialogUtil.showComicsCatalogListDialog(
                  context, '$_comicsId', _updateInfo, (itemModel) {
                if (_curEpisode == itemModel.episode) {
                  return;
                }
                UnlockCheckUtil.comicsCheck(
                    context, '$_comicsId', itemModel.payData, freeFunc: () {
                  _curEpisode = itemModel.episode ?? 1;
                  _getNewEpisodeData();
                });
              });
            },
          ),
          InkWell(
            child: TextWidget.buildSingleLineText(
              StringRes.str_next_episode,
              AppTextStyle.white_s12,
            ),
            onTap: () {
              if (_curEpisode == _totalEpisode) {
                ToastWidget.showToast(StringRes.str_already_last_episode,
                    align: Alignment.center);
                return;
              }
              _curEpisode = _curEpisode + 1;
              _getNewEpisodeData(loadType: LoadType.next);
            },
          ),
          InkWell(
            child: TextWidget.buildSingleLineText(
              StringRes.str_setting,
              AppTextStyle.build(ColorRes.color_ff00b3, 12),
            ),
            onTap: () {
              DialogUtil.showBottomDialog(
                  context: context,
                  height: DimenRes.dimen_300,
                  child: ComicsReadSettingPage());
            },
          )
        ],
      ),
    );
  }

  void _getNewEpisodeData({LoadType loadType = LoadType.init}) {
    _getComicsContentAction(loadType: loadType, isShowLoad: true);
  }

  _buildLikeAndShareBtn() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        Container(
          margin: EdgeInsets.only(
              right: DimenRes.dimen_15, bottom: DimenRes.dimen_15),
          padding: EdgeInsets.symmetric(
              horizontal: DimenRes.dimen_12, vertical: DimenRes.dimen_3),
          decoration: BoxDecoration(
              color: ColorRes.color_d71a152f,
              borderRadius: BorderRadius.circular(28)),
          child: Row(
            children: [
              AppImgWidget(
                path: ImgRes.IC_READER_LIKE,
                width: DimenRes.dimen_30,
                height: DimenRes.dimen_30,
                onTap: () {
                  _likeComicsItemAction();
                },
              ),
              const SpaceWidget(
                hSpace: 10,
              ),
              AppImgWidget(
                path: ImgRes.IC_READER_SHARE,
                width: DimenRes.dimen_30,
                height: DimenRes.dimen_30,
                onTap: () {
                  PageJumpUtil.forwardToSharePage(context);
                },
              ),
            ],
          ),
        )
      ],
    );
  }

  _likeComicsItemAction() {
    LoadingUtil.showLoading();
    HttpHelper.likeComics('$_comicsId', (data) {
      LoadingUtil.closeLoading();
      if (data != null && data is String && data.isNotEmpty) {
        ToastWidget.showToast(data, align: Alignment.center);
      }
    }, (error) {
      LoadingUtil.closeLoading();
      ToastWidget.showToast(StringRes.str_operate_fail,
          align: Alignment.center);
    });
  }

  ListView _buildContentListView() {
    return ListView.builder(
      itemCount: ListUtil.size(comicsContentList),
      shrinkWrap: true,
      controller: _controller,
      scrollDirection: Axis.vertical,
      physics: const ClampingScrollPhysics(),
      cacheExtent: DimenRes.screenHeight * 5,
      padding: EdgeInsets.zero,
      itemBuilder: (context, index) {
        return _buildContentItemSection(comicsContentList[index]);
      },
    );
  }

  _buildContentItemSection(ComicsContentItem contentItem) {
    double imgWidth = DimenRes.screenWidth;
    double imgHeight = 0;

    if (contentItem.imgWidth == '' ||
        contentItem.imgWidth == '0' ||
        contentItem.imgHeight == '' ||
        contentItem.imgHeight == '0') {
      imgHeight = imgWidth;
    } else {
      imgHeight = imgWidth *
          int.parse(contentItem.imgHeight!) /
          int.parse(contentItem.imgWidth!);
    }

    return SizedBox(
      width: imgWidth,
      height: imgHeight,
      child: NetworkImgWidget(
        noVisibilityDetector: true,
        url: contentItem.imgUrlFull,
        filterQuality: FilterQuality.medium,
        fit: BoxFit.fitWidth,
      ),
    );
  }

  @override
  Widget buildPageLayout() {
    return handlePageStateView();
  }
}
