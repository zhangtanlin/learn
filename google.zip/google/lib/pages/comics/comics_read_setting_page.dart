import 'package:flutter/material.dart';
import 'package:iaimei/app_const.dart';
import 'package:iaimei/event/comics_read_config_change_event.dart';
import 'package:iaimei/global.dart';
import 'package:iaimei/res/color_res.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/res/img_res.dart';
import 'package:iaimei/res/string_res.dart';
import 'package:iaimei/style/app_text_style.dart';
import 'package:iaimei/utils/eventbus_util.dart';
import 'package:iaimei/widget/app_back_widget.dart';
import 'package:iaimei/widget/app_img_widget.dart';
import 'package:iaimei/widget/space_widget.dart';
import 'package:iaimei/widget/text_widget.dart';

enum TypeReadWay { auto, manual }

class ComicsReadSettingPage extends StatefulWidget {
  const ComicsReadSettingPage({Key? key}) : super(key: key);

  @override
  State<ComicsReadSettingPage> createState() => _ComicsReadSettingPageState();
}

class _ComicsReadSettingPageState extends State<ComicsReadSettingPage> {
  double _value = 1;
  double minValue = 1;
  double maxValue = 10;
  TypeReadWay _typeReadWay = TypeReadWay.manual;

  @override
  void initState() {
    super.initState();
    Map<dynamic, dynamic> readWayMap = AppGlobal.appBox!
        .get(AppConst.comicsReadWayKey, defaultValue: {
      AppConst.readTypeKey: AppConst.typeManualRead,
      AppConst.readTimeKey: 5
    });

    if (readWayMap[AppConst.readTypeKey] == AppConst.typeManualRead) {
      _typeReadWay = TypeReadWay.manual;
      _value = double.parse(readWayMap[AppConst.readTimeKey].toString());
    } else {
      _typeReadWay = TypeReadWay.auto;
      _value = double.parse(readWayMap[AppConst.readTimeKey].toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildTitleSection(context),
        Padding(
          padding: EdgeInsets.symmetric(
              horizontal: DimenRes.dimen_15, vertical: DimenRes.dimen_20),
          child: TextWidget.buildSingleLineText(
              StringRes.str_read_way, AppTextStyle.white_s16),
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            InkWell(
              child: TextWidget.buildSingleLineText(
                  StringRes.str_auto_read,
                  _typeReadWay == TypeReadWay.auto
                      ? AppTextStyle.build(ColorRes.color_ff00b3, 15)
                      : AppTextStyle.white_s15),
              onTap: () {
                setState(() {
                  _typeReadWay = TypeReadWay.auto;
                  _setReadWayAction(_typeReadWay, _value);
                });
              },
            ),
            InkWell(
              child: TextWidget.buildSingleLineText(
                  StringRes.str_manual_read,
                  _typeReadWay == TypeReadWay.manual
                      ? AppTextStyle.build(ColorRes.color_ff00b3, 15)
                      : AppTextStyle.white_s15),
              onTap: () {
                setState(() {
                  _typeReadWay = TypeReadWay.manual;
                  _setReadWayAction(_typeReadWay, _value);
                });
              },
            ),
          ],
        ),
        Padding(
          padding: EdgeInsets.symmetric(
              horizontal: DimenRes.dimen_15, vertical: DimenRes.dimen_20),
          child: TextWidget.buildSingleLineText(
              StringRes.str_read_speed,
              _typeReadWay == TypeReadWay.auto
                  ? AppTextStyle.white_s16
                  : AppTextStyle.build(ColorRes.color_575464, 16)),
        ),
        Container(
          alignment: Alignment.center,
          padding: EdgeInsets.symmetric(
              horizontal: DimenRes.dimen_15, vertical: DimenRes.dimen_5),
          child: TextWidget.buildSingleLineText(
              '${_value.toInt()}S',
              _typeReadWay == TypeReadWay.auto
                  ? AppTextStyle.white_s12
                  : AppTextStyle.build(ColorRes.color_575464, 12)),
        ),
        Padding(
          padding: EdgeInsets.symmetric(horizontal: DimenRes.dimen_20),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              AppImgWidget(
                path: _typeReadWay == TypeReadWay.auto
                    ? ImgRes.IC_MINUS
                    : ImgRes.IC_MINUS_INACTIVE,
                width: DimenRes.dimen_15,
                height: DimenRes.dimen_15,
                onTap: () {
                  if (_typeReadWay == TypeReadWay.auto) {
                    if (_value <= minValue) return;
                    setState(() {
                      _value--;
                      _setReadWayAction(_typeReadWay, _value);
                    });
                  }
                },
              ),
              Expanded(
                  child: Padding(
                padding: EdgeInsets.symmetric(horizontal: DimenRes.dimen_15),
                child: _buildSliderSection(context),
              )),
              AppImgWidget(
                path: _typeReadWay == TypeReadWay.auto
                    ? ImgRes.IC_ADD
                    : ImgRes.IC_ADD_INACTIVE,
                width: DimenRes.dimen_15,
                height: DimenRes.dimen_15,
                onTap: () {
                  if (_typeReadWay == TypeReadWay.auto) {
                    if (_value >= maxValue) return;
                    setState(() {
                      _value++;
                      _setReadWayAction(_typeReadWay, _value);
                    });
                  }
                },
              ),
            ],
          ),
        )
      ],
    );
  }

  void _setReadWayAction(TypeReadWay typeReadWay, double time) {
    Map readMap = {
      AppConst.readTypeKey: typeReadWay == TypeReadWay.auto
          ? AppConst.typeAutoRead
          : AppConst.typeManualRead,
      AppConst.readTimeKey: time.toInt()
    };
    AppGlobal.appBox!.put(AppConst.comicsReadWayKey, readMap);
    EventBusUtil.fire(ComicsReadConfigChangeEvent(typeReadWay, time.toInt()));
  }

  SliderTheme _buildSliderSection(BuildContext context) {
    return SliderTheme(
      data: SliderTheme.of(context).copyWith(
        trackHeight: 2,
        // 轨道高度
        trackShape: const RectangularSliderTrackShape(),
        // 轨道形状，可以自定义
        activeTrackColor: _typeReadWay == TypeReadWay.auto
            ? ColorRes.color_ff00b3
            : ColorRes.color_575464,
        // 激活的轨道颜色
        inactiveTrackColor: _typeReadWay == TypeReadWay.auto
            ? Colors.white
            : ColorRes.color_37334a,
        // 未激活的轨道颜色
        thumbShape: const RoundSliderThumbShape(
            //  滑块形状，可以自定义
            enabledThumbRadius: 5 // 滑块大小
            ),
        thumbColor: _typeReadWay == TypeReadWay.auto
            ? Colors.white
            : ColorRes.color_575464,
        // 滑块颜色
        overlayShape: const RoundSliderOverlayShape(
          // 滑块外圈形状，可以自定义
          overlayRadius: 10, // 滑块外圈大小
        ),
        overlayColor: _typeReadWay == TypeReadWay.auto
            ? Colors.white54
            : ColorRes.color_37334a,
        // 滑块外圈颜色
        valueIndicatorShape: const RoundSliderOverlayShape(),
        // showValueIndicator: ShowValueIndicator.onlyForContinuous,
        // valueIndicatorColor: Colors.green,
        // valueIndicatorTextStyle: const TextStyle(
        //   color: Colors.green,
        // ),
        // // 标签形状，可以自定义
        // activeTickMarkColor: Colors.red, // 激活的刻度颜色
      ),
      child: Slider(
          value: _value,
          min: minValue,
          max: maxValue,
          label: '',
          onChanged: (value) {}),
    );
  }

  _buildTitleSection(BuildContext context) {
    return Container(
      height: DimenRes.dimen_50,
      decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.12),
          borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(8), topRight: Radius.circular(8))),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Padding(
            padding: const EdgeInsets.all(10),
            child: AppBackWidget(
              onTap: () {
                Navigator.pop(context);
              },
            ),
          ),
          TextWidget.buildSingleLineText(
            StringRes.str_setting,
            AppTextStyle.white_s14,
          ),
          SizedBox(
            width: DimenRes.dimen_50,
          )
        ],
      ),
    );
  }
}
