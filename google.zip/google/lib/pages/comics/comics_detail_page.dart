import 'package:flutter/material.dart';
import 'package:iaimei/base/app_base_widget_state.dart';
import 'package:iaimei/global.dart';
import 'package:iaimei/mixin/page_load_mixin.dart';
import 'package:iaimei/model/comics_brief_model.dart';
import 'package:iaimei/model/comics_catalog_item_model.dart';
import 'package:iaimei/model/comics_detail_model.dart';
import 'package:iaimei/model/comics_item_model.dart';
import 'package:iaimei/net/http_error.dart';
import 'package:iaimei/net/http_helper.dart';
import 'package:iaimei/pages/comics/comics_list_item_widget.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/res/img_res.dart';
import 'package:iaimei/res/string_res.dart';
import 'package:iaimei/style/app_text_style.dart';
import 'package:iaimei/utils/dialog_util.dart';
import 'package:iaimei/utils/list_util.dart';
import 'package:iaimei/utils/page_jump_util.dart';
import 'package:iaimei/utils/string_util.dart';
import 'package:iaimei/utils/unlock_check_util.dart';
import 'package:iaimei/widget/app_divider_widget.dart';
import 'package:iaimei/widget/app_img_widget.dart';
import 'package:iaimei/widget/app_page_title_bar.dart';
import 'package:iaimei/widget/list_widget.dart';
import 'package:iaimei/widget/network_img_container.dart';
import 'package:iaimei/widget/space_widget.dart';
import 'package:iaimei/widget/text_widget.dart';

class ComicsDetailPage extends StatefulWidget {
  final ComicsItemModel item;

  const ComicsDetailPage({Key? key, required this.item}) : super(key: key);

  @override
  State<ComicsDetailPage> createState() => _ComicsDetailPageState();
}

class _ComicsDetailPageState extends AppBaseWidgetState<ComicsDetailPage>
    with PageLoadMixin {
  late ComicsItemModel _itemModel;
  late ComicsDetailModel _detailModel;
  List<ComicsItemModel> comicsItemList = [];

  @override
  void initState() {
    super.initState();
    _itemModel = widget.item;
    onLoadData();
  }

  @override
  buildAppBar() {
    return AppPageTitleBar.getNormalAppBar();
  }

  @override
  onLoadData() {
    _getComicsDetailAction();
  }

  void _getComicsDetailAction({bool isInit = true}) {
    HttpHelper.getComicsDetail("${_itemModel.id}", (data) {
      try {
        _detailModel = ComicsDetailModel.fromJson(data);
        setPageState(_detailModel.detail != null &&
            ListUtil.isNotEmpty(_detailModel.comicsSeries));
        if (isInit) {
          getComicsMore();
        }
      } catch (e) {
        if (isInit) {
          setPageErrorState(HttpError());
        }
      }
    }, (error) {
      if (isInit) {
        setPageErrorState(error);
      }
    });
  }

  void getComicsMore() {
    HttpHelper.getComicsMore("${_itemModel.id}", (data) {
      try {
        comicsItemList = (data as List)
            .map((json) => ComicsItemModel.fromJson(json))
            .toList();
        setState(() {});
      } catch (e) {
        e.toString();
      }
    }, (error) {});
  }

  @override
  Widget successView() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildTopCoverSection(),
          _buildCatalogTitleSection(),
          _buildCatalogSection(),
          _buildKeepWatchBtn(),
          AppDividerWidget(
              padding: EdgeInsets.only(
                  left: DimenRes.dimen_15, right: DimenRes.dimen_15)),
          _buildYouMayLikeSection()
        ],
      ),
    );
  }

  _buildKeepWatchBtn() {
    dynamic tempData = AppGlobal.comicsWatchRecordBox
        ?.get('${_detailModel.detail?.id}', defaultValue: '');
    return tempData != null && tempData != ''
        ? InkWell(
            onTap: () {
              PageJumpUtil.forwardToComicsReaderPage(
                  context,
                  widget.item,
                  ComicsBriefModel(
                      _detailModel.detail!.id!,
                      tempData['episode'],
                      _detailModel.total ?? 1,
                      _detailModel.detail?.title ?? '',
                      _detailModel.detail?.updateInfo ?? ''));
            },
            child: Container(
              alignment: Alignment.center,
              margin: EdgeInsets.only(bottom: DimenRes.dimen_15),
              child: Stack(
                children: [
                  AppImgWidget(
                    path: ImgRes.IMG_BG_BTN,
                    height: DimenRes.dimen_44,
                  ),
                  Positioned.fill(
                      left: 20,
                      right: 20,
                      top: 6,
                      bottom: 10,
                      child: Container(
                        alignment: Alignment.center,
                        child: TextWidget.buildSingleLineText(
                            '继续观看  第 ${tempData['episode']} 话',
                            AppTextStyle.white_s12),
                      )),
                ],
              ),
            ),
          )
        : const SizedBox();
  }

  @override
  Widget buildPageLayout() {
    return handlePageStateView();
  }

  _buildCatalogSection() {
    double width = (DimenRes.screenWidth - DimenRes.dimen_105) / 8;
    double height = width;

    List<ComicsCatalogItemModel> catalogList = _detailModel.comicsSeries!;
    List mixList = [];
    try {
      if (catalogList.isNotEmpty) {
        if (_detailModel.total! > 8) {
          if (catalogList.length > 6) {
            List fList = catalogList.sublist(0, 6);
            List bList = catalogList.sublist(6, 7);
            mixList = [...fList, "...", ...bList];
          } else {
            mixList = catalogList;
          }
        } else {
          mixList = catalogList;
        }
      }
    } catch (e) {
      e.toString();
    }
    return mixList.isNotEmpty
        ? Container(
            margin: EdgeInsets.symmetric(
                vertical: DimenRes.dimen_20, horizontal: DimenRes.dimen_15),
            child: Wrap(
                runSpacing: DimenRes.dimen_10,
                spacing: DimenRes.dimen_10,
                children: mixList.map((item) {
                  return InkWell(
                    onTap: () {
                      if (item is ComicsCatalogItemModel) {
                        UnlockCheckUtil.comicsCheck(
                            context,
                            '${_detailModel.detail!.id!}',
                            item.payData, freeFunc: () {
                          PageJumpUtil.forwardToComicsReaderPage(
                              context,
                              widget.item,
                              ComicsBriefModel(
                                  _detailModel.detail!.id!,
                                  item.episode ?? 1,
                                  _detailModel.total ?? 1,
                                  _detailModel.detail?.title ?? '',
                                  _detailModel.detail?.updateInfo ?? ''));
                        }, paySuccess: () {
                          _getComicsDetailAction(isInit: false);
                        });
                      } else {
                        _showCatalogDialog();
                      }
                    },
                    child: Container(
                      decoration: BoxDecoration(
                        color: Colors.white12,
                        borderRadius: BorderRadius.circular(6),
                      ),
                      alignment: Alignment.center,
                      width: width,
                      height: height,
                      child: TextWidget.buildSingleLineText(
                          item is ComicsCatalogItemModel
                              ? '${item.episode}'
                              : item,
                          AppTextStyle.white_s12),
                    ),
                  );
                }).toList()),
          )
        : const SizedBox();
  }

  _buildYouMayLikeSection() {
    return ListUtil.isNotEmpty(comicsItemList)
        ? Container(
            margin: EdgeInsets.only(
                left: DimenRes.dimen_15,
                right: DimenRes.dimen_15,
                bottom: DimenRes.dimen_20,
                top: DimenRes.dimen_20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextWidget.buildSingleLineText(
                    StringRes.str_you_may_like, AppTextStyle.white_s18),
                const SpaceWidget(vSpace: 10),
                _buildSeriesGridView(comicsItemList)
              ],
            ),
          )
        : const SizedBox();
  }

  _buildSeriesGridView(List resultList) {
    return ListWidget.buildGridView(
        itemCount: resultList.length,
        itemBuilder: (context, index) =>
            _buildComicsSeriesItem(resultList[index] as ComicsItemModel),
        childRatio: 0.618,
        mainSpace: DimenRes.dimen_15,
        crossSpace: DimenRes.dimen_15,
        crossCount: 3);
  }

  _buildComicsSeriesItem(ComicsItemModel itemModel) {
    double width = (DimenRes.screenWidth - DimenRes.dimen_60) / 3;
    double height = width * 7 / 5;
    return InkWell(
      child: ComicsListItemWidget(
          itemData: itemModel, imgWidth: width, imgHeight: height),
      onTap: () {
        _itemModel = itemModel;
        onLoadData();
      },
    );
  }

  _buildCatalogTitleSection() {
    return InkWell(
      onTap: () {
        _showCatalogDialog();
      },
      child: Container(
        margin: EdgeInsets.only(
            left: DimenRes.dimen_15,
            right: DimenRes.dimen_15,
            top: DimenRes.dimen_30),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            TextWidget.buildSingleLineText(
                StringRes.str_catalog, AppTextStyle.white_s16),
            TextWidget.buildSingleLineText(
                '${_detailModel.detail?.updateInfo}', AppTextStyle.white_s13),
            AppImgWidget(
              path: ImgRes.IC_ARROW_RIGHT,
              height: DimenRes.dimen_16,
            )
          ],
        ),
      ),
    );
  }

  void _showCatalogDialog() {
    DialogUtil.showComicsCatalogListDialog(
        context, '${_detailModel.detail?.id}', _detailModel.detail?.updateInfo,
        (item) {
      UnlockCheckUtil.comicsCheck(
          context, '${_detailModel.detail?.id}', item.payData, freeFunc: () {
        PageJumpUtil.forwardToComicsReaderPage(
            context,
            widget.item,
            ComicsBriefModel(
                _detailModel.detail!.id!,
                item.episode ?? 1,
                _detailModel.total ?? 1,
                _detailModel.detail?.title ?? '',
                _detailModel.detail?.updateInfo ?? ''));
      }, paySuccess: () {
        _getComicsDetailAction(isInit: false);
      });
    });
  }

  Container _buildTopCoverSection() {
    String bgImgUrl = _detailModel.detail?.bgThumbFull ?? "";
    String imgUrl = _detailModel.detail?.thumbFull ?? "";
    bgImgUrl = StringUtil.isNotEmpty(bgImgUrl) ? bgImgUrl : imgUrl;
    return Container(
      margin: EdgeInsets.only(
          left: DimenRes.dimen_15,
          right: DimenRes.dimen_15,
          top: DimenRes.dimen_5),
      child: Stack(
        children: [
          Opacity(
              opacity: 0.16,
              child: NetworkImgContainer(
                  url: bgImgUrl,
                  height: DimenRes.dimen_160,
                  radius: BorderRadius.circular(10))),
          Positioned(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                NetworkImgContainer(
                    url: imgUrl,
                    width: DimenRes.dimen_105,
                    height: DimenRes.dimen_140,
                    radius: BorderRadius.circular(10)),
                Expanded(
                    child: Container(
                  margin: EdgeInsets.only(left: DimenRes.dimen_15),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      TextWidget.buildSingleLineText(
                          '${_detailModel.detail?.title}',
                          AppTextStyle.white_s16),
                      const Spacer(),
                      TextWidget.buildSingleLineText(
                          '阅览${_detailModel.detail?.viewCount ?? 0}',
                          AppTextStyle.white_s12)
                    ],
                  ),
                ))
              ],
            ),
            left: DimenRes.dimen_10,
            right: DimenRes.dimen_10,
            top: DimenRes.dimen_10,
            bottom: DimenRes.dimen_10,
          )
        ],
      ),
    );
  }

  @override
  void dispose() {
    super.dispose();
    HttpHelper.cancelComicsDetail();
    HttpHelper.cancelComicsMore();
  }
}
