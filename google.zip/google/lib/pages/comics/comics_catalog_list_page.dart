import 'package:flutter/material.dart';
import 'package:iaimei/mixin/list_page_load_mixin.dart';
import 'package:iaimei/model/comics_catalog_item_model.dart';
import 'package:iaimei/net/http_helper.dart';
import 'package:iaimei/res/color_res.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/style/app_text_style.dart';
import 'package:iaimei/utils/list_util.dart';
import 'package:iaimei/widget/app_back_widget.dart';
import 'package:iaimei/widget/list_widget.dart';
import 'package:iaimei/widget/refresh_load_list_widget.dart';
import 'package:iaimei/widget/text_widget.dart';

typedef ComicsCatalogItemCallback = void Function(
    ComicsCatalogItemModel itemModel);

class ComicsCatalogListPage extends StatefulWidget {
  final String id;
  final String? info;
  final ComicsCatalogItemCallback? callback;

  const ComicsCatalogListPage(
      {Key? key, required this.id, this.info, this.callback})
      : super(key: key);

  @override
  State<ComicsCatalogListPage> createState() => _ComicsCatalogListPageState();
}

class _ComicsCatalogListPageState extends State<ComicsCatalogListPage>
    with ListPageLoadMixin {
  List<ComicsCatalogItemModel> _catalogList = [];

  @override
  void initState() {
    super.initState();
    onLoadData();
  }

  @override
  onLoadData() {
    onRefreshList();
  }

  @override
  void requestListData(bool isRefresh) {
    HttpHelper.getComicsCatalogList(widget.id, getCurPage, getPageSize, (data) {
      _catalogList = (data as List)
          .map((json) => ComicsCatalogItemModel.fromJson(json))
          .toList();
      setListPageState(isRefresh, ListUtil.isNotEmpty(_catalogList), () {
        updatePageList(isRefresh, _catalogList);
      });
    }, (error) {
      setListPageErrorState(isRefresh, error);
    });
  }

  @override
  int setPageSize() {
    return 50;
  }

  @override
  Widget successView() {
    return Column(
      children: [_buildTitleSection(context), _buildListSection()],
    );
  }

  @override
  Widget build(BuildContext context) {
    return handlePageStateView();
  }

  Expanded _buildListSection() {
    return Expanded(
        child: Container(
      color: ColorRes.color_1a152f,
      padding: EdgeInsets.all(DimenRes.dimen_10),
      child: RefreshLoadListWidget(
        onRefresh: onRefreshList,
        onLoad: onLoadList,
        refreshController: refreshController,
        child: _buildCatalogListSection(getResultList),
      ),
    ));
  }

  _buildCatalogListSection(List resultList) {
    return ListWidget.buildGridView(
        itemCount: resultList.length,
        childRatio: 1,
        crossCount: 7,
        mainSpace: DimenRes.dimen_10,
        crossSpace: DimenRes.dimen_10,
        itemBuilder: (BuildContext context, int index) {
          return InkWell(
            onTap: () {
              Navigator.pop(context);
              if (widget.callback != null) {
                widget.callback!(resultList[index] as ComicsCatalogItemModel);
              }
            },
            child:
                _buildCatalogItem(resultList[index] as ComicsCatalogItemModel),
          );
        });
  }

  Container _buildCatalogItem(ComicsCatalogItemModel catalogItemModel) {
    return Container(
      alignment: Alignment.center,
      decoration: BoxDecoration(
          color: ColorRes.color_15fff,
          borderRadius: BorderRadius.circular(DimenRes.dimen_8)),
      child: TextWidget.buildSingleLineText(
        "${catalogItemModel.episode}",
        AppTextStyle.white_s14,
      ),
    );
  }

  _buildTitleSection(BuildContext context) {
    return Container(
      height: DimenRes.dimen_50,
      decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.12),
          borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(8), topRight: Radius.circular(8))),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Padding(
            padding: const EdgeInsets.all(10),
            child: AppBackWidget(
              onTap: () {
                Navigator.pop(context);
              },
            ),
          ),
          TextWidget.buildSingleLineText(
            widget.info ?? '',
            AppTextStyle.white_s14,
          ),
          SizedBox(
            width: DimenRes.dimen_50,
          )
        ],
      ),
    );
  }
}
