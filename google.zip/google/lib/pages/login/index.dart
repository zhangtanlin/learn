import 'package:bot_toast/bot_toast.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:iaimei/components/common/base_dialog.dart';
import 'package:iaimei/global.dart';
import 'package:iaimei/model/basic.dart';
import 'package:iaimei/router/routers.dart';
import 'package:iaimei/theme/default.dart';
import 'package:hive/hive.dart';
import 'package:iaimei/utils/api.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({Key? key}) : super(key: key);

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  // 用户名
  TextEditingController nameController = TextEditingController();
  // 密码
  TextEditingController pwdController = TextEditingController();
  // 是否显示密码
  bool hidePwd = true;

  /// 更新token
  Future<void> updateToken(token) async {
    String tempToken = token;
    Box? box = AppGlobal.appBox;
    await box?.put('gg_token', tempToken);
  }

  /// 登陆提交
  void onSubmit() async {
    String tempUsername = nameController.text;
    String tempPassword = pwdController.text;
    if (tempUsername.trim() == '') {
      BaseDialog.toast(
        text: '用户名不能为空',
      );
      return;
    }
    if (tempPassword.trim() == '') {
      BaseDialog.toast(
        text: '密码不能为空',
      );
      return;
    }
    Basic? res = await apiLogin(
      username: tempUsername,
      password: tempPassword,
    );
    if (res?.status == 1) {
      BotToast.showText(
        text: res?.data["msg"] ?? '登陆成功',
      );
      await updateToken(res!.data["token"]);
      await apiGetBaseInfo(context);
      context.go("/");
    } else {
      BotToast.showText(
        text: res?.msg ?? '登陆失败',
      );
    }
  }

  @override
  void initState() {
    super.initState();
    SystemChannels.textInput.invokeMethod('TextInput.hide');
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScopeNode currentFocus = FocusScope.of(context);
        if (!currentFocus.hasPrimaryFocus &&
            currentFocus.focusedChild != null) {
          /// 取消焦点，相当于关闭键盘
          FocusManager.instance.primaryFocus?.unfocus();
        }
      },
      child: Stack(
        children: [
          Positioned.fill(
            child: Image.asset(
              "assets/images/login/login_bg.jpg",
              fit: BoxFit.cover,
            ),
          ),
          Scaffold(
            resizeToAvoidBottomInset: false,
            backgroundColor: Colors.transparent,
            body: SingleChildScrollView(
              padding: EdgeInsets.zero,
              child: Stack(
                children: [
                  Positioned(
                    top: kIsWeb
                        ? ScreenUtil().setWidth(20.0)
                        : ScreenUtil().statusBarHeight +
                            ScreenUtil().setWidth(20),
                    left: ScreenUtil().setWidth(20.0),
                    child: GestureDetector(
                      onTap: () {
                        Navigator.pop(context);
                      },
                      child: Image.asset(
                        "assets/images/login/login_close.png",
                        width: ScreenUtil().setWidth(28.0),
                        height: ScreenUtil().setWidth(28.0),
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                  SizedBox(
                    width: ScreenUtil().screenWidth,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Padding(
                          padding: EdgeInsets.only(
                            top: ScreenUtil().setWidth(75.0),
                            bottom: ScreenUtil().setWidth(25.0),
                          ),
                          child: Image.asset(
                            "assets/images/login/login_title.png",
                            width: ScreenUtil().setWidth(100.0),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            bottom: ScreenUtil().setWidth(25.0),
                          ),
                          child: Image.asset(
                            "assets/images/login/login_logo.png",
                            width: ScreenUtil().setWidth(200.0),
                            height: ScreenUtil().setWidth(200.0),
                          ),
                        ),
                        // 用户名
                        Container(
                          alignment: Alignment.center,
                          width: ScreenUtil().setWidth(300.0),
                          height: ScreenUtil().setWidth(44.0),
                          padding: EdgeInsets.symmetric(horizontal: 20.w),
                          decoration: BoxDecoration(
                            color: DefaultStyle.bgDefault,
                            borderRadius: BorderRadius.circular(22.w),
                          ),
                          child: TextField(
                            autofocus: false,
                            controller: nameController,
                            style: DefaultStyle.white14,
                            textAlign: TextAlign.center,
                            textInputAction: TextInputAction.done,
                            decoration: InputDecoration(
                              hintText: '请输入暧昧号',
                              hintStyle: DefaultStyle.gray14,
                              contentPadding: EdgeInsets.zero,
                              disabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(30.0),
                                borderSide: const BorderSide(
                                  color: Colors.transparent,
                                  width: 0,
                                ),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(30.0),
                                borderSide: const BorderSide(
                                  color: Colors.transparent,
                                  width: 0,
                                ),
                              ),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(30.0),
                                borderSide: const BorderSide(
                                  color: Colors.transparent,
                                  width: 0,
                                ),
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(30.0),
                                borderSide: const BorderSide(
                                  color: Colors.transparent,
                                  width: 0,
                                ),
                              ),
                            ),
                          ),
                        ),
                        // 密码
                        Container(
                          width: ScreenUtil().setWidth(300.0),
                          height: ScreenUtil().setWidth(44.0),
                          padding: EdgeInsets.symmetric(
                            horizontal: ScreenUtil().setWidth(20.0),
                          ),
                          margin: EdgeInsets.only(
                            top: ScreenUtil().setWidth(15.0),
                            bottom: ScreenUtil().setWidth(50.0),
                          ),
                          decoration: BoxDecoration(
                            color: DefaultStyle.bgDefault,
                            borderRadius: BorderRadius.all(
                              Radius.circular(
                                ScreenUtil().setWidth(22.0),
                              ),
                            ),
                          ),
                          child: Flex(
                            direction: Axis.horizontal,
                            children: [
                              Expanded(
                                flex: 1,
                                child: TextField(
                                  autofocus: false,
                                  controller: pwdController,
                                  obscureText: hidePwd,
                                  style: DefaultStyle.white14,
                                  textAlign: TextAlign.center,
                                  textInputAction: TextInputAction.done,
                                  decoration: InputDecoration(
                                    hintText: '请输入密码',
                                    hintStyle: DefaultStyle.gray14,
                                    contentPadding: EdgeInsets.zero,
                                    disabledBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(30.0),
                                      borderSide: const BorderSide(
                                        color: Colors.transparent,
                                        width: 0,
                                      ),
                                    ),
                                    focusedBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(30.0),
                                      borderSide: const BorderSide(
                                        color: Colors.transparent,
                                        width: 0,
                                      ),
                                    ),
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(30.0),
                                      borderSide: const BorderSide(
                                        color: Colors.transparent,
                                        width: 0,
                                      ),
                                    ),
                                    enabledBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(30.0),
                                      borderSide: const BorderSide(
                                        color: Colors.transparent,
                                        width: 0,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              setPwdIcon(),
                            ],
                          ),
                        ),
                        GestureDetector(
                          onTap: () {
                            onSubmit();
                          },
                          child: Stack(
                            children: [
                              Positioned(
                                top: 0,
                                right: 0,
                                bottom: 0,
                                left: 0,
                                child: Image.asset(
                                  "assets/images/login/login_btn.png",
                                  fit: BoxFit.cover,
                                ),
                              ),
                              Container(
                                width: ScreenUtil().setWidth(180.0),
                                height: ScreenUtil().setWidth(44.0),
                                alignment: Alignment.center,
                                child: Text(
                                  "登录",
                                  style: DefaultStyle.white16,
                                ),
                              ),
                            ],
                          ),
                        ),
                        GestureDetector(
                          onTap: () {
                            context.push("/${Routes.setPwd}");
                          },
                          child: Padding(
                            padding: EdgeInsets.only(
                              top: ScreenUtil().setWidth(15),
                            ),
                            child: Text(
                              '没有账号？去注册',
                              style: DefaultStyle.white12,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  /// 设置密码显示/隐藏按钮地址
  Widget setPwdIcon() {
    String tempIcon;
    if (hidePwd) {
      tempIcon = "assets/images/common/pwd_show.png";
    } else {
      tempIcon = "assets/images/common/pwd_hide.png";
    }
    return GestureDetector(
      onTap: () {
        setState(() {
          hidePwd = !hidePwd;
        });
      },
      child: SizedBox(
        width: ScreenUtil().setWidth(20.0),
        height: ScreenUtil().setWidth(20.0),
        child: Image.asset(
          tempIcon,
          fit: BoxFit.contain,
        ),
      ),
    );
  }
}
