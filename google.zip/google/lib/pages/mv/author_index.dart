import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:iaimei/components/common/commonelements.dart';
import 'package:iaimei/components/common/stackpage.dart';
import 'package:iaimei/model/simple_user.dart';
import 'package:iaimei/net/http_helper.dart';
import 'package:iaimei/router/routers.dart';
import 'package:iaimei/utils/networkimage.dart';
import 'package:iaimei/widget/convenient_mixin.dart';
import 'package:iaimei/widget/network_img_container.dart';
import 'package:iaimei/widget/state_mixin.dart';
import 'package:lpinyin/lpinyin.dart';

class AuthorIndex extends StatefulWidget {
  const AuthorIndex({Key? key, required this.type}) : super(key: key);
  final String type;
  @override
  State<AuthorIndex> createState() => _AuthorIndexState();
}

class _AuthorIndexState extends State<AuthorIndex>
    with ConvenientMixin, StateMixin {
  List<String> letterList = [
    'A',
    'B',
    'C',
    'D',
    'E',
    'F',
    'G',
    'H',
    'I',
    'J',
    'K',
    'L',
    'M',
    'N',
    'O',
    'P',
    'Q',
    'R',
    'S',
    'T',
    'U',
    'V',
    'W',
    'X',
    'Y',
    'Z',
    // '#',
  ];
  List<BaseUserModel> originList = [];
  Map<String, List<BaseUserModel>> targetList = {};
  void onloadCreator() {
    HttpHelper.upperList((data) {
      try {
        originList = (data['creator'] as List).map((item) {
          var model = SimpleUserModel.fromJson(item);
          model.pinyin = PinyinHelper.getPinyin(model.nickname, separator: '');
          return model;
        }).toList();
        targetList = {}; // 置空
        updateListAndWidgetState(originList);
        _buildTransformNicknameSort();
      } catch (err) {
        debugPrint(err.toString());
      }
    }, dealWithErrorsWidgetState);
  }

  void onloadActress() {
    HttpHelper.actorList((data) {
      try {
        originList = (data as List).map((item) {
          var model = ActressUserModel.fromJson(item);
          model.pinyin = PinyinHelper.getPinyin(model.nickname, separator: '');
          return model;
        }).toList();
        targetList = {};
        updateListAndWidgetState(originList);
        _buildTransformNicknameSort();
      } catch (err) {
        debugPrint(err.toString());
      }
    }, dealWithErrorsWidgetState);
  }

  String? selectIndex;
  void _buildTransformNicknameSort() {
    // 所有人名排序
    originList.sort((a, b) => a.pinyin.compareTo(b.pinyin));
    // 给说有人分组
    for (var item in originList) {
      if (item.pinyin.isEmpty) continue;
      var letter = item.pinyin.substring(0, 1).toUpperCase();
      if (!letterList.contains(letter)) continue; //letter = '#';
      if (targetList.containsKey(letter) == false) {
        targetList[letter] = [item];
      } else {
        targetList[letter]?.add(item);
      }
    }

    selectIndex = targetList.keys.first;
    setState(() {});
  }

  @override
  void initState() {
    super.initState();
    widget.type == 'av' ? onloadActress() : onloadCreator();
  }

  final ScrollController _scrollController = ScrollController();

  int itemColumn = 3;
  void _onTapChanged(String alpha) {
    final idx = targetList.keys.toList().indexWhere((key) => key == alpha);
    final val = targetList.values.toList();
    double toHeight = 0.0;
    for (var i = 0; i < val.length && i < idx; i++) {
      int row = (val[i].length + 2) ~/ itemColumn;
      toHeight += 45.w + (94.w + 15.w) * row - 15.w;
    }
    _scrollController.jumpTo(toHeight);
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return StackPage(
        header: CustomHeader(
          title: widget.type == 'av' ? '女优全图鉴' : '原创名人录',
        ),
        child: _buildContentWidget());
  }

  Widget _buildContentWidget() {
    if (widgetState != WidgetState.finish &&
        widgetState != WidgetState.noData) {
      return placeholderWidget();
    }
    return Stack(children: <Widget>[
      ListView.builder(
        padding: EdgeInsets.fromLTRB(16.w, 10.w, 47.w, 20.w),
        controller: _scrollController,
        itemCount: targetList.length,
        itemBuilder: (BuildContext context, int index) {
          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                targetList.keys.toList()[index],
                style: TextStyle(
                    color: rColor, fontSize: 20.sp, fontWeight: fontM),
              ),
              SizedBox(height: 10.w),
              actressItemWidget(targetList.values.toList()[index]),
              SizedBox(height: 20.w),
            ],
          );
        },
      ),
      Positioned(
        right: 0,
        top: 0,
        bottom: 0,
        child: Center(child: indexGroupWidget()),
      )
    ]);
  }

  Widget indexGroupWidget() {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 8.w),
      margin: EdgeInsets.symmetric(horizontal: 8.w),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12.w),
          boxShadow: [
            BoxShadow(
                offset: Offset(0, 3.w),
                blurRadius: 5.w,
                spreadRadius: 0,
                color: const Color.fromRGBO(0, 0, 0, 0.2)),
            BoxShadow(
                blurStyle: BlurStyle.inner,
                offset: Offset(0, -0.5.w),
                blurRadius: 0,
                spreadRadius: 0.5.w,
                color: const Color.fromRGBO(255, 255, 255, 0.1)),
          ],
          color: const Color.fromRGBO(133, 102, 255, 0.12)),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.center,
        children: targetList.keys.map((index) {
          return GestureDetector(
            behavior: HitTestBehavior.translucent,
            onTap: () {
              if (selectIndex != index) {
                selectIndex = index;
                _onTapChanged(index);
              }
            },
            child: SizedBox(
              width: 24.w,
              height: 20.w,
              child: Center(
                child: Text(index,
                    style: TextStyle(
                        color: selectIndex == index ? rColor : wColor,
                        fontSize: 10.sp)),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  void toDetail(int uid) {
    switch (widget.type) {
      case 'av':
        debugPrint('女优全图鉴 $uid');
        context.push('/' + Routes.actressDetail, extra: uid);
        break;
      default:
        debugPrint('原创名人录 $uid');
        context.push('/' + Routes.userhome, extra: uid);
    }
  }

  Widget actressItemWidget(List<BaseUserModel> items) {
    return GridView.builder(
      padding: EdgeInsets.zero,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: items.length,
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: itemColumn,
        childAspectRatio: 1,
        mainAxisSpacing: 15.w,
        crossAxisSpacing: 15.w,
        mainAxisExtent: 94.w,
      ),
      itemBuilder: (BuildContext context, int index) {
        return GestureDetector(
          onTap: () => toDetail(items[index].uid),
          child: Container(
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12.w),
                border: Border.all(
                    width: 0.5, color: Colors.white.withOpacity(0.12)),
                boxShadow: const [
                  BoxShadow(
                      color: Color(0x6a1a152f),
                      offset: Offset(0, 3),
                      blurRadius: 5,
                      spreadRadius: 0)
                ],
                gradient: const LinearGradient(
                    begin: Alignment(0.5, 0),
                    end: Alignment(0.5, 1),
                    colors: [Color(0x29b2aaff), Color(0x296c52de)])),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SizedBox(
                  height: 54.w,
                  width: 54.w,
                  child: NetworkImgContainer(
                    url: items[index].avatarUrl,
                    fit: BoxFit.cover,
                    radius: BorderRadius.circular(27.w),
                  ),
                ),
                SizedBox(height: 5.w),
                Text(
                  items[index].nickname,
                  style: TextStyle(color: Colors.white, fontSize: 10.sp),
                  maxLines: 1,
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
