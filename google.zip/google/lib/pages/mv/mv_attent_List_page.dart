import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:iaimei/components/common/commonelements.dart';
import 'package:iaimei/components/common/stackpage.dart';
import 'package:iaimei/model/simple_user.dart';
import 'package:iaimei/net/http_error.dart';
import 'package:iaimei/router/routers.dart';
import 'package:iaimei/utils/api.dart';
import 'package:iaimei/utils/networkimage.dart';
import 'package:iaimei/widget/convenient_mixin.dart';
import 'package:iaimei/widget/network_img_container.dart';
import 'package:iaimei/widget/state_mixin.dart';

class MvAttentListPage extends StatefulWidget {
  const MvAttentListPage({Key? key}) : super(key: key);

  @override
  State<MvAttentListPage> createState() => _MvAttentListPageState();
}

class _MvAttentListPageState extends State<MvAttentListPage>
    with ConvenientMixin, StateMixin {
  @override
  void initLoadingData() async {
    apiFollowedAuthor(param: param).then((value) {
      if (value != null && value.data is List) {
        var list = [];
        try {
          list =
              value.data.map((json) => SimpleUserModel.fromJson(json)).toList();
        } catch (e) {
          debugPrint(e.toString());
        }
        updateListAndWidgetState(list);
      } else {
        dealWithErrorsWidgetState(HttpError());
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return StackPage(
      header: const CustomHeader(title: '关注'),
      child: _buildContentWidget(),
    );
  }

  Widget _buildContentWidget() {
    if (widgetState != WidgetState.finish &&
        widgetState != WidgetState.noData) {
      return placeholderWidget();
    }
    return _buildAttentListWidget();
  }

  Widget _buildAttentListWidget() {
    return GridView.builder(
      padding: EdgeInsets.fromLTRB(16.w, 10.w, 16.w, 20.w),
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: dataList.length,
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: dataList.length,
        childAspectRatio: 1,
        mainAxisSpacing: 9.w,
        crossAxisSpacing: 9.w,
        mainAxisExtent: 79.w,
      ),
      itemBuilder: (BuildContext context, int index) {
        var item = dataList[index];
        return GestureDetector(
          onTap: () => context.push('/' + Routes.userhome, extra: item.uid),
          child: Container(
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12.w),
                boxShadow: [
                  BoxShadow(
                      offset: Offset(0, 3.w),
                      blurRadius: 5.w,
                      spreadRadius: 0,
                      color: const Color.fromRGBO(0, 0, 0, 0.2)),
                  BoxShadow(
                      blurStyle: BlurStyle.inner,
                      offset: Offset(0, -0.5.w),
                      blurRadius: 0,
                      spreadRadius: 0.5.w,
                      color: const Color.fromRGBO(255, 255, 255, 0.1)),
                ],
                color: const Color.fromRGBO(133, 102, 255, 0.12)),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SizedBox(
                  height: 48.w,
                  width: 48.w,
                  child: NetworkImgContainer(
                    url: item.avatarUrl,
                    fit: BoxFit.cover,
                    radius: BorderRadius.circular(27.w),
                  ),
                ),
                SizedBox(height: 5.w),
                Text(
                  item.nickname,
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.white, fontSize: 12.sp),
                  maxLines: 1,
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
