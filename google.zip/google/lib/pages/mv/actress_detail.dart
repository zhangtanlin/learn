import 'package:flutter/material.dart';
import 'package:flutter_html/shims/dart_ui_real.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:iaimei/components/common/commonelements.dart';
import 'package:iaimei/components/common/pullrefreshlist.dart';
import 'package:iaimei/components/common/stackpage.dart';
import 'package:iaimei/model/simple_user.dart';
import 'package:iaimei/model/video_model.dart';
import 'package:iaimei/net/http_helper.dart';
import 'package:iaimei/pages/mv/mv_list_page.dart';
import 'package:iaimei/widget/convenient_mixin.dart';
import 'package:iaimei/widget/network_img_container.dart';
import 'package:iaimei/widget/state_mixin.dart';

class ActressDetail extends StatefulWidget {
  const ActressDetail({Key? key, this.actor}) : super(key: key);
  final dynamic actor;
  @override
  State<ActressDetail> createState() => _ActressDetailState();
}

class _ActressDetailState extends State<ActressDetail>
    with ConvenientMixin, StateMixin {
  ActressUserModel user = ActressUserModel();
  @override
  void initLoadingData() {
    var param = this.param;
    param['actor_id'] = widget.actor;
    HttpHelper.actorWorks(param, (data) {
      var list = [];
      try {
        if (currentPage == 1 && data['actor'] is Map) {
          user = ActressUserModel.fromJson(data['actor']);
        }
        if (data['list'] is List) {
          list = (data['list'] as List)
              .map((item) => VideoModel.fromJson(item))
              .toList();
        }
      } catch (e) {
        debugPrint(e.toString());
      }
      updateListAndWidgetState(list);
    }, dealWithErrorsWidgetState);
  }

  @override
  Widget build(BuildContext context) {
    return StackPage(
      header: CustomHeader(title: user.nickname),
      child: PullRefreshList(
        isAll: isAll,
        onRefresh: onRefresh,
        onLoading: onLoading,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                margin: EdgeInsets.fromLTRB(16.w, 10.w, 16.w, 0),
                width: 343.w,
                height: 179.w,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(12.w),
                  child: Stack(
                    children: <Widget>[
                      NetworkImgContainer(url: user.coverFull),
                      // 增加深色蒙版
                      Opacity(
                        opacity: 0.2,
                        child: Container(color: Colors.black),
                      ),
                      // 高斯模糊层
                      BackdropFilter(
                        filter: ImageFilter.blur(sigmaX: 5.w, sigmaY: 5.w),
                        child: Container(),
                      ),
                      Positioned.fill(child: _buildActorInfoWidget()),
                    ],
                  ),
                ),
              ),
              Offstage(
                offstage: user.brief.isEmpty,
                child: Padding(
                  padding: EdgeInsets.fromLTRB(16.w, 15.w, 16.w, 0),
                  child: Text(
                    user.brief,
                    style: TextStyle(color: color_54, fontSize: 10.sp),
                  ),
                ),
              ),
              Offstage(
                offstage: dataList.isEmpty,
                child: Padding(
                  padding: EdgeInsets.fromLTRB(16.w, 15.w, 16.w, 0),
                  child: Text(
                    '视频库',
                    style: TextStyle(color: rColor, fontSize: 16.sp),
                  ),
                ),
              ),
              MvListPage(topPadding: 15.w, dataList: dataList),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildActorInfoWidget() {
    return Row(children: [
      SizedBox(
        width: 128.w,
        height: 179.w,
        child: NetworkImgContainer(
          url: user.coverFull,
          fit: BoxFit.cover,
          radius: BorderRadius.circular(12.w),
        ),
      ),
      Container(
        width: 100.w,
        padding: EdgeInsets.fromLTRB(15.w, 22.5.w, 0, 22.5.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            _buildDoubleTextWidget('昵称', user.nickname),
            _buildDoubleTextWidget('生日', user.birthday),
            _buildDoubleTextWidget('出道时间', user.fameDate),
          ],
        ),
      ),
      Expanded(
        child: Padding(
          padding: EdgeInsets.fromLTRB(12.w, 22.5.w, 0, 22.5.w),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _buildDoubleTextWidget('三围', user.bwh),
              _buildDoubleTextWidget('罩杯', user.cup),
              _buildDoubleTextWidget('特点', user.feature),
            ],
          ),
        ),
      )
    ]);
  }

  Widget _buildDoubleTextWidget(text, desc) {
    return Text.rich(
      TextSpan(children: [
        TextSpan(
          text: '$text：\n',
          style: TextStyle(fontSize: 12.sp, color: color_64),
        ),
        TextSpan(
          text: '$desc',
          style: TextStyle(fontSize: 12.sp, color: wColor),
        ),
      ]),
      maxLines: 2,
    );
  }
}
