import 'package:bot_toast/bot_toast.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:iaimei/components/common/base_dialog.dart';
import 'package:iaimei/components/common/commonelements.dart';
import 'package:iaimei/components/common/pullrefreshlist.dart';
import 'package:iaimei/model/tab_item_model.dart';
import 'package:iaimei/net/http_error.dart';
import 'package:iaimei/pages/mv/mv_series_List_page.dart';
import 'package:iaimei/router/routers.dart';
import 'package:iaimei/store/userdata.dart';
import 'package:iaimei/utils/api.dart';
import 'package:iaimei/utils/common.dart';
import 'package:iaimei/widget/buttom_widget.dart';
import 'package:iaimei/widget/convenient_mixin.dart';
import 'package:iaimei/widget/state_mixin.dart';
import 'package:provider/provider.dart';

class MvSpecialOffer extends StatefulWidget {
  const MvSpecialOffer({Key? key, required this.item}) : super(key: key);

  final TabItemModel item;

  @override
  State<MvSpecialOffer> createState() => _MvSpecialOfferState();
}

class _MvSpecialOfferState extends State<MvSpecialOffer>
    with ConvenientMixin, StateMixin {
  @override
  void initLoadingData() {
    commonInterface(
      id: widget.item.id,
      page: currentPage,
      url: widget.item.value,
    ).then((resp) {
      if (resp != null && resp.data is Map) {
        var list = [];
        if (currentPage == 1) {
          var ads = resp.data['ads'] ?? []; // 目前没看见有什么用
          // if (widget.type == OriginType.origin && res.data['creator'] != null) {
          //   creator = (res.data['creator'] as List)
          //       .map((item) => SimpleUserModel.fromJson(item))
          //       .toList();
          // }
          // if (widget.type == OriginType.actress && res.data['actor'] != null) {
          //   creator = (res.data['actor'] as List)
          //       .map((item) => ActressUserModel.fromJson(item))
          //       .toList();
          // }
        }
        if (resp.data['list'] != null && resp.data['list'] is List) {
          list = resp.data['list']
              .map((e) => SeriesItemModel.fromJson(e))
              .toList();
        }
        updateListAndWidgetState(list);
      } else {
        dealWithErrorsWidgetState(HttpError());
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    if (widgetState != WidgetState.finish &&
        widgetState != WidgetState.noData) {
      return placeholderWidget();
    }
    return PullRefreshList(
      isAll: isAll,
      onRefresh: onRefresh,
      onLoading: onLoading,
      child: MvSeriesListPage(
        // type: 2, // 自定义 header 就没必要传 type
        header: (object) => _buildTitleWidget(object),
        dataList: dataList,
        onPlay: (isPay) {
          return isPay == 0 ? () => Method.showText('请先解锁，再播放') : null;
        },
      ),
    );
  }

  void onNextPage(SeriesItemModel object) {
    WaterfallExtra obj = WaterfallExtra(
      title: object.title,
      url: '/api/menu/special_mv',
      params: {'id': object.id},
      showSubscript: false,
    );
    context.push('/${Routes.mvListViewPage}', extra: obj);
  }

  /// 解锁弹出框
  void handleUnlock(SeriesItemModel object) {
    BaseDialog.showdialog(
      context,
      insetPadding: 30.w,
      barrierDismissible: true,
      child: Column(
        children: [
          SizedBox(height: 40.w),
          Text.rich(
            TextSpan(children: [
              TextSpan(text: '支付 ', style: TextStyle(color: wColor)),
              TextSpan(
                  text: '¥${object.coins}', style: TextStyle(color: rColor))
            ]),
            style: TextStyle(fontSize: 18.sp, fontWeight: fontM),
          ),
          SizedBox(height: 10.w),
          Text(
            '解锁${object.title}',
            style: TextStyle(color: color_84, fontSize: 14.sp),
          ),
          SizedBox(height: 30.w),
          ButtonWidget.build('解锁', onTap: () {
            unlockSubmit(object);
            Navigator.pop(context);
          }),
          SizedBox(height: 15.w),
          _buildOverPmWidget(),
          SizedBox(height: 30.w),
        ],
      ),
    );
  }

  Widget _buildOverPmWidget() {
    var user = Provider.of<UserData>(context, listen: false).userInfo;
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(
          '当前余额 ¥${user.coins}',
          style: TextStyle(
              color: wColor, fontSize: 12.w, fontWeight: FontWeight.w400),
        ),
        SizedBox(width: 20.w),
        GestureDetector(
          onTap: () {
            context.push('/rechargeCoins');
            Navigator.of(context).pop();
          },
          child: Text(
            "去充值 ＞＞",
            style: TextStyle(color: rColor, fontSize: 12.w, fontWeight: fontM),
          ),
        )
      ],
    );
  }

  /// 解锁提交
  void unlockSubmit(SeriesItemModel object) async {
    BotToast.showLoading();
    var res = await apiSpecialUnlock(id: object.id);
    BotToast.closeAllLoading();
    if (res?.status == 1) {
      Method.showText("解锁成功");
      // object.isPay = 1;
      initLoadingData(); // reload
    } else {
      Method.showText(res!.msg.toString());
    }
  }

  Widget _buildTitleWidget(SeriesItemModel object) {
    return GestureDetector(
      behavior: HitTestBehavior.translucent,
      onTap: object.isPay == 1
          ? () => onNextPage(object)
          : () => Method.showText('请先解锁，再查看更多'),
      child: Container(
        height: 72.w,
        alignment: Alignment.centerLeft,
        padding: EdgeInsets.symmetric(horizontal: 16.w),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    object.title,
                    style: TextStyle(
                        color: wColor, fontWeight: fontM, fontSize: 18.sp),
                    overflow: TextOverflow.ellipsis,
                    maxLines: 1,
                  ),
                  Row(
                    children: [
                      Text(
                        '¥${object.coins}',
                        style: TextStyle(
                            color: rColor, fontWeight: fontB, fontSize: 12.sp),
                      ),
                      SizedBox(width: 10.w),
                      Text(
                        '解锁${object.number}部',
                        style: TextStyle(color: wColor, fontSize: 12.sp),
                      ),
                    ],
                  )
                ],
              ),
            ),
            Offstage(
              offstage: object.isPay == 1,
              child: ButtonWidget.build('解锁',
                  style: IconStyle.pink_68_34,
                  onTap: () => handleUnlock(object)),
            ),
            SizedBox(width: 13.w),
            Image.asset("assets/images/common/arrow_go.png",
                width: 12.w, height: 18.w),
          ],
        ),
      ),
    );
  }
}
