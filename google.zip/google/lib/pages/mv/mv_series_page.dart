import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:iaimei/components/common/pullrefreshlist.dart';
import 'package:iaimei/model/ads_model.dart';
import 'package:iaimei/model/simple_user.dart';
import 'package:iaimei/model/tab_item_model.dart';
import 'package:iaimei/model/video_model.dart';
import 'package:iaimei/net/http_error.dart';
import 'package:iaimei/pages/mv/mv_list_page.dart';
import 'package:iaimei/pages/mv/mv_series_List_page.dart';
import 'package:iaimei/pages/mv/mv_series_title_page.dart';
import 'package:iaimei/router/routers.dart';
import 'package:iaimei/utils/api.dart';
import 'package:iaimei/widget/banner_widget.dart';
import 'package:iaimei/widget/convenient_mixin.dart';
import 'package:iaimei/widget/network_img_container.dart';
import 'package:iaimei/widget/state_mixin.dart';

class MvSeriesPage extends StatefulWidget {
  const MvSeriesPage({Key? key, required this.item, required this.type})
      : super(key: key);
  final TabItemModel item;
  final String type;

  @override
  State<MvSeriesPage> createState() => _MvSeriesPageState();
}

class _MvSeriesPageState extends State<MvSeriesPage>
    with ConvenientMixin, StateMixin {
  bool isRecommendData = false; // 原创 -> 关注 是推荐数据
  List<AdsModel> ads = [];
  List<BaseUserModel> authorList = [];

  @override
  void initLoadingData() {
    commonInterface(
      id: widget.item.id,
      page: currentPage,
      url: widget.item.value,
    ).then((resp) {
      if (resp != null) {
        if (resp.data is! Map) {
          // error
          updateListAndWidgetState([]);
          return;
        }

        var list = [];
        if (currentPage == 1) {
          if (resp.data['ads'] != null && resp.data['ads'] is List) {
            ads = resp.data['ads']
                .map<AdsModel>((json) => AdsModel.fromJson(json))
                .toList();
          }

          if (widget.type != 'av' &&
              resp.data['creator'] != null &&
              resp.data['creator'] is List) {
            authorList = resp.data['creator']
                .map<SimpleUserModel>((item) => SimpleUserModel.fromJson(item))
                .toList();
          }

          if (widget.type == 'av' &&
              resp.data['actor'] != null &&
              resp.data['actor'] is List) {
            authorList = resp.data['actor']
                .map<ActressUserModel>(
                    (item) => ActressUserModel.fromJson(item))
                .toList();
          }
        }

        // 关注无视频数据，是否是推荐数据
        isRecommendData = resp.data['is_recommend_data'] ?? false; //
        if (resp.data['list'] != null && resp.data['list'] is List) {
          list = resp.data['list'].map((e) {
            if (e['show_style'] != null) {
              return SeriesItemModel.fromJson(e);
            } else {
              return VideoModel.fromJson(e);
            }
          }).toList();
        }

        updateListAndWidgetState(list);
      } else {
        dealWithErrorsWidgetState(HttpError());
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    if (widgetState != WidgetState.finish &&
        widgetState != WidgetState.noData) {
      return placeholderWidget();
    }
    bool isAtten = ['关注', '關注'].contains(widget.item.name);
    return PullRefreshList(
      isAll: isAll,
      onRefresh: onRefresh,
      onLoading: onLoading,
      child: SingleChildScrollView(
        child: Column(
          children: [
            Offstage(
                offstage: widget.type != 'ai' || ads.isEmpty,
                child: _buildCommonAdsWidget()),
            Offstage(
              offstage: !(isAtten && isRecommendData),
              child: Container(
                padding: EdgeInsets.only(top: 5.w, bottom: 10.w),
                child: Text(
                  '无关注用户，为您推荐的视频',
                  style: TextStyle(color: color_84, fontSize: 14.sp),
                ),
              ),
            ),
            Offstage(
                offstage: authorList.isEmpty,
                child: isAtten
                    ? _buildAttentAuthorWidget()
                    : _buildCommonAuthorWidget()),
            (dataList.first is VideoModel)
                ? _buildNonSeriesTagWidget(isAtten ? 3.w : 10.w) // 非系列 标签视频
                : MvSeriesListPage(dataList: dataList), // 系列视频
          ],
        ),
      ),
    );
  }

  /* ********************** 垂直滑动 *********************** */

  Widget _buildNonSeriesTagWidget([double top = 0]) {
    return MvListPage(type: 2, topPadding: top, dataList: dataList);
  }

  /* ********************  top ads  ********************* */

  Widget _buildCommonAdsWidget() {
    return ads.isNotEmpty
        ? BannerWidget(
            adList: ads,
            height: 190.w,
            margin: EdgeInsets.fromLTRB(16.w, 0, 16.w, 0),
            radius: BorderRadius.circular(12),
          )
        : const SizedBox();
  }

  /* ********************  attention  ********************* */
  Widget _buildAttentAuthorWidget() {
    return Row(
      children: [
        Expanded(child: _buildAuthorListWidget(15.w)),
        GestureDetector(
          behavior: HitTestBehavior.translucent,
          onTap: () => context.push('/${Routes.attentList}'),
          child: Container(
            width: 44.w,
            height: 44.w,
            alignment: Alignment.center,
            child: Image.asset(
              "assets/images/common/arrow_go.png",
              width: 12.w,
              height: 18.w,
              fit: BoxFit.cover,
            ),
          ),
        ),
      ],
    );
  }

  /* ******************** author info ********************* */

  Widget _buildCommonAuthorWidget() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        MvSeriesTitlePage(
          title: widget.type != 'av' ? '原创名人录' : '女优全图鉴',
          onTap: () => context.push('/authorIndex', extra: widget.type),
        ),
        _buildAuthorListWidget(),
      ],
    );
  }

  Widget _buildAuthorListWidget([double top = 0]) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Container(
        margin: EdgeInsets.only(left: 6.w, top: top, right: 6.w, bottom: 15.w),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.max,
          children: authorList.map((e) => _buildAuthorInfoWidget(e)).toList(),
        ),
      ),
    );
  }

  void toDetail(int uid) {
    switch (widget.type) {
      case 'av':
        debugPrint('女优全图鉴 $uid');
        context.push('/' + Routes.actressDetail, extra: uid);
        break;
      default:
        debugPrint('原创名人录 $uid');
        context.push('/' + Routes.userhome, extra: uid);
    }
  }

  Widget _buildAuthorInfoWidget(BaseUserModel item) {
    return GestureDetector(
      onTap: () => toDetail(item.uid),
      child: Container(
        width: 44.w,
        margin: EdgeInsets.symmetric(horizontal: 10.w),
        child: Column(children: [
          NetworkImgContainer(
            url: item.avatarUrl,
            height: 44.w,
            radius: BorderRadius.circular(22.w),
          ),
          SizedBox(height: 5.w),
          Text(
            item.nickname,
            style: TextStyle(color: wColor, fontSize: 12.sp),
            maxLines: 1,
            textAlign: TextAlign.center,
          ),
        ]),
      ),
    );
  }
}
