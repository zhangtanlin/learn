import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:iaimei/components/common/commonelements.dart';
import 'package:iaimei/components/common/pageviewmixin.dart';
import 'package:iaimei/components/common/stackpage.dart';
import 'package:iaimei/model/indexlist.dart';
import 'package:iaimei/model/tab_item_model.dart';
import 'package:iaimei/pages/mv/mv_series_page.dart';
import 'package:iaimei/pages/mv/nav_tab_bar_mixin.dart';
import 'package:iaimei/res/img_res.dart';
import 'package:iaimei/router/routers.dart';
import 'package:iaimei/utils/api.dart';
import 'package:iaimei/utils/page_jump_util.dart';
import 'package:iaimei/widget/convenient_mixin.dart';

import 'mv_special_offer.dart';

enum MvType {
  special, // 特价
  origin, // 原创
  actress, // 女优
}

class MvIndexPage extends StatefulWidget {
  const MvIndexPage({Key? key, required this.item}) : super(key: key);
  final Menu item;

  @override
  State<MvIndexPage> createState() => _MvIndexPageState();
}

class _MvIndexPageState extends State<MvIndexPage>
    with TickerProviderStateMixin, ConvenientMixin {
  bool loading = true;
  int selectIndex = 0; // 默认选项
  late TabController tabController;
  List<TabItemModel> tabs = [];

  @override
  void initState() {
    super.initState();
    initTabController();
    feedbackBlock = () => context.push('/${Routes.onlineService}');
    initLoadingData();
  }

  void initTabController() {
    tabController = TabController(
        initialIndex: selectIndex, length: tabs.length, vsync: this);
    tabController.addListener(() {
      setState(() => selectIndex = tabController.index);
    });
  }

  void initLoadingData() {
    debugPrint(widget.item.value);
    interfaceConnector(url: widget.item.value, param: {"id": widget.item.id})
        .then((res) {
      if (res != null && res.data.isNotEmpty) {
        // default selected index
        int index = res.data.indexWhere((item) => item['is_default'] == 1);
        selectIndex = index > 0 ? index : 0;

        tabs = List<TabItemModel>.from(res.data.map((x) {
          return TabItemModel.fromJson(x);
        }));
        initTabController();
        loading = false;
        setState(() {});
      } else {
        loading = false;
        setState(() {});
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return StackPage(
      header: CustomHeader(
        titleWidget: _buildTitleWidget(),
        rListWidget: [
          GestureDetector(
            onTap: () => PageJumpUtil.forwardToSearchPage(context),
            child: Image.asset(ImgRes.IC_SEARCH, width: 35.w, height: 35.w),
          ),
          SizedBox(width: 7.w),
        ],
      ),
      child: _buildItemTypePageWidget(),
    );
  }

  Widget _buildTitleWidget() {
    var select = TextStyle(color: rColor, fontSize: 18.sp, fontWeight: fontM);
    if (tabs.length <= 1) {
      return Padding(
        padding: EdgeInsets.only(left: 10.w),
        child: Text(widget.item.name, style: select),
      );
    }

    return NavTabBarWidget(
      tabVc: tabController,
      tabs: tabs.map((item) => item.name).toList(),
      norTextStyle: TextStyle(
          color: wColor, fontSize: 14.sp, fontWeight: FontWeight.w400),
      selTextStyle: select,
      selectedIndex: selectIndex,
      // onTapCallback: (value) => setState(() => selectIndex = value),
    );
  }

  Widget _buildItemTypePageWidget() {
    if (tabs.isEmpty) {
      return loading ? loadingWiget() : noDataWidget();
    }
    switch (widget.item.type) {
      case 'mv':
        return _buildCommonPageWidget(); // 金币 会员 原创 综艺 奇闻
      case 'av':
        return _buildCommonPageWidget(); // av
      case 'series':
        return _buildCommonPageWidget(); // 国产
      case 'dm':
        return _buildCommonPageWidget(); // 动漫
      case 'special':
        return _buildSpecialOfferWidget();

      // case 'rank':
      //   context.go('/ranking', extra: value); // 排行榜
      //   break;
      case 'ai':
        return _buildCommonPageWidget(); // ai换脸
      default:
        return Container();
    }
  }

  Widget _buildCommonPageWidget() {
    if (tabs.length == 1) {
      return MvSeriesPage(item: tabs.first, type: widget.item.type);
    }

    return TabBarView(
      controller: tabController,
      children: tabs.map((e) {
        return PageViewMixin(
          child: MvSeriesPage(item: e, type: widget.item.type),
        );
      }).toList(),
    );
  }

  Widget _buildSpecialOfferWidget() {
    if (tabs.length == 1) {
      return MvSpecialOffer(item: tabs.first);
    }

    return TabBarView(
      controller: tabController,
      children: tabs
          .map((e) => PageViewMixin(child: MvSpecialOffer(item: e)))
          .toList(),
    );
  }
}
