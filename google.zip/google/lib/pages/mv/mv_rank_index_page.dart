import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:iaimei/components/common/commonelements.dart';
import 'package:iaimei/components/common/pagestatus.dart';
import 'package:iaimei/components/common/pageviewmixin.dart';
import 'package:iaimei/components/common/stackpage.dart';
import 'package:iaimei/model/indexlist.dart';
import 'package:iaimei/pages/mv/nav_tab_bar_mixin.dart';
import 'package:iaimei/pages/mv/mv_rank_sort_page.dart';
import 'package:iaimei/utils/api.dart';

class MvRankIndexPage extends StatefulWidget {
  final Menu item;
  const MvRankIndexPage({Key? key, required this.item}) : super(key: key);

  @override
  State<MvRankIndexPage> createState() => _MvRankIndexPageState();
}

class _MvRankIndexPageState extends State<MvRankIndexPage>
    with TickerProviderStateMixin {
  late TabController tabController;
  List tabs = [];
  int _selectIndex = 0;
  bool loading = true;

  @override
  void initState() {
    super.initState();
    tabController = TabController(length: tabs.length, vsync: this);
    initTabsList();
  }

  @override
  void dispose() {
    tabController.dispose();
    super.dispose();
  }

  void initTabsList() {
    if (kDebugMode) {
      print(widget.item.id);
    }

    apiRankTab().then((res) {
      if (res != null && res.data.isNotEmpty) {
        int defultIndex = 0;
        // 匹配需要默认显示的tab
        tabController = TabController(
            initialIndex: defultIndex, length: res.data.length, vsync: this);
        tabs = res.data;
        tabController.addListener(() {
          setState(() => _selectIndex = tabController.index);
        });
        loading = false;
        if (mounted) {
          setState(() {});
        }
      } else {
        loading = false;
        if (mounted) {
          setState(() {});
        }
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return StackPage(
          header: const CustomHeader(title: "排行榜"),
          child: PageStatus.loading(mounted));
    } else {
      return StackPage(
        header: CustomHeader(
          titleWidget: NavTabBarWidget(
            tabVc: tabController,
            tabs: tabs.map<String>((e) => e.name).toList(),
            norTextStyle: TextStyle(
                color: Colors.white,
                fontSize: 14.sp,
                fontWeight: FontWeight.w400),
            selTextStyle: TextStyle(
                color: const Color(0xffff00b3),
                fontSize: 18.sp,
                fontWeight: FontWeight.w500),
            selectedIndex: _selectIndex,
          ),
        ),
        child: TabBarView(
          controller: tabController,
          children: tabs.asMap().keys.map((e) {
            return PageViewMixin(
              child: MvRankSortPage(
                  showPage: _selectIndex == e, itemData: tabs[e]),
            );
          }).toList(),
        ),
      );
    }
  }
}
