import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:iaimei/model/video_model.dart';
import 'package:iaimei/res/img_res.dart';
import 'package:iaimei/utils/common_utils.dart';
import 'package:iaimei/utils/video_util.dart';
import 'package:iaimei/widget/network_img_container.dart';

class OnTapGestureDetector extends StatelessWidget {
  /// [interval] click response interval, defalut 0
  OnTapGestureDetector({Key? key, this.child, this.onTap, this.interval = 0})
      : super(key: key);

  final void Function()? onTap;
  final Widget? child;
  final int interval;

  DateTime? _lastTime; //上次点击时间

  void _onClickAction() {
    // 1
    if (interval == 0 || _lastTime == null) {
      return onTap?.call();
    }
    // 2
    var last = DateTime.now().difference(_lastTime!).inSeconds;
    if (last > interval) {
      _lastTime = DateTime.now();
      return onTap?.call();
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(onTap: _onClickAction, child: child);
  }
}

class MvItemWidget extends StatelessWidget {
  /// [radius] defalut 12.w
  /// [maxline] default 16 * 9 => 1; 3 * 4 => 2
  /// [isWide] default 16 * 9 => true; 3 * 4 => false
  /// [margin] defaalut EdgeInsets.zero
  const MvItemWidget({
    Key? key,
    required this.width,
    required this.height,
    this.radius, // default 12.w
    this.index = 0,
    this.items = const [],
    this.margin = EdgeInsets.zero,
    // this.backgroundColor = Colors.transparent,
    this.onTap,
    this.maxline, 
    this.isWide,
    this.isRank = false,
  }) : super(key: key);

  /// mv cover
  final double width;
  final double height;
  final double? radius;

  /// mv list & index
  final int index;
  final List items;

  ///
  final bool? isWide; // true -> 16 * 9 false -> 3 * 4
  final bool isRank; // 是否排行榜

  final int? maxline; // default 16 * 9 => 1; 3 * 4 => 2 
  // final Color backgroundColor;
  final EdgeInsetsGeometry margin;
  final GestureTapCallback? onTap;

  void _onClickAction(BuildContext context) {
    List<VideoModel> videoList = items.map((item) {
      return item as VideoModel;
    }).toList();
    VideoUtil.jumpToVideoPlayer(context, videoList, curIndex: index);
  }

  @override
  Widget build(BuildContext context) {
    if (items.isEmpty || items.length <= index) {
      return Container(); // 数据问题
    }

    bool isWide = this.isWide ?? width / height > 1;
    VideoModel item = items[index];
    return OnTapGestureDetector(
      onTap: onTap ?? () => _onClickAction(context),
      child: Container(
        margin: margin,
        width: width,
        height: height,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(radius ?? 12.w),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(radius ?? 12.w),
          child: Stack(
            children: [
              // 背景透明层
              // Opacity(
              //   opacity: 0.72,
              //   child: NetworkImgContainer(url: thumb),
              // ),
              NetworkImgContainer(url: item.coverThumbUrl),
              // 增加深色蒙版
              Opacity(
                opacity: 0.2,
                child: Container(color: const Color(0xff090217)),
              ),
              // 高斯模糊层
              // ClipRect(
              //   child:
              BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 8.w, sigmaY: 8.w),
                child: Container(),
                // ),
              ),

              Positioned.fill(child: _buildImageSourceWidget(item, isWide)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildImageSourceWidget(VideoModel item, bool isWide) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Stack(
          children: [
            NetworkImgContainer(
              width: double.infinity,
              height: width * (isWide ? 9 / 16 : 4 / 3),
              url: item.coverThumbUrl,
              fit: isWide ? BoxFit.cover : BoxFit.fitWidth,
            ),
            Container(
              height: width * (isWide ? 9 / 16 : 4 / 3),
              color: Colors.white.withOpacity(0.09),
            ),
            Padding(
              padding: EdgeInsets.all(5.w),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  _buildSubscript(ImgRes.IC_BADGE_COIN, item.isFree == 2),
                  _buildSubscript(ImgRes.IC_BADGE_VIP, item.isFree == 1),
                  _buildSubscript(ImgRes.IC_BADGE_FREE, item.isFree == 0),
                  _buildSubscript(ImgRes.IC_BADGE_FAN, item.clubId > 0),
                ],
              ),
            ),
            Visibility(
              child: Positioned(
                left: 5.w,
                top: 5.w,
                child: Image.asset(
                  // 'assets/images/video/mv_rank_${index > 9 ? 10 : index + 1}.png',
                  'assets/images/video/mv_rank_${index + 1}.png',
                  width: 35.w,
                  height: 35.w,
                ),
              ),
              visible: isRank && isWide == false && index < 10,
            ),
            Visibility(
              child: Positioned(
                left: 0,
                bottom: 0,
                child: _buildMvPlayCountWidget(item.rating),
              ),
              visible: item.rating > 0,
            ),
            Visibility(
              child: Positioned(
                bottom: 0,
                right: 0,
                child: _buildMvDurationWidget(item.duration),
              ),
              visible: item.duration > 0,
            ),
          ],
        ),
        Expanded(child: _buildMvTitleWidget(item.title, isWide)),
      ],
    );
  }

  Widget _buildSubscript(String icon, bool appear) {
    return Offstage(
      offstage: !appear,
      child: Container(
        margin: EdgeInsets.only(left: 5.w),
        child: Image.asset(icon, width: 36.w, height: 18.w),
      ),
    );
  }

  Widget _buildMvPlayCountWidget(int count) {
    return Container(
      alignment: Alignment.center,
      decoration: const BoxDecoration(
        color: Color(0x6c000000),
        borderRadius: BorderRadius.only(topRight: Radius.circular(6)),
      ),
      padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 2.w),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Image.asset(ImgRes.IC_PLAY_NUM,
              width: 10.w, height: 12.w, fit: BoxFit.contain),
          SizedBox(width: 2.w),
          Text(CommonUtils.renderFixedNumber(count.toDouble()), //'$count',
              style: TextStyle(color: Colors.white, fontSize: 10.sp)),
        ],
      ),
    );
  }

  Widget _buildMvDurationWidget(dynamic time) {
    return Container(
      decoration: const BoxDecoration(
        color: Color(0x6c000000),
        borderRadius: BorderRadius.only(topLeft: Radius.circular(6)),
      ),
      padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 2.w),
      child: Text(CommonUtils.durationToTime(time),
          style: TextStyle(color: Colors.white, fontSize: 10.sp)),
    );
  }

  Widget _buildMvTitleWidget(String title, bool isWide) {
    return Container(
      // color: Colors.red,
      alignment: Alignment.centerLeft,
      padding: EdgeInsets.symmetric(
          horizontal: width < ScreenUtil().screenWidth * 0.5 ? 5.w : 10.w),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Visibility(
            child: Padding(padding: EdgeInsets.only(right: 8.w), child:Image.asset(
              'assets/images/video/mv_rank_${index + 1}.png',
              width: 35.w,
              height: 35.w,
            )),
            visible: isRank && isWide == true && index < 10,
          ),
          Expanded(
            child: Text(
              title,
              style: width < ScreenUtil().screenWidth * 0.5 //maxline == 2
                  ? TextStyle(color: Colors.white, fontSize: 13.sp)
                  : TextStyle(color: Colors.white, fontSize: 13.sp),
              maxLines: maxline ?? (isWide ? 1 : 2),
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }
}
