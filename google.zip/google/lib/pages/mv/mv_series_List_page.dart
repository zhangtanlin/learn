import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:iaimei/components/common/commonelements.dart';
import 'package:iaimei/model/tab_item_model.dart';
import 'package:iaimei/pages/mv/mv_item_page.dart';
import 'package:iaimei/pages/mv/mv_series_title_page.dart';
import 'package:iaimei/router/routers.dart';
import 'package:iaimei/widget/convenient_mixin.dart';

class MvSeriesListPage extends StatefulWidget {
  /// type: 0-系列 1-合集(购买的合集) 2-特价
  const MvSeriesListPage(
      {Key? key,
      this.type = 0,
      this.header,
      this.onPlay,
      this.dataList = const []})
      : super(key: key);
  final int type;
  final List dataList;

  final Widget? Function(SeriesItemModel)? header;

  /// param => specal offer [isPay] 0 false 1 true
  final void Function()? Function(int)? onPlay;

  @override
  State<MvSeriesListPage> createState() => _MvSeriesListPageState();
}

class _MvSeriesListPageState extends State<MvSeriesListPage>
    with ConvenientMixin {
  @override
  Widget build(BuildContext context) {
    return _buildSeriesGroupWidget();
  }

  /* ******************** title info ********************* */

  void onNextPage(SeriesItemModel object) {
    WaterfallExtra obj = WaterfallExtra(
      title: object.title,
      // 1,2 特价视频 special offer
      url: widget.type == 0 ? '/api/menu/series_mv' : '/api/menu/special_mv',
      crossAxisCount: object.showStyle == 1 ? 2 : 1,
      params: {'id': object.id},
    );
    context.push('/${Routes.mvListViewPage}', extra: obj);
  }

  /* ********************** 水平滑动 *********************** */

  Widget _buildSeriesGroupWidget() {
    Widget seriesTitleWidget(SeriesItemModel series) {
      return MvSeriesTitlePage(
        title: series.title,
        onTap: () => onNextPage(series),
        subTitle: series.subTitle,
      );
    }

    Widget seriesStyleWidget(SeriesItemModel series) {
      switch (series.showStyle) {
        case 0: // 0-水平滑动 宽
          return _buildHorizontalScrollWidget(series, true);
        case 1: // 1-水平滑动 宅
          return _buildHorizontalScrollWidget(series, false);
        case 3: // 3-垂直滑动 品
          return _buildVerticalScrollWidget(series);
        default:
          return Container();
      }
    }

    return ListView.builder(
      physics: const NeverScrollableScrollPhysics(),
      shrinkWrap: true,
      itemCount: widget.dataList.length,
      padding: EdgeInsets.zero,
      itemBuilder: (ctx, index) {
        SeriesItemModel series = widget.dataList[index];
        return Offstage(
          offstage: series.list.isEmpty,
          child: Container(
            width: double.infinity,
            padding: EdgeInsets.only(bottom: 15.w),
            margin: EdgeInsets.only(bottom: 10.w),
            color: Colors.white.withOpacity(0.05),
            child: Column(children: [
              widget.header?.call(series) ?? seriesTitleWidget(series),
              seriesStyleWidget(series),
            ]),
          ),
        );
      },
    );
  }

  Widget _buildHorizontalScrollWidget(SeriesItemModel series, bool isWide) {
    return SingleChildScrollView(
      padding: EdgeInsets.only(left: 16.w),
      scrollDirection: Axis.horizontal,
      child: Row(
        mainAxisSize: MainAxisSize.max,
        children: series.list.asMap().keys.map((index) {
          return _buildShowStyleWidget(
              series.list, index, isWide, series.isPay);
        }).toList(),
      ),
    );
  }

  // isPay => special offer series isPay, 0 false 1 true
  Widget _buildShowStyleWidget(
      List dataList, int index, bool isWide, int isPay) {
    return MvItemWidget(
      width: isWide ? 328.w : 157.w,
      height: isWide ? 228.w : 264.w,
      margin: EdgeInsets.only(right: 15.w),
      index: index,
      items: dataList,
      onTap: widget.onPlay?.call(isPay),
    );
  }

  /* ********************** 垂直滑动 *********************** */

  /// 品字型
  Widget _buildVerticalScrollWidget(SeriesItemModel series) {
    bool isWide = series.list.length % 3 != 0;
    return Wrap(
      runSpacing: 15.w,
      spacing: 15.w,
      children: series.list.asMap().keys.map((index) {
        return _buildToastStyleWidget(
            series.list, index, isWide || index % 3 == 0, series.isPay);
      }).toList(),
    );
  }

  // isPay => special offer series isPay, 0 false 1 true
  Widget _buildToastStyleWidget(
      List dataList, int index, bool isWide, int isPay) {
    return MvItemWidget(
      width: isWide ? 343.w : 164.w,
      height: isWide ? 229.w : 122.w,
      index: index,
      items: dataList,
      onTap: widget.onPlay?.call(isPay),
    );
  }
}
