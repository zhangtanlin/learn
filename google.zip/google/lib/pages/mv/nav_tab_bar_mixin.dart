import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:iaimei/widget/convenient_mixin.dart';

class NavTabBarWidget extends StatefulWidget {
  /// tabBarHeight default 44.w
  const NavTabBarWidget({
    Key? key,
    this.isScrollable = true,
    required this.tabVc,
    required this.tabs,
    this.tabBarHeight,
    this.textPadding,
    this.selectedIndex,
    required this.norTextStyle,
    this.selTextStyle,
    this.onTapCallback,
  }) : super(key: key);

  final bool isScrollable;
  final TabController tabVc; // 控制器
  final List<String> tabs; // 栏目
  final double? tabBarHeight; // 栏目高度
  final EdgeInsets? textPadding; // 文字左右边距
  final int? selectedIndex; // 选择

  final TextStyle norTextStyle; //
  final TextStyle? selTextStyle; //
  final void Function(int)? onTapCallback; // 选中回调

  @override
  State<NavTabBarWidget> createState() => _NavTabBarWidgetState();
}

class _NavTabBarWidgetState extends State<NavTabBarWidget>
    with ConvenientMixin {
  late double _tabBarHeight;
  List<double> itemsWidth = [];

  late TextStyle _norTextStyle;
  late TextStyle _selTextStyle;
  late EdgeInsets _textPadding;

  @override
  void initState() {
    super.initState();
    _tabBarHeight = widget.tabBarHeight ?? 44.w;
    _norTextStyle = widget.norTextStyle;
    _selTextStyle = widget.selTextStyle ?? widget.norTextStyle;
    _textPadding = widget.textPadding ?? EdgeInsets.symmetric(horizontal: 10.w);

    // 因字体站位宽度不同，解决选择时的拖动感
    var lrPadding = _textPadding.left + _textPadding.right;
    itemsWidth = widget.tabs.map<double>((text) {
      return calculateTextWidth(text, _selTextStyle) + lrPadding;
    }).toList();
  }

  double calculateTextWidth(String value, TextStyle style,
      {int maxLines = 1,
      double maxWidth = double.infinity,
      double textScaleFactor = 1.0}) {
    var painter = TextPainter(
        locale: WidgetsBinding.instance?.window.locale,
        maxLines: maxLines,
        textDirection: TextDirection.ltr,
        textScaleFactor: textScaleFactor,
        text: TextSpan(text: value, style: style));
    painter.layout(maxWidth: maxWidth);
    return painter.width;
  }

  @override
  Widget build(BuildContext context) {
    bool isOrigin = _selTextStyle.fontSize == _norTextStyle.fontSize ||
        widget.selectedIndex == null;
    return Container(
      // color: Colors.orange,
      height: _tabBarHeight,
      child: _buildTabBarWidget(isOrigin),
    );
  }

  Widget _buildTabBarWidget(bool isOrigin) {
    return Theme(
      data: ThemeData(
        splashColor: Colors.transparent,
        highlightColor: Colors.transparent,
      ),
      child: TabBar(
        padding: EdgeInsets.zero,
        onTap: (value) => widget.onTapCallback?.call(value),
        controller: widget.tabVc,
        isScrollable: widget.isScrollable,
        labelPadding: EdgeInsets.zero,
        labelStyle: isOrigin ? _selTextStyle : null,
        unselectedLabelStyle: isOrigin ? _norTextStyle : null,
        labelColor: _selTextStyle.color,
        unselectedLabelColor: _norTextStyle.color,
        indicator: const BoxDecoration(),
        indicatorWeight: 0,
        enableFeedback: true,
        tabs: _buildTabBarItemsWidget(isOrigin),
      ),
    );
  }

  List<Widget> _buildTabBarItemsWidget(bool isOrigin) {
    return itemsWidth.asMap().keys.map((i) {
      return Container(
        // color: Colors.blue,
        width: itemsWidth[i],
        alignment: Alignment.center,
        child: Text(
          widget.tabs[i],
          style: isOrigin
              ? null
              : (i == widget.selectedIndex ? _selTextStyle : _norTextStyle),
        ),
      );
    }).toList();
  }
}
