import 'package:flutter/material.dart';
import 'package:iaimei/components/common/pullrefreshlist.dart';
import 'package:iaimei/model/rinking_model.dart';
import 'package:iaimei/model/video_model.dart';
import 'package:iaimei/pages/mv/mv_list_page.dart';
import 'package:iaimei/utils/api.dart';
import 'package:iaimei/widget/convenient_mixin.dart';

class MvRankSortPage extends StatefulWidget {
  final bool showPage;
  final RanKTabs itemData;

  const MvRankSortPage(
      {Key? key, this.showPage = false, required this.itemData})
      : super(key: key);

  @override
  State<MvRankSortPage> createState() => _MvRankSortPageState();
}

class _MvRankSortPageState extends State<MvRankSortPage> with ConvenientMixin {
  bool isError = false;
  bool isLoading = true;
  int page = 1;
  bool isAll = false;
  List ads = [];
  List list = [];

  @override
  void initState() {
    super.initState();
    initLoadingData();
  }

  void initLoadingData() {
    interfaceConnector(url: widget.itemData.api, param: {}).then((res) {
      isLoading = false;
      if (res != null && res.data['list'] is List) {
        isError = false;
        list =
            res.data['list'].map((json) => VideoModel.fromJson(json)).toList();
        ads = res.data['ads'];
        setState(() {});
      } else {
        isError = true;
        setState(() {});
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) return loadingWiget();
    if (isError || list.isEmpty) return noDataWidget();
    return PullRefreshList(
      isAll: true,
      onRefresh: initLoadingData,
      child: MvListPage(
        type: widget.itemData.type == 'short' ? 2 : 1,
        isRank: true,
        dataList: list,
      ),
    );
  }
}
