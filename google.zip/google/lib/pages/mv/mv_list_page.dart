import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:iaimei/pages/mv/mv_item_page.dart';
import 'package:iaimei/widget/convenient_mixin.dart';
import 'package:waterfall_flow/waterfall_flow.dart';

class MvListPage extends StatefulWidget {
  /// type: 0 - 瀑布流； 1 - 1列； 2 - 2列
  /// onPlayer -> 自定义视频播放 int 索引
  const MvListPage({
    Key? key,
    this.topPadding,
    this.type = 1,
    this.dataList = const [],
    this.isRank = false,
    this.onPlayer,
  }) : super(key: key);

  final int type;
  final double? topPadding;
  final List dataList;
  final bool isRank;
  final void Function()? Function(int)? onPlayer;

  @override
  State<MvListPage> createState() => _MvListPageState();
}

class _MvListPageState extends State<MvListPage> with ConvenientMixin {
  @override
  Widget build(BuildContext context) {
    return _buildMvColumnStyleWidget(widget.type);
  }

  Widget _buildMvColumnStyleWidget(int type) {
    switch (type) {
      case 1:
        return _buildLongVodeoWidget();
      case 2:
        return _buildSmallVideoWidget();
      default:
        return _buildWaterfallMvWidget();
    }
  }

  Widget _buildSmallVideoWidget() {
    double top = widget.topPadding ?? 10.w;
    return GridView.builder(
      physics: const NeverScrollableScrollPhysics(),
      shrinkWrap: true,
      itemCount: widget.dataList.length,
      padding: EdgeInsets.fromLTRB(3.w, top, 3.w, 20.w),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          childAspectRatio: 0.625,
          crossAxisSpacing: 3.w,
          mainAxisSpacing: 3.w),
      itemBuilder: (BuildContext context, int index) {
        return MvItemWidget(
          width: 183.w,
          height: 289.w,
          index: index,
          items: widget.dataList,
          isRank: widget.isRank,
        );
      },
    );
  }

  Widget _buildLongVodeoWidget() {
    double top = widget.topPadding ?? 10.w;
    return ListView.builder(
      physics: const NeverScrollableScrollPhysics(),
      shrinkWrap: true,
      itemCount: widget.dataList.length,
      padding: EdgeInsets.fromLTRB(16.w, top, 16.w, 20.w),
      itemBuilder: (BuildContext context, int index) {
        return MvItemWidget(
          width: 343.w,
          height: 233.w,
          margin: EdgeInsets.only(bottom: 15.w),
          index: index,
          items: widget.dataList,
          isRank: widget.isRank,
        );
      },
    );
  }

  Widget _buildWaterfallMvWidget() {
    return WaterfallFlow.builder(
      primary: false,
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).padding.bottom +
            ScreenUtil().bottomBarHeight,
        left: ScreenUtil().setWidth(3),
        right: ScreenUtil().setWidth(3),
      ),
      itemCount: widget.dataList.length,
      gridDelegate: SliverWaterfallFlowDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisSpacing: 10.w,
        crossAxisSpacing: 10.w,
      ),
      itemBuilder: (BuildContext context, int index) {
        return const SizedBox();
      },
    );
  }
}
