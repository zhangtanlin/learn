import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:iaimei/components/calendar/utils/models.dart';
import 'package:iaimei/components/calendar/utils/top_modal_sheet.dart';
import 'package:iaimei/components/common/commonelements.dart';
import 'package:iaimei/components/common/pullrefreshlist.dart';
import 'package:iaimei/components/common/stackpage.dart';
import 'package:iaimei/model/video_model.dart';
import 'package:iaimei/net/http_error.dart';
import 'package:iaimei/pages/mv/mv_list_page.dart';
import 'package:iaimei/utils/api.dart';
import 'package:iaimei/widget/convenient_mixin.dart';
import 'package:iaimei/widget/state_mixin.dart';

class MvSeriesDetailPage extends StatefulWidget {
  const MvSeriesDetailPage({Key? key, required this.params}) : super(key: key);
  final WaterfallExtra params;

  @override
  State<MvSeriesDetailPage> createState() => _MvSeriesDetailPageState();
}

class _MvSeriesDetailPageState extends State<MvSeriesDetailPage>
    with ConvenientMixin, StateMixin {
  bool showDate = false;
  Date? selectedDate;
  DateTime? selectedDateTime;

  @override
  void initLoadingData() {
    Map<String, dynamic> param = {
      'page': currentPage,
      'date': selectedDate?.toString() ?? '',
    };
    if (widget.params.params != null) {
      param['id'] = widget.params.params['id'];
    }

    interfaceConnector(url: widget.params.url, param: param).then((res) {
      if (res != null) {
        var list = [];
        if (res.data is List) {
          list = (res.data as List)
              .map((item) => VideoModel.fromJson(item))
              .toList();
        } else {
          var series = res.data['row'];
          if (series != null && series is Map) {
            showDate = series['show_date'] == 1;
          }
          list = (res.data['list'] as List)
              .map((item) => VideoModel.fromJson(item))
              .toList();
        }
        updateListAndWidgetState(list);
      } else {
        dealWithErrorsWidgetState(HttpError());
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return StackPage(
      header: CustomHeader(
        title: widget.params.title,
        rListWidget: [
          Offstage(
            offstage: showDate == false,
            child: GestureDetector(
              onTap: () async {
                Date? dateValue = await showCalendar(
                  context: context,
                  selectedDate: selectedDateTime,
                );
                selectedDate = dateValue;
                if (dateValue != null) {
                  selectedDateTime = DateTime(
                    int.parse(dateValue.year.toString()),
                    int.parse(dateValue.month.toString()),
                    int.parse(dateValue.day.toString()),
                  );
                  onRefresh(); // 重新请求
                }
              },
              child: Image.asset(
                "assets/images/common/action_calendar.png",
                width: 36.w,
                height: 36.w,
              ),
            ),
          ),
          SizedBox(width: 16.w),
        ],
      ),
      child: _buildContainerWidget(),
    );
  }

  Widget _buildContainerWidget() {
    if (widgetState != WidgetState.finish &&
        widgetState != WidgetState.noData) {
      return placeholderWidget();
    }

    return PullRefreshList(
      isAll: isAll,
      onRefresh: onRefresh,
      onLoading: onLoading,
      child: MvListPage(
        type: widget.params.isWaterfallsflow ? 0 : widget.params.crossAxisCount,
        dataList: dataList,
      ),
    );
  }
}
