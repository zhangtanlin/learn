import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:iaimei/widget/convenient_mixin.dart';

class MvSeriesTitlePage extends StatefulWidget {
  const MvSeriesTitlePage(
      {Key? key, required this.title, this.subTitle = '', this.onTap})
      : super(key: key);
  final String title;
  final String subTitle;
  final void Function()? onTap;
  @override
  State<MvSeriesTitlePage> createState() => _MvSeriesTitlePageState();
}

class _MvSeriesTitlePageState extends State<MvSeriesTitlePage>
    with ConvenientMixin {
  @override
  Widget build(BuildContext context) {
    return _buildCommonTitleWidget(
      widget.title,
      subTitle: widget.subTitle,
      onTap: widget.onTap,
    );
  }

  Widget _buildCommonTitleWidget(String title, {String subTitle = '', onTap}) {
    return GestureDetector(
      behavior: HitTestBehavior.translucent,
      onTap: onTap,
      child: Container(
        alignment: Alignment.centerLeft,
        height: subTitle.isEmpty ? 54.w : 72.w,
        padding: EdgeInsets.symmetric(horizontal: 16.w),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: TextStyle(
                          color: wColor, fontWeight: fontM, fontSize: 18.sp),
                      overflow: TextOverflow.ellipsis,
                      maxLines: 1,
                    ),
                    Offstage(
                      offstage: subTitle.isEmpty,
                      child: Text(
                        subTitle,
                        style: TextStyle(color: color_72, fontSize: 12.sp),
                        overflow: TextOverflow.ellipsis,
                        maxLines: 1,
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(width: 13.w),
              Image.asset(
                "assets/images/common/arrow_go.png",
                width: 12.w,
                height: 18.w,
                fit: BoxFit.cover,
              ),
            ],
          ),
        ]),
      ),
    );
  }
}
