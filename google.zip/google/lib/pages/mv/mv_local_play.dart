import 'package:flick_video_player/flick_video_player.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:iaimei/components/common/base_dialog.dart';
import 'package:iaimei/components/common/commonelements.dart';
import 'package:iaimei/mixin/video_related_mixin.dart';
import 'package:iaimei/model/video_model.dart';
import 'package:iaimei/net/http_helper.dart';
import 'package:iaimei/pages/video/flick_short_video_full_controls.dart';
import 'package:iaimei/pages/video/long_video_player.dart';
import 'package:iaimei/res/color_res.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/res/img_res.dart';
import 'package:iaimei/utils/video_util.dart';
import 'package:iaimei/widget/app_img_widget.dart';
import 'package:iaimei/widget/buttom_widget.dart';
import 'package:iaimei/widget/convenient_mixin.dart';
import 'package:iaimei/widget/network_img_widget.dart';
import 'package:provider/provider.dart';
import 'package:video_player/video_player.dart';
import 'package:visibility_detector/visibility_detector.dart';

class LocalShortMvPlayerWidget extends StatefulWidget {
  final VideoModel? data;
  final bool isLocal;
  const LocalShortMvPlayerWidget({Key? key, this.data, this.isLocal = false})
      : super(key: key);

  @override
  State<LocalShortMvPlayerWidget> createState() =>
      _LocalShortMvPlayerWidgetState();
}

class _LocalShortMvPlayerWidgetState extends State<LocalShortMvPlayerWidget>
    with VideoRelatedMixin, ConvenientMixin {
  VideoModel? _videoModel;
  FlickManager? flickManager;

  @override
  void initState() {
    super.initState();
    _videoModel = widget.data ?? VideoModel();
    // _initVideoAction(_videoModel);
    toVideoDetail();
  }

  toVideoDetail() {
    HttpHelper.getVideoDetail(_videoModel!.id, (data) {
      var dest = VideoModel.fromJson(data);

      // 视频播放限制条件
      if (VideoUtil.isFreeVideo(dest)) {
        _initVideoAction(_videoModel, isChange: false);
      }
      // 不满足播放条件
      else {
        _showTipsDialog(VideoUtil.getVideoTips(dest));
      }

      // 播放记录
      // if (dest.id != 0) {
      //   AppGlobal.storeHistory(BrowseKey.video, dest.toJson());
      // }
    }, (error) {});
  }

  void _showTipsDialog(String content) {
    BaseDialog.showdialog(
      context,
      insetPadding: 30,
      barrierDismissible: true,
      child: Column(
        children: [
          SizedBox(height: 40.w),
          Text(
            '温馨提示',
            style: TextStyle(color: wColor, fontSize: 18.sp, fontWeight: fontM),
          ),
          SizedBox(height: 10.w),
          Text(
            content,
            style: TextStyle(color: rColor, fontWeight: fontM),
          ),
          SizedBox(height: 20.w),
          ButtonWidget.build('确定', onTap: () => Navigator.pop(context)),
          SizedBox(height: 20.w),
        ],
      ),
    );
  }

  Future<void> _initVideoAction(VideoModel? videoModel,
      {bool isChange = false}) async {
    String url =
        await VideoUtil.getRealVideoUrl(videoModel, isLocal: widget.isLocal);
    initVideo(url, isChange: isChange);
  }

  initVideo(String url, {bool isChange = false}) {
    if (!isChange) {
      flickManager = FlickManager(
          videoPlayerController: VideoPlayerController.network(url));
    } else {
      //更改播放地址
      // controller!..setLooping(VideoUtil.isFreeVideo(videoModel))
      flickManager!.handleChangeVideo(VideoPlayerController.network(url));
    }

    if (!kIsWeb) {
      flickManager!.flickVideoManager!.videoPlayerController!.play();
    }
    setState(() {});
  }

  _buildLoadingSection() {
    return Stack(
      children: [
        SizedBox(
          width: double.infinity,
          height: double.infinity,
          child: NetworkImgWidget(
            fit: BoxFit.fitWidth,
            url: _videoModel?.coverThumbUrl ?? '',
          ),
        ),
        const Center(
          child: SpinKitFadingCircle(
            color: ColorRes.color_ff00b3,
            size: 45.0,
          ),
        ),
        Container(
          height: double.infinity,
          alignment: Alignment.topCenter,
          padding: EdgeInsets.only(
            left: 0,
            right: 15,
            top: MediaQuery.of(context).padding.top,
            bottom: 40,
          ),
          child: const CustomHeader(),
        ),
      ],
    );
  }

  @override
  void dispose() {
    super.dispose();
    if (flickManager != null) {
      flickManager?.dispose();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Stack(children: [
      Image.asset(
        ImgRes.IMG_APP_BG,
        fit: BoxFit.cover,
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
      ),
      flickManager == null
          ? _buildLoadingSection()
          : _buildVideoPalyerWidget()
    ]);
  }

  Widget _buildVideoPalyerWidget() {
    return VisibilityDetector(
      key: ObjectKey(flickManager),
      onVisibilityChanged: (VisibilityInfo visibility) {
        if (visibility.visibleFraction == 0 && mounted) {
          flickManager!.flickControlManager!.autoPause();
        } else if (visibility.visibleFraction == 1) {
          flickManager!.flickControlManager!.autoResume();
        }
      },
      child: Container(
        width: double.infinity,
        height: double.infinity,
        color: Colors.transparent,
        child: FlickVideoPlayer(
          flickManager: flickManager!,
          flickVideoWithControls: FlickVideoWithControls(
            backgroundColor: Colors.transparent,
            videoFit: BoxFit.contain,
            playerLoadingFallback: _buildLoadingSection(),
            playerErrorFallback: Container(),
            controls: const ShortVideoLocalControls(),
          ),
          flickVideoWithControlsFullscreen: FlickVideoWithControls(
            videoFit: BoxFit.contain,
            controls: FlickShortVideoFullControls(data: _videoModel),
          ),
        ),
      ),
    );
  }
}

class ShortVideoLocalControls extends StatelessWidget {
  const ShortVideoLocalControls({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    FlickControlManager controlManager =
        Provider.of<FlickControlManager>(context);
    FlickVideoManager videoManager = Provider.of<FlickVideoManager>(context);
    double aspectRatio = videoManager.videoPlayerValue?.aspectRatio ?? 1.0;
    return Stack(
      children: <Widget>[
        Positioned.fill(
          child: FlickShowControlsAction(
            handleVideoTap: () {
              videoManager != null && videoManager.isVideoEnded
                  ? controlManager.replay()
                  : controlManager.togglePlay();
            },
            child: Stack(
              children: [
                Positioned(
                  child: const CustomHeader(),
                  left: 0,
                  right: 15,
                  top: DimenRes.statusBarHeight,
                ),
                !kIsWeb && aspectRatio > 1
                    ? Container(
                        padding: EdgeInsets.only(
                            top: DimenRes.screenWidth / aspectRatio +
                                DimenRes.statusBarHeight +
                                DimenRes.dimen_40),
                        alignment: Alignment.center,
                        child: FlickFullScreenToggle(
                          size: 18,
                          enterFullScreenChild: AppImgWidget(
                            path: ImgRes.IC_FULL_SCREEN_S,
                            height: 36,
                          ),
                          exitFullScreenChild: AppImgWidget(
                            path: ImgRes.IC_EXIT_FULL_SCREEN,
                            width: 18,
                          ),
                        ),
                      )
                    : const SizedBox(),
                Positioned(
                  left: 15,
                  right: 15,
                  bottom: 40,
                  child: _buildBottomBar(),
                )
              ],
            ),
          ),
        ),
        IgnorePointer(
          ignoring: true,
          child: Center(
            child: AnimatedOpacity(
              opacity: videoManager.isVideoInitialized &&
                      !videoManager.isBuffering &&
                      !videoManager.isPlaying
                  ? 1.0
                  : 0.0,
              duration: const Duration(milliseconds: 300),
              child: Image.asset(
                'assets/images/video/ic_video_play.png',
                width: 50,
                height: 50,
              ),
            ),
          ),
        ),
        Center(
            child: AnimatedOpacity(
          opacity: !videoManager.isVideoInitialized || videoManager.isBuffering
              ? 1.0
              : 0.0,
          duration: const Duration(milliseconds: 100),
          child: const SpinKitFadingCircle(
            color: ColorRes.color_ff00b3,
            size: 45.0,
          ),
        ))
      ],
    );
  }

  _buildBottomBar() {
    return Container(
      margin: const EdgeInsets.only(top: 40),
      child: Row(
        children: <Widget>[
          kIsWeb ? const FlickSoundToggle(size: 24) : const SizedBox(),
          const SizedBox(width: kIsWeb ? 15 : 0),
          Expanded(
            child: FlickVideoProgressBar(
              flickProgressBarSettings: FlickProgressBarSettings(
                height: 3,
                handleRadius: 5,
                curveRadius: 0,
                backgroundColor: Colors.white.withOpacity(0.12),
                bufferedColor: const Color.fromRGBO(255, 54, 218, 0.3),
                playedColor: const Color.fromRGBO(255, 54, 218, 0.8),
                handleColor: const Color.fromRGBO(255, 54, 218, 0.8),
              ),
            ),
          ),
          const SizedBox(width: 18),
          const FlickCurrentPosition(fontSize: 14),
          const Text(
            ' / ',
            style: TextStyle(color: Colors.white, fontSize: 14),
          ),
          const FlickTotalDuration(fontSize: 14),
        ],
      ),
    );
  }
}

class LocalLongMvPlayerWidget extends StatefulWidget {
  const LocalLongMvPlayerWidget({Key? key, this.data, this.isLocal = false})
      : super(key: key);
  final VideoModel? data;
  final bool isLocal;
  @override
  State<LocalLongMvPlayerWidget> createState() =>
      _LocalLongMvPlayerWidgetState();
}

class _LocalLongMvPlayerWidgetState extends State<LocalLongMvPlayerWidget> {
  bool isLike = false;
  late VideoModel _videoModel;

  @override
  void initState() {
    super.initState();
    _videoModel = widget.data ?? VideoModel();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.black.withOpacity(0.95),
        body: Stack(
          children: [
            Container(
              width: double.infinity,
              height: double.infinity,
              color: Colors.transparent,
              child: GestureDetector(
                onTap: () {
                  Navigator.pop(context);
                },
                behavior: HitTestBehavior.translucent,
              ),
            ),
            _buildLongVideoPlayer(),
          ],
        ));
  }

  Center _buildLongVideoPlayer() {
    return Center(
      child: LayoutBuilder(
        builder: (BuildContext context, BoxConstraints constraints) {
          double tempWidth = constraints.maxWidth;
          double tempHeight = tempWidth * 9 / 16;
          return Container(
            color: Colors.white12,
            width: double.infinity,
            height: tempHeight,
            child: LongVideoPlayer(data: _videoModel, isLocal: widget.isLocal),
          );
        },
      ),
    );
  }
}
