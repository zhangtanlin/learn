import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:iaimei/components/common/commonelements.dart';
import 'package:iaimei/components/common/pullrefreshlist.dart';
import 'package:iaimei/components/common/stackpage.dart';
import 'package:iaimei/net/http_helper.dart';
import 'package:iaimei/router/routers.dart';
import 'package:iaimei/widget/buttom_widget.dart';
import 'package:iaimei/widget/convenient_mixin.dart';
import 'package:iaimei/widget/state_mixin.dart';

class AgencyPage extends StatefulWidget {
  const AgencyPage({Key? key}) : super(key: key);

  @override
  State<AgencyPage> createState() => _AgencyPageState();
}

class _AgencyPageState extends State<AgencyPage> with ConvenientMixin {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/images/common/app_bg.png'),
            fit: BoxFit.cover,
            alignment: Alignment.topCenter,
          ),
        ),
        child: Stack(
          children: [
            SingleChildScrollView(
              child: Image.asset(
                'assets/images/income/agency_bg.png',
                width: 375.w,
                height: 1620.w,
                fit: BoxFit.cover,
              ),
            ),
            Positioned(
              top: MediaQuery.of(context).padding.top + 4.w,
              left: 5.w,
              right: 16.w,
              child: CustomHeader(
                  title: '', rListWidget: [_buildLeftMoreWidget()]),
            ),
            Positioned(
              bottom: 68.w,
              left: 0,
              right: 0,
              child: ButtonWidget.build(
                '开启躺赚之路',
                onTap: () => context.push('/${Routes.spread}'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLeftMoreWidget() {
    return GestureDetector(
      onTap: () {
        context.push('/' + Routes.spreadRecord);
      },
      child: SizedBox(
        height: 36.w,
        child: Center(
          child: Text(
            '邀请记录',
            style: TextStyle(color: rColor, fontSize: 13.sp, fontWeight: fontM),
          ),
        ),
      ),
    );
  }
}

class SpreadRecord extends StatefulWidget {
  const SpreadRecord({Key? key}) : super(key: key);

  @override
  State<SpreadRecord> createState() => _SpreadRecordState();
}

class _SpreadRecordState extends State<SpreadRecord>
    with ConvenientMixin, StateMixin {
  @override
  Widget noDataWidget() {
    return buildDataWidget(
      icon: 'assets/images/common/ic_load_error.png',
      content: '暂无数据',
      btnText: '去推广',
      onTap: () => context.push('/' + Routes.spread),
    );
  }

  @override
  void initLoadingData() {
    HttpHelper.inviteList(param, (data) {
      var list = [];
      try {
        list = data is List ? data : data['data'];
      } catch (e) {
        debugPrint(e.toString());
      }
      updateListAndWidgetState(list);
    }, dealWithErrorsWidgetState);
  }

  @override
  Widget build(BuildContext context) {
    return StackPage(
      header: const CustomHeader(title: '邀请记录'),
      child: _buildContainerWidget(),
    );
  }

  Widget _buildContainerWidget() {
    if (widgetState != WidgetState.finish &&
        widgetState != WidgetState.noData) {
      return placeholderWidget();
    }
    return PullRefreshList(
      isAll: isAll,
      onRefresh: onRefresh,
      onLoading: onLoading,
      child: ListView.builder(
        itemCount: dataList.length,
        itemExtent: 66.w,
        padding: EdgeInsets.fromLTRB(16.w, 10.w, 16.w, 10.w),
        itemBuilder: (context, index) {
          return _buildRecordItemWidget(dataList[index]);
        },
      ),
    );
  }

  Widget _buildRecordItemWidget(Map objc) {
    return buildContainerWidget(
        width: 343.w,
        height: 56.w,
        margin: EdgeInsets.only(bottom: 10.w),
        padding: EdgeInsets.all(9.w),
        child: Row(children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  objc['nickname'] ?? '',
                  style: TextStyle(color: wColor, fontSize: 15.sp),
                  maxLines: 1,
                ),
                SizedBox(height: 3.w),
                Text(
                  objc['regdate_str'] ?? '',
                  style: TextStyle(color: color_64, fontSize: 11.sp),
                ),
              ],
            ),
          ),
          SizedBox(width: 10.w),
          Text(
            objc['is_reg'] == 1 ? '已注册' : '未注册',
            style: TextStyle(
              color: objc['is_reg'] == 1 ? wColor : rColor,
              fontSize: 12.sp,
              fontWeight: fontM,
            ),
          )
        ]));
  }
}
