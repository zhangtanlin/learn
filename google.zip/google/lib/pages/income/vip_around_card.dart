import 'package:card_swiper/card_swiper.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:iaimei/components/common/pullrefreshlist.dart';
import 'package:iaimei/pages/income/card_type_mixin.dart';
import 'package:iaimei/pages/income/pm_modal_mixin.dart';
import 'package:iaimei/pages/income/product_model.dart';
import 'package:iaimei/utils/networkimage.dart';
import 'package:iaimei/widget/convenient_mixin.dart';
import 'package:iaimei/widget/network_img_container.dart';

class VipAroundCard extends StatefulWidget {
  const VipAroundCard(
      {Key? key, this.isloading = true, required this.list, this.refreshBlock})
      : super(key: key);
  final bool isloading;
  final List<ProductItemModel> list;
  final void Function()? refreshBlock;
  @override
  State<VipAroundCard> createState() => _VipAroundCardState();
}

class _VipAroundCardState extends State<VipAroundCard>
    with ConvenientMixin, CardTypeMixin, PmModalMixin {
  @override
  Widget build(BuildContext context) {
    if (widget.isloading) return loadingWiget();

    if (widget.list.isEmpty) return noDataVipWidget();

    return Column(
      children: [
        Expanded(
          child: PullRefreshList(
            onRefresh: widget.refreshBlock,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                _buildProductWidget(),
                SizedBox(height: 35.w),
                Image.asset(
                  'assets/images/income/pm_vip_role.png',
                  height: 44.w,
                  fit: BoxFit.cover,
                ),
                _buildPrivateWidget(),
              ],
            ),
          ),
        ),
        Padding(
          padding: EdgeInsets.only(top: 15.w, bottom: 20.w),
          child: _buildBottomWidget(),
        ),
      ],
    );
  }

  int selectedIndex = 0;
  Widget _buildProductWidget() {
    return SizedBox(
      width: 375.w,
      height: 182.w,
      child: Swiper(
        loop: true,
        scale: 335 / 375,
        viewportFraction: 324 / 375, // 小于1可见上一个和下一个
        itemCount: widget.list.length,
        itemWidth: 324.w,
        itemHeight: 182.w,
        onIndexChanged: (index) {
          if (selectedIndex != index) {
            selectedIndex = index;
            setState(() {});
          }
        },
        itemBuilder: (ctx, index) {
          return buildVipCardWidget(
            widget.list[index],
            margin: EdgeInsets.zero,
          );
        },
      ),
    );
  }

  Widget _buildPrivateWidget() {
    return GridView.builder(
      padding: EdgeInsets.fromLTRB(16.w, 10.w, 16.w, 20.w),
      itemCount: widget.list[selectedIndex].right?.length,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 4,
        mainAxisSpacing: 13.w,
        mainAxisExtent: 76.w,
        crossAxisSpacing: 13.w,
      ),
      itemBuilder: (ctx, index) {
        return _buildPrivateItemWidget(
            widget.list[selectedIndex].right![index]);
      },
    );
  }

  Widget _buildPrivateItemWidget(ProductRightsItemModel item) {
    return Container(
      height: 76.w,
      width: 76.w,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12.w),
        color: const Color.fromRGBO(187, 121, 255, 0.06),
      ),
      child: Column(
        children: [
          SizedBox(height: 10.w),
          SizedBox(
            width: 36.w,
            height: 36.w,
            child: NetworkImgContainer(
              url: '${item.icon}',
              fit: BoxFit.contain,
            ),
          ),
          SizedBox(height: 7.w),
          Text('${item.name}',
              style: TextStyle(color: color_54, fontSize: 12.sp)),
        ],
      ),
    );
  }

  Widget _buildBottomWidget() {
    var item = widget.list[selectedIndex];
    return GestureDetector(
      onTap: () {
        showSelectedBottomSheet(item);
      },
      child: Container(
        padding: EdgeInsets.only(left: 23.w, right: 11.w),
        width: 343.w,
        height: 64.w,
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Color(0xff5b359a), Color(0xd68a38a6)],
            stops: [0, 1],
            begin: Alignment(0.99, -0.16),
            end: Alignment(-0.99, 0.16),
          ),
          borderRadius: BorderRadius.circular(32.w),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Image.asset('assets/images/income/pm_vip_service.png',
                width: 38.w, height: 38.w, fit: BoxFit.cover),
            SizedBox(
              width: 249.w,
              height: 44.w,
              child: Stack(
                clipBehavior: Clip.none,
                children: [
                  Image.asset('assets/images/income/pm_vip_price.png'),
                  Positioned(
                    top: -2,
                    child: _buildPointWidget(item),
                  ),
                  Positioned(
                    top: 10.w,
                    left: 115.w,
                    child: _buildTPriceWidget(item),
                  ),
                  _buildCPriceWidget(item),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPointWidget(ProductItemModel item) {
    return Offstage(
      offstage: !item.isActivity,
      child: Container(
        width: 105.w,
        height: 24.w,
        decoration: const BoxDecoration(
          image: DecorationImage(
              image: AssetImage('assets/images/income/pm_vip_news.png'),
              fit: BoxFit.cover),
        ),
        child: Center(
          child: Text(
            '新人特价 ${item.limitH}',
            style: TextStyle(color: wColor, fontSize: 10.sp, fontWeight: fontM),
          ),
        ),
      ),
    );
  }

  Widget _buildTPriceWidget(ProductItemModel item) {
    return Offstage(
      offstage: !item.isActivity,
      child: Row(children: _buildPricesWidget(item)),
    );
  }

  Widget _buildCPriceWidget(ProductItemModel item) {
    return Offstage(
      offstage: item.isActivity,
      child: Center(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: _buildPricesWidget(item),
        ),
      ),
    );
  }

  List<Widget> _buildPricesWidget(ProductItemModel item) {
    return [
      Text(
        '¥ ${item.p} ',
        style: TextStyle(
          color: wColor,
          fontSize: 18.sp,
          fontWeight: fontB,
        ),
      ),
      Text(
        '¥${item.op}',
        style: TextStyle(
          color: color_54,
          fontSize: 12.sp,
          decoration: TextDecoration.lineThrough,
        ),
      ),
    ];
  }
}
