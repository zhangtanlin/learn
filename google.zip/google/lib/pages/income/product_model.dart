class ProductModel {
  String coins =  '0';
  int gCoins = 0;
  dynamic ads;
  List<ProductItemModel>? list;
  String? desc;

  ProductModel();
  ProductModel.fromJson(Map<String, dynamic> json) {
    coins = json['coins'] ?? '0';
    gCoins = json['g_coins'] ?? 0;
    ads = json['ads'];
    desc = json['desc'] ?? '';
    if (json['list'] is List) {
      list = json['list']
          .map<ProductItemModel>((v) => ProductItemModel.fromJson(v))
          .toList();
    } else {
      list = [];
    }
  }

  Map<String, dynamic> toJson() {
    return <String, dynamic>{
      'ads': ads,
      'list': list?.map((e) => e.toJson()).toList() ?? [],
    };
  }
}

class ProductItemModel {
  int? id;
  String? pname;
  String? sname;
  String? bgImg;
  int? op; // 原价
  int? p; // 价格
  int? coins; // 钻石
  int? freeCoins; // 赠送钻石
  String? description;
  int? validDate;
  int? vipLevel; // 等级
  List<dynamic>? pw; // 支付方式 pg 代理
  bool isActivity = false; // 是否活动限时卡
  dynamic limitH; // 是活动限时卡 多少小时截止
  int? cardType; // 卡片类型  1全能卡  0 单项卡 2 超值卡
  List<ProductRightsItemModel>? right; // 享受权益
  String? expiredDate; // 过期时间
  int needGain = 0;

  ProductItemModel();
  ProductItemModel.fromJson(Map<String, dynamic> json) {
    id = json['id'] ?? 0;
    pname = json['pname'] ?? '';
    sname = json['sname'] ?? '';
    bgImg = json['img'] ?? '';
    op = json['op'] ?? 0;
    p = json['p'] ?? 0;
    coins = json['coins'] ?? 0;
    freeCoins = json['free_coins'] ?? 0;
    description = json['description'] ?? '';
    validDate = json['valid_date'] ?? 0;
    vipLevel = json['vip_level'] ?? 0;
    pw = json['pw'] ?? [];
    isActivity = json['is_a'] == 1 ? true : false;
    limitH = json['limit_h'];
    cardType = json['card_type'] ?? 0;
    if (json['right'] is List && json['right'].length > 0) {
      right = json['right']
          .map<ProductRightsItemModel>(
              (v) => ProductRightsItemModel.fromJson(v))
          .toList();
    } else {
      right = [];
    }
    expiredDate = json['expired_date'] ?? '';
    needGain = json['need_gain'] ?? 0;
  }
  Map<String, dynamic> toJson() {
    return <String, dynamic>{
      'id': id,
      'pname': pname,
      'sname': sname,
      'img': bgImg,
      'op': op,
      'p': p,
      'coins': coins,
      'free_coins': freeCoins,
      'description': description,
      'valid_date': validDate,
      'vip_level': vipLevel,
      'pw': pw,
      'is_a': isActivity == true ? 1 : 0,
      'limit_h': limitH,
      'card_type': cardType,
      'right': right?.map((e) => e.toJson()).toList() ?? [],
      'need_gain': needGain,
    };
  }
}

class ProductRightsItemModel {
  int? id;
  String? name;
  String? desc;
  String? icon;

  ProductRightsItemModel();

  ProductRightsItemModel.fromJson(Map<String, dynamic> json) {
    id = json['id'] ?? '';
    name = json['name'] ?? '';
    desc = json['desc'] ?? '';
    icon = json['img_url'] ?? '';
  }

  Map<String, dynamic> toJson() {
    return <String, dynamic>{
      'id': id,
      'name': name,
      'desc': desc,
      'img_url': icon,
    };
  }
}

/* ********************************************************** */
class PmRecordItemModel {
  String orderId = '';
  String descp = '';
  String updated = '';
  String created = '';
  String amountRmb = '';
  String payAmountRmb = '';
  String status = '';

  PmRecordItemModel();
  PmRecordItemModel.fromJson(Map<String, dynamic> json) {
    orderId = json['order_id'];
    descp = json['descp'];
    updated = json['updated_str'];
    created = json['created_str'];
    amountRmb = json['amount_rmb'];
    payAmountRmb = json['pay_amount_rmb'];
    status = json['status_str'];
  }

  Map<String, dynamic> toJson() {
    return <String, dynamic>{
      'order_id': orderId,
      'descp': descp,
      'updated_str': updated,
      'created_str': created,
      'amount_rmb': amountRmb,
      'pay_amount_rmb': payAmountRmb,
      'status_str': status,
    };
  }
}