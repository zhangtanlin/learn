import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:iaimei/components/common/pageviewmixin.dart';
import 'package:iaimei/components/common/stackpage.dart';
import 'package:iaimei/components/common/commonelements.dart';
import 'package:iaimei/pages/mv/nav_tab_bar_mixin.dart';
import 'package:iaimei/widget/convenient_mixin.dart';

import 'kinds_details.dart';

class FundingDetails extends StatefulWidget {
  const FundingDetails({Key? key, this.index = 0}) : super(key: key);
  final int index;
  @override
  State<FundingDetails> createState() => _FundingDetailsState();
}

class _FundingDetailsState extends State<FundingDetails>
    with TickerProviderStateMixin, ConvenientMixin {
  int selectedIndex = 0;
  late TabController tabController;
  List<String> items = ['充值', '消费', '收益', '提现'];

  @override
  void initState() {
    super.initState();

    selectedIndex = widget.index;
    if (selectedIndex >= items.length) {
      selectedIndex = 0;
    }

    tabController = TabController(
      length: items.length,
      vsync: this,
      initialIndex: selectedIndex,
    );
    tabController.addListener(() {
      setState(() => selectedIndex = tabController.index);
    });
  }

  @override
  Widget build(BuildContext context) {
    return StackPage(
      header: CustomHeader(
        titleWidget: _buildTabBarWidget(),
        rListWidget: [_buildLeftMoreWidget()],
      ),
      child: _buildTabBarViewWidget(),
    );
  }

  Widget _buildLeftMoreWidget() {
    return GestureDetector(
      onTap: () => context.push('/onlineService'),
      child: Container(
        height: 36.w,
        padding: EdgeInsets.only(right: 16.w),
        child: Center(
          child: Text(
            '客服',
            style: TextStyle(color: rColor, fontSize: 13.sp, fontWeight: fontM),
          ),
        ),
      ),
    );
  }

  Widget _buildTabBarWidget() {
    return NavTabBarWidget(
      tabVc: tabController,
      tabs: items,
      textPadding: EdgeInsets.symmetric(horizontal: 15.w),
      norTextStyle: TextStyle(
          color: wColor, fontSize: 14.sp, fontWeight: FontWeight.w400),
      selTextStyle:
          TextStyle(color: rColor, fontSize: 18.sp, fontWeight: fontM),
      selectedIndex: selectedIndex,
    );
  }

  Widget _buildTabBarViewWidget() {
    return TabBarView(
      controller: tabController,
      children: items.asMap().keys.map<Widget>((index) {
        switch (index) {
          case 0:
            return PageViewMixin(child: const PaymentDetails());
          case 1:
            return PageViewMixin(child: const ExpendDetails());
          case 2:
            return PageViewMixin(child: const IncomeDetails());
          default:
            return PageViewMixin(child: const WithdrawDetails());
        }
      }).toList(),
    );
  }
}
