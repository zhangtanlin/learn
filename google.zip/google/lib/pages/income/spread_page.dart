import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:bot_toast/bot_toast.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:iaimei/components/common/commonelements.dart';
import 'package:iaimei/components/common/stackpage.dart';
import 'package:iaimei/model/user_info_model.dart';
import 'package:iaimei/store/userdata.dart';
import 'package:iaimei/utils/common.dart';
import 'package:iaimei/widget/buttom_widget.dart';
import 'package:iaimei/widget/convenient_mixin.dart';
import 'package:image_gallery_saver/image_gallery_saver.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:provider/provider.dart';
import 'package:qr_flutter/qr_flutter.dart';

class SpreadPage extends StatefulWidget {
  const SpreadPage({Key? key}) : super(key: key);

  @override
  State<SpreadPage> createState() => _SpreadPageState();
}

class _SpreadPageState extends State<SpreadPage> with ConvenientMixin {
  late UserInfoModel user;
  @override
  void initState() {
    super.initState();
    user = Provider.of<UserData>(context, listen: false).userInfo;
  }

  @override
  Widget build(BuildContext context) {
    return StackPage(
      header: const CustomHeader(title: '邀请码'),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            RepaintBoundary(
              key: certificateWidgetKey,
              child: Container(
                height: 533.w,
                width: 343.w,
                margin: EdgeInsets.only(top: 10.w),
                decoration: const BoxDecoration(
                    image: DecorationImage(
                        image:
                            AssetImage('assets/images/income/spread_bg.png'))),
                child: Stack(
                  children: [
                    Positioned(
                      right: 48.w,
                      top: 270.w,
                      child: Container(
                        padding: EdgeInsets.all(0.w),
                        height: 100.w,
                        width: 100.w,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10.w),
                            color: Colors.black.withOpacity(0.7)),
                        child: QrImage(
                            data: user.shareUrl ?? '',
                            version: 3,
                            foregroundColor: wColor),
                      ),
                    ),
                    Positioned(
                      left: 200.w,
                      top: 370.w,
                      child: Text(
                        '邀请码：${user.affCode}',
                        style: TextStyle(
                            color: rColor, fontSize: 10.sp, fontWeight: fontB),
                      ),
                    ),
                    Positioned(
                      left: 36.w,
                      top: 355.w,
                      child: SizedBox(
                        width: 150.w,
                        child: FittedBox(
                          child: Text(
                            '下载链接：\n${user.shareUrl}',
                            style: TextStyle(
                              fontSize: 12.sp,
                              color: const Color(0xff16f2e3),
                              fontWeight: fontB,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height: 30.w),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ButtonWidget.build('保存图片', onTap: saveImageAction),
                SizedBox(width: 53.w),
                ButtonWidget.build('复制链接', style: IconStyle.purple, onTap: () {
                  Clipboard.setData(ClipboardData(text: user.shareText));
                  Method.showText('复制成功，快去分享吧～');
                }),
              ],
            ),
            SizedBox(height: 20.w),
          ],
        ),
      ),
    );
  }

  void saveImageAction() async {
    if (kIsWeb) {
      Method.showText('请自行截图保存分享哦～');
    } else if (Platform.isIOS) {
      try {
        BotToast.showLoading();
        localStorageImage();
        BotToast.closeAllLoading();
      } catch (e) {
        Method.showText('您拒绝了存储权限，请前往设置中打开权限');
      }
    } else {
      BotToast.showLoading();
      PermissionStatus storageStatus = await Permission.camera.status;
      if (storageStatus == PermissionStatus.denied) {
        storageStatus = await Permission.camera.request();
        if (storageStatus == PermissionStatus.denied ||
            storageStatus == PermissionStatus.permanentlyDenied) {
          Method.showText('您拒绝了存储权限，请前往设置中打开权限');
        } else {
          localStorageImage();
        }
        BotToast.closeAllLoading();
        return;
      } else if (storageStatus == PermissionStatus.permanentlyDenied) {
        BotToast.closeAllLoading();
        Method.showText('无法保存到相册中，你关闭了存储权限，请前往设置中打开权限');
        return;
      }
      localStorageImage();
      BotToast.closeAllLoading();
    }
  }

  GlobalKey certificateWidgetKey = GlobalKey();
  @protected
  void localStorageImage() async {
    RenderRepaintBoundary? boundary = certificateWidgetKey.currentContext
        ?.findRenderObject() as RenderRepaintBoundary?;
    ui.Image? image = await boundary?.toImage(pixelRatio: 3.0);
    ByteData? byteData = await image?.toByteData(
      format: ui.ImageByteFormat.png,
    );
    Uint8List pngBytes = byteData!.buffer.asUint8List();
    final result = await ImageGallerySaver.saveImage(pngBytes);
    if (result['isSuccess']) {
      Method.showText('图片保存成功～');
    } else if (Platform.isAndroid && result.length > 0) {
      Method.showText('图片保存成功～');
    }
  }
}
