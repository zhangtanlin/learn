import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:iaimei/components/common/pullrefreshlist.dart';
import 'package:iaimei/net/http_helper.dart';
import 'package:iaimei/pages/income/income_model.dart';
import 'package:iaimei/utils/common.dart';
import 'package:iaimei/widget/convenient_mixin.dart';
import 'package:iaimei/widget/state_mixin.dart';

/* ***** ***** ***** 充值明细 ***** ***** ***** */
class PaymentDetails extends StatefulWidget {
  const PaymentDetails({Key? key}) : super(key: key);

  @override
  State<PaymentDetails> createState() => _PaymentDetailsState();
}

class _PaymentDetailsState extends State<PaymentDetails>
    with ConvenientMixin, DetailsMixin, StateMixin {
  @override
  void initLoadingData() {
    HttpHelper.paymentList(param, (data) {
      var list = [];
      try {
        list = (data['list'] as List)
            .map((item) => PaymentItemModel.fromJson(item))
            .toList();
      } catch (error) {
        debugPrint(error.toString());
      }
      updateListAndWidgetState(list);
    }, dealWithErrorsWidgetState);
  }

  @override
  Widget noDataWidget() {
    return buildDataWidget(
        icon: 'assets/images/common/ic_load_error.png',
        content: '暂无数据',
        btnText: '去充值',
        onTap: () => context.push('/rechargeCoins'));
  }

  @override
  Widget build(BuildContext context) {
    if (widgetState != WidgetState.finish &&
        widgetState != WidgetState.noData) {
      return placeholderWidget();
    }
    return PullRefreshList(
      isAll: isAll,
      onRefresh: onRefresh,
      onLoading: onLoading,
      child: ListView.builder(
        physics: const ClampingScrollPhysics(),
        itemBuilder: (BuildContext c, int i) {
          return buildItemWidget(dataList[i]);
        },
        itemCount: dataList.length,
        padding: EdgeInsets.only(top: 10.w),
      ),
    );
  }
}

/* ***** ***** ***** 收益明细 ***** ***** ***** */
class IncomeDetails extends StatefulWidget {
  const IncomeDetails({Key? key}) : super(key: key);

  @override
  State<IncomeDetails> createState() => _IncomeDetailsState();
}

class _IncomeDetailsState extends State<IncomeDetails>
    with ConvenientMixin, DetailsMixin, StateMixin {
  @override
  void initLoadingData() {
    var param = this.param..['type'] = 'income';
    HttpHelper.expendIncome(param, (data) {
      var list = [];
      try {
        list = (data['list'] as List)
            .map((item) => IncomeExpendModel.fromJson(item))
            .toList();
      } catch (error) {
        debugPrint(error.toString());
      }
      updateListAndWidgetState(list);
    }, dealWithErrorsWidgetState);
  }

  @override
  Widget build(BuildContext context) {
    if (widgetState != WidgetState.finish &&
        widgetState != WidgetState.noData) {
      return placeholderWidget();
    }
    return PullRefreshList(
      isAll: isAll,
      onRefresh: onRefresh,
      onLoading: onLoading,
      child: ListView.builder(
        physics: const ClampingScrollPhysics(),
        itemBuilder: (BuildContext c, int i) {
          return buildItemWidget(dataList[i]);
        },
        itemCount: dataList.length,
        padding: const EdgeInsets.all(0.0),
      ),
    );
  }
}

/* ***** ***** ***** 消费明细 ***** ***** ***** */

class ExpendDetails extends StatefulWidget {
  const ExpendDetails({Key? key}) : super(key: key);

  @override
  State<ExpendDetails> createState() => _ExpendDetailsState();
}

class _ExpendDetailsState extends State<ExpendDetails>
    with ConvenientMixin, DetailsMixin, StateMixin {
  @override
  void initLoadingData() {
    var param = this.param..['type'] = 'expend';
    HttpHelper.expendIncome(param, (data) {
      var list = [];
      try {
        list = (data['list'] as List)
            .map((item) => IncomeExpendModel.fromJson(item))
            .toList();
      } catch (error) {
        debugPrint(error.toString());
      }
      updateListAndWidgetState(list);
    }, dealWithErrorsWidgetState);
  }

  @override
  Widget build(BuildContext context) {
    if (widgetState != WidgetState.finish &&
        widgetState != WidgetState.noData) {
      return placeholderWidget();
    }
    return PullRefreshList(
      isAll: isAll,
      onRefresh: onRefresh,
      onLoading: onLoading,
      child: ListView.builder(
        physics: const ClampingScrollPhysics(),
        itemBuilder: (BuildContext c, int i) {
          return buildItemWidget(dataList[i]);
        },
        itemCount: dataList.length,
        padding: const EdgeInsets.all(0.0),
      ),
    );
  }
}

/* ***** ***** ***** 提现明细 ***** ***** ***** */

class WithdrawDetails extends StatefulWidget {
  const WithdrawDetails({Key? key}) : super(key: key);

  @override
  State<WithdrawDetails> createState() => _WithdrawDetailsState();
}

class _WithdrawDetailsState extends State<WithdrawDetails>
    with ConvenientMixin, DetailsMixin, StateMixin {
  @override
  void initLoadingData() {
    HttpHelper.withdrawList(param, (data) {
      var list = [];
      try {
        list = (data['list'] as List)
            .map((item) => WithdrawItemModel.fromJson(item))
            .toList();
      } catch (error) {
        debugPrint(error.toString());
      }
      updateListAndWidgetState(list);
    }, dealWithErrorsWidgetState);
  }

  @override
  Widget build(BuildContext context) {
    if (widgetState != WidgetState.finish &&
        widgetState != WidgetState.noData) {
      return placeholderWidget();
    }
    return PullRefreshList(
      isAll: isAll,
      onRefresh: onRefresh,
      onLoading: onLoading,
      child: ListView.builder(
        physics: const ClampingScrollPhysics(),
        itemBuilder: (BuildContext c, int i) {
          return buildItemWidget(dataList[i]);
        },
        itemCount: dataList.length,
        padding: const EdgeInsets.all(0.0),
      ),
    );
  }
}

mixin DetailsMixin on ConvenientMixin {
  Widget buildItemWidget(BaseDetailModel item) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12.w),
        color: const Color(0x1fbc88ff),
        border: Border.all(color: const Color(0x0dffffff), width: 0.5),
      ),
      margin: EdgeInsets.fromLTRB(16.w, 0, 16.w, 15.w),
      width: 343.w,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          _buildTitleWidget(item.created, item.number),
          item.status.isEmpty
              ? _buildDescWidget(item.descp, item.amount)
              : _buildStateWidget(item.descp, item.status, item.amount),
        ],
      ),
    );
  }

  Widget _buildTitleWidget(String date, String number) {
    return Container(
      height: 36.w,
      color: Colors.black.withOpacity(0.08),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          SizedBox(width: 10.w),
          Expanded(
            child: Text(
              date,
              style: TextStyle(color: color_64, fontSize: 12.sp),
            ),
          ),
          Text(
            number,
            style: TextStyle(color: color_64, fontSize: 12.sp),
          ),
          GestureDetector(
            onTap: () {
              Clipboard.setData(ClipboardData(text: number));
              Method.showText('复制成功，反馈吧');
            },
            child: Padding(
              padding: EdgeInsets.all(10.w),
              child:
                  Text('复制', style: TextStyle(color: rColor, fontSize: 12.sp)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStateWidget(String desc, String status, String amount) {
    return Container(
      height: 44.w,
      padding: EdgeInsets.only(left: 10.w, right: 10.w),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            flex: 1,
            child: Text(
              desc,
              style: TextStyle(color: wColor, fontSize: 14.sp),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ),
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(6.w),
              color: Colors.black.withOpacity(0.12),
            ),
            padding: EdgeInsets.all(5.w),
            child: Text(
              status,
              style:
                  TextStyle(color: wColor, fontSize: 12.sp, fontWeight: fontM),
            ),
          ),
          Expanded(
            flex: 1,
            child: Text(
              amount,
              textAlign: TextAlign.end,
              style:
                  TextStyle(color: wColor, fontSize: 13.sp, fontWeight: fontM),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDescWidget(String desc, String amount) {
    return Container(
      height: 44.w,
      padding: EdgeInsets.only(left: 10.w, right: 10.w),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: Text(
              desc,
              style: TextStyle(color: wColor, fontSize: 14.sp),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ),
          SizedBox(width: 10.w),
          Text(
            amount,
            style: TextStyle(color: wColor, fontSize: 13.sp, fontWeight: fontM),
          ),
        ],
      ),
    );
  }
}
