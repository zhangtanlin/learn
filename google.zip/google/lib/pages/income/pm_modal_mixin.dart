import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:iaimei/components/common/base_dialog.dart';
import 'package:iaimei/components/common/commonelements.dart';
import 'package:iaimei/components/common/pagestatus.dart';
import 'package:iaimei/net/http_helper.dart';
import 'package:iaimei/pages/income/product_model.dart';
import 'package:iaimei/utils/common.dart';
import 'package:iaimei/utils/web_util.dart';
import 'package:iaimei/widget/buttom_widget.dart';
import 'package:iaimei/widget/convenient_mixin.dart';
import 'package:universal_html/html.dart' as html;

mixin PmModalMixin<T extends StatefulWidget> on ConvenientMixin, State<T> {
  BuildContext? sheetContext;
  StateSetter? setSheetState; //
  dynamic selectedWay; // 选择的支付方式
  ProductItemModel? selectedItemModel; // 选择的产品

  /*
   * {
   *  "pUrl":"http://120.24.56.69:7422/api/payPage.html?id=265442",
   *  "order_id":"xy520220401160228045837",
   *  "pay_type":"url"
   * }
   */

  void _submitOrder() {
    if (selectedItemModel == null) return;
    if (selectedWay == null) {
      Method.showText('请选择支付方式');
      return;
    }

    html.WindowBase? winRef;
    if (kIsWeb) {
      dynamic origin = '${html.window.location.origin}/';
      winRef = html.window.open('${origin}waiting.html', '_blank');
    }

    var param = {'product_id': '${selectedItemModel?.id}', 'pw': selectedWay};
    PageStatus.showLoading(text: '正在请求支付');
    HttpHelper.createOrder(param, (data) {
      PageStatus.closeLoading();
      if (kIsWeb) context.pop();
      if (data != null && data['pUrl'] != null) {
        if (kIsWeb) {
          winRef?.location.href = data['pUrl'] ?? '';
        } else {
          WebUtil.browserLaunchURL(data['pUrl'] ?? '');
        }
      } else {
        if (kIsWeb) winRef?.close();
        BaseDialog.toast(text: '数据错误，请稍后再试');
      }
      if (sheetContext != null) Navigator.pop(sheetContext!);
      // context.pop(); // 推出支付页了
      // sheetContext?.pop();
    }, (error) {
      PageStatus.closeLoading();
      if (kIsWeb) winRef?.close;
      if (sheetContext != null) Navigator.pop(sheetContext!);
      BaseDialog.toast(text: '创建订单失败，请稍后再试');
      debugPrint(error.toString());
    });
  }

  void showSelectedBottomSheet(ProductItemModel item) {
    selectedWay = null;
    selectedItemModel = item;
    showModalBottomSheet(
      isScrollControlled: true,
      isDismissible: true,
      context: context,
      backgroundColor: Colors.transparent,
      builder: (builder) {
        return StatefulBuilder(builder: (cnt, state) {
          sheetContext = cnt;
          setSheetState = state;
          return Container(
            padding: EdgeInsets.only(
              bottom: MediaQuery.of(cnt).padding.bottom,
            ),
            decoration: const BoxDecoration(
              color: Color.fromRGBO(26, 21, 47, 1),
              borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
            ),
            clipBehavior: Clip.hardEdge,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Container(
                  padding: EdgeInsets.only(top: 14.w),
                  height: 54.w,
                  color: const Color(0x15ffffff),
                  child: CustomHeader(lMargin: 16.w, title: '选择支付方式'),
                ),
                Padding(
                  padding: EdgeInsets.fromLTRB(16.w, 21.w, 0, 21.w),
                  child: Text.rich(TextSpan(children: [
                    TextSpan(text: '支付金额 ', style: TextStyle(color: wColor)),
                    TextSpan(
                        text: '${item.p}元',
                        style: TextStyle(fontWeight: fontM)),
                  ], style: TextStyle(color: rColor, fontSize: 16.sp))),
                ),
                ListView.builder(
                  itemCount: item.pw?.length,
                  shrinkWrap: true,
                  padding: EdgeInsets.fromLTRB(16.w, 0, 16.w, 16.w),
                  physics: const NeverScrollableScrollPhysics(),
                  itemBuilder: (ctx, index) {
                    return _buildPmWayWidget(item.pw?[index]);
                  },
                ),
                Center(
                  child: ButtonWidget.build('立即支付', onTap: _submitOrder),
                ),
                SizedBox(height: 30.w),
              ],
            ),
          );
        });
      },
    );
  }

  Map<String, List<String>> pmway = {
    'pa': ['assets/images/income/pm_way_pa.png', '支付宝'],
    'pw': ['assets/images/income/pm_way_pw.png', '微信支付'],
    'pb': ['assets/images/income/pm_way_pb.png', '银联支付'],
    'pg': ['assets/images/income/pm_way_pg.png', '代理支付'],
    'pv': ['assets/images/income/pm_way_pv.png', 'visa支付'],
    'ps': ['assets/images/income/pm_way_ps.png', '数字人民币'],
  };

  Widget _buildPmWayWidget(dynamic way) {
    List<String> list = pmway['$way'] ?? ['', '未知新方式'];
    var path =
        'assets/images/upload/upload_fan_${way == selectedWay ? 'sel' : 'nor'}.png';
    return GestureDetector(
      behavior: HitTestBehavior.translucent,
      onTap: () {
        selectedWay = way;
        setSheetState?.call(() {});
      },
      child: buildContainerWidget(
        width: 343.w,
        height: 56.w,
        padding: EdgeInsets.symmetric(horizontal: 20.w),
        margin: EdgeInsets.only(bottom: 14.w),
        child: Row(
          children: [
            Image.asset(list[0], width: 36.w, height: 36.w),
            SizedBox(width: 10.w),
            Expanded(
              child: Text(
                list[1],
                style: TextStyle(color: wColor, fontSize: 14.sp),
              ),
            ),
            Image.asset(path, width: 18.w, height: 18.w),
          ],
        ),
      ),
    );
  }
}
