import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:iaimei/components/common/commonelements.dart';
import 'package:iaimei/components/common/pageviewmixin.dart';
import 'package:iaimei/components/common/stackpage.dart';
import 'package:iaimei/net/http_helper.dart';
import 'package:iaimei/pages/income/card_type_mixin.dart';
import 'package:iaimei/pages/income/other_kinds_card.dart';
import 'package:iaimei/pages/income/product_model.dart';
import 'package:iaimei/pages/income/vip_around_card.dart';
import 'package:iaimei/utils/common.dart';
import 'package:iaimei/widget/convenient_mixin.dart';

class RechargeVip extends StatefulWidget {
  const RechargeVip({Key? key}) : super(key: key);

  @override
  State<RechargeVip> createState() => _RechargeVipState();
}

class _RechargeVipState extends State<RechargeVip>
    with ConvenientMixin, TickerProviderStateMixin, CardTypeMixin {
  int selectedIndex = 0;
  late TabController tabController;
  List<String> items = ['全能卡', '单项卡', '超值卡', '我的卡包'];
  bool isloading = true;

  @override
  void initState() {
    super.initState();
    tabController = TabController(length: items.length, vsync: this);
    tabController.addListener(() {
      if (selected != tabController.index) {
        selected = tabController.index;
        setState(() {});
      }
    });
    loadData();
  }

  List<ProductItemModel> vipList = [];
  List<ProductItemModel> singleList = [];
  List<ProductItemModel> valueList = [];
  void loadData() {
    HttpHelper.productList(1, (data) {
      try {
        var list = ProductModel.fromJson(data).list!;
        vipList = list.where((item) => item.cardType == 1).toList();
        singleList = list.where((item) => item.cardType == 0).toList();
        valueList = list.where((item) => item.cardType == 2).toList();
        isloading = false;
        setState(() {});
      } catch (error) {
        debugPrint(error.toString());
      }
    }, (error) {
      Method.showText(error.message ?? '');
    });
  }

  @override
  Widget build(BuildContext context) {
    return StackPage(
      bgPath: 'assets/images/income/pm_vip_bg.png',
      header: CustomHeader(
        // 左 52
        titleWidget: Container(
          padding: EdgeInsets.only(left: 44.w),
          child: Image.asset(
            'assets/images/income/pm_vip_title.png',
            height: 44.w,
            width: 183.w,
            fit: BoxFit.cover,
          ),
        ),
        // 右 10 + 86
        rListWidget: [_buildLeftMoreWidget()],
      ),
      child: Column(
        children: [
          _buildTabBarWidget(),
          SizedBox(height: 10.w),
          Expanded(
            child: _buildTabBarViewWidget(),
          ),
        ],
      ),
    );
  }

  Widget _buildLeftMoreWidget() {
    return GestureDetector(
      onTap: () => context.push('/funding/${0}'),
      child: Container(
        width: 86.w,
        height: 36.w,
        padding: EdgeInsets.only(left: 2.w),
        alignment: Alignment.centerRight,
        child: Center(
          child: Text(
            '充值记录',
            style: TextStyle(color: rColor, fontSize: 14.sp, fontWeight: fontM),
          ),
        ),
      ),
    );
  }

  int selected = 0;
  Widget _buildTabBarWidget() {
    return SizedBox(
      height: 44.w,
      child: TabBar(
        controller: tabController,
        isScrollable: false,
        labelColor: const Color.fromRGBO(255, 0, 179, 1),
        indicator: const BoxDecoration(),
        unselectedLabelColor: Colors.white,
        labelStyle: TextStyle(fontSize: 18.sp, fontWeight: FontWeight.w500),
        unselectedLabelStyle: TextStyle(fontSize: 14.sp),
        tabs: items
            .asMap()
            .keys
            .map((index) => Tab(
                  icon: Image.asset(
                    'assets/images/income/pm_vip_tab_$index${selected == index ? '1' : '0'}.png',
                    height: 18.w,
                    fit: BoxFit.cover,
                  ),
                ))
            .toList(),
      ),
    );
  }

  Widget _buildTabBarViewWidget() {
    return TabBarView(
      controller: tabController,
      children: items.asMap().keys.map((index) {
        switch (index) {
          case 0:
            return PageViewMixin(
                child: VipAroundCard(
                    isloading: isloading,
                    list: vipList,
                    refreshBlock: loadData));
          case 1:
            return PageViewMixin(
                child: OtherKindsCard(
                    isloading: isloading,
                    index: index,
                    list: singleList,
                    refreshBlock: loadData));
          case 2:
            return PageViewMixin(
                child: OtherKindsCard(
                    isloading: isloading,
                    index: index,
                    list: valueList,
                    refreshBlock: loadData));
          default:
            return PageViewMixin(
                child: OtherKindsCard(index: index, list: const []));
        }
      }).toList(),
    );
  }
}
