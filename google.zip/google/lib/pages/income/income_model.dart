abstract class BaseDetailModel {
  String number = ''; // 流水号 or 订单号
  String status = ''; // 状态

  String descp = ''; // 描述
  String amount = ''; // 数量

  String updated = '';
  String created = '';

  BaseDetailModel();
  BaseDetailModel.fromJson(Map<String, dynamic> json);
}

class PaymentItemModel extends BaseDetailModel {
  PaymentItemModel();
  PaymentItemModel.fromJson(Map<String, dynamic> json) {
    number = json['order_id'];
    status = json['status_str'];

    descp = json['descp'];
    amount = '¥ ${json['amount_rmb']}';

    updated = json['updated_str'];
    created = json['created_str'];
    // payAmountRmb = json['pay_amount_rmb'];
  }
}

class IncomeExpendModel extends BaseDetailModel {
  String type = ''; // 无用
  String action = ''; // 操作
  int coinType = 0; // 0 钻石 1 余额
  IncomeExpendModel();
  IncomeExpendModel.fromJson(Map<String, dynamic> json) {
    number = json['log_sn'];

    descp = json['action_str']; //json['desc'];
    // 收入
    if (json['type'] == 'income') {
      amount =
          '${json['coin_type'] == 0 ? '' : '¥'}${json['reachcoin']}${json['coin_type'] == 0 ? '钻石' : ''}';
    }
    // 消费
    if (json['type'] == 'expend') {
      amount =
          '${json['coin_type'] == 0 ? '' : '¥'}${json['totalcoin']}${json['coin_type'] == 0 ? '钻石' : ''}';
    }
    created = json['add_time_str'];
  }
}

class WithdrawItemModel extends BaseDetailModel {
  // String name = '';
  // String amount = ''; // 折扣后的价格
  WithdrawItemModel();
  WithdrawItemModel.fromJson(Map<String, dynamic> json) {
    number = json['draw_sn'];
    status = json['status_str'];

    descp = json['descp'];
    amount = '¥ ${json['coins']}';

    created = json['created_at_str'];
  }
}

class IncomeListModel {
  String dCoins = '0.00';
  String kCoins = '0.00';
  List<IncomeItemModel> list = [];
  IncomeListModel();
  IncomeListModel.fromJson(Map<String, dynamic> json) {
    dCoins = json['d_coins'];
    kCoins = json['k_coins'];
    if (json['list'] is List) {
      list = (json['list'] as List)
          .map((item) => IncomeItemModel.fromJson(item))
          .toList();
    }
  }
}

class IncomeItemModel {
  int id = 0;
  String reachAmount = '0.00';
  int type = 0;
  String createdDate = '';
  String proxySn = '';
  IncomeItemModel();
  IncomeItemModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    reachAmount = json['reach_amount'];
    type = json['type'];
    createdDate = json['created_date'];
    proxySn = json['proxy_sn'];
  }
}
