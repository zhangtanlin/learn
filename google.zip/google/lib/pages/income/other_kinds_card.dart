import 'package:flutter/material.dart';
import 'package:iaimei/components/common/pullrefreshlist.dart';
import 'package:iaimei/net/http_helper.dart';
import 'package:iaimei/pages/income/card_type_mixin.dart';
import 'package:iaimei/pages/income/pm_modal_mixin.dart';
import 'package:iaimei/pages/income/product_model.dart';
import 'package:iaimei/widget/convenient_mixin.dart';

class OtherKindsCard extends StatefulWidget {
  const OtherKindsCard({
    Key? key,
    this.isloading = true,
    this.index = 0,
    required this.list,
    this.refreshBlock,
  }) : super(key: key);
  final bool isloading;
  final int index;
  final List<ProductItemModel> list;
  final void Function()? refreshBlock;
  @override
  State<OtherKindsCard> createState() => _OtherKindsCardState();
}

class _OtherKindsCardState extends State<OtherKindsCard>
    with ConvenientMixin, CardTypeMixin, PmModalMixin {
  late bool isloading;
  List<ProductItemModel> itemsModel = [];
  void loadData() {
    HttpHelper.cardsList((data) {
      try {
        itemsModel = ProductModel.fromJson(data).list!;
        isloading = false;
        setState(() {});
      } catch (error) {
        debugPrint(error.toString());
      }
    }, (error) {});
  }

  @override
  void initState() {
    super.initState();
    if (widget.index == 3) {
      loadData(); // 卡包
    }
    isloading = widget.isloading;
  }

  @override
  void didUpdateWidget(covariant OtherKindsCard oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.index != 3) {
      isloading = widget.isloading;
    }
  }

  @override
  Widget build(BuildContext context) {
    if (isloading == true) return loadingWiget();
    if (widget.list.isEmpty && itemsModel.isEmpty) return noDataVipWidget();
    switch (widget.index) {
      case 3: // 我的卡包
        return _buildCardViewWidget(widget.index);
      default:
        return _buildPageViewWidget(widget.index);
    }
  }

  Widget _buildPageViewWidget(int index) {
    return PullRefreshList(
      onRefresh: widget.refreshBlock,
      child: ListView.builder(
        key: PageStorageKey<String>('Tab$index'),
        itemCount: widget.list.length,
        padding: const EdgeInsets.all(0.0),
        physics: const ClampingScrollPhysics(),
        itemBuilder: (BuildContext c, int i) {
          var item = widget.list[i];
          switch (item.cardType) {
            case 0: // 0 单卡
              return GestureDetector(
                onTap: () => showSelectedBottomSheet(item),
                child: buildSingleCardWidget(item),
              );
            case 2: // 2 超值卡
              return GestureDetector(
                onTap: () => showSelectedBottomSheet(item),
                child: buildValueCardWidget(item, false),
              );
            default:
              return Container();
          }
        },
      ),
    );
  }

  Widget _buildCardViewWidget(int index) {
    return PullRefreshList(
      onRefresh: loadData,
      child: ListView.builder(
        key: PageStorageKey<String>('Tab$index'),
        itemCount: itemsModel.length,
        padding: const EdgeInsets.all(0.0),
        physics: const ClampingScrollPhysics(),
        itemBuilder: (BuildContext c, int i) {
          var item = itemsModel[i];
          switch (item.cardType) {
            case 0: // 0 单卡
              return GestureDetector(
                onTap: () => showSelectedBottomSheet(item),
                child: buildSingleCardWidget(item),
              );
            case 1: // 1 VIP
              return GestureDetector(
                onTap: () => showSelectedBottomSheet(item),
                child: buildVipCardWidget(item),
              );
            case 2: // 2 超值卡
              return GestureDetector(
                onTap: () => showSelectedBottomSheet(item),
                child: buildValueCardWidget(item, true),
              );
            default:
              return Container();
          }
        },
      ),
    );
  }
}
