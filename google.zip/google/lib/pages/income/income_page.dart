import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:iaimei/components/common/commonelements.dart';
import 'package:iaimei/components/common/pageviewmixin.dart';
import 'package:iaimei/components/common/pullrefreshlist.dart';
import 'package:iaimei/components/common/stackpage.dart';
import 'package:iaimei/net/http_helper.dart';
import 'package:iaimei/pages/income/income_model.dart';
import 'package:iaimei/pages/mv/nav_tab_bar_mixin.dart';
import 'package:iaimei/store/userdata.dart';
import 'package:iaimei/widget/convenient_mixin.dart';
import 'package:iaimei/widget/nested_scroll_view_ext.dart';
import 'package:iaimei/widget/state_mixin.dart';
import 'package:provider/provider.dart';

import '../../model/user_info_model.dart';

class IncomePage extends StatefulWidget {
  const IncomePage({Key? key}) : super(key: key);

  @override
  State<IncomePage> createState() => _IncomePageState();
}

class _IncomePageState extends State<IncomePage>
    with TickerProviderStateMixin, ConvenientMixin {
  final temp = 99999.00;

  int selectedIndex = 0;
  late TabController tabController;
  List<String> items = ['直推收益', '跨级收益'];

  late UserInfoModel user;
  @override
  void initState() {
    super.initState();
    user = Provider.of<UserData>(context, listen: false).userInfo;

    tabController = TabController(
      length: items.length,
      vsync: this,
      initialIndex: selectedIndex,
    );
    tabController.addListener(() {
      selectedIndex = tabController.index;
      setState(() {});
    });

    proxyIncome(); //
  }

  bool init = false;
  int page = 1;
  bool isAll = false;
  List ads = [];
  List list = [];
  String type = 'nomal';

  var dataIncome = {};
  void proxyIncome() {
    HttpHelper.incomeData((data) {
      try {
        dataIncome = data;
        setState(() {});
      } catch (err) {
        debugPrint(err.toString());
      }
    }, (error) {
      debugPrint(error.toString());
    });
  }

  @override
  Widget build(BuildContext context) {
    return StackPage(
      header: const CustomHeader(title: '推广收益'),
      child: NestedScrollViewExt(
        headerSliverBuilder: (BuildContext c, bool f) {
          return <Widget>[
            SliverToBoxAdapter(
              child: Padding(
                padding: EdgeInsets.fromLTRB(16.w, 10.w, 16.w, 20.w),
                child: _buildHeaderWidget(),
              ),
            ),
          ];
        },
        onlyOneScrollInBody: true,
        body: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            NavTabBarWidget(
              tabVc: tabController,
              tabs: const ['直推收益', '跨级收益'],
              textPadding: EdgeInsets.symmetric(horizontal: 15.w),
              norTextStyle: TextStyle(
                  color: wColor, fontSize: 14.sp, fontWeight: FontWeight.w400),
              selTextStyle:
                  TextStyle(color: rColor, fontSize: 14.sp, fontWeight: fontM),
            ),
            Container(
                color: const Color(0x33ffffff),
                margin: EdgeInsets.fromLTRB(16.w, 0, 16.w, 0),
                height: 0.5),
            Expanded(
              child: TabBarView(
                controller: tabController,
                children: <Widget>[
                  PageViewMixin(child: const IncomeItemPage(type: 0)),
                  PageViewMixin(child: const IncomeItemPage(type: 1)),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget _buildHeaderWidget() {
    var path = '';
    switch (dataIncome['level']) {
      // 0 非VIP 1 月卡 2 季卡 3 年卡 4 永久卡 5 半年
      case 1:
        path = 'assets/images/income/sgmt_gold.png';
        break;
      case 2:
        path = 'assets/images/income/sgmt_plat.png';
        break;
      case 3:
        path = 'assets/images/income/sgmt_diam.png';
        break;
      case 4:
        path = 'assets/images/income/sgmt_star.png';
        break;
      case 5:
        path = 'assets/images/income/sgmt_king.png';
        break;
      default:
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12.w),
            color: const Color(0x1fbc88ff),
            border: Border.all(color: const Color(0x0dffffff), width: 0.5),
          ),
          padding: EdgeInsets.fromLTRB(10.w, 10.w, 0, 0.w),
          width: 343.w,
          height: 84.w,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                '余额',
                style: TextStyle(color: wColor, fontSize: 12.sp),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    '¥ ${dataIncome['coins'] ?? '0.00'}',
                    style: TextStyle(
                        color: rColor, fontSize: 26.sp, fontWeight: fontM),
                  ),
                  GestureDetector(
                    onTap: () => context.push('/withdraw'),
                    behavior: HitTestBehavior.translucent,
                    child: Padding(
                      padding: EdgeInsets.fromLTRB(10.w, 15.w, 10.w, 15.w),
                      child: Text(
                        '提现',
                        style: TextStyle(color: rColor, fontSize: 14.sp),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        SizedBox(height: 15.w),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12.w),
                color: const Color(0x1fbc88ff),
                border: Border.all(color: const Color(0x0dffffff), width: 0.5),
              ),
              padding: EdgeInsets.only(left: 10.w, top: 12.w),
              width: 164.w,
              height: 44.w,
              child: Text.rich(
                TextSpan(children: [
                  TextSpan(
                      text: '今日收益   ',
                      style: TextStyle(color: wColor, fontSize: 12.sp)),
                  TextSpan(
                      text: '¥ ${dataIncome['today_tui_coins'] ?? 0}',
                      style: const TextStyle(fontWeight: FontWeight.w500))
                ]),
                style: TextStyle(color: rColor, fontSize: 15.sp),
              ),
            ),
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12.w),
                color: const Color(0x1fbc88ff),
                border: Border.all(color: const Color(0x0dffffff), width: 0.5),
              ),
              padding: EdgeInsets.only(left: 10.w, top: 12.w),
              width: 164.w,
              height: 44.w,
              child: Text.rich(
                TextSpan(children: [
                  TextSpan(
                      text: '累计收益   ',
                      style: TextStyle(color: wColor, fontSize: 12.sp)),
                  TextSpan(
                      text: '¥ ${dataIncome['all_tui_coins'] ?? 0}',
                      style: TextStyle(fontWeight: fontM)),
                ]),
                style: TextStyle(color: rColor, fontSize: 15.sp),
              ),
            ),
          ],
        ),
        SizedBox(height: 15.w),
        Text.rich(TextSpan(children: [
          TextSpan(
            text: '当前等级：',
            style: TextStyle(fontSize: 13.sp, color: color_64),
          ),
          path.isEmpty
              ? TextSpan(
                  text: dataIncome['level_str'] ?? '',
                  style: TextStyle(fontSize: 12.sp, color: color_64),
                )
              : WidgetSpan(
                  child: Image.asset(path, width: 60.w, height: 14.w),
                )
        ])),
        SizedBox(height: 15.w),
        Text.rich(
          TextSpan(children: [
            const TextSpan(text: '距离下一等级还差：'),
            ..._buildTextSpan(),
          ], style: TextStyle(fontSize: 13.sp, color: color_64)),
          maxLines: 1,
          textAlign: TextAlign.center,
        ),
      ],
    );
  }

  List _buildTextSpan() {
    var spanList = [];
    List<String> tips = (dataIncome['tips'] ?? '').split('#');
    var items = tips.where((str) => str.isNotEmpty).toList();
    for (int i = 0; i < items.length; i++) {
      spanList.add(TextSpan(
          text:
              '${(i == 0 ? dataIncome['next_vip'] : dataIncome['next_proxy']) ?? '~'}',
          style: TextStyle(color: rColor)));
      spanList.add(TextSpan(text: items[i]));
    }
    return spanList;
  }
}

class IncomeItemPage extends StatefulWidget {
  const IncomeItemPage({Key? key, this.type = 0}) : super(key: key);

  final int type;

  @override
  State<IncomeItemPage> createState() => _IncomeItemPageState();
}

class _IncomeItemPageState extends State<IncomeItemPage>
    with ConvenientMixin, StateMixin {
  @override
  Widget noDataWidget() {
    return buildDataWidget(
        icon: 'assets/images/common/ic_load_error.png',
        content: '暂无数据',
        tipHidden: true);
  }

  String coins = '0.00';
  @override
  void initLoadingData() {
    var param = this.param;
    param['type'] = widget.type;
    HttpHelper.incomeType(param, (data) {
      var item = IncomeListModel();
      try {
        item = IncomeListModel.fromJson(data);
      } catch (er) {
        debugPrint(er.toString());
      }
      coins = widget.type == 0 ? item.dCoins : item.kCoins;
      updateListAndWidgetState(item.list);
    }, dealWithErrorsWidgetState);
  }

  @override
  Widget build(BuildContext context) {
    if (widgetState != WidgetState.finish &&
        widgetState != WidgetState.noData) {
      return placeholderWidget();
    }
    return _buildIncomeWidget(widget.type);
  }

  Widget _buildIncomeWidget(int index) {
    return PullRefreshList(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.fromLTRB(16.w, 10.w, 16.w, 10.w),
            child: Text.rich(
              TextSpan(
                children: [
                  TextSpan(
                      text: '${index == 0 ? '直推' : '跨级'}收益：',
                      style: TextStyle(color: wColor)),
                  TextSpan(
                      text: '¥ $coins', style: TextStyle(fontWeight: fontM)),
                ],
                style: TextStyle(color: rColor, fontSize: 14.sp),
              ),
            ),
          ),
          ListView.builder(
            key: PageStorageKey<String>('Tab$index'),
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemBuilder: (BuildContext c, int i) {
              return _buildIncomeItemWidget(dataList[i]);
            },
            itemCount: dataList.length,
            padding: const EdgeInsets.all(0.0),
          ),
        ],
      ),
      isAll: isAll,
      onRefresh: onRefresh,
      onLoading: onLoading,
    );
  }

  Widget _buildIncomeItemWidget(IncomeItemModel item) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12.w),
        color: const Color(0x1fbc88ff),
        border: Border.all(color: const Color(0x0dffffff), width: 0.5),
      ),
      margin: EdgeInsets.fromLTRB(16.w, 0, 16.w, 15.w),
      padding: EdgeInsets.fromLTRB(10.w, 10.w, 10, 10.w),
      width: 343.w,
      height: 66.w,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'ID:${item.proxySn}',
                style: TextStyle(color: color_64, fontSize: 12.sp),
              ),
              Text(
                item.createdDate,
                style: TextStyle(color: color_64, fontSize: 12.sp),
              ),
            ],
          ),
          Row(
            children: [
              Text(
                '收益',
                style: TextStyle(color: wColor, fontSize: 12.sp),
              ),
              SizedBox(width: 12.w),
              Text(
                '¥ ${item.reachAmount}',
                style: TextStyle(color: rColor, fontSize: 14.sp),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
