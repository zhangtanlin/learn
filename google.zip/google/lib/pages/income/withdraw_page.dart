import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:iaimei/components/common/commonelements.dart';
import 'package:iaimei/components/common/stackpage.dart';
import 'package:iaimei/net/http_helper.dart';
import 'package:iaimei/store/userdata.dart';
import 'package:iaimei/utils/common.dart';
import 'package:iaimei/widget/buttom_widget.dart';
import 'package:iaimei/widget/convenient_mixin.dart';
import 'package:provider/provider.dart';

import '../../model/user_info_model.dart';

class WithdrawPage extends StatefulWidget {
  const WithdrawPage({Key? key}) : super(key: key);

  @override
  State<WithdrawPage> createState() => _WithdrawPageState();
}

class _WithdrawPageState extends State<WithdrawPage> with ConvenientMixin {
  var yuanStatus = true;
  var cardStatus = true;
  var bankStatus = true;
  var nickStatus = true;
  final yuanVc = TextEditingController();
  final cardVc = TextEditingController();
  final bankVc = TextEditingController();
  final nickVc = TextEditingController();

  late UserInfoModel user;

  var offstageStatus = false;

  @override
  void initState() {
    super.initState();
    user = Provider.of<UserData>(context, listen: false).userInfo;
    onloading(); // history account loading
    yuanVc.addListener(() {
      yuanStatus = yuanVc.text.isEmpty;
      setState(() {});
    });
    cardVc.addListener(() {
      cardStatus = cardVc.text.isEmpty;
      offstageStatus = !cardStatus;
      setState(() {});
    });
    bankVc.addListener(() {
      bankStatus = bankVc.text.isEmpty;
      setState(() {});
    });
    nickVc.addListener(() {
      nickStatus = nickVc.text.isEmpty;
      setState(() {});
    });
  }

  List accountList = [];
  void onloading() {
    HttpHelper.historyAccount((data) {
      try {
        accountList = data['list'];
      } catch (error) {
        debugPrint(error.toString());
      }
    }, (error) {
      debugPrint(error.toString());
    });
  }

  void onSubmit() {
    if (yuanVc.text.isEmpty) {
      Method.showText('请输入提现金额');
      return;
    }
    if (cardVc.text.isEmpty) {
      Method.showText('请输入银行卡号');
      return;
    }
    if (bankVc.text.isEmpty) {
      Method.showText('请输入所属银行');
      return;
    }
    if (nickVc.text.isEmpty) {
      Method.showText('请输入开户人姓名');
      return;
    }

    var param = {
      'account_name': bankVc.text,
      'account': cardVc.text,
      'name': nickVc.text,
      'withdraw_amount': yuanVc.text
    };
    HttpHelper.overWithdraw(param, (data) {
      Method.showText(data['msg'] ?? '');
    }, (error) {
      Method.showText(error.message ?? '');
    });
  }

  String toAccount = '0.00';
  void onChanged(String mm) {
    if (mm.isNotEmpty) {
      try {
        var my = double.parse(mm);
        toAccount = (my * (1 - (user.withdrawRate ?? 0))).toStringAsFixed(2);
      } catch (e) {
        debugPrint(e.toString());
      }
    } else {
      toAccount = '0.00';
    }
    setState(() {});
  }

  // 失去焦点
  void onDismissfocus() {
    FocusScope.of(context).requestFocus(FocusNode());
  }

  Widget _buildLeftMoreWidget() {
    return GestureDetector(
      onTap: () {
        context.push('/funding/${3}');
      },
      child: Container(
        height: 36.w,
        margin: EdgeInsets.only(right: 16.w),
        child: Center(
          child: Text(
            '提现明细',
            style: TextStyle(color: wColor, fontSize: 13.sp, fontWeight: fontM),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return StackPage(
      header: CustomHeader(
        title: '提现',
        rListWidget: [_buildLeftMoreWidget()],
      ),
      child: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.fromLTRB(16.w, 10.w, 16.w, 16.w),
          child: GestureDetector(
            behavior: HitTestBehavior.translucent,
            onTap: onDismissfocus,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildInputAmountWidget(),
                SizedBox(height: 10.w),
                _buildHandlingFeeWidget(),
                SizedBox(height: 20.w),
                Text(
                  '填写收款人信息',
                  style: TextStyle(
                      color: wColor, fontSize: 18.sp, fontWeight: fontM),
                ),
                SizedBox(height: 10.w),
                Stack(children: [
                  _buildInfoWidget('请输入银行卡号', cardVc,
                      cardStatus, type: TextInputType.number, formatter: [
                    FilteringTextInputFormatter(RegExp('^[0-9]+'), allow: true)
                  ]),
                  Positioned(
                    right: 0,
                    child: Offstage(
                        offstage: offstageStatus, child: _buildHistoryWidget()),
                  ),
                ]),
                SizedBox(height: 15.w),
                _buildInfoWidget('所属银行', bankVc, bankStatus),
                SizedBox(height: 15.w),
                _buildInfoWidget('开户人姓名', nickVc, nickStatus),
                SizedBox(height: 30.w),
                Offstage(
                  offstage: user.wxts?.isEmpty ?? true,
                  child: Text(
                    '温馨提示：',
                    style: TextStyle(
                        color: wColor, fontSize: 16.sp, fontWeight: fontM),
                  ),
                ),
                ...(user.wxts ?? '')
                    .split('##')
                    .map((item) => Padding(
                        padding: EdgeInsets.only(top: 10.w),
                        child: Text(
                          item.trim(),
                          style: TextStyle(color: color_64, fontSize: 12.sp),
                        )))
                    .toList(),
                SizedBox(height: 50.w),
                Center(
                  child: ButtonWidget.build('确定', onTap: onSubmit),
                ),
                Center(child: _buildServiceWidget()),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildInputAmountWidget() {
    return buildContainerWidget(
      padding: EdgeInsets.fromLTRB(10.w, 20.w, 0, 0),
      width: 343.w,
      height: 131.5.w,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text('提现金额', style: TextStyle(color: wColor, fontSize: 12.sp)),
          Row(
            children: [
              Text('¥',
                  style: TextStyle(
                      color: wColor, fontWeight: fontM, fontSize: 16.sp)),
              SizedBox(width: 10.w),
              Expanded(
                child: Column(children: [
                  _buildInfoWidget(
                    '',
                    yuanVc,
                    yuanStatus,
                    isYuan: true,
                    type: TextInputType.number,
                    formatter: [
                      FilteringTextInputFormatter(
                        RegExp('^[0-9]+'),
                        allow: true,
                      )
                    ],
                    onChanged: onChanged,
                  ),
                  Container(
                    margin: EdgeInsets.only(top: 5.w),
                    height: 0.5.w,
                    color: Colors.white.withOpacity(0.12),
                  )
                ]),
              ),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text.rich(TextSpan(children: [
                TextSpan(
                    text: '账户余额：',
                    style: TextStyle(color: color_64, fontSize: 14.sp)),
                TextSpan(
                    text: '¥ ${user.coins}',
                    style: TextStyle(color: wColor, fontSize: 14.sp)),
              ])),
              GestureDetector(
                onTap: () {
                  onChanged('${user.coins}');
                  yuanVc.text = '${user.coins}';
                },
                behavior: HitTestBehavior.translucent,
                child: Padding(
                  padding: EdgeInsets.fromLTRB(10.w, 15.w, 10.w, 15.w),
                  child: Text(
                    '全部提现',
                    style: TextStyle(color: rColor, fontSize: 14.sp),
                  ),
                ),
              ),
            ],
          )
        ],
      ),
    );
  }

  Widget _buildHandlingFeeWidget() {
    return Text.rich(
      TextSpan(children: [
        TextSpan(text: '提现包含通道手续费', style: TextStyle(color: wColor)),
        TextSpan(
          text: ' ${(user.withdrawRate ?? 0) * 100}%',
          style: TextStyle(color: rColor),
        ),
        TextSpan(text: '，实际到账金额', style: TextStyle(color: wColor)),
        TextSpan(text: ' $toAccount', style: TextStyle(color: rColor)),
      ]),
      style: TextStyle(fontSize: 12.sp, fontWeight: fontM),
    );
  }

  Widget _buildServiceWidget() {
    return GestureDetector(
      onTap: () => context.push('/onlineService'),
      child: SizedBox(
        height: 50.w,
        width: 126.w,
        child: Center(
          child: Text(
            '联系客服',
            style: TextStyle(color: color_64, fontSize: 16.sp),
          ),
        ),
      ),
    );
  }

  Widget _buildHistoryWidget() {
    return GestureDetector(
      child: SizedBox(
        height: 44.w,
        width: 76.w,
        child: Center(
          child: Text(
            '历史账户',
            style: TextStyle(color: rColor, fontSize: 14.sp, fontWeight: fontB),
          ),
        ),
      ),
      onTap: () {
        if (accountList.isNotEmpty) {
          showSelectedBottomSheet();
        } else {
          Method.showText('您还没有历史账户');
        }
      },
    );
  }

  Widget _buildInfoWidget(
      String hintText, TextEditingController controller, bool offstageStatus,
      {bool isYuan = false,
      TextInputType type = TextInputType.text,
      List<TextInputFormatter>? formatter,
      void Function(String)? onChanged}) {
    return Container(
      alignment: Alignment.centerLeft,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12.w),
        color: isYuan ? Colors.transparent : const Color(0x1fbc88ff),
        border: isYuan
            ? Border.all(color: Colors.transparent, width: 0.0)
            : Border.all(color: const Color(0x0dffffff), width: 0.5),
      ),
      width: double.infinity,
      height: isYuan ? 33.w : 44.w,
      child: TextField(
        inputFormatters: formatter,
        cursorColor: wColor,
        controller: controller,
        keyboardType: type,
        style: TextStyle(color: wColor, fontSize: isYuan ? 24.sp : 15.sp),
        onChanged: onChanged,
        decoration: InputDecoration(
          contentPadding: EdgeInsets.symmetric(horizontal: 10.w),
          hintText: hintText,
          hintStyle: TextStyle(color: color_64, fontSize: 13.sp),
          suffixIcon: Offstage(
            offstage: offstageStatus,
            child: Padding(
              padding: EdgeInsets.all(7.w),
              child: GestureDetector(
                onTap: () {
                  controller.clear();
                  if (isYuan == true) setState(() => toAccount = '0.00');
                },
                child: Image.asset('assets/images/income/income_close.png',
                    scale: 2),
              ),
            ),
          ),
          border: const OutlineInputBorder(borderSide: BorderSide.none),
        ),
      ),
    );
  }

  void showSelectedBottomSheet() {
    showModalBottomSheet(
      isScrollControlled: true,
      context: context,
      isDismissible: true,
      backgroundColor: Colors.transparent,
      builder: (builder) {
        return StatefulBuilder(builder: (cnt, state) {
          return Container(
            // height: 250.w,
            padding: EdgeInsets.only(
              bottom: MediaQuery.of(context).padding.bottom,
            ),
            decoration: const BoxDecoration(
              color: Color.fromRGBO(26, 21, 47, 1),
              borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
            ),
            clipBehavior: Clip.hardEdge,
            child: Column(mainAxisSize: MainAxisSize.min, children: <Widget>[
              Container(
                padding: EdgeInsets.only(top: 14.w),
                height: 54.w,
                color: const Color(0x15ffffff),
                child: CustomHeader(lMargin: 16.w, title: '历史账户'),
              ),
              ListView.builder(
                itemExtent: 44.w,
                itemCount: accountList.length,
                shrinkWrap: true,
                padding: EdgeInsets.fromLTRB(16.w, 10.w, 16.w, 20.w),
                physics: const NeverScrollableScrollPhysics(),
                itemBuilder: (ctx, index) {
                  var item = accountList[index];
                  return Stack(
                    fit: StackFit.expand,
                    children: [
                      GestureDetector(
                        onTap: () {
                          cardVc.text = item['account_number'];
                          bankVc.text = item['account_name'];
                          nickVc.text = item['real_name'];
                          ctx.pop(); // 清楚记录
                        },
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              '${item['account_number']}',
                              style: TextStyle(color: wColor, fontSize: 15.sp),
                            ),
                            Text(
                              '${item['account_name']}',
                              style: TextStyle(color: rColor, fontSize: 14.sp),
                            ),
                          ],
                        ),
                      ),
                      Positioned(
                        child: Container(
                            color: const Color(0x1fffffff), height: 0.5.w),
                        bottom: 0,
                        left: 0,
                        right: 0,
                      ),
                    ],
                  );
                },
              ),
            ]),
          );
        });
      },
    );
  }
}
