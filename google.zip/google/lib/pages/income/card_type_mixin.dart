import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:iaimei/net/http_helper.dart';
import 'package:iaimei/pages/income/product_model.dart';
import 'package:iaimei/utils/common.dart';
import 'package:iaimei/widget/convenient_mixin.dart';
import 'package:iaimei/widget/network_img_widget.dart';

mixin CardTypeMixin<T extends StatefulWidget> on ConvenientMixin, State<T> {
  Widget buildVipCardWidget(ProductItemModel item, {EdgeInsets? margin}) {
    return _buildContainerWidget(
      324.w,
      182.w,
      margin ?? EdgeInsets.fromLTRB(26.w, 0, 26.w, 15.w),
      item.bgImg,
      list: [
        _buildSubTitleWidget(71.w, 50.w, true, item.sname),
        _buildDescrWidget(item.description),
      ],
    );
  }

  Widget buildSingleCardWidget(ProductItemModel item) {
    return _buildContainerWidget(
      324.w,
      176.w,
      EdgeInsets.fromLTRB(26.w, 0, 26.w, 15.w),
      item.bgImg,
      list: [
        _buildSubTitleWidget(
            11.w, 47.w, item.isActivity, '优惠倒计时 ${item.limitH}'),
        _buildPriceListWidget(25.w, 20.w, item.p, item.op),
        _buildDescrWidget(item.description),
      ],
    );
  }

  Widget buildValueCardWidget(ProductItemModel item, bool isCardPack) {
    return _buildContainerWidget(
      324.w,
      176.w,
      EdgeInsets.fromLTRB(26.w, 0, 26.w, 15.w),
      item.bgImg,
      list: [
        _buildSubTitleWidget(72.w, 42.w, true, item.sname),
        _buildPriceListWidget(10.w, 11.w, item.p, item.op),
        isCardPack && item.needGain == 0 // 是卡包 不需领取
            ? Container()
            : _buildActionWidget(item, isCardPack),
        _buildDescrWidget(item.description),
      ],
    );
  }

  Widget _buildContainerWidget(width, height, margin, url,
      {List<Widget> list = const []}) {
    return Container(
      width: width,
      height: height,
      margin: margin,
      child: Stack(
        fit: StackFit.expand,
        clipBehavior: Clip.none,
        children: [
          NetworkImgWidget(url: url, fit: BoxFit.fitWidth),
          // NetworkImgContainer(url: url, fit: BoxFit.fitWidth),
          ...list
        ],
      ),
    );
  }

  Widget _buildSubTitleWidget(left, top, isTrue, subTitle) {
    return Positioned(
      left: left,
      top: top,
      child: Offstage(
        offstage: !isTrue,
        child: Text(
          '$subTitle',
          style: TextStyle(color: wColor, fontSize: 12.sp),
        ),
      ),
    );
  }

  Widget _buildPriceListWidget(right, top, price, origin) {
    return Positioned(
      right: right,
      top: top,
      child: SizedBox(
        height: 72.w,
        width: 72.w,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              '¥$price',
              style: TextStyle(
                color: wColor,
                fontSize: 20.sp,
                fontWeight: fontM,
              ),
            ),
            SizedBox(height: 5.w),
            Text(
              '¥$origin',
              style: TextStyle(
                color: wColor,
                fontSize: 12.sp,
                decoration: TextDecoration.lineThrough,
              ),
            ),
          ],
        ),
      ),
    );
  }

  void onTap(ProductItemModel item) {
    HttpHelper.gainGold({'id': item.id}, (data) {
      item.needGain = 2; //
      Method.showText('今日已领取,明日再接再厉~');
      setState(() {});
    }, (error) {
      debugPrint(error.message);
      Method.showText(error.message ?? '');
    });
  }

  Widget _buildActionWidget(ProductItemModel item, bool isCardPack) {
    return Positioned(
      right: 16.w,
      top: 83.w,
      child: GestureDetector(
        // 是卡包 待领取
        onTap: isCardPack && item.needGain == 1 ? () => onTap(item) : null,
        child: Container(
          width: 58.w,
          height: 24.w,
          margin: EdgeInsets.symmetric(vertical: 10.w),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12.w),
            gradient: LinearGradient(
              colors: item.needGain == 2
                  ? [const Color(0xfff7f7f7), const Color(0xffd4d4d4)]
                  : [const Color(0xfffff6f1), const Color(0xffffc3a8)],
            ),
          ),
          child: Center(
            child: Text(
              !isCardPack ? '购买' : '领取',
              style: TextStyle(
                color: item.needGain == 2
                    ? const Color(0xff282828).withOpacity(0.33)
                    : const Color(0xff793e3e),
                fontSize: 14.sp,
                fontWeight: fontM,
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildDescrWidget(dynamic description) {
    return Positioned(
      bottom: 10.w,
      left: 10.w,
      right: 10.w,
      child: Text(
        '$description',
        style: TextStyle(color: const Color(0xb8f2e7ff), fontSize: 11.sp),
      ),
    );
  }
}
