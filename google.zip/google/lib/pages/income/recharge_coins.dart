import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:iaimei/components/common/commonelements.dart';
import 'package:iaimei/components/common/pullrefreshlist.dart';
import 'package:iaimei/components/common/stackpage.dart';
import 'package:iaimei/net/http_helper.dart';
import 'package:iaimei/pages/income/pm_modal_mixin.dart';
import 'package:iaimei/pages/income/product_model.dart';
import 'package:iaimei/widget/convenient_mixin.dart';

class RechargeCoins extends StatefulWidget {
  const RechargeCoins({Key? key}) : super(key: key);

  @override
  State<RechargeCoins> createState() => _RechargeCoinsState();
}

class _RechargeCoinsState extends State<RechargeCoins>
    with ConvenientMixin, PmModalMixin {
  @override
  void initState() {
    super.initState();
    loadData();
  }

  String coins = '0';
  int gCoins = 0;
  String desc = '';
  List<ProductItemModel> itemsModel = [];
  void loadData() {
    HttpHelper.productList(2, (data) {
      try {
        desc = data['desc'] ?? '';
        coins = data['coins'] ?? '0';
        gCoins = data['g_coins'] ?? 0;
        itemsModel = ProductModel.fromJson(data).list!;
        setState(() {});
      } catch (error) {
        debugPrint(error.toString());
      }
    }, (error) {});
  }

  @override
  Widget build(BuildContext context) {
    return StackPage(
      header: CustomHeader(
        title: '余额充值',
        rListWidget: [_buildLeftMoreWidget()],
      ),
      child: Stack(
        children: [
          PullRefreshList(
            onRefresh: () => loadData(),
            child: SingleChildScrollView(
              child: Container(
                padding: EdgeInsets.fromLTRB(16.w, 10.w, 16.w, 20.w),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildOverInfoWidget(),
                    _buildProductWidget(),
                    ..._buildWarnWidget(),
                  ],
                ),
              ),
            ),
          ),
          Positioned(
            bottom: 60.w,
            right: 20.w,
            child: GestureDetector(
              onTap: () {
                context.push('/onlineService');
              },
              child: Image.asset(
                'assets/images/income/pm_coin_service.png',
                width: 66.w,
                height: 66.w,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLeftMoreWidget() {
    return GestureDetector(
      onTap: () => context.push('/funding/${0}'),
      child: Container(
        height: 36.w,
        padding: EdgeInsets.only(right: 16.w),
        child: Center(
          child: Text(
            '充值记录',
            style: TextStyle(color: rColor, fontSize: 14.sp, fontWeight: fontM),
          ),
        ),
      ),
    );
  }

  Widget _buildTextRichWidget(num, double symbol, double size) {
    return Text.rich(
      TextSpan(
        children: [
          TextSpan(text: '¥ ', style: TextStyle(fontSize: symbol)),
          TextSpan(text: '$num', style: TextStyle(fontSize: size)),
        ],
        style: TextStyle(color: wColor, fontWeight: fontM),
      ),
    );
  }

  // ignore: todo
  // TODO: Over Info Widget
  Widget _buildOverInfoWidget() {
    return SizedBox(
      height: 193.w,
      width: 343.w,
      child: Stack(
        children: [
          Image.asset(
            'assets/images/income/pm_coin_info_bg.png',
            width: 343.w,
            height: 193.w,
            fit: BoxFit.cover,
          ),
          Positioned(
            right: 0,
            top: 0,
            child: _buildCostDetailWidget(),
          ),
          Positioned(
            left: 20.w,
            bottom: 70.w,
            child: _buildOverTitleWidget(),
          ),
          Positioned(
            left: 20.w,
            bottom: 20.w,
            child: _buildTextRichWidget(coins, 24.sp, 36.sp),
          ),
          Positioned(
            right: 20.w,
            bottom: 20.w,
            child: _buildCoinRichWidget(gCoins),
          ),
        ],
      ),
    );
  }

  Widget _buildCoinRichWidget(coins) {
    return Text.rich(
      TextSpan(
        children: [
          TextSpan(text: '钻石  ', style: TextStyle(color: color_64)),
          TextSpan(text: '$coins钻', style: TextStyle(color: wColor)),
        ],
        style: TextStyle(fontSize: 13.sp),
      ),
    );
  }

  Widget _buildCostDetailWidget() {
    return GestureDetector(
      behavior: HitTestBehavior.translucent,
      onTap: () {
        context.push('/funding/${1}');
      },
      child: Container(
        height: 24.w,
        width: 56.w,
        margin: EdgeInsets.fromLTRB(24.w, 19.w, 24.w, 19.w),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12.w),
            border: Border.all(color: color_64, width: 0.5.w)),
        child: Center(
          child: Text(
            '明细',
            style: TextStyle(color: wColor, fontSize: 14.sp, fontWeight: fontM),
          ),
        ),
      ),
    );
  }

  Widget _buildOverTitleWidget() {
    return Container(
      width: 56.w,
      height: 24.w,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12.w),
        color: const Color(0x34000000),
      ),
      child: Center(
        child: Text(
          '余额',
          style: TextStyle(color: color_64, fontSize: 13.sp),
        ),
      ),
    );
  }

  // ignore: todo
  // TODO: Product List Widget
  Widget _buildProductWidget() {
    return GridView.builder(
      padding: EdgeInsets.fromLTRB(0, 20.w, 0, 20.w),
      itemCount: itemsModel.length,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        childAspectRatio: 164 / 82,
        mainAxisSpacing: 15.w,
        mainAxisExtent: 82.w,
        crossAxisSpacing: 15.w,
      ),
      itemBuilder: (context, index) {
        return _buildProductItemWidget(itemsModel[index]);
      },
    );
  }

  Widget _buildProductItemWidget(ProductItemModel item) {
    return GestureDetector(
      onTap: () {
        showSelectedBottomSheet(item);
      },
      child: SizedBox(
        width: 164.w,
        height: 82.w,
        child: Stack(
          children: [
            Image.asset(
              'assets/images/income/pm_coin_item_bg.png',
              width: 164.w,
              height: 82.w,
              fit: BoxFit.cover,
            ),
            Positioned(
              left: 10.w,
              top: 15.w,
              child: _buildTextRichWidget(item.p, 16.sp, 20.sp),
            ),
            Positioned(
              left: 10.w,
              bottom: 15.w,
              child: Text('${item.description}',
                  style: TextStyle(color: wColor, fontSize: 12.sp)),
            ),
          ],
        ),
      ),
    );
  }

  List<Widget> _buildWarnWidget() {
    return [
      Text(
        '温馨提示：',
        style: TextStyle(color: wColor, fontSize: 16.sp, fontWeight: fontM),
      ),
      SizedBox(height: 11.w),
      ...desc
          .split('##')
          .map((item) => Padding(
              padding: EdgeInsets.only(bottom: 10.w),
              child: Text(
                item.trim(),
                style: TextStyle(color: color_64, fontSize: 12.sp),
              )))
          .toList(),
    ];
  }
}
