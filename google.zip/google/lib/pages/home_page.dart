import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:iaimei/app_const.dart';
import 'package:iaimei/components/common/commonelements.dart';
import 'package:iaimei/components/common/stackpage.dart';
import 'package:iaimei/global.dart';
import 'package:iaimei/model/ads_model.dart';
import 'package:iaimei/model/config.dart';
import 'package:iaimei/model/indexlist.dart';
import 'package:iaimei/net/http_helper.dart';
import 'package:iaimei/pages/app_version_upgrade_page.dart';
import 'package:iaimei/res/color_res.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/res/img_res.dart';
import 'package:iaimei/res/string_res.dart';
import 'package:iaimei/router/routers.dart';
import 'package:iaimei/store/homedata.dart';
import 'package:iaimei/store/userdata.dart';
import 'package:iaimei/style/app_text_style.dart';
import 'package:iaimei/utils/api.dart';
import 'package:iaimei/utils/common.dart';
import 'package:iaimei/utils/dialog_util.dart';
import 'package:iaimei/utils/list_util.dart';
import 'package:iaimei/utils/log_util.dart';
import 'package:iaimei/utils/page_jump_util.dart';
import 'package:iaimei/utils/string_util.dart';
import 'package:iaimei/widget/app_text_with_img_bg_widget.dart';
import 'package:iaimei/widget/banner_widget.dart';
import 'package:iaimei/widget/frosted_glass_box.dart';
import 'package:iaimei/widget/network_img_container.dart';
import 'package:iaimei/widget/space_widget.dart';
import 'package:iaimei/widget/text_widget.dart';
import 'package:iaimei/widget/toast_widget.dart';
import 'package:provider/provider.dart';
import 'package:universal_html/html.dart' as html;

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List menuList = [];
  List<AdsModel> ad = [];
  List<AdsModel> adnext = [];
  List<List<Menu>> group = []; // 分组模块 6， 5， 5

  @override
  void initState() {
    super.initState();
    onLoadingConfig();
  }

  @override
  void dispose() {
    super.dispose();
  }

  void checkVersion(Config config) {
    if (config.version != null &&
        StringUtil.isNotEmpty(config.version.version)) {
      Version version = config.version;
      String newVersionCode = version.version;
      var newVersion = newVersionCode.replaceAll('.', '');
      var curVersion = AppConst.appVersion.replaceAll('.', '');
      if (int.parse(newVersion) > int.parse(curVersion)) {
        showVersionUpgradeDialog(config, version);
      } else {
        _afterShowVersionUpgradeDialog(config);
      }
    } else {
      _afterShowVersionUpgradeDialog(config);
    }
  }

  void showVersionUpgradeDialog(Config config, Version version) {
    showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) {
          return AppVersionUpgradePage(
            version: version,
            callback: () {
              _afterShowVersionUpgradeDialog(config);
            },
          );
        });
  }

  void _afterShowVersionUpgradeDialog(Config config) {
    if (StringUtil.isNotEmpty(config.maintainTips) &&
        config.maintainSwitch == '1') {
      showSystemPostDialog(config.maintainTips, config);
    } else if (ListUtil.isNotEmpty(config.adsPop) &&
        config.adsPop[0] != null &&
        StringUtil.isNotEmpty(config.adsPop[0].imgUrl)) {
      showAdDialog(config.adsPop[0]);
    }
  }

  void showAdDialog(AdsModel adsModel) {
    double adImgWidth = DimenRes.screenWidth * 3 / 4;
    double adImgHeight = adImgWidth * 4 / 3;
    DialogUtil.show(
        cxt: context,
        width: adImgWidth,
        dismissible: true,
        decoration: const BoxDecoration(color: Colors.transparent),
        height: adImgHeight + DimenRes.dimen_60,
        contentBuilder: (context) {
          return Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              GestureDetector(
                  onTap: () {
                    Navigator.pop(context);
                    BannerWidget.parseAdType(context, adsModel);
                  },
                  child: NetworkImgContainer(
                      url: adsModel.imgUrl ?? '',
                      radius: BorderRadius.circular(DimenRes.radius(5)),
                      bgColor: Colors.black38,
                      width: adImgWidth,
                      height: adImgHeight)),
              GestureDetector(
                onTap: () {
                  Navigator.pop(context);
                },
                child: Padding(
                  padding: EdgeInsets.only(top: DimenRes.dimen_30),
                  child: Image.asset(
                    ImgRes.IC_DIALOG_CLOSE,
                    fit: BoxFit.contain,
                    width: DimenRes.dimen_30,
                    height: DimenRes.dimen_30,
                  ),
                ),
              ),
            ],
          );
        });
  }

  void showSystemPostDialog(String noticeStr, Config config) {
    DialogUtil.showBaseDialog(
        cxt: context,
        cancelCallback: () {
          if (ListUtil.isNotEmpty(config.adsPop) &&
              config.adsPop[0] != null &&
              StringUtil.isNotEmpty(config.adsPop[0].imgUrl)) {
            showAdDialog(config.adsPop[0]);
          }
        },
        child: SizedBox(
          width: double.infinity,
          child: Column(
            children: [
              Container(
                width: double.infinity,
                height: DimenRes.dimen_65,
                alignment: Alignment.center,
                decoration: const BoxDecoration(
                    borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(24),
                        topRight: Radius.circular(24)),
                    gradient: LinearGradient(colors: [
                      ColorRes.color_ff4cca,
                      ColorRes.color_5c35ff,
                    ])),
                child: TextWidget.buildSingleLineText(
                    StringRes.str_system_post, AppTextStyle.white_s18),
              ),
              Container(
                padding: EdgeInsets.only(
                    top: DimenRes.dimen_20,
                    bottom: DimenRes.dimen_15,
                    left: DimenRes.dimen_15,
                    right: DimenRes.dimen_15),
                constraints: BoxConstraints(
                    maxHeight: DimenRes.dimen_260,
                    minHeight: DimenRes.dimen_200),
                decoration: const BoxDecoration(
                    borderRadius: BorderRadius.only(
                        bottomLeft: Radius.circular(24),
                        bottomRight: Radius.circular(24)),
                    color: Colors.white),
                child: Column(
                  children: [
                    Expanded(
                        child: ScrollbarTheme(
                      data: ScrollbarTheme.of(context).copyWith(
                          radius: const Radius.circular(20),
                          trackBorderColor: MaterialStateProperty.all(
                              const Color(0xffffccff)),
                          thumbColor: MaterialStateProperty.all(
                              const Color(0xffff4cca))),
                      child: Scrollbar(
                        child: SingleChildScrollView(
                          child: Padding(
                            padding: EdgeInsets.only(right: DimenRes.dimen_10),
                            child: TextWidget.build(
                                noticeStr.replaceAll("#", "\n"),
                                AppTextStyle.c4444444_s14),
                          ),
                        ),
                      ),
                    )),
                    const SpaceWidget(vSpace: 10,),
                    AppTextWithImgBgWidget(
                      bgImgPath: ImgRes.BG_BTN_GRADIENT,
                      bgImgHeight: DimenRes.dimen_44,
                      text: StringRes.str_app_center,
                      bottom: 12,
                      onTap: () {
                        Navigator.pop(context);
                        PageJumpUtil.forwardToAppCenter(context);
                      },
                    )
                  ],
                ),
              ),
            ],
          ),
        ));
  }

  void getClipboardText() {
    if (kIsWeb) {
      Uri uri = Uri.parse(html.window.location.href);
      String? aff = uri.queryParameters[AppConst.appClipboardPrefix];
      if (aff != null) {
        toInvitation(affCode: aff);
      }
    } else {
      Clipboard.getData(Clipboard.kTextPlain).then((value) {
        if (value != null) {
          sendCodeInvitation(value);
        }
      });
    }
  }

  Future<void> sendCodeInvitation(value) async {
    if (value.text == null) return;
    List clipTextList = value.text.split(":").toList();
    if (ListUtil.isNotEmpty(clipTextList)) {
      if (clipTextList[0] == AppConst.appClipboardPrefix) {
        if (clipTextList[1] != '') {
          toInvitation(affCode: clipTextList[1]);
        }
      }
    }
  }

  toInvitation({String? affCode}) async {
    try {
      if (StringUtil.isNotEmpty(affCode)) {
        HttpHelper.updateInvite(affCode!, (data) {}, (error) {});
      }
    } catch (e) {
      e.toString();
    }
  }

  void onLoadingConfig() {
    HttpHelper.appConfig((data) {
      try {
        Config result = Config.fromJson(data);
        // 整合接口信息
        Provider.of<HomeData>(context, listen: false).setData(result);
        // 设置上传图片
        AppGlobal.uploadImgKey = result.uploadImgKey;
        AppGlobal.uploadImgUrl = result.imgUploadUrl;

        // 设置上传视频
        AppGlobal.uploadVideoKey = result.uploadKey;
        AppGlobal.uploadVideoUrl = result.videoUploadUrl;

        String tempUrlStr = result.domainName;
        if (StringUtil.isNotEmpty(tempUrlStr)) {
          List<String> urlStrList = tempUrlStr.split(",");
          LogUtil.i("urlStrList------>" + urlStrList.toString());
          if (ListUtil.isNotEmpty(urlStrList)) {
            AppGlobal.appBox!.put(AppConst.apiLinesKey, urlStrList);
          }
        }

        getClipboardText();
        checkVersion(result);
        List<AdsModel> screenAds = result.adsScreen;
        if (ListUtil.isNotEmpty(screenAds)) {
          AdsModel adsModel = screenAds[0];
          Map<String, dynamic> adsModelMap = adsModel.toJson();
          Method.getRealImage(
              url: adsModel.imgUrl,
              setUrl: (imgUrl) {
                if (!mounted) return;
                adsModelMap['img_url'] = imgUrl;
                AppGlobal.appBox!.put(AppConst.splashAdKey, adsModelMap);
              });
        }

        // 加载用户信息 -> 首页信息
        onLoadingUserInfoAndMenuModule();
      } catch (error) {
        ToastWidget.showToast('初始化数据失败');
        debugPrint('on' + error.toString());
      }
    }, (error) {
      ToastWidget.showToast(error.message ?? '未知错误');
      debugPrint('onLoadingConfig' + error.toString());
    });
  }

  void onLoadingUserInfoAndMenuModule() {
    // User Info
    apiGetBaseInfo(context).then((value) {
      if (value == null) {
        ToastWidget.showToast('初始化数据失败');
        return;
      }
      // Menu Module
      getIndexList().then((res) {
        if (res != null && res.data is Map) {
          var temp = HomeModel.fromJson(res.data);
          menuList = temp.menu;
          // 分块 6，5，5
          for (int i = 0; i < menuList.length; i++) {}
          group = [];
          ad = temp.ads;
          adnext = temp.adsNext;
        } else {}
        setState(() {});
      });
    });
  }

  void handleRoute(value) {
    switch (value.type) {
      case 'mv':
        context.go('/' + Routes.mvIndexPage, extra: value); // 金币/会员/原创/综艺/奇闻

        break;
      case 'av':
        context.go('/' + Routes.mvIndexPage, extra: value); // 日韩
        break;
      case 'series':
        context.go('/' + Routes.mvIndexPage, extra: value); // 国产
        break;
      case 'dm':
        context.go('/' + Routes.mvIndexPage, extra: value); // 动漫
        break;
      case 'special':
        context.go('/' + Routes.mvIndexPage, extra: value); // 特价
        break;
      case 'rank':
        context.go('/ranking', extra: value); // 排行榜
        break;
      case 'ai':
        context.go('/' + Routes.mvIndexPage, extra: value); // ai换脸
        break;
      case 'image':
        context.push('/' + Routes.atlas, extra: value); // 图集
        break;
      case 'mh':
        context.push('/' + Routes.comics, extra: value); // 漫画
        break;
      case 'girl':
        context.push('/' + Routes.dating, extra: value); // 同城约炮
        break;
      case 'story':
        context.push('/' + Routes.novel, extra: value); // 小说
        break;
      case 'chat':
        context.push('/' + Routes.chatHome, extra: value); // 裸聊
        break;
      default:
    }
  }

  @override
  Widget build(BuildContext context) {
    return _buildInit();
  }

  /// 初始化构建
  Widget _buildInit() {
    return StackPage(
      header: _buildHeaderWidget(),
      child: menuList.isEmpty ? Container() : _buildMainModuleWidget(),
    );
  }

  Widget _buildMainModuleWidget() {
    index = 0; // reset menu
    return ListView(
      padding: EdgeInsets.only(
          left: DimenRes.dimen_16,
          right: DimenRes.dimen_16,
          bottom: DimenRes.dimen_5,
          top: DimenRes.dimen_10),
      physics: const BouncingScrollPhysics(),
      children: [
        Offstage(offstage: menuList.isEmpty, child: _buildFirstModuleWidget()),
        _buildAdModuleWidget(ad),
        const SpaceWidget(vSpace: 15),
        Offstage(
            offstage: menuList.length < 7, child: _buildSecondModuleWidget()),
        _buildAdModuleWidget(adnext),
        const SpaceWidget(vSpace: 15),
        Offstage(
            offstage: menuList.length < 12, child: _buildThirdModuleWidget()),
        const SpaceWidget(vSpace: 15),
        Offstage(
            offstage: menuList.length < 17, child: _buildFirstModuleWidget()),
      ],
    );
  }

  Widget _buildAdModuleWidget(List<AdsModel> ads) {
    return ads.isNotEmpty
        ? FrostedGlassBox(
            margin: EdgeInsets.only(top: DimenRes.dimen_15),
            child: BannerWidget(
              adList: ads,
              height: DimenRes.convert(108),
              scrollDirection: Axis.horizontal,
              margin: EdgeInsets.all(DimenRes.dimen_10),
              radius: BorderRadius.circular(12),
            ),
          )
        : const SizedBox();
  }

  int index = 0; // 根据索引取值
  Menu? get menu {
    return index < menuList.length ? menuList[index++] : null;
  }

  double getItemWidth() {
    return (DimenRes.screenWidth - DimenRes.dimen_48) / 3;
  }

  Widget _buildFirstModuleWidget() {
    return Column(
      children: [
        Row(children: [
          _buildLargeWidget(menu),
          SizedBox(width: DimenRes.dimen_8),
          Column(
            children: [
              _buildSmallWidget(menu),
              SizedBox(height: DimenRes.dimen_8),
              _buildSmallWidget(menu),
            ],
          )
        ]),
        SizedBox(height: DimenRes.dimen_8),
        Row(
          children: [
            _buildSmallWidget(menu),
            SizedBox(width: DimenRes.dimen_8),
            _buildSmallWidget(menu),
            SizedBox(width: DimenRes.dimen_8),
            _buildSmallWidget(menu),
          ],
        ),
      ],
    );
  }

  Widget _buildSecondModuleWidget() {
    return Row(
      children: [
        Column(
          children: [
            _buildSmallWidget(menu),
            SizedBox(height: 8.w),
            _buildSmallWidget(menu),
          ],
        ),
        SizedBox(width: 8.w),
        Column(
          children: [
            _buildSmallWidget(menu),
            SizedBox(height: 8.w),
            _buildSmallWidget(menu),
          ],
        ),
        SizedBox(width: 8.w),
        _buildTallWidget(menu),
      ],
    );
  }

  Widget _buildThirdModuleWidget() {
    return Column(
      children: [
        Row(
          children: [
            _buildLongWidget(menu),
            SizedBox(width: 8.w),
            _buildSmallWidget(menu),
          ],
        ),
        SizedBox(height: 8.w),
        Row(
          children: [
            _buildSmallWidget(menu),
            SizedBox(width: 8.w),
            _buildSmallWidget(menu),
            SizedBox(width: 8.w),
            _buildSmallWidget(menu),
          ],
        ),
      ],
    );
  }

  Widget _buildLargeWidget(Menu? menu) {
    if (menu == null) return Container();
    double blockWidth = getItemWidth() * 2 + DimenRes.dimen_8;
    double imgWidth = blockWidth * 2 / 3;
    return GestureDetector(
      onTap: () => handleRoute(menu),
      child: FrostedGlassBox(
        height: blockWidth,
        width: blockWidth,
        child: Padding(
          padding: EdgeInsets.only(top: 5.w, left: 10.w, right: 10.w),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildCommonTitle(menu.name),
              SizedBox(height: 3.w),
              Expanded(
                child: Text(
                  menu.subName,
                  maxLines: 2,
                  softWrap: true,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(fontSize: 12.sp, color: Colors.white54),
                ),
              ),
              Center(
                child: NetworkImgContainer(
                    width: imgWidth,
                    height: imgWidth,
                    url: menu.iconFull,
                    bgColor: Colors.transparent),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSmallWidget(Menu? menu) {
    if (menu == null) return Container();
    double blockWidth = getItemWidth();
    double imgWidth = blockWidth * 2 / 3;
    return GestureDetector(
      onTap: () => handleRoute(menu),
      child: FrostedGlassBox(
        height: blockWidth,
        width: blockWidth,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(
              padding: EdgeInsets.fromLTRB(10.w, 5.w, 10.w, 0),
              child: _buildCommonTitle(menu.name),
            ),
            Align(
              alignment: Alignment.centerRight,
              child: NetworkImgContainer(
                  width: imgWidth,
                  height: imgWidth,
                  url: menu.iconFull,
                  bgColor: Colors.transparent),
            )
          ],
        ),
      ),
    );
  }

  Widget _buildLongWidget(Menu? menu) {
    if (menu == null) return Container();
    double blockWidth = getItemWidth() * 2 + DimenRes.dimen_8;
    double blockHeight = getItemWidth();
    double imgWidth = blockHeight;
    return GestureDetector(
      onTap: () => handleRoute(menu),
      child: FrostedGlassBox(
        height: blockHeight,
        width: blockWidth,
        child: Row(
          children: [
            SizedBox(width: 10.w),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: 5.w),
                  _buildCommonTitle(menu.name),
                  SizedBox(height: 5.w),
                  Text(
                    menu.subName,
                    maxLines: 3,
                    softWrap: true,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(fontSize: 12.sp, color: Colors.white54),
                  ),
                ],
              ),
            ),
            NetworkImgContainer(
                height: imgWidth,
                width: imgWidth,
                url: menu.iconFull,
                bgColor: Colors.transparent),
          ],
        ),
      ),
    );
  }

  Widget _buildTallWidget(Menu? menu) {
    if (menu == null) return Container();
    double blockWidth = getItemWidth();
    double blockHeight = blockWidth * 2 + DimenRes.dimen_8;
    double imgWidth = blockWidth;
    double imgHeight = blockWidth;
    return GestureDetector(
      onTap: () => handleRoute(menu),
      child: FrostedGlassBox(
        height: blockHeight,
        width: blockWidth,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: EdgeInsets.fromLTRB(10.w, 5.w, 10.w, 5.w),
              child: _buildCommonTitle(menu.name),
            ),
            Expanded(
              child: Padding(
                padding: EdgeInsets.fromLTRB(10.w, 0, 10.w, 0),
                child: Text(
                  menu.subName,
                  maxLines: 4,
                  softWrap: true,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(fontSize: 12.sp, color: Colors.white54),
                ),
              ),
            ),
            NetworkImgContainer(
              height: imgWidth,
              width: imgHeight,
              url: menu.iconFull,
              bgColor: Colors.transparent,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCommonTitle(String text) {
    return Text(text,
        style: TextStyle(
          fontSize: 16.sp,
          color: Colors.white,
          shadows: const [
            Shadow(
              offset: Offset(0, 3),
              blurRadius: 5.0,
              color: Color.fromRGBO(26, 21, 47, 0.64),
            ),
          ],
        ));
  }

  Widget _buildHeaderWidget() {
    var userData = Provider.of<UserData>(context).userInfo;
    return Padding(
      padding: EdgeInsets.only(bottom: DimenRes.dimen_10),
      child: Row(
        children: [
          Expanded(
            flex: 1,
            child: GestureDetector(
              onTap: () {
                context.go('/${Routes.personalCenter}');
              },
              child: Row(
                children: [
                  const SpaceWidget(hSpace: 16),
                  NetworkImgContainer(
                    url: userData.avatarUrl ?? '',
                    width: DimenRes.dimen_42,
                    height: DimenRes.dimen_42,
                    radius: const BorderRadius.all(
                      Radius.circular(15),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 10, right: 10),
                    child: Text(
                      userData.nickname ?? '',
                      maxLines: 1,
                      softWrap: false,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: DimenRes.sp(18),
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  )
                ],
              ),
            ),
          ),
          Row(
            children: [
              ActionIcon(
                onTap: () => PageJumpUtil.forwardToSearchPage(context),
                url: ImgRes.IC_SEARCH,
              ),
              const SpaceWidget(hSpace: 3),
              ActionIcon(
                onTap: () => context.go('/clsIdx'),
                url: ImgRes.IC_MORE,
              ),
              const SpaceWidget(hSpace: 3),
              ActionIcon(
                onTap: () => PageJumpUtil.forwardToFilterPage(context),
                url: ImgRes.IC_FILTER,
              ),
            ],
          ),
          const SpaceWidget(hSpace: 10),
        ],
      ),
    );
  }
}
