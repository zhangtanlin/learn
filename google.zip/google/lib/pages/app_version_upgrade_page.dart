import 'dart:io';

import 'package:app_installer/app_installer.dart';
import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:iaimei/app_const.dart';
import 'package:iaimei/model/config.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/res/img_res.dart';
import 'package:iaimei/res/string_res.dart';
import 'package:iaimei/style/app_decoration.dart';
import 'package:iaimei/style/app_text_style.dart';
import 'package:iaimei/utils/download_util.dart';
import 'package:iaimei/utils/permission_util.dart';
import 'package:iaimei/utils/string_util.dart';
import 'package:iaimei/utils/web_util.dart';
import 'package:iaimei/widget/app_img_widget.dart';
import 'package:iaimei/widget/app_text_with_img_bg_widget.dart';
import 'package:iaimei/widget/linear_gradient_progress_bar.dart';
import 'package:iaimei/widget/space_widget.dart';
import 'package:iaimei/widget/text_widget.dart';
import 'package:iaimei/widget/toast_widget.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';

typedef UpgradeCallback = void Function();

class AppVersionUpgradePage extends StatefulWidget {
  final Version? version;
  final UpgradeCallback? callback;

  const AppVersionUpgradePage({Key? key, this.version, this.callback})
      : super(key: key);

  @override
  State<AppVersionUpgradePage> createState() => _AppVersionUpgradePageState();
}

class _AppVersionUpgradePageState extends State<AppVersionUpgradePage> {
  bool _startUpgrade = false;
  int _progress = 0;
  Version? _appVersion;

  @override
  void initState() {
    super.initState();
    _appVersion = widget.version!;
  }

  @override
  Widget build(BuildContext context) {
    double dialogWidth = DimenRes.screenWidth * 3 / 4;
    return Material(
      //创建透明层
      type: MaterialType.transparency, //透明类型
      child: Center(
        //保证控件居中效果
        child: Container(
            width: dialogWidth,
            constraints: BoxConstraints(
              minHeight: DimenRes.dimen_200,
              maxHeight: DimenRes.dimen_370,
            ),
            child: Column(
              children: [
                Stack(
                  children: [
                    Positioned(
                      child: Container(
                        color: Colors.white,
                        height: DimenRes.dimen_20,
                        width: dialogWidth,
                      ),
                      bottom: 0,
                    ),
                    AppImgWidget(
                      path: ImgRes.IMG_UPGRADE_TOP,
                      width: dialogWidth,
                      height: dialogWidth * 23 / 63,
                      fit: BoxFit.fitWidth,
                    ),
                  ],
                ),
                Container(
                  width: double.infinity,
                  height: DimenRes.dimen_210,
                  transform: Matrix4.translationValues(0, -1, 0),
                  decoration: AppDecoration.getSingleColorBg(
                      color: Colors.white,
                      radius: const BorderRadius.only(
                          bottomLeft: Radius.circular(24),
                          bottomRight: Radius.circular(24))),
                  child: Column(
                    children: [
                      Padding(
                          padding: EdgeInsets.only(
                              left: DimenRes.dimen_20,
                              top: DimenRes.dimen_20,
                              bottom: DimenRes.dimen_10,
                              right: DimenRes.dimen_20),
                          child: TextWidget.buildSingleLineText(
                              StringRes.str_new_version_update,
                              AppTextStyle.c333333_s18_bold)),
                      Expanded(
                        child: SingleChildScrollView(
                          child: Padding(
                            padding: EdgeInsets.only(
                                left: DimenRes.dimen_20,
                                right: DimenRes.dimen_20),
                            child: TextWidget.build(
                                widget.version!.tips.replaceAll("#", "\n"),
                                AppTextStyle.c4444444_s13),
                          ),
                        ),
                      ),
                      _startUpgrade
                          ? _buildProgressBar()
                          : Padding(
                              padding: EdgeInsets.only(
                                  top: DimenRes.dimen_20,
                                  bottom: DimenRes.dimen_15),
                              child: _buildBottomBtnSection(context))
                    ],
                  ),
                ),
                SpaceWidget(
                  vSpace: DimenRes.dimen_20,
                ),
                _appVersion?.must == 1
                    ? const SizedBox()
                    : AppImgWidget(
                        path: ImgRes.IC_DIALOG_CLOSE,
                        width: DimenRes.dimen_30,
                        height: DimenRes.dimen_30,
                        onTap: () {
                          Navigator.pop(context);
                          widget.callback?.call();
                        },
                      )
              ],
            )),
      ),
    );
  }

  Column _buildProgressBar() {
    return Column(
      children: [
        Padding(
          padding: EdgeInsets.only(
              left: DimenRes.dimen_20,
              right: DimenRes.dimen_20,
              bottom: DimenRes.dimen_10,
              top: DimenRes.dimen_20),
          child: SizedBox(
              width: DimenRes.screenWidth * 3 / 4,
              height: DimenRes.dimen_10,
              child: LinearGradientProgressBar(
                value: _progress.toDouble() / 100,
              )),
        ),
        Padding(
          padding: EdgeInsets.only(bottom: DimenRes.dimen_20),
          child: TextWidget.buildSingleLineText(
              _progress < 100 ? "新版下载$_progress%，请稍等..." : "新版已下载完成，请安装使用",
              AppTextStyle.c4444444_s13),
        )
      ],
    );
  }

  Widget _buildBottomBtnSection(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        AppTextWithImgBgWidget(
            bgImgPath: ImgRes.BG_BTN_GRADIENT,
            bgImgHeight: DimenRes.dimen_44,
            text: StringRes.str_upgrade_now,
            bottom: 12,
            onTap: () {
              if (!kIsWeb) {
                if (Platform.isAndroid) {
                  List<Permission> permissionList = [
                    Permission.storage,
                  ];
                  PermissionUtil.check(permissionList, onSuccess: () async {
                    setState(() {
                      _startUpgrade = true;
                    });
                    _downApkAction();
                  }, onFail: () {
                    ToastWidget.showToast(StringRes.str_denied_permission_hint);
                  });
                } else if (Platform.isIOS) {
                  WebUtil.browserLaunchURL(_appVersion!.apk);
                }
              }
            }),
      ],
    );
  }

  void _downApkAction() {
    try {
      getExternalStorageDirectory().then((documents) {
        String savePath =
            '${documents!.path}/${AppConst.appPrefix}_${DateTime.now().millisecondsSinceEpoch}.apk';
        String url = _appVersion!.apk;
        if (StringUtil.isNotEmpty(url)) {
          Future<Response> response = DownloadUtil.download(url, savePath,
              onReceiveProgress: (int count, int total) {
            var tmp = (count / total * 100).toInt();
            if (tmp % 1 == 0) {
              setState(() {
                _progress = tmp;
              });
            }
            if (count >= total) {
              _installApk(savePath);
            }
          });
          response.catchError((e) {
            _updateFailAction();
          });
        } else {
          _updateFailAction();
        }
      });
    } catch (e) {
      _updateFailAction();
    }
  }

  void _updateFailAction() {
    ToastWidget.showToast(StringRes.str_update_failed);
    _startUpgrade = false;
    setState(() {});
  }

  Future<void> _installApk(savePath) async {
    try {
      // CommonUtils.checkStoragePermission();
      AppInstaller.installApk(savePath)
          .then((result) {})
          .catchError((error) {});
    } on Exception catch (_) {}
  }
}
