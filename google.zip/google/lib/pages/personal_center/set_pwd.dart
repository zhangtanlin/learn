import 'package:bot_toast/bot_toast.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:hive/hive.dart';
import 'package:iaimei/components/common/base_dialog.dart';
import 'package:iaimei/components/common/commonelements.dart';
import 'package:iaimei/components/common/stackpage.dart';
import 'package:iaimei/global.dart';
import 'package:iaimei/model/basic.dart';
import 'package:iaimei/utils/api.dart';
import 'package:iaimei/widget/buttom_widget.dart';

/// 设置密码
class SetPwd extends StatefulWidget {
  const SetPwd({Key? key}) : super(key: key);

  @override
  State<SetPwd> createState() => _SetPwdState();
}

class _SetPwdState extends State<SetPwd> with TickerProviderStateMixin {
  // 提交处理中
  bool isSubmit = true;

  // 暧昧号文本框控制器
  TextEditingController nameController = TextEditingController();
  // 密码文本框控制器
  TextEditingController pwdController = TextEditingController();
  // 密码确认文本框控制器
  TextEditingController pwdVerifyController = TextEditingController();

  /// 更新token
  Future<void> updateToken(token) async {
    String tempToken = token;
    Box? box = AppGlobal.appBox;
    await box?.put('gg_token', tempToken);
  }

  /// 提交
  void handleSubmit() async {
    String tempName = nameController.text.trim();
    String tempPwd = pwdController.text.trim();
    String tempConfirmPwd = pwdVerifyController.text.trim();
    if (tempName == '') {
      BaseDialog.toast(text: '暧昧号不能为空');
      return;
    }
    if (tempPwd == '') {
      BaseDialog.toast(text: '密码不能为空');
      return;
    }
    if (tempConfirmPwd == '') {
      BaseDialog.toast(text: '新密码不能为空');
      return;
    }
    if (tempPwd != tempConfirmPwd) {
      BaseDialog.toast(text: '两次密码输入不一致');
      return;
    }
    await onSubmit(
      username: tempName,
      password: tempPwd,
      confirmPassword: tempConfirmPwd,
    );
  }

  /// 请求接口
  Future<void> onSubmit(
      {required username, required password, required confirmPassword}) async {
    Basic? res = await apiSetUserInfo(
      username: username,
      password: password,
      confirmPassword: confirmPassword,
    );
    if (res?.status == 1) {
      BotToast.showText(text: res?.data["msg"] ?? "设置暧昧号成功");
      await updateToken(res!.data["token"]);
      await apiGetBaseInfo(context);
      context.go('/');
    } else {
      BotToast.showText(text: res?.msg ?? '设置暧昧号失败');
    }
  }

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    nameController.dispose();
    pwdController.dispose();
    pwdVerifyController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScopeNode currentFocus = FocusScope.of(context);
        if (!currentFocus.hasPrimaryFocus &&
            currentFocus.focusedChild != null) {
          FocusManager.instance.primaryFocus?.unfocus();
        }
      },
      child: StackPage(
        header: const CustomHeader(title: '设置暧昧号'),
        child: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 16.w),
            child: Column(
              children: [
                SizedBox(height: 10.w),
                _buildContainerWidget(
                  child: _buildTextFieldWidget(nameController, '设置暧昧号'),
                ),
                _buildContainerWidget(
                  child: _buildTextFieldWidget(pwdController, '请输入密码',
                      obscureText: true),
                ),
                _buildContainerWidget(
                  child: _buildTextFieldWidget(pwdVerifyController, '确认密码',
                      obscureText: true),
                ),
                _buildHintTextWidget(),
                SizedBox(height: 100.w),
                ButtonWidget.build('提交', onTap: handleSubmit),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildContainerWidget({Widget? child}) {
    return Container(
      height: 44.w,
      alignment: Alignment.center,
      margin: EdgeInsets.only(bottom: 15.w),
      decoration: BoxDecoration(
        color: const Color.fromRGBO(188, 136, 255, 0.12),
        border: Border.all(color: const Color(0x0dffffff), width: 0.5),
        borderRadius: BorderRadius.circular(12.w),
      ),
      child: child,
    );
  }

  Widget _buildTextFieldWidget(
      TextEditingController? controller, String hintText,
      {bool obscureText = false}) {
    return TextField(
      obscureText: obscureText,
      controller: controller,
      cursorColor: const Color(0xffFF00B3),
      style: TextStyle(color: Colors.white, fontSize: 14.sp),
      textAlign: TextAlign.center,
      decoration: InputDecoration(
        contentPadding: EdgeInsets.symmetric(horizontal: 10.w),
        hintText: hintText,
        hintStyle: TextStyle(color: const Color(0x99FFFFFF), fontSize: 13.sp),
        border: const OutlineInputBorder(borderSide: BorderSide.none),
        suffixIcon: GestureDetector(
          onTap: () => controller?.clear(),
          child: Image.asset('assets/images/common/input_close.png', scale: 2),
        ),
      ),
    );
  }

  Widget _buildHintTextWidget() {
    return Container(
      padding: EdgeInsets.only(top: 5.w),
      alignment: Alignment.topLeft,
      child: Text.rich(
        const TextSpan(children: [
          TextSpan(text: '温馨提示:', style: TextStyle(color: Color(0xd6ffffff))),
          TextSpan(text: '\n暧昧号是登录暧昧app唯一凭证，提交后不可修改！')
        ]),
        style: TextStyle(color: const Color(0x89ffffff), fontSize: 12.sp),
      ),
    );
  }
}
