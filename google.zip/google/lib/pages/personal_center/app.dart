import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:iaimei/components/common/commonelements.dart';
import 'package:iaimei/components/common/pagestatus.dart';
import 'package:iaimei/components/common/pullrefreshlist.dart';
import 'package:iaimei/components/common/stackpage.dart';
import 'package:iaimei/model/model_app.dart';
import 'package:iaimei/utils/api.dart';
import 'package:iaimei/utils/web_util.dart';
import 'package:iaimei/widget/banner_widget.dart';
import 'package:iaimei/widget/buttom_widget.dart';
import 'package:iaimei/widget/convenient_mixin.dart';
import 'package:iaimei/widget/frosted_glass_box.dart';
import 'package:iaimei/widget/network_img_container.dart';

/// 应用中心
class App extends StatefulWidget {
  const App({Key? key}) : super(key: key);

  @override
  State<App> createState() => _AppState();
}

class _AppState extends State<App> with ConvenientMixin {
  bool loading = true; // 加载中状态

  late Data data;

  void getData() async {
    ModelApp? res = await apiApp();
    if (res?.status == 1) {
      data = res!.data;
    }
    loading = false;
    setState(() {});
  }

  @override
  void initState() {
    super.initState();
    getData();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return StackPage(
      header: const CustomHeader(title: '应用推荐'),
      child: loading ? PageStatus.loading(true) : flex(),
    );
  }

  /// 布局
  Widget flex() {
    return Flex(
      direction: Axis.vertical,
      children: [
        SizedBox(height: 10.w),
        FrostedGlassBox(
          margin: EdgeInsets.symmetric(horizontal: 16.w),
          child: BannerWidget(
            adList: data.banner,
            height: 108.w,
            scrollDirection: Axis.vertical,
            margin: EdgeInsets.all(10.w),
            radius: BorderRadius.circular(12),
          ),
        ),
        SizedBox(height: 5.w),
        Expanded(
          child: PullRefreshList(
            onRefresh: () {},
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                for (var i = 0; i < data.apps.length; i++) ...[
                  _buildItemWidget(data.apps[i]),
                ]
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildItemWidget(dynamic item) {
    return GestureDetector(
      onTap: () {
        if (item.linkUrl.isNotEmpty) {
          WebUtil.browserLaunchURL(item.linkUrl);
        }
      },
      child: Flex(
        direction: Axis.horizontal,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          SizedBox(width: 16.w),
          SizedBox(
            width: 56.w,
            height: 56.w,
            child: NetworkImgContainer(
              url: item.imgUrl,
              radius: BorderRadius.all(Radius.circular(12.w)),
            ),
          ),
          SizedBox(width: 8.w),
          Expanded(
            child: Container(
              height: 86.0.w,
              decoration: const BoxDecoration(
                border: Border(
                  bottom: BorderSide(width: 0.5, color: Color(0x1effffff)),
                ),
              ),
              child: Flex(
                direction: Axis.horizontal,
                children: [
                  Expanded(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          item.title,
                          style: TextStyle(
                              color: wColor,
                              fontSize: 14.sp,
                              fontWeight: fontM),
                        ),
                        Text(
                          item.description,
                          style: TextStyle(color: color_54, fontSize: 12.sp),
                          maxLines: 1,
                        ),
                      ],
                    ),
                  ),
                  SizedBox(width: 16.w),
                  ButtonWidget.build('下载', style: IconStyle.pink_68_34),
                ],
              ),
            ),
          ),
          SizedBox(width: 16.w),
        ],
      ),
    );
  }
}
