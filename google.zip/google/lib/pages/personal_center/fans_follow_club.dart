import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:iaimei/components/common/head.dart';
import 'package:iaimei/components/common/pageviewmixin.dart';
import 'package:iaimei/components/common/stackpage.dart';
import 'package:iaimei/components/list/list_club.dart';
import 'package:iaimei/components/list/list_fans.dart';
import 'package:iaimei/pages/mv/nav_tab_bar_mixin.dart';
import 'package:iaimei/store/userdata.dart';
import 'package:provider/provider.dart';

class FansFollowClub extends StatefulWidget {
  final int type;
  const FansFollowClub({
    Key? key,
    this.type = 0,
  }) : super(key: key);

  @override
  State<FansFollowClub> createState() => _FansFollowClubState();
}

class _FansFollowClubState extends State<FansFollowClub>
    with TickerProviderStateMixin {
  // 选项卡控制器啊
  late TabController tabController;
  // 头部选项卡
  List tabs = [
    {
      "name": '粉丝',
    },
    {
      "name": '关注',
    },
    {
      "name": '粉丝团',
    },
  ];
  int tabIndexCurrent = 0;

  @override
  void initState() {
    super.initState();
    tabIndexCurrent = widget.type;
    tabController = TabController(
      initialIndex: widget.type,
      length: tabs.length,
      vsync: this,
    );
    tabController.addListener(() {
      setState(() {
        tabIndexCurrent = tabController.index;
      });
    });
  }

  @override
  void dispose() {
    tabController.dispose();
    super.dispose();
  }

  /// 设置列表
  Widget setList(i) {
    switch (i) {
      case 1:
        return const ListFans(
          type: 1,
        );
      case 2:
        var user = Provider.of<UserData>(context, listen: false).userInfo;
        return ListClub(id: user.club == null ? null : user.club['id']);
      default:
        return const ListFans();
    }
  }

  @override
  Widget build(BuildContext context) {
    return StackPage(
      header: HeadBack(
        leftText: '',
        center: Row(
          children: [
            NavTabBarWidget(
              tabVc: tabController,
              tabs: tabs.map<String>((e) => e['name']).toList(),
              textPadding: EdgeInsets.symmetric(horizontal: 15.w),
              norTextStyle: TextStyle(
                  color: Colors.white,
                  fontSize: 14.sp,
                  fontWeight: FontWeight.w400),
              selTextStyle: TextStyle(
                  color: const Color(0xffff00b3),
                  fontSize: 18.sp,
                  fontWeight: FontWeight.w500),
              selectedIndex: tabIndexCurrent,
            ),
          ],
        ),
        right: SizedBox(
          width: ScreenUtil().setWidth(15.0),
        ),
      ),
      child: TabBarView(
        controller: tabController,
        children: [
          for (var i = 0; i < tabs.length; i++) ...[
            PageViewMixin(
              child: setList(i),
            ),
          ]
        ],
      ),
    );
  }
}
