import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:iaimei/components/card/card_dating_item.dart';
import 'package:iaimei/components/common/commonelements.dart';
import 'package:iaimei/components/common/pageviewmixin.dart';
import 'package:iaimei/components/common/pullrefreshlist.dart';
import 'package:iaimei/components/common/stackpage.dart';
import 'package:iaimei/global.dart';
import 'package:iaimei/model/atlas_item_model.dart';
import 'package:iaimei/model/chat_detail_model.dart';
import 'package:iaimei/model/comics_item_model.dart';
import 'package:iaimei/model/novel_item_model.dart';
import 'package:iaimei/model/video_model.dart';
import 'package:iaimei/pages/mv/mv_list_page.dart';
import 'package:iaimei/pages/mv/nav_tab_bar_mixin.dart';
import 'package:iaimei/res/img_res.dart';
import 'package:iaimei/router/routers.dart';
import 'package:iaimei/utils/page_jump_util.dart';
import 'package:iaimei/widget/convenient_mixin.dart';
import 'package:iaimei/widget/network_img_container.dart';
import 'package:iaimei/widget/state_mixin.dart';

class BrowseHistory extends StatefulWidget {
  const BrowseHistory({Key? key, this.index = 0}) : super(key: key);
  final int index;
  @override
  State<BrowseHistory> createState() => _BrowseHistoryState();
}

class _BrowseHistoryState extends State<BrowseHistory>
    with TickerProviderStateMixin, ConvenientMixin {
  int selectedIndex = 0;
  late TabController tabController;
  List<String> items = ['视频', '漫画', '小说', '裸聊', '约炮', '图集'];

  @override
  void initState() {
    super.initState();

    selectedIndex = widget.index;
    if (selectedIndex >= items.length) {
      selectedIndex = 0;
    }

    tabController = TabController(
      length: items.length,
      vsync: this,
      initialIndex: selectedIndex,
    );
  }

  @override
  Widget build(BuildContext context) {
    return StackPage(
      header: const CustomHeader(title: '浏览记录'),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          NavTabBarWidget(
            tabVc: tabController,
            tabs: items,
            textPadding: EdgeInsets.symmetric(horizontal: 15.w),
            norTextStyle: TextStyle(
                color: wColor, fontSize: 14.sp, fontWeight: FontWeight.w400),
            selTextStyle:
                TextStyle(color: rColor, fontSize: 14.sp, fontWeight: fontM),
          ),
          Container(
              color: Colors.white24,
              margin: EdgeInsets.symmetric(horizontal: 16.w),
              height: 0.5),
          Expanded(child: _buildTabBarViewWidget()),
        ],
      ),
    );
  }

  Widget _buildTabBarViewWidget() {
    return TabBarView(
      controller: tabController,
      children: items
          .asMap()
          .keys
          .map<Widget>(
              (index) => PageViewMixin(child: BrowseHistoryList(index: index)))
          .toList(),
    );
  }
}

/* ************************************************************* */

class BrowseHistoryList extends StatefulWidget {
  const BrowseHistoryList({Key? key, this.index = 0}) : super(key: key);
  final int index;
  @override
  State<BrowseHistoryList> createState() => _BrowseHistoryListState();
}

class _BrowseHistoryListState extends State<BrowseHistoryList>
    with ConvenientMixin, StateMixin {
  @override
  void initLoadingData() {
    var list = [];
    switch (widget.index) {
      case 0: // 视频
        list = AppGlobal.readBrowseHistory(BrowseKey.video)
            .map((json) => VideoModel.fromJson(json))
            .toList();
        break;
      case 1: // 漫画
        list = AppGlobal.readBrowseHistory(BrowseKey.comics)
            .map((json) => ComicsItemModel.fromJson(json))
            .toList();
        break;
      case 2: // 小说
        list = AppGlobal.readBrowseHistory(BrowseKey.novel)
            .map((json) => NovelItemModel.fromJson(json))
            .toList();
        break;
      case 3: // 裸聊
        list = AppGlobal.readBrowseHistory(BrowseKey.nudeChat)
            .map((json) => ChatDetailModel.fromJson(json))
            .toList();
        break;
      case 4: // 约炮
        list = AppGlobal.readBrowseHistory(BrowseKey.dateLove);
        break;
      case 5: // 图集
        list = AppGlobal.readBrowseHistory(BrowseKey.imgAsset)
            .map((json) => AtlasItemModel.fromJson(json))
            .toList();
        break;
      default:
    }
    updateListAndWidgetState(list);
  }

  @override
  Widget noDataWidget() {
    return buildDataWidget(
      icon: 'assets/images/common/ic_load_error.png',
      content: '暂无数据',
      tipHidden: true,
    );
  }

  @override
  Widget build(BuildContext context) {
    if (widgetState != WidgetState.finish &&
        widgetState != WidgetState.noData) {
      return placeholderWidget();
    }

    Widget itemWidget(item) {
      switch (widget.index) {
        case 0: // 视频
          return Container();
        case 1: // 漫画
          item = item as ComicsItemModel;
          var temp =
              item.isType == 1 ? 'vip' : (item.isType == 2 ? 'coin' : 'free');
          var path = "assets/images/common/ic_badge_$temp.png";
          return commonWidget(BrowseKey.comics, item, item.title,
              item.imgUrlFull, item.refreshAt, path);
        case 2: // 小说
          item = item as NovelItemModel;
          var temp =
              item.isType == 1 ? 'vip' : (item.isType == 2 ? 'coin' : 'free');
          var path = "assets/images/common/ic_badge_$temp.png";
          return commonWidget(BrowseKey.novel, item, item.title,
              item.imgUrlFull, item.refreshAt, path);
        case 3: // 裸聊
          item = item as ChatDetailModel;
          return commonWidget(BrowseKey.nudeChat, item, item.title,
              item.thumbUrl, item.createdAt, null);
        case 4: // 约炮
          return CardDatingItem(item: item);
        case 5: // 图集
          item = item as AtlasItemModel;
          var temp =
              item.isType == 1 ? 'vip' : (item.isType == 2 ? 'coin' : 'free');
          var path = "assets/images/common/ic_badge_$temp.png";
          return commonWidget(BrowseKey.imgAsset, item, item.title,
              item.thumbFull, item.refreshAt, path);
        default:
          return Container();
      }
    }

    // 视频
    if (widget.index == 0) {
      return PullRefreshList(
        isAll: true,
        onRefresh: onRefresh,
        child: MvListPage(
          type: 2,
          dataList: dataList,
        ),
      );
    }
    // 其它
    return PullRefreshList(
      isAll: true,
      onRefresh: onRefresh,
      child: SingleChildScrollView(
        child: ListView.builder(
          itemCount: dataList.length,
          padding: EdgeInsets.fromLTRB(16.w, 0, 16.w, 20.w),
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemBuilder: ((context, index) => itemWidget(dataList[index])),
        ),
      ),
    );
  }

  Widget commonWidget(BrowseKey type, dynamic item, title, url, date, icon) {
    var temp = icon ?? ImgRes.IC_BADGE_FREE;
    return GestureDetector(
      behavior: HitTestBehavior.translucent,
      onTap: () {
        switch (type) {
          case BrowseKey.comics:
            PageJumpUtil.forwardToComicsDetailPage(context, item);
            break;
          case BrowseKey.novel:
            PageJumpUtil.forwardToNovelDetailPage(context, item);
            break;
          case BrowseKey.imgAsset:
            PageJumpUtil.forwardToAtlasDetailPage(context, item);
            break;
          case BrowseKey.nudeChat:
            context.push('/${Routes.chatDetail}', extra: {'info_id': item.id});
            break;
          default:
        }
      },
      child: Padding(
        padding: EdgeInsets.only(top: 15.0.w),
        child: Flex(
          direction: Axis.horizontal,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Stack(
              children: [
                SizedBox(
                  height: 140.0.w,
                  width: 105.0.w,
                  // color: const Color.fromRGBO(188, 136, 255, 0.12),
                  child: NetworkImgContainer(
                    url: '$url',
                    fit: BoxFit.cover,
                    radius: BorderRadius.circular(10.w),
                  ),
                ),
                Positioned(
                  right: 5.0.w,
                  top: 5.0.w,
                  child: Offstage(
                      offstage: icon == null,
                      child: Image.asset(temp, width: 36.0.w, height: 18.0.w)),
                ),
              ],
            ),
            Expanded(
              child: Container(
                height: 140.0.w,
                padding: EdgeInsets.only(left: 10.0.w),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('$title',
                        style: TextStyle(
                            color: wColor, fontSize: 14.sp, fontWeight: fontM),
                        maxLines: 3),
                    Text('$date',
                        style: TextStyle(color: color_64, fontSize: 12.sp)),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
