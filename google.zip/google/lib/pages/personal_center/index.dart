import 'package:flutter/material.dart';
import 'package:flutter_html/style.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:iaimei/components/common/base_dialog.dart';
import 'package:iaimei/components/common/commonelements.dart';
import 'package:iaimei/components/common/glassmorphism.dart';
import 'package:iaimei/components/common/head.dart';
import 'package:iaimei/components/common/pullrefreshlist.dart';
import 'package:iaimei/components/common/stackpage.dart';
import 'package:iaimei/model/user_info_model.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/router/routers.dart';
import 'package:iaimei/store/userdata.dart';
import 'package:iaimei/theme/default.dart';
import 'package:iaimei/utils/api.dart';
import 'package:iaimei/utils/common.dart';
import 'package:iaimei/utils/networkimage.dart';
import 'package:iaimei/widget/banner_widget.dart';
import 'package:iaimei/widget/buttom_widget.dart';
import 'package:iaimei/widget/frosted_glass_box.dart';
import 'package:provider/provider.dart';

/// 个人中心
class PersonalCenter extends StatefulWidget {
  const PersonalCenter({Key? key}) : super(key: key);

  @override
  State<PersonalCenter> createState() => _PersonalCenterState();
}

class _PersonalCenterState extends State<PersonalCenter>
    with TickerProviderStateMixin {
  List serverList = [
    {
      "title": "浏览记录",
      "icon": "assets/images/personal_center/server1.png",
      "route": "/browseHistory",
    },
    {
      "title": "收藏购买",
      "icon": "assets/images/personal_center/server2.png",
      "route": "/collectBuy/0",
    },
    {
      "title": "下载缓存",
      "icon": "assets/images/personal_center/server3.png",
      "route": "/cacheHistory",
    },
    {
      "title": "建议意见",
      "icon": "assets/images/personal_center/server4.png",
      "route": "/${Routes.msgBoard}",
    },
    {
      "title": "认证与入驻",
      "icon": "assets/images/personal_center/server5.png",
      "route": "/${Routes.authIndex}",
    },
    {
      "title": "联系运营",
      "icon": "assets/images/personal_center/server6.png",
      "route": "/${Routes.contact}",
    },
    {
      "title": "联系客服",
      "icon": "assets/images/personal_center/server7.png",
      "route": "/${Routes.onlineService}",
    },
    {
      "title": "应用推荐",
      "icon": "assets/images/personal_center/server8.png",
      "route": "/${Routes.appCenter}",
    },
  ]; // 服务列表

  void getData() async {
    await apiGetBaseInfo(context);
  }

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    var user = Provider.of<UserData>(context).userInfo;
    List activeList = [
      {
        "type": 1,
        'descr': user.vipLevel == 0 ? '您还不是会员' : '',
        "value": user.vipLevel == 5
            ? '永不到期'
            : user.vipLevel > 0 && user.expiredStr != null
                ? user.expiredStr!.split(' ')[0] + '到期'
                : '',
        "titleUrl": "assets/images/personal_center/active_title1.png",
        "bgUrl": "assets/images/personal_center/active_bg1.png",
        "route": "/${Routes.rechargeVip}",
      },
      {
        "type": 2,
        'descr': '余额：',
        "value": user.coins ?? 0,
        "titleUrl": "assets/images/personal_center/active_title2.png",
        "bgUrl": "assets/images/personal_center/active_bg2.png",
        "route": "/${Routes.rechargeCoins}",
      },
      {
        "type": 3,
        'descr': '今日收益：',
        "value": user.todayCoins ?? 0,
        "titleUrl": "assets/images/personal_center/active_title3.png",
        "bgUrl": "assets/images/personal_center/active_bg3.png",
        "route": "/${Routes.creator}",
      },
      {
        "type": 4,
        'descr': '今日收益：',
        "value": user.todayTuiCoins ?? 0,
        "titleUrl": "assets/images/personal_center/active_title4.png",
        "bgUrl": "assets/images/personal_center/active_bg4.png",
        "route": double.parse('${user.allTuiCoins}') > 0
            ? "/${Routes.income}"
            : "/${Routes.agency}",
        // "route":  "/${Routes.income}"
      },
    ]; // 操作列表
    return StackPage(
      header: HeadBack(
        leftText: '',
        right: Row(
          children: [
            ActionIcon(
              url: "assets/images/common/action_message.png",
              // mark: userData.messageTip! > 0,
              onTap: () {
                setState(() {
                  Provider.of<UserData>(
                    context,
                    listen: false,
                  ).setMessageTip(0);
                });
                context.push("/${Routes.msg}");
              },
            ),
            ActionIcon(
              url: "assets/images/common/action_set.png",
              onTap: () {
                context.push("/${Routes.set}");
              },
            ),
          ],
        ),
      ),
      child: PullRefreshList(
        onRefresh: () => getData(),
        child: SingleChildScrollView(
          child: Column(
            children: [
              const UserInfoBox(),
              const StatisticsBox(),
              _buildCenterWidget(activeList, user),
              const AdBox(),
              _buildBottomWidget(serverList, user),
            ],
          ),
        ),
      ),
    );
  }

  /// 点击
  void onTap(String route, UserInfoModel data) {
    List filter = ['/${Routes.creator}', '/${Routes.authIndex}'];
    // 创作中心/认证与入住->未绑定暧昧号->绑定
    if (filter.contains(route) && data.isReg != 1) {
      // Method.showText('请先绑定暧昧号');
      context.push("/${Routes.setPwd}");
      return;
    }
    // 创作中心->未认证->弹窗联系客服
    if (route == '/${Routes.creator}' &&
        (data.maker == null || data.maker['is_up'] != 1)) {
      BaseDialog.showdialog(
        context,
        barrierColor: Colors.black.withOpacity(0.54),
        barrierDismissible: true,
        cancelBack: () {},
        child: Column(
          children: [
            Padding(
              padding: EdgeInsets.only(top: 30.w, bottom: 10.w),
              child: Text(
                '提示',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 18.sp,
                    fontWeight: FontWeight.w500),
              ),
            ),
            Text(
              "成为原创主，需官方认证",
              style: TextStyle(
                  color: const Color(0xffff00b7),
                  fontSize: 14.sp,
                  fontWeight: FontWeight.w600),
            ),
            SizedBox(height: 20.w),
            ButtonWidget.build(
              '联系官方',
              onTap: () => context.push("/${Routes.contact}"),
            ),
            SizedBox(height: 20.w),
          ],
        ),
      );
      return;
    }
    context.push(route);
  }

  Widget _buildCenterWidget(List list, UserInfoModel data) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 20.0.w),
      child: Wrap(
        direction: Axis.horizontal,
        runSpacing: 15.0.w,
        spacing: 15.0.w,
        runAlignment: WrapAlignment.spaceBetween,
        children: list
            .map(
              (item) => _buildCenterItemWidget(item, data),
            )
            .toList(),
      ),
    );
  }

  Widget _buildCenterItemWidget(Map item, UserInfoModel data) {
    return Stack(
      children: [
        Positioned.fill(child: Image.asset(item["bgUrl"], fit: BoxFit.cover)),
        GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: () => onTap(item["route"], data),
          child: Container(
            height: 60.w,
            width: 164.w,
            padding: EdgeInsets.symmetric(horizontal: 8.0.w),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Image.asset(item["titleUrl"], height: 17.5.w),
                SizedBox(height: 2.w),
                Text.rich(
                  TextSpan(children: [
                    TextSpan(
                      text: '${item['descr']}',
                      style: const TextStyle(color: Color(0xb8ffffff)),
                    ),
                    TextSpan(
                      text: '${item['value']}',
                      style: const TextStyle(
                          color: Colors.white, fontWeight: FontWeight.w600),
                    ),
                  ]),
                  style: TextStyle(fontSize: 12.sp),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildBottomWidget(List list, UserInfoModel data) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 20.0.w),
      child: Wrap(
        direction: Axis.horizontal,
        runSpacing: 13.0.w,
        spacing: 13.0.w,
        runAlignment: WrapAlignment.spaceBetween,
        children: list.map((item) {
          return _buildBottomItemWidget(item, data);
        }).toList(),
      ),
    );
  }

  Widget _buildBottomItemWidget(Map item, UserInfoModel data) {
    return GestureDetector(
      onTap: () => onTap(item["route"], data),
      child: Container(
        height: 76.w,
        width: 76.w,
        decoration: BoxDecoration(
          color: const Color.fromRGBO(188, 136, 255, 0.12),
          borderRadius: BorderRadius.all(Radius.circular(12.0.w)),
          border: Border.all(color: const Color(0x0dffffff), width: 0.5),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            SizedBox(height: 10.w),
            Image.asset(item["icon"], width: 36.w, height: 36.w),
            SizedBox(height: 5.w), // 6 overflowed 1 pixels
            Text(
              item["title"],
              style: TextStyle(color: const Color(0xa3ffffff), fontSize: 12.sp),
            ),
            // SizedBox(height: 7.w), //
          ],
        ),
      ),
    );
  }
}

/// 用户信息盒子
/// [_buildVipSection]设置vip/vip等级/粉丝团
class UserInfoBox extends StatelessWidget {
  const UserInfoBox({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var user = Provider.of<UserData>(context).userInfo;
    return Padding(
      padding: EdgeInsets.only(
        right: DefaultStyle.pagePadding,
        bottom: ScreenUtil().setWidth(20.0),
        left: DefaultStyle.pagePadding,
      ),
      child: Flex(
        direction: Axis.horizontal,
        children: [
          GestureDetector(
            child: Container(
              height: 72.w,
              width: 72.w,
              padding: EdgeInsets.all(0.1.w),
              decoration: BoxDecoration(
                border: Border.all(color: const Color(0x33ffffff), width: 1.w),
                borderRadius: BorderRadius.circular(25.w),
              ),
              child: ClipRRect(
                  borderRadius: BorderRadius.circular(25.w),
                  child: PlatformAwareAssetImage(
                    fit: BoxFit.fill,
                    url: user.avatarUrl ?? "",
                    alignment: Alignment.center,
                  )),
            ),
            onTap: () {
              if (user.isReg != 1) {
                context.push("/${Routes.login}");
              }
            },
          ),
          Expanded(
            child: Container(
              padding: EdgeInsets.only(left: 5.0.w),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Text(
                        user.nickname.toString(),
                        style: TextStyle(
                          color: DefaultStyle.colorWhite,
                          fontSize: ScreenUtil().setSp(16),
                          overflow: TextOverflow.ellipsis,
                          decoration: TextDecoration.none,
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.only(left: 5.w),
                        padding: EdgeInsets.symmetric(
                          vertical: ScreenUtil().setWidth(1.25),
                          horizontal: ScreenUtil().setWidth(5),
                        ),
                        decoration: BoxDecoration(
                          color: DefaultStyle.bgDefault,
                          borderRadius: BorderRadius.all(Radius.circular(10.w)),
                        ),
                        child: Text(
                          'ID:${user.uid.toString()}',
                          style: DefaultStyle.gray12,
                        ),
                      )
                    ],
                  ),
                  SizedBox(height: 6.w),
                  SetUserMark(map: (user.maker ?? {}), vipLevel: user.vipLevel),
                ],
              ),
            ),
          ),
          GestureDetector(
            onTap: () {
              if (user.isReg == 1) {
                context.push("/${Routes.personalInfo}");
              } else {
                // Method.showText('请先设置暧昧号');
                context.push("/${Routes.setPwd}");
              }
            },
            child: Container(
              padding: EdgeInsets.only(right: 10.w),
              child: Image.asset(
                "assets/images/personal_center/ic_edit.png",
                width: ScreenUtil().setWidth(20.0),
                height: ScreenUtil().setWidth(20.0),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// 设置标记
/// "is_up": 1,//up视频上传认证
/// "is_live": 1,//裸聊主播认证
/// "is_lfeng": 1,//楼凤认证
/// "is_jjren": 1,//经纪人认证
/// "is_face": 1,//官方视频本人身份认证}
class SetUserMark extends StatelessWidget {
  final Map? map;
  final int vipLevel;
  const SetUserMark({Key? key, this.map, this.vipLevel = 0}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // var subscript = map.map((key, value) => null);
    var subscript = {};
    if (map != null) {
      subscript =
          Map.fromEntries(map!.entries.where((element) => element.value > 0));
    }
    if (vipLevel > 0) {
      subscript['is_vip'] = vipLevel;
    }
    List<Widget> tempList = [];
    if (subscript.isNotEmpty) {
      subscript.forEach((key, value) {
        String tempUrl;
        switch (key) {
          case 'is_up':
            tempUrl = 'assets/images/common/grade_up.png';
            break;
          case 'is_live':
            tempUrl = 'assets/images/common/grade_chat.png';
            break;
          case 'is_lfeng':
            tempUrl = 'assets/images/common/grade_girl.png';
            break;
          case 'is_jjren':
            tempUrl = 'assets/images/common/grade_agent.png';
            break;
          // case 'is_face':
          //   tempUrl = 'assets/images/common/grade_vip.png';
          //   break;
          case 'is_vip':
            tempUrl = 'assets/images/common/grade_vip.png';
            break;
          default:
            tempUrl = '';
        }
        if (tempUrl.isNotEmpty) {
          tempList.add(
            Padding(
              padding: EdgeInsets.only(top: 5.0.w, right: 5.0.w),
              child: Image.asset(tempUrl, height: 14.0.w),
            ),
          );
        }
      });
    }
    return Row(children: tempList);
  }
}

/// 统计列表盒子
/// [statisticsItem]统计列表项
class StatisticsBox extends StatelessWidget {
  const StatisticsBox({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var user = Provider.of<UserData>(context, listen: false).userInfo;
    Widget statisticsItem({
      required int value,
      required text,
      int statisticsNum = 0,
      Function? onTap,
    }) {
      Widget tempMark = Container();
      if (statisticsNum > 0) {
        tempMark = Row(
          children: [
            Container(
              width: 6,
              height: 6,
              decoration: const BoxDecoration(
                border: Border(
                  top: BorderSide(
                    color: Colors.transparent,
                    width: 3,
                    style: BorderStyle.solid,
                  ),
                  right: BorderSide(
                    color: Color.fromRGBO(255, 0, 179, .25),
                    width: 3,
                    style: BorderStyle.solid,
                  ),
                  bottom: BorderSide(
                    color: Colors.transparent,
                    width: 3,
                    style: BorderStyle.solid,
                  ),
                  left: BorderSide(
                    color: Colors.transparent,
                    width: 3,
                    style: BorderStyle.solid,
                  ),
                ),
              ),
            ),
            RedGlassmorphoismBox(
              borderRadius: BorderRadius.all(
                Radius.circular(
                  ScreenUtil().setWidth(1.25),
                ),
              ),
              child: Container(
                padding: EdgeInsets.symmetric(
                  horizontal: ScreenUtil().setWidth(3.725),
                ),
                child: Text(
                  statisticsNum.toString(),
                  style: DefaultStyle.white10,
                ),
              ),
            ),
          ],
        );
      }
      return GestureDetector(
        onTap: () {
          onTap!();
        },
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text(
                  value.toString(),
                  style: DefaultStyle.white18,
                ),
                tempMark,
              ],
            ),
            SizedBox(height: 4.w),
            Container(
              padding: EdgeInsets.only(
                top: ScreenUtil().setWidth(2.5),
              ),
              child: Text(
                text.toString(),
                style: DefaultStyle.gray12,
              ),
            ),
          ],
        ),
      );
    }

    return Flex(
      direction: Axis.horizontal,
      children: [
        Expanded(
          flex: 1,
          child: statisticsItem(
            statisticsNum: 0,
            value: user.fansCount ?? 0,
            text: "粉丝",
            onTap: () {
              context.push("/fansFollowClub/${0}");
            },
          ),
        ),
        Expanded(
          flex: 1,
          child: statisticsItem(
            statisticsNum: 0,
            value: user.followedCount ?? 0,
            text: "关注",
            onTap: () {
              context.push("/fansFollowClub/${1}");
            },
          ),
        ),
        Expanded(
          flex: 1,
          child: statisticsItem(
            statisticsNum: 0,
            value: user.club != null ? user.club["count"] : 0,
            text: "粉丝团",
            onTap: () {
              context.push("/fansFollowClub/${2}");
            },
          ),
        ),
      ],
    );
  }
}

/// 广告盒子
class AdBox extends StatelessWidget {
  const AdBox({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var user = Provider.of<UserData>(context, listen: false).userInfo;
    return FrostedGlassBox(
      margin: EdgeInsets.symmetric(horizontal: DimenRes.dimen_15),
      child: BannerWidget(
        adList: user.ads,
        height: 108.w,
        scrollDirection: Axis.vertical,
        margin: EdgeInsets.all(10.w),
        radius: BorderRadius.circular(12),
      ),
    );
  }
}
