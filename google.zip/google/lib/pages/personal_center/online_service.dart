import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:iaimei/components/common/avatar.dart';
import 'package:iaimei/components/common/glassmorphism.dart';
import 'package:iaimei/components/common/head.dart';
import 'package:iaimei/components/common/pagestatus.dart';
import 'package:iaimei/components/common/pullrefreshlist.dart';
import 'package:iaimei/components/common/stackpage.dart';
import 'package:iaimei/model/basic.dart';
import 'package:iaimei/model/user_info_model.dart';
import 'package:iaimei/model/model_online_list.dart';
import 'package:iaimei/pages/creator/upload_picker_mixin.dart';
import 'package:iaimei/store/userdata.dart';
import 'package:iaimei/theme/default.dart';
import 'package:iaimei/utils/api.dart';
import 'package:iaimei/utils/common.dart';
import 'package:iaimei/utils/networkimage.dart';
import 'package:iaimei/utils/string_util.dart';
import 'package:iaimei/widget/convenient_mixin.dart';
import 'package:iaimei/widget/network_img_container.dart';
import 'package:provider/provider.dart';

/// 在线客服
class OnlineService extends StatefulWidget {
  const OnlineService({Key? key}) : super(key: key);

  @override
  State<OnlineService> createState() => _OnlineServiceState();
}

class _OnlineServiceState extends State<OnlineService>
    with ConvenientMixin, UploadPickerMixin {
  TextEditingController textEditingController =
      TextEditingController(); // 文本框控制器
  bool _loading = true;
  int _page = 1;
  final int _limit = 10;
  bool _isAll = false;
  List<Datum> _list = [];

  /// 请求列表
  Future<void> getData() async {
    if (_isAll) return;
    ModelOnlineList? res = await apiOnlineList(
      page: _page,
      limit: _limit,
    );
    if (res?.status == 1) {
      List<Datum> tempData = res?.data ?? [];
      if (_page == 1) {
        _list = tempData;
      } else {
        _list.addAll(tempData);
      }
      if (tempData.length < _limit) {
        _isAll = true;
      } else {
        _isAll = false;
      }
    }
  }

  /// 初始化列表
  Future<void> initData() async {
    setState(() {
      _loading = true;
    });
    await getData();
    setState(() {
      _loading = false;
    });
  }

  /// 提交
  /// [content]文字
  /// [thumb]图片
  Future<void> onSubmit({
    String? content,
    String? thumb,
  }) async {
    Basic? res = await apiOnlineSubmit(
      content: content,
      thumb: thumb,
    );
    if (res?.status == 1) {
      _page = 1;
      _isAll = false;
      textEditingController.clear();
      initData();
      Method.showText("${res?.data["msg"]}");
    } else {
      Method.showText("${res?.msg}");
    }
  }

  /// 提交文字
  Future<void> handleSubmitText() async {
    String tempText = textEditingController.text.trim();
    if (tempText == '') {
      return Method.showText("文本框不能为空");
    }
    await onSubmit(content: tempText);
  }

  /// 提交图片
  Future<void> handleSubmitThumb(String thumb) async {
    String tempThumb = thumb.trim();
    if (tempThumb == '') {
      return Method.showText("图片不能为空");
    }
    await onSubmit(thumb: tempThumb);
  }

  @override
  void initState() {
    super.initState();

    actionSize = const Size(24, 22);
    commonInitUploadCallback();
    // 上传图片
    singleObjectCallback = () {
      if (imagePathMap.isEmpty) {
        debugPrint('出现错误了...');
        return;
      }
      var obj = imagePathMap.values.first;
      handleSubmitThumb(obj["url"].toString());
    };
    // 初始化列表
    initData();
  }

  @override
  void dispose() {
    textEditingController.dispose();
    super.dispose();
  }

  /// 底部输入行
  Widget activeBottom() {
    return Container(
      padding: EdgeInsets.only(
        top: ScreenUtil().setWidth(10.0),
        right: ScreenUtil().setWidth(15.0),
        bottom: ScreenUtil().setWidth(30.0),
        left: ScreenUtil().setWidth(15.0),
      ),
      decoration: const BoxDecoration(
        color: Color.fromRGBO(36, 30, 59, 1),
      ),
      child: Flex(
        direction: Axis.horizontal,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          GestureDetector(
            onTap: () => showImageAssets(),
            child: SizedBox(
              width: ScreenUtil().setWidth(24.0),
              height: ScreenUtil().setWidth(22.0),
              child: Stack(
                children: [
                  Image.asset(
                    "assets/images/common/add_photo.png",
                    width: ScreenUtil().setWidth(24.0),
                    height: ScreenUtil().setWidth(22.0),
                  ),
                ],
              ),
            ),
          ),
          Expanded(
            flex: 1,
            child: Container(
              alignment: Alignment.centerLeft,
              height: ScreenUtil().setWidth(32.0),
              margin: EdgeInsets.symmetric(
                horizontal: ScreenUtil().setWidth(10.0),
              ),
              padding: EdgeInsets.symmetric(
                horizontal: ScreenUtil().setWidth(10.0),
              ),
              decoration: BoxDecoration(
                color: const Color.fromRGBO(255, 255, 255, .1),
                borderRadius: BorderRadius.circular(
                  ScreenUtil().setWidth(16.0),
                ),
              ),
              child: TextField(
                autofocus: false,
                controller: textEditingController,
                style: DefaultStyle.white12,
                textInputAction: TextInputAction.done,
                decoration: InputDecoration(
                  hintText: '请详细描述您遇到的问题！',
                  hintStyle: DefaultStyle.gray12,
                  contentPadding: EdgeInsets.zero,
                  disabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(30.0),
                    borderSide: const BorderSide(
                      color: Colors.transparent,
                      width: 0,
                    ),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(30.0),
                    borderSide: const BorderSide(
                      color: Colors.transparent,
                      width: 0,
                    ),
                  ),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(30.0),
                    borderSide: const BorderSide(
                      color: Colors.transparent,
                      width: 0,
                    ),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(30.0),
                    borderSide: const BorderSide(
                      color: Colors.transparent,
                      width: 0,
                    ),
                  ),
                ),
              ),
            ),
          ),
          GestureDetector(
            onTap: handleSubmitText,
            child: RedGlassmorphoismBox(
              width: ScreenUtil().setWidth(64.0),
              height: ScreenUtil().setWidth(30.0),
              child: Text(
                '发送',
                style: DefaultStyle.white12,
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return StackPage(
      header: const HeadBack(
        leftText: '在线客服',
      ),
      child: Flex(
        direction: Axis.vertical,
        children: [
          Expanded(
            flex: 1,
            child: _buildInit(),
          ),
          activeBottom(),
        ],
      ),
    );
  }

  /// 初始化构建
  Widget _buildInit() {
    if (_loading) {
      return PageStatus.loading(_loading);
    }
    return PullRefreshList(
      onRefresh: () {
        if (!_isAll) {
          _page++;
          getData();
        }
      },
      onLoading: () {
        // _isAll = false;
        // _page = 1;
        // initData();
      },
      child: ListView.builder(
        itemCount: _list.length,
        itemBuilder: (
          BuildContext context,
          int index,
        ) {
          return ListItem(
            item: _list[index],
          );
        },
      ),
    );
  }
}

/// 列表项
class ListItem extends StatelessWidget {
  final Datum item;
  const ListItem({
    Key? key,
    required this.item,
  }) : super(key: key);

  Widget avatarBox(String text) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: ScreenUtil().setWidth(10.0),
      ),
      child: Avatar(
        width: ScreenUtil().setWidth(36.0),
        height: ScreenUtil().setWidth(36.0),
        borderRadius: BorderRadius.all(
          Radius.circular(
            ScreenUtil().setWidth(18.0),
          ),
        ),
        url: text,
      ),
    );
  }

  Widget textBox(String text) {
    return Container(
      constraints: BoxConstraints(
        maxWidth: ScreenUtil().screenWidth / 2,
      ),
      padding: EdgeInsets.symmetric(
        vertical: ScreenUtil().setWidth(10.0),
        horizontal: ScreenUtil().setWidth(15.0),
      ),
      decoration: BoxDecoration(
        color: const Color.fromRGBO(255, 255, 255, 0.08),
        borderRadius: BorderRadius.all(Radius.circular(
          ScreenUtil().setWidth(12.0),
        )),
      ),
      child: Text(
        text,
        style: TextStyle(
          color: DefaultStyle.colorWhite,
          fontSize: ScreenUtil().setSp(12),
          decoration: TextDecoration.none,
        ),
      ),
    );
  }

  Widget imgBox(
    BuildContext context, {
    String url = "",
  }) {
    return ClipRRect(
      borderRadius: BorderRadius.all(
        Radius.circular(
          ScreenUtil().setWidth(12.0),
        ),
      ),
      child: GestureDetector(
        onTap: () {
          showDialog(
            context: context,
            builder: (BuildContext context) {
              return AlertDialog(
                backgroundColor: Colors.transparent,
                content: GestureDetector(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: SizedBox(
                    width: ScreenUtil().screenWidth,
                    height: ScreenUtil().screenHeight,
                    child: NetworkImgContainer(
                      fit: BoxFit.contain,
                      url: url,
                    ),
                  ),
                ),
              );
            },
          );
        },
        child: NetworkImgContainer(
            width: ScreenUtil().screenWidth / 2,
            height: ScreenUtil().setWidth(120),
            url: url,
        ),
      ),
    );
  }

  Widget headerBox() {
    if (item.addtimeStr!.isNotEmpty) {
      return Container(
        padding: EdgeInsets.only(
          top: ScreenUtil().setWidth(20.0),
        ),
        child: Text(
          item.addtimeStr.toString(),
          style: TextStyle(
            color: const Color.fromRGBO(255, 255, 255, 0.36),
            fontSize: ScreenUtil().setSp(12.0),
          ),
        ),
      );
    }
    return Container();
  }

  Widget rightBox(BuildContext context) {
    var userData = Provider.of<UserData>(context).userInfo;
    Widget tempContent;
    if (StringUtil.isNotEmpty(item.content)) {
      tempContent = textBox(item.content.toString());
    } else {
      tempContent = imgBox(
        context,
        url: item.thumbFull.toString(),
      );
    }
    return Padding(
      padding: EdgeInsets.only(
        top: ScreenUtil().setWidth(20.0),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          tempContent,
          avatarBox(userData.avatarUrl.toString()),
        ],
      ),
    );
  }

  Widget leftBox() {
    Widget tempWidget = Container();
    if (item.replyContent != null) {
      tempWidget = Padding(
        padding: EdgeInsets.only(
          top: ScreenUtil().setWidth(15.0),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            avatarBox(''),
            textBox(item.replyContent.toString()),
          ],
        ),
      );
    }
    return tempWidget;
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScopeNode currentFocus = FocusScope.of(context);
        if (!currentFocus.hasPrimaryFocus &&
            currentFocus.focusedChild != null) {
          /// 取消焦点，相当于关闭键盘
          FocusManager.instance.primaryFocus?.unfocus();
        }
      },
      child: Column(
        children: [
          headerBox(),
          rightBox(context),
          leftBox(),
        ],
      ),
    );
  }
}
