import 'package:bot_toast/bot_toast.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:iaimei/components/common/commonelements.dart';
import 'package:iaimei/components/common/glassmorphism.dart';
import 'package:iaimei/components/common/head.dart';
import 'package:iaimei/components/common/pullrefreshlist.dart';
import 'package:iaimei/components/common/stackpage.dart';
import 'package:iaimei/model/basic.dart';
import 'package:iaimei/theme/default.dart';
import 'package:iaimei/utils/api.dart';
import 'package:iaimei/widget/buttom_widget.dart';
import 'package:iaimei/widget/convenient_mixin.dart';

class MsgBoard extends StatefulWidget {
  const MsgBoard({Key? key}) : super(key: key);

  @override
  State<MsgBoard> createState() => _MsgBoardState();
}

class _MsgBoardState extends State<MsgBoard>
    with TickerProviderStateMixin, ConvenientMixin {
  bool loading = true; // 加载中状态
  TextEditingController textEditingController =
      TextEditingController(); // 文本框控制器

  /// 提交
  void submit() async {
    String tempContent = textEditingController.text.trim();
    if (tempContent == '') {
      BotToast.showText(text: "留言内容不能为空");
      return;
    }
    Basic? res = await apiMsgBoard(
      content: tempContent,
    );
    if (res?.status == 1) {
      BotToast.showText(text: res?.data);
      textEditingController.clear();
    }
  }

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    textEditingController.dispose();
    super.dispose();
  }

  /// 描述文本框
  Widget textField() {
    return TextField(
      maxLines: 5,
      maxLength: 200,
      autofocus: false,
      cursorColor: rColor,
      controller: textEditingController,
      style: TextStyle(color: wColor, fontSize: 12.w, height: 1.5),
      textInputAction: TextInputAction.done,
      keyboardType: TextInputType.multiline,
      decoration: InputDecoration(
        contentPadding: EdgeInsets.all(10.w),
        hintText: '强大的原创团队，时刻等候陛下的指令',
        hintStyle: TextStyle(color: const Color(0xa3ffffff), fontSize: 12.w),
        border: InputBorder.none,
        counterStyle: TextStyle(color: wColor, fontSize: 12.w),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScopeNode currentFocus = FocusScope.of(context);
        if (!currentFocus.hasPrimaryFocus &&
            currentFocus.focusedChild != null) {
          /// 取消焦点，相当于关闭键盘
          FocusManager.instance.primaryFocus?.unfocus();
        }
      },
      child: StackPage(
        header: const CustomHeader(title: '建议意见'),
        // child: PullRefreshList(
        child: Column(
          children: [
            Container(
                margin: EdgeInsets.fromLTRB(16.w, 10.w, 16.w, 0),
                child: Text(
                  '您对暧昧APP有任何想法、建议、意见都可以畅所欲言哦！\n会直接发送至运营总监！但是如果不是建议意见或恶意发文将会封号哦！',
                  style:
                      TextStyle(color: color_84, fontSize: 12.w, height: 1.7),
                )),
            SizedBox(height: 20.w),
            Container(
              margin: EdgeInsets.symmetric(horizontal: 16.w),
              padding: EdgeInsets.all(10.w),
              decoration: BoxDecoration(
                color: const Color(0x1fb2aaff),
                borderRadius: BorderRadius.circular(12.w),
                border: Border.all(color: const Color(0x0dffffff), width: 0.5),
              ),
              child: Container(
                padding: EdgeInsets.only(bottom: 10.w), // 底部限制字数
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(6.w),
                  color: const Color.fromRGBO(0, 0, 0, 0.12),
                ),
                child: textField(),
              ),
            ),
            SizedBox(height: 100.w),
            ButtonWidget.build('提交', onTap: submit),
          ],
        ),
        // ),
      ),
    );
  }
}
