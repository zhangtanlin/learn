import 'dart:async';
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:iaimei/components/common/commonelements.dart';
import 'package:iaimei/components/common/pageviewmixin.dart';
import 'package:iaimei/components/common/pullrefreshlist.dart';
import 'package:iaimei/components/common/scale_pageroute.dart';
import 'package:iaimei/components/common/stackpage.dart';
import 'package:iaimei/model/video_model.dart';
import 'package:iaimei/pages/mv/mv_local_play.dart';
import 'package:iaimei/pages/mv/nav_tab_bar_mixin.dart';
import 'package:iaimei/utils/common.dart';
import 'package:iaimei/utils/download_video.dart';
import 'package:iaimei/utils/eventbus_util.dart';
import 'package:iaimei/widget/convenient_mixin.dart';
import 'package:iaimei/widget/network_img_container.dart';
import 'package:iaimei/widget/state_mixin.dart';

class CacheHistory extends StatefulWidget {
  const CacheHistory({Key? key, this.index = 0}) : super(key: key);
  final int index;
  @override
  State<CacheHistory> createState() => _CacheHistoryState();
}

class _CacheHistoryState extends State<CacheHistory>
    with TickerProviderStateMixin, ConvenientMixin {
  int selectedIndex = 0;
  late TabController tabController;
  List<String> items = ['视频', '图集'];
  @override
  void initState() {
    super.initState();

    selectedIndex = widget.index;
    if (selectedIndex >= items.length) {
      selectedIndex = 0;
    }

    tabController = TabController(
      length: items.length,
      vsync: this,
      initialIndex: selectedIndex,
    );
  }

  @override
  Widget build(BuildContext context) {
    return StackPage(
      header: const CustomHeader(title: '下载缓存'),
      child: Column(
        children: [
          Align(alignment: Alignment.centerLeft, child: _buildTabBarWidget()),
          Container(color: Colors.white24, width: 343.w, height: 0.5),
          Expanded(child: _buildTabBarViewWidget()),
        ],
      ),
    );
  }

  Widget _buildTabBarWidget() {
    return NavTabBarWidget(
      tabVc: tabController,
      tabs: items,
      textPadding: EdgeInsets.symmetric(horizontal: 15.w),
      norTextStyle: TextStyle(
          color: wColor, fontSize: 14.sp, fontWeight: FontWeight.w400),
      selTextStyle:
          TextStyle(color: rColor, fontSize: 14.sp, fontWeight: fontM),
    );
  }

  Widget _buildTabBarViewWidget() {
    return TabBarView(
      controller: tabController,
      children: items
          .asMap()
          .keys
          .map<Widget>(
              (index) => PageViewMixin(child: CacheHistoryList(index: index)))
          .toList(),
    );
  }
}

class CacheHistoryList extends StatefulWidget {
  const CacheHistoryList({Key? key, this.index = 0}) : super(key: key);
  final int index;
  @override
  State<CacheHistoryList> createState() => _CacheHistoryListState();
}

class _CacheHistoryListState extends State<CacheHistoryList>
    with ConvenientMixin, StateMixin {
  late StreamSubscription<DownloadEvent>? _configChangeSubscription;

  @override
  void initLoadingData() async {
    List list = [];
    switch (widget.index) {
      case 0:
        list = await DownloadUtil.readCacheHistory(CacheKey.video);
        break;
      case 1:
        list = await DownloadUtil.readCacheHistory(CacheKey.image);
        break;
      default:
    }
    updateListAndWidgetState(list);
  }

  @override
  void dispose() {
    if (_configChangeSubscription != null) {
      _configChangeSubscription!.cancel();
    }
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    _configChangeSubscription = EventBusUtil.listen((event) {
      if (event.type == CacheKey.video) {
        for (var item in dataList) {
          if (item['id'] == event.obj['id']) {
            item['progress'] = event.obj['progress'];
            item['downloading'] = event.obj['downloading'];
            break;
          }
        }
        setState(() {});
      } else {
        setState(() {});
      }
    });
  }

  @override
  Widget noDataWidget() {
    return buildDataWidget(
      icon: 'assets/images/common/ic_load_error.png',
      content: '暂无数据',
      tipHidden: true,
    );
  }

  @override
  Widget build(BuildContext context) {
    if (widgetState != WidgetState.finish &&
        widgetState != WidgetState.noData) {
      return placeholderWidget();
    }

    return PullRefreshList(
      isAll: true,
      onRefresh: onRefresh,
      child: SingleChildScrollView(
        child: ListView.builder(
          itemCount: dataList.length,
          padding: EdgeInsets.fromLTRB(16.w, 0, 16.w, 20.w),
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemBuilder: ((context, index) {
            return Padding(
              padding: EdgeInsets.only(top: 15.w),
              child: GestureDetector(
                behavior: HitTestBehavior.translucent,
                onTap: () => onPalyer(dataList[index]),
                child: _buildVideoWidget(dataList[index]),
              ),
            );
          }),
        ),
      ),
    );
  }

  void onPalyer(Map item) {
    if (item['progress'].toDouble() != 1) {
      Method.showText('未下载完成...');
      return;
    }
    /** 
      * taskInfo数据结构:
      * id              视频id
      * urlPath         下载地址（需解密）
      * title           视频标题
      * thumbCover      视频封面
      * date             
      * tags            视频标签
      * contentType     视频类型
      * downloading     视频下载状态 bool
      * isWaiting       是否在下载队列中 bool
      * url             视频m3u8储存地址
      * tsLists         视频ts链接队列
      * localM3u8       本地m3u8文件 string
      * tsListsFinished 已下载完成的ts队列
      * progress        视频下载进度
      */
    var videoModel = VideoModel()
      ..id = int.parse(item['id'])
      ..title = item['title']
      ..coverThumbUrl = item['thumbCover']
      ..playUrl = item['url']
      ..payUrlFull = item['url'];

    Navigator.push(
      context,
      ScalePageRoute(
        widget: LocalShortMvPlayerWidget(data: videoModel, isLocal: true),
        // widget: item['contentType'] == 1
        //     ? LocalLongMvPlayerWidget(data: videoModel, isLocal: true)
        //     : LocalShortMvPlayerWidget(data: videoModel, isLocal: true),
      ),
    );
  }

  Widget _buildVideoWidget(Map item) {
    Widget _buildBottomWidget(Map item) {
      try {
        double progress = item['progress'].toDouble();
        switch (progress.toInt()) {
          case 1:
            return Text(
              item['date'] ?? '~',
              style: TextStyle(color: color_64, fontSize: 12.sp),
            );
          case -1:
            return GestureDetector(
              onTap: () {
                DownloadUtil.createDownloadTask(item);
                initLoadingData();
              },
              child: Text(
                item['下载失败，重新下载'],
                style: TextStyle(color: rColor, fontSize: 12.sp),
              ),
            );
          default:
            return _buildProgressBar(item, progress); //
        }
      } catch (e) {
        return Container();
      }
    }

    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildGaussianWidget(160.w, 90.w, 6.w, item['thumbCover']),
        SizedBox(width: 10.w),
        Expanded(
          child: SizedBox(
            height: 90.w,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  item['title'] ?? '~',
                  style: TextStyle(color: wColor, fontSize: 14.sp),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                _buildBottomWidget(item),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildProgressBar(Map item, dynamic progress) {
    return Column(
      children: [
        Container(
          height: 3.w,
          width: 175.w,
          decoration: BoxDecoration(
              color: Colors.white24,
              borderRadius: BorderRadius.all(Radius.circular(1.5.w))),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Container(
                height: 3.w,
                width: 175.w * progress,
                decoration: BoxDecoration(
                  color: rColor,
                  borderRadius: BorderRadius.all(Radius.circular(1.5.w)),
                ),
              ),
            ],
          ),
        ),
        SizedBox(
          height: 28.w,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              GestureDetector(
                onTap: () {
                  if (item['isWaiting'] == true) return;
                  item['downloading'] == true
                      ? DownloadUtil.removeTask(item['id'])
                      : DownloadUtil.createDownloadTask(item);
                  initLoadingData(); // 重新获取
                },
                child: Text(
                  item['downloading'] == true
                      ? '暂停'
                      : item['isWaiting'] == true
                          ? '等待'
                          : '继续',
                  style: TextStyle(
                      color: rColor, fontSize: 13.sp, fontWeight: fontM),
                ),
              ),
              Text('${(progress * 100).toInt()}%',
                  style: TextStyle(color: wColor, fontSize: 12.sp)),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildGaussianWidget(width, height, radii, url) {
    return SizedBox(
      height: height,
      width: width,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(radii),
        child: Stack(
          children: [
            // 约束性盒子
            ConstrainedBox(
              constraints: const BoxConstraints.expand(),
              child: NetworkImgContainer(url: url, fit: BoxFit.cover),
            ),
            // 背景过滤器
            BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 5.0, sigmaY: 5.0),
              child: Opacity(
                opacity: 0.2,
                child: Container(color: Colors.black),
              ),
            ),
            // 原图显示
            NetworkImgContainer(url: url, fit: BoxFit.contain)
          ],
        ),
      ),
    );
  }
}
