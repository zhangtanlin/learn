import 'package:bot_toast/bot_toast.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:iaimei/components/common/base_dialog.dart';
import 'package:iaimei/components/common/head.dart';
import 'package:iaimei/components/common/pullrefreshlist.dart';
import 'package:iaimei/components/common/stackpage.dart';
import 'package:iaimei/model/basic.dart';
import 'package:iaimei/store/userdata.dart';
import 'package:iaimei/theme/default.dart';
import 'package:iaimei/utils/api.dart';
import 'package:iaimei/utils/string_util.dart';
import 'package:iaimei/widget/buttom_widget.dart';
import 'package:provider/provider.dart';

/// 设置昵称
class SetNickname extends StatefulWidget {
  const SetNickname({Key? key}) : super(key: key);

  @override
  State<SetNickname> createState() => _SetNicknameState();
}

class _SetNicknameState extends State<SetNickname>
    with TickerProviderStateMixin {
  // 提交处理中
  bool isSubmit = true;
  // 昵称文本框控制器
  TextEditingController nicknameController = TextEditingController();

  /// 提交
  void handleSubmit() async {
    String tempNickname = nicknameController.text.trim();
    if (tempNickname == '') {
      BaseDialog.toast(text: '昵称不能为空');
      return;
    }
    if (StringUtil.stringLength(tempNickname) > 12) {
      BaseDialog.toast(text: '昵称最多为6个汉字或者12个英文字母');
      return;
    }
    if (!isSubmit) {
      BotToast.showText(text: "处理中...");
      return;
    }
    isSubmit = false;
    Basic? res = await apiSetBaseInfo(nickname: tempNickname);
    if (res?.status == 1) {
      BotToast.showText(text: res?.data ?? '设置成功');
    }
    isSubmit = true;
    nicknameController.clear();
    setState(() {
      Provider.of<UserData>(context, listen: false).setNickname(tempNickname);
      // EventBusUtil.fire(UserInfoEvent(true));
    });
  }

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    nicknameController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    var userData = Provider.of<UserData>(context, listen: false).userInfo;
    return GestureDetector(
      onTap: () {
        FocusScopeNode currentFocus = FocusScope.of(context);
        if (!currentFocus.hasPrimaryFocus &&
            currentFocus.focusedChild != null) {
          /// 取消焦点，相当于关闭键盘
          FocusManager.instance.primaryFocus?.unfocus();
        }
      },
      child: StackPage(
        header: const HeadBack(
          leftText: '修改昵称',
        ),
        child: PullRefreshList(
          onRefresh: () {},
          child: Padding(
            padding: EdgeInsets.symmetric(
              horizontal: DefaultStyle.pagePadding,
            ),
            child: Column(
              children: [
                Container(
                  alignment: Alignment.topLeft,
                  padding: EdgeInsets.only(top: 10.w, bottom: 10.w),
                  child: Text.rich(
                      TextSpan(children: [
                        const TextSpan(
                            text: '当前昵称：',
                            style: TextStyle(color: Color(0xa3ffffff))),
                        TextSpan(
                            text: '${userData.nickname}',
                            style: const TextStyle(color: Colors.white))
                      ]),
                      style: TextStyle(fontSize: 14.sp)),
                ),
                Container(
                  height: 54.w,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12.w),
                    color: const Color.fromRGBO(202, 116, 255, 0.08),
                  ),
                  child: TextField(
                    cursorColor: const Color(0xffFF00B3),
                    controller: nicknameController,
                    style: TextStyle(color: Colors.white, fontSize: 14.sp),
                    textAlign: TextAlign.center,
                    decoration: InputDecoration(
                      contentPadding: EdgeInsets.all(10.w),
                      hintStyle: TextStyle(
                          color: const Color(0xa3ffffff), fontSize: 13.sp),
                      hintText: '请输入昵称（最多8个汉字）',
                      border: InputBorder.none,
                    ),
                  ),
                ),
                SizedBox(height: 100.w),
                ButtonWidget.build('确定', onTap: handleSubmit),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
