import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:iaimei/components/common/head.dart';
import 'package:iaimei/components/common/pagestatus.dart';
import 'package:iaimei/components/common/stackpage.dart';
import 'package:iaimei/components/tab/tab_collect_buy.dart';
import 'package:iaimei/pages/mv/nav_tab_bar_mixin.dart';
import 'package:iaimei/widget/tab_bar_view_ext.dart';

/// 我的收藏/我的购买
/// [type]类型{1: 我的收藏,2:我的购买}
class CollectBuy extends StatefulWidget {
  final int type;
  const CollectBuy({
    Key? key,
    required this.type,
  }) : super(key: key);

  @override
  State<CollectBuy> createState() => _CollectBuyState();
}

class _CollectBuyState extends State<CollectBuy> with TickerProviderStateMixin {
  // 加载中
  bool loading = true;
  // 选项卡控制器啊
  late TabController tabController;
  // 头部选项卡
  List tabs = [
    {
      "name": '收藏',
      "children": [
        {
          "id": 1,
          "name": "视频",
        },
        {
          "id": 2,
          "name": "漫画",
        },
        {
          "id": 3,
          "name": "小说",
        },
        {
          "id": 4,
          "name": "裸聊",
        },
        {
          "id": 5,
          "name": "约炮",
        },
        {
          "id": 6,
          "name": "图集",
        },
      ],
    },
    {
      "name": '购买',
      "children": [
        {
          "id": 1,
          "name": "视频",
        },
        {
          "id": 7,
          "name": "合集",
        },
        {
          "id": 2,
          "name": "漫画",
        },
        {
          "id": 3,
          "name": "小说",
        },
        {
          "id": 4,
          "name": "裸聊",
        },
        {
          "id": 5,
          "name": "约炮",
        },
        {
          "id": 6,
          "name": "图集",
        },
      ],
    },
  ];
  int tabIndexCurrent = 0;

  /// 请求初始化
  void initData() {
    tabController = TabController(
      initialIndex: tabIndexCurrent,
      length: tabs.length,
      vsync: this,
    );
    tabController.addListener(() {
      setState(() => tabIndexCurrent = tabController.index);
    });
    setState(() => loading = false);
  }

  @override
  void initState() {
    super.initState();
    initData();
  }

  @override
  void dispose() {
    tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return _buildInit();
  }

  /// 构建初始化
  Widget _buildInit() {
    if (loading) {
      return PageStatus.loading(loading);
    }
    return StackPage(
      header: HeadBack(
        leftText: '',
        center: Row(
          children: [
            NavTabBarWidget(
              tabVc: tabController,
              tabs: tabs.map<String>((item) => item['name']).toList(),
              textPadding: EdgeInsets.symmetric(horizontal: 15.w),
              norTextStyle: TextStyle(
                  color: Colors.white,
                  fontSize: 14.sp,
                  fontWeight: FontWeight.w400),
              selTextStyle: TextStyle(
                  color: const Color(0xffff00b3),
                  fontSize: 18.sp,
                  fontWeight: FontWeight.w600),
              selectedIndex: tabIndexCurrent,
            )
          ],
        ),
        right: SizedBox(
          width: ScreenUtil().setWidth(15.0),
        ),
      ),
      child: TabBarViewExt(
        controller: tabController,
        children: [
          for (var i = 0; i < tabs.length; i++) ...[
            TabCollectBuy(
              type: i,
              tabs: tabs[i]['children'],
            ),
          ]
        ],
      ),
    );
  }
}
