import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:iaimei/components/common/base_dialog.dart';
import 'package:iaimei/components/common/commonelements.dart';
import 'package:iaimei/components/common/pagestatus.dart';
import 'package:iaimei/components/common/pullrefreshlist.dart';
import 'package:iaimei/components/common/stackpage.dart';
import 'package:iaimei/model/model_contact.dart';
import 'package:iaimei/utils/api.dart';
import 'package:iaimei/utils/common.dart';
import 'package:iaimei/widget/buttom_widget.dart';
import 'package:iaimei/widget/network_img_container.dart';

/// 联系官方
class Contact extends StatefulWidget {
  const Contact({Key? key}) : super(key: key);

  @override
  State<Contact> createState() => _ContactState();
}

class _ContactState extends State<Contact> {
  // 加载中
  bool loading = true;
  // 信息
  List<DataList>? data = [];

  void getData() async {
    ModelContact? res = await apiContact();
    if (res?.status == 1) {
      data = res?.data?.list;
      loading = false;
      setState(() {});
    }
  }

  @override
  void initState() {
    super.initState();
    getData();
  }

  @override
  void dispose() {
    super.dispose();
  }

  Widget init() {
    if (loading) {
      return PageStatus.loading(true);
    }
    if (data!.isEmpty) {
      return PageStatus.noData();
    }
    return PullRefreshList(
      child: ListView.builder(
        itemCount: data!.length,
        padding: EdgeInsets.only(top: 10.w),
        itemBuilder: (BuildContext context, int index) {
          return _buildItemWidgt(data![index]);
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return StackPage(
      header: const CustomHeader(title: '联系官方'),
      child: init(),
    );
  }

  Widget contactInfoItem(DataList item,
      {ListList? childItem, hidBottomLine = false}) {
    Border tempBootmLine = const Border(
      bottom: BorderSide(
        width: 0,
        color: Color.fromRGBO(255, 255, 255, 0.12),
      ),
    );
    if (hidBottomLine) {
      tempBootmLine = const Border();
    }
    return GestureDetector(
      onTap: () {
        if (childItem != null && childItem.url != null) {
          Method.launchURL(childItem.url.toString());
        } else {
          BaseDialog.toast(text: '数据错误，请稍后再试');
        }
      },
      child: Flex(
        direction: Axis.horizontal,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.only(top: 15.w),
            child: NetworkImgContainer(
              url: childItem!.iconFull.toString(),
              width: 36.w,
              height: 36.w,
              radius: BorderRadius.circular(12.w),
            ),
          ),
          SizedBox(width: 10.w),
          Expanded(
            child: Container(
              // alignment: Alignment.centerLeft,
              decoration: BoxDecoration(border: tempBootmLine),
              child: Flex(
                direction: Axis.horizontal,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(height: 15.w),
                        Text(
                          childItem.title.toString(),
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 14.sp,
                              fontWeight: FontWeight.w500),
                        ),
                        Text(
                          childItem.text.toString(),
                          style: TextStyle(
                              color: const Color(0xd6ffffff), fontSize: 11.sp),
                        ),
                        SizedBox(height: 5.w),
                        Text(
                          "TG群打不开？看这里",
                          style: TextStyle(
                            color: const Color.fromRGBO(88, 180, 255, 1),
                            fontSize: ScreenUtil().setSp(10.0),
                            overflow: TextOverflow.ellipsis,
                            decoration: TextDecoration.underline,
                          ),
                        ),
                        SizedBox(height: 11.5.w),
                      ],
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(top: 18.w),
                    child: ButtonWidget.bgText(
                      '立即加入',
                      'assets/images/button/btn_small.png',
                      size: Size(68.w, 34.w),
                    ),
                  ),
                  SizedBox(width: 12.w),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildItemWidgt(DataList item) {
    return Padding(
      padding: EdgeInsets.fromLTRB(16.w, 0, 16.w, 20.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            item.title.toString(),
            style: TextStyle(
              color: Colors.white,
              fontSize: 18.sp,
              fontWeight: FontWeight.w500,
            ),
          ),
          Padding(
            padding: EdgeInsets.only(top: 2.w, bottom: 10.w),
            child: Text(
              item.text.toString(),
              style: TextStyle(color: const Color(0xd6ffffff), fontSize: 12.sp),
            ),
          ),
          Container(
            padding: EdgeInsets.only(left: 15.w),
            decoration: BoxDecoration(
              color: const Color(0x1fbc88ff),
              borderRadius: BorderRadius.all(Radius.circular(12.w)),
              border: Border.all(color: const Color(0x0dffffff)),
            ),
            child: Column(
              children: [
                for (var i = 0; i < item.list!.length; i++) ...[
                  contactInfoItem(
                    item,
                    childItem: item.list![i],
                    hidBottomLine: (i == item.list!.length - 1),
                  ),
                ]
              ],
            ),
          ),
        ],
      ),
    );
  }
}
