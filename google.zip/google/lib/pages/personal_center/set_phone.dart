import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:iaimei/components/common/base_dialog.dart';
import 'package:iaimei/components/common/glassmorphism.dart';
import 'package:iaimei/components/common/head.dart';
import 'package:iaimei/components/common/pullrefreshlist.dart';
import 'package:iaimei/components/common/stackpage.dart';
import 'package:iaimei/theme/default.dart';
import 'package:iaimei/utils/printLog.dart';

/// 设置密码
class SetPhone extends StatefulWidget {
  const SetPhone({Key? key}) : super(key: key);

  @override
  State<SetPhone> createState() => _SetPhoneState();
}

class _SetPhoneState extends State<SetPhone> with TickerProviderStateMixin {
  // 是否已发送验证码
  bool isSendCode = false;
  // 按钮上的文字
  String btnText = "获取验证码";
  // 倒计时
  int timerNum = 60;
  // 倒计时定时器
  late Timer timer;
  // 手机号文本框控制器
  TextEditingController phoneController = TextEditingController();
  // 验证码文本框控制器
  TextEditingController codeController = TextEditingController();

  /// 倒计时
  void countdown() {
    timer = Timer.periodic(
      const Duration(
        seconds: 1,
      ),
      (timer) {
        timerNum--;
        if (timerNum <= 0) {
          //取消定时器，避免无限回调
          isSendCode = false;
          btnText = '重新获取';
          timerNum = 60;
          timer.cancel();
        } else {
          isSendCode = true;
          btnText = '${timerNum}S';
        }
        setState(() {});
      },
    );
  }

  /// 发送验证码
  void handleSendCode() {
    PrintUtil.d("手机号提交:${phoneController.text}");
    PrintUtil.d("验证码提交:${codeController.text}");
  }

  /// 提交
  void handleSubmit() {
    if (phoneController.text.trim() == '') {
      BaseDialog.toast(
        text: '手机号不能为空',
      );
      return;
    }
    if (codeController.text.trim() == '') {
      BaseDialog.toast(
        text: '验证码不能为空',
      );
      return;
    }
    PrintUtil.d("手机号提交:${phoneController.text}");
    PrintUtil.d("验证码提交:${codeController.text}");
    setState(() {
      phoneController.clear();
      codeController.clear();
    });
  }

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    phoneController.dispose();
    codeController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return StackPage(
      header: const HeadBack(
        leftText: '绑定手机号',
      ),
      child: PullRefreshList(
        child: Padding(
          padding: EdgeInsets.symmetric(
            horizontal: DefaultStyle.pagePadding,
          ),
          child: Column(
            children: [
              Padding(
                padding: EdgeInsets.only(
                  bottom: ScreenUtil().setWidth(15.0),
                ),
                child: TextField(
                  // 光标颜色
                  cursorColor: const Color(0xffFF00B3),
                  // 文本框控制器
                  controller: phoneController,
                  // 输入文本样式
                  style: TextStyle(
                    color: const Color(0xffffffff),
                    fontSize: ScreenUtil().setSp(14),
                    decoration: TextDecoration.none,
                    height: 1.0, // 行高
                  ),
                  // 文本对齐方式
                  textAlign: TextAlign.center,
                  decoration: InputDecoration(
                    // 如果filled为true,背景色使用fillColor的颜色
                    filled: true,
                    fillColor: const Color.fromRGBO(0, 0, 0, 0.12),
                    // 内边距
                    contentPadding: EdgeInsets.all(
                      ScreenUtil().setWidth(10.0),
                    ),
                    // 占位文本
                    hintText: '请输入手机号',
                    // 占位文本样式
                    hintStyle: TextStyle(
                      color: const Color(0x99FFFFFF),
                      fontSize: ScreenUtil().setSp(12),
                      decoration: TextDecoration.none,
                    ),
                    // 边框
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10.0),
                      borderSide: const BorderSide(
                        color: Colors.transparent,
                        width: 0,
                      ),
                    ),
                    // 输入框禁用时边框（errorText为空时生效）
                    disabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10.0),
                      borderSide: const BorderSide(
                        color: Colors.transparent,
                        width: 0,
                      ),
                    ),
                    // 输入框可用时边框（errorText为空时生效）
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10.0),
                      borderSide: const BorderSide(
                        color: Colors.transparent,
                        width: 0,
                      ),
                    ),
                    // 输入框获取焦点时边框
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10.0),
                      borderSide: const BorderSide(
                        color: Colors.transparent,
                        width: 0,
                      ),
                    ),
                  ),
                ),
              ),
              Flex(
                direction: Axis.horizontal,
                children: [
                  Expanded(
                    child: TextField(
                      // 光标颜色
                      cursorColor: const Color(0xffFF00B3),
                      // 文本框控制器
                      controller: codeController,
                      // 输入文本样式
                      style: TextStyle(
                        color: const Color(0xffffffff),
                        fontSize: ScreenUtil().setSp(14),
                        decoration: TextDecoration.none,
                        height: 1.0, // 行高
                      ),
                      // 文本对齐方式
                      textAlign: TextAlign.center,
                      decoration: InputDecoration(
                        // 如果filled为true,背景色使用fillColor的颜色
                        filled: true,
                        fillColor: const Color.fromRGBO(0, 0, 0, 0.12),
                        // 内边距
                        contentPadding: EdgeInsets.all(
                          ScreenUtil().setWidth(10.0),
                        ),
                        // 占位文本
                        hintText: '确认验证码',
                        // 占位文本样式
                        hintStyle: TextStyle(
                          color: const Color(0x99FFFFFF),
                          fontSize: ScreenUtil().setSp(12),
                          decoration: TextDecoration.none,
                        ),
                        // 边框
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10.0),
                          borderSide: const BorderSide(
                            color: Colors.transparent,
                            width: 0,
                          ),
                        ),
                        // 输入框禁用时边框（errorText为空时生效）
                        disabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10.0),
                          borderSide: const BorderSide(
                            color: Colors.transparent,
                            width: 0,
                          ),
                        ),
                        // 输入框可用时边框（errorText为空时生效）
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10.0),
                          borderSide: const BorderSide(
                            color: Colors.transparent,
                            width: 0,
                          ),
                        ),
                        // 输入框获取焦点时边框
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10.0),
                          borderSide: const BorderSide(
                            color: Colors.transparent,
                            width: 0,
                          ),
                        ),
                      ),
                    ),
                  ),
                  GestureDetector(
                    onTap: () {
                      if (!isSendCode) {
                        countdown();
                      }
                    },
                    child: Container(
                      width: ScreenUtil().setWidth(100.0),
                      height: ScreenUtil().setWidth(45.0),
                      alignment: Alignment.center,
                      margin: EdgeInsets.only(
                        left: ScreenUtil().setWidth(10.0),
                      ),
                      decoration: BoxDecoration(
                        color: DefaultStyle.bgDefault,
                        borderRadius: BorderRadius.all(
                          Radius.circular(
                            ScreenUtil().setWidth(5.0),
                          ),
                        ),
                      ),
                      child: Text(
                        btnText,
                        style: DefaultStyle.red12,
                      ),
                    ),
                  ),
                ],
              ),
              GestureDetector(
                onTap: () {
                  handleSubmit();
                },
                child: Padding(
                  padding: EdgeInsets.only(
                    top: ScreenUtil().setWidth(100.0),
                  ),
                  child: RedGlassmorphoismBox(
                    width: ScreenUtil().setWidth(120.0),
                    height: ScreenUtil().setWidth(45.0),
                    borderRadius: BorderRadius.all(
                      Radius.circular(
                        ScreenUtil().setWidth(22.5),
                      ),
                    ),
                    child: Text(
                      '确定',
                      style: DefaultStyle.white14,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
