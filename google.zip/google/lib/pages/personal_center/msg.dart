import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:iaimei/components/common/head.dart';
import 'package:iaimei/components/common/pagestatus.dart';
import 'package:iaimei/components/common/pullrefreshlist.dart';
import 'package:iaimei/components/common/stackpage.dart';
import 'package:iaimei/model/modle_msg_list.dart';
import 'package:iaimei/theme/default.dart';
import 'package:iaimei/utils/api.dart';

class Msg extends StatefulWidget {
  const Msg({Key? key}) : super(key: key);

  @override
  State<Msg> createState() => _MsgState();
}

class _MsgState extends State<Msg> with TickerProviderStateMixin {
  bool loading = true; // 加载中状态

  late List<Datum> data;

  void getData() async {
    ModelMsgList? res = await apiMsgList();
    if (res?.status == 1) {
      data = res!.data;
      loading = false;
      setState(() {});
    }
  }

  @override
  void initState() {
    super.initState();
    getData();
  }

  /// 列表项
  Widget listItem(Datum item) {
    return Container(
      margin: EdgeInsets.only(
        right: DefaultStyle.pagePadding,
        bottom: DefaultStyle.pagePadding,
        left: DefaultStyle.pagePadding,
      ),
      padding: EdgeInsets.all(
        ScreenUtil().setWidth(10.0),
      ),
      decoration: BoxDecoration(
        color: DefaultStyle.bgDefault,
        borderRadius: BorderRadius.all(
          Radius.circular(
            ScreenUtil().setWidth(12.0),
          ),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            item.title,
            style: DefaultStyle.white14,
          ),
          Padding(
            padding: EdgeInsets.only(
              top: ScreenUtil().setWidth(5.0),
              bottom: ScreenUtil().setWidth(7.5),
            ),
            child: Text(
              item.createdAt,
              style: DefaultStyle.gray10,
            ),
          ),
          Text(
            item.description,
            style: TextStyle(
              color: const Color(0x99FFFFFF),
              fontSize: ScreenUtil().setSp(12),
              decoration: TextDecoration.none,
            ),
          ),
        ],
      ),
    );
  }

  /// 初始化
  Widget init() {
    if (loading) {
      return PageStatus.loading(true);
    }
    Widget tempStatus = PageStatus.noData();
    if (data.isNotEmpty) {
      tempStatus = ListView.builder(
        itemCount: data.length,
        itemBuilder: (BuildContext context, int index) {
          return listItem(data[index]);
        },
      );
    }
    return PullRefreshList(
      onRefresh: () {
        getData();
      },
      child: tempStatus,
    );
  }

  @override
  Widget build(BuildContext context) {
    return StackPage(
      header: const HeadBack(
        leftText: '消息中心',
      ),
      child: init(),
    );
  }
}
