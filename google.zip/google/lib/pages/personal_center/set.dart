import 'package:bot_toast/bot_toast.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:hive/hive.dart';
import 'package:iaimei/app_const.dart';
import 'package:iaimei/components/card/card_space_between.dart';
import 'package:iaimei/components/citypicker/city_picker_page.dart';
import 'package:iaimei/components/common/base_dialog.dart';
import 'package:iaimei/components/common/commonelements.dart';
import 'package:iaimei/components/common/glassmorphism.dart';
import 'package:iaimei/components/common/pullrefreshlist.dart';
import 'package:iaimei/components/common/stackpage.dart';
import 'package:iaimei/global.dart';
import 'package:iaimei/model/basic.dart';
import 'package:iaimei/model/config.dart';
import 'package:iaimei/pages/app_version_upgrade_page.dart';
import 'package:iaimei/res/string_res.dart';
import 'package:iaimei/store/homedata.dart';
import 'package:iaimei/store/userdata.dart';
import 'package:iaimei/theme/default.dart';
import 'package:iaimei/utils/api.dart';
import 'package:iaimei/utils/string_util.dart';
import 'package:iaimei/widget/buttom_widget.dart';
import 'package:provider/provider.dart';

/// 设置
class Set extends StatefulWidget {
  const Set({Key? key}) : super(key: key);

  @override
  State<Set> createState() => _SetState();
}

class _SetState extends State<Set> with TickerProviderStateMixin {
  // 是否提交中
  bool isSubmit = true;

  // 弹出框的文本框控制器
  TextEditingController textFieldController = TextEditingController();

  /// 弹出框
  /// [type]类型{1/null: 兑换码, 2: 邀请码}
  void publicDialog(
    BuildContext context, {
    int type = 1,
  }) {
    String tempTitle = '兑换码';
    if (type == 2) {
      tempTitle = '邀请码';
    }
    BaseDialog.showdialog(
      context,
      insetPadding: 30.w,
      barrierColor: Colors.black45,
      barrierDismissible: false,
      cancelBack: () {
        isSubmit = true;
        setState(() {
          textFieldController.clear();
        });
      },
      child: Column(
        children: [
          Padding(
            padding: EdgeInsets.only(top: 40.w, bottom: 10.w),
            child: Text(
              tempTitle,
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 18.sp,
                  fontWeight: FontWeight.w600),
            ),
          ),
          Container(
            margin: EdgeInsets.symmetric(horizontal: 23.w),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12.w),
              color: const Color.fromRGBO(0, 0, 0, 0.16),
            ),
            alignment: Alignment.center,
            height: 44.w,
            child: TextField(
              controller: textFieldController,
              cursorColor: const Color(0xffFF00B3),
              autofocus: false,
              textAlign: TextAlign.center,
              style: TextStyle(color: const Color(0xffffffff), fontSize: 14.sp),
              decoration: InputDecoration(
                contentPadding: EdgeInsets.all(10.w),
                hintText: '请输入$tempTitle',
                hintStyle:
                    TextStyle(color: const Color(0xa3FFFFFF), fontSize: 13.sp),
                border: InputBorder.none,
              ),
            ),
          ),
          SizedBox(height: 30.w),
          ButtonWidget.build(
            '提交',
            onTap: () {
              String? tempCode = textFieldController.text.trim();
              if (tempCode == '') {
                BotToast.showText(text: "$tempTitle不能为空");
                return;
              }
              if (type == 2) {
                inviteSubmit(context, code: tempCode);
              } else {
                exchangeSubmit(context, code: tempCode);
              }
            },
          ),
          SizedBox(height: 25.w),
        ],
      ),
    );
  }

  /// 兑换码提交
  void exchangeSubmit(
    BuildContext context, {
    required String code,
  }) async {
    if (!isSubmit) {
      return;
    }
    isSubmit = false;
    Basic? res = await apiExchangeCode(
      code: code,
    );
    if (res?.status == 1) {
      BotToast.showText(
        text: res!.data["msg"].toString(),
      );
      await apiGetBaseInfo(context);
      Navigator.pop(context);
    } else {
      BotToast.showText(
        text: '兑换失败',
      );
    }
    isSubmit = true;
  }

  /// 邀请码提交
  void inviteSubmit(
    BuildContext context, {
    required String code,
  }) async {
    if (!isSubmit) {
      return;
    }
    isSubmit = false;
    Basic? res = await apiInviteCode(
      code: code,
    );
    if (res?.status == 1) {
      BotToast.showText(
        text: res!.data.toString(),
      );
      await apiGetBaseInfo(context);
      setState(() {});
      Navigator.pop(context);
    } else {
      BotToast.showText(
        text: '设置邀请码失败',
      );
    }
    isSubmit = true;
  }

  @override
  void initState() {
    super.initState();
    AppGlobal.calculateimageCache((value) {
      setState(() => cache = value);
    });
  }

  String cache = '0.0B';

  /// 清理缓存
  Future<void> cleanCache() async {
    BotToast.showLoading();
    Basic? res = await apiCleanCache();
    if (res?.status == 1) {
      AppGlobal.clearCache((value) {
        setState(() => cache = value);
        BotToast.closeAllLoading();
        BotToast.showText(text: "缓存清理成功");
      });
    } else {
      BotToast.closeAllLoading();
      BotToast.showText(text: "缓存清理失败");
    }
  }

  @override
  void dispose() {
    textFieldController.dispose();
    super.dispose();
  }

  /// 更新token
  Future<void> updateToken(token) async {
    String tempToken = token;
    Box? box = AppGlobal.appBox;
    await box?.put('gg_token', tempToken);
  }

  /// 退出登录
  Future<void> onLogOut() async {
    BotToast.showText(text: '退出成功');
    Basic? res = await apiCleanCache(); // 清除缓存
    if (res?.status == 1) {
      await updateToken('');
      await apiGetBaseInfo(context);
      context.go("/");
    } else { // 缓存清理出错
      await updateToken('');
      await apiGetBaseInfo(context);
      context.go("/");
    }
  }

  /// 设置退出按钮
  Widget buildLoginOutBtn(int isReg) {
    return isReg == 1
        ? ButtonWidget.build('退出', onTap: onLogOut)
        : const SizedBox();
  }

  @override
  Widget build(BuildContext context) {
    var userData = Provider.of<UserData>(context, listen: false).userInfo;
    Config configData = Provider.of<HomeData>(context, listen: false).data;
    return StackPage(
      header: const CustomHeader(title: '设置'),
      child: PullRefreshList(
        onRefresh: () {},
        child: Column(
          children: [
            SizedBox(height: 10.w),
            _buildItemWidget(
              title: '兑换码',
              onTap: () => publicDialog(context, type: 1),
            ),
            _buildItemWidget(
              title: "邀请码",
              subTitle: userData.inviteByCode.toString() == ""
                  ? ''
                  : userData.inviteByCode.toString(),
              onTap: () {
                if (userData.inviteByCode.toString() == "") {
                  publicDialog(context, type: 2);
                }
              },
            ),
            _buildItemWidget(title: "清除缓存", subTitle: cache, onTap: cleanCache),
            _buildItemWidget(
              title: StringRes.str_check_update,
              subTitle: AppConst.appVersion,
              onTap: () => checkVersion(configData),
            ),
            SizedBox(height: 100.w),
            buildLoginOutBtn(userData.isReg ?? 0),
          ],
        ),
      ),
    );
  }

  Widget _buildItemWidget(
      {String title = '', String subTitle = '', void Function()? onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 52.w,
        margin: EdgeInsets.fromLTRB(16.w, 0, 16.w, 15.w),
        padding: EdgeInsets.symmetric(horizontal: 10.w),
        decoration: BoxDecoration(
          color: const Color(0x1fb2aaff),
          borderRadius: BorderRadius.circular(12.w),
          border: Border.all(color: const Color(0x0dffffff)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              child: Text(
                title,
                style: TextStyle(color: Colors.white, fontSize: 15.sp),
              ),
            ),
            Row(
              children: [
                Text(
                  subTitle,
                  style: TextStyle(
                      color: const Color(0xd6ff00b3), fontSize: 12.sp),
                ),
                SizedBox(width: subTitle.isNotEmpty ? 10.w : 0),
                Image.asset("assets/images/common/arrow_go.png", height: 18.w),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void checkVersion(Config config) {
    if (config.version != null &&
        StringUtil.isNotEmpty(config.version.version)) {
      Version version = config.version;
      String newVersionCode = version.version;
      var newVersion = newVersionCode.replaceAll('.', '');
      var curVersion = AppConst.appVersion.replaceAll('.', '');
      if (int.parse(newVersion) > int.parse(curVersion)) {
        showVersionUpgradeDialog(config, version);
      }
    }
  }

  void showVersionUpgradeDialog(Config config, Version version) {
    showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) {
          return AppVersionUpgradePage(
            version: version,
            callback: () {},
          );
        });
  }
}
