import 'dart:async';

import 'package:bot_toast/bot_toast.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_picker/Picker.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:iaimei/components/card/card_space_between.dart';
import 'package:iaimei/components/common/head.dart';
import 'package:iaimei/components/common/stackpage.dart';
import 'package:iaimei/components/form/radio_sex_box.dart';
import 'package:iaimei/model/basic.dart';
import 'package:iaimei/model/user_info_model.dart';
import 'package:iaimei/pages/creator/upload_picker_mixin.dart';
import 'package:iaimei/router/routers.dart';
import 'package:iaimei/store/userdata.dart';
import 'package:iaimei/theme/default.dart';
import 'package:iaimei/utils/api.dart';
import 'package:iaimei/utils/networkimage.dart';
import 'package:iaimei/widget/convenient_mixin.dart';
import 'package:iaimei/widget/network_img_container.dart';
import 'package:provider/provider.dart';

class PersonalInfo extends StatefulWidget {
  const PersonalInfo({Key? key}) : super(key: key);

  @override
  State<PersonalInfo> createState() => _PersonalInfoState();
}

class _PersonalInfoState extends State<PersonalInfo>
    with ConvenientMixin, UploadPickerMixin {
  // 提交处理中
  bool isSubmit = true;

  /// 性别点击事件
  void handleSexType(data) {
    onSubmit(sex: data);
    setState(() {
      Provider.of<UserData>(
        context,
        listen: false,
      ).setSexType(data);
    });
  }

  /// 出生日期修改弹出框
  void handleBirthdayDialog() {
    Picker(
      adapter: DateTimePickerAdapter(
        yearSuffix: "年",
        daySuffix: "日",
        months: [
          "1月",
          "2月",
          "3月",
          "4月",
          "5月",
          "6月",
          "7月",
          "8月",
          "9月",
          "10月",
          "11月",
          "12月",
        ],
      ),
      // 隐藏头部
      hideHeader: true,
      // 标题
      title: Text(
        "生日选择",
        style: DefaultStyle.white14,
      ),
      // 全局文本样式
      textStyle: const TextStyle(
        color: Color.fromRGBO(255, 255, 255, 0.64),
      ),
      // 取消按钮文字
      cancelText: "取消",
      // 取消按钮文字样式
      cancelTextStyle: DefaultStyle.white14,
      // 确认按钮文字
      confirmText: "确认",
      // 确认按钮文字
      confirmTextStyle: DefaultStyle.white14,
      // 选中的文字样式
      selectedTextStyle: const TextStyle(
        color: Colors.white,
      ),
      // 日期内部背景色
      backgroundColor: const Color.fromRGBO(26, 21, 47, 1),
      // 确认事件
      onConfirm: (Picker picker, List value) {
        String? tempDateTime = picker.adapter.toString().split(" ")[0];
        handleBirthday(tempDateTime);
      },
    ).showDialog(
      context,
      // 弹出框背景色
      backgroundColor: const Color.fromRGBO(26, 21, 47, 1),
    );
  }

  /// 初始化用户信息接口
  Future<void> initUserBaseInfo() async {
    await apiGetBaseInfo(context);
  }

  /// 出生日期确认事件
  void handleBirthday(data) {
    onSubmit(birthday: data);
    setState(() {
      Provider.of<UserData>(
        context,
        listen: false,
      ).setBirthday(data);
    });
  }

  /// 上传头像
  Future<void> handleThumb(data) async {
    await onSubmit(thumb: data);
    await initUserBaseInfo();
  }

  /// 请求接口方法
  Future<void> onSubmit({
    String? nickname,
    int? sex,
    String? birthday,
    String? thumb,
  }) async {
    if (!isSubmit) {
      BotToast.showText(text: "处理中...");
      return;
    }
    isSubmit = false;
    Basic? res = await apiSetBaseInfo(
      nickname: nickname,
      sex: sex,
      birthday: birthday,
      thumb: thumb,
    );
    if (res?.status == 1) {
      BotToast.showText(text: res?.data ?? '设置成功');
    }
    isSubmit = true;
  }

  @override
  void initState() {
    super.initState();
    actionSize = Size(96.w, 96.w);
    commonInitUploadCallback();

    /// 获取上传头像成功的返回值之后在提交给后端
    singleObjectCallback = () {
      if (imagePathMap.isEmpty) {
        debugPrint('出现错误了...');
        return;
      }
      var obj = imagePathMap.values.first;
      handleThumb(obj["url"].toString());
    };
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    var userData = Provider.of<UserData>(context).userInfo;
    return StackPage(
      header: const HeadBack(leftText: '个人资料'),
      child: SingleChildScrollView(
        child: Column(
          children: [
            GestureDetector(
              onTap: () => showImageAssets(),
              child: Container(
                alignment: Alignment.center,
                margin: EdgeInsets.only(top: 10.w, bottom: 20.0.w),
                height: 96.w,
                width: 96.w,
                child: Stack(
                  children: [
                    Container(
                      padding: EdgeInsets.all(1.w),
                      child: NetworkImgContainer(
                        url: userData.avatarUrl ?? "",
                        fit: BoxFit.cover,
                        radius: BorderRadius.circular(32.5.w),
                      ),
                    ),
                    Image.asset('assets/images/common/avatar_cover.png'),
                  ],
                ),
              ),
            ),
            _buildItemWidget(
              title: "昵称",
              subTitle: Text(
                userData.nickname ?? '',
                style:
                    TextStyle(color: const Color(0xd6ffffff), fontSize: 13.sp),
              ),
              onTap: () => context.push("/${Routes.setNickname}"),
            ),
            _buildItemWidget(
              title: "性别",
              subTitle: RadioSexBox(
                value: userData.sex ?? 0,
                list: const [
                  {"label": '男', "value": 0},
                  {"label": '女', "value": 1},
                ],
                onTap: (data) => handleSexType(data),
              ),
            ),
            _buildItemWidget(
              title: "生日",
              subTitle: Text(
                userData.birthday!.isEmpty ? "暂无" : userData.birthday!,
                style:
                    TextStyle(color: const Color(0xd6ffffff), fontSize: 13.sp),
              ),
              onTap: handleBirthdayDialog,
            ),
            SizedBox(height: 15.w),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 16.w),
              alignment: Alignment.centerLeft,
              child: Text(
                '温馨提示',
                style:
                    TextStyle(color: const Color(0xd6ffffff), fontSize: 14.sp),
              ),
            ),
            SizedBox(height: 5.w),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 16.w),
              alignment: Alignment.centerLeft,
              child: Text(
                '系统会根据您的星座、年龄、性别给您推荐更匹配的内容，所以，请填写真实性别和生日哦！嘿嘿！',
                style:
                    TextStyle(color: const Color(0xa3ffffff), fontSize: 12.sp),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildItemWidget(
      {String title = '', Widget? subTitle, void Function()? onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 52.w,
        margin: EdgeInsets.fromLTRB(16.w, 0, 16.w, 15.w),
        padding: EdgeInsets.symmetric(horizontal: 10.w),
        decoration: BoxDecoration(
          color: const Color(0x1fb2aaff),
          borderRadius: BorderRadius.circular(12.w),
          border: Border.all(color: const Color(0x0dffffff)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              child: Text(
                title,
                style: TextStyle(color: Colors.white, fontSize: 15.sp),
              ),
            ),
            Row(children: [subTitle ?? const SizedBox()]),
          ],
        ),
      ),
    );
  }
}
