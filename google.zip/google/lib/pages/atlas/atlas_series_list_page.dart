import 'package:flutter/material.dart';
import 'package:iaimei/base/app_base_widget_state.dart';
import 'package:iaimei/mixin/list_page_load_mixin.dart';
import 'package:iaimei/model/atlas_item_model.dart';
import 'package:iaimei/model/atlas_series_item_model.dart';
import 'package:iaimei/net/http_error.dart';
import 'package:iaimei/net/http_helper.dart';
import 'package:iaimei/pages/atlas/atlas_list_item_widget.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/utils/list_util.dart';
import 'package:iaimei/utils/page_jump_util.dart';
import 'package:iaimei/widget/app_page_title_bar.dart';
import 'package:iaimei/widget/list_widget.dart';
import 'package:iaimei/widget/refresh_load_list_widget.dart';

class AtlasSeriesListPage extends StatefulWidget {
  final AtlasSeriesItemModel data;

  const AtlasSeriesListPage({Key? key, required this.data}) : super(key: key);

  @override
  State<AtlasSeriesListPage> createState() => _AtlasSeriesListPageState();
}

class _AtlasSeriesListPageState extends AppBaseWidgetState<AtlasSeriesListPage>
    with ListPageLoadMixin {
  @override
  buildAppBar() {
    return AppPageTitleBar.getNormalAppBar(title: widget.data.name);
  }

  @override
  void initState() {
    super.initState();
    onLoadData();
  }

  @override
  Widget buildPageLayout() {
    return handlePageStateView();
  }

  @override
  onLoadData() {
    onRefreshList();
  }

  @override
  void requestListData(bool isRefresh) {
    HttpHelper.getAtlasSeriesList('${widget.data.id}', getCurPage, getPageSize,
        (data) {
      List<AtlasItemModel> atlasList = [];
      try {
        if (data is List) {
          atlasList =
              data.map((item) => AtlasItemModel.fromJson(item)).toList();
        }
        setListPageState(isRefresh, ListUtil.isNotEmpty(atlasList), () {
          updatePageList(isRefresh, atlasList);
        });
      } catch (e) {
        setListPageErrorState(isRefresh, HttpError());
      }
    }, (error) {
      setListPageErrorState(isRefresh, error);
    });
  }

  @override
  int setPageSize() {
    return 12;
  }

  @override
  Widget successView() {
    return RefreshLoadListWidget(
        enableLoad: isEnableLoad(),
        enableRefresh: isEnableRefresh(),
        onRefresh: onRefreshList,
        onLoad: onLoadList,
        child: Padding(
          padding: EdgeInsets.only(
              left: DimenRes.dimen_15,
              right: DimenRes.dimen_15,
              top: DimenRes.dimen_5),
          child: _buildSeriesGridView(getResultList),
        ),
        refreshController: refreshController);
  }

  _buildSeriesGridView(List resultList) {
    return ListWidget.buildGridView(
        itemCount: resultList.length,
        itemBuilder: (context, index) =>
            _buildAtlasSeriesItem(resultList[index] as AtlasItemModel),
        childRatio: 0.618,
        mainSpace: DimenRes.dimen_15,
        crossSpace: DimenRes.dimen_15,
        crossCount: 3);
  }

  _buildAtlasSeriesItem(AtlasItemModel itemModel) {
    double width = (DimenRes.screenWidth - DimenRes.dimen_60) / 3;
    double height = width * 7 / 5;
    return InkWell(
      onTap: () {
        PageJumpUtil.forwardToAtlasDetailPage(context, itemModel);
      },
      child: AtlasListItemWidget(
          itemData: itemModel, imgWidth: width, imgHeight: height),
    );
  }
}
