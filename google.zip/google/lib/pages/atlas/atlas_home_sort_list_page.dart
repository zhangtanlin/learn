import 'package:flutter/material.dart';
import 'package:iaimei/base/base_widget_state.dart';
import 'package:iaimei/mixin/list_page_load_mixin.dart';
import 'package:iaimei/model/atlas_item_model.dart';
import 'package:iaimei/model/atlas_series_item_model.dart';
import 'package:iaimei/net/http_error.dart';
import 'package:iaimei/net/http_helper.dart';
import 'package:iaimei/pages/atlas/atlas_list_item_widget.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/res/img_res.dart';
import 'package:iaimei/style/app_text_style.dart';
import 'package:iaimei/utils/list_util.dart';
import 'package:iaimei/utils/page_jump_util.dart';
import 'package:iaimei/widget/app_img_widget.dart';
import 'package:iaimei/widget/list_widget.dart';
import 'package:iaimei/widget/refresh_load_list_widget.dart';
import 'package:iaimei/widget/space_widget.dart';
import 'package:iaimei/widget/text_widget.dart';

import '../../model/tab_data.dart';

class AtlasHomeSortListPage extends StatefulWidget {
  final int id;

  final SubTab tab;

  final String api;

  const AtlasHomeSortListPage(
      {Key? key, required this.id, required this.tab, required this.api})
      : super(key: key);

  @override
  State<AtlasHomeSortListPage> createState() => _AtlasHomeSortListPageState();
}

class _AtlasHomeSortListPageState extends BaseWidgetState<AtlasHomeSortListPage>
    with ListPageLoadMixin {
  @override
  void initState() {
    super.initState();
    onLoadData();
  }

  @override
  onLoadData() {
    onRefreshList();
  }

  @override
  void requestListData(bool isRefresh) {
    HttpHelper.getCommonIndexList(
        widget.api, '${widget.id}', widget.tab.value!, getCurPage, getPageSize,
        (data) {
      List<AtlasSeriesItemModel> atlasSeriesList = [];
      try {
        if (data is List) {
          atlasSeriesList =
              data.map((item) => AtlasSeriesItemModel.fromJson(item)).toList();
        }
        setListPageState(isRefresh, ListUtil.isNotEmpty(atlasSeriesList), () {
          updatePageList(isRefresh, atlasSeriesList);
        });
      } catch (e) {
        setListPageErrorState(isRefresh, HttpError());
      }
    }, (error) {
      setListPageErrorState(isRefresh, error);
    });
  }

  @override
  Widget successView() {
    return RefreshLoadListWidget(
      enableLoad: isEnableLoad(),
      enableRefresh: isEnableRefresh(),
      onRefresh: onRefreshList,
      onLoad: onLoadList,
      refreshController: refreshController,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [buildAtlasListSection(getResultList)],
      ),
    );
  }

  buildAtlasListSection(List dataList) {
    return ListWidget.buildVerticalListView(
        itemCount: dataList.length,
        itemBuilder: (context, index) {
          return _buildAtlasSeriesListSection(
            index,
              dataList[index] as AtlasSeriesItemModel);
        },
        shrinkWrap: true,
        physics: const BouncingScrollPhysics());
  }

  _buildAtlasSeriesListSection(int index,AtlasSeriesItemModel atlasSeriesItemModel) {
    return Column(
      children: [
        index == 0
            ? const SizedBox()
            : SpaceWidget(
          vSpace: DimenRes.dimen_10,
        ),
        Container(
          color: Colors.white.withOpacity(0.04),
          padding: EdgeInsets.only(
              left: DimenRes.dimen_15,
              top: DimenRes.dimen_15,
              right: DimenRes.dimen_15,
              bottom: DimenRes.dimen_15),
          child: InkWell(
            onTap: () {
              PageJumpUtil.forwardToAtlasSeriesPage(
                  context, atlasSeriesItemModel);
            },
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Expanded(
                  child: TextWidget.buildSingleLineText(
                      '${atlasSeriesItemModel.name}', AppTextStyle.white_s18),
                ),
                AppImgWidget(
                    path: ImgRes.IC_ARROW_RIGHT,
                    fit: BoxFit.contain,
                    height: DimenRes.dimen_18)
              ],
            ),
          ),
        ),
        Container(
            height: DimenRes.convert(175),
            width: DimenRes.screenWidth,
            color: Colors.white.withOpacity(0.04),
            padding: EdgeInsets.only(
                left: DimenRes.dimen_15,
                bottom: DimenRes.dimen_15),
            child: ListWidget.buildHorizontalListView(
                itemCount: atlasSeriesItemModel.list!.length,
                itemBuilder: (context, index) =>
                    _buildSortListItem(atlasSeriesItemModel.list![index])))
      ],
    );
  }

  _buildSortListItem(AtlasItemModel item) {
    return Row(
      children: [
        InkWell(
          onTap: () {
            PageJumpUtil.forwardToAtlasDetailPage(context, item);
          },
          child: _buildComicsItem(item),
        ),
        const SpaceWidget(
          hSpace: 12,
        )
      ],
    );
  }

  @override
  Widget buildPageLayout() {
    return handlePageStateView();
  }

  _buildComicsItem(AtlasItemModel item) {
    return AtlasListItemWidget(
        itemData: item,
        imgWidth: DimenRes.dimen_100,
        imgHeight: DimenRes.dimen_135);
  }
}
