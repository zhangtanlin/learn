import 'package:flutter/material.dart';
import 'package:iaimei/base/base_widget_state.dart';
import 'package:iaimei/model/ads_model.dart';
import 'package:iaimei/pages/atlas/atlas_home_sort_list_page.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/style/app_text_style.dart';
import 'package:iaimei/utils/list_util.dart';
import 'package:iaimei/widget/app_divider_widget.dart';
import 'package:iaimei/widget/banner_widget.dart';
import 'package:iaimei/widget/keep_alive_wrapper.dart';
import 'package:iaimei/widget/snap_top_tab_navigator.dart';

import '../../model/tab_data.dart';

class AtlasHomeSortPage extends StatefulWidget {
  final TabData? data;

  const AtlasHomeSortPage({Key? key, this.data}) : super(key: key);

  @override
  State<AtlasHomeSortPage> createState() => _AtlasHomeSortPageState();
}

class _AtlasHomeSortPageState extends BaseWidgetState<AtlasHomeSortPage> {
  late SnapTopTabNavConfig _tabNavConfig;
  late List<SubTab> _subList;
  late List<AdsModel> _adList;

  @override
  void initState() {
    super.initState();
    _adList = widget.data!.ads!;
    _subList = widget.data!.subTab!;
    _tabNavConfig = SnapTopTabNavConfig(
        snapTopHeight: DimenRes.convert(44),
        snapTopBgColor: Colors.transparent,
        tabItemMargin: EdgeInsets.only(right: DimenRes.dimen_30),
        textStyle: AppTextStyle.white_s15,
        navMargin:
            EdgeInsets.only(left: DimenRes.dimen_15, right: DimenRes.dimen_15),
        selectedTextStyle: AppTextStyle.cff00b3_s15_bold);
  }

  @override
  Widget buildPageLayout() {
    return ListUtil.isNotEmpty(_subList)
        ? SnapTopTabNavigator(
            tabItems: _subList.map((nav) => '${nav.name}').toList(),
            pages: _subList
                .map((nav) => KeepAliveWrapper(
                        child: AtlasHomeSortListPage(
                      id: widget.data!.id!,
                      api: widget.data!.api!,
                      tab: nav,
                    )))
                .toList(),
            foldWidget: _buildSnapTopWidget(),
            config: _tabNavConfig)
        : const SizedBox();
  }

  _buildSnapTopWidget() {
    return ListUtil.isNotEmpty(_adList)
        ? BannerWidget(
            adList: _adList,
            height: DimenRes.dimen_190,
            margin: EdgeInsets.only(
                left: DimenRes.dimen_15,
                top: DimenRes.dimen_15,
                right: DimenRes.dimen_15),
            radius: BorderRadius.circular(12),
          )
        : const SizedBox();
  }
}
