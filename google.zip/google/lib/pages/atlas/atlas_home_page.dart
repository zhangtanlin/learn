import 'package:flutter/material.dart';
import 'package:iaimei/base/app_base_widget_state.dart';
import 'package:iaimei/mixin/page_load_mixin.dart';
import 'package:iaimei/net/http_error.dart';
import 'package:iaimei/net/http_helper.dart';
import 'package:iaimei/pages/atlas/atlas_home_sort_page.dart';
import 'package:iaimei/res/color_res.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/res/img_res.dart';
import 'package:iaimei/style/app_text_style.dart';
import 'package:iaimei/utils/list_util.dart';
import 'package:iaimei/utils/page_jump_util.dart';
import 'package:iaimei/widget/app_back_widget.dart';
import 'package:iaimei/widget/app_img_widget.dart';
import 'package:iaimei/widget/top_tab_navigator.dart';

import '../../model/tab_data.dart';

class AtlasHomePage extends StatefulWidget {
  const AtlasHomePage({Key? key}) : super(key: key);

  @override
  State<AtlasHomePage> createState() => _AtlasHomePageState();
}

class _AtlasHomePageState extends AppBaseWidgetState<AtlasHomePage>
    with PageLoadMixin {

  late TopTabNavConfig _tabNavConfig;
  late List<TabData> tabDataList=[];

  @override
  void initState() {
    super.initState();
    _tabNavConfig = TopTabNavConfig(
        tabHeight: DimenRes.dimen_44,
        selectedTextColor: ColorRes.color_30313f,
        isScrollable: false,
        textColor: ColorRes.color_30313f,
        navMargin:
            EdgeInsets.only(left: DimenRes.dimen_15, right: DimenRes.dimen_15),
        navTabMargin:
            EdgeInsets.only(left: DimenRes.dimen_20, right: DimenRes.dimen_20),
        textStyle: AppTextStyle.white_s14,
        selectedTextStyle: AppTextStyle.cff00b3_s18_bold,
        rightWidget: _buildSearchBtn(),
        leftWidget: _buildBackBtn());
    onLoadData();
  }

  _buildSearchBtn() {
    return AppImgWidget(
      path: ImgRes.IC_SEARCH,
      width: DimenRes.dimen_30,
      height: DimenRes.dimen_30,
      onTap: () {
        PageJumpUtil.forwardToSearchPage(context);
      },
    );
  }

  _buildBackBtn() {
    return const AppBackWidget();
  }

  @override
  Widget buildPageLayout() {
    return handlePageStateView();
  }

  @override
  onLoadData() {
    HttpHelper.getAtlasIndex((data) {
      try {
        if (data is List) {
          tabDataList = data.map((item) => TabData.fromJson(item)).toList();
        }
        setPageState(ListUtil.isNotEmpty(tabDataList));
      } catch (e) {
        setPageErrorState(HttpError());
      }
    }, (error) {
      setPageErrorState(error);
    });
  }

  @override
  Widget successView() {
    return TopTabNavigator(
      pages: tabDataList
          .map((item) => AtlasHomeSortPage(
                data: item,
              ))
          .toList(),
      config: _tabNavConfig,
      tabItems: tabDataList.map((item) => '${item.name}').toList(),
    );
  }
}
