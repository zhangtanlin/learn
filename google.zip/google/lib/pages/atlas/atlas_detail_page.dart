import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:iaimei/base/app_base_widget_state.dart';
import 'package:iaimei/mixin/page_load_mixin.dart';
import 'package:iaimei/model/atlas_detail_model.dart';
import 'package:iaimei/model/atlas_item_model.dart';
import 'package:iaimei/model/img_preview_info.dart';
import 'package:iaimei/net/http_error.dart';
import 'package:iaimei/net/http_helper.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/res/img_res.dart';
import 'package:iaimei/res/string_res.dart';
import 'package:iaimei/router/routers.dart';
import 'package:iaimei/style/app_text_style.dart';
import 'package:iaimei/utils/list_util.dart';
import 'package:iaimei/utils/page_jump_util.dart';
import 'package:iaimei/utils/string_util.dart';
import 'package:iaimei/utils/unlock_check_util.dart';
import 'package:iaimei/widget/app_divider_widget.dart';
import 'package:iaimei/widget/app_img_widget.dart';
import 'package:iaimei/widget/app_page_title_bar.dart';
import 'package:iaimei/widget/app_text_with_img_bg_widget.dart';
import 'package:iaimei/widget/keep_alive_wrapper.dart';
import 'package:iaimei/widget/network_img_container.dart';
import 'package:iaimei/widget/space_widget.dart';
import 'package:iaimei/widget/toast_widget.dart';

class AtlasDetailPage extends StatefulWidget {
  final AtlasItemModel item;

  const AtlasDetailPage({Key? key, required this.item}) : super(key: key);

  @override
  State<AtlasDetailPage> createState() => _AtlasDetailPageState();
}

class _AtlasDetailPageState extends AppBaseWidgetState<AtlasDetailPage>
    with PageLoadMixin {
  List<Resources> resourcesList = [];
  late AtlasDetailModel detailModel;
  bool isLike = false;

  @override
  void initState() {
    super.initState();
    onLoadData();
  }

  @override
  buildAppBar() {
    return AppPageTitleBar.getNormalAppBar(
        title: widget.item.title, titleAlignment: Alignment.center);
  }

  @override
  Widget buildPageLayout() {
    return handlePageStateView();
  }

  @override
  onLoadData() {
    HttpHelper.getAtlasDetail('${widget.item.id}', (data) {
      try {
        detailModel = AtlasDetailModel.fromJson(data);
        isLike = detailModel.favorites == 1;
        resourcesList = detailModel.resources!;
        setPageState(ListUtil.isNotEmpty(resourcesList));
      } catch (e) {
        setPageErrorState(HttpError());
      }
    }, (error) {
      setPageErrorState(error);
    });
  }

  @override
  Widget successView() {
    return Column(
      children: [
        Expanded(child: _buildContentListView()),
        AppDividerWidget(
          padding: EdgeInsets.only(
              top: DimenRes.dimen_15,
              bottom: DimenRes.dimen_10,
              left: DimenRes.dimen_15,
              right: DimenRes.dimen_15),
        ),
        _buildContentListBottomSection(),
      ],
    );
  }

  String getTips() {
    String tips = '';
    if (detailModel.payData?.free == 1) {
      tips = '开通VIP可查看完整图集';
    } else if (detailModel.payData?.free == 2) {
      tips = '购买可永久查看完整图集';
    }
    return tips;
  }

  _buildContentListBottomSection() {
    return Container(
      margin: EdgeInsets.only(
          bottom: DimenRes.dimen_30,
          left: DimenRes.dimen_15,
          right: DimenRes.dimen_15),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          StringUtil.isEmpty(getTips())
              ? const SizedBox()
              : AppTextWithImgBgWidget(
                  alignment: Alignment.topLeft,
                  bgImgPath: ImgRes.BG_UNLOCK_WATCH_WHOLE,
                  text: getTips(),
                  textStyle: AppTextStyle.white_s13,
                  top: 0,
                  bottom: 0,
                  left: 10,
                  right: 10,
                  bgImgHeight: DimenRes.convert(28),
                  onTap: () {
                    UnlockCheckUtil.atlasCheck(
                        context, '${detailModel.id}', detailModel.payData,
                        paySuccessFunc: (data) {
                      onLoadData();
                    });
                  },
                ),
          const Expanded(child: SizedBox()),
          GestureDetector(
            onTap: () {
              _likeAtlasAction();
            },
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                AppImgWidget(
                  path: isLike ? ImgRes.IC_LIKED : ImgRes.IC_NO_LIKE,
                  width: 28,
                  height: 28,
                ),
              ],
            ),
          ),
          const SpaceWidget(hSpace: 20),
          GestureDetector(
            onTap: () {
              PageJumpUtil.forwardToSharePage(context);
            },
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                AppImgWidget(
                  path: ImgRes.IC_SHARE,
                  width: 28,
                  height: 28,
                ),
              ],
            ),
          ),
          // const SpaceWidget(hSpace: 20),
          // GestureDetector(
          //   onTap: () {
          //     ToastWidget.showToast(StringRes.str_start_download);
          //   },
          //   child: Column(
          //     mainAxisSize: MainAxisSize.min,
          //     children: [
          //       AppImgWidget(
          //         path: ImgRes.IC_DOWNLOAD,
          //         width: 35,
          //         height: 35,
          //       ),
          //     ],
          //   ),
          // ),
        ],
      ),
    );
  }

  void _likeAtlasAction() {
    HttpHelper.likeAtlas('${detailModel.id}', (data) {
      setState(() {
        isLike = !isLike;
      });
      String tips = data as String;
      ToastWidget.showToast(tips);
    }, (error) {
      ToastWidget.showToast(StringRes.str_operate_fail);
    });
  }

  _buildContentListView() {
    return ListView.builder(
      padding:
          EdgeInsets.only(left: DimenRes.dimen_15, right: DimenRes.dimen_15),
      itemCount: ListUtil.size(resourcesList),
      shrinkWrap: true,
      scrollDirection: Axis.vertical,
      physics: const BouncingScrollPhysics(),
      cacheExtent: DimenRes.screenHeight * 5,
      itemBuilder: (context, index) {
        return KeepAliveWrapper(
          child: GestureDetector(
            onTap: () {
              context.push(
                "/" + Routes.imagePreview,
                extra: ImgPreviewInfo(
                    resourcesList.map((e) => e.imgUrlFull).toList(),
                    defaultIndex: index),
              );
            },
            child: _buildContentItemSection(resourcesList[index]),
          ),
        );
      },
    );
  }

  _buildContentItemSection(Resources contentItem) {
    double imgWidth = DimenRes.screenWidth - DimenRes.dimen_30;
    double imgHeight = 0;

    if (contentItem.imgWidth == '' ||
        contentItem.imgWidth == '0' ||
        contentItem.imgHeight == '' ||
        contentItem.imgHeight == '0') {
      imgHeight = imgWidth;
    } else {
      imgHeight = imgWidth *
          int.parse(contentItem.imgHeight!) /
          int.parse(contentItem.imgWidth!);
    }
    return Column(
      children: [
        SpaceWidget(
          vSpace: DimenRes.dimen_15,
        ),
        NetworkImgContainer(
          url: contentItem.imgUrlFull ?? '',
          width: imgWidth,
          height: imgHeight,
          filterQuality: FilterQuality.high,
          radius: BorderRadius.circular(10),
        )
      ],
    );
  }
}
