import 'package:flutter/material.dart';
import 'package:iaimei/pages/search/search_result_atlas_list_page.dart';
import 'package:iaimei/pages/search/search_result_comics_list_page.dart';
import 'package:iaimei/pages/search/search_result_novel_list_page.dart';
import 'package:iaimei/pages/search/search_result_short_video_list_page.dart';
import 'package:iaimei/pages/search/search_result_video_list_page.dart';
import 'package:iaimei/res/color_res.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/res/string_res.dart';
import 'package:iaimei/style/app_text_style.dart';
import 'package:iaimei/widget/app_divider_widget.dart';
import 'package:iaimei/widget/top_tab_navigator.dart';

class SearchResultPage extends StatefulWidget {
  final String? keywords;

  const SearchResultPage({Key? key, this.keywords}) : super(key: key);

  @override
  State<SearchResultPage> createState() => _SearchResultPageState();
}

class _SearchResultPageState extends State<SearchResultPage> {
  late List<String> tabItems;
  late TopTabNavConfig _tabNavConfig;
  late List<Widget> pages = [];

  @override
  void initState() {
    super.initState();
    tabItems = [
      StringRes.str_long_video,
      StringRes.str_short_video,
      StringRes.str_comics,
      StringRes.str_novel,
      StringRes.str_atlas
    ];
    _tabNavConfig = TopTabNavConfig(
        tabHeight: DimenRes.dimen_42,
        selectedTextColor: ColorRes.color_30313f,
        textColor: ColorRes.color_30313f,
        navTabMargin:
            EdgeInsets.only(left: DimenRes.dimen_15, right: DimenRes.dimen_15),
        tabItemMargin: EdgeInsets.only(right: DimenRes.dimen_15),
        textStyle: AppTextStyle.white_s14,
        selectedTextStyle: AppTextStyle.cff00b3_s18_bold,
        tabItemTextPadding: EdgeInsets.only(right: DimenRes.dimen_8));
  }

  @override
  Widget build(BuildContext context) {
    String kws = widget.keywords ?? '';
    pages.clear();
    pages
      ..add(SearchResultVideoListPage(
        keywords: kws,
      ))
      ..add(SearchResultShortVideoListPage(keywords: kws))
      ..add(SearchResultComicsListPage(keywords: kws))
      ..add(SearchResultNovelListPage(keywords: kws))
      ..add(SearchResultAtlasListPage(keywords: kws));
    return TopTabNavigator(
      tabItems: tabItems,
      pages: pages,
      config: _tabNavConfig,
      divideWidget: AppDividerWidget(
          padding: EdgeInsets.only(
              left: DimenRes.dimen_15, right: DimenRes.dimen_15)),
    );
  }
}
