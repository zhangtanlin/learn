import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:iaimei/app_const.dart';
import 'package:iaimei/base/app_base_widget_state.dart';
import 'package:iaimei/components/common/commonelements.dart';
import 'package:iaimei/global.dart';
import 'package:iaimei/mixin/page_load_mixin.dart';
import 'package:iaimei/model/search_index_model.dart';
import 'package:iaimei/model/video_model.dart';
import 'package:iaimei/net/http_helper.dart';
import 'package:iaimei/pages/search/search_result_page.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/res/img_res.dart';
import 'package:iaimei/res/string_res.dart';
import 'package:iaimei/style/app_text_style.dart';
import 'package:iaimei/utils/list_util.dart';
import 'package:iaimei/utils/page_jump_util.dart';
import 'package:iaimei/utils/string_util.dart';
import 'package:iaimei/utils/video_util.dart';
import 'package:iaimei/widget/app_back_widget.dart';
import 'package:iaimei/widget/app_tag_widget.dart';
import 'package:iaimei/widget/frosted_glass_box.dart';
import 'package:iaimei/widget/space_widget.dart';
import 'package:iaimei/widget/text_widget.dart';
import 'package:iaimei/widget/toast_widget.dart';

class SearchPage extends StatefulWidget {
  const SearchPage({Key? key}) : super(key: key);

  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends AppBaseWidgetState<SearchPage>
    with PageLoadMixin {
  List<String> searchHistoryTags = [];
  bool isShowResult = false;
  String _keywords = '';
  List<SearchSortList> searchSortList = [];
  late TextEditingController controller;
  late FocusNode focusNode;

  @override
  void initState() {
    super.initState();
    controller = TextEditingController();
    focusNode = FocusNode();
    List<String> tempSearchTags = AppGlobal.appBox!
        .get(AppConst.searchHistoryKey, defaultValue: <String>[]);
    if (ListUtil.isNotEmpty(tempSearchTags)) {
      searchHistoryTags = tempSearchTags;
    }
    onLoadData();
  }

  @override
  bool isResizeToAvoidBottomInset() {
    return false;
  }

  void onSubmitFunction(String value) {
    if (focusNode != null) {
      focusNode.unfocus();
    }

    if (StringUtil.isEmpty(value)) {
      ToastWidget.showToast('请输入搜索关键字');
      return;
    }
    if (value.length < 2) {
      ToastWidget.showToast('搜索关键字不少于两个字符');
      return;
    }

    setState(() {
      isShowResult = true;
      _keywords = value;
    });

    if (searchHistoryTags.contains(value)) {
      searchHistoryTags.remove(value);
    }
    searchHistoryTags.insert(0, value);

    if (searchHistoryTags.length > 30) {
      searchHistoryTags.removeLast();
    }
    AppGlobal.appBox!.put(AppConst.searchHistoryKey, searchHistoryTags);
  }

  @override
  onLoadData() {
    HttpHelper.searchIndex((data) {
      try {
        SearchIndexModel searchIndexModel = SearchIndexModel.fromJson(data);
        searchSortList = searchIndexModel.list ?? [];
        setPageState(ListUtil.isNotEmpty(searchHistoryTags) ||
            ListUtil.isNotEmpty(searchSortList));
      } catch (e) {
        setPageState(ListUtil.isNotEmpty(searchHistoryTags) ||
            ListUtil.isNotEmpty(searchSortList));
      }
    }, (error) {
      setPageErrorState(error);
    });
  }

  @override
  Widget successView() {
    return Visibility(
        visible: !isShowResult,
        replacement: SearchResultPage(
          keywords: _keywords,
        ),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ListUtil.isNotEmpty(searchHistoryTags)
                  ? Container(
                      margin: EdgeInsets.symmetric(
                          horizontal: DimenRes.dimen_15,
                          vertical: DimenRes.dimen_10),
                      alignment: Alignment.topLeft,
                      child: Text(
                        StringRes.str_search_history,
                        style: AppTextStyle.white_s18,
                      ),
                    )
                  : const SizedBox(),
              ListUtil.isNotEmpty(searchHistoryTags)
                  ? Container(
                      margin: EdgeInsets.symmetric(
                          horizontal: DimenRes.dimen_15,
                          vertical: DimenRes.dimen_10),
                      child: Wrap(
                        direction: Axis.horizontal,
                        alignment: WrapAlignment.start,
                        spacing: DimenRes.dimen_15,
                        runSpacing: DimenRes.dimen_12,
                        children: searchHistoryTags.map((tag) {
                          return AppTagWidget(
                            child: TextWidget.buildSingleLineText(
                                tag,
                                AppTextStyle.build(
                                    Colors.white.withOpacity(0.84), 14)),
                            onTap: () {
                              controller.text = tag;
                              onSubmitFunction(tag);
                            },
                          );
                        }).toList(),
                      ),
                    )
                  : const SizedBox(),
              ...searchSortList.map((sortItem) {
                return Container(
                  margin: EdgeInsets.symmetric(
                      horizontal: DimenRes.dimen_15,
                      vertical: DimenRes.dimen_10),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        alignment: Alignment.topLeft,
                        child: Text(
                          '${sortItem.name}',
                          style: AppTextStyle.white_s18,
                        ),
                      ),
                      SpaceWidget(
                        vSpace: DimenRes.dimen_12,
                      ),
                      sortItem.type == 'search'
                          ? _buildHotSearch(sortItem)
                          : _buildHotPlaySection(sortItem)
                    ],
                  ),
                );
              }).toList(),
            ],
          ),
        ));
  }

  Wrap _buildHotSearch(SearchSortList sortItem) {
    return Wrap(
      direction: Axis.horizontal,
      alignment: WrapAlignment.start,
      spacing: DimenRes.dimen_15,
      runSpacing: DimenRes.dimen_12,
      children: sortItem.data!.map((dataItem) {
        return AppTagWidget(
          child: TextWidget.buildSingleLineText('${dataItem.name}',
              AppTextStyle.build(Colors.white.withOpacity(0.84), 14)),
          onTap: () {
            controller.text = dataItem.value!;
            onSubmitFunction(dataItem.value!);
          },
        );
      }).toList(),
    );
  }

  _buildHotPlaySection(SearchSortList sortItem) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: sortItem.data!.asMap().keys.map((index) {
        return _buildHotPlayItem(index, sortItem);
      }).toList(),
    );
  }

  Widget _buildHotPlayItem(int index, SearchSortList sortItem) {
    return GestureDetector(
      child: Container(
        padding: EdgeInsets.only(bottom: DimenRes.dimen_15),
        child: Text.rich(
          TextSpan(children: [
            TextSpan(
                text: '${index + 1}',
                style: index < 3
                    ? AppTextStyle.cff00b3_s14_bold
                    : AppTextStyle.white_s14_bold),
            TextSpan(
              text: '    ${sortItem.data![index].name}',
              style: AppTextStyle.build(Colors.white.withOpacity(0.64), 14),
            )
          ]),
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
      ),
      onTap: () {
        // SearchSortData sortData = sortItem.data![index];
        // VideoModel videoModel = VideoModel();
        // videoModel.id = int.parse(sortData.value ?? '0');
        List<VideoModel> videoList = sortItem.data!.map((item) {
          VideoModel videoModel = VideoModel();
          videoModel.id = int.parse(item.value ?? '0');
          return videoModel;
        }).toList();
        VideoUtil.jumpToVideoPlayer(context, videoList, curIndex: index);
      },
    );
  }

  @override
  Widget buildPageLayout() {
    return GestureDetector(
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(10.0),
            child: SearchBarWidget(
              controller: controller,
              onSubmit: onSubmitFunction,
              onChange: (value) {
                setState(() {
                  isShowResult = false;
                  _keywords = value;
                });
              },
              focusNode: focusNode,
            ),
          ),
          Expanded(child: handlePageStateView())
        ],
      ),
      onTap: () {
        focusNode.unfocus();
      },
    );
  }
}

class SearchBarWidget extends StatefulWidget {
  final Function onSubmit;
  final Function? onChange;
  final TextEditingController controller;
  final FocusNode focusNode;

  const SearchBarWidget(
      {Key? key,
      required this.onSubmit,
      this.onChange,
      required this.controller,
      required this.focusNode})
      : super(key: key);

  @override
  State<SearchBarWidget> createState() => _SearchBarWidgetState();
}

class _SearchBarWidgetState extends State<SearchBarWidget> {
  late TextEditingController searchController;
  late FocusNode searchFocusNode;
  bool offstageStatus = true;

  @override
  void initState() {
    super.initState();
    searchController = widget.controller;
    searchFocusNode = widget.focusNode;
    searchController.addListener(() {
      setState(() {
        offstageStatus = searchController.text.isEmpty;
      });
    });
  }

  void handleSubmit(value) {
    searchFocusNode.unfocus();
    widget.onSubmit.call(value);
  }

  void handleChange(value) {
    widget.onChange!.call(value);
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        const AppBackWidget(),
        const SizedBox(
          width: 10,
        ),
        Expanded(
          child: FrostedGlassSimpleBox(
            width: double.infinity,
            height: DimenRes.dimen_36,
            borderRadius: BorderRadius.all(
              Radius.circular(DimenRes.radius(12)),
            ),
            child: TextField(
              onSubmitted: handleSubmit,
              controller: searchController,
              focusNode: searchFocusNode,
              onChanged: handleChange,
              maxLines: 1,
              cursorColor: const Color.fromARGB(30, 129, 129, 129),
              textInputAction: TextInputAction.search,
              keyboardType: TextInputType.text,
              textAlignVertical: TextAlignVertical.center,
              autofocus: false,
              maxLength: 30,
              style: TextStyle(
                  fontSize: DimenRes.sp(12),
                  color: const Color.fromRGBO(255, 255, 255, 0.84)),
              decoration: InputDecoration(
                prefixIcon: Padding(
                  padding: EdgeInsets.symmetric(
                      vertical: ScreenUtil().setWidth(10),
                      horizontal: ScreenUtil().setWidth(10)),
                  child: InputIcon(
                    url: ImgRes.IC_PRE_SEARCH,
                  ),
                ),
                suffixIcon: Offstage(
                  offstage: offstageStatus,
                  child: Padding(
                    padding: EdgeInsets.symmetric(
                        vertical: ScreenUtil().setWidth(7),
                        horizontal: ScreenUtil().setWidth(7)),
                    child: InputIcon(
                      onTap: () {
                        searchController.clear();
                        handleChange('');
                      },
                      url: ImgRes.IC_SUF_CLEAR,
                    ),
                  ),
                ),
                hintStyle: TextStyle(
                    fontSize: ScreenUtil().setSp(12),
                    color: const Color(0xffb4b4b4)),
                hintText: "请输入关键字",
                counterText: '',
                border: const OutlineInputBorder(
                  borderSide: BorderSide.none,
                ),
                contentPadding: EdgeInsets.zero,
              ),
            ),
          ),
        ),
        const SizedBox(
          width: 10,
        ),
        ActionIcon(
            onTap: () {
              PageJumpUtil.forwardToSortPage(context);
            },
            url: ImgRes.IC_MORE),
        const SpaceWidget(hSpace: 3),
        ActionIcon(
            onTap: () {
              PageJumpUtil.forwardToFilterPage(context);
            },
            url: ImgRes.IC_FILTER),
      ],
    );
  }
}

class InputIcon extends StatelessWidget {
  final GestureTapCallback? onTap;
  final String url;

  const InputIcon({Key? key, this.onTap, required this.url}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: ScreenUtil().setWidth(13),
        height: ScreenUtil().setWidth(13),
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage(url),
            fit: BoxFit.contain,
          ),
        ),
      ),
    );
  }
}
