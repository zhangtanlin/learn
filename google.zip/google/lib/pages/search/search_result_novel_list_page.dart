import 'package:flutter/material.dart';
import 'package:iaimei/base/base_widget_state.dart';
import 'package:iaimei/mixin/list_page_load_mixin.dart';
import 'package:iaimei/model/novel_item_model.dart';
import 'package:iaimei/model/search_novel_model.dart';
import 'package:iaimei/net/http_error.dart';
import 'package:iaimei/net/http_helper.dart';
import 'package:iaimei/pages/novel/novel_item_widget.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/utils/list_util.dart';
import 'package:iaimei/utils/page_jump_util.dart';
import 'package:iaimei/widget/list_widget.dart';
import 'package:iaimei/widget/refresh_load_list_widget.dart';

class SearchResultNovelListPage extends StatefulWidget {
  final String? keywords;

  const SearchResultNovelListPage({Key? key, this.keywords}) : super(key: key);

  @override
  State<SearchResultNovelListPage> createState() =>
      _SearchResultNovelListPageState();
}

class _SearchResultNovelListPageState
    extends BaseWidgetState<SearchResultNovelListPage> with ListPageLoadMixin {
  List<NovelItemModel> _novelList = [];

  @override
  void initState() {
    super.initState();
    onLoadData();
  }

  @override
  Widget buildPageLayout() {
    return handlePageStateView();
  }

  @override
  onLoadData() {
    onRefreshList();
  }

  @override
  void requestListData(bool isRefresh) {
    HttpHelper.searchNovelList(widget.keywords ?? '', getCurPage, getPageSize,
        (data) {
      try {
        SearchNovelModel searchNovelModel = SearchNovelModel.fromJson(data);
        _novelList = searchNovelModel.list ?? [];
        setListPageState(isRefresh, ListUtil.isNotEmpty(_novelList), () {
          updatePageList(isRefresh, _novelList);
        });
      } catch (e) {
        setListPageErrorState(isRefresh, HttpError());
      }
    }, (error) {
      setListPageErrorState(isRefresh, error);
    });
  }

  @override
  Widget successView() {
    return RefreshLoadListWidget(
        enableRefresh: isEnableLoad(),
        enableLoad: isEnableLoad(),
        onRefresh: onRefreshList,
        onLoad: onLoadList,
        child: Container(
            margin: EdgeInsets.symmetric(
                horizontal: DimenRes.dimen_15, vertical: DimenRes.dimen_10),
            child: _buildNovelGridView(getResultList)),
        refreshController: refreshController);
  }

  _buildNovelGridView(List resultList) {
    return ListWidget.buildGridView(
        itemCount: resultList.length,
        itemBuilder: (context, index) =>
            _buildComicsItem(resultList[index] as NovelItemModel),
        childRatio: 0.618,
        mainSpace: DimenRes.dimen_15,
        crossSpace: DimenRes.dimen_15,
        crossCount: 3);
  }

  _buildComicsItem(NovelItemModel item) {
    double width = (DimenRes.screenWidth - DimenRes.dimen_60) / 3;
    double height = width * 7 / 5;
    return InkWell(
      child:
          NovelItemWidget(itemData: item, imgWidth: width, imgHeight: height),
      onTap: () {
        PageJumpUtil.forwardToNovelDetailPage(context, item);
      },
    );
  }
}
