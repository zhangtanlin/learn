import 'package:flutter/material.dart';
import 'package:iaimei/base/base_widget_state.dart';
import 'package:iaimei/mixin/list_page_load_mixin.dart';
import 'package:iaimei/model/comics_item_model.dart';
import 'package:iaimei/model/search_comics_model.dart';
import 'package:iaimei/net/http_error.dart';
import 'package:iaimei/net/http_helper.dart';
import 'package:iaimei/pages/comics/comics_list_item_widget.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/utils/list_util.dart';
import 'package:iaimei/utils/page_jump_util.dart';
import 'package:iaimei/widget/list_widget.dart';
import 'package:iaimei/widget/refresh_load_list_widget.dart';

class SearchResultComicsListPage extends StatefulWidget {
  final String? keywords;

  const SearchResultComicsListPage({Key? key, this.keywords}) : super(key: key);

  @override
  State<SearchResultComicsListPage> createState() =>
      _SearchResultComicsListPageState();
}

class _SearchResultComicsListPageState
    extends BaseWidgetState<SearchResultComicsListPage> with ListPageLoadMixin {
  List<ComicsItemModel> _comicsList = [];

  @override
  void initState() {
    super.initState();
    onLoadData();
  }

  @override
  Widget buildPageLayout() {
    return handlePageStateView();
  }

  @override
  onLoadData() {
    onRefreshList();
  }

  @override
  void requestListData(bool isRefresh) {
    HttpHelper.searchComicsList(widget.keywords ?? '', getCurPage, getPageSize,
        (data) {
      try {
        SearchComicsModel searchComicsModel = SearchComicsModel.fromJson(data);
        _comicsList = searchComicsModel.list ?? [];
        setListPageState(isRefresh, ListUtil.isNotEmpty(_comicsList), () {
          updatePageList(isRefresh, _comicsList);
        });
      } catch (e) {
        setListPageErrorState(isRefresh, HttpError());
      }
    }, (error) {
      setListPageErrorState(isRefresh, error);
    });
  }

  @override
  Widget successView() {
    return RefreshLoadListWidget(
        enableRefresh: isEnableLoad(),
        enableLoad: isEnableLoad(),
        onRefresh: onRefreshList,
        onLoad: onLoadList,
        child: Container(
            margin: EdgeInsets.symmetric(
                horizontal: DimenRes.dimen_15, vertical: DimenRes.dimen_10),
            child: _buildComicsGridView(getResultList)),
        refreshController: refreshController);
  }

  _buildComicsGridView(List resultList) {
    return ListWidget.buildGridView(
        itemCount: resultList.length,
        itemBuilder: (context, index) =>
            _buildComicsItem(resultList[index] as ComicsItemModel),
        childRatio: 0.618,
        mainSpace: DimenRes.dimen_15,
        crossSpace: DimenRes.dimen_15,
        crossCount: 3);
  }

  _buildComicsItem(ComicsItemModel item) {
    double width = (DimenRes.screenWidth - DimenRes.dimen_60) / 3;
    double height = width * 7 / 5;
    return InkWell(
      child: ComicsListItemWidget(
          itemData: item, imgWidth: width, imgHeight: height),
      onTap: () {
        PageJumpUtil.forwardToComicsDetailPage(context, item);
      },
    );
  }
}
