import 'package:flutter/material.dart';
import 'package:flutter_html/shims/dart_ui_real.dart';
import 'package:iaimei/base/base_widget_state.dart';
import 'package:iaimei/mixin/list_page_load_mixin.dart';
import 'package:iaimei/model/atlas_item_model.dart';
import 'package:iaimei/model/search_atlas_model.dart';
import 'package:iaimei/net/http_error.dart';
import 'package:iaimei/net/http_helper.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/style/app_text_style.dart';
import 'package:iaimei/utils/badge_util.dart';
import 'package:iaimei/utils/list_util.dart';
import 'package:iaimei/utils/page_jump_util.dart';
import 'package:iaimei/widget/app_img_widget.dart';
import 'package:iaimei/widget/list_widget.dart';
import 'package:iaimei/widget/network_img_container.dart';
import 'package:iaimei/widget/refresh_load_list_widget.dart';
import 'package:iaimei/widget/text_widget.dart';

class SearchResultAtlasListPage extends StatefulWidget {
  final String? keywords;

  const SearchResultAtlasListPage({Key? key, this.keywords}) : super(key: key);

  @override
  State<SearchResultAtlasListPage> createState() =>
      _SearchResultAtlasListPageState();
}

class _SearchResultAtlasListPageState
    extends BaseWidgetState<SearchResultAtlasListPage> with ListPageLoadMixin {
  List<AtlasItemModel> _atlasList = [];

  @override
  void initState() {
    super.initState();
    onLoadData();
  }

  @override
  Widget buildPageLayout() {
    return handlePageStateView();
  }

  @override
  onLoadData() {
    onRefreshList();
  }

  @override
  void requestListData(bool isRefresh) {
    HttpHelper.searchAtlasList(widget.keywords ?? '', getCurPage, getPageSize,
        (data) {
      try {
        SearchAtlasModel searchAtlasModel = SearchAtlasModel.fromJson(data);
        _atlasList = searchAtlasModel.list ?? [];

        setListPageState(isRefresh, ListUtil.isNotEmpty(_atlasList), () {
          updatePageList(isRefresh, _atlasList);
        });
      } catch (e) {
        setListPageErrorState(isRefresh, HttpError());
      }
    }, (error) {
      setListPageErrorState(isRefresh, error);
    });
  }

  @override
  Widget successView() {
    return RefreshLoadListWidget(
        enableRefresh: isEnableLoad(),
        enableLoad: isEnableLoad(),
        onRefresh: onRefreshList,
        onLoad: onLoadList,
        child: Container(
            margin: EdgeInsets.symmetric(
                horizontal: DimenRes.dimen_3, vertical: DimenRes.dimen_10),
            child: _buildVideoListSection(getResultList)),
        refreshController: refreshController);
  }

  _buildVideoListSection(List resultList) {
    return ListWidget.buildGridView(
        itemCount: resultList.length,
        childRatio: 0.625,
        crossCount: 2,
        mainSpace: DimenRes.dimen_3,
        crossSpace: DimenRes.dimen_3,
        itemBuilder: (BuildContext context, int index) {
          return InkWell(
            onTap: () {
              PageJumpUtil.forwardToAtlasDetailPage(context, resultList[index] as AtlasItemModel);
            },
            child: _buildVideoItem(resultList[index] as AtlasItemModel),
          );
        });
  }

  _buildVideoItem(AtlasItemModel atlasModel) {
    double tempWidth = (DimenRes.screenWidth - DimenRes.dimen_6) / 2;
    return Stack(
      children: [
        NetworkImgContainer(
          width: double.infinity,
          height: double.infinity,
          url: '${atlasModel.thumbFull}',
          radius: BorderRadius.circular(10),
        ),
        ClipRRect(
          borderRadius: BorderRadius.circular(10),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 40, sigmaY: 40),
            child: Opacity(
              opacity: 0.2,
              child: Container(
                width: double.infinity,
                height: double.infinity,
                decoration: BoxDecoration(color: Colors.white.withOpacity(0.2)),
              ),
            ),
          ),
        ),
        Column(
          children: [
            Stack(
              children: [
                NetworkImgContainer(
                  width: double.infinity,
                  height: tempWidth * 4 / 3,
                  url: '${atlasModel.thumbFull}',
                  radius: const BorderRadius.only(
                      topRight: Radius.circular(10),
                      topLeft: Radius.circular(10)),
                ),
                Positioned(
                    right: DimenRes.dimen_5,
                    top: DimenRes.dimen_5,
                    child: AppImgWidget(
                      path: BadgeUtil.getVideoTypeBadgeImgPath(
                          atlasModel.isType!),
                      width: DimenRes.dimen_36,
                      height: DimenRes.dimen_18,
                    ))
              ],
            ),
            Container(
              alignment: Alignment.topLeft,
              padding: EdgeInsets.symmetric(
                  horizontal: DimenRes.dimen_8, vertical: DimenRes.dimen_5),
              child: TextWidget.build(
                  atlasModel.title ?? '', AppTextStyle.white_s12,
                  maxLines: 2, overflow: TextOverflow.ellipsis),
            )
          ],
        ),
      ],
    );
  }
}
