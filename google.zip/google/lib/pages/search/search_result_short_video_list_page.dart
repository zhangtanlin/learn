import 'package:flutter/material.dart';
import 'package:iaimei/base/base_widget_state.dart';
import 'package:iaimei/components/card/card_video.dart';
import 'package:iaimei/mixin/list_page_load_mixin.dart';
import 'package:iaimei/model/search_video_model.dart';
import 'package:iaimei/model/video_model.dart';
import 'package:iaimei/net/http_error.dart';
import 'package:iaimei/net/http_helper.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/utils/list_util.dart';
import 'package:iaimei/utils/video_util.dart';
import 'package:iaimei/widget/list_widget.dart';
import 'package:iaimei/widget/refresh_load_list_widget.dart';

class SearchResultShortVideoListPage extends StatefulWidget {
  final String? keywords;

  const SearchResultShortVideoListPage({Key? key, this.keywords})
      : super(key: key);

  @override
  State<SearchResultShortVideoListPage> createState() =>
      _SearchResultShortVideoListPageState();
}

class _SearchResultShortVideoListPageState
    extends BaseWidgetState<SearchResultShortVideoListPage>
    with ListPageLoadMixin {
  List<VideoModel> _videoList = [];

  @override
  Widget buildPageLayout() {
    return handlePageStateView();
  }

  @override
  void initState() {
    super.initState();
    onLoadData();
  }

  @override
  onLoadData() {
    onRefreshList();
  }

  @override
  void requestListData(bool isRefresh) {
    HttpHelper.searchShortVideoList(
        widget.keywords ?? '', getCurPage, getPageSize, (data) {
      try {
        SearchVideoModel searchVideoModel = SearchVideoModel.fromJson(data);
        _videoList = searchVideoModel.list ?? [];

        setListPageState(isRefresh, ListUtil.isNotEmpty(_videoList), () {
          updatePageList(isRefresh, _videoList);
        });
      } catch (e) {
        setListPageErrorState(isRefresh, HttpError());
      }
    }, (error) {
      setListPageErrorState(isRefresh, error);
    });
  }

  @override
  Widget successView() {
    return RefreshLoadListWidget(
        enableRefresh: isEnableLoad(),
        enableLoad: isEnableLoad(),
        onRefresh: onRefreshList,
        onLoad: onLoadList,
        child: Container(
            margin: EdgeInsets.symmetric(
                horizontal: DimenRes.dimen_3, vertical: DimenRes.dimen_10),
            child: _buildVideoListSection(getResultList)),
        refreshController: refreshController);
  }

  _buildVideoListSection(List resultList) {
    return ListWidget.buildGridView(
        itemCount: resultList.length,
        childRatio: 0.625,
        crossCount: 2,
        mainSpace: DimenRes.dimen_3,
        crossSpace: DimenRes.dimen_3,
        itemBuilder: (BuildContext context, int index) {
          return InkWell(
            onTap: () {
              VideoUtil.jumpToVideoPlayer(
                  context, resultList as List<VideoModel>,
                  curIndex: index);
            },
            child: _buildVideoItem(resultList[index] as VideoModel),
          );
        });
  }

  _buildVideoItem(VideoModel videoModel) {
    double tempWidth = (DimenRes.screenWidth - DimenRes.dimen_6) / 2;
    return CardVideoFilter(
      width: tempWidth,
      type: 2,
      videoModel: videoModel,
    );
  }
}
