import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:iaimei/utils/api.dart';
import 'package:iaimei/widget/buttom_widget.dart';
import 'package:iaimei/widget/convenient_mixin.dart';
import 'package:iaimei/widget/toast_widget.dart';

class RewardList extends StatefulWidget {
  const RewardList(
      {Key? key,
      required this.id,
      this.type = 0,
      required this.coins,
      required this.list})
      : super(key: key);
  final int id;
  final int type;
  final List list;
  final String coins;

  @override
  State<RewardList> createState() => _RewardListState();
}

class _RewardListState extends State<RewardList> with ConvenientMixin {
  String gid = '';

  @override
  void initState() {
    super.initState();
    if (widget.list.isNotEmpty) {
      gid = widget.list[0].gid;
    }
  }

  void onSubmit() {
    if (gid.isEmpty) return;
    // type 0 创造者 1 裸聊
    apiChatReward(uid: widget.id, gid: gid, type: widget.type).then((res) {
      if (res?.status == 1) {
        Navigator.pop(context);
        ToastWidget.showToast(res?.msg ?? '打赏成功');
      } else {
        ToastWidget.showToast(res?.msg ?? '打赏失败');
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(height: 40.w),
          Wrap(
            spacing: 10.w,
            runSpacing: 10.w,
            children: widget.list.map((item) {
              return _buildOptionWidget(item.gid, item.value);
            }).toList(),
          ),
          SizedBox(height: 20.w),
          ButtonWidget.build('打赏', onTap: onSubmit),
          SizedBox(height: 12.w),
          _buildOverPmWidget(),
          SizedBox(height: 30.w),
        ],
      ),
    );
  }

  Widget _buildOverPmWidget() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(
          '当前余额 ¥${widget.coins}',
          style: TextStyle(color: wColor, fontSize: 12.w),
        ),
        SizedBox(width: 20.w),
        GestureDetector(
          onTap: () {
            context.push('/rechargeCoins');
            Navigator.of(context).pop();
          },
          child: Text(
            "去充值 ＞＞",
            style: TextStyle(color: rColor, fontSize: 12.w, fontWeight: fontM),
          ),
        )
      ],
    );
  }

  Widget _buildOptionWidget(index, value) {
    return GestureDetector(
      onTap: () => setState(() => gid = index),
      child: Container(
        height: 44.w,
        width: 88.w,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12.w),
          border: Border.all(
            width: 1.5.w,
            color: index == gid ? rColor : Colors.transparent,
          ),
          color: const Color(0x1f000000),
        ),
        clipBehavior: Clip.hardEdge,
        child: Center(
          child: Text(
            "￥$value",
            style: TextStyle(
              color: index == gid ? rColor : wColor,
              fontSize: 14.sp,
              fontWeight: fontM,
            ),
          ),
        ),
      ),
    );
  }
}
