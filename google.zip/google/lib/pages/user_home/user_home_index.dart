import 'package:bot_toast/bot_toast.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:iaimei/components/common/base_dialog.dart';
import 'package:iaimei/components/common/commonelements.dart';
import 'package:iaimei/components/common/pageviewmixin.dart';
import 'package:iaimei/components/common/stackpage.dart';
import 'package:iaimei/model/reward_set.dart';
import 'package:iaimei/model/userhome_model.dart';
import 'package:iaimei/net/http_helper.dart';
import 'package:iaimei/pages/mv/nav_tab_bar_mixin.dart';
import 'package:iaimei/pages/user_home/join_fans_club.dart';
import 'package:iaimei/pages/user_home/reward_list.dart';
import 'package:iaimei/pages/user_home/user_home_page.dart';
import 'package:iaimei/router/routers.dart';
import 'package:iaimei/store/userdata.dart';
import 'package:iaimei/utils/api.dart';
import 'package:iaimei/widget/buttom_widget.dart';
import 'package:iaimei/widget/convenient_mixin.dart';
import 'package:iaimei/widget/nested_scroll_view_ext.dart';
import 'package:iaimei/widget/network_img_container.dart';
import 'package:provider/provider.dart';

class UserHomeIndex extends StatefulWidget {
  const UserHomeIndex({Key? key, this.uid}) : super(key: key);
  final dynamic uid;

  @override
  State<UserHomeIndex> createState() => _UserHomeIndexState();
}

class _UserHomeIndexState extends State<UserHomeIndex>
    with TickerProviderStateMixin, ConvenientMixin {
  late TabController tabController;
  late UserHomeData data;
  bool isError = false;
  bool isloading = true;
  List<String> tabs = ['视频', '粉丝团专属'];

  @override
  void initState() {
    super.initState();
    tabController = TabController(length: tabs.length, vsync: this);
    initData();
  }

  void initData() {
    //
    apiUsersHomeInfo(uid: widget.uid).then((res) {
      // // 14115346
      // // 14115117
      // apiUsersHomeInfo(uid: '14115346').then((res) {
      isloading = false;
      if (res != null) {
        data = res.data!;
        isError = false;
        setState(() {});
      } else {
        isError = true;
        setState(() {});
      }
    });
  }

  void onAttention() {
    BotToast.showLoading();
    HttpHelper.attentCreator({'to_uid': data.uid}, (data) {
      BotToast.closeAllLoading();
      // BotToast.showText(text: data['msg'] ?? '操作成功');
      this.data.isAttention = data['is_attention'] ?? 0;
      setState(() {});
    }, (error) {
      BotToast.closeAllLoading();
      BotToast.showText(text: error.message ?? '未知错误');
    });
  }

  void onDatingAction() {
    // 无条件
    if (data.maker == null) {
      return;
    }
    // 约炮
    else if (data.maker?.isLfeng == 1) {
      context.push('/${Routes.datingDetail}', extra: {'uid': data.uid});
    }
    // 裸聊
    else if (data.maker?.isLive == 1) {
      context.push('/${Routes.chatDetail}', extra: {'uid': data.uid});
    }
  }

  void onRewardAction() {
    BotToast.showLoading();
    HttpHelper.rewardGiftList((data) {
      BotToast.closeAllLoading();
      try {
        if (data['gifts'] != null && data['gifts'] is List) {
          var gifts = data['gifts'].map<RewardSet>((json) {
            return RewardSet.fromJson(json);
          }).toList();
          BaseDialog.showdialog(
            context,
            insetPadding: 30.w,
            barrierDismissible: true,
            child: RewardList(
              id: this.data.uid,
              list: gifts,
              type: 0,
              coins: data['member']['coins'],
            ),
          );
        }
      } catch (e) {
        debugPrint(e.toString());
      }
    }, (error) {
      BotToast.closeAllLoading();
      BotToast.showText(text: error.message ?? '未知错误');
    });
  }

  void onJoinFansClubAction() {
    if (data.club == null) {
      BotToast.showText(text: '作者没有粉丝团');
      return;
    }
    BaseDialog.showdialog(
      context,
      barrierDismissible: true,
      insetPadding: 30.w,
      child: JoinFansClub(
        club: data.club!,
        callback: () => setState(() {}),
      ),
    );
  }

  void onMessageAction() {
    var user = Provider.of<UserData>(context, listen: false).userInfo;
    if (user.vipLevel < 3) {
      BaseDialog.showdialog(
        context,
        insetPadding: 30.w,
        barrierDismissible: true,
        child: Column(
          children: [
            SizedBox(height: 40.w),
            Text(
              '提示',
              style:
                  TextStyle(color: wColor, fontSize: 18.sp, fontWeight: fontM),
            ),
            SizedBox(height: 10.w),
            Text(
              '半年卡以上VIP会员可留言',
              style: TextStyle(color: rColor, fontWeight: fontM),
            ),
            SizedBox(height: 20.w),
            ButtonWidget.build(
              '去开通',
              onTap: () => context.push('/${Routes.rechargeVip}'),
            ),
            SizedBox(height: 20.w),
          ],
        ),
      );
    } else {
      context.push('/' + Routes.msgBoard);
    }
  }

  @override
  Widget build(BuildContext context) {
    return StackPage(
      header: CustomHeader(rListWidget: [
        GestureDetector(
          onTap: onMessageAction,
          child: Image.asset(
            "assets/images/common/action_message.png",
            width: 36.w,
            height: 36.w,
          ),
        ),
        SizedBox(width: 16.w),
      ]),
      child: Stack(children: [
        _buildContainerWidget(),
        Positioned(
          left: 0,
          right: 0,
          bottom: 35.w,
          child: ButtonWidget.build('打赏作者', onTap: onRewardAction),
        ),
      ]),
    );
  }

  Widget _buildContainerWidget() {
    if (isloading) {
      return loadingWiget();
    }
    if (isError) {
      return errorWidget();
    }
    bool isJson = data.club != null && data.club?.isJoin == false;
    return NestedScrollViewExt(
      onlyOneScrollInBody: true,
      headerSliverBuilder: (ctx, innerBoxIsScrolled) {
        return [
          SliverToBoxAdapter(child: _buildHeaderViewWidget()),
          SliverToBoxAdapter(
            child: Container(
              height: 54.0.w,
              decoration: _buildDecorationImage(2),
              padding: EdgeInsets.only(top: isJson ? 0 : 10.w),
              child: _buildNavigatorTabBarWidget(),
            ),
          ),
        ];
      },
      pinnedHeaderSliverHeightBuilder: () => 44.w + (isJson ? 10.w : 0),
      body: _buildTabBarViewWidget(),
    );
  }

  Widget _buildNavigatorTabBarWidget() {
    return NavTabBarWidget(
      tabVc: tabController,
      tabs: tabs,
      isScrollable: false,
      norTextStyle: TextStyle(
          color: wColor, fontSize: 15.sp, fontWeight: FontWeight.w400),
      selTextStyle:
          TextStyle(color: rColor, fontSize: 15.sp, fontWeight: fontM),
    );
  }

  Widget _buildTabBarViewWidget() {
    return TabBarView(
      controller: tabController,
      children: tabs.asMap().keys.map<Widget>((index) {
        switch (index) {
          case 0:
            return PageViewMixin(
              child: UserHomePage(index: index, id: data.uid),
            );
          default:
            return PageViewMixin(
              child: UserHomePage(
                index: index,
                id: data.club?.id ?? '',
                isJoin: data.club?.isJoin ?? false,
                callback: onJoinFansClubAction,
              ),
            );
        }
      }).toList(),
    );
  }

  Widget _buildHeaderViewWidget() {
    return Column(children: [
      Row(children: [
        Container(
          height: 68.w,
          width: 68.w,
          margin: EdgeInsets.fromLTRB(16.w, 8.w, 21.w, 8.w),
          decoration: BoxDecoration(
            border: Border.all(color: Colors.white24, width: 3.w),
            borderRadius: BorderRadius.circular(20.w),
          ),
          child: NetworkImgContainer(
              radius: BorderRadius.circular(18.w),
              url: data.avatarUrl,
              fit: BoxFit.cover),
        ),
        Expanded(
          child: Row(
            children: [
              Expanded(child: _buildSmallPartWidget('粉丝', data.fansCount)),
              Container(width: 1, height: 10, color: Colors.white24),
              Expanded(child: _buildSmallPartWidget('关注', data.followedCount)),
              Container(width: 1, height: 10, color: Colors.white24),
              Expanded(child: _buildSmallPartWidget('获赞', data.fabulousCount)),
            ],
          ),
        ),
        SizedBox(width: 16.w),
      ]),
      SizedBox(
        height: 44.w,
        child: Row(children: [
          SizedBox(width: 16.w),
          Expanded(child: _buildNickNameWidget()),
          Offstage(
            offstage: data.maker == null ||
                (data.maker?.isLfeng != 1 && data.maker?.isLive != 1),
            child: ButtonWidget.build('约她',
                style: IconStyle.pink_68_34, onTap: onDatingAction),
          ),
          SizedBox(width: 5.w),
          ButtonWidget.bgText(
            data.isAttention == 1 ? '已关注' : '关注',
            data.isAttention == 1
                ? "assets/images/button/btn_black.png"
                : "assets/images/button/btn_small.png",
            size: Size(68.w, 34.w),
            onTap: onAttention,
          ),
          SizedBox(width: 16.w),
        ]),
      ),
      _buildSubscriptWidget(),
      data.club != null && data.club?.isJoin != true
          ? _buildFansClubWidget()
          : const SizedBox()
    ]);
  }

  BoxDecoration? _buildDecorationImage(int index) {
    var sub = index == 2 ? '_shadow' : '';
    var path = "assets/images/other/userhome_fansgroup$sub.png";
    return data.club != null && data.club?.isJoin == false
        ? BoxDecoration(image: DecorationImage(image: AssetImage(path)))
        : null;
  }

  Widget _buildNickNameWidget() {
    return Row(
      children: [
        Flexible(
          child: FittedBox(
            fit: BoxFit.scaleDown,
            child: Text(
              data.nickname,
              style: TextStyle(
                  color: color_84, fontSize: 20.sp, fontWeight: fontB),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ),
        )
      ],
    );
  }

  Widget _buildSubscriptWidget() {
    var subscript = (data.maker?.toJson() ?? {})
        .entries
        .where((item) => item.value > 0)
        .toList();
    if (data.vipLevel > 0) subscript.add(MapEntry('is_vip', data.vipLevel));
    var icons = subscript
        .map((item) {
          switch (item.key) {
            case 'is_up':
              return 'assets/images/common/grade_up.png';
            case 'is_live':
              return 'assets/images/common/grade_chat.png';
            case 'is_lfeng':
              return 'assets/images/common/grade_girl.png';

            case 'is_jjren':
              return 'assets/images/common/grade_agent.png';
            // case 'is_face':
            //    return 'assets/images/common/grade_vip.png';
            case 'is_vip':
              return 'assets/images/common/grade_vip.png';
            default:
              return '';
          }
        })
        .where((item) => item.isNotEmpty)
        .toList();
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 16.w),
      child: Row(
        children: icons
            .map((path) => Container(
                  padding: EdgeInsets.only(right: 5.w, bottom: 5.w),
                  child: Image.asset(path, height: 14.w),
                ))
            .toList(),
      ),
    );
  }

  Widget _buildSmallPartWidget(title, number) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text('$title',
            style: TextStyle(color: color_64, fontSize: 12.sp),
            textAlign: TextAlign.center),
        SizedBox(height: 5.w),
        Text('$number',
            style:
                TextStyle(color: color_84, fontWeight: fontM, fontSize: 14.sp),
            textAlign: TextAlign.center),
      ],
    );
  }

  Widget _buildFansClubWidget() {
    return Container(
      margin: EdgeInsets.only(top: 10.w),
      height: 100.w,
      width: double.infinity,
      decoration: _buildDecorationImage(1),
      padding: EdgeInsets.fromLTRB(26.w, 10.w, 26.w, 12.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text.rich(
            TextSpan(children: [
              TextSpan(
                text: '¥${data.club?.month}', // 变更需求
                style: TextStyle(color: rColor),
              ),
              TextSpan(text: '加入她的粉丝团，', style: TextStyle(color: wColor)),
              TextSpan(text: '免费', style: TextStyle(color: rColor)),
              TextSpan(text: '观看粉丝团专属视频', style: TextStyle(color: wColor)),
            ]),
            style: TextStyle(fontSize: 13.sp, fontWeight: fontM),
          ),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text.rich(
              TextSpan(
                children: [
                  TextSpan(
                    text: '${data.club?.count}',
                    style: TextStyle(color: rColor),
                  ),
                  const TextSpan(
                    text: '人已加入',
                    style: TextStyle(color: Color(0xebffffff)),
                  ),
                ],
                style: TextStyle(fontWeight: fontB, fontSize: 12.sp),
              ),
            ),
            // SizedBox(width: 20.w),
            ButtonWidget.bgText(
              '加入',
              "assets/images/button/btn_small.png",
              size: Size(78.w, 42.w),
              onTap: onJoinFansClubAction,
            )
          ])
        ],
      ),
    );
  }
}
