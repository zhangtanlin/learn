import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:iaimei/store/userdata.dart';
import 'package:iaimei/widget/buttom_widget.dart';
import 'package:iaimei/widget/convenient_mixin.dart';
import 'package:provider/provider.dart';

class UnlockFansVideo extends StatefulWidget {
  const UnlockFansVideo({Key? key, this.coins, this.callback})
      : super(key: key);
  final dynamic coins;
  // 0 原价解锁， 1 加入粉丝团
  final void Function(int)? callback;
  @override
  State<UnlockFansVideo> createState() => _UnlockFansVideoState();
}

class _UnlockFansVideoState extends State<UnlockFansVideo>
    with ConvenientMixin {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(height: 40.w),
        Text.rich(
          TextSpan(
            children: [
              TextSpan(
                text: '¥${widget.coins} ',
                style: TextStyle(color: rColor),
              ),
              TextSpan(text: '解锁', style: TextStyle(color: wColor)),
            ],
          ),
          style: TextStyle(fontSize: 18.sp, fontWeight: fontB),
        ),
        SizedBox(height: 10.w),
        Text.rich(
          TextSpan(children: [
            TextSpan(text: '加入粉丝团', style: TextStyle(color: wColor)),
            TextSpan(
              text: '免费',
              style: TextStyle(color: rColor, fontWeight: fontB),
            ),
            TextSpan(text: '观看专属视频', style: TextStyle(color: wColor)),
          ]),
          style: TextStyle(fontSize: 14.sp),
        ),
        SizedBox(height: 30.w),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ButtonWidget.bgText(
              '原价解锁',
              'assets/images/button/btn_white_base.png',
              onTap: () {
                widget.callback?.call(0);
                Navigator.pop(context);
              },
            ),
            SizedBox(width: 18.w),
            ButtonWidget.build(
              '加入粉丝团',
              onTap: () {
                Navigator.pop(context);
                widget.callback?.call(1);
              },
            ),
          ],
        ),
        SizedBox(height: 12.w),
        _buildOverPmWidget(),
        SizedBox(height: 20.w),

      ],
    );
  }

  Widget _buildOverPmWidget() {
    var user = Provider.of<UserData>(context, listen: false).userInfo;
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(
          '当前余额 ¥${user.coins}',
          style: TextStyle(color: wColor, fontSize: 12.w),
        ),
        SizedBox(width: 20.w),
        GestureDetector(
          onTap: () {
            context.push('/rechargeCoins');
            Navigator.of(context).pop();
          },
          child: Text(
            "去充值 ＞＞",
            style: TextStyle(color: rColor, fontSize: 12.w, fontWeight: fontM),
          ),
        )
      ],
    );
  }
}
