import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:iaimei/model/userhome_model.dart';
import 'package:iaimei/net/http_helper.dart';
import 'package:iaimei/store/userdata.dart';
import 'package:iaimei/utils/common.dart';
import 'package:iaimei/widget/buttom_widget.dart';
import 'package:iaimei/widget/convenient_mixin.dart';
import 'package:provider/provider.dart';

class JoinFansClub extends StatefulWidget {
  const JoinFansClub({Key? key, required this.club, this.callback})
      : super(key: key);
  final Club club;
  final void Function()? callback;
  @override
  State<JoinFansClub> createState() => _JoinFansClubState();
}

class _JoinFansClubState extends State<JoinFansClub> with ConvenientMixin {
  int selectIndex = 0;
  void onSubmit() {
    var type = 'month';
    switch (selectIndex) {
      case 0:
        type = 'month';
        break;
      case 1:
        type = 'quarter';
        break;
      case 3:
        type = 'year';
        break;
      default:
        type = 'long';
    }
    var param = {'id': widget.club.id, 'type': type};
    HttpHelper.joinFansClub(param, (data) {
      Navigator.pop(context);
      widget.club.isJoin = true;
      Method.showText(data ?? '加入成功');
      widget.callback?.call();
    }, (error) {
      Method.showText(error.message ?? '加入失败');
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(height: 40.w),
          Text(
            '加入粉丝团',
            style: TextStyle(color: wColor, fontSize: 16.sp, fontWeight: fontM),
          ),
          SizedBox(height: 20.w),
          Wrap(spacing: 15.w, runSpacing: 15.w, children: [
            _buildOptionWidget(0, '1个月', widget.club.month, selectIndex == 0),
            _buildOptionWidget(1, '3个月', widget.club.quarter, selectIndex == 1),
            _buildOptionWidget(2, '1年', widget.club.year, selectIndex == 2),
            _buildOptionWidget(3, '永久', widget.club.long, selectIndex == 3),
          ]),
          SizedBox(height: 20.w),
          ButtonWidget.build('加入', onTap: onSubmit),
          SizedBox(height: 15.w),
          _buildOverPmWidget(),
          SizedBox(height: 30.w),
        ],
      ),
    );
  }

  Widget _buildOverPmWidget() {
    var user = Provider.of<UserData>(context, listen: false).userInfo;
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(
          '当前余额 ¥${user.coins}',
          style: TextStyle(color: wColor, fontSize: 12.w),
        ),
        SizedBox(width: 20.w),
        GestureDetector(
          onTap: () {
            context.push('/rechargeCoins');
            Navigator.of(context).pop();
          },
          child: Text(
            "去充值 ＞＞",
            style: TextStyle(color: rColor, fontSize: 12.w, fontWeight: fontM),
          ),
        )
      ],
    );
  }

  Widget _buildOptionWidget(index, title, value, isSeleted) {
    return GestureDetector(
      onTap: () => setState(() => selectIndex = index),
      child: Container(
        width: 130.w,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12.w),
          border: Border.all(
              width: 1.5.w, color: isSeleted ? rColor : Colors.transparent),
        ),
        clipBehavior: Clip.hardEdge,
        child: Column(
          children: [
            Container(
              color: Colors.black.withOpacity(0.24),
              height: 28.w,
              child: Center(
                child: Text('$title',
                    style: TextStyle(color: wColor, fontSize: 12.w)),
              ),
            ),
            Container(
              color: Colors.black.withOpacity(0.12),
              height: 36.w,
              child: Center(
                child: Text(
                  "￥$value",
                  style: TextStyle(
                    color: isSeleted ? rColor : wColor,
                    fontWeight: fontB,
                    fontSize: 16.sp,
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
