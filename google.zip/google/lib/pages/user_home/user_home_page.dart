import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:iaimei/components/common/base_dialog.dart';
import 'package:iaimei/components/common/pullrefreshlist.dart';
import 'package:iaimei/model/video_model.dart';
import 'package:iaimei/net/http_helper.dart';
import 'package:iaimei/pages/mv/mv_list_page.dart';
import 'package:iaimei/pages/user_home/unlock_fans_video.dart';
import 'package:iaimei/utils/video_util.dart';
import 'package:iaimei/widget/convenient_mixin.dart';
import 'package:iaimei/widget/state_mixin.dart';

class UserHomePage extends StatefulWidget {
  const UserHomePage(
      {Key? key, this.index = 0, this.id, this.isJoin = false, this.callback})
      : super(key: key);
  final dynamic id;
  final int index;
  final bool isJoin;
  final void Function()? callback;

  @override
  State<UserHomePage> createState() => _UserHomePageState();
}

class _UserHomePageState extends State<UserHomePage>
    with ConvenientMixin, StateMixin {
  @override
  void initLoadingData() {
    var param = this.param;
    if (widget.index == 0) {
      param['uid'] = widget.id;
      HttpHelper.creatorVideo(param, (data) {
        var list = [];
        try {
          list = data.map((item) => VideoModel.fromJson(item)).toList();
        } catch (e) {
          debugPrint(e.toString());
        }
        updateListAndWidgetState(list);
      }, dealWithErrorsWidgetState);
    }
    if (widget.index == 1) {
      param['club_id'] = widget.id;
      if ('${widget.id}'.isEmpty) {
        updateListAndWidgetState([]);
        return;
      }
      HttpHelper.fansClubVideo(param, (data) {
        var list = [];
        try {
          list = data.map((item) => VideoModel.fromJson(item)).toList();
        } catch (e) {
          debugPrint(e.toString());
        }
        updateListAndWidgetState(list);
      }, dealWithErrorsWidgetState);
    }
  }

  void onTap(List list, int index) {
    // 去播放
    void toPlay(List list, int idx) {
      List<VideoModel> videoList =
          list.map((item) => item as VideoModel).toList();
      VideoUtil.jumpToVideoPlayer(context, videoList, curIndex: idx);
    }

    if (widget.index == 1 && widget.isJoin == false) {
      BaseDialog.showdialog(
        context,
        insetPadding: 30.w,
        barrierDismissible: true,
        child: UnlockFansVideo(
          coins: list[index].coins,
          callback: (index) {
            switch (index) {
              case 1: // 加入粉丝团
                widget.callback?.call();
                break;
              default: // 原价购买
                toPlay(list, index); //
            }
          },
        ),
      );
      return;
    }
    toPlay(list, index); //
  }

  @override
  Widget noDataWidget() {
    return buildDataWidget(
      icon: 'assets/images/common/ic_load_error.png',
      content: '暂无数据',
      tipHidden: true,
    );
  }

  @override
  Widget build(BuildContext context) {
    if (widgetState != WidgetState.finish &&
        widgetState != WidgetState.noData) {
      return placeholderWidget();
    }
    return PullRefreshList(
      isAll: isAll,
      child: MvListPage(
        topPadding: 3.w,
        type: 2,
        dataList: dataList,
        onPlayer: (idx) {
          return () => onTap(dataList, idx);
        } 
      ),
      onRefresh: onRefresh,
      onLoading: onLoading,
    );
  }
}
