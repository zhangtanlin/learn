import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:iaimei/components/card/card_space_between.dart';
import 'package:iaimei/components/common/avatar.dart';
import 'package:iaimei/components/common/glassmorphism.dart';
import 'package:iaimei/components/common/head.dart';
import 'package:iaimei/components/common/pagestatus.dart';
import 'package:iaimei/components/common/stackpage.dart';
import 'package:iaimei/model/model_dating_order.dart';
import 'package:iaimei/theme/default.dart';
import 'package:iaimei/utils/api.dart';
import 'package:iaimei/utils/common.dart';

/// 约炮订单
/// [id]订单id
class DatingOrder extends StatefulWidget {
  final String id;
  const DatingOrder({
    Key? key,
    required this.id,
  }) : super(key: key);

  @override
  State<DatingOrder> createState() => _DatingOrderState();
}

class _DatingOrderState extends State<DatingOrder> {
  // 定义状态
  bool loading = true;
  // 订单id
  String? orderId = '';
  // 联络方式
  List<Contact>? contactList = [];
  // 工具下载
  List<Contact>? toolList = [];

  /// 请求订单信息
  Future<void> getData() async {
    ModelDatingOrder? res = await apiDatingOrder(
      id: int.parse(widget.id),
    );
    if (res?.status == 1) {
      orderId = res?.data?.orderSn ?? '';
      contactList = res?.data?.contact ?? [];
      toolList = res?.data?.download ?? [];
    }
  }

  /// 初始化请求
  Future<void> initData() async {
    setState(() {
      loading = true;
    });
    await getData();
    setState(() {
      loading = false;
    });
  }

  /// 复制链接分享
  void _copyLinkShare() {
    Clipboard.setData(ClipboardData(text: orderId));
    Method.showText(
      '复制成功,快去分享吧',
    );
  }

  /// 下载
  void _handleDownload(String url) {
    Method.launchURL(url);
  }

  @override
  void initState() {
    super.initState();
    initData();
  }

  @override
  void dispose() {
    super.dispose();
  }

  /// 设置标题
  Widget setTitle({
    String? text,
  }) {
    return Padding(
      padding: EdgeInsets.symmetric(
        vertical: ScreenUtil().setWidth(10),
        horizontal: DefaultStyle.pagePadding,
      ),
      child: Text(
        text.toString(),
        style: DefaultStyle.white16,
      ),
    );
  }

  /// 竖版滚动
  Widget singleChildScrollView() {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CardSpaceBetween(
            title: "订单号：$orderId",
            right: Text(
              "复制",
              style: DefaultStyle.red14,
            ),
            onTap: () {
              _copyLinkShare();
            },
          ),
          setTitle(text: "联络方式"),
          setContactWidget(),
          setTitle(text: "联络工具下载地址"),
          setToolWidget(),
        ],
      ),
    );
  }

  /// 联络方式列表
  Widget setContactWidget() {
    if (contactList!.isNotEmpty) {
      List<Widget> tempWidgetList = [];
      for (var i = 0; i < contactList!.length; i++) {
        tempWidgetList.add(
          CardSpaceBetween(
            title: '',
            padding: EdgeInsets.all(
              ScreenUtil().setWidth(15),
            ),
            onTap: () {
              if (contactList![i].url.toString() != '') {
                _handleDownload(contactList![i].url.toString());
              }
            },
            left: Row(
              children: [
                Avatar(
                  width: ScreenUtil().setWidth(36),
                  height: ScreenUtil().setWidth(36),
                  url: contactList![i].iconFull.toString(),
                ),
                Padding(
                  padding: EdgeInsets.only(
                    left: ScreenUtil().setWidth(10.0),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        contactList![i].title.toString(),
                        style: DefaultStyle.white14,
                      ),
                      Padding(
                        padding: EdgeInsets.only(
                          top: ScreenUtil().setWidth(5.0),
                        ),
                        child: Text(
                          contactList![i].text.toString(),
                          style: DefaultStyle.white10,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            right: RedGlassmorphoismBox(
              width: ScreenUtil().setWidth(66),
              height: ScreenUtil().setWidth(28),
              child: Text(
                "立即联络",
                style: DefaultStyle.white12,
              ),
            ),
          ),
        );
      }
      return Column(
        children: tempWidgetList,
      );
    }
    return const SizedBox();
  }

  /// 工具列表
  Widget setToolWidget() {
    if (contactList!.isNotEmpty) {
      List<Widget> tempWidgetList = [];
      for (var i = 0; i < toolList!.length; i++) {
        BoxBorder? tempBorder = const Border(
          bottom: BorderSide(
            color: Color.fromRGBO(255, 255, 255, 0.12),
            width: 1,
          ),
        );
        if (toolList!.length == i) {
          tempBorder = const Border();
        }
        tempWidgetList.add(
          GestureDetector(
            onTap: () {
              if (toolList![i].url.toString() != '') {
                _handleDownload(toolList![i].url.toString());
              }
            },
            child: Flex(
              direction: Axis.horizontal,
              children: [
                Avatar(
                  width: ScreenUtil().setWidth(36),
                  height: ScreenUtil().setWidth(36),
                  url: toolList![i].iconFull.toString(),
                ),
                Expanded(
                  flex: 1,
                  child: Container(
                    margin: EdgeInsets.only(
                      left: ScreenUtil().setWidth(10),
                    ),
                    padding: EdgeInsets.symmetric(
                      vertical: ScreenUtil().setWidth(15),
                    ),
                    decoration: BoxDecoration(
                      border: tempBorder,
                    ),
                    child: Flex(
                      direction: Axis.horizontal,
                      children: [
                        Expanded(
                          flex: 1,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                toolList![i].title.toString(),
                                style: DefaultStyle.white14,
                              ),
                              Padding(
                                padding: EdgeInsets.only(
                                  top: ScreenUtil().setWidth(5.0),
                                ),
                                child: Text(
                                  toolList![i].text.toString(),
                                  style: DefaultStyle.white10,
                                ),
                              ),
                            ],
                          ),
                        ),
                        RedGlassmorphoismBox(
                          width: ScreenUtil().setWidth(66),
                          height: ScreenUtil().setWidth(28),
                          child: Text(
                            "立即下载",
                            style: DefaultStyle.white12,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      }
      return Container(
        margin: EdgeInsets.symmetric(
          horizontal: DefaultStyle.pagePadding,
        ),
        padding: EdgeInsets.symmetric(
          horizontal: ScreenUtil().setWidth(15),
        ),
        decoration: BoxDecoration(
          color: const Color.fromRGBO(188, 136, 255, 0.12),
          borderRadius: BorderRadius.all(
            Radius.circular(
              ScreenUtil().setWidth(12.0),
            ),
          ),
        ),
        child: Column(
          children: tempWidgetList,
        ),
      );
    }
    return const SizedBox();
  }

  /// 全局加载状态
  Widget init() {
    Widget loadingWidget = PageStatus.loading(true);
    return loading ? loadingWidget : singleChildScrollView();
  }

  @override
  Widget build(BuildContext context) {
    return StackPage(
      header: const HeadBack(
        leftText: "约炮妹子",
      ),
      child: init(),
    );
  }
}
