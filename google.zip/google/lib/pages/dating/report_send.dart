import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:iaimei/components/common/head.dart';
import 'package:iaimei/components/common/pagestatus.dart';
import 'package:iaimei/components/common/stackpage.dart';
import 'package:iaimei/model/basic.dart';
import 'package:iaimei/pages/creator/upload_picker_mixin.dart';
import 'package:iaimei/theme/default.dart';
import 'package:iaimei/utils/api.dart';
import 'package:iaimei/utils/common.dart';
import 'package:iaimei/utils/printLog.dart';
import 'package:iaimei/widget/buttom_widget.dart';
import 'package:iaimei/widget/convenient_mixin.dart';

/// 发布报告
class ReportSend extends StatefulWidget {
  final String id;
  const ReportSend({
    Key? key,
    required this.id,
  }) : super(key: key);

  @override
  State<ReportSend> createState() => _ReportSendState();
}

class _ReportSendState extends State<ReportSend>
    with ConvenientMixin, UploadPickerMixin {
  /// 定义状态
  bool loading = true;
  List listImg = []; // 图片列表
  TextEditingController textEditingController =
      TextEditingController(); // 文本框控制器

  @override
  void initState() {
    super.initState();
    actionSize = Size(104.w, 104.w); // web
    commonInitUploadCallback();
    setState(() {
      loading = false;
    });
  }

  @override
  void dispose() {
    textEditingController.dispose();
    super.dispose();
  }

  /// 描述文本框
  Widget textField() {
    return TextField(
      // 最大行
      maxLines: 7,
      // 最大字符个数
      maxLength: 200,
      // 是否自动获得焦点
      autofocus: false,
      // 光标颜色
      cursorColor: const Color(0xffFF00B3),
      // 文本框控制器
      controller: textEditingController,
      // 输入文本样式
      style: TextStyle(
        color: const Color(0xffffffff),
        fontSize: ScreenUtil().setSp(12),
        decoration: TextDecoration.none,
        height: 1.5, // 行高
      ),
      // 控制键盘动作（一般位于右下角，默认是完成）
      textInputAction: TextInputAction.done,
      // 输入框键盘类型（当前多行文本框）
      keyboardType: TextInputType.multiline,
      decoration: InputDecoration(
        // 如果filled为true,背景色使用fillColor的颜色
        filled: true,
        fillColor: const Color.fromRGBO(0, 0, 0, 0.12),
        // 内边距
        contentPadding: EdgeInsets.all(
          ScreenUtil().setWidth(10.0),
        ),
        // 占位文本
        hintText: '请输入投诉详细内容，附上照片or视频可以提高审核速度哦!',
        // 占位文本样式
        hintStyle: TextStyle(
          color: const Color(0x99FFFFFF),
          fontSize: ScreenUtil().setSp(12),
          decoration: TextDecoration.none,
        ),
        // 边框
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10.0),
          borderSide: const BorderSide(
            color: Colors.transparent,
            width: 0,
          ),
        ),
        // 输入框禁用时边框（errorText为空时生效）
        disabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10.0),
          borderSide: const BorderSide(
            color: Colors.transparent,
            width: 0,
          ),
        ),
        // 输入框可用时边框（errorText为空时生效）
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10.0),
          borderSide: const BorderSide(
            color: Colors.transparent,
            width: 0,
          ),
        ),
        // 输入框获取焦点时边框
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10.0),
          borderSide: const BorderSide(
            color: Colors.transparent,
            width: 0,
          ),
        ),
      ),
    );
  }

  /// 竖版滚动
  Widget singleChildScrollView() {
    return SingleChildScrollView(
      child: Column(
        children: [
          Container(
            margin: EdgeInsets.symmetric(
              vertical: ScreenUtil().setWidth(15.0),
            ),
            padding: EdgeInsets.all(
              ScreenUtil().setWidth(10.0),
            ),
            decoration: BoxDecoration(
              color: const Color.fromRGBO(133, 102, 255, 0.2),
              borderRadius: BorderRadius.circular(
                ScreenUtil().setWidth(10.0),
              ),
            ),
            child: textField(),
          ),
          Align(
            alignment: Alignment.topLeft,
            child: Wrap(
              direction: Axis.horizontal,
              alignment: WrapAlignment.start,
              crossAxisAlignment: WrapCrossAlignment.start,
              spacing: ScreenUtil().setWidth(15.0),
              runSpacing: ScreenUtil().setWidth(15.0),
              children: [
                ...localImageMap.values
                    .map((data) => buildContainerWidget(
                        width: 104.w,
                        height: 104.w,
                        child: imageMemoryWidget(data)))
                    .toList(),
                uploadActionWidget(84.w, 84.w, false), // 图片
                uploadActionWidget(84.w, 84.w, true), // 视频
              ],
            ),
          ),
          SizedBox(height: 50.w),
          ButtonWidget.build('提交', onTap: onSubmitAction)
        ],
      ),
    );
  }

  // 失去焦点
  void onDismissfocus() {
    FocusScope.of(context).requestFocus(FocusNode());
  }

  @override
  void onUploadAction(bool isVideo) {
    if (!isVideo && imagePathMap.length > 4) {
      Method.showText('图片最多上传5个');
      return;
    }
    if (isVideo && videoPathMap.isNotEmpty) {
      Method.showText('视频最多上传1个');
      return;
    }
    onDismissfocus(); // 失去焦点
    uploadIndex += 1;
    isVideo ? showVideoAssets() : showImageAssets();
  }

  /// 提交
  Future<void> onSubmitAction() async {
    String tempText = textEditingController.text.trim();
    dynamic tempImgs = jsonEncode(
      imagePathMap.values.toList(),
    );
    String tempVideos = videoPathMap.values.join(',');
    if (tempText == '') {
      Method.showText("验茶报告的文本不能为空");
      return;
    }
    if (tempImgs.isEmpty && tempVideos.isEmpty) {
      Method.showText('请上传封面或者视频');
      return;
    }
    Basic? res = await apiDatingCreateVerify(
      infoId: widget.id,
      images: tempImgs,
      videos: tempVideos,
      content: tempText,
    );
    PrintUtil.d("提交:${res?.toJson()}");
    if (res?.status == 1) {
      Method.showText(
        res?.data.toString() ?? "发布成功",
      );
      setState(() {
        textEditingController.clear();
        imagePathMap = {}; // 清空图片地址
        localImageMap = {}; // 清空本地图片地址
        videoPathMap = {}; // 清空视频地址
      });
    } else {
      Method.showText(
        res?.msg ?? "发布失败",
      );
    }
  }

  /// 全局加载状态
  Widget init() {
    Widget loadingWidget = PageStatus.loading(true);
    return loading ? loadingWidget : singleChildScrollView();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScopeNode currentFocus = FocusScope.of(context);
        if (!currentFocus.hasPrimaryFocus &&
            currentFocus.focusedChild != null) {
          /// 取消焦点，相当于关闭键盘
          FocusManager.instance.primaryFocus?.unfocus();
        }
      },
      child: StackPage(
        header: const HeadBack(
          leftText: '发布验证',
        ),
        child: Padding(
          padding: EdgeInsets.symmetric(
            horizontal: DefaultStyle.pagePadding,
          ),
          child: init(),
        ),
      ),
    );
  }
}
