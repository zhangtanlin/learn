import 'dart:async';

import 'package:flutter/material.dart';
import 'package:iaimei/app_const.dart';
import 'package:iaimei/base/base_widget_state.dart';
import 'package:iaimei/components/card/card_dating_item.dart';
import 'package:iaimei/components/card/card_report_item.dart';
import 'package:iaimei/event/dating_city_change_event.dart';
import 'package:iaimei/event/dating_filter_change_event.dart';
import 'package:iaimei/global.dart';
import 'package:iaimei/mixin/list_page_load_mixin.dart';
import 'package:iaimei/model/dating_city_model.dart';
import 'package:iaimei/net/http_error.dart';
import 'package:iaimei/net/http_helper.dart';
import 'package:iaimei/utils/eventbus_util.dart';
import 'package:iaimei/utils/list_util.dart';
import 'package:iaimei/utils/string_util.dart';
import 'package:iaimei/widget/list_widget.dart';
import 'package:iaimei/widget/refresh_load_list_widget.dart';

/// 约炮列表
/// [type] 一级选项卡类型{"recommend":"为你推荐","normal":"普通专区","feature":"精品专区","verify":"验车报告"}
/// [url] 选项卡请求地址
/// [secondId] 二级选项卡id
/// [cityCode] 城市代码
/// [param] 过滤参数
class DatingSortListPage extends StatefulWidget {
  final String? url;
  final String? tabType;
  final int? subTabType;

  const DatingSortListPage({
    Key? key,
    this.url,
    this.tabType,
    this.subTabType,
  }) : super(key: key);

  @override
  State<DatingSortListPage> createState() => _DatingSortListPageState();
}

class _DatingSortListPageState extends BaseWidgetState<DatingSortListPage>
    with ListPageLoadMixin {
  List dataList = [];

  StreamSubscription<DatingFilterChangeEvent>? _filterSubscription;
  StreamSubscription<DatingCityChangeEvent>? _datingCityChangeSubscription;

  late int _cityCode;

  @override
  void initState() {
    super.initState();
    _getCityCodeAction();
    _filterSubscription = EventBusUtil.listen((event) {
      if (event.param!.isNotEmpty) {
        AppGlobal.datingFilterParam = event.param!;
        onRefreshList();
      }
    });

    _datingCityChangeSubscription = EventBusUtil.listen((event) {
      _getCityCodeAction();
      onRefreshList();
    });

    onLoadData();
  }

  void _getCityCodeAction() {
    var data = AppGlobal.appBox!.get(AppConst.datingCityKey,
        defaultValue: CityItemModel(id: 0, areaname: "全国").toJson());
    _cityCode = CityItemModel.fromJson(data).id ?? 0;
  }

  @override
  Widget buildPageLayout() {
    return handlePageStateView();
  }

  @override
  onLoadData() {
    onRefreshList();
  }

  @override
  void requestListData(bool isRefresh) {
    if (StringUtil.isEmpty(widget.url)) {
      setListPageErrorState(isRefresh, HttpError());
      return;
    }
    Map<String, dynamic> params = {
      "page": getCurPage,
      "limit": getPageSize,
      "city_code": _cityCode,
      "type": widget.subTabType,
    };
    if (AppGlobal.datingFilterParam != null &&
        AppGlobal.datingFilterParam.isNotEmpty) {
      params.addAll(AppGlobal.datingFilterParam);
    }
    HttpHelper.requestCommonInterface(widget.url!, params, (data) {
      dataList = data["list"] ?? [];
      setListPageState(isRefresh, ListUtil.isNotEmpty(dataList), () {
        updatePageList(isRefresh, dataList);
      });
    }, (error) {
      setListPageErrorState(isRefresh, error);
    });
  }

  @override
  Widget successView() {
    return RefreshLoadListWidget(
        enableLoad: isEnableLoad(),
        enableRefresh: isEnableRefresh(),
        onRefresh: onRefreshList,
        onLoad: onLoadList,
        refreshController: refreshController,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [_buildGirlListSection(getResultList)],
        ));
  }

  _buildGirlListSection(List dataList) {
    return ListWidget.buildVerticalListView(
        itemCount: dataList.length,
        itemBuilder: (context, index) {
          return _buildListItemSection(index, dataList);
        },
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics());
  }

  _buildListItemSection(int index, List dataList) {
    switch (widget.tabType) {
      case "verify":
        //  验车报告
        return CardReportItem(
          item: dataList[index],
        );
      default:
        // 约炮
        return CardDatingItem(
          item: dataList[index],
        );
    }
  }

  @override
  void dispose() {
    if (_filterSubscription != null) {
      _filterSubscription!.cancel();
    }
    if (_datingCityChangeSubscription != null) {
      _datingCityChangeSubscription!.cancel();
    }
    super.dispose();
  }
}
