import 'package:card_swiper/card_swiper.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:iaimei/components/common/head.dart';
import 'package:iaimei/components/common/pagestatus.dart';
import 'package:iaimei/components/common/stackpage.dart';
import 'package:iaimei/model/model_girl_detail_verify.dart';
import 'package:iaimei/model/video_model.dart';
import 'package:iaimei/pages/video/long_video_player.dart';
import 'package:iaimei/router/routers.dart';
import 'package:iaimei/theme/default.dart';
import 'package:iaimei/utils/api.dart';
import 'package:iaimei/utils/string_util.dart';
import 'package:iaimei/widget/network_img_container.dart';

/// 报告详情
class ReportDetail extends StatefulWidget {
  final String id;

  const ReportDetail({
    Key? key,
    required this.id,
  }) : super(key: key);

  @override
  State<ReportDetail> createState() => _ReportDetailState();
}

class _ReportDetailState extends State<ReportDetail> {
  bool loading = true;
  late Data? data; // 验车详情

  void getData() async {
    ModelGirlDetailVerify? res = await apiGirlDetailVerify(
      id: widget.id, // 约炮验车报告信息id
    );
    if (res?.status == 1) {
      data = res?.data;
      loading = false;
      setState(() {});
    }
  }

  @override
  void initState() {
    super.initState();
    getData();
  }

  @override
  void dispose() {
    super.dispose();
  }

  /// 用户基础信息块
  Widget baseInfoPanel() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.only(
            right: ScreenUtil().setWidth(10.0),
            bottom: ScreenUtil().setWidth(10.0),
            left: ScreenUtil().setWidth(10.0),
          ),
          child: Text(
            data?.content ?? '',
            style: TextStyle(
              color: const Color(0x99FFFFFF),
              fontSize: ScreenUtil().setSp(13),
              height: 1.75,
              decoration: TextDecoration.none,
            ),
          ),
        ),
        GestureDetector(
          onTap: () {
            // context.push('/datingInfo/${data?.infoId}');
            context.push(
              '/${Routes.datingDetail}',
              extra: {'info_id': data?.infoId},
            );
          },
          child: Container(
            alignment: Alignment.center,
            padding: EdgeInsets.symmetric(
              vertical: ScreenUtil().setWidth(12.5),
            ),
            decoration: BoxDecoration(
              color: const Color.fromRGBO(0, 0, 0, .45),
              borderRadius: BorderRadius.vertical(
                bottom: Radius.circular(
                  ScreenUtil().setWidth(10.0),
                ),
              ),
            ),
            child: Text(
              '查看女神信息',
              style: DefaultStyle.red14,
            ),
          ),
        ),
      ],
    );
  }

  /// 竖版滚动
  Widget singleChildScrollView() {
    return SingleChildScrollView(
      child: Container(
        decoration: BoxDecoration(
          color: const Color.fromRGBO(133, 102, 255, .1),
          borderRadius: BorderRadius.all(
            Radius.circular(
              ScreenUtil().setWidth(10.0),
            ),
          ),
        ),
        child: Column(
          children: [
            Container(
              height: ScreenUtil().setWidth(450),
              padding: EdgeInsets.all(
                ScreenUtil().setWidth(10.0),
              ),
              alignment: Alignment.center,
              child: setVideoAndPictures(),
            ),
            baseInfoPanel(),
          ],
        ),
      ),
    );
  }

  /// 根据条件判定轮播显示视频和图片
  Widget setVideoAndPictures() {
    List swiperList = [];
    if (StringUtil.isNotEmpty(data!.playUrl)) {
      swiperList.add({
        "type": "showVideo",
        "url": data!.playUrl,
      });
    }
    if (data!.imagesFull!.isNotEmpty) {
      for (var i = 0; i < data!.imagesFull!.length; i++) {
        swiperList.add({
          "type": "showPictures",
          "url": data!.imagesFull![i].url,
        });
      }
    }
    return Swiper(
      loop: false,
      itemCount: swiperList.length,
      itemBuilder: (context, index) {
        if (swiperList[index]["type"] == 'showVideo') {
          return LongVideoPlayer(
            data: getTempVideo(data),
          );
        } else {
          return Container(
            color: DefaultStyle.bgDefault,
            height: ScreenUtil().setWidth(450),
            child: NetworkImgContainer(
              url: swiperList[index]["url"],
              fit: BoxFit.contain,
            ),
          );
        }
      },
    );
  }

  /// 构造播放模型
  VideoModel getTempVideo(Data? data) {
    VideoModel _videoModel = VideoModel();
    _videoModel.playUrl = data!.playUrl!;
    return _videoModel;
  }

  /// 全局加载状态
  Widget init() {
    Widget loadingWidget = PageStatus.loading(true);
    return loading ? loadingWidget : singleChildScrollView();
  }

  @override
  Widget build(BuildContext context) {
    return StackPage(
      header: const HeadBack(
        leftText: '用户体验',
      ),
      child: Padding(
        padding: EdgeInsets.symmetric(
          horizontal: DefaultStyle.pagePadding,
        ),
        child: init(),
      ),
    );
  }
}
