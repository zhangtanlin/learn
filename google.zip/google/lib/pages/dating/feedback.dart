import 'dart:convert';

import 'package:bot_toast/bot_toast.dart';
import 'package:iaimei/components/btn/btn_dating_feedback.dart';
import 'package:iaimei/components/common/glassmorphism.dart';
import 'package:iaimei/model/model_helper.dart';
import 'package:iaimei/pages/creator/upload_picker_mixin.dart';
import 'package:iaimei/utils/common.dart';
import 'package:iaimei/widget/convenient_mixin.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:iaimei/components/common/head.dart';
import 'package:iaimei/components/common/pagestatus.dart';
import 'package:iaimei/components/common/stackpage.dart';
import 'package:iaimei/model/basic.dart';
import 'package:iaimei/theme/default.dart';
import 'package:iaimei/utils/api.dart';

/// 投诉
class FeedBack extends StatefulWidget {
  final String id;
  const FeedBack({
    Key? key,
    required this.id,
  }) : super(key: key);

  @override
  State<FeedBack> createState() => _FeedBackState();
}

class _FeedBackState extends State<FeedBack>
    with ConvenientMixin, UploadPickerMixin {
  /// 定义状态
  bool loading = true;
  var textEditingController = TextEditingController(); // 文本框控制器

  dynamic seletedReason;
  List reasonList = [];
  void getData() async {
    var res = await apiListHelper();
    if (res?.status == 1) {
      loading = false;
      reasonList = res!.data;
      setState(() {});
    }
  }

  /// 提交
  void submit() async {
    String tempReasonId = '$seletedReason';
    String tempResonText = textEditingController.text.toString().trim();
    dynamic tempResonImg = jsonEncode(
      imagePathMap.values.toList(),
    );
    if (tempReasonId == "" && tempResonText == '' && tempResonImg.isEmpty) {
      Method.showText("请选择或输入投诉信息");
      return;
    }
    Basic? res = await apiCreateReport(
      id: widget.id,
      type: tempReasonId,
      images: tempResonImg,
      content: tempResonText,
    );
    if (res?.status == 1) {
      setState(() {
        textEditingController.clear();
        seletedReason = null;
        imagePathMap = {}; // 清空图片地址
        localImageMap = {}; // 清空本地图片地址
      });
      BotToast.showText(
        text: res?.data.toString() ?? "",
      );
    } else {
      BotToast.showText(
        text: res?.msg ?? "投诉失败",
      );
    }
  }

  @override
  void initState() {
    super.initState();
    getData();

    actionSize = Size(100.w, 100.w); // web
    commonInitUploadCallback();
  }

  @override
  void dispose() {
    super.dispose();
  }

  /// 描述文本框
  Widget textField() {
    return TextField(
      // 最大行
      maxLines: 7,
      // 最大字符个数
      maxLength: 200,
      // 是否自动获得焦点
      autofocus: false,
      // 光标颜色
      cursorColor: const Color(0xffFF00B3),
      // 文本框控制器
      controller: textEditingController,
      // 输入文本样式
      style: TextStyle(
        color: const Color(0xffffffff),
        fontSize: ScreenUtil().setSp(12),
        decoration: TextDecoration.none,
        height: 1.5, // 行高
      ),
      // 控制键盘动作（一般位于右下角，默认是完成）
      textInputAction: TextInputAction.done,
      // 输入框键盘类型（当前多行文本框）
      keyboardType: TextInputType.multiline,
      decoration: InputDecoration(
        // 如果filled为true,背景色使用fillColor的颜色
        filled: true,
        fillColor: const Color.fromRGBO(0, 0, 0, 0.12),
        // 内边距
        contentPadding: EdgeInsets.all(
          ScreenUtil().setWidth(10.0),
        ),
        // 占位文本
        hintText: '请输入投诉详细内容，附上照片or视频可以提高审核速度哦!',
        // 占位文本样式
        hintStyle: TextStyle(
          color: const Color(0x99FFFFFF),
          fontSize: ScreenUtil().setSp(12),
          decoration: TextDecoration.none,
        ),
        // 边框
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10.0),
          borderSide: const BorderSide(
            color: Colors.transparent,
            width: 0,
          ),
        ),
        // 输入框禁用时边框（errorText为空时生效）
        disabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10.0),
          borderSide: const BorderSide(
            color: Colors.transparent,
            width: 0,
          ),
        ),
        // 输入框可用时边框（errorText为空时生效）
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10.0),
          borderSide: const BorderSide(
            color: Colors.transparent,
            width: 0,
          ),
        ),
        // 输入框获取焦点时边框
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10.0),
          borderSide: const BorderSide(
            color: Colors.transparent,
            width: 0,
          ),
        ),
      ),
    );
  }

  /// 按钮列表
  Widget setBtnListWidget() {
    if (reasonList.isEmpty) {
      return const SizedBox();
    }
    return Wrap(
      direction: Axis.horizontal,
      spacing: ScreenUtil().setWidth(20.0),
      runSpacing: ScreenUtil().setWidth(15.0),
      children: [
        for (int i = 0; i < reasonList.length; i++) ...[
          GestureDetector(
            onTap: () => setState(() => seletedReason = reasonList[i]['key']),
            child: seletedReason == reasonList[i]['key']
                ? RedGlassmorphoismBox(
                    child: Container(
                      padding:
                          EdgeInsets.symmetric(vertical: 6.w, horizontal: 20.w),
                      child: Text(reasonList[i]['value'],
                          style: DefaultStyle.white12),
                    ),
                  )
                : GlassmorphoismTags(
                    child: Text(reasonList[i]['value'],
                        style: DefaultStyle.white12),
                  ),
          )
        ]
      ],
    );
  }

  /// 竖版滚动
  Widget singleChildScrollView() {
    return SingleChildScrollView(
      child: Column(
        children: [
          setBtnListWidget(),
          Container(
            margin: EdgeInsets.symmetric(
              vertical: ScreenUtil().setWidth(15.0),
            ),
            padding: EdgeInsets.all(
              ScreenUtil().setWidth(10.0),
            ),
            decoration: BoxDecoration(
              color: const Color.fromRGBO(133, 102, 255, 0.2),
              borderRadius: BorderRadius.circular(
                ScreenUtil().setWidth(10.0),
              ),
            ),
            child: textField(),
          ),
          Wrap(
            direction: Axis.horizontal,
            alignment: WrapAlignment.start,
            crossAxisAlignment: WrapCrossAlignment.start,
            spacing: ScreenUtil().setWidth(20.0),
            runSpacing: ScreenUtil().setWidth(20.0),
            children: [
              ...localImageMap.values
                  .map((data) => buildContainerWidget(
                      width: 100.w,
                      height: 100.w,
                      child: imageMemoryWidget(data)))
                  .toList(),
              uploadActionWidget(84.w, 84.w, false), // 图片上传
              // uploadActionWidget(84.w,84.w,true), // 视频上传
            ],
          ),
          GestureDetector(
            onTap: () {
              submit();
            },
            child: Padding(
              padding: EdgeInsets.symmetric(
                vertical: ScreenUtil().setWidth(20.0),
              ),
              child: Stack(
                children: [
                  Positioned(
                    top: 0,
                    bottom: 0,
                    right: 0,
                    left: 0,
                    child: Image.asset(
                      'assets/images/button/btn_middle.png',
                      fit: BoxFit.fill,
                    ),
                  ),
                  Container(
                    width: ScreenUtil().setWidth(120.0),
                    height: ScreenUtil().setWidth(50.0),
                    alignment: Alignment.center,
                    padding: EdgeInsets.only(
                      bottom: ScreenUtil().setWidth(5.0),
                    ),
                    child: Text(
                      '提交',
                      style: DefaultStyle.white14,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // 失去焦点
  void onDismissfocus() {
    FocusScope.of(context).requestFocus(FocusNode());
  }

  @override
  void onUploadAction(bool isVideo) {
    if (!isVideo && imagePathMap.length > 4) {
      Method.showText('图片最多上传5个');
      return;
    }
    onDismissfocus(); // 失去焦点
    uploadIndex += 1;
    isVideo ? showVideoAssets() : showImageAssets();
  }

  /// 全局加载状态
  Widget init() {
    Widget loadingWidget = PageStatus.loading(true);
    return loading ? loadingWidget : singleChildScrollView();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScopeNode currentFocus = FocusScope.of(context);
        if (!currentFocus.hasPrimaryFocus &&
            currentFocus.focusedChild != null) {
          /// 取消焦点，相当于关闭键盘
          FocusManager.instance.primaryFocus?.unfocus();
        }
      },
      child: StackPage(
        header: const HeadBack(
          leftText: '投诉',
        ),
        child: Padding(
          padding: EdgeInsets.symmetric(
            horizontal: DefaultStyle.pagePadding,
          ),
          child: init(),
        ),
      ),
    );
  }
}
