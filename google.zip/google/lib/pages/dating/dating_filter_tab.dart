import 'package:flutter/material.dart';
import 'package:iaimei/model/dating_filter_item_model.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/res/img_res.dart';
import 'package:iaimei/style/app_text_style.dart';
import 'package:iaimei/widget/text_widget.dart';

/// 约炮tab
class DatingFilterTab extends StatelessWidget {
  final DatingFilterItemModel itemData;
  final String? selectValue;
  final Function? onTap;

  const DatingFilterTab({
    Key? key,
    required this.itemData,
    this.selectValue = "",
    this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(
        bottom: DimenRes.dimen_8,
      ),
      height: DimenRes.convert(36),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.24),
        borderRadius: BorderRadius.circular(
          DimenRes.radius(18),
        ),
      ),
      child: _buildItemSection(),
    );
  }

  Widget _buildItemSection() {
    return Row(
      children: [
        Padding(
          padding: EdgeInsets.only(
            right: DimenRes.dimen_20,
            left: DimenRes.dimen_18,
          ),
          child: TextWidget.buildSingleLineText(
            itemData.name ?? '',
            AppTextStyle.cff00b3_s12,
          ),
        ),
        Expanded(
          child: _buildFilterItemList(),
        ),
      ],
    );
  }

  Widget _buildFilterItemList() {
    return ListView.builder(
      physics: const BouncingScrollPhysics(),
      scrollDirection: Axis.horizontal,
      itemCount: itemData.tags?.length,
      itemBuilder: (
        BuildContext context,
        int index,
      ) {
        return _buildTabItemBtn(
          itemData.tags![index],
        );
      },
    );
  }

  /// 按钮样式
  Widget _buildTabItemBtn(DatingFilterTags item) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () {
        if (onTap != null) onTap!(item.value);
      },
      child: SizedBox(
        width: DimenRes.convert(70),
        height: DimenRes.dimen_28,
        child: Stack(
          alignment: Alignment.center,
          children: [
            AnimatedOpacity(
              duration: const Duration(milliseconds: 300),
              opacity: item.value == selectValue ? 1.0 : 0,
              child: Container(
                alignment: Alignment.center,
                child: Image.asset(
                  ImgRes.BTN_GRADIENT_S,
                  width: DimenRes.convert(66),
                  height: DimenRes.dimen_28,
                  fit: BoxFit.contain,
                ),
              ),
            ),
            Text(
              item.label ?? '',
              style: item.value == selectValue
                  ? AppTextStyle.white_s12
                  : AppTextStyle.build(Colors.white.withOpacity(0.64), 12),
            ),
          ],
        ),
      ),
    );
  }
}
