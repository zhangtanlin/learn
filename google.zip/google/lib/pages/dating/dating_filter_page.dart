import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:iaimei/base/app_base_widget_state.dart';
import 'package:iaimei/event/dating_filter_change_event.dart';
import 'package:iaimei/mixin/page_load_mixin.dart';
import 'package:iaimei/model/dating_filter_item_model.dart';
import 'package:iaimei/net/http_helper.dart';
import 'package:iaimei/pages/dating/dating_filter_mul.dart';
import 'package:iaimei/pages/dating/dating_filter_tab.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/res/img_res.dart';
import 'package:iaimei/res/string_res.dart';
import 'package:iaimei/utils/eventbus_util.dart';
import 'package:iaimei/utils/list_util.dart';
import 'package:iaimei/widget/app_img_widget.dart';
import 'package:iaimei/widget/app_page_title_bar.dart';

/// 约炮筛选
class DatingFilterPage extends StatefulWidget {
  const DatingFilterPage({Key? key}) : super(key: key);

  @override
  State<DatingFilterPage> createState() => _DatingFilterPageState();
}

class _DatingFilterPageState extends AppBaseWidgetState<DatingFilterPage>
    with PageLoadMixin {
  // 列表
  late List<DatingFilterItemModel> filterItemList = [];

  // 选中的值
  late Map<String, dynamic> selectParam = {};

  @override
  void initState() {
    super.initState();
    onLoadData();
  }

  @override
  buildAppBar() {
    return AppPageTitleBar.getNormalAppBar(
        title: StringRes.str_same_city_dating);
  }

  @override
  Widget buildPageLayout() {
    return handlePageStateView();
  }

  @override
  onLoadData() {
    HttpHelper.getDatingFilter((data) {
      filterItemList = (data as List)
          .map((json) => DatingFilterItemModel.fromJson(json))
          .toList();

      if (ListUtil.isNotEmpty(filterItemList)) {
        filterItemList.map((item) {
          if (item.style == 1) {
            selectParam[item.key!] = "";
          } else {
            selectParam[item.key!] = [];
          }
        }).toList();
      }
      setPageState(ListUtil.isNotEmpty(filterItemList));
    }, (error) {
      setPageErrorState(error);
    });
  }

  @override
  Widget successView() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: EdgeInsets.symmetric(
        vertical: DimenRes.dimen_10,
        horizontal: DimenRes.dimen_16,
      ),
      child: _buildWidgetList(),
    );
  }

  /// 根据数据类型使用不同的显示方式（单选横向滚动展示/多选选列表展示）
  _buildWidgetList() {
    List<Widget> widgetList = [];
    for (int i = 0; i < filterItemList.length; i++) {
      switch (filterItemList[i].style) {
        // 单选列表
        case 1:
          widgetList.add(
            DatingFilterTab(
              itemData: filterItemList[i],
              selectValue: selectParam[filterItemList[i].key],
              onTap: (String value) {
                selectParam[filterItemList[i].key!] = value;
                setState(() {});
              },
            ),
          );
          break;
        // 多选列表
        case 2:
          widgetList.add(
            DartingFilterMul(
              data: filterItemList[i],
              selectList: selectParam[filterItemList[i].key],
              onTap: (value) {
                if (selectParam[filterItemList[i].key].contains(value)) {
                  selectParam[filterItemList[i].key].remove(value);
                } else {
                  selectParam[filterItemList[i].key].add(value);
                }
                setState(() {});
              },
            ),
          );
          break;
        default:
          // 其他列表
          widgetList.add(
            const SizedBox(),
          );
      }
    }
    widgetList.add(
      Padding(
        padding: EdgeInsets.only(
          top: ScreenUtil().setWidth(50.0),
        ),
        child: GestureDetector(
          onTap: () {
            Navigator.of(context).pop();
            EventBusUtil.fire(DatingFilterChangeEvent(selectParam));
          },
          child: AppImgWidget(
            path: ImgRes.BTN_FILTER_SUBMIT,
            height: DimenRes.dimen_50,
          ),
        ),
      ),
    );
    return Column(
      children: widgetList,
    );
  }
}
