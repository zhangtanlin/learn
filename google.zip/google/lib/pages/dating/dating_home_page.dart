import 'dart:async';

import 'package:card_swiper/card_swiper.dart';
import 'package:flutter/material.dart';
import 'package:iaimei/app_const.dart';
import 'package:iaimei/base/app_base_widget_state.dart';
import 'package:iaimei/components/card/dating_rec_item.dart';
import 'package:iaimei/components/citypicker/city_picker_page.dart';
import 'package:iaimei/event/dating_city_change_event.dart';
import 'package:iaimei/global.dart';
import 'package:iaimei/mixin/page_load_mixin.dart';
import 'package:iaimei/model/dating_city_model.dart';
import 'package:iaimei/model/dating_girl_info_model.dart';
import 'package:iaimei/model/dating_home_top_model.dart';
import 'package:iaimei/net/http_helper.dart';
import 'package:iaimei/pages/dating/dating_filter_page.dart';
import 'package:iaimei/pages/dating/dating_sort_page.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/res/img_res.dart';
import 'package:iaimei/res/string_res.dart';
import 'package:iaimei/style/app_text_style.dart';
import 'package:iaimei/utils/eventbus_util.dart';
import 'package:iaimei/utils/list_util.dart';
import 'package:iaimei/utils/page_jump_util.dart';
import 'package:iaimei/widget/app_img_widget.dart';
import 'package:iaimei/widget/app_page_title_bar.dart';
import 'package:iaimei/widget/snap_top_tab_navigator.dart';
import 'package:iaimei/widget/space_widget.dart';
import 'package:iaimei/widget/text_widget.dart';

/// 约炮主页面
class DatingHomePage extends StatefulWidget {
  const DatingHomePage({Key? key}) : super(key: key);

  @override
  State<DatingHomePage> createState() => _DatingHomePageState();
}

class _DatingHomePageState extends AppBaseWidgetState<DatingHomePage>
    with PageLoadMixin {
  late CityItemModel curDatingCity; // 默认城市
  late List<DatingGirlInfoModel> recList = []; // 轮播图
  late SwiperController _swiperController;
  late List<DatingTabData> tabList = []; // 一级选项卡列表
  late SnapTopTabNavConfig _tabNavConfig;
  StreamSubscription<DatingCityChangeEvent>? _datingCityChangeSubscription;

  @override
  void initState() {
    super.initState();

    _swiperController = SwiperController();
    _tabNavConfig = SnapTopTabNavConfig(
        snapTopHeight: DimenRes.convert(44),
        tabItemWidth: DimenRes.convert(81),
        tabItemHeight: DimenRes.convert(34),
        snapTopBgColor: Colors.white12,
        tabItemMargin: EdgeInsets.only(right: DimenRes.convert(2)),
        snapTopPadding:
            EdgeInsets.only(left: DimenRes.dimen_5, right: DimenRes.dimen_5),
        tabItemTextPadding:
            EdgeInsets.only(left: DimenRes.dimen_12, right: DimenRes.dimen_12),
        snapTopDecoration: BoxDecoration(
            border:
                Border.all(color: Colors.white.withOpacity(0.12), width: 0.3),
            borderRadius: BorderRadius.circular(22),
            gradient: const LinearGradient(colors: [
              Color.fromRGBO(178, 170, 255, 0.12),
              Color.fromRGBO(108, 82, 222, 0.08),
            ], begin: Alignment.topCenter, end: Alignment.bottomCenter)),
        textStyle: AppTextStyle.white_s14,
        indicatorWidget: AppImgWidget(path: ImgRes.BTN_MIDDLE),
        selectedTextStyle: AppTextStyle.white_s14);
    _getCurDatingCityAction();

    _datingCityChangeSubscription = EventBusUtil.listen((event) {
      _getCurDatingCityAction();
      setState(() {});
    });
    // 初始化选项卡
    onLoadData();
  }

  void _getCurDatingCityAction() {
    var data = AppGlobal.appBox!.get(AppConst.datingCityKey,
        defaultValue: CityItemModel(id: 0, areaname: "全国").toJson());
    curDatingCity = CityItemModel.fromJson(data);
  }

  @override
  onLoadData() {
    HttpHelper.getDatingHomeTab((data) {
      DatingHomeTopModel homeTopModel = DatingHomeTopModel.fromJson(data);
      if (homeTopModel != null) {
        tabList = homeTopModel.data ?? [];
        recList = homeTopModel.ads ?? [];
      }
      setPageState(
          homeTopModel != null && ListUtil.isNotEmpty(homeTopModel.data));
    }, (error) {
      setPageErrorState(error);
    });
  }

  @override
  buildAppBar() {
    return AppPageTitleBar.getNormalAppBar(
        title: StringRes.str_same_city_dating,
        rightWidget: _buildTitleRightWidget());
  }

  /// 头部右侧过滤按钮(单个返回图标+文字)
  _buildTitleRightWidget() {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        GestureDetector(
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => const CityPickerPage(),
              ),
            );
          },
          child: TextWidget.buildSingleLineText(
            curDatingCity.areaname.toString(),
            AppTextStyle.white_s13,
          ),
        ),
        const SpaceWidget(
          hSpace: 10,
        ),
        GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const DatingFilterPage(),
                ),
              );
            },
            child: AppImgWidget(
              path: ImgRes.IC_FILTER,
              width: DimenRes.dimen_35,
              height: DimenRes.dimen_35,
            )),
      ],
    );
  }

  @override
  Widget successView() {
    return ListUtil.isNotEmpty(tabList)
        ? Container(
            padding: EdgeInsets.symmetric(horizontal: DimenRes.dimen_16),
            child: SnapTopTabNavigator(
              config: _tabNavConfig,
              foldWidget: _buildCarouselSection(),
              pages: [
                for (var i = 0; i < tabList.length; i++) ...[
                  DatingSortPage(
                    url: tabList[i].value ?? '',
                    tabType: tabList[i].type ?? '',
                    subTabs: tabList[i].subTab ?? [],
                  )
                ],
              ],
              tabItems: [
                for (int i = 0; i < tabList.length; i++) ...[
                  tabList[i].name ?? '',
                ]
              ],
            ),
          )
        : const SizedBox();
  }

  @override
  void dispose() {
    if (_swiperController != null) {
      _swiperController.dispose();
    }
    if (_datingCityChangeSubscription != null) {
      _datingCityChangeSubscription!.cancel();
    }
    super.dispose();
  }

  @override
  Widget buildPageLayout() {
    return handlePageStateView();
  }

  Widget _buildCarouselSection() {
    if (ListUtil.isEmpty(recList)) {
      return const SizedBox();
    }
    return Container(
      height: DimenRes.convert(206),
      margin: EdgeInsets.only(
        top: DimenRes.dimen_10,
        bottom: DimenRes.dimen_20,
      ),
      child: Swiper(
        autoplay: recList.length > 1,
        itemCount: recList.length,
        scale: 0.8,
        duration: 300,
        autoplayDelay: 5000,
        controller: _swiperController,
        onTap: (index) {
          PageJumpUtil.forwardToDatingDetailPage(context, recList[index].id!);
        },
        itemBuilder: (
          BuildContext context,
          int index,
        ) {
          return DatingRecItem(
            item: recList[index],
          );
        },
      ),
    );
  }
}
