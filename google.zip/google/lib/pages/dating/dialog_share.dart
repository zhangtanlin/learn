import 'package:flutter/material.dart';

/// 分享弹出框
class DialogShareContent extends StatelessWidget {
  const DialogShareContent({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const Text('分享');
  }
}
