import 'package:card_swiper/card_swiper.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:iaimei/base/app_base_widget_state.dart';
import 'package:iaimei/global.dart';
import 'package:iaimei/mixin/page_load_mixin.dart';
import 'package:iaimei/model/dating_girl_info_model.dart';
import 'package:iaimei/model/img_preview_info.dart';
import 'package:iaimei/model/like_result_model.dart';
import 'package:iaimei/model/unlock_info_model.dart';
import 'package:iaimei/model/video_model.dart';
import 'package:iaimei/net/http_helper.dart';
import 'package:iaimei/pages/dating/sheet_comment.dart';
import 'package:iaimei/pages/video/long_video_player.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/res/img_res.dart';
import 'package:iaimei/res/string_res.dart';
import 'package:iaimei/style/app_text_style.dart';
import 'package:iaimei/utils/list_util.dart';
import 'package:iaimei/utils/page_jump_util.dart';
import 'package:iaimei/utils/string_util.dart';
import 'package:iaimei/utils/unlock_check_util.dart';
import 'package:iaimei/widget/app_img_widget.dart';
import 'package:iaimei/widget/app_page_title_bar.dart';
import 'package:iaimei/widget/app_text_with_img_bg_widget.dart';
import 'package:iaimei/widget/frosted_glass_box.dart';
import 'package:iaimei/widget/network_img_container.dart';
import 'package:iaimei/widget/space_widget.dart';
import 'package:iaimei/widget/text_widget.dart';

/// 约炮信息
/// [id]约炮信息的id
class DatingDetailPage extends StatefulWidget {
  final Map<String, dynamic> param;

  const DatingDetailPage({Key? key, this.param = const {}}) : super(key: key);

  @override
  State<DatingDetailPage> createState() => _DatingDetailPageState();
}

class _DatingDetailPageState extends AppBaseWidgetState<DatingDetailPage>
    with PageLoadMixin {
  late DatingGirlInfoModel datingInfo;
  String title = ''; // 约炮信息标题(头部使用)
  bool isLouFeng = false; // 约炮类型  {true: 楼凤, false: 非楼凤}
  bool unlocked = false; // 是否已解锁
  String unlockText = "购买"; // 是否已解锁按钮文本
  late UnlockInfoModel unlockInfo; // 解锁弹出框信息
  String contactNumber = ''; // 联系方式
  bool isCollected = true; // 是否已收藏
  bool isCollecting = true; // 收藏按钮是否被点击
  String uid = ''; // 外部传入
  String infoId = ''; // 外部传入

  @override
  void initState() {
    super.initState();
    uid = '${widget.param['uid'] ?? ''}';
    infoId = '${widget.param['info_id'] ?? ''}';
    onLoadData();
  }

  @override
  onLoadData() {
    Map<String, dynamic> params = {};
    params['info_id'] = infoId;
    params['uid'] = uid;
    HttpHelper.getDatingDetail(params, (data) {
      DatingGirlInfoModel infoModel = DatingGirlInfoModel.fromJson(data);
      if (infoModel != null) {
        datingInfo = infoModel;
        title = datingInfo.title ?? '';

        // 存入阅读历史
        infoId = '${datingInfo.id ?? ''}'; // 必须给值，页面操作根据 infoId
        AppGlobal.storeHistory(BrowseKey.dateLove, datingInfo.toJson());

        // 是否已收藏
        isCollected = datingInfo.isLike == 1;

        // 判定是否解锁
        unlocked = datingInfo.isPay == 1;

        // 设置支付方式
        unlockInfo = datingInfo.payData!;

        // 判定是否为楼凤
        if (datingInfo.type == 2) {
          isLouFeng = true;
          contactNumber = datingInfo.contact ?? '';
        } else {
          isLouFeng = false;
        }

        // 设置解锁文字
        if (unlocked && !isLouFeng) {
          unlockText = '再次购买';
        }
      }
      setPageState(infoModel != null);
    }, (error) {
      setPageErrorState(error);
    });
  }

  @override
  buildAppBar() {
    return AppPageTitleBar.getNormalAppBar(
        title: title, rightWidget: titleRightBtn());
  }

  @override
  Widget buildPageLayout() {
    return handlePageStateView();
  }

  @override
  Widget successView() {
    return Stack(
      children: [
        _buildScrollViewSection(),
        _buildBuyBtnSection(),
      ],
    );
  }

  _buildScrollViewSection() {
    return SingleChildScrollView(
      padding: EdgeInsets.symmetric(horizontal: DimenRes.dimen_16),
      physics: const BouncingScrollPhysics(),
      child: Column(
        children: [
          const SpaceWidget(vSpace: 10),
          FrostedGlassSimpleBox(
              child: Column(
            children: [
              _buildVideoAndPicturesSection(),
              _buildDetailInfoSection(),
            ],
          )),
          const SpaceWidget(
            vSpace: 120,
          )
        ],
      ),
    );
  }

  /// 解锁弹出框
  void handleUnlock() {
    UnlockCheckUtil.datingCheck(context, '${datingInfo.id}', unlockInfo,
        title: StringRes.str_unlock_lou_feng, paySuccessFunc: (data) {
      onLoadData();
    });
  }

  /// 投诉按钮
  Widget titleRightBtn() {
    return GestureDetector(
        onTap: () {
          if (infoId.isNotEmpty) {
            context.push("/feedBack/$infoId");
          }
        },
        child: AppImgWidget(
          path: ImgRes.IC_WARN,
          width: DimenRes.dimen_35,
          height: DimenRes.dimen_35,
        ));
  }

  /// 竖版列表项
  /// [title]上部文字
  /// [value]下部文字
  Widget _basicItemSection({
    required String title,
    required String value,
  }) {
    return Expanded(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          TextWidget.buildSingleLineText(
            title,
            AppTextStyle.build(Colors.white.withOpacity(0.64), 12),
          ),
          const SpaceWidget(
            vSpace: 2,
          ),
          TextWidget.buildSingleLineText(value, AppTextStyle.white_s12),
        ],
      ),
    );
  }

  /// 横版列表项
  /// [title]左侧 TextSpan 部件
  /// [value]右侧 TextSpan 部件
  Widget _buildHorizontalItem(
    String key,
    String value,
  ) {
    return Text.rich(TextSpan(
      text: key,
      style: AppTextStyle.build(Colors.white.withOpacity(0.64), 12),
      children: [
        TextSpan(
          text: value,
          style: AppTextStyle.white_s12,
        ),
      ],
    ));
  }

  /// 联系方式是否显示
  Widget _buildContactInfoSection() {
    Widget tempWidget = const SizedBox();
    if (unlocked && isLouFeng) {
      tempWidget = _buildHorizontalItem(
        '联系方式：',
        contactNumber.toString(),
      );
    } else if (unlocked && !isLouFeng) {
      tempWidget = GestureDetector(
        onTap: () {
          context.push("/datingOrder/$infoId");
        },
        child: _buildHorizontalItem(
          '联系方式：',
          '点击此处联系官方',
        ),
      );
    } else {
      tempWidget = _buildHorizontalItem(
        '联系方式：',
        '购买后显示联系方式',
      );
    }
    return Container(
      alignment: Alignment.centerLeft,
      padding: EdgeInsets.only(
          top: DimenRes.dimen_10,
          left: DimenRes.dimen_30,
          right: DimenRes.dimen_30,
          bottom: DimenRes.dimen_30),
      child: tempWidget,
    );
  }

  /// 底部导航列表
  List<Widget> _buildBottomNavSection() {
    List bottomNavList = [
      {
        "show": unlocked, // 是否解锁=>对应是否显示
        "isActive": false, // 是否被点击
        "src": ImgRes.IC_COMMENT, // 默认icon
        "srcActive": ImgRes.IC_COMMENT, // 点击之后的icon
        "title": '评论', // 默认文字
        "titleActive": '评论', // 点击之后的文字
        "onTap": () {
          return showModalBottomSheet(
            backgroundColor: Colors.transparent, // 背景色
            context: context,
            builder: (BuildContext context) {
              return SheetComment(id: infoId);
            },
          );
        }, // 点击事件
      },
      {
        "show": true,
        "isActive": isCollected,
        "src": ImgRes.IC_NO_LIKE,
        "srcActive": ImgRes.IC_LIKED,
        "title": '收藏',
        "titleActive": '已收藏',
        "onTap": () {
          if (isCollecting) {
            isCollecting = false;
            HttpHelper.likeDatingAction(infoId, (data) {
              isCollecting = true;
              LikeResultModel likeResultModel = LikeResultModel.fromJson(data);
              isCollected = likeResultModel.isLike == 1;
            }, (error) {
              isCollecting = true;
            });
          }
        },
      },
      {
        "show": true,
        "isActive": false,
        "src": ImgRes.IC_SHARE,
        "srcActive": ImgRes.IC_SHARE,
        "title": '分享',
        "titleActive": '分享',
        "onTap": () {
          PageJumpUtil.forwardToSharePage(context);
        },
      },
      {
        "show": unlocked,
        "isActive": false,
        "src": ImgRes.IC_REPORT,
        "srcActive": ImgRes.IC_REPORTED,
        "title": '发布验证',
        "titleActive": '发布验证',
        "onTap": () {
          return context.push('/reportSend/$infoId');
        },
      },
    ];
    List<Widget> widgetList = [];
    for (int i = 0; i < bottomNavList.length; i++) {
      Widget tempWidget = const SizedBox();
      if (bottomNavList[i]['show']) {
        tempWidget = Expanded(
          child: FunBtnItem(
            isActive: bottomNavList[i]['isActive'],
            src: bottomNavList[i]['src'],
            srcActive: bottomNavList[i]['srcActive'],
            title: bottomNavList[i]['title'],
            titleActive: bottomNavList[i]['titleActive'],
            onTap: bottomNavList[i]['onTap'],
          ),
        );
      }
      widgetList.add(tempWidget);
    }
    return widgetList;
  }

  /// 用户详细信息块
  _buildDetailInfoSection() {
    return Column(
      children: [
        Padding(
          padding: EdgeInsets.only(
              top: DimenRes.dimen_15,
              left: DimenRes.dimen_10,
              right: DimenRes.dimen_10),
          child: Column(
            children: [
              StringUtil.isNotEmpty(datingInfo.girlPrice)
                  ? TextWidget.buildSingleLineText(
                      datingInfo.girlPrice!,
                      AppTextStyle.cff00b3_s14,
                    )
                  : const SizedBox(),
              _buildBasicInfoSection(),
              ..._buildInfoSection(),
              _buildContactInfoSection(),
            ],
          ),
        ),
        _buildBottomFun(),
      ],
    );
  }

  _buildBottomFun() {
    return Container(
      padding: EdgeInsets.symmetric(
        vertical: DimenRes.dimen_10,
      ),
      decoration: BoxDecoration(
        color: const Color.fromRGBO(0, 0, 0, 0.24),
        borderRadius: BorderRadius.vertical(
          bottom: Radius.circular(
            DimenRes.radius(12),
          ),
        ),
      ),
      child: Row(
        children: _buildBottomNavSection(),
      ),
    );
  }

  _buildInfoSection() {
    return [
      Container(
          padding: EdgeInsets.only(
            top: DimenRes.dimen_15,
            left: DimenRes.dimen_30,
            right: DimenRes.dimen_30,
          ),
          alignment: Alignment.centerLeft,
          child: _buildHorizontalItem(
            '类型：',
            datingInfo.typeStr ?? '',
          )),
      Container(
        padding: EdgeInsets.only(
          top: DimenRes.dimen_10,
          left: DimenRes.dimen_30,
          right: DimenRes.dimen_30,
        ),
        alignment: Alignment.centerLeft,
        child: _buildHorizontalItem(
          '营业时间：',
          datingInfo.girlBusinessHours ?? '',
        ),
      ),
      Container(
        padding: EdgeInsets.only(
          top: DimenRes.dimen_10,
          left: DimenRes.dimen_30,
          right: DimenRes.dimen_30,
        ),
        alignment: Alignment.centerLeft,
        child: _buildHorizontalItem(
          '服务项目：',
          datingInfo.girlServiceType ?? '',
        ),
      ),
      Container(
        alignment: Alignment.centerLeft,
        padding: EdgeInsets.only(
          top: DimenRes.dimen_10,
          left: DimenRes.dimen_30,
          right: DimenRes.dimen_30,
        ),
        child: _buildHorizontalItem(
          '标签：',
          datingInfo.girlTags ?? '',
        ),
      )
    ];
  }

  _buildBasicInfoSection() {
    return Container(
      alignment: Alignment.center,
      margin: EdgeInsets.only(
        top: DimenRes.dimen_15,
      ),
      padding:
          EdgeInsets.only(top: DimenRes.dimen_10, bottom: DimenRes.dimen_10),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.18),
        borderRadius: BorderRadius.circular(
          DimenRes.radius(12),
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          _basicItemSection(
            title: '年龄',
            value: datingInfo.girlAge.toString(),
          ),
          Text(
            "|",
            style: AppTextStyle.build(Colors.white.withOpacity(0.2), 12),
          ),
          _basicItemSection(
            title: '罩杯',
            value: datingInfo.girlCup ?? '',
          ),
          Text(
            "|",
            style: AppTextStyle.build(Colors.white.withOpacity(0.2), 12),
          ),
          _basicItemSection(
            title: '身高',
            value: datingInfo.girlHeight.toString(),
          ),
          Text(
            "|",
            style: AppTextStyle.build(Colors.white.withOpacity(0.2), 12),
          ),
          _basicItemSection(
            title: '体重',
            value: "${datingInfo.girlWeight}kg",
          ),
        ],
      ),
    );
  }

  /// 购买按钮
  Widget _buildBuyBtnSection() {
    if (unlocked && isLouFeng) {
      return const SizedBox();
    }
    return Positioned(
        bottom: DimenRes.dimen_40,
        left: 0,
        right: 0,
        child: AppTextWithImgBgWidget(
          bgImgPath: ImgRes.BTN_BUY_BIG,
          bgImgHeight: DimenRes.dimen_44,
          text: unlockText,
          textStyle: AppTextStyle.white_s16,
          onTap: () {
            handleUnlock();
          },
        ));
  }

  /// 构造播放模型
  VideoModel getTempVideo(DatingGirlInfoModel data) {
    VideoModel _videoModel = VideoModel();
    _videoModel.playUrl = data.m3u8Full!;
    _videoModel.coverThumbUrl = data.girlPicsUrl?[0] ?? '';
    return _videoModel;
  }

  /// 根据条件判定轮播显示视频和图片
  _buildVideoAndPicturesSection() {
    List mediaList = [];
    bool isHasVideo = false;
    if (StringUtil.isNotEmpty(datingInfo.m3u8Full)) {
      isHasVideo = true;
      mediaList.add({
        "type": "video",
        "url": datingInfo.m3u8Full,
      });
    }
    if (ListUtil.isNotEmpty(datingInfo.girlPicsUrl)) {
      for (var i = 0; i < datingInfo.girlPicsUrl!.length; i++) {
        mediaList.add({
          "type": "image",
          "url": datingInfo.girlPicsUrl![i],
        });
      }
    } else {
      if (StringUtil.isNotEmpty(datingInfo.thumbUrl)) {
        mediaList.add({
          "type": "image",
          "url": datingInfo.thumbUrl,
        });
      }
    }
    return ListUtil.isNotEmpty(mediaList)
        ? Container(
            padding: EdgeInsets.only(
                left: DimenRes.dimen_10,
                right: DimenRes.dimen_10,
                top: DimenRes.dimen_10),
            height: DimenRes.convert(450),
            alignment: Alignment.center,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.all(
                Radius.circular(
                  DimenRes.radius(12),
                ),
              ),
            ),
            child: Swiper(
              loop: false,
              itemCount: mediaList.length,
              physics: const BouncingScrollPhysics(),
              itemBuilder: (context, index) {
                if (mediaList[index]["type"] == 'video') {
                  return LongVideoPlayer(
                    data: getTempVideo(datingInfo),
                  );
                } else {
                  return GestureDetector(
                      onTap: () {
                        PageJumpUtil.forwardToImgPreviewPage(
                            context,
                            ImgPreviewInfo(
                                mediaList.map((item) {
                                  if (item["type"] == "image") {
                                    return item['url'];
                                  }
                                }).toList(),
                                defaultIndex: isHasVideo
                                    ? (index - 1 >= 0 ? index - 1 : 0)
                                    : index));
                      },
                      child: NetworkImgContainer(
                        height: double.infinity,
                        url: mediaList[index]["url"],
                        radius: BorderRadius.circular(10),
                        noVisibilityDetector: true,
                        fit: BoxFit.cover,
                      ));
                }
              },
            ))
        : const SizedBox();
  }
}

/// 按钮
/// [isActive]当前按钮初始化状态{true: 未选中状态,false:选中状态}
/// [src]未选中状态下显示的图片
/// [srcActive]选中状态下显示图片
/// [title]未选中状态显示的文字
/// [titleActive]选中状态显示的文字
/// [onTap]异步函数（注意异步函数要有返回值）
/// 描述：上下布局的按钮行
class FunBtnItem extends StatefulWidget {
  bool? isActive;
  late String src;
  String? srcActive;
  late String title;
  String? titleActive;
  Function onTap;

  FunBtnItem({
    Key? key,
    this.isActive,
    required this.src,
    this.srcActive,
    required this.title,
    this.titleActive,
    required this.onTap,
  }) : super(key: key);

  @override
  State<FunBtnItem> createState() => _FunBtnItemState();
}

class _FunBtnItemState extends State<FunBtnItem> {
  late bool _isActive;
  late String _src;
  late String _srcActive;
  late String _title;
  late String _titleActive;
  bool _isClick = false; // 点击后是否正在执行中

  @override
  void initState() {
    super.initState();
    setState(() {
      _isActive = widget.isActive ?? false;
      _src = widget.src;
      _srcActive = widget.srcActive ?? widget.src;
      _title = widget.title;
      _titleActive = widget.titleActive ?? widget.title;
    });
  }

  @override
  Widget build(BuildContext context) {
    void handle() async {
      if (!_isClick) {
        _isClick = true;
        await widget.onTap();
        setState(() {
          _isActive = !_isActive;
        });
        _isClick = false;
      }
    }

    return GestureDetector(
      onTap: () {
        handle();
      },
      child: Column(
        children: [
          AppImgWidget(
            path: _isActive ? _srcActive : _src,
            width: DimenRes.dimen_28,
            height: DimenRes.dimen_28,
          ),
          const SpaceWidget(
            vSpace: 3,
          ),
          TextWidget.buildSingleLineText(
            _isActive ? _titleActive : _title,
            AppTextStyle.build(Colors.white.withOpacity(0.84), 10),
          )
        ],
      ),
    );
  }
}
