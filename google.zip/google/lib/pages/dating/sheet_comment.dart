import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:iaimei/components/card/card_dating_comment.dart';
import 'package:iaimei/components/common/pagestatus.dart';
import 'package:iaimei/components/common/pullrefreshlist.dart';
import 'package:iaimei/model/chat_model.dart';
import 'package:iaimei/model/basic.dart';
import 'package:iaimei/theme/default.dart';
import 'package:iaimei/utils/api.dart';
import 'package:iaimei/utils/common.dart';

/// 底部评论
class SheetComment extends StatefulWidget {
  final String id;
  const SheetComment({
    Key? key,
    required this.id,
  }) : super(key: key);

  @override
  State<SheetComment> createState() => _SheetCommentState();
}

class _SheetCommentState extends State<SheetComment> {
  // 是否加载中
  bool loading = true;
  // 是否已加载全部列表
  bool isAll = false;
  // 页码
  int page = 1;
  // 每页显示的数据条数
  int limit = 5;
  // 评论列表
  late List<CommentList> data;
  // 输入框控制器
  TextEditingController textEditingController = TextEditingController();

  void getData() async {
    ChatListComment? res = await apiChatGirlListComment(
      id: widget.id,
      page: page,
      limit: limit,
    );
    if (res?.status == 1) {
      List<CommentList> tempData = res!.data.list;
      if (page == 1) {
        data = tempData;
      } else {
        data.addAll(tempData);
      }
      if (data.isEmpty) {
        isAll = true;
      }
      loading = false;
      setState(() {});
    }
  }

  /// 创建评论
  void createComment() async {
    String tempText = textEditingController.text.trim();
    if (tempText == '') {
      Method.showText('评论不能为空');
      return;
    }
    Basic? res = await apiCreateComment(
      id: int.parse(widget.id),
      content: tempText,
    );
    if (res?.status == 1) {
      textEditingController.clear();
      Method.showText(res?.data ?? '评论成功');
      setState(() {
        loading = true;
      });
      page = 1;
      getData();
    } else {
      Method.showText(res?.msg ?? '评论失败');
    }
  }

  @override
  void initState() {
    super.initState();
    getData();
  }

  @override
  void dispose() {
    textEditingController.dispose();
    super.dispose();
  }

  /// 主体
  Widget flex() {
    return Flex(
      direction: Axis.vertical,
      children: [
        Container(
          alignment: Alignment.centerLeft,
          padding: EdgeInsets.all(
            ScreenUtil().setWidth(10.0),
          ),
          decoration: BoxDecoration(
            color: const Color.fromRGBO(44, 40, 63, 1),
            borderRadius: BorderRadius.vertical(
              top: Radius.circular(
                ScreenUtil().setWidth(15.0),
              ),
            ),
          ),
          child: Text(
            '评论',
            style: DefaultStyle.white16,
          ),
        ),
        Expanded(
          flex: 1,
          child: Container(
            color: const Color.fromRGBO(26, 21, 47, 1),
            child: PullRefreshList(
              isAll: isAll,
              onRefresh: () {
                setState(() {
                  page = 1;
                  getData();
                });
              },
              onLoading: () {
                setState(() {
                  page++;
                  getData();
                });
              },
              child: setListWidget(),
            ),
          ),
        ),
        bottomComment(),
      ],
    );
  }

  /// 设置列表
  Widget setListWidget() {
    if (data.isEmpty) {
      return PageStatus.noData(
        padding: EdgeInsets.only(
          top: ScreenUtil().setWidth(20),
        ),
      );
    }
    return ListView.builder(
      itemCount: data.length,
      itemBuilder: (
        BuildContext context,
        int index,
      ) {
        return CardDatingComment(item: data[index]);
      },
    );
  }

  /// 底部评论行
  Widget bottomComment() {
    return Container(
      padding: EdgeInsets.only(
        top: ScreenUtil().setWidth(10.0),
        right: ScreenUtil().setWidth(15.0),
        bottom: ScreenUtil().setWidth(30.0),
        left: ScreenUtil().setWidth(15.0),
      ),
      decoration: const BoxDecoration(
        color: Color.fromRGBO(36, 30, 59, 1),
        border: Border(
          top: BorderSide(
            width: 1,
            color: Color.fromRGBO(255, 255, 255, .2),
          ),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Expanded(
            flex: 1,
            child: Container(
              height: ScreenUtil().setWidth(30.0),
              padding: EdgeInsets.symmetric(
                horizontal: ScreenUtil().setWidth(10.0),
              ),
              decoration: BoxDecoration(
                color: const Color.fromRGBO(255, 255, 255, .1),
                borderRadius: BorderRadius.circular(
                  ScreenUtil().setWidth(15.0),
                ),
              ),
              child: TextField(
                autofocus: false,
                controller: textEditingController,
                style: DefaultStyle.white12,
                textInputAction: TextInputAction.done,
                decoration: InputDecoration(
                  hintText: '留下真实评论的哥哥，都是最帅的男人',
                  hintStyle: DefaultStyle.gray12,
                  contentPadding: EdgeInsets.zero,
                  disabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(30.0),
                    borderSide: const BorderSide(
                      color: Colors.transparent,
                      width: 0,
                    ),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(30.0),
                    borderSide: const BorderSide(
                      color: Colors.transparent,
                      width: 0,
                    ),
                  ),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(30.0),
                    borderSide: const BorderSide(
                      color: Colors.transparent,
                      width: 0,
                    ),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(30.0),
                    borderSide: const BorderSide(
                      color: Colors.transparent,
                      width: 0,
                    ),
                  ),
                ),
              ),
            ),
          ),
          GestureDetector(
            onTap: () => {
              createComment(),
            },
            child: Container(
              margin: EdgeInsets.only(
                left: ScreenUtil().setWidth(5.0),
              ),
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Positioned(
                    child: Image.asset(
                      'assets/images/button/btn_small.png',
                      width: ScreenUtil().setWidth(62.0),
                      height: ScreenUtil().setWidth(34.0),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(
                      bottom: ScreenUtil().setWidth(5.0),
                    ),
                    child: Text(
                      '发送',
                      style: DefaultStyle.white14,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// 全局加载状态
  Widget init() {
    Widget loadingWidget = PageStatus.loading(true);
    return loading ? loadingWidget : flex();
  }

  @override
  Widget build(BuildContext context) {
    return init();
  }
}
