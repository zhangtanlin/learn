import 'package:flutter/material.dart';
import 'package:iaimei/pages/dating/dating_sort_list_page.dart';
import 'package:iaimei/model/dating_home_top_model.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/res/img_res.dart';
import 'package:iaimei/style/app_text_style.dart';
import 'package:iaimei/utils/list_util.dart';
import 'package:iaimei/widget/app_img_widget.dart';
import 'package:iaimei/widget/keep_alive_wrapper.dart';
import 'package:iaimei/widget/top_tab_navigator.dart';

/// 约炮二级选项卡
/// [url]二级选项卡请求接口地址
/// [type]一级选项卡类型{"recommend":"为你推荐","normal":"普通专区","feature":"精品专区","verify":"验车报告"}
/// [data]二级选项卡列表
class DatingSortPage extends StatefulWidget {
  final String? url;
  final String? tabType;
  final List<DatingSubTabModel>? subTabs;

  const DatingSortPage({
    Key? key,
    this.url,
    this.tabType,
    this.subTabs,
  }) : super(key: key);

  @override
  State<DatingSortPage> createState() => _DatingSortPageState();
}

class _DatingSortPageState extends State<DatingSortPage>
    with SingleTickerProviderStateMixin {
  late TopTabNavConfig _tabNavConfig;

  @override
  void initState() {
    super.initState();

    _tabNavConfig = TopTabNavConfig(
        tabItemWidth: DimenRes.convert(64),
        tabItemHeight: DimenRes.convert(28),
        tabHeight: DimenRes.dimen_28,
        navMargin:
            EdgeInsets.only(top: DimenRes.dimen_10, bottom: DimenRes.dimen_5),
        selectedTextColor: Colors.white,
        isScrollable: true,
        textColor: Colors.white,
        tabItemMargin: EdgeInsets.only(right: DimenRes.dimen_10),
        textStyle: AppTextStyle.white_s12,
        indicatorWidget: AppImgWidget(
          path: ImgRes.BTN_MIDDLE_S,
        ),
        selectedTextStyle: AppTextStyle.white_s12,
        tabItemDecoration: BoxDecoration(
            borderRadius:
                BorderRadius.all(Radius.circular(DimenRes.radius(20))),
            border:
                Border.all(width: 0.5, color: Colors.white.withOpacity(0.3))));
  }

  @override
  Widget build(BuildContext context) {
    if (ListUtil.isNotEmpty(widget.subTabs)) {
      return _buildSecondTabSection(widget.subTabs!);
    } else {
      return KeepAliveWrapper(
        child: DatingSortListPage(
          url: widget.url,
          tabType: widget.tabType,
          subTabType: 0,
        ),
      );
    }
  }

  /// 有二级选项卡时显示的选项卡
  Widget _buildSecondTabSection(List<DatingSubTabModel> subTabs) {
    return TopTabNavigator(
      config: _tabNavConfig,
      pages: [
        for (var i = 0; i < subTabs.length; i++) ...[
          KeepAliveWrapper(
            child: DatingSortListPage(
              url: widget.url,
              tabType: widget.tabType,
              subTabType: subTabs[i].id,
            ),
          ),
        ]
      ],
      tabItems: [
        for (var i = 0; i < subTabs.length; i++) ...[
          subTabs[i].name ?? '',
        ]
      ],
    );
  }
}
