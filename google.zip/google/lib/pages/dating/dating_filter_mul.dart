import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:iaimei/model/dating_filter_item_model.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/res/img_res.dart';
import 'package:iaimei/style/app_text_style.dart';
import 'package:iaimei/widget/app_img_widget.dart';
import 'package:iaimei/widget/frosted_glass_box.dart';
import 'package:iaimei/widget/text_widget.dart';

class DartingFilterMul extends StatelessWidget {
  final DatingFilterItemModel data;
  final List selectList;
  final Function? onTap;

  const DartingFilterMul({
    Key? key,
    required this.data,
    this.selectList = const [],
    this.onTap,
  }) : super(key: key);

  Widget _buildBtnItem(int index, DatingFilterTags item) {
    double itemWidth = (DimenRes.screenWidth - DimenRes.convert(86)) / 4;
    Widget tempWidget;
    if (selectList.contains(item.value)) {
      tempWidget = Container(
          width: itemWidth,
          alignment: Alignment.center,
          child: Stack(
            children: [
              AppImgWidget(
                path: ImgRes.BTN_DATING_FILTER,
                height: DimenRes.dimen_30,
                fit: BoxFit.contain,
              ),
              Positioned.fill(
                  child: Container(
                alignment: Alignment.center,
                child: TextWidget.buildSingleLineText(
                  item.label ?? '',
                  AppTextStyle.white_s12,
                ),
              )),
            ],
          ));
    } else {
      tempWidget = FrostedGlassSimpleBox(
        width: itemWidth,
        height: DimenRes.dimen_30,
        borderRadius: BorderRadius.circular(
          DimenRes.radius(15),
        ),
        child: Container(
          alignment: Alignment.center,
          child: TextWidget.buildSingleLineText(
            item.label ?? '',
            AppTextStyle.white_s12,
          ),
        ),
      );
    }
    return GestureDetector(
      onTap: () {
        if (onTap != null) onTap!(item.value);
      },
      child: tempWidget,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      alignment: Alignment.centerLeft,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.only(
              top: ScreenUtil().setWidth(25.0),
              bottom: ScreenUtil().setWidth(15.0),
            ),
            child: Text(
              "服务项目",
              style: AppTextStyle.white_s16,
            ),
          ),
          Wrap(
            spacing: DimenRes.dimen_15,
            runSpacing: DimenRes.dimen_15,
            children: [
              for (int i = 0; i < data.tags!.length; i++) ...[
                _buildBtnItem(i, data.tags![i]),
              ],
            ],
          ),
        ],
      ),
    );
  }
}
