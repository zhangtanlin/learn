import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:iaimei/app_const.dart';
import 'package:iaimei/global.dart';
import 'package:iaimei/model/ads_model.dart';
import 'package:iaimei/pages/home_page.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/res/img_res.dart';
import 'package:iaimei/res/string_res.dart';
import 'package:iaimei/style/app_text_style.dart';
import 'package:iaimei/utils/line_util.dart';
import 'package:iaimei/utils/loading_util.dart';
import 'package:iaimei/utils/string_util.dart';
import 'package:iaimei/widget/app_text_with_img_bg_widget.dart';
import 'package:iaimei/widget/banner_widget.dart';
import 'package:iaimei/widget/toast_widget.dart';

class SplashPage extends StatefulWidget {
  const SplashPage({Key? key}) : super(key: key);

  @override
  _SplashPageState createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> {
  int _curIndex = 0;
  DateTime? _lastPressedAt; //上次点击时间
  Map? _splashAdMap;
  Timer? _timer;
  int curTime = 5;

  @override
  void initState() {
    super.initState();

    dynamic tempAdData = AppGlobal.appBox!.get(AppConst.splashAdKey);
    if (tempAdData != null) {
      _splashAdMap = tempAdData;
    }

    LoadingUtil.showLoading(tips: StringRes.str_loading);
    LineUtil.check(onSuccess: () {
      LoadingUtil.closeLoading();
      setAdCountDown();
      if (_splashAdMap == null) {
        setHomeIndex();
      }
    }, onFailed: () {
      LoadingUtil.closeLoading();
      ToastWidget.showToast(StringRes.str_no_net_retry);
    });
  }

  void setHomeIndex() {
    _curIndex = 1;
    setState(() {});
  }

  void setAdCountDown() {
    if (_splashAdMap == null) return;
    _timer ??= Timer.periodic(const Duration(seconds: 1), (Timer timer) {
      if (curTime <= 1) {
        _timer!.cancel();
        setHomeIndex();
        return;
      }
      setState(() {
        curTime--;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        if (_lastPressedAt == null ||
            DateTime.now().difference(_lastPressedAt!) >
                const Duration(seconds: 2)) {
          //两次点击间隔超过2秒则重新计时
          _lastPressedAt = DateTime.now();
          ToastWidget.showToast('再按一下退出程序');
          return false;
        }
        return true;
      },
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: GestureDetector(
            onTap: () {
              FocusScopeNode currentFocus = FocusScope.of(context);
              if (!currentFocus.hasPrimaryFocus &&
                  currentFocus.focusedChild != null) {
                FocusManager.instance.primaryFocus?.unfocus();
              }
            },
            behavior: HitTestBehavior.translucent,
            child: _curIndex == 0
                ? _splashAdMap != null
                    ? Stack(
                        children: [
                          SizedBox(
                              width: double.infinity,
                              height: double.infinity,
                              child: GestureDetector(
                                child: Image.memory(
                                  _splashAdMap!['img_url'],
                                  width: double.infinity,
                                  height: double.infinity,
                                  fit: BoxFit.cover,
                                ),
                                onTap: () {
                                  if (_splashAdMap == null ||
                                      StringUtil.isEmpty(
                                          _splashAdMap!['url'])) {
                                    return;
                                  }
                                  BannerWidget.parseAdType(
                                      context,
                                      AdsModel(
                                          type: _splashAdMap!['type'],
                                          url: _splashAdMap!['url']));
                                },
                              )),
                          Positioned(
                            top: DimenRes.dimen_20 +
                                ScreenUtil().statusBarHeight,
                            right: DimenRes.dimen_30,
                            child: AppTextWithImgBgWidget(
                              text: '${curTime}s',
                              bgImgPath: ImgRes.IMG_BG_GRAY_BTN,
                              bgImgHeight: DimenRes.dimen_30,
                              textStyle: AppTextStyle.white_s15_bold,
                            ),
                          )
                        ],
                      )
                    : Image.asset(
                        ImgRes.IMG_SPLASH,
                        width: DimenRes.screenWidth,
                        height: DimenRes.screenHeight,
                        fit: BoxFit.cover,
                      )
                : const HomePage()),
      ),
    );
  }

  @override
  void dispose() {
    super.dispose();
    if (_timer != null) {
      _timer!.cancel();
      _timer = null;
    }
  }
}
