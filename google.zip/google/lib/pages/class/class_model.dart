class ClassModalModel {
  int id = 0;
  String name = '';
  String subName = '';
  List<ClassItemModel> items = [];
  ClassModalModel();
  ClassModalModel.fromJson(Map<String, dynamic> json) {
    id = json['id'] ?? 0;
    name = json['name'] ?? '';
    subName = json['sub_name'] ?? '';
    items = (json['items'] as List)
        .map<ClassItemModel>((item) => ClassItemModel.fromJson(item))
        .toList();
  }
}

class ClassItemModel {
  int id = 0;
  String name = '';
  String target = '';
  ClassItemModel();
  ClassItemModel.fromJson(Map<String, dynamic> json) {
    id = json['id'] ?? 0;
    name = json['name'] ?? '';
    target = json['target'] ?? '';
  }
}
