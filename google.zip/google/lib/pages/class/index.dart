import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:iaimei/components/common/commonelements.dart';
import 'package:iaimei/components/common/pullrefreshlist.dart';
import 'package:iaimei/components/common/stackpage.dart';
import 'package:iaimei/model/comics_index_list_model.dart';
import 'package:iaimei/model/novel_list_model.dart';
import 'package:iaimei/net/http_helper.dart';
import 'package:iaimei/pages/class/class_model.dart';
import 'package:iaimei/res/img_res.dart';
import 'package:iaimei/router/routers.dart';
import 'package:iaimei/utils/page_jump_util.dart';
import 'package:iaimei/widget/convenient_mixin.dart';
import 'package:iaimei/widget/state_mixin.dart';

class ClassIndex extends StatefulWidget {
  const ClassIndex({Key? key}) : super(key: key);

  @override
  State<ClassIndex> createState() => _ClassIndexState();
}

class _ClassIndexState extends State<ClassIndex>
    with ConvenientMixin, StateMixin {
  @override
  initLoadingData() {
    HttpHelper.categoryList((data) {
      var list = [];
      try {
        list = (data['list'] as List)
            .map((item) => ClassModalModel.fromJson(item))
            .toList();
      } catch (e) {
        debugPrint(e.toString());
      }
      updateListAndWidgetState(list);
    }, dealWithErrorsWidgetState);
  }

  List<Widget> rListWidget() {
    return [
      ActionIcon(
        onTap: () {
          context.go('/search');
        },
        url: ImgRes.IC_SEARCH,
      ),
      ActionIcon(
        onTap: () {
          context.push('/filter');
        },
        url: "assets/images/common/ic_filter.png",
      ),
    ];
  }

  @override
  Widget build(BuildContext context) {
    return StackPage(
      header: CustomHeader(
        title: '分类',
        rListWidget: rListWidget(),
      ),
      child: Align(alignment: Alignment.topCenter, child: _buildChildWidget()),
    );
  }

  Widget _buildChildWidget() {
    if (widgetState != WidgetState.finish &&
        widgetState != WidgetState.noData) {
      return placeholderWidget();
    }
    return PullRefreshList(
      child: ListView.builder(
        itemCount: dataList.length,
        padding: EdgeInsets.symmetric(horizontal: 16.w),
        itemBuilder: (context, index) {
          return _buildGroupItem(dataList[index]);
        },
      ),
      isAll: true,
      onRefresh: onRefresh,
    );
  }

  onTap() {}

  Widget _buildGroupItem(ClassModalModel item) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Row(
          children: [
            Text(
              item.name,
              style:
                  TextStyle(color: wColor, fontSize: 16.sp, fontWeight: fontM),
            ),
            SizedBox(width: 10.w),
            Text(
              item.subName,
              style: TextStyle(fontSize: 12.sp, color: color_72),
            ),
          ],
        ),
        GridView.builder(
          itemCount: item.items.length,
          padding: EdgeInsets.only(top: 11.w, bottom: 21.w),
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 4,
            childAspectRatio: 41 / 18,
            mainAxisSpacing: 5.w,
            crossAxisSpacing: 5.w,
          ),
          itemBuilder: (context, index) {
            return GestureDetector(
              onTap: () {
                switch (item.items[index].target) {
                  case 'special': // 特价编号 视频列表 (首页特价模块)

                    break;
                  case 'series': // 系列编号 视频列表 (首页国产模块)
                    WaterfallExtra object = WaterfallExtra(
                      title: item.items[index].name,
                      crossAxisCount: 1,
                      url: '/api/menu/series_mv',
                      params: {'id': item.items[index].id},
                    );
                    context.push('/${Routes.mvListViewPage}', extra: object);
                    break;
                  case 'mh': // 漫画系列 漫画列表
                    var json = {
                      'id': item.items[index].id,
                      'name': item.items[index].name
                    };
                    var model = ComicsListModel.fromJson(json);
                    PageJumpUtil.forwardToComicsSeriesPage(context, model);
                    break;
                  case 'story': // 小说系列 指定特价
                    var json = {
                      'id': item.items[index].id,
                      'name': item.items[index].name
                    };
                    var model = NovelListModel.fromJson(json);
                    PageJumpUtil.forwardToNovelSeriesPage(context, model);
                    break;
                  default:
                }
              },
              child: Container(
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(6.w),
                    gradient: const LinearGradient(colors: [
                      Color.fromRGBO(133, 102, 255, 0.1),
                      Color.fromRGBO(255, 255, 255, 0.02)
                    ]),
                    border: Border.all(
                        color: const Color.fromRGBO(255, 255, 255, 0.05),
                        width: 0.5.w)),
                child: Center(
                  child: Text(
                    item.items[index].name,
                    style: TextStyle(fontSize: 12.sp, color: color_84),
                    textAlign: TextAlign.center,
                    maxLines: 2,
                  ),
                ),
              ),
            );
          },
        ),
      ],
    );
  }
}
