import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
class PageA extends StatefulWidget {
  const PageA({Key? key}) : super(key: key);

  @override
  State<PageA> createState() => _PageAState();
}

class _PageAState extends State<PageA> {
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(top: 40),
      child: ElevatedButton.icon(
        icon: Icon(Icons.message),
        label: Text("聊天"),
        onPressed: (){
          context.push('/pageA/videoPlayer');
        },
      ),
    );
  }
}
