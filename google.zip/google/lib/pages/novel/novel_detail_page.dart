import 'package:flutter/material.dart';
import 'package:iaimei/base/app_base_widget_state.dart';
import 'package:iaimei/global.dart';
import 'package:iaimei/mixin/page_load_mixin.dart';
import 'package:iaimei/model/novel_brief_model.dart';
import 'package:iaimei/model/novel_detail_model.dart';
import 'package:iaimei/model/novel_item_model.dart';
import 'package:iaimei/net/http_error.dart';
import 'package:iaimei/net/http_helper.dart';
import 'package:iaimei/pages/novel/novel_item_widget.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/res/img_res.dart';
import 'package:iaimei/res/string_res.dart';
import 'package:iaimei/style/app_text_style.dart';
import 'package:iaimei/utils/dialog_util.dart';
import 'package:iaimei/utils/list_util.dart';
import 'package:iaimei/utils/page_jump_util.dart';
import 'package:iaimei/utils/string_util.dart';
import 'package:iaimei/utils/unlock_check_util.dart';
import 'package:iaimei/widget/app_divider_widget.dart';
import 'package:iaimei/widget/app_img_widget.dart';
import 'package:iaimei/widget/app_page_title_bar.dart';
import 'package:iaimei/widget/list_widget.dart';
import 'package:iaimei/widget/network_img_container.dart';
import 'package:iaimei/widget/space_widget.dart';
import 'package:iaimei/widget/text_widget.dart';

class NovelDetailPage extends StatefulWidget {
  final NovelItemModel item;

  const NovelDetailPage({Key? key, required this.item}) : super(key: key);

  @override
  State<NovelDetailPage> createState() => _NovelDetailPageState();
}

class _NovelDetailPageState extends AppBaseWidgetState<NovelDetailPage>
    with PageLoadMixin {
  late NovelDetailModel _detailModel;
  late NovelItemModel _itemModel;
  List<NovelItemModel> novelItemList = [];

  @override
  void initState() {
    super.initState();
    _itemModel = widget.item;
    onLoadData();
  }

  @override
  buildAppBar() {
    return AppPageTitleBar.getNormalAppBar();
  }

  @override
  Widget buildPageLayout() {
    return handlePageStateView();
  }

  @override
  onLoadData() {
    HttpHelper.getNovelDetail('${_itemModel.id}', (data) {
      try {
        _detailModel = NovelDetailModel.fromJson(data);
        setPageState(_detailModel.detail != null);
        getNovelMore();
      } catch (e) {
        setPageErrorState(HttpError());
      }
    }, (error) {
      setPageErrorState(error);
    });
  }

  @override
  Widget successView() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildTopCoverSection(),
          _buildCatalogTitleSection(),
          _buildKeepWatchBtn(),
          AppDividerWidget(
              padding: EdgeInsets.only(
                  left: DimenRes.dimen_15, right: DimenRes.dimen_15)),
          _buildYouMayLikeSection()
        ],
      ),
    );
  }

  _buildYouMayLikeSection() {
    return ListUtil.isNotEmpty(novelItemList)
        ? Container(
            margin: EdgeInsets.only(
                left: DimenRes.dimen_15,
                right: DimenRes.dimen_15,
                bottom: DimenRes.dimen_20,
                top: DimenRes.dimen_20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextWidget.buildSingleLineText(
                    StringRes.str_you_may_like, AppTextStyle.white_s18),
                const SpaceWidget(vSpace: 10),
                _buildSeriesGridView(novelItemList)
              ],
            ),
          )
        : const SizedBox();
  }

  _buildSeriesGridView(List resultList) {
    return ListWidget.buildGridView(
        itemCount: resultList.length,
        itemBuilder: (context, index) =>
            _buildNovelSeriesItem(resultList[index] as NovelItemModel),
        childRatio: 0.618,
        mainSpace: DimenRes.dimen_15,
        crossSpace: DimenRes.dimen_15,
        crossCount: 3);
  }

  _buildNovelSeriesItem(NovelItemModel itemModel) {
    double width = (DimenRes.screenWidth - DimenRes.dimen_60) / 3;
    double height = width * 7 / 5;
    return InkWell(
      child: NovelItemWidget(
          itemData: itemModel, imgWidth: width, imgHeight: height),
      onTap: () {
        _itemModel = itemModel;
        onLoadData();
      },
    );
  }

  _buildCatalogTitleSection() {
    return InkWell(
      onTap: () {
        DialogUtil.showNovelCatalogListDialog(
            context,
            '${_detailModel.detail!.id}',
            _detailModel.detail?.updateInfo, ((itemModel) {

          UnlockCheckUtil.novelCheck(
              context, '${_detailModel.detail!.id}', itemModel.payData,
              freeFunc: () {
            PageJumpUtil.forwardToNovelReaderPage(
                context,
                widget.item,
                NovelBriefModel(
                    _detailModel.detail!.id!,
                    itemModel.series!,
                    _detailModel.total!,
                    _detailModel.detail!.title!,
                    _detailModel.detail!.updateInfo!));

          });
        }));
      },
      child: Container(
        margin: EdgeInsets.only(
            left: DimenRes.dimen_15,
            right: DimenRes.dimen_15,
            bottom: DimenRes.dimen_20,
            top: DimenRes.dimen_30),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            TextWidget.buildSingleLineText(
                StringRes.str_catalog, AppTextStyle.white_s16),
            TextWidget.buildSingleLineText(
                '${_detailModel.detail?.updateInfo}', AppTextStyle.white_s13),
            AppImgWidget(
              path: ImgRes.IC_ARROW_RIGHT,
              height: DimenRes.dimen_16,
            )
          ],
        ),
      ),
    );
  }

  void getNovelMore() {
    HttpHelper.getNovelMore("${_itemModel.id}", (data) {
      try {
        novelItemList = (data as List)
            .map((json) => NovelItemModel.fromJson(json))
            .toList();
        setState(() {});
      } catch (e) {
        e.toString();
      }
    }, (error) {});
  }

  _buildTopCoverSection() {
    String bgImgUrl = _detailModel.detail?.bgThumbFull ?? "";
    String imgUrl = _detailModel.detail?.imgUrlFull ?? "";
    bgImgUrl = StringUtil.isNotEmpty(bgImgUrl) ? bgImgUrl : imgUrl;
    return Container(
      margin: EdgeInsets.only(
          left: DimenRes.dimen_15,
          right: DimenRes.dimen_15,
          top: DimenRes.dimen_5),
      child: Stack(
        children: [
          Opacity(
              opacity: 0.16,
              child: NetworkImgContainer(
                  url: bgImgUrl,
                  height: DimenRes.dimen_160,
                  radius: BorderRadius.circular(10))),
          Positioned(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                NetworkImgContainer(
                    url: imgUrl,
                    width: DimenRes.dimen_105,
                    height: DimenRes.dimen_140,
                    radius: BorderRadius.circular(10)),
                Expanded(
                    child: Container(
                  margin: EdgeInsets.only(left: DimenRes.dimen_15),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      TextWidget.buildSingleLineText(
                          '${_detailModel.detail?.title}',
                          AppTextStyle.white_s16),
                      const Spacer(),
                      TextWidget.buildSingleLineText(
                          '阅览${_detailModel.detail?.viewCount ?? 0}',
                          AppTextStyle.white_s12)
                    ],
                  ),
                ))
              ],
            ),
            left: DimenRes.dimen_10,
            right: DimenRes.dimen_10,
            top: DimenRes.dimen_10,
            bottom: DimenRes.dimen_10,
          )
        ],
      ),
    );
  }

  _buildKeepWatchBtn() {
    dynamic tempData = AppGlobal.novelWatchRecordBox
        ?.get('${_detailModel.detail?.id}', defaultValue: '');
    return tempData != null && tempData != ''
        ? InkWell(
            onTap: () {
              PageJumpUtil.forwardToNovelReaderPage(
                  context,
                  widget.item,
                  NovelBriefModel(
                      _detailModel.detail!.id!,
                      tempData['episode'],
                      _detailModel.total!,
                      _detailModel.detail!.title!,
                      _detailModel.detail!.updateInfo!));
            },
            child: Container(
              alignment: Alignment.center,
              margin: EdgeInsets.only(bottom: DimenRes.dimen_15),
              child: Stack(
                children: [
                  AppImgWidget(
                    path: ImgRes.IMG_BG_BTN,
                    height: DimenRes.dimen_44,
                  ),
                  Positioned.fill(
                      left: 20,
                      right: 20,
                      top: 6,
                      bottom: 10,
                      child: Container(
                        alignment: Alignment.center,
                        child: TextWidget.buildSingleLineText(
                            '继续观看  第 ${tempData['episode']} 章',
                            AppTextStyle.white_s12),
                      )),
                ],
              ),
            ),
          )
        : const SizedBox();
  }

  @override
  void dispose() {
    HttpHelper.cancelNovelDetail();
    HttpHelper.cancelNovelMore();
    super.dispose();
  }
}
