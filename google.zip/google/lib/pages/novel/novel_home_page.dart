import 'package:flutter/material.dart';
import 'package:iaimei/base/app_base_widget_state.dart';
import 'package:iaimei/mixin/page_load_mixin.dart';
import 'package:iaimei/model/ads_model.dart';
import 'package:iaimei/model/novel_index_model.dart';
import 'package:iaimei/net/http_error.dart';
import 'package:iaimei/net/http_helper.dart';
import 'package:iaimei/pages/novel/novel_home_sort_page.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/res/img_res.dart';
import 'package:iaimei/res/string_res.dart';
import 'package:iaimei/style/app_text_style.dart';
import 'package:iaimei/utils/list_util.dart';
import 'package:iaimei/utils/page_jump_util.dart';
import 'package:iaimei/widget/app_img_widget.dart';
import 'package:iaimei/widget/app_page_title_bar.dart';
import 'package:iaimei/widget/banner_widget.dart';
import 'package:iaimei/widget/keep_alive_wrapper.dart';
import 'package:iaimei/widget/snap_top_tab_navigator.dart';

class NovelHomePage extends StatefulWidget {
  const NovelHomePage({Key? key}) : super(key: key);

  @override
  State<NovelHomePage> createState() => _NovelHomePageState();
}

class _NovelHomePageState extends AppBaseWidgetState<NovelHomePage>
    with PageLoadMixin {
  late SnapTopTabNavConfig _tabNavConfig;
  late List<TabData> _tabList;
  late List<AdsModel> _adList;

  @override
  buildAppBar() {
    return AppPageTitleBar.getNormalAppBar(
        title: StringRes.str_novel,
        rightWidget: AppImgWidget(
          path: ImgRes.IC_SEARCH,
          width: DimenRes.dimen_35,
          height: DimenRes.dimen_35,
          onTap: () {
            PageJumpUtil.forwardToSearchPage(context);
          },
        ));
  }

  @override
  void initState() {
    super.initState();
    onLoadData();
    _tabNavConfig = SnapTopTabNavConfig(
        snapTopHeight: DimenRes.convert(44),
        snapTopMargin: EdgeInsets.only(top: DimenRes.dimen_10),
        snapTopBgColor: Colors.transparent,
        tabItemMargin: EdgeInsets.only(right: DimenRes.dimen_30),
        textStyle: AppTextStyle.white_s15,
        navMargin:
            EdgeInsets.only(left: DimenRes.dimen_15, right: DimenRes.dimen_15),
        selectedTextStyle: AppTextStyle.cff00b3_s15_bold);
  }

  @override
  Widget buildPageLayout() {
    return handlePageStateView();
  }

  @override
  onLoadData() {
    HttpHelper.getNovelIndex((data) {
      try {
        NovelIndexModel novelIndexModel = NovelIndexModel.fromJson(data);
        _tabList = novelIndexModel.data!;
        _adList = novelIndexModel.ads!;
        setPageState(ListUtil.isNotEmpty(novelIndexModel.data));
      } catch (e) {
        setPageErrorState(HttpError());
      }
    }, (error) {
      setPageErrorState(error);
    });
  }

  @override
  Widget successView() {
    return ListUtil.isNotEmpty(_tabList)
        ? SnapTopTabNavigator(
            tabItems: _tabList.map((nav) => '${nav.name}').toList(),
            pages: _tabList
                .map((nav) => KeepAliveWrapper(
                        child: NovelHomeSortPage(
                      tabData: nav,
                    )))
                .toList(),
            foldWidget: _buildSnapTopWidget(),
            config: _tabNavConfig)
        : const SizedBox();
  }

  _buildSnapTopWidget() {
    return ListUtil.isNotEmpty(_adList)
        ? BannerWidget(
            adList: _adList,
            height: DimenRes.dimen_190,
            margin: EdgeInsets.only(
                left: DimenRes.dimen_15,
                top: DimenRes.dimen_8,
                right: DimenRes.dimen_15),
            radius: BorderRadius.circular(12),
          )
        : const SizedBox();
  }
}
