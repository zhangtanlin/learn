import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_html/flutter_html.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:html/parser.dart' show parse;
import 'package:iaimei/global.dart';
import 'package:iaimei/mixin/page_load_mixin.dart';
import 'package:iaimei/model/novel_brief_model.dart';
import 'package:iaimei/model/novel_content_model.dart';
import 'package:iaimei/net/http_error.dart';
import 'package:iaimei/net/http_helper.dart';
import 'package:iaimei/res/color_res.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/res/img_res.dart';
import 'package:iaimei/res/string_res.dart';
import 'package:iaimei/style/app_text_style.dart';
import 'package:iaimei/utils/crypto.dart';
import 'package:iaimei/utils/dialog_util.dart';
import 'package:iaimei/utils/http.dart';
import 'package:iaimei/utils/loading_util.dart';
import 'package:iaimei/utils/log_util.dart';
import 'package:iaimei/utils/page_jump_util.dart';
import 'package:iaimei/utils/string_util.dart';
import 'package:iaimei/utils/unlock_check_util.dart';
import 'package:iaimei/widget/app_back_widget.dart';
import 'package:iaimei/widget/app_img_widget.dart';
import 'package:iaimei/widget/space_widget.dart';
import 'package:iaimei/widget/text_widget.dart';
import 'package:iaimei/widget/toast_widget.dart';
import 'package:iaimei/widget/transition_widget.dart';

enum LoadType { init, last, next }

class NovelReader extends StatefulWidget {
  final NovelBriefModel item;

  const NovelReader({Key? key, required this.item}) : super(key: key);

  @override
  State<NovelReader> createState() => _NovelReaderState();
}

class _NovelReaderState extends State<NovelReader> with PageLoadMixin {
  bool isShow = true; //控制器的隐藏显示
  double _statusBarHeight = 0;
  int? _novelId;
  String? _novelTitle;
  late int _curEpisode;
  int? _totalEpisode;
  String? _updateInfo;
  String? _contentStr;
  ScrollController? _controller;
  Timer? _watchRecordTimer;
  double _scrollOffset = 0;
  bool isReset = false;

  @override
  void initState() {
    super.initState();
    _statusBarHeight = ScreenUtil().statusBarHeight;

    _novelId = widget.item.id;
    _novelTitle = widget.item.title;
    _curEpisode = widget.item.episode;
    _totalEpisode = widget.item.totalEpisode;
    _updateInfo = widget.item.updateInfo;

    WidgetsBinding.instance?.addPostFrameCallback((timeStamp) {
      onLoadData();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.transparent,
      child: Stack(
        children: [
          Image.asset(
            ImgRes.IMG_APP_BG,
            fit: BoxFit.cover,
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height,
          ),
          handlePageStateView()
        ],
      ),
    );
  }

  @override
  onLoadData() {
    _getNovelContentAction();
  }

  @override
  Widget successView() {
    return Stack(
      children: [
        Column(
          children: [
            Expanded(
                child: GestureDetector(
              child: Padding(
                padding: EdgeInsets.only(
                    top: DimenRes.statusBarHeight,
                    left: DimenRes.dimen_15,
                    right: DimenRes.dimen_15),
                child: CustomScrollView(
                  controller: _controller,
                  physics: const BouncingScrollPhysics(),
                  slivers: [
                    SliverToBoxAdapter(
                      child: Column(
                        children: [
                          Html(
                            data: _contentStr ?? "",
                            style: {
                              "*": Style(
                                  color: Colors.white.withOpacity(0.9),
                                  padding: const EdgeInsets.all(0),
                                  margin: const EdgeInsets.all(0),
                                  fontSize: FontSize(DimenRes.sp(15)),
                                  lineHeight: const LineHeight(1.8)),
                            },
                          ),
                          kIsWeb
                              ? Container(
                                  height: DimenRes.dimen_160,
                                  width: DimenRes.screenWidth,
                                  color: Colors.transparent,
                                )
                              : const SizedBox()
                        ],
                      ),
                    )
                  ],
                ),
              ),
              onTap: () {
                _toggleStateAction();
              },
            )),
            Container(
              height: DimenRes.dimen_15,
              width: DimenRes.screenWidth,
              color: Colors.transparent,
            )
          ],
        ),
        _buildContentAboveSection()
      ],
    );
  }

  _toggleStateAction() {
    setState(() {
      isShow = !isShow;
    });
  }

  _buildContentAboveSection() {
    return Positioned(
        bottom: 0,
        left: 0,
        right: 0,
        top: 0,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            TransitionWidget(
                height: DimenRes.dimen_50 + _statusBarHeight,
                top: isShow ? 0 : -(DimenRes.dimen_50 + _statusBarHeight),
                opacity: isShow ? 1 : 0,
                child: _buildTitleSection(),
                time: 500),
            TransitionWidget(
              height: DimenRes.dimen_140,
              bottom: isShow ? 0 : -DimenRes.dimen_140,
              opacity: isShow ? 1 : 0,
              time: 500,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [_buildLikeAndShareBtn(), _buildBottomMenu()],
              ),
            )
          ],
        ));
  }

  _buildTitleSection() {
    return Container(
      height: DimenRes.dimen_50 + _statusBarHeight,
      width: DimenRes.screenWidth,
      color: ColorRes.color_d71a152f,
      alignment: Alignment.centerLeft,
      padding: EdgeInsets.only(top: _statusBarHeight),
      child: Row(
        children: [
          Padding(
            padding: EdgeInsets.symmetric(horizontal: DimenRes.dimen_10),
            child: const AppBackWidget(),
          ),
          Expanded(
              child: Container(
                  alignment: Alignment.center,
                  child: TextWidget.buildSingleLineText(
                      _novelTitle ?? '', AppTextStyle.white_s16))),
          SizedBox(
            width: DimenRes.dimen_50,
          )
        ],
      ),
    );
  }

  _buildLikeAndShareBtn() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        Container(
          margin: EdgeInsets.only(
              right: DimenRes.dimen_15, bottom: DimenRes.dimen_15),
          padding: EdgeInsets.symmetric(
              horizontal: DimenRes.dimen_12, vertical: DimenRes.dimen_3),
          decoration: BoxDecoration(
              color: ColorRes.color_d71a152f,
              borderRadius: BorderRadius.circular(28)),
          child: Row(
            children: [
              AppImgWidget(
                path: ImgRes.IC_READER_LIKE,
                width: DimenRes.dimen_30,
                height: DimenRes.dimen_30,
                onTap: () {
                  _likeNovelItemAction();
                },
              ),
              const SpaceWidget(
                hSpace: 10,
              ),
              AppImgWidget(
                path: ImgRes.IC_READER_SHARE,
                width: DimenRes.dimen_30,
                height: DimenRes.dimen_30,
                onTap: () {
                  PageJumpUtil.forwardToSharePage(context);
                },
              ),
            ],
          ),
        )
      ],
    );
  }

  _likeNovelItemAction() {
    LoadingUtil.showLoading();
    HttpHelper.likeNovel('$_novelId', (data) {
      LoadingUtil.closeLoading();
      if (data != null && data is String && data.isNotEmpty) {
        ToastWidget.showToast(data, align: Alignment.center);
      }
    }, (error) {
      LoadingUtil.closeLoading();
      ToastWidget.showToast(StringRes.str_operate_fail,
          align: Alignment.center);
    });
  }

  _buildBottomMenu() {
    return Container(
      height: DimenRes.dimen_90,
      width: DimenRes.screenWidth,
      color: ColorRes.color_d71a152f,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          GestureDetector(
            child: TextWidget.buildSingleLineText(
              StringRes.str_last_chapter,
              AppTextStyle.white_s12,
            ),
            onTap: () {
              if (_curEpisode == 1) {
                ToastWidget.showToast(StringRes.str_already_first_chapter,
                    align: Alignment.center);
                return;
              }
              _curEpisode = _curEpisode - 1;
              _getNewEpisodeData(loadType: LoadType.last);
            },
          ),
          GestureDetector(
            child: TextWidget.buildSingleLineText(
              StringRes.str_catalog,
              AppTextStyle.white_s14_bold,
            ),
            onTap: () {
              DialogUtil.showNovelCatalogListDialog(
                  context, '$_novelId', _updateInfo ?? '', (itemModel) {
                if (_curEpisode == itemModel.series) {
                  return;
                }
                UnlockCheckUtil.novelCheck(
                    context, '$_novelId', itemModel.payData, freeFunc: () {
                  _curEpisode = itemModel.series ?? 1;
                  _getNewEpisodeData();
                });
              });
            },
          ),
          GestureDetector(
            child: TextWidget.buildSingleLineText(
              StringRes.str_next_chapter,
              AppTextStyle.white_s12,
            ),
            onTap: () {
              if (_curEpisode == _totalEpisode) {
                ToastWidget.showToast(StringRes.str_already_last_chapter,
                    align: Alignment.center);
                return;
              }
              _curEpisode = _curEpisode + 1;
              _getNewEpisodeData(loadType: LoadType.next);
            },
          ),
        ],
      ),
    );
  }

  void _getNewEpisodeData({LoadType loadType = LoadType.init}) {
    _getNovelContentAction(loadType: loadType, isShowLoad: true);
  }

  void _getNovelContentAction(
      {LoadType loadType = LoadType.init, bool isShowLoad = false}) {
    if (isShowLoad) {
      LoadingUtil.showLoading();
    }

    HttpHelper.getNovelContent('$_novelId', '$_curEpisode', (data) {
      if (isShowLoad) {
        LoadingUtil.closeLoading();
      }
      try {
        NovelContentModel contentModel = NovelContentModel.fromJson(data);

        UnlockCheckUtil.novelCheck(context, '$_novelId', contentModel.payData,
            freeFunc: () async {
          if (contentModel.list != null &&
              StringUtil.isNotEmpty(contentModel.list!.urlFull)) {
            NovelContentItem contentItem = contentModel.list!;
            String? contentUrl = contentItem.urlFull;
            String? tempDataStr = await PlatformAwareHttp.getImage(contentUrl);
            if (StringUtil.isNotEmpty(tempDataStr)) {
              dynamic decrypted = PlatformAwareCrypto.decryptImage(tempDataStr);
              if (decrypted != null && decrypted != '') {
                decrypted = base64Decode(decrypted);
                decrypted = utf8.decode(decrypted);
                String tempContentStr = decrypted.toString();
                _contentStr = parse(tempContentStr).body!.text;
                if (StringUtil.isNotEmpty(_contentStr)) {
                  _scrollOffset = 0;
                  isReset = true;
                  if (_controller != null) {
                    _controller!.jumpTo(0);
                  }
                  setPageState(true);
                  _createScrollController();
                  _watchRecordTimer ??= _createWatchRecordTimer();
                } else {
                  setErrorView(loadType);
                }
              } else {
                setErrorView(loadType);
              }
            } else {
              setErrorView(loadType);
            }
          } else {
            setErrorView(loadType);
          }
        }, buyVipFunc: () {
          _resetEpisode(loadType);
        }, payFunc: () {
          _resetEpisode(loadType);
        }, payFailFunc: () {
          _quitRead(loadType);
        }, paySuccessFunc: () {
          _quitRead(loadType);
        }, payCancel: () {
          _quitRead(loadType);
        });
      } catch (e) {
        setErrorView(loadType);
      }
    }, (error) {
      if (isShowLoad) {
        LoadingUtil.closeLoading();
      }
      _resetEpisode(loadType);
      setPageErrorState(error);
    });
  }

  void setErrorView(LoadType loadType) {
    if (loadType == LoadType.init) {
      setPageErrorState(HttpError());
    }
  }

  void _quitRead(LoadType loadType) {
    if (loadType == LoadType.init) {
      context.pop();
    }
  }

  void _resetEpisode(LoadType loadType) {
    if (loadType == LoadType.last) {
      _curEpisode = _curEpisode + 1;
    } else if (loadType == LoadType.next) {
      _curEpisode = _curEpisode - 1;
    }
  }

  _createScrollController() {
    double recordOffSet = 0;
    try {
      dynamic recordData =
          AppGlobal.novelWatchRecordBox?.get('$_novelId', defaultValue: '');
      if (recordData == null || recordData == '') {
        recordOffSet = 0;
      } else {
        if (recordData['episode'] == _curEpisode) {
          recordOffSet = recordData['offset'];
        }
      }
    } catch (e) {
      e.toString();
    }
    _controller = ScrollController(initialScrollOffset: recordOffSet);
    _scrollOffset = recordOffSet;
    _controller?.addListener(() {
      if (isShow) {
        if (isReset) {
          isReset = false;
          return;
        }
        setState(() {
          isShow = false;
        });
      }
      _scrollOffset = _controller!.offset;
    });
  }

  Timer _createWatchRecordTimer() {
    return Timer.periodic(const Duration(seconds: 2), (timer) {
      Map readRecordMap = {
        'id': _novelId,
        'title': _novelTitle ?? '',
        'episode': _curEpisode,
        'offset': _scrollOffset
      };
      LogUtil.i("readRecordMap-------->$readRecordMap");
      AppGlobal.novelWatchRecordBox!.put('$_novelId', readRecordMap);
    });
  }

  @override
  void dispose() {
    if (_controller != null) {
      _controller!.dispose();
    }
    if (_watchRecordTimer != null && _watchRecordTimer!.isActive) {
      _watchRecordTimer!.cancel();
    }
    HttpHelper.cancelNovelContent();
    super.dispose();
  }
}
