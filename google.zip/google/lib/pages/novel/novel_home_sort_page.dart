import 'package:flutter/material.dart';
import 'package:iaimei/base/app_base_widget_state.dart';
import 'package:iaimei/mixin/list_page_load_mixin.dart';
import 'package:iaimei/model/novel_index_model.dart';
import 'package:iaimei/model/novel_item_model.dart';
import 'package:iaimei/model/novel_list_model.dart';
import 'package:iaimei/net/http_request.dart';
import 'package:iaimei/pages/novel/novel_item_widget.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/res/img_res.dart';
import 'package:iaimei/style/app_text_style.dart';
import 'package:iaimei/utils/list_util.dart';
import 'package:iaimei/utils/page_jump_util.dart';
import 'package:iaimei/widget/app_img_widget.dart';
import 'package:iaimei/widget/list_widget.dart';
import 'package:iaimei/widget/refresh_load_list_widget.dart';
import 'package:iaimei/widget/space_widget.dart';
import 'package:iaimei/widget/text_widget.dart';

class NovelHomeSortPage extends StatefulWidget {
  final TabData tabData;

  const NovelHomeSortPage({
    Key? key,
    required this.tabData,
  }) : super(key: key);

  @override
  State<NovelHomeSortPage> createState() => _NovelHomeSortPageState();
}

class _NovelHomeSortPageState extends AppBaseWidgetState<NovelHomeSortPage>
    with ListPageLoadMixin {
  late List<NovelListModel> _novelList;

  @override
  buildPageBg() {
    return null;
  }

  @override
  void initState() {
    super.initState();
    onLoadData();
  }

  @override
  Widget buildPageLayout() {
    return handlePageStateView();
  }

  @override
  onLoadData() {
    onRefreshList();
  }

  @override
  void requestListData(bool isRefresh) {
    Map<String, dynamic> params = {};
    params['page'] = getCurPage;
    params['limit'] = getPageSize;
    HttpRequest().postRequest(
      widget.tabData.api!,
      widget.tabData.name!,
      (data) {
        _novelList = (data as List)
            .map((json) => NovelListModel.fromJson(json))
            .toList();
        setListPageState(isRefresh, ListUtil.isNotEmpty(_novelList), () {
          updatePageList(isRefresh, _novelList);
        });
      },
      (error) {},
      params: params,
    );
  }

  @override
  Widget successView() {
    return RefreshLoadListWidget(
      enableLoad: isEnableLoad(),
      enableRefresh: isEnableRefresh(),
      onRefresh: onRefreshList,
      onLoad: onLoadList,
      refreshController: refreshController,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [_buildNovelListSection(getResultList)],
      ),
    );
  }

  _buildNovelListSection(List dataList) {
    return ListWidget.buildVerticalListView(
        itemCount: dataList.length,
        itemBuilder: (context, index) {
          return _buildListItemSection(
              index, dataList[index] as NovelListModel);
        },
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics());
  }

  _buildListItemSection(int index, NovelListModel novelListModel) {
    return Column(
      children: [
        index == 0
            ? const SizedBox()
            : SpaceWidget(
                vSpace: DimenRes.dimen_10,
              ),
        Container(
          color: Colors.white.withOpacity(0.04),
          padding: EdgeInsets.only(
              left: DimenRes.dimen_15,
              top: DimenRes.dimen_15,
              right: DimenRes.dimen_15,
              bottom: DimenRes.dimen_15),
          child: InkWell(
            onTap: () {
              PageJumpUtil.forwardToNovelSeriesPage(context, novelListModel);
            },
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Expanded(
                  child: TextWidget.buildSingleLineText(
                      '${novelListModel.name}', AppTextStyle.white_s18),
                ),
                AppImgWidget(
                    path: ImgRes.IC_ARROW_RIGHT,
                    fit: BoxFit.contain,
                    height: DimenRes.dimen_18)
              ],
            ),
          ),
        ),
        Container(
            height: DimenRes.convert(175),
            width: DimenRes.screenWidth,
            color: Colors.white.withOpacity(0.04),
            padding: EdgeInsets.only(
                left: DimenRes.dimen_15, bottom: DimenRes.dimen_15),
            child: ListWidget.buildHorizontalListView(
                itemCount: novelListModel.list!.length,
                itemBuilder: (context, index) =>
                    _buildSortListItem(novelListModel.list![index])))
      ],
    );
  }

  _buildSortListItem(NovelItemModel item) {
    return Row(
      children: [
        InkWell(
          onTap: () {
            PageJumpUtil.forwardToNovelDetailPage(context, item);
          },
          child: _buildComicsItem(item),
        ),
        const SpaceWidget(
          hSpace: 12,
        )
      ],
    );
  }

  _buildComicsItem(NovelItemModel item) {
    return NovelItemWidget(
        itemData: item,
        imgWidth: DimenRes.dimen_100,
        imgHeight: DimenRes.dimen_135);
  }
}
