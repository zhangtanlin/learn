import 'package:flutter/material.dart';
import 'package:iaimei/base/app_base_widget_state.dart';
import 'package:iaimei/mixin/list_page_load_mixin.dart';
import 'package:iaimei/model/novel_item_model.dart';
import 'package:iaimei/model/novel_list_model.dart';
import 'package:iaimei/net/http_helper.dart';
import 'package:iaimei/pages/novel/novel_item_widget.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/utils/list_util.dart';
import 'package:iaimei/utils/page_jump_util.dart';
import 'package:iaimei/widget/app_page_title_bar.dart';
import 'package:iaimei/widget/list_widget.dart';
import 'package:iaimei/widget/refresh_load_list_widget.dart';

class NovelSeriesListPage extends StatefulWidget {
  final NovelListModel data;

  const NovelSeriesListPage({Key? key, required this.data}) : super(key: key);

  @override
  State<NovelSeriesListPage> createState() => _NovelSeriesListPageState();
}

class _NovelSeriesListPageState extends AppBaseWidgetState<NovelSeriesListPage>
    with ListPageLoadMixin {
  late List<NovelItemModel> _novelList;

  @override
  void initState() {
    super.initState();
    onLoadData();
  }

  @override
  buildAppBar() {
    return AppPageTitleBar.getNormalAppBar(title: widget.data.name);
  }

  @override
  Widget buildPageLayout() {
    return handlePageStateView();
  }

  @override
  onLoadData() {
    onRefreshList();
  }

  @override
  void requestListData(bool isRefresh) {
    HttpHelper.getNovelSeriesList('${widget.data.id}', getCurPage, getPageSize,
        (data) {
      _novelList =
          (data as List).map((json) => NovelItemModel.fromJson(json)).toList();
      setListPageState(isRefresh, ListUtil.isNotEmpty(_novelList), () {
        updatePageList(isRefresh, _novelList);
      });
    }, (error) {
      setListPageErrorState(isRefresh, error);
    });
  }

  @override
  int setPageSize() {
    return 12;
  }

  @override
  Widget successView() {
    return RefreshLoadListWidget(
        enableLoad: isEnableLoad(),
        enableRefresh: isEnableRefresh(),
        onRefresh: onRefreshList,
        onLoad: onLoadList,
        child: Padding(
          padding: EdgeInsets.only(
              left: DimenRes.dimen_15,
              right: DimenRes.dimen_15,
              top: DimenRes.dimen_5),
          child: _buildSeriesGridView(getResultList),
        ),
        refreshController: refreshController);
  }

  _buildSeriesGridView(List resultList) {
    return ListWidget.buildGridView(
        itemCount: resultList.length,
        itemBuilder: (context, index) =>
            _buildComicsSeriesItem(resultList[index] as NovelItemModel),
        childRatio: 0.618,
        mainSpace: DimenRes.dimen_15,
        crossSpace: DimenRes.dimen_15,
        crossCount: 3);
  }

  _buildComicsSeriesItem(NovelItemModel itemModel) {
    double width = (DimenRes.screenWidth - DimenRes.dimen_60) / 3;
    double height = width * 7 / 5;
    return InkWell(
      onTap: () {
        PageJumpUtil.forwardToNovelDetailPage(context, itemModel);
      },
      child: NovelItemWidget(
          itemData: itemModel, imgWidth: width, imgHeight: height),
    );
  }
}
