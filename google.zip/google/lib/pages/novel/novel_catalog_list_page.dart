import 'package:flutter/material.dart';
import 'package:iaimei/mixin/list_page_load_mixin.dart';
import 'package:iaimei/model/novel_catalog_item_model.dart';
import 'package:iaimei/net/http_helper.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/res/img_res.dart';
import 'package:iaimei/style/app_text_style.dart';
import 'package:iaimei/utils/list_util.dart';
import 'package:iaimei/widget/app_back_widget.dart';
import 'package:iaimei/widget/app_img_widget.dart';
import 'package:iaimei/widget/list_widget.dart';
import 'package:iaimei/widget/refresh_load_list_widget.dart';
import 'package:iaimei/widget/text_widget.dart';

typedef NovelCatalogItemCallback = void Function(NovelCatalogItemModel itemModel);

class NovelCatalogListPage extends StatefulWidget {
  final String id;
  final String? info;
  final NovelCatalogItemCallback? callback;

  const NovelCatalogListPage({
    Key? key,
    required this.id,
    this.info,
    this.callback,
  }) : super(key: key);

  @override
  State<NovelCatalogListPage> createState() => _NovelCatalogListPageState();
}

class _NovelCatalogListPageState extends State<NovelCatalogListPage>
    with ListPageLoadMixin {
  List<NovelCatalogItemModel> _catalogList = [];

  late String _listOrder;

  @override
  void initState() {
    super.initState();
    _listOrder = 'asc';
    onLoadData();
  }

  @override
  Widget build(BuildContext context) {
    return handlePageStateView();
  }

  @override
  onLoadData() {
    onRefreshList();
  }

  @override
  int setPageSize() {
    return 30;
  }

  @override
  void requestListData(bool isRefresh) {
    HttpHelper.getNovelCatalogList(
        widget.id, _listOrder, getCurPage, getPageSize, (data) {
      _catalogList = (data as List)
          .map((json) => NovelCatalogItemModel.fromJson(json))
          .toList();
      setListPageState(isRefresh, ListUtil.isNotEmpty(_catalogList), () {
        updatePageList(isRefresh, _catalogList);
      });
    }, (error) {
      setListPageErrorState(isRefresh, error);
    });
  }

  @override
  Widget successView() {
    return Column(
      children: [_buildTitleSection(context), _buildListSection()],
    );
  }

  _buildTitleSection(BuildContext context) {
    return Container(
      height: DimenRes.dimen_50,
      decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.12),
          borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(8), topRight: Radius.circular(8))),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Padding(
            padding: const EdgeInsets.all(10),
            child: AppBackWidget(
              onTap: () {
                Navigator.pop(context);
              },
            ),
          ),
          TextWidget.buildSingleLineText(
            widget.info ?? '',
            AppTextStyle.white_s14,
          ),
          Padding(
            padding: const EdgeInsets.all(10),
            child: AppImgWidget(
              width: DimenRes.dimen_30,
              path: ImgRes.IC_RESORT,
              onTap: () {
                _listOrder = _listOrder == 'asc' ? 'desc' : 'asc';
                onRefreshList();
              },
            ),
          )
        ],
      ),
    );
  }

  Expanded _buildListSection() {
    return Expanded(
        child: Container(
      padding: EdgeInsets.only(top: DimenRes.dimen_10),
      child: RefreshLoadListWidget(
        onRefresh: onRefreshList,
        onLoad: onLoadList,
        refreshController: refreshController,
        child: _buildCatalogListSection(getResultList),
      ),
    ));
  }

  _buildCatalogListSection(List resultList) {
    return ListWidget.buildVerticalListView(
        itemCount: resultList.length,
        itemBuilder: (BuildContext context, int index) {
          return InkWell(
            onTap: () {
              Navigator.pop(context);
              if (widget.callback != null) {
                widget.callback!(resultList[index] as NovelCatalogItemModel);
              }
            },
            child:
                _buildCatalogItem(resultList[index] as NovelCatalogItemModel),
          );
        });
  }

  Container _buildCatalogItem(NovelCatalogItemModel catalogItemModel) {
    return Container(
      padding: EdgeInsets.symmetric(
          horizontal: DimenRes.dimen_15, vertical: DimenRes.dimen_12),
      child: TextWidget.buildSingleLineText(
        "第${catalogItemModel.series}章 ${catalogItemModel.title}",
        AppTextStyle.white_s14,
      ),
    );
  }
}
