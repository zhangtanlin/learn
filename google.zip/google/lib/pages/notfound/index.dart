import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:iaimei/components/common/head.dart';
import 'package:iaimei/components/common/stackpage.dart';

class NotFound extends StatefulWidget {
  const NotFound({Key? key, required this.error}) : super(key: key);
  final dynamic error;
  @override
  State<NotFound> createState() => _NotFoundState();
}

class _NotFoundState extends State<NotFound> {
  @override
  Widget build(BuildContext context) {
    return StackPage(
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text(
              '页面没有找到，错误原因:',
              style: TextStyle(color: Colors.white),
            ),
            Text(
              widget.error.toString(),
              style: const TextStyle(color: Colors.white),
            ),
            SizedBox(height: ScreenUtil().setWidth(30)),
            GestureDetector(
              onTap: () => context.go('/'),
              child: Container(
                  width: ScreenUtil().setWidth(120),
                  height: ScreenUtil().setWidth(44),
                  padding: EdgeInsets.only(bottom: 6.w),
                  alignment: Alignment.center,
                  decoration: const BoxDecoration(
                    image: DecorationImage(
                      image: AssetImage("assets/images/button/btn_middle.png"),
                    ),
                  ),
                  child: const Text(
                    '返回首页',
                    style: TextStyle(color: Colors.white),
                  )),
            ),
          ],
        ),
      ),
    );
  }
}
