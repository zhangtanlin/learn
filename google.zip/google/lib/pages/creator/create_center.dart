import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:iaimei/components/common/commonelements.dart';
import 'package:iaimei/components/common/pageviewmixin.dart';
import 'package:iaimei/components/common/pullrefreshlist.dart';
import 'package:iaimei/components/common/stackpage.dart';
import 'package:iaimei/model/video_model.dart';
import 'package:iaimei/net/http_helper.dart';
import 'package:iaimei/pages/mv/nav_tab_bar_mixin.dart';
import 'package:iaimei/res/img_res.dart';
import 'package:iaimei/store/userdata.dart';
import 'package:iaimei/widget/convenient_mixin.dart';
import 'package:iaimei/widget/network_img_container.dart';
import 'package:iaimei/widget/state_mixin.dart';
import 'package:iaimei/widget/nested_scroll_view_ext.dart';
import 'package:provider/provider.dart';
import 'package:iaimei/model/user_info_model.dart';

class CreateCenter extends StatefulWidget {
  const CreateCenter({Key? key}) : super(key: key);

  @override
  State<CreateCenter> createState() => _CreateCenterState();
}

class _CreateCenterState extends State<CreateCenter>
    with TickerProviderStateMixin, ConvenientMixin {
  late TabController tabController;
  late UserInfoModel? user;
  int selectedIndex = 0;
  @override
  void initState() {
    super.initState();
    user = Provider.of<UserData>(context, listen: false).userInfo;
    tabController = TabController(length: 3, vsync: this);
    tabController.addListener(() {
      setState(() => selectedIndex = tabController.index);
    });
  }

  @override
  Widget build(BuildContext context) {
    return StackPage(
      header: const CustomHeader(title: '创作中心'),
      child: normalDataWidget(),
    );
  }

  Widget normalDataWidget() {
    return NestedScrollViewExt(
      headerSliverBuilder: (BuildContext c, bool f) {
        return <Widget>[
          SliverToBoxAdapter(
            child: Padding(
              padding: EdgeInsets.fromLTRB(16.w, 10.w, 16.w, 20.w),
              child: _buildHistoryDataWidget(),
            ),
          ),
        ];
      },
      onlyOneScrollInBody: true,
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          NavTabBarWidget(
            tabVc: tabController,
            tabs: const ['已通过', '待审核', '未通过'],
            textPadding: EdgeInsets.symmetric(horizontal: 16.w),
            norTextStyle: TextStyle(
                color: wColor, fontSize: 14.sp, fontWeight: FontWeight.w400),
            selTextStyle:
                TextStyle(color: rColor, fontSize: 18.sp, fontWeight: fontM),
            selectedIndex: selectedIndex,
          ),
          Container(
            color: const Color(0x33ffffff),
            margin: EdgeInsets.fromLTRB(16.w, 0, 16.w, 0),
            height: 0.5,
          ),
          Expanded(
            child: TabBarView(
              controller: tabController,
              children: <Widget>[
                PageViewMixin(child: const WorkReleaseWidget()),
                PageViewMixin(child: const WorkWaitWidget()),
                PageViewMixin(child: const WorkRejectWidget()),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHistoryDataWidget() {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            _buildOverContainer(),
            GestureDetector(
              onTap: () => context.push('/uploadWork'),
              child: Image.asset(
                'assets/images/upload/upload_pink.png',
                width: 104.w,
                height: 84.w,
              ),
            ),
          ],
        ),
        SizedBox(height: 15.w),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            _buildItemContainer('今日', user?.todayCoins),
            _buildItemContainer('粉丝团', user?.club?['count'] ?? 0),
            _buildItemContainer('历史累计', user?.coinsTotal),
          ],
        ),
      ],
    );
  }

  Widget _buildOverContainer() {
    return _buildOuterContainer(
      padding: EdgeInsets.only(left: 10.w, top: 10.w),
      width: 223.5.w,
      height: 84.w,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            '余额',
            style: TextStyle(color: color_72, fontSize: 12.sp),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                user?.coins ?? '0',
                style: TextStyle(
                    color: rColor, fontSize: 26.sp, fontWeight: fontM),
              ),
              GestureDetector(
                onTap: () => context.push('/withdraw'),
                child: SizedBox(
                  height: 56.w,
                  width: 48.w,
                  child: Center(
                    child: Text(
                      '提现',
                      style: TextStyle(
                          color: rColor, fontSize: 14.sp, fontWeight: fontM),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildItemContainer(title, number) {
    return _buildOuterContainer(
      padding: EdgeInsets.all(10.w),
      width: 104.w,
      height: 62.w,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '$title',
            style: TextStyle(
              color: const Color.fromRGBO(255, 255, 255, 0.72),
              fontSize: 12.sp,
            ),
          ),
          Text(
            '$number',
            style: TextStyle(
              fontWeight: FontWeight.w500,
              color: Colors.white,
              fontSize: 16.sp,
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildOuterContainer({
    required double width,
    required double height,
    required Widget child,
    required EdgeInsets padding,
  }) {
    return Container(
      height: height,
      width: width,
      padding: padding,
      decoration: BoxDecoration(
        color: const Color.fromRGBO(188, 136, 255, 0.12),
        borderRadius: BorderRadius.circular(12.w),
      ),
      child: child,
    );
  }
}

/* *************************************************************** */

class WorkReleaseWidget extends StatefulWidget {
  const WorkReleaseWidget({Key? key}) : super(key: key);

  @override
  State<WorkReleaseWidget> createState() => _WorkReleaseWidgetState();
}

class _WorkReleaseWidgetState extends State<WorkReleaseWidget>
    with ConvenientMixin, StateMixin, CreateCenterMixin {
  @override
  void initLoadingData() {
    super.initLoadingData();
    HttpHelper.worksRelease(param, (data) {
      var list = [];
      try {
        list = (data as List).map((item) {
          return VideoModel.fromJson(item);
        }).toList();
      } catch (e) {
        debugPrint(e.toString());
      }
      updateListAndWidgetState(list);
    }, dealWithErrorsWidgetState);
  }

  @override
  Widget build(BuildContext context) {
    if (widgetState != WidgetState.finish &&
        widgetState != WidgetState.noData) {
      return placeholderWidget();
    }
    return buildVideoPageWidget(onRefresh, onLoading, dataList, isAll);
  }
}

class WorkWaitWidget extends StatefulWidget {
  const WorkWaitWidget({Key? key}) : super(key: key);

  @override
  State<WorkWaitWidget> createState() => _WorkWaitWidgetState();
}

class _WorkWaitWidgetState extends State<WorkWaitWidget>
    with ConvenientMixin, StateMixin, CreateCenterMixin {
  @override
  void initLoadingData() {
    super.initLoadingData();
    var param = {'page': 1};
    HttpHelper.worksWait(param, (data) {
      var list = [];
      try {
        list = (data as List).map((item) {
          return VideoModel.fromJson(item);
        }).toList();
      } catch (e) {
        debugPrint(e.toString());
      }
      updateListAndWidgetState(list);
    }, dealWithErrorsWidgetState);
  }

  @override
  Widget build(BuildContext context) {
    if (widgetState != WidgetState.finish &&
        widgetState != WidgetState.noData) {
      return placeholderWidget();
    }
    return buildVideoPageWidget(onRefresh, onLoading, dataList, isAll);
  }
}

class WorkRejectWidget extends StatefulWidget {
  const WorkRejectWidget({Key? key}) : super(key: key);

  @override
  State<WorkRejectWidget> createState() => _WorkRejectWidgetState();
}

class _WorkRejectWidgetState extends State<WorkRejectWidget>
    with ConvenientMixin, StateMixin, CreateCenterMixin {
  @override
  void initLoadingData() {
    super.initLoadingData();
    HttpHelper.worksReject(param, (data) {
      var list = [];
      try {
        list = (data as List).map((item) {
          return VideoModel.fromJson(item);
        }).toList();
      } catch (e) {
        debugPrint(e.toString());
      }
      updateListAndWidgetState(list);
    }, dealWithErrorsWidgetState);
  }

  @override
  Widget build(BuildContext context) {
    if (widgetState != WidgetState.finish &&
        widgetState != WidgetState.noData) {
      return placeholderWidget();
    }
    return buildVideoPageWidget(onRefresh, onLoading, dataList, isAll);
  }
}

mixin CreateCenterMixin on ConvenientMixin {
  @override
  Widget noDataWidget() {
    return buildDataWidget(
      icon: 'assets/images/common/ic_load_error.png',
      content: '暂无数据',
      tipHidden: true,
    );
  }

  Widget buildVideoPageWidget(
      void Function() onRefresh, void Function() onLoading, List dataList,
      [bool isAll = true]) {
    return PullRefreshList(
      isAll: isAll,
      onRefresh: onRefresh,
      onLoading: onLoading,
      child: ListView.builder(
        itemCount: dataList.length,
        padding: EdgeInsets.symmetric(horizontal: 16.w),
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        itemBuilder: (BuildContext c, int i) {
          return Container(
            child: _buildVideoItemWidget(dataList[i]),
            decoration: const BoxDecoration(
              border: Border(bottom: BorderSide(color: Color(0x1fffffff))),
            ),
          );
        },
      ),
    );
  }

  Widget _buildVideoItemWidget(VideoModel item) {
    var total = item.coins * item.countPay;
    var path = ImgRes.IC_BADGE_FREE;
    switch (item.isFree) {
      case 1:
        path = ImgRes.IC_BADGE_VIP;
        break;
      case 2:
        path = ImgRes.IC_BADGE_COIN;
        break;
      default:
        path = ImgRes.IC_BADGE_FREE;
    }
    return Row(
      children: [
        Container(
          margin: EdgeInsets.symmetric(vertical: 15.w),
          width: 150.w,
          height: 94.w,
          child: Stack(children: [
            NetworkImgContainer(
              radius: BorderRadius.circular(6.w),
              fit: BoxFit.cover,
              url: item.coverThumbUrl,
            ),
            Positioned(
              right: 5.w,
              top: 5.w,
              child: Container(
                width: 36.w,
                height: 18.w,
                decoration: BoxDecoration(
                    image: DecorationImage(image: AssetImage(path))),
                child: Center(
                  child: Text(
                    '',
                    // item.isFree == 2 ? '${item.coins}钻' : '',
                    style: TextStyle(
                        color: color_84, fontSize: 12.sp, fontWeight: fontM),
                  ),
                ),
              ),
            ),
          ]),
        ),
        SizedBox(width: 10.w),
        Expanded(
          child: SizedBox(
            height: 94.w,
            child: Column(
              // mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  item.title,
                  style: TextStyle(color: wColor, fontSize: 13.sp),
                  maxLines: 2,
                ),
                SizedBox(height: 2.w),
                Flexible(
                  fit: FlexFit.tight,
                  child: Text(
                    item.createdStr,
                    style: TextStyle(color: color_64, fontSize: 12.sp),
                  ),
                ),
                Text.rich(
                  TextSpan(children: [
                    TextSpan(text: '收益: ', style: TextStyle(color: color_64)),
                    TextSpan(text: '$total 钻', style: TextStyle(color: wColor)),
                  ]),
                  maxLines: 1,
                  style: TextStyle(fontSize: 12.sp),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
