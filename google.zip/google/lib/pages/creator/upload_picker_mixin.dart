import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:bot_toast/bot_toast.dart';
import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:iaimei/utils/http.dart';
import 'package:iaimei/widget/convenient_mixin.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:universal_html/html.dart' as html;
import 'package:image_picker/image_picker.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:http_parser/http_parser.dart';

import 'package:image/image.dart' as dimage;
import 'package:video_thumbnail/video_thumbnail.dart';

typedef OnUploadObject = void Function(
    bool isVideo, String remotePath, Size? size, dynamic localPath);
enum InputFileType {
  image,
  video,
  both,
}

mixin UploadPickerMixin<T extends StatefulWidget> on ConvenientMixin, State<T> {
  /* **************************  数据存储及使用方法  ************************** */

  int uploadIndex = 0; // 上传的索引，默认为0
  OnUploadObject? uploadCallback;
  void Function()? singleObjectCallback; // 单张图片或单个视频上传成功回调
  Size actionSize = const Size(25, 25);
  String uploadFileName = 'FileInput';
  Size? vCoverSize;

  Map<int, dynamic> videoPathMap = {}; // {0:'/.../2021122115340678287.xxx'}
  Map<int, dynamic> imagePathMap = {}; // {3:'/.../2021122115340678287.png'}
  // index of videoPaths & imagePaths key
  Map<int, Uint8List?> localImageMap = {}; // 本地图片数据列表

  Widget imageMemoryWidget(Uint8List? byte) {
    return byte != null ? Image.memory(byte, fit: BoxFit.contain) : Container();
  }

  void commonInitUploadCallback() {
    uploadCallback = (isVideo, remotePath, imageSize, object) {
      switch (isVideo) {
        case true:
          videoPathMap[uploadIndex] = remotePath;
          // loadingVideoCover(kIsWeb ? object[1] : object);
          loadingVideoCover(object);
          break;
        default:
          // 单张图片处理
          if (singleObjectCallback != null) {
            imagePathMap = {}; // 重置
          }

          // {'1': {url: /.../...png, width: 200, height: 100}}
          imagePathMap[uploadIndex] = {
            'url': remotePath, // url_path
            'width': imageSize?.width,
            'height': imageSize?.height,
          };

          // web 0 index 1 Uint8List
          // localImageMap[uploadIndex] = kIsWeb ? object[1] : object;
          localImageMap[uploadIndex] = object;
          singleObjectCallback?.call(); //单个文件处理
          setState(() {});
      }
    };
  }

  // 视频封面 处理
  void loadingVideoCover(path) async {
    // web 上传视频
    if (path is Uint8List) {
      try {
        localImageMap[uploadIndex] = path;
      } catch (error) {
        debugPrint(error.toString());
      }
      setState(() {});
      return;
    }

    // 原生 视频封面
    var coverPath = await VideoThumbnail.thumbnailData(
      video: path,
      imageFormat: ImageFormat.PNG,
      maxWidth: (vCoverSize?.width ?? actionSize.width).toInt(),
      maxHeight: (vCoverSize?.height ?? actionSize.height).toInt(),
      quality: 100,
    );

    try {
      localImageMap[uploadIndex] = coverPath;
    } catch (error) {
      debugPrint(error.toString());
    }
    setState(() {});
  }

  // 原生上传 操作
  void onUploadAction(bool isVideo) {
    BotToast.showText(text: '需要重写此方法');
  }

  // 展示上传 图片
  Widget uploadActionWidget(double width, double height, bool isVideo,
      {String? path, List<Widget> images = const []}) {
    path ??= isVideo
        ? 'assets/images/upload/upload_up_svideo.png'
        : 'assets/images/upload/upload_up_simage.png';

    return buildContainerWidget(
      width: actionSize.width,
      height: actionSize.height,
      child: GestureDetector(
        onTap: () => onUploadAction(isVideo),
        child: Stack(
          alignment: AlignmentDirectional.center,
          children: [
            Image.asset(path, width: width, height: height, fit: BoxFit.cover),
            // imageMemoryWidget(imageCover),
            ...images,
          ],
        ),
      ),
    );
  }

  /* **************************  ------结束------  ************************** */

  final ImagePicker _picker = ImagePicker();

  imageBase64(file, Function done) {
    html.FileReader reader = html.FileReader();
    reader.readAsDataUrl(file);
    reader.onLoadEnd.listen((_event) {
      done(reader.result);
    });
  }

  Widget operateOptionWidget(String title, void Function()? callbackAction) {
    return TextButton(
      onPressed: () {
        callbackAction?.call();
        Navigator.pop(context);
      },
      child: SizedBox(
        height: 49.w,
        child: Center(
          child: Text(
            title,
            style: TextStyle(color: wColor, fontSize: 15.sp, fontWeight: fontM),
          ),
        ),
      ),
    );
  }

  Future<List> imageFileSize(XFile file) async {
    var imageBytes = await file.readAsBytes();
    var destImage = dimage.decodeImage(imageBytes);
    return [
      imageBytes,
      Size(
        destImage?.width.toDouble() ?? 0,
        destImage?.height.toDouble() ?? 0,
      )
    ];
  }

  /* ********************************************************************** */

  void showImageAssets([OnUploadObject? callback]) {
    uploadCallback ??= callback;
    if (kIsWeb) {
      webSelectUploadMethod('image');
    } else {
      if (Platform.isIOS) selectImage(ImageSource.gallery);
      if (Platform.isAndroid) androidSelectUploadMethod('image');
    }
  }

  void showVideoAssets([OnUploadObject? callback]) {
    uploadCallback ??= callback;
    if (kIsWeb) {
      webSelectUploadMethod('video');
    } else {
      if (Platform.isIOS) selectVideo(ImageSource.gallery);
      if (Platform.isAndroid) androidSelectUploadMethod('video');
    }
  }

  void webSelectUploadMethod(String type) async {
    try {
      XFile? imageFile;
      switch (type) {
        case 'video':
          imageFile = await _picker.pickVideo(source: ImageSource.gallery);
          break;
        case 'image':
          imageFile = await _picker.pickImage(source: ImageSource.gallery);
          break;
        default:
      }
      //
      if (imageFile == null) return;
      dynamic multiFile = MultipartFile.fromBytes(
        await imageFile.readAsBytes(),
        filename: imageFile.name,
        contentType: MediaType.parse( // pwa error
            type == 'video' ? 'video/mp4' : (imageFile.mimeType ?? '')),
      );
      if (imageFile.mimeType?.contains('image') ?? false) {
        List imageList = await imageFileSize(imageFile);
        uploadImage(imageList[1], multiFile, imageList[0]);
      }
      //
      else if (imageFile.mimeType?.contains('video') ?? false) {
        var data =
            await rootBundle.load('assets/images/upload/upload_mv_success.png');
        String type = imageFile.name.split(".").last.toLowerCase();
        if (type == 'mp4' || imageFile.mimeType == 'video/quicktime') {
          uploadVideo(multiFile, xfile: data.buffer.asUint8List());
        } else {
          BotToast.showText(text: '上传视频格式必须为 mp4');
        }
      }
      // 收集日志 记录错误
      else {
        debugPrint('web select image error ...');
      }
    } catch (e) {
      BotToast.showText(text: '您拒绝授予权限，请前往设置中打开权限');
      debugPrint('select image ---> ' + e.toString());
    }
  }

  // android
  void androidSelectUploadMethod(String type) async {
    var status = await Permission.camera.status;
    if (status == PermissionStatus.denied) {
      status = await Permission.camera.request();
      if (status == PermissionStatus.denied ||
          status == PermissionStatus.permanentlyDenied) {
        BotToast.showText(text: '您拒绝授予权限，请前往设置中打开权限');
      } else {
        type == 'video'
            ? selectVideo(ImageSource.gallery)
            : selectImage(ImageSource.gallery);
      }
    } else if (status == PermissionStatus.permanentlyDenied) {
      BotToast.showText(text: '您拒绝授予权限，请前往设置中打开权限');
    } else {
      type == 'video'
          ? selectVideo(ImageSource.gallery)
          : selectImage(ImageSource.gallery);
    }
  }

  @Deprecated('Use selectVideo or selectImage')
  void iOSSelectUploadMethod(String type) {
    showModalBottomSheet(
      isScrollControlled: true,
      context: context,
      backgroundColor: Colors.transparent,
      builder: (BuildContext context) {
        return StatefulBuilder(
          builder: (context1, state) {
            return Container(
              padding: EdgeInsets.only(
                bottom: MediaQuery.of(context).padding.bottom,
              ),
              decoration: const BoxDecoration(
                color: Color.fromRGBO(26, 21, 47, 1),
                borderRadius: BorderRadius.vertical(top: Radius.circular(15)),
              ),
              child: Column(mainAxisSize: MainAxisSize.min, children: <Widget>[
                operateOptionWidget(
                  '拍照',
                  () => type == 'video'
                      ? selectVideo(ImageSource.camera)
                      : selectImage(ImageSource.camera),
                ),
                Container(
                    margin: EdgeInsets.only(left: 15.w, right: 15.w),
                    height: 1.w,
                    color: Colors.white12),
                operateOptionWidget(
                  '从相册选择',
                  () => type == 'video'
                      ? selectVideo(ImageSource.gallery)
                      : selectImage(ImageSource.gallery),
                ),
              ]),
            );
          },
        );
      },
    );
  }

  Future<void> selectImage(ImageSource source) async {
    try {
      XFile? imageFile =
          await _picker.pickImage(source: source, imageQuality: 30);
      if (imageFile == null) return;

      // 0-Uint8List 1-Size
      List imageList = await imageFileSize(imageFile);
      var formatList = ["heic", "heif", "HEIC", "HEIF"];
      List imgArr = imageFile.name.split('.');
      String type = imgArr.last;
      if (formatList.contains(type)) {
        for (var j = 0; j < formatList.length; j++) {
          if (imageFile.path.endsWith(formatList[j])) {
            // String jpegPath;
            // jpegPath = await HeicToJpg.convert(photo.path);
            // upImage(jpegPath);
          }
        }
      } else {
        uploadImage(imageList[1], imageFile.path, imageList[0]);
      }
    } catch (e) {
      BotToast.showText(text: '您拒绝授予权限，请前往设置中打开权限');
      debugPrint('select image ---> ' + e.toString());
    }
  }

  Future<void> uploadImage(Size size, dynamic filePath, dynamic xfile) async {
    /// 动画
    onLoadingAnimation();

    /// 网络
    var result = await PlatformAwareHttp.uploadImage(imageUrl: filePath);
    BotToast.closeAllLoading();
    if (result == null) {
      debugPrint('上传图片返回错误...');
      BotToast.showText(text: '上传图片返回数据错误');
      return;
    }

    try {
      var json = jsonDecode(result.data);
      if (json['code'] == 1) {
        var imagePath = json['msg'];
        uploadCallback?.call(false, imagePath, size, xfile);
        debugPrint('upload image ----> ' + imagePath);
      } else {
        BotToast.showText(text: json['msg']);
      }
    } catch (e) {
      debugPrint('upload image ---> ' + e.toString());
      BotToast.showText(text: '上传图片返回格式错误');
    }
  }

  Future<void> selectVideo(ImageSource source) async {
    try {
      XFile? videoFile = await _picker.pickVideo(source: source);
      if (videoFile == null) return;
      String type = videoFile.name.split(".").last.toLowerCase();
      debugPrint('$type................. ${videoFile.mimeType}');
      if (Platform.isIOS ||
          type == 'mp4' ||
          videoFile.mimeType == 'video/quicktime') {
        uploadVideo(videoFile.path);
      } else {
        BotToast.showText(text: '上传视频格式必须为 mp4');
      }
    } catch (e) {
      BotToast.showText(text: '您拒绝授予权限，请前往设置中打开权限');
      debugPrint('select video ---> ' + e.toString());
    }
  }

  Future<void> uploadVideo(dynamic filePath, {dynamic xfile}) async {
    onLoadingAnimation();

    /// 网络
    var result = await PlatformAwareHttp.uploadVideo(videoUrl: filePath);
    BotToast.closeAllLoading();
    if (result == null) {
      debugPrint('上传视频返回数据错误...');
      BotToast.showText(text: '上传视频返回数据错误');
      return;
    }

    try {
      var json = jsonDecode(result.data);
      if (json['code'] == 1) {
        BotToast.closeAllLoading();
        var imagePath = json['msg'];
        debugPrint('upload video ----> ' + imagePath);
        uploadCallback?.call(true, imagePath, null, kIsWeb ? xfile : filePath);
      } else {
        BotToast.showText(text: json['msg']);
      }
    } catch (e) {
      debugPrint('upload video ---> ' + e.toString());
      BotToast.showText(text: '上传视频返回格式错误');
    }
  }

  void onLoadingAnimation() {
    /// 动画
    BotToast.showLoading(wrapToastAnimation: (animation, fc, child) {
      // BotToast.showCustomLoading(toastBuilder: (_) {
      return Container(
        padding: const EdgeInsets.all(15),
        decoration: const BoxDecoration(
          color: Colors.black54,
          borderRadius: BorderRadius.all(Radius.circular(8)),
        ),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const CircularProgressIndicator(
            backgroundColor: Colors.white,
          ),
          SizedBox(height: 12.5.w),
          Text(
            '上传中...',
            style: TextStyle(
              color: Colors.white,
              fontSize: 15.sp,
              fontWeight: FontWeight.w500,
            ),
          ),
        ]),
      );
    });
  }
}
