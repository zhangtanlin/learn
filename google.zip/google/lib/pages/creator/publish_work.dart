import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:iaimei/components/common/commonelements.dart';
import 'package:iaimei/components/common/stackpage.dart';
import 'package:iaimei/net/http_helper.dart';
import 'package:iaimei/pages/creator/upload_picker_mixin.dart';
import 'package:iaimei/utils/common.dart';
import 'package:iaimei/widget/buttom_widget.dart';
import 'package:iaimei/widget/convenient_mixin.dart';

class PublishWork extends StatefulWidget {
  const PublishWork({Key? key}) : super(key: key);

  @override
  State<PublishWork> createState() => _PublishWorkState();
}

class _PublishWorkState extends State<PublishWork>
    with ConvenientMixin, UploadPickerMixin {
  bool isExclusive = false;
  final titleVc = TextEditingController();
  final priceVc = TextEditingController();

  Uint8List? imageCover;
  Uint8List? videoCover;

  @override
  void initState() {
    super.initState();
    priceVc.text = '0';
    onLoadingAction();

    actionSize = Size(164.w, 164.w);
    commonInitUploadCallback();
  }

  @override
  void onUploadAction(bool isVideo) {
    onDismissfocus(); // 失去焦点
    uploadIndex = isVideo ? 1 : 0; // 固定放视频或图片封面
    isVideo ? showVideoAssets() : showImageAssets();
  }

  var tags = [];
  var scxz = '';
  var selectedTags = <String>[];
  void onLoadingAction() {
    HttpHelper.uploadTags((data) {
      try {
        tags = data['list'] ?? [];
        scxz = data['scxz'] ?? '';
        setState(() {});
      } catch (error) {
        debugPrint(error.toString());
      }
    }, (error) {
      debugPrint(error.toString());
    });
  }

  // 失去焦点
  void onDismissfocus() {
    FocusScope.of(context).requestFocus(FocusNode());
  }

  void onSubmitClick() {
    onDismissfocus(); // 失去焦点
    if (imagePathMap.values.isEmpty) {
      Method.showText('请上传封面');
      return;
    }
    if (videoPathMap.values.isEmpty) {
      Method.showText('请上传视频');
      return;
    }
    if (titleVc.text.isEmpty) {
      Method.showText('请输入标题');
      return;
    }
    if (selectedTags.isEmpty) {
      Method.showText('请选择标签');
      return;
    }

    var param = {
      'img_url': imagePathMap.values.first['url'],
      'thumb_width': imagePathMap.values.first['width'],
      'thumb_height': imagePathMap.values.first['height'],
      'url': videoPathMap.values.first,
      'title': titleVc.text,
      'tags': selectedTags.join(','),
      'coins': priceVc.text,
      'is_club': isExclusive ? 1 : 0,
    };
    HttpHelper.uploadWork(param, (data) {
      try {
        imagePathMap = {};
        videoPathMap = {};
        localImageMap = {};
        selectedTags = [];
        titleVc.text = '';
        priceVc.text = '0';
        isExclusive = false;
        Method.showText(data['msg']);
      } catch (error) {
        debugPrint(error.toString());
      }
      setState(() {});
    }, (error) {
      Method.showText(error.toString());
    });
  }

  @override
  Widget build(BuildContext context) {
    return StackPage(
      header: const CustomHeader(title: '上传作品'),
      child: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.fromLTRB(16.w, 10.w, 16.w, 20.w),
          child: GestureDetector(
            behavior: HitTestBehavior.translucent,
            onTap: onDismissfocus,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildResourceWidget(),
                SizedBox(height: 15.w),
                _buildRowItemWidget(
                  '标题：',
                  [_buildTitleWidget()],
                ),
                SizedBox(height: 15.w),
                _buildRowItemWidget(
                  '标签：',
                  [_buildLabelWidget()],
                  padding: EdgeInsets.only(left: 10.w),
                ),
                SizedBox(height: 15.w),
                _buildRowItemWidget(
                  '价格：',
                  [_buildPriceWidget()],
                ),
                SizedBox(height: 15.w),
                _buildRowItemWidget(
                  '粉丝团专属',
                  [_buildFactorWidget()],
                  padding: EdgeInsets.only(left: 10.w),
                ),
                SizedBox(height: 20.w),
                ..._buildUploadWidget(),
                SizedBox(height: 50.w),
                Center(
                  child: ButtonWidget.build('确定', onTap: onSubmitClick),
                ),
                Center(child: _buildOnlineService()),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildResourceWidget() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        uploadActionWidget(144.w, 144.w, false,
            path: 'assets/images/upload/upload_up_image.png',
            images: [imageMemoryWidget(localImageMap[0])]),
        Column(
          children: [
            uploadActionWidget(144.w, 144.w, true,
                path: 'assets/images/upload/upload_up_video.png',
                images: [imageMemoryWidget(localImageMap[1])]),
            SizedBox(height: 10.w),
            Text(
              '最大支持100M',
              style: TextStyle(color: color_64, fontSize: 12.sp),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildTitleWidget() {
    return Expanded(
      child: TextField(
        textAlign: TextAlign.end,
        controller: titleVc,
        maxLines: 1,
        cursorHeight: 15.w,
        style: TextStyle(color: color_84, fontSize: 13.sp),
        decoration: InputDecoration(
          hintText: '最多支持22个汉字',
          hintStyle: TextStyle(color: color_64, fontSize: 13.sp),
          border: InputBorder.none,
          contentPadding: EdgeInsets.only(left: 10.w),
        ),
      ),
    );
  }

  Widget _buildLabelWidget() {
    return GestureDetector(
      onTap: () {
        onDismissfocus(); // 失去焦点
        showSelectedLabelSheet();
      },
      child: Row(children: [
        Text.rich(
          TextSpan(
            children: selectedTags.map((item) {
              return WidgetSpan(
                child: Padding(
                  padding: EdgeInsets.only(left: 10.w),
                  child: Text(
                    item,
                    style: TextStyle(color: color_84, fontSize: 13.sp),
                  ),
                ),
              );
            }).toList(),
          ),
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
        Image.asset(
          'assets/images/upload/upload_push.png',
          width: 32.w,
          height: 44.w,
          scale: 2,
        ),
      ]),
    );
  }

  Widget _buildPriceWidget() {
    return Container(
      height: 28.w,
      width: 65.w,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14.w),
        color: Colors.black.withOpacity(0.24),
      ),
      padding: EdgeInsets.only(left: 6.w, right: 8.w),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              textAlign: TextAlign.center,
              controller: priceVc,
              maxLines: 1,
              cursorHeight: 15.w,
              keyboardType: TextInputType.number,
              style:
                  TextStyle(color: rColor, fontSize: 13.sp, fontWeight: fontM),
              decoration: null,
            ),
          ),
          Text(
            '元',
            style: TextStyle(color: rColor, fontSize: 13.sp, fontWeight: fontM),
          ),
        ],
      ),
    );
  }

  Widget _buildFactorWidget() {
    var path =
        'assets/images/upload/upload_fan_${isExclusive ? 'sel' : 'nor'}.png';
    return GestureDetector(
      behavior: HitTestBehavior.translucent,
      onTap: () {
        onDismissfocus(); // 失去焦点
        isExclusive = !isExclusive;
        setState(() {});
      },
      child: Container(
        width: 18.w,
        height: 18.w,
        margin: EdgeInsets.all(10.w),
        child: Image.asset(path, fit: BoxFit.cover),
      ),
    );
  }

  Widget _buildRowItemWidget(title, List<Widget> list, {EdgeInsets? padding}) {
    padding ??= EdgeInsets.symmetric(horizontal: 10.w);
    return buildContainerWidget(
      padding: padding,
      width: 343.w,
      height: 44.w,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text('$title', style: TextStyle(color: wColor, fontSize: 15.sp)),
          ...list,
        ],
      ),
    );
  }

  void showSelectedLabelSheet() {
    showModalBottomSheet(
      isScrollControlled: true,
      context: context,
      isDismissible: true,
      backgroundColor: Colors.transparent,
      builder: (builder) {
        return StatefulBuilder(builder: (cnt, setSheetState) {
          return Container(
            height: tags.length > 40
                ? 514.w
                : (54 + 46 * ((tags.length + 3) / 4).floor()).w,
            // padding: EdgeInsets.only(
            //   bottom: MediaQuery.of(context).padding.bottom,
            // ),
            decoration: const BoxDecoration(
              color: Color.fromRGBO(26, 21, 47, 1),
              borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
            ),
            clipBehavior: Clip.hardEdge,
            child: Column(mainAxisSize: MainAxisSize.min, children: <Widget>[
              Container(
                padding: EdgeInsets.only(top: 14.w),
                height: 54.w,
                color: const Color(0x15ffffff),
                child: CustomHeader(lMargin: 16.w, title: '标签'),
              ),
              Expanded(
                child: SingleChildScrollView(
                  child: GridView.builder(
                    padding: EdgeInsets.fromLTRB(16.w, 10.w, 16.w, 20.w),
                    itemCount: tags.length,
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 4,
                      childAspectRatio: 79 / 36,
                      mainAxisSpacing: 9.w,
                      mainAxisExtent: 36.w,
                      crossAxisSpacing: 9.w,
                    ),
                    itemBuilder: (ctx, index) {
                      var isSelected =
                          selectedTags.contains(tags[index]['value']);
                      var path =
                          'assets/images/upload/upload_tag_${isSelected ? 'sel' : 'nor'}.png';
                      return GestureDetector(
                        onTap: () {
                          if (selectedTags.contains(tags[index]['value'])) {
                            selectedTags.remove(tags[index]['value']);
                          } else {
                            selectedTags.add(tags[index]['value']);
                          }
                          setSheetState(() {});
                          setState(() {});
                        },
                        child: Container(
                          height: 36.w,
                          width: 79.w,
                          decoration: BoxDecoration(
                              image: DecorationImage(image: AssetImage(path))),
                          child: Center(
                            child: Text(
                              tags[index]['label'],
                              style: TextStyle(
                                color: wColor,
                                fontSize: 13.sp,
                                fontWeight: fontM,
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ),
            ]),
          );
        });
      },
    );
  }

  List<Widget> _buildUploadWidget() {
    return [
      Offstage(
        offstage: scxz.isEmpty,
        child: Text(
          '上传须知：',
          style: TextStyle(color: wColor, fontSize: 16.sp, fontWeight: fontM),
        ),
      ),
      ...scxz
          .split('##')
          .map(((item) => Padding(
              padding: EdgeInsets.only(top: 10.w),
              child: Text(
                item.trim(),
                style: TextStyle(color: color_64, fontSize: 12.sp),
              ))))
          .toList()
    ];
  }

  Widget _buildOnlineService() {
    return GestureDetector(
      onTap: () {
        onDismissfocus(); // 失去焦点
        context.push('/onlineService');
      },
      child: SizedBox(
        height: 50.w,
        width: 126.w,
        child: Center(
          child: Text(
            '联系客服',
            style: TextStyle(color: color_64, fontSize: 16.sp),
          ),
        ),
      ),
    );
  }
}
