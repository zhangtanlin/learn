import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:iaimei/base/app_base_widget_state.dart';
import 'package:iaimei/res/color_res.dart';
import 'package:iaimei/widget/app_page_title_bar.dart';
import 'package:iaimei/widget/banner_widget.dart';
import 'package:webview_flutter/webview_flutter.dart';

class WebViewPage extends StatefulWidget {
  final Map? args;

  const WebViewPage({
    this.args,
    Key? key,
  }) : super(key: key);

  @override
  _WebViewPageState createState() => _WebViewPageState();
}

class _WebViewPageState extends AppBaseWidgetState<WebViewPage> {
  bool isLoaded = false;
  double progressValue = 0.0;

  @override
  void initState() {
    super.initState();
    if (!kIsWeb) {
      if (Platform.isAndroid) WebView.platform = AndroidWebView();
    }
  }

  @override
  buildAppBar() {
    return AppPageTitleBar.getNormalAppBar(
        title: widget.args!['title'], titleAlignment: Alignment.center);
  }

  @override
  Widget buildPageLayout() {
    return Column(
      children: [
        !isLoaded
            ? LinearProgressIndicator(
                color: ColorRes.color_ff00b3,
                backgroundColor: Colors.white12,
                minHeight: 3,
                value: progressValue,
              )
            : const SizedBox(
                width: 0,
                height: 0,
              ),
        Expanded(
            child: WebView(
          initialUrl: widget.args!['url'],
          javascriptMode: JavascriptMode.unrestricted,
          backgroundColor: Colors.transparent,
          onProgress: (progress) {
            setState(() {
              progressValue = progress / 100;
            });
          },
          javascriptChannels: {_jsChannel(context)},
          // contactOfficial
          navigationDelegate: _jsRouter,
          onPageFinished: (url) {
            setState(() {
              isLoaded = true;
            });
          },
        ))
      ],
    );
  }

  JavascriptChannel _jsChannel(BuildContext context) {
    return JavascriptChannel(
      name: 'Toast',
      onMessageReceived: (JavascriptMessage message) {
        // showToast(message.message);
      },
    );
  }

  NavigationDecision _jsRouter(NavigationRequest request) {
    debugPrint(request.url);
    // 联系官方
    if (request.url.startsWith('am://official')) {
      BannerWidget.commonPushAction(context, 'official');
      return NavigationDecision.prevent;
    }
    // 联系客服
    if (request.url.startsWith('am://services')) {
      BannerWidget.commonPushAction(context, 'services');
      return NavigationDecision.prevent;
    }
    // 余额充值
    if (request.url.startsWith('am://balance')) {
      BannerWidget.commonPushAction(context, ' balance');
      return NavigationDecision.prevent;
    }
    // 购买VIP
    if (request.url.startsWith('am://members')) {
      BannerWidget.commonPushAction(context, 'members');
      return NavigationDecision.prevent;
    }
    return NavigationDecision.navigate;
  }
}
