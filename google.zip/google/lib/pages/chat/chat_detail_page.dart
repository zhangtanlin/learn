import 'package:card_swiper/card_swiper.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:iaimei/base/app_base_widget_state.dart';
import 'package:iaimei/global.dart';
import 'package:iaimei/mixin/page_load_mixin.dart';
import 'package:iaimei/model/chat_detail_model.dart';
import 'package:iaimei/model/chat_reward_list.dart';
import 'package:iaimei/model/like_result_model.dart';
import 'package:iaimei/model/reward_set.dart';
import 'package:iaimei/net/http_helper.dart';
import 'package:iaimei/pages/chat/buy_chat_time_section.dart';
import 'package:iaimei/pages/chat/chat_reward_list_section.dart';
import 'package:iaimei/pages/chat/input_comment_mixin.dart';
import 'package:iaimei/res/color_res.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/res/img_res.dart';
import 'package:iaimei/res/string_res.dart';
import 'package:iaimei/style/app_text_style.dart';
import 'package:iaimei/utils/dialog_util.dart';
import 'package:iaimei/utils/list_util.dart';
import 'package:iaimei/utils/loading_util.dart';
import 'package:iaimei/utils/page_jump_util.dart';
import 'package:iaimei/utils/string_util.dart';
import 'package:iaimei/widget/app_img_widget.dart';
import 'package:iaimei/widget/app_page_title_bar.dart';
import 'package:iaimei/widget/app_text_with_img_bg_widget.dart';
import 'package:iaimei/widget/audio_player_widget.dart';
import 'package:iaimei/widget/convenient_mixin.dart';
import 'package:iaimei/widget/frosted_glass_box.dart';
import 'package:iaimei/widget/network_img_container.dart';
import 'package:iaimei/widget/space_widget.dart';
import 'package:iaimei/widget/text_widget.dart';
import 'package:iaimei/widget/toast_widget.dart';

class ChatDetailPage extends StatefulWidget {
  const ChatDetailPage({Key? key, this.param = const {}}) : super(key: key);
  final Map<String, dynamic> param;

  @override
  State<ChatDetailPage> createState() => _ChatDetailPageState();
}

class _ChatDetailPageState extends AppBaseWidgetState<ChatDetailPage>
    with ConvenientMixin, InputCommentMixin, PageLoadMixin {
  late ChatDetailModel _chatDetail;
  bool isLike = false;
  String uid = '';
  bool _isFront = true;

  @override
  void initState() {
    super.initState();
    uid = '${widget.param['uid'] ?? ''}';
    infoId = '${widget.param['info_id'] ?? ''}';
    onLoadData();
  }

  @override
  onLoadData() {
    HttpHelper.getChatDetail(infoId, uid, (data) {
      _chatDetail = ChatDetailModel.fromJson(data);
      isLike = _chatDetail.isLike == 1;
      setPageState(_chatDetail != null);
      AppGlobal.storeHistory(BrowseKey.nudeChat, data);
    }, (error) {
      setPageErrorState(error);
    });
  }

  @override
  Widget buildPageLayout() {
    return handlePageStateView();
  }

  @override
  Widget successView() {
    return Stack(
      children: [
        _buildStackPageWidget(),
        AppPageTitleBar.getNormalAppBar(
            title: StringRes.str_nude_chat,
            rightWidget: AppImgWidget(
                onTap: () {
                  onStopAudio();
                  PageJumpUtil.forwardToChatRankPage(context);
                },
                path: ImgRes.IC_RANK,
                width: DimenRes.dimen_35,
                height: DimenRes.dimen_35))
      ],
    );
  }

  @override
  bool isShowSafeArea() {
    return false;
  }

  void onStopAudio() {
    setState(() {
      _isFront = false;
    });
  }

  void likeAction() {
    HttpHelper.likeChatAction(_chatDetail.id ?? 0, (data) {
      LikeResultModel model = LikeResultModel.fromJson(data);
      setState(() {
        isLike = model.isLike == 1;
      });
    }, (error) {
      ToastWidget.showToast(error.message ?? StringRes.str_operate_fail);
    });
  }

  //打赏
  void onRewardAction() {
    LoadingUtil.showLoading();
    HttpHelper.rewardGiftList((data) {
      LoadingUtil.closeLoading();
      try {
        ChatRewardList chatRewardList = ChatRewardList.fromJson(data);
        List<RewardSet> rewardList = chatRewardList.gifts ?? [];
        if (chatRewardList != null && ListUtil.isNotEmpty(rewardList)) {
          DialogUtil.showPurpleFrostedGlassDialog(
              cxt: context,
              dismissible: true,
              insetPadding: DimenRes.dimen_30,
              child: ChatRewardListSection(
                rewardData: chatRewardList,
                uid: _chatDetail.uid,
              ));
        } else {
          ToastWidget.showToast(StringRes.str_no_reward_product);
        }
      } catch (e) {
        ToastWidget.showToast(StringRes.str_no_reward_product);
      }
    }, (error) {
      LoadingUtil.closeLoading();
      ToastWidget.showToast(error.message ?? StringRes.str_no_reward_product);
    });
  }

  void onNudeChatAction() {
    if (ListUtil.isEmpty(_chatDetail.chatset)) {
      ToastWidget.showToast('暂无裸聊相关产品');
      return;
    }

    DialogUtil.showPurpleFrostedGlassDialog(
        cxt: context,
        insetPadding: DimenRes.dimen_30,
        child: BuyChatTimeSection(
          chatList: _chatDetail.chatset ?? [],
          id: _chatDetail.id ?? 0,
          callback: onLoadData,
        ));
  }

  Widget _buildStackPageWidget() {
    return Stack(
      children: [
        SizedBox(
          width: DimenRes.screenWidth,
          height: DimenRes.screenWidth * 4 / 3,
          child: ListUtil.isEmpty(_chatDetail.girlPicsUrl)
              ? NetworkImgContainer(
                  url: _chatDetail.thumbUrl ?? '',
                  noVisibilityDetector: true,
                  fit: BoxFit.cover,
                )
              : SwiperContainer(imgList: _chatDetail.girlPicsUrl!),
        ),
        SingleChildScrollView(
          child: Container(
            margin: EdgeInsets.only(
                top: DimenRes.screenWidth * 4 / 3 - DimenRes.dimen_20),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.vertical(
                  top: Radius.circular(DimenRes.radius(20))),
              boxShadow: const [
                BoxShadow(
                    blurStyle: BlurStyle.outer,
                    color: Color.fromRGBO(0, 0, 0, 0.3),
                    offset: Offset(0, 0),
                    blurRadius: 10,
                    spreadRadius: 0),
              ],
              color: const Color(0xff1a152f).withOpacity(0.12),
              image: DecorationImage(
                  image: AssetImage(ImgRes.IMG_APP_BG),
                  fit: BoxFit.cover,
                  alignment: Alignment.topCenter),
            ),
            child: Padding(
              padding: EdgeInsets.symmetric(
                  vertical: DimenRes.convert(19),
                  horizontal: DimenRes.convert(16)),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildTitleSection(),
                  _buildAudioPlayerSection(),
                  const SpaceWidget(vSpace: 15),
                  _buildBaseInfoSection(),
                  const SpaceWidget(vSpace: 20),
                  _buildDescWidget(),
                  const SpaceWidget(vSpace: 30),
                  _buildFunSection(),
                  const SpaceWidget(vSpace: 50),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildTitleSection() {
    return Row(children: [
      Expanded(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextWidget.buildSingleLineText(
              _chatDetail.title ?? '',
              TextStyle(
                  color: Colors.white,
                  fontSize: DimenRes.sp(21),
                  fontWeight: FontWeight.w500),
            ),
            const SpaceWidget(vSpace: 3),
            StringUtil.isNotEmpty(_chatDetail.girlPrice)
                ? RichText(
                    text: TextSpan(
                      children: [
                        TextSpan(
                          style: TextStyle(
                              color: ColorRes.color_ff00b3,
                              fontSize: DimenRes.sp(16),
                              fontWeight: FontWeight.w500),
                          text: '¥${_chatDetail.girlPrice}',
                        ),
                        TextSpan(
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: DimenRes.sp(12),
                              fontWeight: FontWeight.w400),
                          text: " 起聊",
                        ),
                      ],
                    ),
                  )
                : const SizedBox(),
          ],
        ),
      ),
      Row(
        children: [
          Offstage(
            offstage: _chatDetail.isPay == 1,
            child: AppTextWithImgBgWidget(
              bgImgPath: ImgRes.BTN_SMALL,
              bgImgHeight: DimenRes.convert(34),
              text: StringRes.str_connect_line,
              top: 6,
              bottom: 10,
              left: 10,
              right: 10,
              textStyle: AppTextStyle.white_s12,
              onTap: onNudeChatAction,
            ),
          ),
          SpaceWidget(
              hSpace: (_chatDetail != null && _chatDetail.isPay == 1) ? 10 : 0),
          Offstage(
              offstage: _chatDetail.isPay != 1,
              child: AppTextWithImgBgWidget(
                bgImgPath: ImgRes.BTN_SMALL,
                bgImgHeight: DimenRes.convert(34),
                text: StringRes.str_contact_official,
                top: 6,
                bottom: 10,
                left: 5,
                right: 5,
                textStyle: AppTextStyle.white_s12,
                onTap: () {
                  onStopAudio();
                  context.push('/chatOrder?id=${_chatDetail.id}');
                },
              )),
          const SpaceWidget(hSpace: 10),
          AppTextWithImgBgWidget(
            bgImgPath: ImgRes.BTN_PINK,
            bgImgHeight: DimenRes.convert(34),
            text: StringRes.str_reward,
            top: 6,
            bottom: 10,
            left: 10,
            right: 10,
            textStyle: AppTextStyle.white_s12,
            onTap: onRewardAction,
          )
        ],
      )
    ]);
  }

  Widget _buildAudioPlayerSection() {
    return _chatDetail == null || StringUtil.isEmpty(_chatDetail.m3u8Full)
        ? const SizedBox()
        : Container(
            width: double.infinity,
            padding: EdgeInsets.only(
                left: DimenRes.dimen_20,
                right: DimenRes.dimen_20,
                top: DimenRes.dimen_15),
            decoration: BoxDecoration(
              borderRadius:
                  BorderRadius.all(Radius.circular(DimenRes.radius(12))),
              color: const Color(0x4c000000),
            ),
            child: AudioPlayerWidget(
              url: _chatDetail.m3u8Full ?? '',
              isFront: _isFront,
            ));
  }

  Widget _buildBaseInfoSection() {
    double itemWidth = (DimenRes.screenWidth - DimenRes.convert(16) * 5) / 4;
    Widget buildBaseInfoItem(String labelStr, String valueStr) {
      return FrostedGlassBox(
        width: itemWidth,
        padding: EdgeInsets.symmetric(
            vertical: DimenRes.dimen_8, horizontal: DimenRes.dimen_8),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextWidget.buildSingleLineText(
              labelStr,
              TextStyle(
                  color: Colors.white.withOpacity(0.84),
                  fontSize: DimenRes.sp(12)),
            ),
            const SpaceWidget(vSpace: 3),
            TextWidget.buildSingleLineText(
              valueStr,
              TextStyle(
                  color: Colors.white,
                  fontSize: DimenRes.sp(16),
                  fontWeight: FontWeight.w600),
            )
          ],
        ),
      );
    }

    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        buildBaseInfoItem(StringRes.str_age, '${_chatDetail.girlAge}'),
        buildBaseInfoItem(StringRes.str_cup, _chatDetail.girlCup ?? '无'),
        buildBaseInfoItem(StringRes.str_height, '${_chatDetail.girlHeight}'),
        buildBaseInfoItem(StringRes.str_weight, '${_chatDetail.girlWeight}'),
      ],
    );
  }

  Widget _buildDescWidget() {
    Widget buildDescItem(String titleStr, String contentStr,
        {int maxLines = 1}) {
      return Offstage(
        offstage: contentStr.isEmpty,
        child: Text("$titleStr：$contentStr",
            style: TextStyle(
                color: Colors.white.withOpacity(0.84),
                fontSize: DimenRes.sp(12)),
            maxLines: maxLines,
            overflow: TextOverflow.ellipsis),
      );
    }

    return _chatDetail != null
        ? Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              buildDescItem(
                  StringRes.str_chat_time, _chatDetail.girlBusinessHours ?? ''),
              SpaceWidget(
                vSpace:
                    StringUtil.isNotEmpty(_chatDetail.girlServiceType) ? 10 : 0,
              ),
              buildDescItem(StringRes.str_service_type,
                  _chatDetail.girlServiceType ?? ''),
              SpaceWidget(
                vSpace: StringUtil.isNotEmpty(_chatDetail.desc) ? 10 : 0,
              ),
              buildDescItem(StringRes.str_intro, _chatDetail.desc ?? '',
                  maxLines: 3),
              SpaceWidget(
                vSpace: StringUtil.isNotEmpty(_chatDetail.address) ? 10 : 0,
              ),
              buildDescItem(StringRes.str_address, _chatDetail.address ?? ''),
            ],
          )
        : const SizedBox();
  }

  Widget _buildFunSection() {
    Widget buildFunItem(String text, String path, void Function() onTap) {
      return GestureDetector(
        onTap: onTap,
        child: Column(
          children: [
            Image.asset(path,
                fit: BoxFit.contain,
                width: DimenRes.convert(30),
                height: DimenRes.convert(30)),
            const SpaceWidget(
              vSpace: 3,
            ),
            TextWidget.buildSingleLineText(
                text,
                TextStyle(
                    color: Colors.white.withOpacity(0.84),
                    fontSize: DimenRes.sp(10))),
          ],
        ),
      );
    }

    return FrostedGlassBox(
      width: double.infinity,
      borderRadius: BorderRadius.circular(DimenRes.radius(24)),
      child: Padding(
        padding: EdgeInsets.symmetric(vertical: DimenRes.dimen_12),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            buildFunItem(
              StringRes.str_comment,
              ImgRes.IC_COMMENT,
              () => showCommentModalDialog(),
            ),
            buildFunItem(
              isLike ? StringRes.str_collected : StringRes.str_collect,
              isLike ? ImgRes.IC_LIKED : ImgRes.IC_NO_LIKE,
              () => likeAction(),
            ),
            buildFunItem(
              StringRes.str_share,
              ImgRes.IC_SHARE,
              () {
                onStopAudio();
                PageJumpUtil.forwardToSharePage(context);
              },
            ),
          ],
        ),
      ),
    );
  }
}

class SwiperContainer extends StatefulWidget {
  final List imgList;

  const SwiperContainer({Key? key, required this.imgList}) : super(key: key);

  @override
  _SwiperContainerState createState() => _SwiperContainerState();
}

class _SwiperContainerState extends State<SwiperContainer> {
  List _imgList = [];

  @override
  void initState() {
    super.initState();
    _imgList = widget.imgList;
  }

  @override
  Widget build(BuildContext context) {
    return _imgList.length > 1
        ? SizedBox(
            width: DimenRes.screenWidth,
            height: DimenRes.screenWidth * 4 / 3,
            child: Swiper(
              scrollDirection: Axis.horizontal,
              itemBuilder: (BuildContext context, int index) {
                return NetworkImgContainer(
                  url: _imgList[index],
                  noVisibilityDetector: true,
                  fit: BoxFit.cover,
                );
              },
              itemCount: _imgList.length,
              pagination: SwiperPagination(
                margin: EdgeInsets.only(
                    bottom: DimenRes.dimen_5, right: DimenRes.dimen_5),
                builder: SwiperCustomPagination(
                  builder: (context, config) {
                    return Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Padding(
                            padding: EdgeInsets.all(DimenRes.dimen_16),
                            child: RichText(
                                text: TextSpan(children: [
                              TextSpan(
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.w400,
                                      fontStyle: FontStyle.normal,
                                      shadows: const <Shadow>[
                                        Shadow(
                                          offset: Offset(1.0, 1.0),
                                          blurRadius: 10.0,
                                          color: Color.fromRGBO(0, 0, 0, 0.2),
                                        ),
                                      ],
                                      fontSize: DimenRes.sp(36)),
                                  text: "${config.activeIndex + 1}"),
                              TextSpan(
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.w400,
                                      fontStyle: FontStyle.normal,
                                      shadows: const <Shadow>[
                                        Shadow(
                                          offset: Offset(1.0, 1.0),
                                          blurRadius: 10.0,
                                          color: Color.fromRGBO(0, 0, 0, 0.2),
                                        ),
                                      ],
                                      fontSize: DimenRes.sp(22)),
                                  text: "/${config.itemCount}")
                            ])),
                          )
                        ]);
                  },
                ),
              ),
            ),
          )
        : SizedBox(
            width: double.infinity,
            height: _imgList.length == 1 ? double.infinity : 0,
            child: _imgList.length == 1
                ? NetworkImgContainer(
                    url: _imgList[0],
                    noVisibilityDetector: true,
                    fit: BoxFit.cover,
                  )
                : const SizedBox(),
          );
  }
}
