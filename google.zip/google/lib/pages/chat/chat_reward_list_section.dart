import 'package:flutter/material.dart';
import 'package:iaimei/model/chat_reward_list.dart';
import 'package:iaimei/model/reward_set.dart';
import 'package:iaimei/net/http_helper.dart';
import 'package:iaimei/res/color_res.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/res/img_res.dart';
import 'package:iaimei/res/string_res.dart';
import 'package:iaimei/style/app_text_style.dart';
import 'package:iaimei/utils/list_util.dart';
import 'package:iaimei/utils/page_jump_util.dart';
import 'package:iaimei/widget/app_text_with_img_bg_widget.dart';
import 'package:iaimei/widget/space_widget.dart';
import 'package:iaimei/widget/text_widget.dart';
import 'package:iaimei/widget/toast_widget.dart';

class ChatRewardListSection extends StatefulWidget {
  final ChatRewardList? rewardData;
  final int? uid;

  const ChatRewardListSection({Key? key, this.rewardData, this.uid})
      : super(key: key);

  @override
  State<ChatRewardListSection> createState() => _ChatRewardListSectionState();
}

class _ChatRewardListSectionState extends State<ChatRewardListSection> {
  String _gid = '';
  List<RewardSet> _rewardList = [];
  Member _member = Member();

  @override
  void initState() {
    super.initState();
    if (widget.rewardData != null &&
        ListUtil.isNotEmpty(widget.rewardData!.gifts)) {
      _rewardList = widget.rewardData!.gifts ?? [];
      _member = widget.rewardData!.member ?? Member();
      _gid = widget.rewardData!.gifts![0].gid ?? '';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const SpaceWidget(
          vSpace: 40,
        ),
        TextWidget.buildSingleLineText('要怎么打赏妹妹呢？', AppTextStyle.white_s16),
        const SpaceWidget(
          vSpace: 20,
        ),
        _buildItemSection(),
        const SpaceWidget(
          vSpace: 30,
        ),
        _buildConfirmBtnWidget(),
        const SpaceWidget(
          vSpace: 15,
        ),
        _buildBottomSection(context),
        const SpaceWidget(
          vSpace: 20,
        ),
      ],
    );
  }

  _buildBottomSection(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        TextWidget.buildSingleLineText(
          '当前余额 ¥${_member.coins}',
          AppTextStyle.white_s12,
        ),
        const SpaceWidget(hSpace: 20),
        GestureDetector(
          onTap: () {
            PageJumpUtil.forwardToRechargeCoinsPage(context);
            Navigator.pop(context);
          },
          child: TextWidget.buildSingleLineText(
            StringRes.str_to_recharge,
            AppTextStyle.cff00b3_s12,
          ),
        ),
      ],
    );
  }

  _buildItemSection() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: DimenRes.dimen_15),
      child: Wrap(
        spacing: DimenRes.dimen_10,
        runSpacing: DimenRes.dimen_10,
        children: _buildRewardItemSection(),
      ),
    );
  }

  _buildConfirmBtnWidget() {
    return AppTextWithImgBgWidget(
      bgImgPath: ImgRes.DIALOG_BTN_BG,
      bgImgHeight: DimenRes.convert(44),
      text: StringRes.str_confirm,
      top: 6,
      bottom: 10,
      left: 10,
      right: 10,
      textStyle: AppTextStyle.white_s12,
      onTap: onReward,
    );
  }

  void onReward() {
    if (_gid.isEmpty) return;
    HttpHelper.chatRewardAction(widget.uid ?? 0, _gid, (data) {
      ToastWidget.showToast(StringRes.str_reward_success);
      Navigator.pop(context);
    }, (error) {
      ToastWidget.showToast(error.message ?? StringRes.str_reward_fail);
      Navigator.pop(context);
    });
  }

  _buildRewardItemSection() {
    double itemWidth = (DimenRes.screenWidth - DimenRes.convert(110)) / 3;
    return _rewardList.map((item) {
      return GestureDetector(
        onTap: () {
          setState(() {
            _gid = item.gid ?? '';
          });
        },
        child: Container(
          width: itemWidth,
          decoration: BoxDecoration(
              color: Colors.black12,
              border: Border.all(
                  width: 1,
                  color: _gid == item.gid
                      ? ColorRes.color_ff00b3
                      : Colors.transparent),
              borderRadius: BorderRadius.circular(12)),
          alignment: Alignment.center,
          padding: EdgeInsets.symmetric(
              vertical: DimenRes.dimen_15, horizontal: DimenRes.dimen_12),
          child: TextWidget.buildSingleLineText(
              '¥${item.value}',
              _gid == item.gid
                  ? AppTextStyle.cff00b3_s16
                  : AppTextStyle.white_s16),
        ),
      );
    }).toList();
  }
}
