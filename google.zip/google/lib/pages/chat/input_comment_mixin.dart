import 'package:bot_toast/bot_toast.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:iaimei/components/common/pullrefreshlist.dart';
import 'package:iaimei/utils/api.dart';
import 'package:iaimei/widget/convenient_mixin.dart';
import 'package:iaimei/widget/network_img_container.dart';

mixin InputCommentMixin<T extends StatefulWidget> on ConvenientMixin, State<T> {
  dynamic infoId; // 裸聊ID 约炮ID
  List mmList = []; // 列表数据
  int commentPage = 1;
  StateSetter? commentSetState;
  String? inputHintText;
  TextEditingController? inputVc;

  void _onDismissfocus() {
    FocusScope.of(context).requestFocus(FocusNode());
  }

  void initCommentList() {
    if (infoId == null) {
      BotToast.showText(text: "信息ID不能为空");
      return;
    }
    apiChatListComment(id: infoId, page: commentPage).then((res) {
      if (res != null) {
        if (commentPage == 1) mmList = [];
        mmList.addAll(res.data.list);
        commentSetState?.call(() {});
      } else {
        BotToast.showText(text: res?.msg ?? '未知错误');
      }
    });
  }

  void onCommentRefresh() {
    commentPage = 1;
    initCommentList();
  }

  void onCommentLoading() {
    commentPage += 1;
    initCommentList();
  }

  void onCommentSubmit() {
    if (infoId == null) {
      BotToast.showText(text: "信息ID不能为空");
      return;
    }

    if (inputVc?.text.isEmpty ?? true) {
      BotToast.showText(text: "请输入评论内容");
      return;
    }

    BotToast.showLoading();
    apiChatCreateComment(infoId, inputVc!.text).then((res) {
      BotToast.closeAllLoading();
      if (res != null) {
        BotToast.showText(text: res.msg);
        onCommentRefresh(); // 更新信息
        if (res.status == 1) {
          inputVc!.text = "";
        }
        commentSetState?.call(() {});
      }
    });
  }

  void showCommentModalDialog() {
    initCommentList();
    inputVc ??= TextEditingController();
    inputHintText ??= '留下真实评论的哥哥，都是最帅的男人';

    showModalBottomSheet(
      isScrollControlled: true,
      context: context,
      backgroundColor: const Color(0xff1a152f),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(15.w)),
      ),
      builder: (context) {
        return StatefulBuilder(
          builder: (context, StateSetter setState) {
            commentSetState = setState;
            return AnimatedPadding(
              // 键盘弹出动画
              padding: MediaQuery.of(context).viewInsets,
              duration: const Duration(milliseconds: 0), // 100s
              child: SizedBox(
                height: ScreenUtil().screenHeight * 0.6,
                child: GestureDetector(
                  onTap: _onDismissfocus,
                  child: Column(
                    children: [
                      buildCommentNavBarWidget('评论'),
                      Expanded(
                        child: PullRefreshList(
                          onRefresh: onCommentRefresh,
                          onLoading: onCommentLoading,
                          child: buildCommentListWidget(),
                        ),
                      ),
                      buildCommentBottomBarWidget(), // 输入发布评论
                    ],
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget buildCommentNavBarWidget(String title) {
    return Container(
      padding: EdgeInsets.fromLTRB(16.w, 20.w, 16.w, 10.w),
      width: double.infinity,
      color: const Color(0x15ffffff),
      child: Text(
        title,
        style: TextStyle(color: wColor, fontSize: 18.sp, fontWeight: fontB),
        textAlign: TextAlign.justify,
      ),
    );
  }

  Widget buildCommentListWidget() {
    return ListView.builder(
      itemCount: mmList.length,
      itemBuilder: (_, i) => Container(
        margin: EdgeInsets.fromLTRB(16.w, 10.w, 16.w, 0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              children: [
                ClipOval(
                  child: SizedBox(
                    width: 24.w,
                    height: 24.w,
                    child: NetworkImgContainer(
                      url: mmList[i].member.avatarUrl,
                      noVisibilityDetector: true,
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
                SizedBox(width: 10.w),
                Text(
                  mmList[i].member.nickname,
                  overflow: TextOverflow.ellipsis,
                  maxLines: 1,
                  style: TextStyle(
                      color: wColor, fontSize: 14.sp, fontWeight: fontM),
                ),
              ],
            ),
            SizedBox(height: 10.w),
            Text(
              mmList[i].content,
              style: TextStyle(color: color_84, fontSize: 12.sp),
              textAlign: TextAlign.start,
            ),
            SizedBox(height: 10.w),
            Container(
              width: double.infinity,
              height: 0.5.w,
              color: const Color(0x33ffffff),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildCommentBottomBarWidget() {
    return Container(
      padding: EdgeInsets.fromLTRB(
          16.w, 8.5.w, 16.w, 8.5.w + ScreenUtil().bottomBarHeight),
      width: double.infinity,
      color: const Color(0xff241e3b),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Expanded(
            child: Container(
              width: double.infinity,
              alignment: Alignment.centerLeft,
              height: 32.w,
              padding: EdgeInsets.symmetric(horizontal: 15.w),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.all(Radius.circular(18.w)),
                color: const Color(0x14ffffff),
              ),
              child: TextField(
                onSubmitted: (input) {},
                controller: inputVc,
                maxLines: 1,
                cursorColor: color_84,
                textInputAction: TextInputAction.done,
                autofocus: false,
                maxLength: 50,
                style: TextStyle(fontSize: 12.sp, color: color_84),
                decoration: InputDecoration(
                  hintStyle: TextStyle(fontSize: 12.sp, color: color_64),
                  hintText: inputHintText,
                  counterText: '',
                  border: const OutlineInputBorder(borderSide: BorderSide.none),
                  contentPadding: EdgeInsets.zero,
                ),
              ),
            ),
          ),
          SizedBox(width: 15.w),
          GestureDetector(
            onTap: onCommentSubmit,
            child: SizedBox(
              width: 66.w,
              height: 36.w,
              child: Stack(
                children: [
                  Image.asset("assets/images/button/btn_small.png",
                      width: 66.w, height: 36.w),
                  Positioned.fill(
                    child: Padding(
                      padding: EdgeInsets.only(top: 7.w),
                      child: Text(
                        "发送",
                        style: TextStyle(
                            color: wColor, fontWeight: fontM, fontSize: 13.sp),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
