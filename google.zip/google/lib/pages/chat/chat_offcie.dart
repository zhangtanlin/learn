import 'package:flutter/material.dart';

class ChatOffice extends StatefulWidget {
  const ChatOffice({Key? key}) : super(key: key);

  @override
  State<ChatOffice> createState() => _ChatOfficeState();
}

class _ChatOfficeState extends State<ChatOffice> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
