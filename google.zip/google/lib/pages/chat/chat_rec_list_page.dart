import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:iaimei/base/app_base_widget_state.dart';
import 'package:iaimei/mixin/list_page_load_mixin.dart';
import 'package:iaimei/model/chat_item_model.dart';
import 'package:iaimei/model/chat_rec_model.dart';
import 'package:iaimei/net/http_helper.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/res/img_res.dart';
import 'package:iaimei/res/string_res.dart';
import 'package:iaimei/utils/list_util.dart';
import 'package:iaimei/utils/page_jump_util.dart';
import 'package:iaimei/widget/app_page_title_bar.dart';
import 'package:iaimei/widget/list_widget.dart';
import 'package:iaimei/widget/network_img_container.dart';
import 'package:iaimei/widget/refresh_load_list_widget.dart';

class ChatRecListPage extends StatefulWidget {
  const ChatRecListPage({Key? key}) : super(key: key);

  @override
  State<ChatRecListPage> createState() => _ChatRecListPageState();
}

class _ChatRecListPageState extends AppBaseWidgetState<ChatRecListPage>
    with ListPageLoadMixin {
  @override
  void initState() {
    super.initState();
    onLoadData();
  }

  @override
  buildAppBar() {
    return AppPageTitleBar.getNormalAppBar(
      title: StringRes.str_nude_chat,
    );
  }

  @override
  Widget buildPageLayout() {
    return handlePageStateView();
  }

  @override
  onLoadData() {
    onRefreshList();
  }

  @override
  void requestListData(bool isRefresh) {
    HttpHelper.getChatRecList(getCurPage, getPageSize, (data) {
      ChatRecModel recModel = ChatRecModel.fromJson(data);
      setListPageState(isRefresh, ListUtil.isNotEmpty(recModel.list), () {
        updatePageList(isRefresh, recModel.list!);
      });
    }, (error) {
      setPageErrorState(error);
    });
  }

  @override
  Widget successView() {
    return RefreshLoadListWidget(
      enableLoad: isEnableLoad(),
      enableRefresh: isEnableRefresh(),
      onRefresh: onRefreshList,
      onLoad: onLoadList,
      refreshController: refreshController,
      child: _buildChatListSection(getResultList),
    );
  }

  _buildChatListSection(List resultList) {
    return ListWidget.buildGridView(
        padding: EdgeInsets.only(
            left: DimenRes.dimen_15,
            right: DimenRes.dimen_15,
            top: DimenRes.dimen_10),
        itemCount: resultList.length,
        itemBuilder: (context, index) =>
            _buildChatItem(resultList[index] as ChatItemModel),
        childRatio: 0.72,
        mainSpace: DimenRes.dimen_15,
        crossSpace: DimenRes.dimen_15,
        crossCount: 2);
  }

  _buildChatItem(ChatItemModel itemModel) {
    return ChatBigCard(
        items: itemModel,
        onTap: () {
          PageJumpUtil.forwardToChatDetailPage(context, itemModel.id!);
        });
  }
}

class ChatBigCard extends StatelessWidget {
  const ChatBigCard({
    Key? key,
    required this.onTap,
    required this.items,
  }) : super(key: key);
  final GestureTapCallback onTap;
  final ChatItemModel items;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: ClipRRect(
        borderRadius: const BorderRadius.all(Radius.circular(15)),
        child: Stack(
          children: [
            Positioned.fill(
                child: NetworkImgContainer(
              url: items.thumbUrl ?? '',
              noVisibilityDetector: true,
              fit: BoxFit.cover,
            )),
            Positioned.fill(
                child: Image.asset(
              ImgRes.GRADIENT_LAYER_MID,
              fit: BoxFit.cover,
            )),
            Positioned(
                left: 0,
                right: 0,
                bottom: 0,
                child: Container(
                  padding: EdgeInsets.only(
                    left: DimenRes.dimen_5,
                    right: DimenRes.dimen_5,
                    bottom: DimenRes.dimen_5,
                  ),
                  child: Text(
                    items.title ?? '',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w500,
                        fontSize: ScreenUtil().setSp(12)),
                  ),
                ))
          ],
        ),
      ),
    );
  }
}
