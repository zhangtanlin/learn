import 'package:flutter/material.dart';
import 'package:iaimei/model/chat_set.dart';
import 'package:iaimei/net/http_helper.dart';
import 'package:iaimei/res/color_res.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/res/img_res.dart';
import 'package:iaimei/res/string_res.dart';
import 'package:iaimei/store/userdata.dart';
import 'package:iaimei/style/app_text_style.dart';
import 'package:iaimei/utils/page_jump_util.dart';
import 'package:iaimei/widget/app_text_with_img_bg_widget.dart';
import 'package:iaimei/widget/space_widget.dart';
import 'package:iaimei/widget/text_widget.dart';
import 'package:iaimei/widget/toast_widget.dart';
import 'package:provider/provider.dart';

class BuyChatTimeSection extends StatefulWidget {
  final List<ChatSet>? chatList;
  final int? id;
  final void Function()? callback;

  const BuyChatTimeSection({Key? key, this.chatList, this.id, this.callback})
      : super(key: key);

  @override
  State<BuyChatTimeSection> createState() => _BuyChatTimeSectionState();
}

class _BuyChatTimeSectionState extends State<BuyChatTimeSection> {
  List<ChatSet> _chatList = [];
  String _chatSet = '';

  @override
  void initState() {
    super.initState();
    _chatList = widget.chatList ?? [];
    _chatSet = _chatList[0].setId ?? '';
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const SpaceWidget(
          vSpace: 40,
        ),
        _buildItemSection(),
        const SpaceWidget(
          vSpace: 30,
        ),
        _buildConfirmBtnWidget(),
        const SpaceWidget(
          vSpace: 15,
        ),
        _buildBottomSection(context),
        const SpaceWidget(
          vSpace: 20,
        ),
      ],
    );
  }

  _buildItemSection() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: DimenRes.dimen_15),
      child: Wrap(
        spacing: DimenRes.dimen_20,
        runSpacing: DimenRes.dimen_20,
        children: _buildChatTimeItemSection(),
      ),
    );
  }

  _buildChatTimeItemSection() {
    double itemWidth = (DimenRes.screenWidth - DimenRes.convert(140)) / 2;
    return _chatList.map((item) {
      return GestureDetector(
        onTap: () {
          setState(() {
            _chatSet = item.setId!;
          });
        },
        child: Container(
          width: itemWidth,
          alignment: Alignment.center,
          decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.18),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                  width: 1,
                  color: _chatSet == item.setId
                      ? ColorRes.color_ff00b3
                      : Colors.transparent)),
          child: Column(
            children: [
              Container(
                width: double.infinity,
                alignment: Alignment.center,
                padding: EdgeInsets.symmetric(vertical: DimenRes.dimen_5),
                decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.18),
                    borderRadius:
                        BorderRadius.vertical(top: Radius.circular(12))),
                child: TextWidget.buildSingleLineText(
                    item.name ?? '',
                    _chatSet == item.setId
                        ? AppTextStyle.cff00b3_s12
                        : AppTextStyle.white_s12),
              ),
              Container(
                padding: EdgeInsets.symmetric(vertical: DimenRes.dimen_20),
                child: TextWidget.buildSingleLineText(
                    '¥${item.value ?? ''}',
                    _chatSet == item.setId
                        ? AppTextStyle.cff00b3_s14
                        : AppTextStyle.white_s14),
              ),
            ],
          ),
        ),
      );
    }).toList();
  }

  _buildConfirmBtnWidget() {
    return AppTextWithImgBgWidget(
      bgImgPath: ImgRes.DIALOG_BTN_BG,
      bgImgHeight: DimenRes.convert(44),
      text: StringRes.str_buy,
      top: 6,
      bottom: 10,
      left: 10,
      right: 10,
      textStyle: AppTextStyle.white_s12,
      onTap: onBuyAction,
    );
  }

  void onBuyAction() {
    if (_chatSet.isEmpty) return;
    HttpHelper.chatBuyAction(widget.id ?? 0, _chatSet, (data) {
      ToastWidget.showToast(StringRes.str_buy_success);
      Navigator.pop(context);
      widget.callback?.call();
    }, (error) {
      ToastWidget.showToast(error.message ?? StringRes.str_buy_fail);
    });
  }

  _buildBottomSection(BuildContext context) {
    var user = Provider.of<UserData>(context, listen: false).userInfo;
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        TextWidget.buildSingleLineText(
          '当前余额 ¥${user.coins}',
          AppTextStyle.white_s12,
        ),
        const SpaceWidget(hSpace: 20),
        GestureDetector(
          onTap: () {
            PageJumpUtil.forwardToRechargeCoinsPage(context);
            Navigator.pop(context);
          },
          child: TextWidget.buildSingleLineText(
            StringRes.str_to_recharge,
            AppTextStyle.cff00b3_s12,
          ),
        ),
      ],
    );
  }
}
