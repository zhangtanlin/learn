import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:iaimei/base/base_widget_state.dart';
import 'package:iaimei/components/common/pageviewmixin.dart';
import 'package:iaimei/model/chat_rank_user_model.dart';
import 'package:iaimei/net/http_helper.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/res/img_res.dart';
import 'package:iaimei/widget/app_divider_widget.dart';
import 'package:iaimei/widget/app_img_widget.dart';
import 'package:iaimei/widget/network_img_container.dart';
import 'package:iaimei/widget/space_widget.dart';
import 'package:iaimei/widget/text_widget.dart';

class ChatRankingPage extends StatefulWidget {
  const ChatRankingPage({Key? key}) : super(key: key);

  @override
  State<ChatRankingPage> createState() => _ChatRankingPageState();
}

class _ChatRankingPageState extends BaseWidgetState<ChatRankingPage>
    with TickerProviderStateMixin {
  late TabController tabController;
  List rankTabs = ["魅力榜", "土豪榜"];
  int _selectIndex = 0;

  @override
  void initState() {
    super.initState();
    tabController = TabController(length: rankTabs.length, vsync: this);
    tabController.addListener(() {
      if (tabController.index.toDouble() == tabController.animation?.value) {
        setState(() {
          _selectIndex = tabController.index;
        });
      }
    });
  }

  @override
  bool isShowSafeArea() {
    return false;
  }

  @override
  void dispose() {
    if (tabController != null) {
      tabController.dispose();
    }
    super.dispose();
  }

  @override
  Widget buildPageLayout() {
    return SizedBox(
      width: double.infinity,
      height: double.infinity,
      child: Stack(
        children: [
          _buildTabBarView(),
          Padding(
            padding: EdgeInsets.only(top: DimenRes.statusBarHeight),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                GestureDetector(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: _buildBackWidget(),
                ),
                Container(
                  alignment: Alignment.center,
                  margin: EdgeInsets.only(top: DimenRes.dimen_10),
                  width: DimenRes.convert(136),
                  height: DimenRes.convert(32),
                  decoration: BoxDecoration(
                      border: Border.all(
                          color: _selectIndex == 0
                              ? const Color(0xffff00b3)
                              : const Color(0xfffbc989)),
                      borderRadius: BorderRadius.circular(20)),
                  child: _buildTopTabBar(),
                ),
                SizedBox(
                  width: DimenRes.dimen_35,
                  height: DimenRes.dimen_35,
                )
              ],
            ),
          ),
        ],
      ),
    );
  }

  _buildTabBarView() {
    return TabBarView(
      controller: tabController,
      children: rankTabs
          .asMap()
          .keys
          .map((index) => PageViewMixin(
                child: ChatRankingListPage(
                    showPage: _selectIndex == index, type: index + 1),
              ))
          .toList(),
    );
  }

  _buildBackWidget() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: DimenRes.dimen_6),
      child: Image.asset(
        _selectIndex == 0 ? ImgRes.IC_ARROW_BACK : ImgRes.IC_ARROW_BACK_GOLD,
        width: DimenRes.dimen_35,
        height: DimenRes.dimen_35,
        fit: BoxFit.contain,
      ),
    );
  }

  _buildTopTabBar() {
    return TabBar(
      padding: EdgeInsets.zero,
      labelPadding: EdgeInsets.zero,
      controller: tabController,
      unselectedLabelColor: Colors.transparent,
      unselectedLabelStyle: TextStyle(fontSize: DimenRes.sp(11)),
      indicatorWeight: 0,
      indicator: const BoxDecoration(),
      labelColor: Colors.transparent,
      labelStyle: TextStyle(fontSize: DimenRes.sp(11)),
      enableFeedback: true,
      tabs: [
        Tab(
          iconMargin: EdgeInsets.zero,
          height: DimenRes.convert(24),
          child: _selectIndex == 0
              ? Image.asset(
                  ImgRes.TAB_MEILI,
                  width: DimenRes.convert(59),
                  height: DimenRes.convert(24),
                  fit: BoxFit.contain,
                )
              : TextWidget.buildSingleLineText(
                  rankTabs[0],
                  TextStyle(color: Colors.white.withOpacity(0.84)),
                ),
        ),
        Tab(
          height: DimenRes.convert(24),
          child: _selectIndex == 1
              ? Image.asset(
                  ImgRes.TAB_TUHAO,
                  width: DimenRes.convert(59),
                  height: DimenRes.convert(24),
                  fit: BoxFit.contain,
                )
              : TextWidget.buildSingleLineText(
                  rankTabs[1],
                  TextStyle(color: Colors.white.withOpacity(0.84)),
                ),
        )
      ],
    );
  }
}

class ChatRankingListPage extends StatefulWidget {
  const ChatRankingListPage(
      {Key? key, required this.type, required this.showPage})
      : super(key: key);
  final int type;
  final bool showPage;

  @override
  State<ChatRankingListPage> createState() => _ChatRankingListPageState();
}

class _ChatRankingListPageState extends BaseWidgetState<ChatRankingListPage> {
  List<ChatRankUserModel> rankList = [];
  List<ChatRankUserModel> secList = [];

  @override
  void initState() {
    super.initState();
    initData();
  }

  void initData() {
    HttpHelper.getChatRanking(widget.type, (data) {
      rankList = (data as List)
          .map((json) => ChatRankUserModel.fromJson(json))
          .toList();
      secList = rankList.sublist(3);
      setState(() {});
    }, (error) {});
  }

  @override
  void didUpdateWidget(covariant ChatRankingListPage oldWidget) {
    super.didUpdateWidget(oldWidget);
  }

  @override
  Widget buildPageLayout() {
    return SingleChildScrollView(
      child: Column(
        children: [
          SizedBox(
            height: DimenRes.statusBarHeight + DimenRes.dimen_55,
          ),
          _buildTopAvatarSection(),
          const SpaceWidget(vSpace: 105),
          _buildRankListSection(),
          const SpaceWidget(vSpace: 50),
        ],
      ),
    );
  }

  _buildRankListSection() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: DimenRes.dimen_16),
      height: DimenRes.convert(367),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(DimenRes.radius(20)),
          border: Border.all(
              width: 0.5,
              color: widget.type == 1
                  ? const Color.fromRGBO(255, 127, 255, 0.5)
                  : const Color.fromRGBO(255, 219, 168, 0.5)),
          color: const Color.fromRGBO(255, 255, 255, 0.12)),
      child: Column(
        children: [
          _buildRankListTitleSection(),
          Column(
            children: secList
                .asMap()
                .keys
                .map((e) => RankingItem(
                    avatarUrl: secList[e].avatarUrl ?? '',
                    coins: secList[e].rank ?? '0',
                    nickname: secList[e].nickname ?? '',
                    numbers: (e + 4).toString(),
                    isGold: widget.type == 1))
                .toList(),
          )
        ],
      ),
    );
  }

  _buildRankListTitleSection() {
    return SizedBox(
      height: DimenRes.convert(54),
      child: ClipRRect(
        borderRadius: BorderRadius.only(
            topLeft: Radius.circular(DimenRes.radius(20)),
            topRight: Radius.circular(DimenRes.radius(20))),
        child: Container(
          color: Colors.white.withOpacity(0.18),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 13, sigmaY: 13),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Expanded(
                    child: Container(
                  alignment: Alignment.center,
                  child: Text(
                    "名次",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: DimenRes.sp(14),
                      fontWeight: FontWeight.w600,
                      fontStyle: FontStyle.normal,
                      letterSpacing: 0,
                      shadows: [
                        BoxShadow(
                            color: widget.type == 1
                                ? const Color(0x80ff02b7)
                                : const Color(0x80ffe8ad),
                            offset: const Offset(0, 2),
                            blurRadius: 4,
                            spreadRadius: 0)
                      ],
                    ),
                  ),
                )),
                Expanded(
                    child: Container(
                        alignment: Alignment.center,
                        child: Text(
                          widget.type == 1 ? "女神" : "土豪",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: DimenRes.sp(14),
                            fontWeight: FontWeight.w600,
                            fontStyle: FontStyle.normal,
                            letterSpacing: 0,
                            shadows: [
                              BoxShadow(
                                  color: widget.type == 1
                                      ? const Color(0x80ff02b7)
                                      : const Color(0x80ffe8ad),
                                  offset: const Offset(0, 2),
                                  blurRadius: 4,
                                  spreadRadius: 0)
                            ],
                          ),
                        ))),
                Expanded(
                    child: Container(
                        alignment: Alignment.center,
                        child: Text(
                          widget.type == 1 ? "被赏钻石" : "打赏钻石",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: DimenRes.sp(14),
                            fontWeight: FontWeight.w600,
                            fontStyle: FontStyle.normal,
                            letterSpacing: 0,
                            shadows: [
                              BoxShadow(
                                  color: widget.type == 1
                                      ? const Color(0x80ff02b7)
                                      : const Color(0x80ffe8ad),
                                  offset: const Offset(0, 2),
                                  blurRadius: 4,
                                  spreadRadius: 0)
                            ],
                          ),
                        ))),
              ],
            ),
          ),
        ),
      ),
    );
  }

  _buildTopAvatarSection() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        _buildSecondSection(),
        const SpaceWidget(hSpace: 5),
        _buildFirstSection(),
        const SpaceWidget(hSpace: 5),
        _buildThirdSection(),
      ],
    );
  }

  _buildThirdSection() {
    return SizedBox(
      width: DimenRes.convert(96),
      child: GestureDetector(
        onTap: () {},
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SpaceWidget(vSpace: 40),
            Stack(
              alignment: Alignment.center,
              children: [
                AppImgWidget(
                    path: widget.type == 1
                        ? ImgRes.AVATAR_BORDER_23
                        : ImgRes.AVATAR_BORDER_GOLD_23,
                    width: DimenRes.convert(76),
                    height: DimenRes.convert(76),
                    fit: BoxFit.cover),
                NetworkImgContainer(
                  width: DimenRes.convert(64),
                  height: DimenRes.convert(64),
                  radius: BorderRadius.circular(35),
                  url: rankList.length >= 3 ? rankList[2].avatarUrl ?? '' : '',
                  fit: BoxFit.cover,
                )
              ],
            ),
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text(
                rankList.length >= 3 ? rankList[2].nickname ?? "虚位以待" : "虚位以待",
                maxLines: 1,
                style: TextStyle(
                    color: const Color(0xffffffff),
                    fontWeight: FontWeight.w600,
                    fontStyle: FontStyle.normal,
                    fontSize: DimenRes.sp(16)),
                textAlign: TextAlign.center,
              ),
            ),
            Text(rankList.length >= 3 ? rankList[2].rank ?? '0' : "0",
                style: TextStyle(
                    color: widget.type == 1
                        ? const Color(0xffff00b3)
                        : const Color(0xfffbd1a4),
                    fontWeight: FontWeight.w600,
                    fontStyle: FontStyle.normal,
                    fontSize: DimenRes.sp(14)),
                textAlign: TextAlign.center)
          ],
        ),
      ),
    );
  }

  _buildFirstSection() {
    return SizedBox(
      width: DimenRes.convert(112),
      child: GestureDetector(
        onTap: () {},
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Stack(
              alignment: Alignment.center,
              children: [
                AppImgWidget(
                    path: widget.type == 1
                        ? ImgRes.AVATAR_BORDER_1
                        : ImgRes.AVATAR_BORDER_GOLD_1,
                    width: DimenRes.convert(92),
                    height: DimenRes.convert(92),
                    fit: BoxFit.cover),
                NetworkImgContainer(
                  width: DimenRes.convert(72),
                  height: DimenRes.convert(72),
                  radius: BorderRadius.circular(40),
                  url: rankList.isNotEmpty ? rankList[0].avatarUrl ?? '' : '',
                  fit: BoxFit.cover,
                )
              ],
            ),
            Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Text(
                  rankList.isNotEmpty ? rankList[0].nickname ?? '虚位以待' : "虚位以待",
                  maxLines: 1,
                  style: TextStyle(
                      color: const Color(0xffffffff),
                      fontWeight: FontWeight.w600,
                      fontStyle: FontStyle.normal,
                      fontSize: 18.sp),
                  textAlign: TextAlign.center,
                )),
            Text(rankList.isNotEmpty ? rankList[0].rank ?? '0' : "0",
                style: TextStyle(
                    color: widget.type == 1
                        ? const Color(0xffff00b3)
                        : const Color(0xfffbd1a4),
                    fontWeight: FontWeight.w600,
                    fontStyle: FontStyle.normal,
                    fontSize: 14.sp),
                textAlign: TextAlign.center)
          ],
        ),
      ),
    );
  }

  _buildSecondSection() {
    return SizedBox(
      width: DimenRes.convert(96),
      child: GestureDetector(
        onTap: () {},
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SpaceWidget(vSpace: 40),
            Stack(
              alignment: Alignment.center,
              children: [
                AppImgWidget(
                    path: widget.type == 1
                        ? ImgRes.AVATAR_BORDER_23
                        : ImgRes.AVATAR_BORDER_GOLD_23,
                    width: DimenRes.convert(76),
                    height: DimenRes.convert(76),
                    fit: BoxFit.cover),
                NetworkImgContainer(
                  width: DimenRes.convert(64),
                  height: DimenRes.convert(64),
                  radius: BorderRadius.circular(35),
                  url: rankList.length >= 2 ? rankList[1].avatarUrl ?? '' : '',
                  fit: BoxFit.cover,
                )
              ],
            ),
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text(
                rankList.length >= 2 ? rankList[1].nickname ?? "虚位以待" : "虚位以待",
                maxLines: 1,
                style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w600,
                    fontStyle: FontStyle.normal,
                    fontSize: DimenRes.sp(16)),
                textAlign: TextAlign.center,
              ),
            ),
            Text(rankList.length >= 2 ? rankList[1].rank ?? '0' : "0",
                style: TextStyle(
                    color: widget.type == 1
                        ? const Color(0xffff00b3)
                        : const Color(0xfffbd1a4),
                    fontWeight: FontWeight.w600,
                    fontStyle: FontStyle.normal,
                    fontSize: DimenRes.sp(14)),
                textAlign: TextAlign.center)
          ],
        ),
      ),
    );
  }

  @override
  bool isShowSafeArea() {
    return false;
  }

  @override
  buildPageBg() {
    return Image.asset(
      widget.type == 1 ? ImgRes.BG_RANK_MEILI : ImgRes.BG_RANK_TUHAO,
      fit: BoxFit.cover,
      width: MediaQuery.of(context).size.width,
      height: MediaQuery.of(context).size.height,
    );
  }
}

class RankingItem extends StatelessWidget {
  const RankingItem({
    Key? key,
    required this.avatarUrl,
    required this.nickname,
    required this.coins,
    required this.numbers,
    required this.isGold,
  }) : super(key: key);
  final String avatarUrl;
  final String nickname;
  final String coins;
  final String numbers;
  final bool isGold;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: EdgeInsets.symmetric(vertical: DimenRes.dimen_10),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Expanded(
                  child: Container(
                alignment: Alignment.center,
                child: Text(
                  numbers,
                  maxLines: 1,
                  style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w600,
                      fontStyle: FontStyle.normal,
                      fontSize: DimenRes.sp(13)),
                  textAlign: TextAlign.center,
                ),
              )),
              Expanded(
                  child: Container(
                alignment: Alignment.center,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    NetworkImgContainer(
                      width: DimenRes.convert(24),
                      height: DimenRes.convert(24),
                      radius: BorderRadius.circular(DimenRes.dimen_15),
                      url: avatarUrl,
                      fit: BoxFit.cover,
                    ),
                    const SpaceWidget(
                      hSpace: 10,
                    ),
                    Expanded(
                        child: Text(
                      nickname,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.start,
                      style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w600,
                          fontStyle: FontStyle.normal,
                          fontSize: DimenRes.sp(13)),
                    )),
                  ],
                ),
              )),
              Expanded(
                  child: Container(
                alignment: Alignment.center,
                child: Text(
                  coins,
                  maxLines: 1,
                  style: TextStyle(
                      color: isGold
                          ? const Color(0xffff00b7)
                          : const Color(0xffffd09d),
                      fontWeight: FontWeight.w600,
                      fontStyle: FontStyle.normal,
                      fontSize: DimenRes.sp(13)),
                  textAlign: TextAlign.center,
                ),
              ))
            ],
          ),
        ),
        AppDividerWidget(
          height: 0.5,
          padding: EdgeInsets.only(
              left: DimenRes.dimen_24, right: DimenRes.dimen_24),
          color: Colors.white.withOpacity(0.12),
        ),
      ],
    );
  }
}
