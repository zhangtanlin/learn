import 'package:card_swiper/card_swiper.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:iaimei/base/app_base_widget_state.dart';
import 'package:iaimei/components/common/commonelements.dart';
import 'package:iaimei/mixin/page_load_mixin.dart';
import 'package:iaimei/model/chat_index_model.dart';
import 'package:iaimei/model/chat_item_model.dart';
import 'package:iaimei/net/http_helper.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/res/img_res.dart';
import 'package:iaimei/res/string_res.dart';
import 'package:iaimei/utils/list_util.dart';
import 'package:iaimei/utils/page_jump_util.dart';
import 'package:iaimei/utils/string_util.dart';
import 'package:iaimei/widget/app_img_widget.dart';
import 'package:iaimei/widget/app_page_title_bar.dart';
import 'package:iaimei/widget/audio_player_widget.dart';
import 'package:iaimei/widget/load_state_widget.dart';
import 'package:iaimei/widget/network_img_container.dart';
import 'package:iaimei/widget/space_widget.dart';

class ChatHomePage extends StatefulWidget {
  const ChatHomePage({Key? key}) : super(key: key);

  @override
  State<ChatHomePage> createState() => _ChatHomePageState();
}

class _ChatHomePageState extends AppBaseWidgetState<ChatHomePage>
    with PageLoadMixin {
  int chatIndex = 0;
  List<CategoryModel> filterCategoryList = [];
  List<ChatItemModel> recList = [];
  List<ChatItemModel> chatList = [];
  String age = "";
  String cup = "";
  bool _isFront = true;

  @override
  void initState() {
    super.initState();
    onLoadData();
  }

  @override
  onLoadData() {
    HttpHelper.getChatFilterData(age, cup, (data) {
      ChatIndexModel chatIndexModel = ChatIndexModel.fromJson(data);
      filterCategoryList = chatIndexModel.category ?? [];
      chatList = chatIndexModel.list ?? [];
      recList = chatIndexModel.recommend ?? [];
      setPageState(ListUtil.isNotEmpty(filterCategoryList));
    }, (error) {
      setPageErrorState(error);
    });
  }

  @override
  Widget buildPageLayout() {
    return handlePageStateView();
  }

  void selectTag(int index, int itemIndex) {
    if (filterCategoryList[index].name == "age") {
      age = filterCategoryList[index].items![itemIndex].value!;
    } else {
      cup = filterCategoryList[index].items![itemIndex].value!;
    }
    setState(() {});
    onLoadData();
  }

  @override
  buildAppBar() {
    return AppPageTitleBar.getNormalAppBar(
        title: StringRes.str_nude_chat,
        rightWidget: Row(
          children: [
            AppImgWidget(
                width: DimenRes.dimen_35,
                height: DimenRes.dimen_35,
                onTap: () {
                  context.push('/funding/${2}');
                },
                path: ImgRes.IC_REWARD),
            const SpaceWidget(
              hSpace: 10,
            ),
            AppImgWidget(
                width: DimenRes.dimen_35,
                height: DimenRes.dimen_35,
                onTap: () {
                  PageJumpUtil.forwardToChatRankPage(context);
                },
                path: ImgRes.IC_RANK),
            const SpaceWidget(
              hSpace: 5,
            )
          ],
        ));
  }

  void onStopAudio() {
    setState(() {
      _isFront = false;
    });
  }

  @override
  Widget successView() {
    return ListView(
      physics: const BouncingScrollPhysics(),
      children: [
        _buildFilterCategorySection(),
        const SpaceWidget(vSpace: 10),
        _buildChatListSection(),
        _buildRecommendSection(),
      ],
    );
  }

  _buildChatListSection() {
    return Visibility(
      visible: ListUtil.isNotEmpty(chatList),
      replacement: SizedBox(
        width: double.infinity,
        height: DimenRes.convert(380),
        child: Center(
            child:
                LoadSateWidget.noDataView(() {}, hint: StringRes.str_no_data)),
      ),
      child: SizedBox(
        width: double.infinity,
        height: DimenRes.convert(380),
        child: Swiper(
          itemCount: chatList.length,
          loop: chatList.length > 1,
          onIndexChanged: (int value) {
            setState(() {
              chatIndex = value;
            });
          },
          itemBuilder: (BuildContext context, int index) {
            return GestureDetector(
              onTap: () {
                onStopAudio();
                PageJumpUtil.forwardToChatDetailPage(
                    context, chatList[index].id!);
              },
              child: _buildChatItemSection(index),
            );
          },
          viewportFraction: 0.7,
          scale: 0.8,
        ),
      ),
    );
  }

  _buildRecommendSection() {
    return ListUtil.isNotEmpty(recList)
        ? Container(
            margin: EdgeInsets.only(
                top: DimenRes.dimen_10, bottom: DimenRes.dimen_30),
            child: Column(
              children: [
                TitleCell(
                  title: StringRes.str_beauty_recommend,
                  onTap: () {
                    onStopAudio();
                    PageJumpUtil.forwardToChatRecList(context);
                  },
                ),
                Padding(
                  padding: EdgeInsets.only(
                      left: DimenRes.dimen_16, top: DimenRes.dimen_15),
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: recList
                          .asMap()
                          .keys
                          .map((e) => ChatCard(
                                item: recList[e],
                                onTap: () {
                                  onStopAudio();
                                  PageJumpUtil.forwardToChatDetailPage(
                                      context, recList[e].id!);
                                },
                              ))
                          .toList(),
                    ),
                  ),
                )
              ],
            ),
          )
        : const SizedBox();
  }

  _buildFilterCategorySection() {
    return Padding(
      padding: EdgeInsets.symmetric(
          vertical: DimenRes.dimen_10, horizontal: DimenRes.dimen_16),
      child: Column(
          children: filterCategoryList
              .asMap()
              .keys
              .map((e) => ChatFilterTab(
                  filterTags: filterCategoryList[e],
                  onSelect: (index) {
                    selectTag(e, index);
                  }))
              .toList()),
    );
  }

  _buildChatItemSection(int index) {
    return ClipRRect(
        borderRadius: BorderRadius.circular(DimenRes.radius(12)),
        child: LayoutBuilder(
            builder: (BuildContext context, BoxConstraints constraints) {
          double tempWidth = constraints.maxWidth;
          double tempHeight = tempWidth * 4 / 3;
          return Container(
            height: tempHeight,
            width: double.infinity,
            color: Colors.white12,
            child: Stack(
              children: [
                Positioned.fill(
                    child: NetworkImgContainer(
                  url: chatList[index].thumbUrl ?? '',
                  noVisibilityDetector: true,
                  fit: BoxFit.cover,
                )),
                Positioned.fill(
                    child: Image.asset(
                  ImgRes.LAYER_GRADIENT_LARGE,
                  fit: BoxFit.cover,
                )),
                Positioned.fill(
                    child: Padding(
                  padding: EdgeInsets.symmetric(
                      horizontal: DimenRes.dimen_15,
                      vertical: DimenRes.dimen_12),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(chatList[index].title ?? '',
                          style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w600,
                              fontStyle: FontStyle.normal,
                              fontSize: DimenRes.sp(16))),
                      const SpaceWidget(
                        vSpace: 5,
                      ),
                      Text(chatList[index].desc ?? '',
                          style: TextStyle(
                              color: const Color(0xd6ffffff),
                              fontWeight: FontWeight.w400,
                              fontStyle: FontStyle.normal,
                              fontSize: DimenRes.sp(10))),
                      Offstage(
                          offstage: chatList[index].m3u8Full!.isEmpty,
                          child: StringUtil.isNotEmpty(chatList[index].m3u8Full)
                              ? AudioPlayerWidget(
                                  url: chatList[index].m3u8Full,
                                  curIndex: chatIndex,
                                  isFront: _isFront,
                                )
                              : const SizedBox())
                    ],
                  ),
                )),
              ],
            ),
          );
        }));
  }
}

class ChatCard extends StatelessWidget {
  const ChatCard({
    Key? key,
    required this.onTap,
    required this.item,
  }) : super(key: key);
  final GestureTapCallback onTap;
  final ChatItemModel item;

  @override
  Widget build(BuildContext context) {
    double itemWidth = DimenRes.dimen_88;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: EdgeInsets.only(
          right: DimenRes.dimen_15,
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(DimenRes.radius(12)),
          child: SizedBox(
            width: itemWidth,
            height: itemWidth * 4 / 3,
            child: Stack(
              children: [
                Positioned.fill(
                    child: NetworkImgContainer(
                  url: item.thumbUrl ?? '',
                  noVisibilityDetector: true,
                  fit: BoxFit.cover,
                )),
                Positioned.fill(
                    child: Image.asset(
                  ImgRes.LAYER_GRADIENT_SMALL,
                  fit: BoxFit.cover,
                )),
                Positioned(
                    left: 0,
                    right: 0,
                    bottom: 0,
                    child: Container(
                      padding: EdgeInsets.only(
                        left: DimenRes.dimen_5,
                        right: DimenRes.dimen_5,
                        bottom: DimenRes.dimen_5,
                      ),
                      child: Text(
                        item.title ?? '',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w500,
                            fontSize: DimenRes.sp(12)),
                      ),
                    ))
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class ChatFilterTab extends StatelessWidget {
  final CategoryModel filterTags;
  final Function onSelect;

  const ChatFilterTab({
    Key? key,
    required this.filterTags,
    required this.onSelect,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      alignment: Alignment.centerLeft,
      padding: EdgeInsets.only(left: DimenRes.dimen_5, right: DimenRes.dimen_5),
      margin: EdgeInsets.only(bottom: DimenRes.dimen_8),
      height: DimenRes.convert(36),
      decoration: BoxDecoration(
          color: const Color.fromRGBO(0, 0, 0, 0.24),
          borderRadius: BorderRadius.circular(DimenRes.radius(18))),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        child: FilterTabsItem(
          tabs: filterTags.items ?? [],
          onTabSelect: (item) {
            onSelect(item);
          },
        ),
      ),
    );
  }
}

class FilterTabsItem extends StatefulWidget {
  final List<CategoryItemModel> tabs;
  final Function onTabSelect;

  const FilterTabsItem(
      {Key? key, required this.tabs, required this.onTabSelect})
      : super(key: key);

  @override
  _FilterTabsItemState createState() => _FilterTabsItemState();
}

class _FilterTabsItemState extends State<FilterTabsItem> {
  int curIndex = 0;

  onTapTabsItem(int idx) {
    setState(() {
      curIndex = idx;
    });
    widget.onTabSelect(idx);
  }

  @override
  Widget build(BuildContext context) {
    return Row(
        children: widget.tabs
            .asMap()
            .keys
            .map((e) => TabsItem(
                  title: widget.tabs[e].label ?? '',
                  curIndex: curIndex,
                  keyIndex: e,
                  onTap: () {
                    onTapTabsItem(e);
                  },
                ))
            .toList());
  }
}

class TabsItem extends StatelessWidget {
  final String title;
  final int curIndex;
  final int keyIndex;
  final GestureTapCallback onTap;

  const TabsItem(
      {Key? key,
      required this.title,
      this.curIndex = 0,
      required this.onTap,
      required this.keyIndex})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: DimenRes.convert(70),
        height: DimenRes.dimen_28,
        color: Colors.transparent,
        alignment: Alignment.center,
        child: Stack(
          alignment: Alignment.center,
          children: [
            AnimatedOpacity(
              duration: const Duration(milliseconds: 300),
              opacity: curIndex == keyIndex ? 1.0 : 0,
              child: Container(
                alignment: Alignment.center,
                child: Image.asset(
                  ImgRes.BTN_GRADIENT_S,
                  width: DimenRes.convert(66),
                  height: DimenRes.dimen_28,
                  fit: BoxFit.contain,
                ),
              ),
            ),
            Text(title,
                textAlign: TextAlign.center,
                style: curIndex == keyIndex
                    ? TextStyle(
                        color: Colors.white,
                        fontSize: DimenRes.sp(12),
                        fontWeight: FontWeight.w700)
                    : TextStyle(
                        color: Colors.white.withOpacity(0.64),
                        fontSize: DimenRes.sp(12))),
          ],
        ),
      ),
    );
  }
}
