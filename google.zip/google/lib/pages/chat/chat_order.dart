import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:iaimei/components/common/commonelements.dart';
import 'package:iaimei/components/common/glassmorphism.dart';
import 'package:iaimei/components/common/stackpage.dart';
import 'package:iaimei/model/model_dating_order.dart';
import 'package:iaimei/router/routers.dart';
import 'package:iaimei/utils/api.dart';
import 'package:iaimei/utils/common.dart';
import 'package:iaimei/widget/convenient_mixin.dart';
import 'package:iaimei/widget/network_img_container.dart';

class ChatOrder extends StatefulWidget {
  const ChatOrder({Key? key, required this.id}) : super(key: key);
  final dynamic id;

  @override
  State<ChatOrder> createState() => _ChatOrderState();
}

class _ChatOrderState extends State<ChatOrder> with ConvenientMixin {
  // 定义状态
  bool loading = true;
  String orderId = '';
  List<Contact> contacts = [];
  List<Contact> toolList = [];

  /// 请求订单信息
  Future<void> getData() async {
    ModelDatingOrder? res = await apiChatOrder(id: widget.id);
    if (res?.status == 1) {
      orderId = res?.data?.orderSn ?? '';
      contacts = res?.data?.contact ?? [];
      toolList = res?.data?.download ?? [];
    }
  }

  /// 初始化请求
  Future<void> initData() async {
    await getData();
    setState(() {
      loading = false;
    });
  }

  @override
  void initState() {
    super.initState();
    initData();
    feedbackBlock = () => context.push('/${Routes.onlineService}');
  }

  @override
  Widget build(BuildContext context) {
    return StackPage(
      header: const CustomHeader(title: "裸聊"),
      child: loading
          ? loadingWiget()
          : (orderId.isEmpty ? noDataWidget() : singleChildScrollView()),
    );
  }

  /// 竖版滚动
  Widget singleChildScrollView() {
    return SingleChildScrollView(
      child: Column(
        children: [
          SizedBox(height: 10.w),
          _buildOrderWidget(),
          _buildTitleWidget(contacts.isEmpty ? '' : '联络方式'),
          _buildContactsWidget(),
          Offstage(
            offstage: contacts.isEmpty,
            child: Container(
              padding: EdgeInsets.fromLTRB(16.w, 10.w, 16.w, 10.w),
              child: Text(
                '添加官方商务的TG并发送您的订单号，官方商务即会为您开启裸聊房间。',
                style: TextStyle(color: color_84, fontSize: 12.sp),
              ),
            ),
          ),
          _buildTitleWidget(toolList.isEmpty ? '' : '联络工具下载地址'),
          _buildChatToolWidget(),
          Offstage(
            offstage: toolList.isEmpty,
            child: Container(
              padding: EdgeInsets.fromLTRB(16.w, 10.w, 16.w, 10.w),
              child: Text(
                '国内下载使用Telegram需要使用VPN，请先下载免费的蚂蚁VPN，开启VPN后再下载Telegram。',
                style: TextStyle(color: color_84, fontSize: 12.sp),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildOrderWidget() {
    return Offstage(
      offstage: orderId.isEmpty,
      child: buildContainerWidget(
        width: 343.w,
        height: 44.w,
        padding: EdgeInsets.symmetric(horizontal: 15.w),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              '订单号：$orderId',
              style: TextStyle(color: wColor, fontSize: 14.sp),
            ),
            GestureDetector(
              onTap: () {
                Clipboard.setData(ClipboardData(text: orderId));
                Method.showText('复制成功,快去分享吧');
              },
              child: Text(
                "复制",
                style: TextStyle(
                    color: rColor, fontSize: 14.sp, fontWeight: fontM),
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget _buildTitleWidget(String text) {
    return Offstage(
      offstage: text.isEmpty,
      child: Padding(
        padding: EdgeInsets.fromLTRB(16.w, 20.w, 0, 9.w),
        child: Align(
          alignment: Alignment.centerLeft,
          child: Text(
            text,
            style: TextStyle(color: wColor, fontSize: 18.sp, fontWeight: fontM),
          ),
        ),
      ),
    );
  }

  Widget _buildContactsWidget() {
    Widget itemWidget(Contact item) {
      return buildContainerWidget(
        width: 343.w,
        height: 66.w,
        padding: EdgeInsets.symmetric(horizontal: 15.w),
        child: GestureDetector(
          behavior: HitTestBehavior.translucent,
          onTap: () => context.push('/onlineService'),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(
                width: 36.w,
                height: 36.w,
                child: NetworkImgContainer(url: item.iconFull ?? ''),
              ),
              SizedBox(width: 10.w),
              Expanded(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      item.title ?? '',
                      style: TextStyle(
                          color: wColor, fontSize: 14.sp, fontWeight: fontM),
                      maxLines: 1,
                    ),
                    Padding(
                      padding: EdgeInsets.only(top: 5.0.w),
                      child: Text(
                        item.text ?? '',
                        style: TextStyle(color: color_84, fontSize: 11.sp),
                        maxLines: 1,
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(width: 10.w),
              RedGlassmorphoismBox(
                width: 66.w,
                height: 28.w,
                child: Text(
                  "立即联络",
                  style: TextStyle(
                      color: wColor, fontSize: 12.sp, fontWeight: fontM),
                ),
              ),
            ],
          ),
        ),
      );
    }

    return Column(children: contacts.map((item) => itemWidget(item)).toList());
  }

  Widget _buildChatToolWidget() {
    Widget itemWidget(Contact item) {
      return SizedBox(
        height: 66,
        child: GestureDetector(
          onTap: () => Method.launchURL(item.url ?? ''),
          child: Row(
            children: [
              SizedBox(width: 16.w),
              SizedBox(
                width: 36.w,
                height: 36.w,
                child: NetworkImgContainer(url: item.iconFull ?? ''),
              ),
              SizedBox(width: 10.w),
              Expanded(
                child: Text(
                  item.title.toString(),
                  style: TextStyle(
                      color: wColor, fontSize: 14.sp, fontWeight: fontM),
                ),
              ),
              RedGlassmorphoismBox(
                width: 66.w,
                height: 28.w,
                child: Text(
                  "立即下载",
                  style: TextStyle(
                      color: wColor, fontSize: 12.sp, fontWeight: fontM),
                ),
              ),
              SizedBox(width: 16.w),
            ],
          ),
        ),
      );
    }

    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.all(Radius.circular(12.0.w)),
        color: const Color.fromRGBO(188, 136, 255, 0.12),
      ),
      margin: EdgeInsets.symmetric(horizontal: 16.w),
      child: Column(
        children: toolList
            .asMap()
            .keys
            .map((index) => Column(children: [
                  itemWidget(toolList[index]),
                  Container(
                    height: 1.w,
                    width: 282.w,
                    color: toolList.length - 1 != index
                        ? Colors.white12
                        : Colors.transparent,
                    margin: EdgeInsets.only(left: 61.w),
                  ),
                ]))
            .toList(),
      ),
    );
  }
}
