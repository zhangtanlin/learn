import 'package:dio/dio.dart';

Dio _downloadDio = Dio(BaseOptions(
  connectTimeout: 60 * 1000,
  receiveTimeout: 300 * 1000,
));

class DownloadUtil {
  static Future<Response> download(String urlPath, String savePath,
      {ProgressCallback? onReceiveProgress}) {
      return _downloadDio.download(urlPath, savePath,
          onReceiveProgress: onReceiveProgress);
  }
}
