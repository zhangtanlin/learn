import 'dart:convert';

import 'package:bot_toast/bot_toast.dart';
import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:go_router/go_router.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:http_parser/http_parser.dart';
import 'package:iaimei/global.dart';
import 'package:iaimei/utils/common.dart';
import 'package:iaimei/utils/crypto.dart';
import 'package:iaimei/utils/log_util.dart';
import 'package:iaimei/widget/toast_widget.dart';
import 'package:universal_html/html.dart' as html;

// 是否因token失效跳转到登录页
bool isJump = false;
Dio _imageDio = Dio(BaseOptions(
  connectTimeout: 10 * 1000,
  receiveTimeout: 60 * 1000,
  responseType: ResponseType.bytes,
  validateStatus: (status) {
    return status! < 500;
  },
));

getToken() {
  Box? box = AppGlobal.appBox;
  return box?.get('gg_token');
}

Dio _uploadDio = Dio(BaseOptions(
  connectTimeout: 60 * 1000,
  receiveTimeout: 300 * 1000,
));

Dio _apiDio = Dio(BaseOptions(
    connectTimeout: 60 * 1000,
    receiveTimeout: 300 * 1000,
    validateStatus: (status) {
      return status! < 500;
    },
    contentType: Headers.formUrlEncodedContentType))
  ..interceptors.add(InterceptorsWrapper(onRequest: (options, handler) async {
    Map _data = {};
    dynamic yytoken = getToken();
    if (yytoken != null) {
      AppGlobal.apiToken = yytoken;
    }
    _data.addAll(AppGlobal.appinfo);
    _data.addAll({'token': AppGlobal.apiToken});
    if (options.data != null) {
      _data.addAll(options.data);
    }
    LogUtil.i("[ 加密前 param ] = [ ${_data.toString()} ]");
    options.data = await PlatformAwareCrypto.encryptReqParams(
      jsonEncode(_data),
    );

    return handler.next(options);
  }, onResponse: (response, handler) async {
    //不要删，测试用
    LogUtil.i("[ api ] = [ ${response.realUri.toString()} ]");
    LogUtil.i("[ statusCode ] = [ ${response.statusCode} ]");
    LogUtil.i("[ statusMessage ] = [ ${response.statusMessage} ]");
    if (response.data != null && response.data['data'] != null) {
      String _data = await PlatformAwareCrypto.decryptResData(
        response.data,
      );
      response.data = jsonDecode(_data);
    }
    if (response.data["msg"] == "token无效" && !isJump && AppGlobal.apInit) {
      Method.showText("token失效,请重新登录");
      isJump = true;
      AppGlobal.apiToken = '';
      Box? box = AppGlobal.appBox;
      box?.delete('gg_token');
      if (AppGlobal.routerReplace) {
        AppGlobal.appContext?.pop();
      }
      // 需要登录逻辑
      // AppGlobal.appContext.go('/${Routes.login}', extra: {'is_expired': true});
      Future.delayed(const Duration(seconds: 3), () {
        isJump = false;
      });
    }
    return handler.next(response);
  }, onError: (DioError e, handler) {
    LogUtil.i("[ e ] = [ ${e.toString()} ]");
    return handler.next(e);
  }));

class PlatformAwareHttp {
  static Future getImage(url) {
    if (url.contains('http')) {
      return kIsWeb
          ? html.HttpRequest.request(
              url,
              responseType: 'arraybuffer',
            ).then((xhr) {
              if (xhr.response != null) {
                return base64Encode(
                  xhr.response.asUint8List(),
                );
              }
              return '';
            }).onError((error, stackTrace) => '')
          : _imageDio
              .get(url)
              .then((res) => base64Encode(res.data))
              .onError((error, stackTrace) => '');
    } else {
      return url;
    }
  }

  static Future uploadImage(
      {dynamic imageUrl,
      String id = '',
      String position = 'head',
      ProgressCallback? progressCallback}) async {
    try {
      var idValue = '${DateTime.now().millisecondsSinceEpoch}';
      var imgKey = AppGlobal.uploadImgKey.replaceFirst('head', '');
      var newKey = 'id=$id&position=$position$imgKey';
      var tmpSha256 = Method.convertSha256(newKey);
      var sign = Method.convertMD5(tmpSha256);
      var imgUrlSplit = kIsWeb ? '' : imageUrl.split(".");
      var imageType = kIsWeb ? '' : imgUrlSplit.last;
      if (!kIsWeb && imgUrlSplit.length <= 1) {
        imageType = 'png';
      }
      var imageName = Method.convertMD5(id);
      FormData formData = FormData.fromMap({
        'id': id.isNotEmpty ? id : idValue,
        'position': position,
        'sign': sign,
        'cover': kIsWeb
            ? imageUrl
            : await MultipartFile.fromFile(
                imageUrl,
                filename: '$imageName.$imageType',
                contentType: MediaType.parse('image/$imageType'),
              ),
      });
      Response response = await _uploadDio.post(
        AppGlobal.uploadImgUrl,
        data: formData,
        onSendProgress: progressCallback,
        options: Options(contentType: 'multipart/form-data'),
      );
      return response;
    } catch (e) {
      return null;
    }

//     if (response.statusCode >= 200 && response.statusCode < 300) {
//       var responseData = response.data;
//       if (responseData == null || responseData == "") return {};
//       // // debugPrint('response data: ${response.data}');
//       var encryptData = jsonDecode(responseData);
//       if ('${encryptData['code']}' == '1') {
//         return encryptData;
//       }
// //    // debugPrint('---------------------------------------------');
//       var strDecryptData =
//           await FlutterEncryptPlugin.getDecryptData(encryptData);
// //      // debugPrint('uploadImage data: $strDecryptData');
//       var decryptData = jsonDecode(strDecryptData);
//       return decryptData;
//     }
  }

  static Future uploadVideo({
    /*String uuid,*/
    dynamic videoUrl,
    ProgressCallback? progressCallback,
  }) async {
    try {
      String timestamp = '${DateTime.now().millisecondsSinceEpoch}';
      String videoKey = AppGlobal.uploadVideoKey.replaceFirst('head', '');
      String newKey = '$timestamp$videoKey';
      String sign = Method.convertMD5(newKey); // Utils.gvMD5(newKey);
      var videoUrlSplit = kIsWeb ? '' : videoUrl.split(".");
      var videoType = kIsWeb ? '' : videoUrlSplit.last;
      if (videoUrlSplit.length <= 1) {
        videoType = 'mp4';
      }
      // Utils.gvMD5(timestamp);
      String videoName = Method.convertMD5(timestamp);
      FormData formData = FormData.fromMap({
        'uuid': 'chaguaner',
        'timestamp': timestamp,
        'sign': sign,
        'video': kIsWeb
            ? videoUrl
            : await MultipartFile.fromFile(
                videoUrl,
                filename: '$videoName.$videoType',
                // contentType: MediaType.parse('video/$videoType'),
                contentType: MediaType.parse('video/mp4'),
              ),
      });
      var token = null;
      token = CancelToken();
      Response response = await _uploadDio.post(
        AppGlobal.uploadVideoUrl,
        cancelToken: token,
        data: formData,
        onSendProgress: progressCallback,
        options: Options(contentType: 'multipart/form-data'),
      );
      return response;
    } catch (e) {
      debugPrint(e.toString());
      BotToast.showText(text: e.toString());
      return null;
    }
  }

  static Future<Response> download(
    String urlPath,
    String savePath, {
    required ProgressCallback onReceiveProgress,
  }) {
//    if(_dio == null) return;
    return _uploadDio.download(urlPath, savePath,
        onReceiveProgress: onReceiveProgress);
  }

  // cancelToken 用于二级页面销毁时，中断正在进行中的异步请求
  static Future post(
    String path, {
    dynamic data,
    CancelToken? cancelToken,
  }) {
    return _apiDio.post(AppGlobal.apiBaseURL + path,
        data: data, cancelToken: cancelToken);
  }

  static Future simplePost(
    String url, {
    dynamic data,
    CancelToken? cancelToken,
  }) {
    return _apiDio.post(url, data: data, cancelToken: cancelToken);
  }

  static Future get(
    String path, {
    Map<String, dynamic>? params,
    CancelToken? cancelToken,
  }) {
    return _apiDio.get(AppGlobal.apiBaseURL + path,
        queryParameters: params, cancelToken: cancelToken);
  }
}
