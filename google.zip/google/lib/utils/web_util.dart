import 'package:flutter/material.dart';
import 'package:iaimei/widget/toast_widget.dart';
import 'package:url_launcher/url_launcher.dart';

class WebUtil {
  static void browserLaunchURL(String url) async {
    try {
      // await launch(url, forceSafariVC: false);
      await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    } catch (e) {
      ToastWidget.showToast("加载失败，请检查网址后重试");
    }
  }

  static void inAppWebView(String url) async {
    try {
      await launchUrl(Uri.parse(url), mode: LaunchMode.inAppWebView);
    } catch (e) {
      debugPrint(e.toString());
      ToastWidget.showToast("加载失败，请检查网址后重试");
    }
  }
}
