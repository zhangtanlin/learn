import 'package:flutter/material.dart';
import 'package:iaimei/model/unlock_info_model.dart';
import 'package:iaimei/net/http_helper.dart';
import 'package:iaimei/res/string_res.dart';
import 'package:iaimei/utils/dialog_util.dart';
import 'package:iaimei/utils/string_util.dart';
import 'package:iaimei/widget/toast_widget.dart';

import 'loading_util.dart';

typedef BuyVipCallback = Function(UnlockInfoModel unlockInfo);
typedef PayCallback = Function(UnlockInfoModel unlockInfo);

class UnlockCheckUtil {
  static void comicsCheck(
    BuildContext context,
    String comicsId,
    UnlockInfoModel? unlockInfo, {
    VoidCallback? freeFunc,
    VoidCallback? buyVipFunc,
    VoidCallback? payFunc,
    VoidCallback? paySuccess,
    VoidCallback? payFail,
    VoidCallback? payCancel,
  }) {
    check(unlockInfo, freeCallback: freeFunc, buyVipCallback: (unlockInfo) {
      if (buyVipFunc != null) {
        buyVipFunc.call();
      }
      DialogUtil.showBuyVipDialog(cxt: context);
    }, payCallback: (unlockInfo) {
      if (payFunc != null) {
        payFunc.call();
      }
      DialogUtil.showPayDialog(
          cxt: context,
          unlockInfo: unlockInfo,
          balancePayCallback: (unlockInfo, type) {
            _comicsUnlockAction(context, comicsId, type,
                paySuccessFunc: paySuccess, payFailFunc: payFail);
          },
          coinPayCallback: (unlockInfo, type) {
            _comicsUnlockAction(context, comicsId, type,
                paySuccessFunc: paySuccess, payFailFunc: payFail);
          },
          timesPayCallback: (unlockInfo, type) {
            _comicsUnlockAction(context, comicsId, type,
                paySuccessFunc: paySuccess, payFailFunc: payFail);
          },
          payCancel: () {
            if (payCancel != null) {
              payCancel.call();
            }
          });
    });
  }

  static void _comicsUnlockAction(
    BuildContext context,
    String comicsId,
    String type, {
    VoidCallback? paySuccessFunc,
    VoidCallback? payFailFunc,
  }) {
    LoadingUtil.showLoading();
    HttpHelper.comicsUnlock(comicsId, type, (data) {
      LoadingUtil.closeLoading();
      ToastWidget.showToast(
          StringUtil.isNotEmpty(data) ? '$data' : StringRes.str_unlock_success);
      if (paySuccessFunc != null) {
        paySuccessFunc.call();
      }
    }, (error) {
      LoadingUtil.closeLoading();
      ToastWidget.showToast(error.message ?? StringRes.str_unlock_fail);
      if (payFailFunc != null) {
        payFailFunc.call();
      }
    });
  }

  static void novelCheck(
      BuildContext context, String novelId, UnlockInfoModel? unlockInfo,
      {VoidCallback? freeFunc,
      VoidCallback? buyVipFunc,
      VoidCallback? payFunc,
      VoidCallback? paySuccessFunc,
      VoidCallback? payFailFunc,
      VoidCallback? payCancel}) {
    check(unlockInfo, freeCallback: freeFunc, buyVipCallback: (unlockInfo) {
      if (buyVipFunc != null) {
        buyVipFunc.call();
      }
      DialogUtil.showBuyVipDialog(cxt: context);
    }, payCallback: (unlockInfo) {
      if (payFunc != null) {
        payFunc.call();
      }
      DialogUtil.showPayDialog(
          cxt: context,
          unlockInfo: unlockInfo,
          balancePayCallback: (unlockInfo, type) {
            _novelUnlockAction(novelId, type,
                paySuccessFunc: paySuccessFunc, payFailFunc: payFailFunc);
          },
          coinPayCallback: (unlockInfo, type) {
            _novelUnlockAction(novelId, type,
                paySuccessFunc: paySuccessFunc, payFailFunc: payFailFunc);
          },
          timesPayCallback: (unlockInfo, type) {
            _novelUnlockAction(novelId, type,
                paySuccessFunc: paySuccessFunc, payFailFunc: payFailFunc);
          },
          payCancel: () {
            if (payCancel != null) {
              payCancel.call();
            }
          });
    });
  }

  static void videoCheck(
      BuildContext context, String videoId, UnlockInfoModel? unlockInfo,
      {VoidCallback? freeFunc,
      VoidCallback? buyVipFunc,
      VoidCallback? payFunc,
      Function? paySuccessFunc,
      Function? payFailFunc,
      VoidCallback? payCancel}) {
    check(unlockInfo, freeCallback: freeFunc, buyVipCallback: (unlockInfo) {
      if (buyVipFunc != null) {
        buyVipFunc.call();
      }
      DialogUtil.showBuyVipDialog(cxt: context);
    }, payCallback: (unlockInfo) {
      if (payFunc != null) {
        payFunc.call();
      }
      DialogUtil.showPayDialog(
          cxt: context,
          unlockInfo: unlockInfo,
          balancePayCallback: (unlockInfo, type) {
            _videoUnlockAction(videoId, type,
                paySuccessFunc: paySuccessFunc, payFailFunc: payFailFunc);
          },
          coinPayCallback: (unlockInfo, type) {
            _videoUnlockAction(videoId, type,
                paySuccessFunc: paySuccessFunc, payFailFunc: payFailFunc);
          },
          timesPayCallback: (unlockInfo, type) {
            _videoUnlockAction(videoId, type,
                paySuccessFunc: paySuccessFunc, payFailFunc: payFailFunc);
          },
          payCancel: () {
            if (payCancel != null) {
              payCancel.call();
            }
          });
    });
  }

  static void datingCheck(
      BuildContext context, String datingId, UnlockInfoModel? unlockInfo,
      {VoidCallback? freeFunc,
      VoidCallback? buyVipFunc,
      VoidCallback? payFunc,
      String? title,
      Function? paySuccessFunc,
      Function? payFailFunc,
      VoidCallback? payCancel}) {
    check(unlockInfo, freeCallback: freeFunc, buyVipCallback: (unlockInfo) {
      if (buyVipFunc != null) {
        buyVipFunc.call();
      }
      DialogUtil.showBuyVipDialog(cxt: context);
    }, payCallback: (unlockInfo) {
      if (payFunc != null) {
        payFunc.call();
      }
      DialogUtil.showPayDialog(
          cxt: context,
          unlockInfo: unlockInfo,
          titleStr: title,
          balancePayCallback: (unlockInfo, type) {
            _datingUnlockAction(datingId, type,
                paySuccessFunc: paySuccessFunc, payFailFunc: payFailFunc);
          },
          coinPayCallback: (unlockInfo, type) {
            _datingUnlockAction(datingId, type,
                paySuccessFunc: paySuccessFunc, payFailFunc: payFailFunc);
          },
          timesPayCallback: (unlockInfo, type) {
            _datingUnlockAction(datingId, type,
                paySuccessFunc: paySuccessFunc, payFailFunc: payFailFunc);
          },
          payCancel: () {
            if (payCancel != null) {
              payCancel.call();
            }
          });
    });
  }

  static void _datingUnlockAction(
    String datingId,
    String type, {
    Function? paySuccessFunc,
    Function? payFailFunc,
  }) {
    LoadingUtil.showLoading();
    HttpHelper.datingUnlock(datingId, type, (data) {
      LoadingUtil.closeLoading();
      ToastWidget.showToast(StringRes.str_unlock_success);
      if (paySuccessFunc != null) {
        paySuccessFunc.call(data);
      }
    }, (error) {
      LoadingUtil.closeLoading();
      ToastWidget.showToast(error.message ?? StringRes.str_unlock_fail);
      if (payFailFunc != null) {
        payFailFunc.call();
      }
    });
  }

  static void atlasCheck(
      BuildContext context, String atlasId, UnlockInfoModel? unlockInfo,
      {VoidCallback? freeFunc,
      VoidCallback? buyVipFunc,
      VoidCallback? payFunc,
      Function? paySuccessFunc,
      Function? payFailFunc,
      VoidCallback? payCancel}) {
    check(unlockInfo, freeCallback: freeFunc, buyVipCallback: (unlockInfo) {
      if (buyVipFunc != null) {
        buyVipFunc.call();
      }
      DialogUtil.showBuyVipDialog(cxt: context);
    }, payCallback: (unlockInfo) {
      if (payFunc != null) {
        payFunc.call();
      }
      DialogUtil.showPayDialog(
          cxt: context,
          unlockInfo: unlockInfo,
          balancePayCallback: (unlockInfo, type) {
            _atlasUnlockAction(atlasId, type,
                paySuccessFunc: paySuccessFunc, payFailFunc: payFailFunc);
          },
          coinPayCallback: (unlockInfo, type) {
            _atlasUnlockAction(atlasId, type,
                paySuccessFunc: paySuccessFunc, payFailFunc: payFailFunc);
          },
          timesPayCallback: (unlockInfo, type) {
            _atlasUnlockAction(atlasId, type,
                paySuccessFunc: paySuccessFunc, payFailFunc: payFailFunc);
          },
          payCancel: () {
            if (payCancel != null) {
              payCancel.call();
            }
          });
    });
  }

  static void _atlasUnlockAction(
    String atlasId,
    String type, {
    Function? paySuccessFunc,
    Function? payFailFunc,
  }) {
    LoadingUtil.showLoading();
    HttpHelper.atlasUnlock(atlasId, type, (data) {
      LoadingUtil.closeLoading();
      ToastWidget.showToast(StringRes.str_unlock_success);
      if (paySuccessFunc != null) {
        paySuccessFunc.call(data);
      }
    }, (error) {
      LoadingUtil.closeLoading();
      ToastWidget.showToast(error.message ?? StringRes.str_unlock_fail);
      if (payFailFunc != null) {
        payFailFunc.call();
      }
    });
  }

  static void _videoUnlockAction(
    String videoId,
    String type, {
    Function? paySuccessFunc,
    Function? payFailFunc,
  }) {
    LoadingUtil.showLoading();
    HttpHelper.videoUnlock(videoId, type, (data) {
      LoadingUtil.closeLoading();
      ToastWidget.showToast(StringRes.str_unlock_success);
      if (paySuccessFunc != null) {
        paySuccessFunc.call(data);
      }
    }, (error) {
      LoadingUtil.closeLoading();
      ToastWidget.showToast(error.message ?? StringRes.str_unlock_fail);
      if (payFailFunc != null) {
        payFailFunc.call();
      }
    });
  }

  static void _novelUnlockAction(
    String novelId,
    String type, {
    VoidCallback? paySuccessFunc,
    VoidCallback? payFailFunc,
  }) {
    LoadingUtil.showLoading();
    HttpHelper.novelUnlock(novelId, type, (data) {
      LoadingUtil.closeLoading();
      ToastWidget.showToast(
          StringUtil.isNotEmpty(data) ? '$data' : StringRes.str_unlock_success);
      if (paySuccessFunc != null) {
        paySuccessFunc.call();
      }
    }, (error) {
      LoadingUtil.closeLoading();
      ToastWidget.showToast(error.message ?? StringRes.str_unlock_fail);
      if (payFailFunc != null) {
        payFailFunc.call();
      }
    });
  }

  static void check(UnlockInfoModel? unlockInfo,
      {VoidCallback? freeCallback,
      BuyVipCallback? buyVipCallback,
      PayCallback? payCallback}) {
    if (unlockInfo != null) {
      int type = unlockInfo.free ?? 1;
      if (type == 0) {
        if (freeCallback != null) {
          freeCallback.call();
        }
      } else if (type == 1) {
        if (buyVipCallback != null) {
          buyVipCallback.call(unlockInfo);
        }
      } else if (type == 2) {
        if (payCallback != null) {
          payCallback.call(unlockInfo);
        }
      }
    }
  }
}
