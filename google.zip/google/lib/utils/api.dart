//获取全局config接口
import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:iaimei/model/atlasmodel.dart';
import 'package:iaimei/model/basic.dart';
import 'package:iaimei/model/chat_model.dart';
import 'package:iaimei/model/fictionmodel.dart';
import 'package:iaimei/model/user_info_model.dart';
import 'package:iaimei/model/modelDatingCollect.dart';
import 'package:iaimei/model/model_app.dart';
import 'package:iaimei/model/model_carton_list.dart';
import 'package:iaimei/model/model_club_list.dart';
import 'package:iaimei/model/model_collect_buy_dating.dart';
import 'package:iaimei/model/model_collect_buy_novel.dart';
import 'package:iaimei/model/model_collect_buy_pictures.dart';
import 'package:iaimei/model/model_contact.dart';
import 'package:iaimei/model/model_dating_detail.dart';
import 'package:iaimei/model/model_dating_order.dart';
import 'package:iaimei/model/model_fans_list.dart';
import 'package:iaimei/model/model_favorites_video_list.dart';
import 'package:iaimei/model/model_girl_detail_verify.dart';
import 'package:iaimei/model/model_collect_buy_chat.dart';
import 'package:iaimei/model/model_online_list.dart';
import 'package:iaimei/model/modle_msg_list.dart';
import 'package:iaimei/model/rinking_model.dart';
import 'package:iaimei/model/userhome_model.dart';
import 'package:iaimei/model/video_model.dart';
import 'package:iaimei/store/userdata.dart';
import 'package:iaimei/utils/http.dart';
import 'package:iaimei/utils/log_util.dart';
import 'package:iaimei/utils/printLog.dart';
import 'package:provider/provider.dart';

Future<Basic?> getIndexList() async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post('/api/menu/index');
    LogUtil.i(jsonEncode(res.data));
    Basic result = Basic.fromJson(res.data);
    return result;
  } catch (e) {
    debugPrint(e.toString());
    return null;
  }
}

Future<Basic?> commonInterface({String url = '', int? id, int page = 1}) async {
  try {
    Response<dynamic> res =
        await PlatformAwareHttp.post(url, data: {'id': id, 'page': page});
    LogUtil.i(jsonEncode(res.data));
    Basic result = Basic.fromJson(res.data);
    return result;
  } catch (e) {
    debugPrint(e.toString());
    return null;
  }
}

/// 公用接口连接器（地址+param）
Future<Basic?> interfaceConnector({String url = '', dynamic param}) async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post(url, data: param);
    LogUtil.i(jsonEncode(res.data));
    Basic result = Basic.fromJson(res.data);
    return result;
  } catch (e) {
    debugPrint(e.toString());
    return null;
  }
}

/// 约炮详情
Future<ModelDatingDetail?> apiDatingDetail({String? id, String? uid}) async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post(
      '/api/girl/detail_meet',
      data: {'info_id': id ?? '', 'uid': uid ?? ''},
    );
    PrintUtil.d("约炮详情:${res.toString()}");
    PrintUtil.d("约炮详情id:${id.toString()}");
    ModelDatingDetail result = ModelDatingDetail.fromJson(res.data);
    return result;
  } catch (e) {
    return null;
  }
}

/// 约炮解锁
// Future<Basic?> apiDatingUnlock({
//   int? id,
//   String? type,
// }) async {
//   try {
//     Response<dynamic> res = await PlatformAwareHttp.post(
//       '/api/girl/buy',
//       data: {'info_id': id, 'type': type},
//     );
//     Basic result = Basic.fromJson(res.data);
//     return result;
//   } catch (e) {
//     return null;
//   }
// }

Future<Basic?> apiSpecialUnlock({int? id}) async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post(
      '/api/mv/buy_special',
      data: {'id': id, 'type': 'balance'},
    );
    LogUtil.i(jsonEncode(res.data));
    Basic result = Basic.fromJson(res.data);
    return result;
  } catch (e) {
    debugPrint(e.toString());
    return null;
  }
}

/// 收藏/已收藏
Future<ModelDatingCollect?> apiDatingCollect({dynamic id}) async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post(
      '/api/girl/toggle_like',
      data: {'info_id': id},
    );
    ModelDatingCollect result = ModelDatingCollect.fromJson(res.data);
    return result;
  } catch (e) {
    return null;
  }
}

/// 裸聊收藏/已收藏
Future<ModelDatingCollect?> apiChatCollect({
  required int id,
}) async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post(
      '/api/chat/toggle_like',
      data: {'info_id': id},
    );
    ModelDatingCollect result = ModelDatingCollect.fromJson(res.data);
    return result;
  } catch (e) {
    return null;
  }
}

/// 创建评论
Future<Basic?> apiCreateComment({
  required int id,
  required String content,
}) async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post(
      '/api/girl/create_comment',
      data: {
        "info_id": id,
        "content": content,
      },
    );
    Basic result = Basic.fromJson(res.data);
    return result;
  } catch (e) {
    return null;
  }
}

/// 举报-约炮
Future<Basic?> apiCreateReport({
  String? id,
  String? type,
  dynamic images,
  String? content,
}) async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post(
      '/api/girl/create_report',
      data: {
        'info_id': id,
        'type': type,
        'images': images,
        'content': content,
      },
    );
    Basic result = Basic.fromJson(res.data);
    return result;
  } catch (e) {
    return null;
  }
}

// 图集
Future<PictureAtlas?> apiPictureMain({required int type}) async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post(
      '/api/picture/main',
      data: {
        'type': type,
      },
    );
    PictureAtlas result = PictureAtlas.fromJson(res.data);
    return result;
  } catch (e) {
    return null;
  }
}

// 小说
Future<FictionModel?> getFiction({required int type}) async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post(
      '/api/story/main',
      data: {
        'type': type,
      },
    );
    FictionModel result = FictionModel.fromJson(res.data);
    return result;
  } catch (e) {
    return null;
  }
}

// 个人信息
Future<UserInfoModel?> apiGetBaseInfo(BuildContext context) async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post(
      '/api/users/base_info',
    );
    LogUtil.i(jsonEncode(res.data));
    Basic basic = Basic.fromJson(res.data);
    if (basic.status == 1) {
      UserInfoModel result = UserInfoModel.fromJson(basic.data);
      Provider.of<UserData>(context, listen: false).setData(result);
      return result;
    } else {
      debugPrint(basic.msg);
      return null;
    }
  } catch (e) {
    debugPrint(e.toString());
    return null;
  }
}

/// 设置个人信息
Future<Basic?> apiSetBaseInfo({
  String? nickname,
  int? sex,
  String? birthday,
  String? thumb,
}) async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post(
      '/api/users/set_all',
      data: {
        "nickname": nickname,
        "sex": sex,
        "birthday": birthday,
        "thumb": thumb,
      },
    );
    Basic result = Basic.fromJson(res.data);
    return result;
  } catch (e) {
    return null;
  }
}

/// 设置暧昧号
/// [username]暧昧号
/// [password]密码
/// [confirmPassword]确认密码
Future<Basic?> apiSetUserInfo({
  String? username,
  String? password,
  String? confirmPassword,
}) async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post(
      '/api/users/set_user',
      data: {
        "username": username,
        "password": password,
        "confirm_password": confirmPassword,
      },
    );
    Basic result = Basic.fromJson(res.data);
    return result;
  } catch (e) {
    return null;
  }
}

// 约炮选项卡
// Future<ModelDatingTab?> apiGetGirlTab(BuildContext context) async {
//   try {
//     Response<dynamic> res = await PlatformAwareHttp.post(
//       '/api/girl/tab',
//     );
//     ModelDatingTab result = ModelDatingTab.fromJson(res.data);
//     return result;
//   } catch (e) {
//     return null;
//   }
// }

// 约炮筛选条件
// Future<ModelDatingFilter?> apiDatingFilter() async {
//   try {
//     Response<dynamic> res = await PlatformAwareHttp.post(
//       '/api/girl/filter',
//     );
//     ModelDatingFilter result = ModelDatingFilter.fromJson(res.data);
//     return result;
//   } catch (e) {
//     return null;
//   }
// }

// 视频排行导航
Future<RanKTabsModel?> apiRankTab() async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post(
      '/api/rank/tab',
    );
    LogUtil.i(jsonEncode(res.data));
    RanKTabsModel result = RanKTabsModel.fromJson(res.data);
    return result;
  } catch (e) {
    debugPrint(e.toString());
    return null;
  }
}

// 城市列表
// Future<ModelCityList?> apiCityList() async {
//   try {
//     Response<dynamic> res = await PlatformAwareHttp.post(
//       'api/girl/area',
//     );
//     ModelCityList result = ModelCityList.fromJson(res.data);
//     return result;
//   } catch (e) {
//     return null;
//   }
// }

// 裸聊入口 选项卡
Future<ChatIndex?> apiChatFilter({String age = "", String cup = ""}) async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post('/api/chat/tab',
        data: {"age": age, "cup": cup});
    LogUtil.i(jsonEncode(res.data));
    ChatIndex result = ChatIndex.fromJson(res.data);
    return result;
  } catch (e) {
    debugPrint(e.toString());
    return null;
  }
}

// 裸聊推荐
Future<ChatRecommend?> apiChatRecommend() async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post('/api/chat/recommend');
    LogUtil.i(jsonEncode(res.data));
    ChatRecommend result = ChatRecommend.fromJson(res.data);
    return result;
  } catch (e) {
    debugPrint(e.toString());
    return null;
  }
}

// 裸聊详情
Future<Basic?> apiChatDetail({dynamic id, dynamic uid}) async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post(
      '/api/chat/detail_chat',
      data: {"info_id": id, 'uid': uid},
    );
    LogUtil.i(jsonEncode(res.data));
    Basic result = Basic.fromJson(res.data);
    return result;
  } catch (e) {
    debugPrint(e.toString());
    return null;
  }
}

// 裸聊评论列表
Future<ChatListComment?> apiChatListComment({dynamic id, int? page}) async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post(
      '/api/chat/list_comment',
      data: {"info_id": id, "page": page},
    );
    LogUtil.i(jsonEncode(res.data));
    ChatListComment result = ChatListComment.fromJson(res.data);
    return result;
  } catch (e) {
    debugPrint(e.toString());
    return null;
  }
}

// 裸聊发布评论
Future<Basic?> apiChatCreateComment(dynamic id, String content) async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post(
      '/api/chat/create_comment',
      data: {"info_id": id, "content": content},
    );
    LogUtil.i(jsonEncode(res.data));
    Basic result = Basic.fromJson(res.data);
    return result;
  } catch (e) {
    debugPrint(e.toString());
    return null;
  }
}

/// 约炮联系方式获取
Future<ModelDatingOrder?> apiChatOrder({dynamic id}) async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post('/api/chat/contact',
        data: {"info_id": id});
    ModelDatingOrder result = ModelDatingOrder.fromJson(res.data);
    return result;
  } catch (e) {
    return null;
  }
}

// 裸聊/约炮评论列表
Future<ChatListComment?> apiChatGirlListComment({
  String? id,
  int? page,
  int? limit,
}) async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post(
      '/api/girl/list_comment',
      data: {
        "info_id": id,
        "page": page,
        "limit": limit,
      },
    );
    ChatListComment result = ChatListComment.fromJson(res.data);
    return result;
  } catch (e) {
    debugPrint(e.toString());
    return null;
  }
}

// 他人主页
Future<UserHomeModel?> apiUsersHomeInfo({
  required dynamic uid,
}) async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post('/api/users/home_info',
        data: {"uid": uid});
    LogUtil.i(jsonEncode(res.data));
    UserHomeModel result = UserHomeModel.fromJson(res.data);
    return result;
  } catch (e) {
    debugPrint(e.toString());
    return null;
  }
}

// 裸聊榜单
// Future<ChatRanKingModel?> apiChatRanKing({int type = 1}) async {
//   try {
//     Response<dynamic> res =
//         await PlatformAwareHttp.post('/api/chat/ranking', data: {"type": type});
//     LogUtil.i(jsonEncode(res.data));
//     ChatRanKingModel result = ChatRanKingModel.fromJson(res.data);
//     return result;
//   } catch (e) {
//     // debugPrint(e.toString());
//     return null;
//   }
// }

Future<Basic?> apiChatBuy({int infoId = 0, dynamic chatset = 0}) async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post('/api/chat/buy',
        data: {
          "info_id": infoId,
          "chatset": chatset,
          "type": "resource_coins"
        });
    LogUtil.i(jsonEncode(res.data));
    Basic result = Basic.fromJson(res.data);
    return result;
  } catch (e) {
    debugPrint(e.toString());
    return null;
  }
}

// 裸聊打赏
Future<Basic?> apiChatReward(
    {int uid = 0, dynamic gid = 0, dynamic type}) async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post('/api/chat/reward',
        data: {"uid": uid, "gid": gid, 'type': type});
    LogUtil.i(jsonEncode(res.data));
    Basic result = Basic.fromJson(res.data);
    return result;
  } catch (e) {
    debugPrint(e.toString());
    return null;
  }
}

// 他人主页视频
Future<Basic?> apiWorksVideos({int uid = 0, int page = 1}) async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post(
      'api/works/videos',
      data: {"uid": uid, "page": page},
    );
    Basic result = Basic.fromJson(res.data);
    return result;
  } catch (e) {
    debugPrint(e.toString());
    return null;
  }
}

// 他人的粉团视频
Future<Basic?> apiWorksClubVideos({int clubId = 0}) async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post(
      'api/works/club_videos',
      data: {"club_id": clubId},
    );
    Basic result = Basic.fromJson(res.data);
    return result;
  } catch (e) {
    return null;
  }
}

// 视频详情
Future<VideoModel?> apiMvDetials({required int id}) async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post(
      'api/mv/detail',
      data: {"id": id},
    );
    PrintUtil.d(res);
    VideoModel result = VideoModel.fromJson(res.data);
    return result;
  } catch (e) {
    PrintUtil.d(e);
  }
}

/// 验车报告详情
Future<ModelGirlDetailVerify?> apiGirlDetailVerify({
  String? id,
}) async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post(
      'api/girl/detail_verify',
      data: {"id": id},
    );
    ModelGirlDetailVerify result = ModelGirlDetailVerify.fromJson(
      res.data,
    );
    return result;
  } catch (e) {
    return null;
  }
}

/// 登录
Future<Basic?> apiLogin({
  required String username,
  required String password,
}) async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post(
      '/api/users/login',
      data: {"username": username, "password": password},
    );
    LogUtil.i(jsonEncode(res.data));
    Basic result = Basic.fromJson(res.data);
    return result;
  } catch (e) {
    return null;
  }
}

/// 应用中心
Future<ModelApp?> apiApp() async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post(
      '/api/system/appcenter',
    );
    ModelApp result = ModelApp.fromJson(res.data);
    return result;
  } catch (e) {
    return null;
  }
}

/// 视频收藏/已收藏
Future<Basic?> apiFavoritesMvLike({
  required int id,
}) async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post(
      '/api/favorites/mv_like',
      data: {'id': id},
    );
    Basic result = Basic.fromJson(res.data);
    return result;
  } catch (e) {
    return null;
  }
}

/// 投诉类型
/// [type]投诉类型{1: 投诉类型,...}
Future<Basic?> apiListHelper({int? type = 1}) async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post(
      '/api/girl/helper',
      data: {'type': type},
    );
    LogUtil.i(jsonEncode(res.data));
    Basic result = Basic.fromJson(res.data);
    return result;
  } catch (e) {
    return null;
  }
}

/// 消息中心
Future<ModelMsgList?> apiMsgList() async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post(
      '/api/message/list',
    );
    ModelMsgList result = ModelMsgList.fromJson(res.data);
    return result;
  } catch (e) {
    return null;
  }
}

/// 兑换码
Future<Basic?> apiExchangeCode({
  required String code,
}) async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post(
      '/api/users/exchange',
      data: {
        "code": code,
      },
    );
    Basic result = Basic.fromJson(res.data);
    return result;
  } catch (e) {
    return null;
  }
}

/// 邀请码
Future<Basic?> apiInviteCode({
  required String code,
}) async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post(
      '/api/users/invitation',
      data: {
        "aff_code": code,
      },
    );
    Basic result = Basic.fromJson(res.data);
    return result;
  } catch (e) {
    return null;
  }
}

/// 留言提交
Future<Basic?> apiMsgBoard({
  required String content,
}) async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post(
      '/api/users/message',
      data: {
        "content": content,
      },
    );
    Basic result = Basic.fromJson(res.data);
    return result;
  } catch (e) {
    return null;
  }
}

/// 约炮联系方式获取
Future<ModelDatingOrder?> apiDatingOrder({
  int? id,
}) async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post(
      '/api/girl/contact',
      data: {
        "info_id": id,
      },
    );
    ModelDatingOrder result = ModelDatingOrder.fromJson(res.data);
    return result;
  } catch (e) {
    return null;
  }
}

/// 粉丝列表
/// [uid]传uid表示别人关注列表，不传表示自己的
Future<ModelFansList?> apiFansList({
  String? uid,
  int? page,
  int? limit,
}) async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post(
      '/api/users/fans',
      data: {
        "uid": uid,
        "page": page,
        "limit": limit,
      },
    );
    ModelFansList result = ModelFansList.fromJson(res.data);
    return result;
  } catch (e) {
    return null;
  }
}

/// 关注列表
/// [uid]传uid表示别人关注列表，不传表示自己的
Future<Basic?> apiFollowedAuthor({param}) async {
  try {
    Response<dynamic> res =
        await PlatformAwareHttp.post('/api/users/followed', data: param);
    LogUtil.i(jsonEncode(res.data));
    var result = Basic.fromJson(res.data);
    return result;
  } catch (e) {
    return null;
  }
}

Future<ModelFansList?> apiFollowedList({
  String? uid,
  int? page,
  int? limit,
}) async {
  try {
    Response<dynamic> res =
        await PlatformAwareHttp.post('/api/users/followed', data: {"uid": uid});
    LogUtil.i(jsonEncode(res.data));
    ModelFansList result = ModelFansList.fromJson(res.data);
    return result;
  } catch (e) {
    debugPrint(e.toString());
    return null;
  }
}

/// 粉丝团成员列表
/// [id]传id表示别人的粉丝团成员列表，不传表示自己的粉丝团成员
Future<ModelClubList?> apiClubMemberList({
  dynamic id,
  int? page,
  int? limit,
}) async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post(
      '/api/creator/club_members',
      data: {"id": id},
    );
    LogUtil.i(jsonEncode(res.data));
    ModelClubList result = ModelClubList.fromJson(res.data);
    return result;
  } catch (e) {
    debugPrint(e.toString());
    return null;
  }
}

/// 关注/取消关注
/// [uid]对方uid
Future<Basic?> apiFollowing({
  String? uid,
}) async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post(
      '/api/users/following',
      data: {
        "to_uid": uid,
      },
    );
    Basic result = Basic.fromJson(res.data);
    return result;
  } catch (e) {
    return null;
  }
}

/// 清理缓存
Future<Basic?> apiCleanCache() async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post(
      '/api/users/clear',
    );
    Basic result = Basic.fromJson(res.data);
    return result;
  } catch (e) {
    return null;
  }
}

/// 发布验车报告
Future<Basic?> apiDatingCreateVerify({
  String? infoId,
  dynamic images,
  dynamic videos,
  String? content,
}) async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post(
      '/api/girl/create_verify',
      data: {
        "info_id": infoId,
        "images": images,
        "videos": videos,
        "content": content,
      },
    );
    Basic result = Basic.fromJson(res.data);
    return result;
  } catch (e) {
    return null;
  }
}

/// 我的收藏-视频
Future<ModelFavoritesVideoList?> apiFavoritesMvList({
  int page = 1,
  int limit = 5,
}) async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post(
      '/api/favorites/mv_favorite',
      data: {"page": page, "limit": limit},
    );
    ModelFavoritesVideoList result = ModelFavoritesVideoList.fromJson(
      res.data,
    );
    return result;
  } catch (e) {
    return null;
  }
}

/// 我的购买-视频
Future<ModelFavoritesVideoList?> apiBuyMvList({
  int page = 1,
  int limit = 5,
}) async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post(
      '/api/favorites/mv_buy',
      data: {"page": page, "limit": limit},
    );
    LogUtil.i(jsonEncode(res.data));
    ModelFavoritesVideoList result = ModelFavoritesVideoList.fromJson(
      res.data,
    );
    return result;
  } catch (e) {
    return null;
  }
}

/// 我的收藏-漫画
Future<ModelCartonList?> apiFavoritesCartoonList({
  int page = 1,
  int limit = 5,
}) async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post(
      '/api/favorites/comics_favorite',
      data: {"page": page, "limit": limit},
    );
    ModelCartonList result = ModelCartonList.fromJson(
      res.data,
    );
    return result;
  } catch (e) {
    return null;
  }
}

/// 我的购买-漫画
Future<ModelCartonList?> apiBuyCartoonList({
  int page = 1,
  int limit = 5,
}) async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post(
        '/api/favorites/comics_buy',
        data: {"page": page});
    ModelCartonList result = ModelCartonList.fromJson(res.data);
    return result;
  } catch (e) {
    return null;
  }
}

/// 我的收藏-裸聊
Future<ModelCollectBuyChat?> apiFavoritesNudeChatList({
  int page = 1,
  int limit = 5,
}) async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post(
      '/api/favorites/chat_favorite',
      data: {"page": page, "limit": limit},
    );
    ModelCollectBuyChat result = ModelCollectBuyChat.fromJson(
      res.data,
    );
    return result;
  } catch (e) {
    return null;
  }
}

/// 我的购买-裸聊
Future<ModelCollectBuyChat?> apiBuyNudeChatList({
  int page = 1,
  int limit = 5,
}) async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post(
      '/api/favorites/chat_buy',
      data: {"page": page, "limit": limit},
    );
    ModelCollectBuyChat result = ModelCollectBuyChat.fromJson(
      res.data,
    );
    return result;
  } catch (e) {
    return null;
  }
}

/// 我的收藏-约炮
Future<ModelCollectBuyDating?> apiFavoritesDating({
  int page = 1,
  int limit = 5,
}) async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post(
      '/api/favorites/meet_favorite',
      data: {"page": page, "limit": limit},
    );
    ModelCollectBuyDating result = ModelCollectBuyDating.fromJson(
      res.data,
    );
    return result;
  } catch (e) {
    return null;
  }
}

/// 我的购买-约炮
Future<ModelCollectBuyDating?> apiBuyDating({
  int page = 1,
  int limit = 5,
}) async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post(
      '/api/favorites/meet_buy',
      data: {"page": page, "limit": limit},
    );
    ModelCollectBuyDating result = ModelCollectBuyDating.fromJson(
      res.data,
    );
    return result;
  } catch (e) {
    return null;
  }
}

/// 我的收藏-小说
Future<ModelCollectBuyNovel?> apiFavoritesNovel({
  int page = 1,
  int limit = 5,
}) async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post(
      '/api/favorites/story_favorite',
      data: {"page": page, "limit": limit},
    );
    ModelCollectBuyNovel result = ModelCollectBuyNovel.fromJson(
      res.data,
    );
    return result;
  } catch (e) {
    return null;
  }
}

/// 我的购买-小说
Future<ModelCollectBuyNovel?> apiBuyNovel({
  int page = 1,
  int limit = 5,
}) async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post(
      '/api/favorites/story_buy',
      data: {"page": page, "limit": limit},
    );
    ModelCollectBuyNovel result = ModelCollectBuyNovel.fromJson(
      res.data,
    );
    return result;
  } catch (e) {
    return null;
  }
}

/// 我的收藏-图集
Future<ModelCollectBuyPictures?> apiFavoritesPictures({
  int page = 1,
  int limit = 5,
}) async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post(
      '/api/favorites/picture_favorite',
      data: {"page": page, "limit": limit},
    );
    LogUtil.i(jsonEncode(res.data));
    var result = ModelCollectBuyPictures.fromJson(res.data);
    return result;
  } catch (e) {
    return null;
  }
}

/// 我的购买-图集
Future<ModelCollectBuyPictures?> apiBuyPictures({
  int page = 1,
  int limit = 5,
}) async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post(
      '/api/favorites/picture_buy',
      data: {"page": page, "limit": limit},
    );
    ModelCollectBuyPictures result = ModelCollectBuyPictures.fromJson(
      res.data,
    );
    return result;
  } catch (e) {
    return null;
  }
}

/// 商务联系
Future<ModelContact?> apiContact() async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post(
      '/api/system/shangwu',
    );
    LogUtil.i(jsonEncode(res.data));
    ModelContact result = ModelContact.fromJson(res.data);
    return result;
  } catch (e) {
    return null;
  }
}

/// 我的购买-合集
Future<Basic?> apiBuyGather({int page = 1, int limit = 5}) async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post(
      '/api/favorites/special_buy',
      data: {"page": page, "limit": limit},
    );
    var result = Basic.fromJson(res.data);
    return result;
  } catch (e) {
    return null;
  }
}

/// 筛选-视频
Future<Basic?> apiMvFilter({
  int page = 1,
  int limit = 5,
  String category = "mv",
  String tags = "",
  String fee = "",
  String order = "",
}) async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post(
      '/api/mv/filter',
      data: {
        "page": page,
        "limit": limit,
        "category": category,
        "tags": tags,
        "fee": fee,
        "order": order,
      },
    );
    Basic result = Basic.fromJson(res.data);
    return result;
  } catch (e) {
    return null;
  }
}

/// 工单历史/在线客服历史列表
Future<ModelOnlineList?> apiOnlineList({
  int page = 1,
  int limit = 5,
}) async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post(
      '/api/helper/feed_list',
      data: {
        "page": page,
        "limit": limit,
      },
    );
    ModelOnlineList result = ModelOnlineList.fromJson(res.data);
    return result;
  } catch (e) {
    return null;
  }
}

/// 工单提交/在线客服提交
Future<Basic?> apiOnlineSubmit({
  String? content,
  String? thumb,
}) async {
  try {
    Response<dynamic> res = await PlatformAwareHttp.post(
      '/api/helper/feed_save',
      data: {
        "content": content,
        "thumb": thumb,
      },
    );
    Basic result = Basic.fromJson(res.data);
    return result;
  } catch (e) {
    return null;
  }
}
