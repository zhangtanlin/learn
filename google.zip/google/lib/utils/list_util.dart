class ListUtil {
  static bool isNotEmpty(List<dynamic>? list) {
    return list != null && list.isNotEmpty;
  }

  static bool isEmpty(List<dynamic>? list) {
    return list == null || list.isEmpty;
  }

  static int size(List list) {
    return isEmpty(list) ? 0 : list.length;
  }
}
