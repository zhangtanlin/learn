class StringUtil {
  static bool isNotEmpty(String? str) {
    return str != null && str != '';
  }

  static bool isEmpty(String? str) {
    return str == null || str == '';
  }

  static String formatNumber(double number, int positon) {
    if (number >= 10000) {
      return formatDecimal(number / 10000, positon) + '万';
    }
    return number.toStringAsFixed(positon);
  }

  static String formatDecimal(double number, int positon) {
    var temp = number.toString();
    if ((temp.length - temp.lastIndexOf('.') - 1) <= positon) {
      return number.toStringAsFixed(positon);
    } else {
      return temp.substring(0, temp.lastIndexOf('.') + positon + 1);
    }
  }

  /// 判断当前字符串转换成长度（中文算作2个字符）
  static int stringLength(String str) {
    int tempLength = 0;
    if (str.isNotEmpty) {
      List<dynamic> tempList = str.split("");
      for (var i = 0; i < tempList.length; i++) {
        RegExp chinese = RegExp(r"[\u4e00-\u9fa5]");
        bool isChinese = chinese.hasMatch(tempList[i]);
        if (isChinese) {
          tempLength += 2;
        } else {
          tempLength += 1;
        }
      }
    }
    return tempLength;
  }
}
