import 'package:flutter_screenutil/flutter_screenutil.dart';

class ImgUtil {
  static clipImageUrl(String url, {double inputWidth = 120}) {
    if (url == null) {
      return '';
    }
    String t = '';
    if (url != null && url.contains('!')) {
      return url;
    }

    inputWidth = inputWidth * ScreenUtil().pixelRatio!;

    int width = 120;
    if (inputWidth > 720) {
      return url;
    } else if (inputWidth > 360) {
      width = 720;
    } else if (inputWidth > 120) {
      width = 360;
    }
    var list = url.split('.');
    if (list.length < 2) {
      return url;
    }
    for (var i = 0; i < list.length; i++) {
      t += list[i];

      if (i == list.length - 2) {
        t += '!${width}x0';
        t += '.';
        t += list.last;
        break;
      }
      t += '.';
    }
    return t;
  }
}
