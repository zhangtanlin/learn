class DateUtil {
  static String strToDateStr(String dateStr) {
    DateTime dateTime = DateTime.parse(dateStr);
    return dateToDateStr(dateTime);
  }

  static String dateToDateStr(DateTime dateTime) {
    return '${dateTime.year}年${dateTime.month}月${dateTime.day}日';
  }
  
  /// yyyy-MM-dd HH:mm:ss
  static String dateToStr(DateTime dateTime) {
    return '${dateTime.year}-${dateTime.month}-${dateTime.day} ${dateTime.hour}:${dateTime.minute}:${dateTime.second}';
  }
}
