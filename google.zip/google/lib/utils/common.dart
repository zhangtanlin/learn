import 'dart:convert';
import 'dart:math';
import 'package:bot_toast/bot_toast.dart';
import 'package:crypto/crypto.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:iaimei/global.dart';
import 'package:iaimei/utils/http.dart';
import 'package:iaimei/utils/printLog.dart';
import 'package:isolated_worker/worker_delegator.dart';
import 'package:universal_html/html.dart' as html;
import 'package:url_launcher/url_launcher.dart';
import "package:hex/hex.dart";

class Method {
  static bool isAndroidWeb() {
    return kIsWeb &&
        (html.window.navigator.userAgent.contains('Android') ||
            html.window.navigator.userAgent.contains('Linux'));
  }

  static showText(String text, {int time = 3}) {
    return BotToast.showText(
        text: text,
        textStyle: TextStyle(
            color: const Color.fromRGBO(255, 255, 255, 1),
            fontSize: ScreenUtil().setSp(15),
            decoration: TextDecoration.none),
        align: const Alignment(0, 0),
        duration: Duration(seconds: time));
  }

  static launchURL(String url) async {
    try {
      await launch(url, forceSafariVC: false);
    } catch (e) {
      BotToast.showText(text: '网址错误');
    }
  }

  static void debugPrint(value) {
    const bool inProduction = bool.fromEnvironment("dart.vm.product");
    if (!inProduction) {
      PrintUtil.d(value);
    }
  }

  static String convertMD5(String data) {
    var content = const Utf8Encoder().convert(data);
    var digest = md5.convert(content);
    var text = HEX.encode(digest.bytes);
    return text;
  }

  static String convertSha256(String data) {
    var content = const Utf8Encoder().convert(data);
    var digest = sha256.convert(content);
    var text = HEX.encode(digest.bytes);
    return text;
  }

  static Map<String, int> retryCountMap = {};
  static List<List> tasks = [];
  static List<bool> wdsRuningStatuses = List.generate(5, (index) => false);
  static void getRealImage(
      {dynamic url,
      dynamic imgUrl,
      Function? setUrl,
      Function? retryHandler,
      bool isNovel = false}) {
    if (url == null) return Method.debugPrint('无封面图');
    void doWork(args, _freeIndex) async {
      if (args[0] != null || args[1] != null || args[0] != '') {
        dynamic decrypted;
        String? data;
        decrypted = AppGlobal.imageCacheBox?.get(args[0]) ??
            AppGlobal.imageAssetBox?.get(args[0]);
        if (decrypted == null) {
          try {
            data = await PlatformAwareHttp.getImage(args[0]);
            if (data != '' && data != null) {
              decrypted =
                  await WorkerDelegator().run('decryptImage$_freeIndex', data);
              if (decrypted != '' && decrypted != null) {
                decrypted = base64Decode(decrypted);
                if (isNovel) {
                  decrypted = utf8.decode(decrypted);
                }
                if (args[0].toString().contains('assets/yy/')) {
                  AppGlobal.imageAssetBox?.put(args[0], decrypted);
                } else {
                  AppGlobal.imageCacheBox?.put(args[0], decrypted);
                }
              }
            }
          } catch (err) {
            // Method.debugPrint('图片请求失败${args[0]}');
            // Method.debugPrint('图片请求失败$err');
          }
        }
        if (decrypted != null && args[2] != null) {
          args[2](decrypted);
        } else if (args[3] != null) {
          args[3]();
        }
        decrypted = null;
        data = null;
      }
      wdsRuningStatuses[_freeIndex] = false;
      int f = wdsRuningStatuses.indexWhere((element) => !element);
      if (tasks.isNotEmpty && f != -1) {
        wdsRuningStatuses[f] = true;
        doWork(tasks.removeAt(0), f);
      }
    }

    var tempUrl = url.toString().contains('assets/images/')
        ? '${AppGlobal.bannerImgBase}new/$url'.replaceAll('images/', 'gg/')
        : url;

    tasks.add([tempUrl, imgUrl, setUrl, retryHandler]);

    int freeIndex = wdsRuningStatuses.indexWhere((element) => !element);
    if (freeIndex != -1 && tasks.isNotEmpty) {
      wdsRuningStatuses[freeIndex] = true;
      doWork(tasks.removeAt(0), freeIndex);
    }
  }

  static String randomId(int range) {
    String str = "";
    List<String> arr = [
      "0",
      "1",
      "2",
      "3",
      "4",
      "5",
      "6",
      "7",
      "8",
      "9",
      "a",
      "b",
      "c",
      "d",
      "e",
      "f",
      "g",
      "h",
      "i",
      "j",
      "k",
      "l",
      "m",
      "n",
      "o",
      "p",
      "q",
      "r",
      "s",
      "t",
      "u",
      "v",
      "w",
      "x",
      "y",
      "z",
      "A",
      "B",
      "C",
      "D",
      "E",
      "F",
      "G",
      "H",
      "I",
      "J",
      "K",
      "L",
      "M",
      "N",
      "O",
      "P",
      "Q",
      "R",
      "S",
      "T",
      "U",
      "V",
      "W",
      "X",
      "Y",
      "Z"
    ];
    for (int i = 0; i < range; i++) {
      int pos = Random().nextInt(arr.length - 1);
      str += arr[pos];
    }
    return str;
  }
}
