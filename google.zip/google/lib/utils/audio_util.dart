import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:iaimei/global.dart';
import 'package:iaimei/utils/crypto.dart';
import 'package:universal_html/html.dart' as html;
import 'package:iaimei/utils/shelf_proxy.dart';

class AudioUtil{

  static Future<String> getRealUrl(String? url,
      {bool isLocal = false, bool isNew = false}) async {
    String resultUrl = '';
    String preUrl = url??'';
    if (kIsWeb) {
      if (AppGlobal.m3u8Encrypt == '1') {
        Response res = await Dio().get(preUrl);
        String decrypted = PlatformAwareCrypto.decryptM3U8(res.data);
        final _blob = html.Blob([decrypted], 'application/x-mpegURL', 'native');
        final tempUrl = html.Url.createObjectUrl(_blob);
        resultUrl = tempUrl;
      } else {
        resultUrl = preUrl;
      }
    } else if (!isLocal) {
      if (AppGlobal.m3u8Encrypt == '1') {
        Map proxyConfig = await createServer(preUrl);
        String proxyUrl =
        preUrl.replaceAll(proxyConfig['origin'], proxyConfig['localproxy']);
        resultUrl = proxyUrl;
      } else {
        resultUrl = preUrl;
      }
    } else {
      String tempUrl = await createStaticServer(preUrl);
      resultUrl = tempUrl;
    }
    return resultUrl;
  }
}