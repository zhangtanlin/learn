import 'dart:async';

import 'package:iaimei/utils/eventbus_helper.dart';

class EventBusUtil{

  //返回事件的订阅者
  static StreamSubscription<T> listen<T>(Function(T event) onData) {
    return EventBusHelper.getInstance().on<T>().listen(onData);
  }

  //发送事件
  static void fire(e) {
    EventBusHelper.getInstance().fire(e);
  }
}