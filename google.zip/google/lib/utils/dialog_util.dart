import 'package:flutter/material.dart';
import 'package:iaimei/model/unlock_info_model.dart';
import 'package:iaimei/pages/comics/comics_catalog_list_page.dart';
import 'package:iaimei/pages/novel/novel_catalog_list_page.dart';
import 'package:iaimei/res/color_res.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/res/img_res.dart';
import 'package:iaimei/res/string_res.dart';
import 'package:iaimei/style/app_decoration.dart';
import 'package:iaimei/style/app_text_style.dart';
import 'package:iaimei/utils/list_util.dart';
import 'package:iaimei/utils/page_jump_util.dart';
import 'package:iaimei/utils/string_util.dart';
import 'package:iaimei/widget/app_img_widget.dart';
import 'package:iaimei/widget/app_normal_btn_widget.dart';
import 'package:iaimei/widget/purple_frosted_glass_container.dart';
import 'package:iaimei/widget/space_widget.dart';
import 'package:iaimei/widget/text_widget.dart';

typedef BalancePayCallback = Function(UnlockInfoModel unlockInfo, String type);
typedef CoinPayCallback = Function(UnlockInfoModel unlockInfo, String type);
typedef TimesPayCallback = Function(UnlockInfoModel unlockInfo, String type);
typedef ContentBuilder = Widget Function(BuildContext context);

class DialogUtil {
  static void showBuyVipDialog({required BuildContext cxt}) {
    showPurpleFrostedGlassDialog(
        cxt: cxt,
        insetPadding: DimenRes.dimen_30,
        child: Column(
          children: [
            Padding(
              padding: EdgeInsets.only(
                  left: DimenRes.dimen_15,
                  top: DimenRes.dimen_40,
                  bottom: DimenRes.dimen_30,
                  right: DimenRes.dimen_15),
              child: Text.rich(TextSpan(children: [
                TextSpan(
                    text: StringRes.str_open_vip,
                    style: AppTextStyle.white_s14),
                TextSpan(
                  text: StringRes.str_free,
                  style: AppTextStyle.cff00b3_s14,
                ),
                TextSpan(
                  text: StringRes.str_watch,
                  style: AppTextStyle.white_s14,
                )
              ])),
            ),
            AppDialogBtnWidget(
              text: StringRes.str_go_open,
              onTap: () {
                PageJumpUtil.forwardToBuyVipPage(cxt);
                Navigator.pop(cxt);
              },
            ),
            Padding(
              padding: EdgeInsets.only(
                  left: DimenRes.dimen_15,
                  top: DimenRes.dimen_15,
                  bottom: DimenRes.dimen_20,
                  right: DimenRes.dimen_15),
              child: InkWell(
                child: TextWidget.build(
                  StringRes.str_to_recharge,
                  AppTextStyle.cff00b3_s12,
                ),
                onTap: () {
                  PageJumpUtil.forwardToRechargeCoinsPage(cxt);
                  Navigator.pop(cxt);
                },
              ),
            )
          ],
        ));
  }

  static Widget _buildCoinUnlockSection(
      BuildContext cxt, int index, String type, UnlockInfoModel? unlockInfo,
      {CoinPayCallback? coinPayCallback}) {
    double itemWidth = (DimenRes.screenWidth - DimenRes.convert(105)) / 2;
    return Container(
        width: itemWidth,
        decoration: BoxDecoration(
            color: const Color(0xff000000).withOpacity(0.12),
            borderRadius: BorderRadius.circular(12)),
        child: Column(
          children: [
            Container(
              height: DimenRes.dimen_22,
              margin: EdgeInsets.only(
                  left: DimenRes.dimen_10,
                  right: DimenRes.dimen_10,
                  bottom: DimenRes.dimen_20,
                  top: DimenRes.dimen_30),
              child: TextWidget.buildSingleLineText(
                  '${unlockInfo?.resourceGCoins} 钻', AppTextStyle.white_s15),
            ),
            TextWidget.buildSingleLineText(
                StringRes.str_cur_balance + ' ${unlockInfo?.userGCoins} 钻',
                AppTextStyle.white_s12),
            Container(
              margin: EdgeInsets.only(
                  left: DimenRes.dimen_8,
                  right: DimenRes.dimen_8,
                  top: DimenRes.dimen_10,
                  bottom: DimenRes.dimen_10),
              child: AppDialogBtnWidget(
                text: StringRes.str_coin_unlock,
                textStyle: AppTextStyle.white_s16,
                onTap: () {
                  if (coinPayCallback != null) {
                    coinPayCallback.call(unlockInfo!, type);
                  }
                  Navigator.pop(cxt);
                },
              ),
            )
          ],
        ));
  }

  static Widget _buildTimesUnlockSection(BuildContext cxt, int index,
      String titleStr, String type, UnlockInfoModel? unlockInfo) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: DimenRes.dimen_15),
      alignment: Alignment.center,
      child: Column(
        children: [
          const SpaceWidget(vSpace: 25),
          TextWidget.buildSingleLineText(titleStr, AppTextStyle.white_s16),
          const SpaceWidget(vSpace: 20),
          TextWidget.buildSingleLineText('本次解锁消耗：1次', AppTextStyle.white_s14),
          const SpaceWidget(vSpace: 10),
          TextWidget.buildSingleLineText(
              '剩余解锁次数：${unlockInfo?.userTimes ?? 0}次', AppTextStyle.white_s14),
        ],
      ),
    );
  }

  static Widget _buildBalanceUnlockSection(
      BuildContext cxt, int index, String type, UnlockInfoModel? unlockInfo,
      {BalancePayCallback? balancePayCallback}) {
    double itemWidth = (DimenRes.screenWidth - DimenRes.convert(105)) / 2;
    return Container(
      width: itemWidth,
      decoration: BoxDecoration(
          color: const Color(0xff000000).withOpacity(0.12),
          borderRadius: BorderRadius.circular(12)),
      child: Column(
        children: [
          Container(
            height: DimenRes.dimen_22,
            margin: EdgeInsets.only(
                left: DimenRes.dimen_10,
                right: DimenRes.dimen_10,
                bottom: DimenRes.dimen_20,
                top: DimenRes.dimen_30),
            child: TextWidget.buildSingleLineText(
                '¥ ${unlockInfo?.resourceCoins}', AppTextStyle.white_s15),
          ),
          TextWidget.buildSingleLineText(
              StringRes.str_cur_balance + ' ${unlockInfo?.userCoins}',
              AppTextStyle.white_s12),
          Container(
              margin: EdgeInsets.only(
                  left: DimenRes.dimen_8,
                  right: DimenRes.dimen_8,
                  top: DimenRes.dimen_10,
                  bottom: DimenRes.dimen_10),
              child: AppDialogBtnWidget(
                text: StringRes.str_balance_unlock,
                textStyle: AppTextStyle.white_s16,
                onTap: () {
                  if (balancePayCallback != null) {
                    balancePayCallback.call(unlockInfo!, type);
                  }
                  Navigator.pop(cxt);
                },
              ))
        ],
      ),
    );
  }

  static void showPayDialog(
      {required BuildContext cxt,
      String? titleStr,
      UnlockInfoModel? unlockInfo,
      BalancePayCallback? balancePayCallback,
      CoinPayCallback? coinPayCallback,
      TimesPayCallback? timesPayCallback,
      VoidCallback? payCancel}) {
    List<PayWay> payWayList = [];
    int times = 0;
    if (unlockInfo != null) {
      if (ListUtil.isNotEmpty(unlockInfo.payWay)) {
        payWayList = unlockInfo.payWay!;
      }
      times = unlockInfo.userTimes ?? 0;
    }

    showPurpleFrostedGlassDialog(
        cxt: cxt,
        insetPadding: DimenRes.dimen_30,
        cancelCallback: () {
          if (payCancel != null) {
            payCancel.call();
          }
        },
        child: Column(
          children: [
            const SpaceWidget(
              vSpace: 20,
            ),
            Wrap(
              spacing: DimenRes.dimen_15,
              runSpacing: DimenRes.dimen_15,
              children: payWayList.asMap().keys.map((index) {
                Widget tempWidget = const SizedBox();
                String _tmpType = payWayList[index].type ?? '';
                if (StringUtil.isNotEmpty(_tmpType)) {
                  if (_tmpType == "user_times") {
                    tempWidget = _buildTimesUnlockSection(
                        cxt, index, titleStr ?? '', _tmpType, unlockInfo);
                  } else {
                    if (_tmpType == "resource_coins") {
                      tempWidget = _buildBalanceUnlockSection(
                          cxt, index, _tmpType, unlockInfo,
                          balancePayCallback: balancePayCallback);
                    } else if (_tmpType == "resource_g_coins") {
                      tempWidget = _buildCoinUnlockSection(
                          cxt, index, _tmpType, unlockInfo,
                          coinPayCallback: coinPayCallback);
                    }
                  }
                }
                return tempWidget;
              }).toList(),
            ),
            times > 0
                ? Container(
                    child: AppDialogBtnWidget(
                      text: StringRes.str_unlock,
                      textStyle: AppTextStyle.white_s16,
                      onTap: () {
                        if (timesPayCallback != null) {
                          timesPayCallback.call(unlockInfo!, "user_times");
                        }
                        Navigator.pop(cxt);
                      },
                    ),
                    margin: EdgeInsets.only(
                        top: DimenRes.dimen_30, bottom: DimenRes.dimen_20),
                  )
                : Padding(
                    padding: EdgeInsets.only(
                        left: DimenRes.dimen_15,
                        top: DimenRes.dimen_15,
                        bottom: DimenRes.dimen_20,
                        right: DimenRes.dimen_15),
                    child: InkWell(
                      child: TextWidget.build(
                          StringRes.str_to_recharge, AppTextStyle.cff00b3_s12),
                      onTap: () {
                        PageJumpUtil.forwardToRechargeCoinsPage(cxt);
                        Navigator.pop(cxt);
                      },
                    ),
                  )
          ],
        ));
  }

  static void showPurpleFrostedGlassDialog(
      {required BuildContext cxt,
      required Widget child,
      bool dismissible = false,
      double insetPadding = 30,
      VoidCallback? cancelCallback}) {
    showDialog(
      context: cxt,
      barrierDismissible: dismissible,
      builder: (context) {
        return Dialog(
          insetPadding: EdgeInsets.all(insetPadding),
          backgroundColor: Colors.transparent,
          insetAnimationCurve: Curves.easeIn,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              PurpleFrostedGlassContainer(
                radius: const BorderRadius.all(Radius.circular(24)),
                sigmaX: 12,
                sigmaY: 10,
                child: child,
              ),
              const SpaceWidget(
                vSpace: 20,
              ),
              AppImgWidget(
                path: ImgRes.IC_DIALOG_CLOSE,
                width: DimenRes.dimen_30,
                height: DimenRes.dimen_30,
                onTap: () {
                  if (cancelCallback != null) {
                    cancelCallback.call();
                  }
                  Navigator.pop(context);
                },
              )
            ],
          ),
        );
      },
    );
  }

  static void showBaseDialog(
      {required BuildContext cxt,
      required Widget child,
      bool dismissible = false,
      double insetPadding = 40,
      VoidCallback? cancelCallback}) {
    showDialog(
        context: cxt,
        builder: (context) {
          return Dialog(
            insetPadding: EdgeInsets.all(insetPadding),
            backgroundColor: Colors.transparent,
            insetAnimationCurve: Curves.easeIn,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                child,
                SpaceWidget(
                  vSpace: DimenRes.dimen_20,
                ),
                AppImgWidget(
                  path: ImgRes.IC_DIALOG_CLOSE,
                  width: DimenRes.dimen_30,
                  height: DimenRes.dimen_30,
                  onTap: () {
                    Navigator.pop(context);
                    if (cancelCallback != null) {
                      cancelCallback.call();
                    }
                  },
                )
              ],
            ),
          );
        },
        barrierDismissible: dismissible);
  }

  static void showComicsCatalogListDialog(BuildContext cxt, String id,
      String? info, ComicsCatalogItemCallback callback) {
    showBottomDialog(
        context: cxt,
        height: DimenRes.dimen_380,
        child: ComicsCatalogListPage(
          id: id,
          info: info ?? '',
          callback: callback,
        ));
  }

  static void showNovelCatalogListDialog(BuildContext cxt, String id,
      String? info, NovelCatalogItemCallback callback) {
    showBottomDialog(
        context: cxt,
        height: DimenRes.dimen_400,
        child: NovelCatalogListPage(
          id: id,
          info: info ?? '',
          callback: callback,
        ));
  }

  static void showBottomDialog(
      {required BuildContext context,
      required Widget child,
      double? width,
      double? height,
      Color? bgColor}) {
    showModalBottomSheet(
        context: context,
        backgroundColor: bgColor ?? ColorRes.color_1a152f,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(8), topRight: Radius.circular(8)),
        ),
        builder: (context) {
          return SizedBox(
            width: width,
            height: height,
            child: child,
          );
        });
  }

  static show({
    required BuildContext cxt,
    required ContentBuilder contentBuilder,
    double? width,
    double? height,
    EdgeInsetsGeometry? padding,
    Decoration? decoration,
    BoxConstraints? boxConstraints,
    bool dismissible = false,
  }) {
    showDialog(
        context: cxt,
        barrierDismissible: dismissible,
        builder: (context) {
          return Material(
            //创建透明层
            type: MaterialType.transparency, //透明类型
            child: Center(
              //保证控件居中效果
              child: Container(
                constraints: boxConstraints,
                width: width == null || width <= 0
                    ? DimenRes.screenWidth * 3 / 4
                    : width,
                height: height,
                padding: padding,
                decoration: decoration ??
                    AppDecoration.getSingleColorBg(
                        color: Colors.white,
                        radius: BorderRadius.circular(DimenRes.radius(10))),
                child: contentBuilder(context),
              ),
            ),
          );
        });
  }
}
