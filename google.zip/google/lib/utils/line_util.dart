import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:iaimei/app_const.dart';
import 'package:iaimei/global.dart';
import 'package:iaimei/utils/list_util.dart';
import 'package:iaimei/utils/log_util.dart';
import 'package:iaimei/utils/string_util.dart';
import 'package:iaimei/widget/toast_widget.dart';
import 'package:universal_html/html.dart' as html;

class LineUtil {
  static void checkLine({Function? onSuccess, Function? onFailed}) async {
    int _timeout = 30;

    // pwa error -- List<dynamic>
    var temp = AppGlobal.appBox?.get(AppConst.apiLinesKey);
    if (temp is! List) temp = AppConst.apiLines;
    List<String> lines = temp.map((item) => item as String).toList();

    List<String> unCheckLines = lines;

    List<Map> errorLines = [];
    Function doCheck;
    Function reportErrorLines;
    Function handleResult;
    reportErrorLines = () async {
      // 上报错误线路&保存服务端推荐线路到本地
      if (errorLines.isEmpty) return;
    };

    handleResult = (String? line) async {
      if (line != null) {
        AppGlobal.apiBaseURL = line;
        await reportErrorLines();
        if (onSuccess != null) {
          onSuccess.call();
        }
      } else {
        if (onFailed != null) {
          onFailed.call();
        }
      }
    };

    doCheck = ({String? line}) async {
      dynamic result;
      try {
        String tempUrl = '';
        if (line!.endsWith('/api.php')) {
          int cIndex = line.lastIndexOf('/');
          tempUrl = line.substring(0, cIndex);
        } else {
          tempUrl = line;
        }
        result = await Dio().get('$tempUrl/ping.txt');
      } catch (err) {
        result = 'error';
      }
      if (result == 'error') {
        errorLines.add({'url': line});
        //启用备用github线路
        if (errorLines.length == unCheckLines.length) {
          String gitUrl = AppConst.githubUrl;
          dynamic result = await Dio().get(gitUrl);
          handleResult(result.toString().trim());
        }
      } else {
        if (result.toString() == '200') {
          handleResult(line);
        } else {
          if (onFailed != null) {
            onFailed.call();
          }
        }
      }
      return result;
    };

    ConnectivityResult connectivityResult =
        await Connectivity().checkConnectivity();
    if (connectivityResult == ConnectivityResult.mobile ||
        connectivityResult == ConnectivityResult.wifi) {
      Future.any(unCheckLines.map((line) {
        return doCheck(line: line).then((value) {
          if (value.toString() == '200') {
            return line;
          } else {
            return Future.delayed(Duration(seconds: _timeout), () {
              return null;
            });
          }
        });
      })).then((line) {
        handleResult(line);
      });
    } else {
      if (onFailed != null) {
        onFailed.call();
      }
    }
  }

  static Future<void> check({Function? onSuccess, Function? onFailed}) async {
    ConnectivityResult connectivityResult =
        await Connectivity().checkConnectivity();

    if (connectivityResult == ConnectivityResult.mobile ||
        connectivityResult == ConnectivityResult.wifi) {
      String availableUrl = '';

      List<String> lines = AppConst.apiLines;

      try {
        List<dynamic>? tempList = AppGlobal.appBox!.get(AppConst.apiLinesKey);

        if (ListUtil.isNotEmpty(tempList)) {
          if (tempList is List) {
            lines = tempList.map((item) => item as String).toList();
          }
        }

        List<String> unCheckLines = lines;

        String getGithubUrl = '';
        if (kIsWeb) {
          Future<String> requestAction() =>
              html.HttpRequest.request(AppConst.githubUrl)
                  .then((responseValue) {
                return responseValue.responseText.toString();
              });
          getGithubUrl = await requestAction();
        } else {
          var tmpUrl = await Dio().get(AppConst.githubUrl);
          getGithubUrl = tmpUrl.toString();
        }
        String githubUrl = getGithubUrl.trim();
        unCheckLines.add(githubUrl);

        for (int i = 0; i < unCheckLines.length; i++) {
          String curUrl = unCheckLines[i];
          LogUtil.i("curUrl----->$curUrl");
          if (StringUtil.isNotEmpty(curUrl)) {
            String tempUrl = '';
            if (curUrl.endsWith('/api.php')) {
              int cIndex = curUrl.lastIndexOf('/');
              tempUrl = curUrl.substring(0, cIndex);
            } else {
              tempUrl = curUrl;
            }
            String apiUrl = '$tempUrl/ping.txt';
            if (kIsWeb) {
              Future<String> requestAction() =>
                  html.HttpRequest.request(apiUrl).then((responseValue) {
                    if (responseValue.responseText.toString() == '200') {
                      return curUrl;
                    }
                    return '';
                  });
              String tempRUrl = await requestAction();
              availableUrl = tempRUrl;
            } else {
              dynamic result = await Dio().get(apiUrl);
              if (result.toString() == '200') {
                availableUrl = curUrl;
              }
            }
            if (StringUtil.isNotEmpty(availableUrl)) {
              break;
            }
          }
        }
      } catch (e) {
        e.toString();
      }

      if (StringUtil.isNotEmpty(availableUrl)) {
        AppGlobal.apiBaseURL = availableUrl;
        if (onSuccess != null) {
          onSuccess.call();
        }
      } else {
        if (onFailed != null) {
          onFailed.call();
        }
      }
    } else {
      if (onFailed != null) {
        onFailed.call();
      }
    }
  }
}
