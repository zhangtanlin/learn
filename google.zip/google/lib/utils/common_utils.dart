import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:bot_toast/bot_toast.dart';
import 'package:convert/convert.dart';
import 'package:crypto/crypto.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:iaimei/global.dart';
import 'package:iaimei/utils/log_util.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:universal_html/html.dart' as html;
import 'package:url_launcher/url_launcher.dart';

class CommonUtils {
  static Size boundingTextSize(
      BuildContext context, String text, TextStyle style,
      {int maxLines = 2 ^ 31, double maxWidth = double.infinity}) {
    if (text == null || text.isEmpty) {
      return Size.zero;
    }
    final TextPainter textPainter = TextPainter(
        textDirection: TextDirection.ltr,
        locale: Localizations.localeOf(context),
        text: TextSpan(text: text, style: style),
        maxLines: maxLines)
      ..layout(maxWidth: maxWidth);
    return textPainter.size;
  }

  static setBottomBar() {
    if (Platform.isAndroid) {
      SystemUiOverlayStyle systemUiOverlayStyle =
          const SystemUiOverlayStyle(systemNavigationBarColor: Colors.black);
      SystemChrome.setSystemUIOverlayStyle(systemUiOverlayStyle);
    }
  }

  static String durationToTime(dynamic value) {
    double durations = 0.0;
    if (value is String) {
      durations = double.parse(value);
    }
    if (value is int) {
      durations = double.parse(value.toString());
    }
    double hours = durations.floor() / 3600;
    double forMinutes = durations % 3600;
    double minutes = forMinutes.floor() / 60;
    double sec = forMinutes.ceil() % 60;

    String hoursString = hours.round().toString();
    String minutesString = minutes < 10
        ? "0" + minutes.round().toString()
        : minutes.round().toString();
    String secString =
        sec < 10 ? "0" + sec.round().toString() : sec.round().toString();
    if (durations < 3600) {
      return minutesString + ':' + secString;
    } else {
      return hoursString + ':' + minutesString + ':' + secString;
    }
  }

  static setStatusBar({bool dark = true}) {
    if (kIsWeb) {
      return SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle.dark);
    } else if (Platform.isAndroid) {
      SystemUiOverlayStyle systemUiOverlayStyle = SystemUiOverlayStyle(
        statusBarColor: Colors.transparent, //全局设置透明
        statusBarIconBrightness: dark ? Brightness.dark : Brightness.light,
      );
      SystemChrome.setSystemUIOverlayStyle(systemUiOverlayStyle);
    } else if (Platform.isIOS) {
      //导航栏状态栏文字颜色
      SystemChrome.setSystemUIOverlayStyle(
          dark ? SystemUiOverlayStyle.dark : SystemUiOverlayStyle.light);
    }
  }

  static int platform() {
    if (kIsWeb) {
      return 2;
    } else if (Platform.isAndroid) {
      return 0;
    } else {
      return 1;
    }
  }

  static showText(String text, {int time = 3}) {
    return BotToast.showText(
        text: text,
        textStyle: TextStyle(
            color: Colors.white,
            fontSize: ScreenUtil().setSp(15),
            decoration: TextDecoration.none),
        align: const Alignment(0, 0),
        duration: Duration(seconds: time));
  }

  static getHMTime(int time) {
    getTime(int _num) {
      return _num < 10 ? '0' + _num.toString() : _num;
    }

    var times = DateTime.fromMillisecondsSinceEpoch(time * 1000);
    String cTime = '${getTime(times.hour)}:${getTime(times.minute)}';
    return cTime;
  }

  // 检查安装未知安装包
  static checkRequestInstallPackages() async {
    if (Platform.isAndroid) {
      PermissionStatus _status = await Permission.requestInstallPackages.status;
      if (_status == PermissionStatus.granted) {
        return true;
      } else if (_status == PermissionStatus.permanentlyDenied) {
        CommonUtils.showText('您拒绝了安装未知应用权限，所以无法安装，请前往官网下载。');
        return false;
      } else {
        await Permission.requestInstallPackages.request();
        return true;
      }
    }
  }

  ///检查是否有权限
  static checkStoragePermission() async {
    //检查是否已有读写内存权限
    if (Platform.isAndroid) {
      PermissionStatus storageStatus = await Permission.storage.status;
      if (storageStatus == PermissionStatus.granted) {
        return true;
      } else if (storageStatus == PermissionStatus.permanentlyDenied) {
        CommonUtils.showText('您拒绝了存储权限，未避免账号丢失，请前往设置中打开存储权限');
        return false;
      } else {
        await Permission.storage.request();
        return true;
      }
    }
  }

  static renderFixedNumber(double value) {
    var tips;
    if (value >= 10000) {
      var newvalue = (value / 1000) / 10.round();
      tips = formatNum(newvalue, 1) + "万";
    // } else if (value >= 1000) {
    //   var newvalue = (value / 100) / 10.round();
    //   tips = formatNum(newvalue, 1) + "千";
    } else {
      tips = value.toString().split('.')[0];
    }
    return tips;
  }

  static formatNum(double number, int postion) {
    if ((number.toString().length - number.toString().lastIndexOf(".") - 1) <
        postion) {
      //小数点后有几位小数
      return number
          .toStringAsFixed(postion)
          .substring(0, number.toString().lastIndexOf(".") + postion + 1)
          .toString();
    } else {
      return number
          .toString()
          .substring(0, number.toString().lastIndexOf(".") + postion + 1)
          .toString();
    }
  }

  static launchURL(String url) async {
    try {
      await launch(url, forceSafariVC: false);
    } catch (e) {
      BotToast.showText(text: '网址错误');
    }
  }

  static String getRealHash([String? value]) {
    if (kIsWeb) {
      var currentHash = html.window.location.hash.replaceAll('#', '');
      if (value == null) return currentHash;
      if (currentHash.lastIndexOf('/') == currentHash.length - 1) {
        return '$currentHash$value';
      } else {
        return '$currentHash/$value';
      }
    } else {
      var location = '${AppGlobal.appRouter.location}/$value';
      if (value == null) return AppGlobal.appRouter.location;
      if (location.contains('//')) {
        var current = location.replaceAll('//', '/');
        return current;
      } else {
        return location;
      }
    }
  }

  static void debugPrint(value) {
    LogUtil.i(value);
  }

  static List<List> tasks = [];
  static List<bool> wdsRuningStatuses = List.generate(5, (index) => false);

  static String randomId(int range) {
    String str = "";
    List<String> arr = [
      "0",
      "1",
      "2",
      "3",
      "4",
      "5",
      "6",
      "7",
      "8",
      "9",
      "a",
      "b",
      "c",
      "d",
      "e",
      "f",
      "g",
      "h",
      "i",
      "j",
      "k",
      "l",
      "m",
      "n",
      "o",
      "p",
      "q",
      "r",
      "s",
      "t",
      "u",
      "v",
      "w",
      "x",
      "y",
      "z",
      "A",
      "B",
      "C",
      "D",
      "E",
      "F",
      "G",
      "H",
      "I",
      "J",
      "K",
      "L",
      "M",
      "N",
      "O",
      "P",
      "Q",
      "R",
      "S",
      "T",
      "U",
      "V",
      "W",
      "X",
      "Y",
      "Z"
    ];
    for (int i = 0; i < range; i++) {
      int pos = Random().nextInt(arr.length - 1);
      str += arr[pos];
    }
    return str;
  }

  static String gvMD5(String data) {
    var content = const Utf8Encoder().convert(data);
    var digest = md5.convert(content);
    var text = hex.encode(digest.bytes);
    return text;
  }

  static String getRandomThumb() {
    int random = Random().nextInt(29);
    return 'assets/images/random/${random + 1}.jpg';
  }

  static String gvSha256(String data) {
    var content = const Utf8Encoder().convert(data);
    var digest = sha256.convert(content);
    var text = hex.encode(digest.bytes);
    return text;
  }

  static getThumb(dynamic data) {
    if (data['thumb'] != null && data['thumb'] != '') {
      return data['thumb'];
    } else if (data['cover_thumb_vertical'] != null &&
        data['cover_thumb_vertical'] != '') {
      return data['cover_thumb_vertical'];
    } else if (data['cover_thumb_horizontal'] != null &&
        data['cover_thumb_horizontal'] != '') {
      return data['cover_thumb_horizontal'];
    } else if (data['cover_zip_vertical'] != null &&
        data['cover_zip_vertical'] != '') {
      return data['cover_zip_vertical'];
    } else if (data['cover_zip_horizontal'] != null &&
        data['cover_zip_horizontal'] != '') {
      return data['cover_zip_horizontal'];
    } else if (data['cover_original_vertical'] != null &&
        data['cover_original_vertical'] != '') {
      return data['cover_original_vertical'];
    } else {
      return data['cover_original_horizontal'];
    }
  }
}

class RelativeDateFormat {
  static const num oneMinute = 60000;
  static const num oneHour = 3600000;
  static const num oneDay = 86400000;
  static const num oneWeek = 604800000;

  static const String oneSecondAgo = "秒前";
  static const String oneMinuteAgo = "分钟前";
  static const String oneHourAgo = "小时前";
  static const String oneDayAgo = "天前";
  static const String oneMonthAgo = "月前";
  static const String oneYearAgo = "年前";

//时间转换
  static String format(DateTime date) {
    num delta =
        DateTime.now().millisecondsSinceEpoch - date.millisecondsSinceEpoch;

    if (delta < 1 * oneMinute) {
      num seconds = toSeconds(delta);
      return (seconds <= 0 ? 1 : seconds).toInt().toString() + oneSecondAgo;
    }
    if (delta < 60 * oneMinute) {
      num minutes = toMinutes(delta);
      return (minutes <= 0 ? 1 : minutes).toInt().toString() + oneMinuteAgo;
    }
    if (delta < 24 * oneHour) {
      num hours = toHours(delta);
      return (hours <= 0 ? 1 : hours).toInt().toString() + oneHourAgo;
    }
    if (delta < 48 * oneHour) {
      return "昨天";
    }
    if (delta < 30 * oneDay) {
      num days = toDays(delta);
      return (days <= 0 ? 1 : days).toInt().toString() + oneDayAgo;
    }
    if (delta < 12 * 4 * oneWeek) {
      num months = toMonths(delta);
      return (months <= 0 ? 1 : months).toInt().toString() + oneMonthAgo;
    } else {
      num years = toYears(delta);
      return (years <= 0 ? 1 : years).toInt().toString() + oneYearAgo;
    }
  }

  static num toSeconds(num date) {
    return date / 1000;
  }

  static num toMinutes(num date) {
    return toSeconds(date) / 60;
  }

  static num toHours(num date) {
    return toMinutes(date) / 60;
  }

  static num toDays(num date) {
    return toHours(date) / 24;
  }

  static num toMonths(num date) {
    return toDays(date) / 30;
  }

  static num toYears(num date) {
    return toMonths(date) / 12;
  }
}
