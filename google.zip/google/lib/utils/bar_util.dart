import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class BarUtil {
  static void setBarUi(
      {Color color = Colors.transparent, Brightness status = Brightness.dark}) {
    if (!kIsWeb) {
      if (Platform.isAndroid) {
        SystemUiOverlayStyle systemUiOverlayStyle = SystemUiOverlayStyle(
            systemNavigationBarColor: Colors.black,
            systemNavigationBarIconBrightness: Brightness.dark,
            statusBarColor: color,
            statusBarBrightness: status,
            statusBarIconBrightness: status);
        SystemChrome.setSystemUIOverlayStyle(systemUiOverlayStyle);
      }
    }
  }
}
