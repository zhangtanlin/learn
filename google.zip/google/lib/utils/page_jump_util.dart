import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:iaimei/global.dart';
import 'package:iaimei/model/atlas_item_model.dart';
import 'package:iaimei/model/atlas_series_item_model.dart';
import 'package:iaimei/model/comics_brief_model.dart';
import 'package:iaimei/model/comics_index_list_model.dart';
import 'package:iaimei/model/comics_item_model.dart';
import 'package:iaimei/model/img_preview_info.dart';
import 'package:iaimei/model/novel_brief_model.dart';
import 'package:iaimei/model/novel_item_model.dart';
import 'package:iaimei/model/novel_list_model.dart';
import 'package:iaimei/model/short_video_info.dart';
import 'package:iaimei/router/routers.dart';

class PageJumpUtil {
  static void forwardToComicsDetailPage(
      BuildContext context, ComicsItemModel item) {
    context.push("/" + Routes.comicsDetail, extra: item);
  }

  static void forwardToNovelDetailPage(
      BuildContext context, NovelItemModel item) {
    context.push("/" + Routes.novelDetail, extra: item);
  }

  static void forwardToSearchPage(BuildContext context) {
    context.push("/" + Routes.search);
  }

  static void forwardToFilterPage(BuildContext context) {
    context.push("/" + Routes.filter);
  }

  static void forwardToSortPage(BuildContext context) {
    context.push("/" + Routes.clsIdx);
  }

  static void forwardToSharePage(BuildContext context) {
    context.push("/" + Routes.spread);
  }

  static void forwardToNovelSeriesPage(
      BuildContext context, NovelListModel novelListModel) {
    context.push("/" + Routes.novelSeries, extra: novelListModel);
  }

  static void forwardToNovelReaderPage(
      BuildContext context, NovelItemModel item, NovelBriefModel briefModel) {
    context.push("/" + Routes.novelReader, extra: briefModel);
    AppGlobal.storeHistory(BrowseKey.novel, item.toJson());
  }

  static void forwardToComicsSeriesPage(
      BuildContext context, ComicsListModel comicsListModel) {
    context.push("/" + Routes.comicsSeries, extra: comicsListModel);
  }

  static void forwardToAtlasPage(BuildContext context) {
    context.push("/" + Routes.atlas);
  }

  static void forwardToAtlasSeriesPage(
      BuildContext context, AtlasSeriesItemModel atlasSeriesItemModel) {
    context.push("/" + Routes.atlasSeries, extra: atlasSeriesItemModel);
  }

  static void forwardToAtlasDetailPage(
      BuildContext context, AtlasItemModel atlasItemModel) {
    context.push("/" + Routes.atlasDetail, extra: atlasItemModel);
    AppGlobal.storeHistory(BrowseKey.imgAsset, atlasItemModel.toJson());
  }

  static void forwardToComicsReaderPage(
      BuildContext context, ComicsItemModel item, ComicsBriefModel briefModel) {
    context.push("/" + Routes.comicsReader, extra: briefModel);
    AppGlobal.storeHistory(BrowseKey.comics, item.toJson());
  }

  static void forwardToBuyVipPage(BuildContext context) {
    context.push("/" + Routes.rechargeVip);
  }

  static void forwardToRechargeCoinsPage(BuildContext context) {
    context.push("/" + Routes.rechargeCoins);
  }

  static void forwardToUserHomePage(BuildContext context, dynamic uid) {
    context.push("/" + Routes.userhome, extra: uid);
  }

  static void forwardToWebViewPage(
      BuildContext context, Map<String, dynamic> extraInfo) {
    context.push("/" + Routes.webview, extra: extraInfo);
  }

  static void forwardToChatRankPage(BuildContext context) {
    context.push("/" + Routes.chatranking);
  }

  static void forwardToChatRecList(BuildContext context) {
    context.push("/" + Routes.chatRecList);
  }

  static void forwardToAppCenter(BuildContext context) {
    context.push("/" + Routes.appCenter);
  }

  static void forwardToImgPreviewPage(
      BuildContext context, ImgPreviewInfo imgPreviewInfo) {
    context.push("/" + Routes.imagePreview, extra: imgPreviewInfo);
  }

  static void forwardToShortVideoPage(
      BuildContext context, ShortVideoInfo shortVideoInfo) {
    context.push("/" + Routes.shortVideoPlay, extra: shortVideoInfo);
  }

  static void forwardToDatingDetailPage(BuildContext context, int id) {
    context.push("/" + Routes.datingDetail, extra: {'info_id': id});
  }

  static void forwardToChatDetailPage(BuildContext context, int id) {
    context.push("/" + Routes.chatDetail, extra: {'info_id': id});
  }
}
