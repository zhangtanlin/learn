import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:iaimei/components/common/scale_pageroute.dart';
import 'package:iaimei/global.dart';
import 'package:iaimei/model/video_model.dart';
import 'package:iaimei/pages/video/short_video_play_page.dart';
import 'package:iaimei/utils/crypto.dart';
import 'package:iaimei/utils/list_util.dart';
import 'package:iaimei/utils/log_util.dart';
import 'package:iaimei/utils/shelf_proxy.dart';
import 'package:iaimei/utils/string_util.dart';
import 'package:universal_html/html.dart' as html;

class VideoUtil {
  static String getAvailableVideoUrl(VideoModel? videoModel) {
    String url = '';
    if (videoModel != null) {
      if (StringUtil.isNotEmpty(videoModel.payUrlFull)) {
        url = videoModel.payUrlFull;
        LogUtil.i("-------full---------");
      } else if (StringUtil.isNotEmpty(videoModel.playUrl)) {
        url = videoModel.playUrl;
        LogUtil.i("-------preUrl---------");
      }
    }
    return url;
  }

  static bool isFreeVideo(VideoModel? videoModel) {
    return videoModel != null &&
        (videoModel.isFree == 0 ||
            StringUtil.isNotEmpty(videoModel.payUrlFull));
  }

  static String getVideoTips(VideoModel? videoModel) {
    String tips = '';
    if (videoModel != null && StringUtil.isEmpty(videoModel.payUrlFull)) {
      if (videoModel.isFree == 1) {
        tips = '开通VIP即可观看完整版';
      } else if (videoModel.isFree == 2) {
        tips = '购买后可永久观看完整版';
      }
    }
    return tips;
  }

  static Future<String> getRealVideoUrl(VideoModel? videoModel,
      {bool isLocal = false, bool isNew = false}) async {
    String resultUrl = '';
    String preUrl = getAvailableVideoUrl(videoModel);
    if (kIsWeb) {
      if (AppGlobal.m3u8Encrypt == '1') {
        Response res = await Dio().get(preUrl);
        String decrypted = PlatformAwareCrypto.decryptM3U8(res.data);
        final _blob = html.Blob([decrypted], 'application/x-mpegURL', 'native');
        final tempUrl = html.Url.createObjectUrl(_blob);
        resultUrl = tempUrl;
      } else {
        resultUrl = preUrl;
      }
    } else if (!isLocal) {
      if (AppGlobal.m3u8Encrypt == '1') {
        Map proxyConfig = await createServer(preUrl);
        String proxyUrl =
            preUrl.replaceAll(proxyConfig['origin'], proxyConfig['localproxy']);
        resultUrl = proxyUrl;
      } else {
        resultUrl = preUrl;
      }
    } else {
      String tempUrl = await createStaticServer(preUrl);
      resultUrl = tempUrl;
    }
    return resultUrl;
  }

  static void jumpToVideoPlayer(
      BuildContext context, List<VideoModel> videoList,
      {int curIndex = 0, int type = 1}) {
    if (ListUtil.isEmpty(videoList)) return;
    LogUtil.i("--------jumpToVideoPlayer---------");
    Navigator.push(
      context,
      ScalePageRoute(
        widget: ShortVideoPlayPage(
          curIndex: curIndex,
          dataList: videoList,
        ),
      ),
    );
  }

// if (type == 1) {
//   //长视频
//   HttpHelper.getVideoDetail(videoList[0].id, (data) {
//     if (data != null) {
//       AppGlobal.storeHistory(BrowseKey.video, data);
//       VideoModel videoModel = VideoModel.fromJson(data);
//       Navigator.push(
//         context,
//         ScalePageRoute(
//           widget: LongVideoPlayPage(
//             videoDetail: videoModel,
//           ),
//         ),
//       );
//     }
//   }, (error) {
//     ToastWidget.showToast(
//         error.message ?? StringRes.str_video_detail_get_fail);
//   });
// } else if (type == 2) {
// }

//短视频
// PageJumpUtil.forwardToShortVideoPage(
//     context, ShortVideoInfo(curIndex: curIndex, dataList: videoList));
// }

}
