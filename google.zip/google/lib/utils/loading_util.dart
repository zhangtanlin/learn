import 'package:bot_toast/bot_toast.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/style/app_text_style.dart';
import 'package:iaimei/utils/string_util.dart';
import 'package:iaimei/widget/space_widget.dart';

class LoadingUtil {
  static Function showLoading(
      {String? tips,
      Color bgColor = Colors.black26,
      Color? loadBgColor,
      Color loadColor = Colors.white,
      double? width,
      double? height,
      TextStyle? textStyle}) {
    return BotToast.showLoading(
        backgroundColor: bgColor,
        wrapToastAnimation: (AnimationController animation, fc, Widget child) {
          return Container(
            width: width ?? DimenRes.dimen_80,
            height: height ?? DimenRes.dimen_80,
            decoration: BoxDecoration(
                color: loadBgColor ?? Colors.black.withOpacity(0.6),
                borderRadius: BorderRadius.circular(DimenRes.radius(5))),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                _loadAnimSection(loadColor),
                StringUtil.isNotEmpty(tips)
                    ? SpaceWidget(
                        vSpace: DimenRes.dimen_5,
                      )
                    : const SizedBox(),
                StringUtil.isNotEmpty(tips)
                    ? _loadTipsSection(tips!,
                        textStyle ?? AppTextStyle.build(Colors.white, 12))
                    : const SizedBox()
              ],
            ),
          );
        });
  }

  static Widget _loadAnimSection(Color loadColor) {
    return SpinKitCircle(
      color: loadColor,
      size: 45.0,
    );
  }

  static Text _loadTipsSection(String tips, TextStyle textStyle) {
    return Text(
      StringUtil.isNotEmpty(tips) ? tips : '',
      maxLines: 1,
      overflow: TextOverflow.ellipsis,
      style: textStyle,
    );
  }

  static void closeLoading() {
    return BotToast.closeAllLoading();
  }
}
