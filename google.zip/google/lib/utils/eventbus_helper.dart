import 'package:event_bus/event_bus.dart';

class EventBusHelper{

  static EventBus? _eventBus;

  //获取单例
  static EventBus getInstance(){
    _eventBus ??= EventBus();
    return _eventBus!;
  }

}