import 'package:iaimei/res/img_res.dart';

class BadgeUtil {

  static getVideoTypeBadgeImgPath(int type) {
    if (type == 1) {
      return ImgRes.IC_BADGE_VIP;
    } else if (type == 2) {
      return ImgRes.IC_BADGE_COIN;
    }
    return ImgRes.IC_BADGE_FREE;
  }
}
