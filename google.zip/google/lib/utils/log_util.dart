import 'dart:developer';

import 'package:iaimei/app_const.dart';


class LogUtil {
  static void i(dynamic obj, {String prefix = AppConst.logPrefix}) {
    if (AppConst.isDebug) {
      log(prefix + obj.toString());
    }
  }
}
