import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:iaimei/components/common/commonelements.dart';
import 'package:iaimei/model/atlas_item_model.dart';
import 'package:iaimei/model/atlas_series_item_model.dart';
import 'package:iaimei/model/comics_brief_model.dart';
import 'package:iaimei/model/comics_index_list_model.dart';
import 'package:iaimei/model/comics_item_model.dart';
import 'package:iaimei/model/img_preview_info.dart';
import 'package:iaimei/model/indexlist.dart';
import 'package:iaimei/model/novel_brief_model.dart';
import 'package:iaimei/model/novel_item_model.dart';
import 'package:iaimei/model/novel_list_model.dart';
import 'package:iaimei/model/short_video_info.dart';
import 'package:iaimei/pages/atlas/atlas_detail_page.dart';
import 'package:iaimei/pages/atlas/atlas_home_page.dart';
import 'package:iaimei/pages/atlas/atlas_series_list_page.dart';
import 'package:iaimei/pages/auth/auth_index.dart';
import 'package:iaimei/pages/auth/date_love_info.dart';
import 'package:iaimei/pages/chat/chat_detail_page.dart';
import 'package:iaimei/pages/chat/chat_home_page.dart';
import 'package:iaimei/pages/chat/chat_order.dart';
import 'package:iaimei/pages/chat/chat_ranking_page.dart';
import 'package:iaimei/pages/chat/chat_rec_list_page.dart';
import 'package:iaimei/pages/class/index.dart';
import 'package:iaimei/pages/comics/comics_detail_page.dart';
import 'package:iaimei/pages/comics/comics_home_page.dart';
import 'package:iaimei/pages/comics/comics_reader.dart';
import 'package:iaimei/pages/comics/comics_series_list_page.dart';
import 'package:iaimei/pages/creator/create_center.dart';
import 'package:iaimei/pages/creator/publish_work.dart';
import 'package:iaimei/pages/dating/dating_detail_page.dart';
import 'package:iaimei/pages/dating/dating_filter_page.dart';
import 'package:iaimei/pages/dating/dating_home_page.dart';
import 'package:iaimei/pages/dating/dating_order.dart';
import 'package:iaimei/pages/dating/feedback.dart';
import 'package:iaimei/pages/dating/report_detail.dart';
import 'package:iaimei/pages/dating/report_send.dart';
import 'package:iaimei/pages/filter/index.dart';
import 'package:iaimei/pages/income/agency_page.dart';
import 'package:iaimei/pages/income/funding_details.dart';
import 'package:iaimei/pages/income/income_page.dart';
import 'package:iaimei/pages/income/recharge_coins.dart';
import 'package:iaimei/pages/income/recharge_vip.dart';
import 'package:iaimei/pages/income/spread_page.dart';
import 'package:iaimei/pages/income/withdraw_page.dart';
import 'package:iaimei/pages/login/index.dart';
import 'package:iaimei/pages/mv/actress_detail.dart';
import 'package:iaimei/pages/mv/author_index.dart';
import 'package:iaimei/pages/mv/mv_attent_List_page.dart';
import 'package:iaimei/pages/mv/mv_index_page.dart';
import 'package:iaimei/pages/mv/mv_series_detail_page.dart';
import 'package:iaimei/pages/novel/novel_detail_page.dart';
import 'package:iaimei/pages/novel/novel_home_page.dart';
import 'package:iaimei/pages/novel/novel_reader.dart';
import 'package:iaimei/pages/novel/novel_series_list_page.dart';
import 'package:iaimei/pages/personal_center/app.dart';
import 'package:iaimei/pages/personal_center/browse_history.dart';
import 'package:iaimei/pages/personal_center/cache_history.dart';
import 'package:iaimei/pages/personal_center/collect_buy.dart';
import 'package:iaimei/pages/personal_center/contact.dart';
import 'package:iaimei/pages/personal_center/fans_follow_club.dart';
import 'package:iaimei/pages/personal_center/index.dart';
import 'package:iaimei/pages/personal_center/msg.dart';
import 'package:iaimei/pages/personal_center/msg_board.dart';
import 'package:iaimei/pages/personal_center/online_service.dart';
import 'package:iaimei/pages/personal_center/personal_info.dart';
import 'package:iaimei/pages/personal_center/set.dart';
import 'package:iaimei/pages/personal_center/set_nickname.dart';
import 'package:iaimei/pages/personal_center/set_phone.dart';
import 'package:iaimei/pages/personal_center/set_pwd.dart';
import 'package:iaimei/pages/mv/mv_rank_index_page.dart';
import 'package:iaimei/pages/search/search_page.dart';
import 'package:iaimei/pages/splash_page.dart';
import 'package:iaimei/pages/test/lng_video_player.dart';
import 'package:iaimei/pages/test/page_a.dart';
import 'package:iaimei/pages/user_home/user_home_index.dart';
import 'package:iaimei/pages/video/short_video_play_page.dart';
import 'package:iaimei/pages/webview_page.dart';
import 'package:iaimei/widget/image_preview.dart';
import 'package:logging/logging.dart';

class Routes {
  static String login = 'login'; // 登录
  static String search = 'search'; // 搜索
  static String clsIdx = 'clsIdx'; // 分类
  static String dating = 'dating'; // 约炮
  static String filter = 'filter'; // 筛选
  static String comics = 'comics'; // 漫画
  static String comicsSeries = 'comicsSeries';
  static String comicsDetail = 'comicsDetail';
  static String comicsReader = 'comicsReader';
  static String atlas = 'atlas'; // 图集
  static String atlasSeries = 'atlasSeries'; // 图集系列
  static String atlasDetail = 'atlasDetail'; // 图集系列
  static String ranking = 'ranking'; // 排行榜
  static String novel = 'novel'; // 小说
  static String novelSeries = 'novelSeries'; // 小说系列
  static String novelDetail = 'novelDetail'; // 小说详情
  static String novelReader = 'novelReader'; // 小说详情
  static String chatHome = 'chat'; // 裸聊
  static String authorIndex = 'authorIndex'; // 女优\原创列表
  static String actressDetail = 'actressDetail'; // 女优详情
  static String datingDetail = 'datingDetail'; // 约炮-信息
  static String datingOrder = 'datingOrder/:id'; // 约炮-订单联系方式
  static String reportDetail = 'reportDetail/:id'; // 约炮-验车报告详情
  static String reportSend = 'reportSend/:id'; // 约炮-发送骑车报告
  static String feedBack = 'feedBack/:id'; // 约炮-投诉
  static String userhome = 'userhome'; // 用户主页
  static String personalCenter = 'personalCenter'; // 个人中心
  static String mvIndexPage = 'mvIndexPage'; // 综合页面
  static String mvListViewPage = 'mvListViewPage'; // 列表页（瀑布流、非瀑布流）
  static String income = 'income'; // 收益
  static String spread = 'spread'; // 推广
  static String agency = 'agency'; // 代理
  static String spreadRecord = 'spreadRecord'; // 推广记录
  static String withdraw = 'withdraw'; // 提现
  static String fundingDetails = 'funding/:index'; // 资金明细

  static String creator = 'creator'; // 创作中心
  static String uploadWork = 'uploadWork'; // 上传作品
  static String attentList = 'attentList'; // 关注列表

  static String msg = 'msg'; // 消息中心
  static String set = 'set'; // 设置
  static String msgBoard = 'msgBoard'; // 留言板
  static String personalInfo = 'personalInfo'; // 个人信息
  static String chatRecList = 'chatRecList'; // 裸聊列表页
  static String chatDetail = 'chatDetail'; // 裸聊详情页
  static String chatOrder = 'chatOrder'; // 裸聊妹子
  static String chatranking = 'chatranking'; // 裸聊排行榜

  static String setPwd = 'setPwd'; // 设置密码
  static String setNickname = 'setNickname'; // 设置昵称
  static String setPhone = 'setPhone'; // 设置手机号
  static String fansFollowClub = 'fansFollowClub/:type'; // 个人中心-粉丝/关注/粉丝团
  static String rechargeVip = 'rechargeVip'; // 会员中心
  static String rechargeCoins = 'rechargeCoins'; // 余额充值
  static String onlineService = 'onlineService'; // 在线客服
  static String contact = 'contact'; // 联系官方
  static String collectBuy = 'collectBuy/:type'; // 我的收藏/我的购买
  static String appCenter = 'appCenter'; // 应用推荐
  static String datingFilter = 'datingFilter'; // 同城约炮-筛选
  static String specialpage = 'specialpage'; // 特价

  static String authIndex = 'authIndex'; // 认证
  static String dateLoveInfo = 'dateLoveInfo'; // 约炮信息

  static String browseHistory = 'browseHistory'; // 浏览记录
  static String cacheHistory = 'cacheHistory'; // 下载缓存
  static String testPage = 'testPage';
  static String imagePreview = 'imagePreview';
  static String webview = 'webview';
  static String videoPlayer = 'videoPlayer';
  static String shortVideoPlay = 'shortVideoPlay';
  static String pageA = 'pageA';

  static List<GoRoute> getDetailRoutes() {
    return [

    ];
  }

  static GoRouter init() {
    List<GoRoute> rootRoutes = [
      GoRoute(
          path: webview,
          builder: (context, state) {
            final args = state.extra as Map<String, dynamic>;
            return WebViewPage(
              args: args,
            );
          }),
      GoRoute(
          path: imagePreview,
          builder: (context, state) {
            final args = state.extra as ImgPreviewInfo;
            return ImagePreview(
              imgItems: args.imgItems,
              defaultIndex: args.defaultIndex,
              pageChanged: args.pageChanged,
              direction: args.direction,
              decoration: args.decoration,
            );
          }),

      GoRoute(
          path: shortVideoPlay,
          builder: (context, state) {
            final shortVideoInfo = state.extra as ShortVideoInfo;
            return ShortVideoPlayPage(
              curIndex: shortVideoInfo.curIndex,
              dataList: shortVideoInfo.dataList,
            );
          }),
      GoRoute(
        path: login,
        builder: (context, state) => const LoginPage(),
      ),
      GoRoute(
        path: novel,
        builder: (context, state) => const NovelHomePage(),
      ),
      GoRoute(
        path: novelSeries,
        builder: (context, state) =>
            NovelSeriesListPage(data: state.extra as NovelListModel),
      ),
      GoRoute(
        path: novelDetail,
        builder: (context, state) => NovelDetailPage(
          item: state.extra as NovelItemModel,
        ),
      ),
      GoRoute(
        path: novelReader,
        builder: (context, state) => NovelReader(
          item: state.extra as NovelBriefModel,
        ),
      ),
      GoRoute(
        path: mvIndexPage,
        builder: (context, state) => MvIndexPage(
          item: state.extra! as Menu,
        ),
        routes: getDetailRoutes()
      ),
      GoRoute(
        path: mvListViewPage,
        builder: (context, state) => MvSeriesDetailPage(
          params: state.extra! as WaterfallExtra,
        ),
        routes: getDetailRoutes()
      ),
      GoRoute(
        path: ranking,
        builder: (context, state) => MvRankIndexPage(
          item: state.extra! as Menu,
        ),
      ),
      GoRoute(
        path: chatranking,
        builder: (context, state) => const ChatRankingPage(),
      ),
      GoRoute(
        path: chatRecList,
        builder: (context, state) => const ChatRecListPage(),
      ),
      GoRoute(
        path: chatDetail,
        builder: (context, state) =>
            ChatDetailPage(param: state.extra as Map<String, dynamic>),
      ),
      GoRoute(
        path: chatOrder,
        builder: (context, state) => ChatOrder(id: state.queryParams['id']),
      ),
      GoRoute(
        path: authorIndex,
        builder: (context, state) => AuthorIndex(type: '${state.extra}'),
      ),
      GoRoute(
        path: actressDetail,
        builder: (context, state) => ActressDetail(actor: '${state.extra}'),
      ),
      GoRoute(
        path: chatHome,
        builder: (context, state) =>  ChatHomePage(),
        routes: [
        ]
      ),
      GoRoute(
        path: userhome,
        builder: (context, state) => UserHomeIndex(uid: state.extra),
      ),
      GoRoute(
        path: attentList,
        builder: (context, state) => const MvAttentListPage(),
      ),
      GoRoute(
        path: search,
        builder: (context, state) => const SearchPage(),
      ),
      GoRoute(
        path: clsIdx,
        builder: (context, state) => const ClassIndex(),
      ),
      GoRoute(
        path: filter,
        builder: (context, state) => const FilterPage(),
      ),
      GoRoute(
        path: atlas,
        builder: (context, state) => const AtlasHomePage(),
      ),
      GoRoute(
          path: comics,
          builder: (context, state) => const ComicsHomePage()),
      GoRoute(
          path: comicsSeries,
          builder: (context, state) => ComicsSeriesListPage(
                data: state.extra as ComicsListModel,
              )),
      GoRoute(
          path: atlasSeries,
          builder: (context, state) =>
              AtlasSeriesListPage(data: state.extra as AtlasSeriesItemModel)),
      GoRoute(
          path: comicsDetail,
          builder: (context, state) => ComicsDetailPage(
                item: state.extra as ComicsItemModel,
              )),
      GoRoute(
          path: atlasDetail,
          builder: (context, state) => AtlasDetailPage(
                item: state.extra as AtlasItemModel,
              )),
      GoRoute(
          path: comicsReader,
          builder: (context, state) {
            ComicsBriefModel args = state.extra as ComicsBriefModel;
            return ComicsReader(item: args);
          }),
      GoRoute(
        path: dating,
        builder: (context, state) => const DatingHomePage(),
      ),
      GoRoute(
        path: datingDetail,
        builder: (context, state) =>
            DatingDetailPage(param: state.extra as Map<String, dynamic>),
      ),
      GoRoute(
        path: datingOrder,
        builder: (context, state) => DatingOrder(
          id: state.params['id'].toString(),
        ),
      ),
      GoRoute(
        path: reportDetail,
        builder: (context, state) => ReportDetail(
          id: state.params['id'].toString(),
        ),
      ),
      GoRoute(
        path: reportSend,
        builder: (context, state) => ReportSend(
          id: state.params['id'].toString(),
        ),
      ),
      GoRoute(
        path: feedBack,
        builder: (context, state) => FeedBack(
          id: state.params['id'].toString(),
        ),
      ),
      GoRoute(
        path: personalCenter,
        builder: (context, state) => const PersonalCenter(),
      ),
      GoRoute(
        path: income,
        builder: (context, state) => const IncomePage(),
      ),
      GoRoute(
        path: spread,
        builder: (context, state) => const SpreadPage(),
      ),
      GoRoute(
        path: agency,
        builder: (context, state) => const AgencyPage(),
      ),
      GoRoute(
        path: spreadRecord,
        builder: (context, state) => const SpreadRecord(),
      ),
      GoRoute(
        path: withdraw,
        builder: (context, state) => const WithdrawPage(),
      ),
      GoRoute(
        path: fundingDetails,
        builder: (context, state) => FundingDetails(
          index: int.parse(state.params['index'].toString()),
        ),
      ),
      GoRoute(
        path: creator,
        builder: (context, state) => const CreateCenter(),
      ),
      GoRoute(
        path: uploadWork,
        builder: (context, state) => const PublishWork(),
      ),
      GoRoute(
        path: msg,
        builder: (context, state) => const Msg(),
      ),
      GoRoute(
        path: set,
        builder: (context, state) => const Set(),
      ),
      GoRoute(
        path: msgBoard,
        builder: (context, state) => const MsgBoard(),
      ),
      GoRoute(
        path: personalInfo,
        builder: (context, state) => const PersonalInfo(),
      ),
      GoRoute(
        path: setPwd,
        builder: (context, state) => const SetPwd(),
      ),
      GoRoute(
        path: setNickname,
        builder: (context, state) => const SetNickname(),
      ),
      GoRoute(
        path: setPhone,
        builder: (context, state) => const SetPhone(),
      ),
      GoRoute(
        path: fansFollowClub,
        builder: (context, state) => FansFollowClub(
          type: int.parse(state.params['type'].toString()),
        ),
      ),
      GoRoute(
        path: rechargeVip,
        builder: (context, state) => const RechargeVip(),
      ),
      GoRoute(
        path: rechargeCoins,
        builder: (context, state) => const RechargeCoins(),
      ),
      GoRoute(
        path: onlineService,
        builder: (context, state) => const OnlineService(),
      ),
      GoRoute(
        path: contact,
        builder: (context, state) => const Contact(),
      ),
      GoRoute(
        path: collectBuy,
        builder: (context, state) => CollectBuy(
          type: int.parse(state.params['type'].toString()),
        ),
      ),
      GoRoute(
        path: appCenter,
        builder: (context, state) => const App(),
      ),
      GoRoute(
        path: datingFilter,
        builder: (context, state) => const DatingFilterPage(),
      ),
      GoRoute(
        path: authIndex,
        builder: (context, state) => const AuthIndex(),
      ),
      GoRoute(
        path: dateLoveInfo,
        builder: (context, state) => const DateLoveInfo(),
      ),
      GoRoute(
        path: browseHistory,
        builder: (context, state) => const BrowseHistory(),
      ),
      GoRoute(
        path: cacheHistory,
        builder: (context, state) => const CacheHistory(),
      ),
      GoRoute(
        path: videoPlayer,
        builder: (context, state) => const LngVideoPlayer(),
      ),
      GoRoute(
        path: testPage,
        builder: (context, state) => const PageA(),
        routes: [
          GoRoute(
            path: videoPlayer,
            builder: (context, state) => const LngVideoPlayer(),
          ),
        ]
      ),
    ];
    // rootRoutes.addAll(getDetailRoutes());
    return GoRouter(
        routerNeglect: true,
        routes: [
          GoRoute(
              path: '/',
              builder: (context, state) => const SplashPage(),
              routes: rootRoutes)
        ],
        observers: [MyNavObserver()],
        // errorBuilder: (context, state) => NotFound(error: state.error)
    );
  }
}

class MyNavObserver extends NavigatorObserver {
  MyNavObserver() {
    log.onRecord.listen((LogRecord e) => debugPrint('$e'));
  }

  /// The logged message.
  final Logger log = Logger('MyNavObserver');

  @override
  void didPush(Route<dynamic> route, Route<dynamic>? previousRoute) =>
      log.info('didPush: ${route.str}, previousRoute= ${previousRoute?.str}');

  @override
  void didPop(Route<dynamic> route, Route<dynamic>? previousRoute) =>
      log.info('didPop: ${route.str}, previousRoute= ${previousRoute?.str}');

  @override
  void didRemove(Route<dynamic> route, Route<dynamic>? previousRoute) =>
      log.info('didRemove: ${route.str}, previousRoute= ${previousRoute?.str}');

  @override
  void didReplace({Route<dynamic>? newRoute, Route<dynamic>? oldRoute}) =>
      log.info('didReplace: new= ${newRoute?.str}, old= ${oldRoute?.str}');

  @override
  void didStartUserGesture(
      Route<dynamic>? route,
      Route<dynamic>? previousRoute,
      ) =>
      log.info('didStartUserGesture: ${route?.str}, '
          'previousRoute= ${previousRoute?.str}');

  @override
  void didStopUserGesture() => log.info('didStopUserGesture');
}

extension on Route<dynamic> {
  String get str => 'route(${settings.name}: ${settings.arguments})';
}
