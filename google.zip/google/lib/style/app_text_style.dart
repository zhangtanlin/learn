// ignore_for_file: non_constant_identifier_names

import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:iaimei/res/color_res.dart';
import 'package:iaimei/res/dimen_res.dart';

class AppTextStyle {
  static TextStyle c999999_s12 = build(ColorRes.color_999999, 12);

  static TextStyle c999999_s14 = build(ColorRes.color_999999, 14);

  static TextStyle c999999_s15 = build(ColorRes.color_999999, 15);

  static TextStyle cfef693_s12 = build(ColorRes.color_fef693, 12);

  static TextStyle c30313f_s18_bold =
      build(ColorRes.color_30313f, 18, fontWeight: FontWeight.bold);

  static TextStyle cff00b3_s18_bold =
      build(ColorRes.color_ff00b3, 18, fontWeight: FontWeight.bold);

  static TextStyle cff00b3_s15_bold =
      build(ColorRes.color_ff00b3, 15, fontWeight: FontWeight.bold);

  static TextStyle c333333_s18_bold =
      build(ColorRes.color_333333, 18, fontWeight: FontWeight.bold);

  static TextStyle c333333_s18 = build(ColorRes.color_333333, 18);

  static TextStyle white_s10 = build(Colors.white, 10);

  static TextStyle white_s11 = build(Colors.white, 11);

  static TextStyle white_s12 = build(Colors.white, 12);

  static TextStyle white_s14_bold =
      build(Colors.white, 14, fontWeight: FontWeight.w500);

  static TextStyle white_s13 = build(Colors.white, 13);

  static TextStyle white_s14 = build(Colors.white, 14);

  static TextStyle white_s15 = build(Colors.white, 15);

  static TextStyle white_s15_bold =
      build(Colors.white, 15, fontWeight: FontWeight.w500);

  static TextStyle white_s16 = build(Colors.white, 16);

  static TextStyle white_s16_bold = build(Colors.white, 16,fontWeight: FontWeight.bold);

  static TextStyle white_s18 = build(Colors.white, 18);

  static TextStyle c333333_s12 = build(ColorRes.color_333333, 12);

  static TextStyle c3e4559_s13 = build(ColorRes.color_3e4559, 12);

  static TextStyle c646464_s11 = build(ColorRes.color_646464, 11);

  static TextStyle c909090_s12 = build(ColorRes.color_909090, 12);

  static TextStyle cc6c7db_s12 = build(ColorRes.color_c6c7db, 12);

  static TextStyle cff0000_s12 = build(ColorRes.color_ff0000, 12);

  static TextStyle c909090_s14 = build(ColorRes.color_909090, 14);

  static TextStyle c1b1b2e_s15 =
      build(ColorRes.color_1b1b2e, 15, fontWeight: FontWeight.w500);

  static TextStyle c1b1b2e_s20 =
      build(ColorRes.color_1b1b2e, 20, fontWeight: FontWeight.w500);

  static TextStyle c30313f_s20_bold =
      build(ColorRes.color_30313f, 20, fontWeight: FontWeight.bold);

  static TextStyle cc15500_s20_bold =
      build(ColorRes.color_c15500, 20, fontWeight: FontWeight.bold);

  static TextStyle cc15500_s16_bold =
      build(ColorRes.color_c15500, 16, fontWeight: FontWeight.bold);

  static TextStyle cc15500_s12_bold =
      build(ColorRes.color_c15500, 12, fontWeight: FontWeight.bold);

  static TextStyle c30313f_s11 = build(ColorRes.color_30313f, 11);

  static TextStyle c30313f_s12 = build(ColorRes.color_30313f, 12);

  static TextStyle c30313f_s14 = build(ColorRes.color_30313f, 14);

  static TextStyle cff00b3_s14 = build(ColorRes.color_ff00b3, 14);

  static TextStyle cff00b3_s16 = build(ColorRes.color_ff00b3, 16);

  static TextStyle cff00b3_s14_bold = build(ColorRes.color_ff00b3, 14,fontWeight: FontWeight.bold);

  static TextStyle cff00b3_s12 = build(ColorRes.color_ff00b3, 12);

  static TextStyle c30313f_s14_bold =
      build(ColorRes.color_30313f, 14, fontWeight: FontWeight.bold);

  static TextStyle c30313f_s15 = build(ColorRes.color_30313f, 15);

  static TextStyle c30313f_s15_bold =
      build(ColorRes.color_30313f, 15, fontWeight: FontWeight.bold);

  static TextStyle c30313f_s16 = build(ColorRes.color_30313f, 16);

  static TextStyle c30313f_s16_bold =
      build(ColorRes.color_30313f, 16, fontWeight: FontWeight.bold);

  static TextStyle c3f3f3f_s11 = build(ColorRes.color_3f3f3f, 11);

  static TextStyle c787878_s13 = build(ColorRes.color_787878, 13);

  static TextStyle cf15d58_s13 = build(ColorRes.color_f15d58, 13);

  static TextStyle c787878_s14 = build(ColorRes.color_787878, 14);

  static TextStyle c666666_s12 = build(ColorRes.color_666666, 12);

  static TextStyle c6c5aef_s12 = build(ColorRes.color_6c5aef, 12);

  static TextStyle c6c5aef_s12_bold =
      build(ColorRes.color_6c5aef, 12, fontWeight: FontWeight.bold);

  static TextStyle cb4b4b4_s12 = build(ColorRes.color_b4b4b4, 12);

  static TextStyle cf8a327_s26_bold =
      build(ColorRes.color_f8a327, 26, fontWeight: FontWeight.bold);

  static TextStyle cd80404_s15 = build(ColorRes.color_d80404, 15);

  static TextStyle cffb434_s30 = build(ColorRes.color_ffb434, 30);

  static TextStyle cbababa_s13 = build(ColorRes.color_bababa, 13);

  static TextStyle ca7a7a7_s14 = build(ColorRes.color_a7a7a7, 13);

  static TextStyle c1e1e1e_s12 = build(ColorRes.color_1e1e1e, 12);

  static TextStyle c2c2c2c_s15 = build(ColorRes.color_2c2c2c, 15);

  static TextStyle cff4149_s11 = build(ColorRes.color_ff4149, 11);

  static TextStyle c4444444_s13 = build(ColorRes.color_444444, 13);

  static TextStyle c4444444_s14 = build(ColorRes.color_444444, 14);

  static TextStyle build(Color color, double fontSize,
      {FontWeight fontWeight = FontWeight.normal,
      String? fontFamily,
      double? height,
      TextDecoration decoration = TextDecoration.none}) {
    return TextStyle(
        color: color,
        fontSize: DimenRes.sp(fontSize),
        fontWeight: fontWeight,
        decoration: decoration,
        height: height,
        fontFamily: fontFamily ??
            (!kIsWeb && Platform.isIOS ? 'PingFangSC-Regular' : 'RobotoMono'));
  }

  static TextStyle buildB(Color color, double fontSize) {
    return AppTextStyle.build(color, fontSize, fontWeight: FontWeight.w500);
  }

  static TextStyle buildM(Color color, double fontSize,
      {double? height, TextDecoration decoration = TextDecoration.none}) {
    return TextStyle(
      color: color,
      fontSize: DimenRes.sp(fontSize),
      fontWeight: FontWeight.w500,
      fontFamily: 'PingFangSC-Medium',
      height: height,
      decoration: decoration,
    );
  }

  static TextStyle DINB(Color color, double fontSize) {
    return build(color, fontSize,
        fontWeight: FontWeight.w500, fontFamily: 'DINAlternate-Bold');
  }
}
