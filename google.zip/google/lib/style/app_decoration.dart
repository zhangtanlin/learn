import 'package:flutter/material.dart';
import 'package:iaimei/res/color_res.dart';
import 'package:iaimei/res/dimen_res.dart';

class AppDecoration {
  static getBRYGradientBg({BorderRadiusGeometry? radius}) {
    return getLinearGradientBg(
        radius: radius,
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          ColorRes.color_89ebff,
          ColorRes.color_f4aef4,
          ColorRes.color_facf60,
        ]);
  }

  static getBlueGradientBg({BorderRadiusGeometry? radius}) {
    return getLinearGradientBg(
        radius: radius,
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [ColorRes.color_7f85f4, ColorRes.color_6c5aef]);
  }

  static getOrangeGradientBg({BorderRadiusGeometry? radius}) {
    return getLinearGradientBg(
        radius: radius,
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [ColorRes.color_f2ad55, ColorRes.color_f9a338]);
  }

  static getGrayBg({BorderRadiusGeometry? radius}) {
    return getSingleColorBg(color: ColorRes.color_f8f8f8, radius: radius);
  }

  static getLinearGradientBg(
      {AlignmentGeometry begin = Alignment.centerLeft,
      AlignmentGeometry end = Alignment.centerRight,
      required List<Color> colors,
      List<BoxShadow>? boxShadow,
      BorderStyle borderStyle = BorderStyle.solid,
      double borderWidth = 1.0,
      BorderRadiusGeometry? radius,
      Color borderColor = Colors.transparent}) {
    return BoxDecoration(
        border: Border.all(
            color: borderColor, style: borderStyle, width: borderWidth),
        boxShadow: boxShadow,
        borderRadius: radius,
        gradient: LinearGradient(begin: begin, end: end, colors: colors));
  }

  static getSingleColorBg(
      {Color color = Colors.white,
      List<BoxShadow>? boxShadow,
      Color borderColor = Colors.transparent,
      BorderStyle borderStyle = BorderStyle.solid,
      double borderWidth = 1.0,
      BorderRadiusGeometry? radius}) {
    return BoxDecoration(
      border: Border.all(
        color: borderColor,
        style: borderStyle,
        width: borderWidth,
      ),
      boxShadow: boxShadow,
      borderRadius: radius ?? BorderRadius.circular(DimenRes.radius(3)),
      color: color,
    );
  }
}
