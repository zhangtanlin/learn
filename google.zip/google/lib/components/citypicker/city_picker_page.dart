import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:iaimei/app_const.dart';
import 'package:iaimei/base/app_base_widget_state.dart';
import 'package:iaimei/event/dating_city_change_event.dart';
import 'package:iaimei/global.dart';
import 'package:iaimei/mixin/page_load_mixin.dart';
import 'package:iaimei/model/dating_city_model.dart';
import 'package:iaimei/net/http_helper.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/res/string_res.dart';
import 'package:iaimei/style/app_text_style.dart';
import 'package:iaimei/utils/eventbus_util.dart';
import 'package:iaimei/utils/list_util.dart';
import 'package:iaimei/widget/app_page_title_bar.dart';
import 'package:iaimei/widget/frosted_glass_box.dart';
import 'package:iaimei/widget/text_widget.dart';
import 'package:lpinyin/lpinyin.dart';

typedef AlphaChanged = void Function(String? alpha);
typedef OnTouchStart = void Function();
typedef OnTouchMove = void Function();
typedef OnTouchEnd = void Function();

/// 城市选择
class CityPickerPage extends StatefulWidget {
  const CityPickerPage({
    Key? key,
  }) : super(key: key);

  @override
  State<CityPickerPage> createState() => _CityPickerPageState();
}

class _CityPickerPageState extends AppBaseWidgetState<CityPickerPage>
    with PageLoadMixin {
  // 后端返回的热门城市数据
  List<CityItemModel> hotCityList = [];

  // 后端返回的全部城市数据
  List<CityItemModel> allCityList = [];

  List<String> letters = [];

  // 添加了字母区分的全部城市列表
  late List<DatumCity> newCityData = [];
  Timer? _changeTimer;
  bool _isTouchTagBar = false;
  double letterItemSize = DimenRes.dimen_20;
  late String _tagName;
  late ScrollController _scrollController;

  /// 获取全部的城市列表汉字的拼音首字母添加进数据中
  Future<List<dynamic>> onFormatData(List<CityItemModel>? cityList) async {
    List<CityItemModel> tempCityList = cityList ?? [];

    List allCityLetterList = [];

    // 获取城市首字母
    for (int i = 0; i < tempCityList.length; i++) {
      allCityLetterList.add({
        "id": tempCityList[i].id,
        "areaname": tempCityList[i].areaname,
        "letter": PinyinHelper.getPinyinE(tempCityList[i].areaname ?? '')
            .substring(0, 1),
      });
    }

    var allCityNewList = [];
    var letterList = [];
    // 排序相同首字母城市放入同一数组 处理成多维数组
    for (int j = 0; j < allCityLetterList.length; j++) {
      var curCity = allCityLetterList[j];
      var curLetter = curCity['letter'];
      if (!letterList.contains(curLetter)) {
        allCityNewList.add({
          "letter": curLetter,
          "listData": [curCity]
        });
        letterList.add(curLetter);
      } else {
        for (int k = 0; k < allCityNewList.length; k++) {
          var tempCity = allCityNewList[k];
          if (tempCity['letter'] == curLetter) {
            tempCity['listData'].add(curCity);
            break;
          }
        }
      }
    }
    // 首字母排序
    allCityNewList.sort((a, b) {
      return a['letter'].toLowerCase().compareTo(b['letter'].toLowerCase());
    });
    return allCityNewList;
  }

  _onTagChange(String alpha) {
    if (_changeTimer?.isActive ?? false) {
      _changeTimer!.cancel();
    }
    _changeTimer = Timer(const Duration(milliseconds: 100), () {
      int index = letters.indexOf(alpha);
      var height = index * 45.0;
      for (int i = 0; i < index; i++) {
        height += newCityData[i].listData.length * 40.w;
      }
      _scrollController.jumpTo(height);
    });
  }

  @override
  void dispose() {
    if (_scrollController != null) {
      _scrollController.dispose();
    }
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    _scrollController = ScrollController();
    onLoadData();
  }

  @override
  buildAppBar() {
    return AppPageTitleBar.getNormalAppBar(title: '选择城市');
  }

  @override
  onLoadData() {
    HttpHelper.getDatingCityList((data) async {
      DatingCityModel datingCityModel = DatingCityModel.fromJson(data);
      hotCityList = datingCityModel.hotCity ?? [];
      allCityList = datingCityModel.allCity ?? [];
      if (ListUtil.isNotEmpty(allCityList)) {
        var result = await onFormatData(allCityList);
        var resultString = {"data": result};
        var resultEntity = CityListData.fromJson(resultString);
        newCityData = resultEntity.data;
        for (int i = 0; i < newCityData.length; i++) {
          letters.add(newCityData[i].letter.toUpperCase());
        }
      }
      setPageState(datingCityModel != null && ListUtil.isNotEmpty(allCityList));
    }, (error) {
      setPageErrorState(error);
    });
  }

  @override
  Widget successView() {
    return Column(
      children: [
        _buildHotCitySection(),
        Expanded(
          child: buildAllCitySection(),
        )
      ],
    );
  }

  @override
  Widget buildPageLayout() {
    return handlePageStateView();
  }

  /// 热门城市
  _buildHotCitySection() {
    return Container(
      padding: EdgeInsets.only(
        top: DimenRes.dimen_10,
        left: DimenRes.dimen_16,
        right: DimenRes.dimen_16,
        bottom: DimenRes.dimen_10,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.only(
              bottom: DimenRes.dimen_10,
            ),
            child: TextWidget.buildSingleLineText(
              StringRes.str_hot_city,
              TextStyle(
                fontSize: ScreenUtil().setSp(18),
                color: Colors.white,
              ),
            ),
          ),
          _buildHotCityView(),
        ],
      ),
    );
  }

  /// 渲染热门城市
  Widget _buildHotCityView() {
    double itemWidth = (DimenRes.screenWidth - DimenRes.convert(50)) / 4;

    return Wrap(
      alignment: WrapAlignment.center,
      runAlignment: WrapAlignment.center,
      spacing: DimenRes.dimen_5,
      runSpacing: DimenRes.dimen_5,
      children: hotCityList.map((item) {
        return GestureDetector(
          onTap: () {
            AppGlobal.appBox!.put(AppConst.datingCityKey, item.toJson());
            EventBusUtil.fire(DatingCityChangeEvent());
            Navigator.pop(context);
          },
          child: FrostedGlassSimpleBox(
              width: itemWidth,
              alignment: Alignment.center,
              borderRadius: BorderRadius.circular(12),
              padding: EdgeInsets.only(
                  top: DimenRes.dimen_10, bottom: DimenRes.dimen_10),
              child: TextWidget.buildSingleLineText(
                  item.areaname ?? '', AppTextStyle.white_s12)),
        );
      }).toList(),
    );
  }

  /// 全部城市列表
  Widget buildAllCitySection() {
    Widget tempWidget = const SizedBox(); // 判定是否有数据
    Widget tempTouchBar = const SizedBox(); // 判定操作列表
    if (ListUtil.isNotEmpty(newCityData)) {
      tempWidget = Padding(
        padding: EdgeInsets.only(
          left: DimenRes.dimen_16,
          right: DimenRes.dimen_50,
        ),
        child: ListView.builder(
          controller: _scrollController,
          physics: const BouncingScrollPhysics(),
          itemCount: newCityData.length,
          itemBuilder: (
            BuildContext context,
            int index,
          ) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CityIndexName(newCityData[index].letter.toUpperCase()),
                FrostedGlassSimpleBox(
                  child: ListView.builder(
                    padding: EdgeInsets.only(
                        left: DimenRes.dimen_10, right: DimenRes.dimen_10),
                    itemBuilder: (
                      BuildContext context,
                      int idx,
                    ) {
                      bool offstage = false;
                      if (newCityData[index].listData.length == idx + 1) {
                        offstage = true;
                      }
                      return GestureDetector(
                        child: Container(
                          decoration: BoxDecoration(
                            color: Colors.transparent,
                            border: Border(
                              bottom: BorderSide(
                                width: offstage ? 0 : 0.5,
                                color: Color.fromRGBO(
                                  255,
                                  255,
                                  255,
                                  offstage ? 0 : 0.1,
                                ),
                              ),
                            ),
                          ),
                          padding: EdgeInsets.only(
                            top: DimenRes.dimen_12,
                            bottom: DimenRes.dimen_12,
                          ),
                          child: TextWidget.buildSingleLineText(
                            newCityData[index].listData[idx].areaname,
                            TextStyle(
                              fontSize: DimenRes.sp(12),
                              color: Colors.white,
                            ),
                          ),
                        ),
                        onTap: () {
                          CityItemModel tempCity = CityItemModel(
                            id: newCityData[index].listData[idx].id,
                            areaname: newCityData[index].listData[idx].areaname,
                          );
                          AppGlobal.appBox!
                              .put(AppConst.datingCityKey, tempCity.toJson());
                          EventBusUtil.fire(DatingCityChangeEvent());
                          Navigator.of(context).pop();
                        },
                      );
                    },
                    itemCount: newCityData[index].listData.isEmpty
                        ? 0
                        : newCityData[index].listData.length,
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                  ),
                )
              ],
            );
          },
        ),
      );
    }
    if (_isTouchTagBar) {
      tempTouchBar = Center(
        child: Card(
          color: Colors.black.withOpacity(0.1),
          child: Container(
            alignment: Alignment.center,
            width: 80.0,
            height: 80.0,
            child: Text(
              _tagName,
              style: TextStyle(
                fontSize: DimenRes.sp(30),
                color: Colors.white,
              ),
            ),
          ),
        ),
      );
    }
    return Stack(
      children: <Widget>[
        tempWidget,
        tempTouchBar,
        Positioned(
          top: 0,
          right: DimenRes.dimen_10,
          bottom: 0,
          child: Alpha(
            alphas: letters,
            alphaItemSize: letterItemSize,
            onTouchStart: () {
              setState(() {
                _isTouchTagBar = true;
              });
            },
            onTouchEnd: () {
              setState(() {
                _isTouchTagBar = false;
              });
            },
            onAlphaChange: (String? alpha) {
              setState(() {
                if (!_isTouchTagBar) {
                  _isTouchTagBar = true;
                }
                _tagName = alpha!;
              });
              // _initOffsetRangList();
              if (alpha != null) {
                _onTagChange(alpha);
              }
            },
          ),
        )
      ],
    );
  }
}

class Alpha extends StatefulWidget {
  /// 单个字母的字体大小
  final double alphaItemSize;
  final List alphas;

  /// 当选中的字母发生改变
  final AlphaChanged? onAlphaChange;

  final OnTouchStart? onTouchStart;
  final OnTouchMove? onTouchMove;
  final OnTouchEnd? onTouchEnd;

  /// 激活状态下的背景色
  final Color activeBgColor;

  /// 未激活状态下的背景色
  final Color bgColor;

  /// 未激活状态下字体的颜色
  final Color fontColor;

  /// 激活状态下字体的颜色
  final Color fontActiveColor;

  const Alpha(
      {Key? key,
      required this.alphaItemSize,

      /// 可供选择的字母集
      required this.alphas,

      /// 当右侧字母集, 因触摸而产生的回调
      this.onAlphaChange,
      this.onTouchStart,
      this.onTouchMove,
      this.onTouchEnd,
      this.activeBgColor = Colors.green,
      this.bgColor = Colors.yellow,
      this.fontColor = Colors.black,
      this.fontActiveColor = Colors.yellow})
      : super(key: key);

  @override
  AlphaState createState() {
    return AlphaState();
  }
}

class AlphaState extends State<Alpha> {
//  Timer _changeTimer;

  bool isTouched = false;

  List<double> indexRange = [];

  /// 第一个字母或者分类距离global坐标系的高度
  double? _distance2Top;

  // 当触摸结束前, 最后一个字母;
  String? _lastTag;

  @override
  void initState() {
    super.initState();
    _init();
  }

  _init() {
    List alphas = widget.alphas;
    for (int i = 0; i <= alphas.length; i++) {
      indexRange.add((i) * widget.alphaItemSize);
    }
  }

  String? _getHitAlpha(offset) {
    int hit = (offset / widget.alphaItemSize).toInt();
    if (hit < 0) {
      return null;
    }
    if (hit >= widget.alphas.length) {
      return null;
    }
    return widget.alphas[hit];
  }

  _onAlphaChange([String? tag]) {
    if (widget.onAlphaChange != null && tag != _lastTag) {
      _lastTag = tag;
      widget.onAlphaChange!(tag);
    }
  }

  _touchStartEvent(String tag) {
    setState(() {
      isTouched = true;
    });
    _onAlphaChange(tag);

    if (widget.onTouchStart != null) {
      widget.onTouchStart!();
    }
  }

  _touchMoveEvent(String tag) {
    _onAlphaChange(tag);
    if (widget.onTouchMove != null) {
      widget.onTouchMove!();
    }
  }

  _touchEndEvent() {
    setState(() {
      isTouched = false;
    });
    // 这里本可以不用再触发一次的. 但是为了数据的准备, 最后再触发一次
    if (_lastTag != null) {
      _onAlphaChange(_lastTag);
    }
    if (widget.onTouchEnd != null) {
      widget.onTouchEnd!();
    }
  }

  _buildAlpha() {
    List<Widget> result = [];
    for (var alpha in widget.alphas) {
      result.add(Container(
        key: Key(alpha),
        alignment: Alignment.center,
        height: widget.alphaItemSize,
        child: Text(
          alpha,
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: DimenRes.sp(10),
            color: isTouched
                ? const Color.fromRGBO(255, 255, 255, 0.5)
                : const Color.fromRGBO(255, 255, 255, 0.5),
          ),
        ),
      ));
    }
    return Align(
      alignment: Alignment.centerRight,
      child: Container(
        alignment: Alignment.center,
        color: isTouched ? Colors.transparent : Colors.transparent,
        child: FrostedGlassSimpleBox(
          padding: const EdgeInsets.fromLTRB(8, 10, 8, 10),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: result,
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onVerticalDragDown: (DragDownDetails details) {
        if (_distance2Top == null) {
          RenderBox? renderBox = context.findRenderObject() as RenderBox;
          _distance2Top = renderBox.localToGlobal(Offset.zero).dy.toInt() +
              (renderBox.size.height -
                      widget.alphaItemSize * widget.alphas.length) /
                  2;
        }

        int touchOffset2Begin =
            details.globalPosition.dy.toInt() - _distance2Top!.toInt();
        String? tag = _getHitAlpha(touchOffset2Begin);
        if (tag != null) {
          _touchStartEvent(tag);
        }
      },
      onVerticalDragUpdate: (DragUpdateDetails details) {
        int touchOffset2Begin =
            details.globalPosition.dy.toInt() - _distance2Top!.toInt();
        String? tag = _getHitAlpha(touchOffset2Begin);
        if (tag != null) {
          _touchMoveEvent(tag);
        }
      },
      onVerticalDragEnd: (DragEndDetails details) {
        _touchEndEvent();
      },
      child: _buildAlpha(),
    );
  }
}

// ignore: must_be_immutable
class CityIndexName extends StatelessWidget {
  String indexName;

  CityIndexName(this.indexName, {Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      alignment: Alignment.centerLeft,
      color: Colors.transparent,
      child: Padding(
        padding: EdgeInsets.only(
            top: DimenRes.dimen_10,
            bottom: DimenRes.dimen_10,
            right: DimenRes.dimen_10),
        child: TextWidget.buildSingleLineText(
          indexName,
          TextStyle(
            fontSize: DimenRes.sp(20),
            color: const Color(0xffff00b7),
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }
}

CityListData cityListDataFromJson(String str) =>
    CityListData.fromJson(json.decode(str));

String cityListDataToJson(CityListData data) => json.encode(data.toJson());

/// 以下为含有字母序号的新列表模型
class CityListData {
  CityListData({
    required this.data,
  });

  List<DatumCity> data;

  factory CityListData.fromJson(Map<String, dynamic> json) => CityListData(
        data: List<DatumCity>.from(
          json["data"].map(
            (x) => DatumCity.fromJson(x),
          ),
        ),
      );

  Map<String, dynamic> toJson() => {
        "data": data,
      };
}

class DatumCity {
  DatumCity({
    required this.listData,
    required this.letter,
  });

  List<ListDatumCity> listData;
  String letter;

  factory DatumCity.fromJson(Map<String, dynamic> json) => DatumCity(
        listData: List<ListDatumCity>.from(
          json["listData"].map(
            (x) => ListDatumCity.fromJson(x),
          ),
        ),
        letter: json["letter"] ?? '',
      );

  Map<String, dynamic> toJson() => {
        "listData": listData,
        "letter": letter,
      };
}

class ListDatumCity {
  ListDatumCity({
    required this.letter,
    required this.id,
    required this.areaname,
  });

  String letter;
  int id;
  String areaname;

  factory ListDatumCity.fromJson(Map<String, dynamic> json) => ListDatumCity(
        letter: json["letter"] ?? '',
        id: json["id"] ?? '',
        areaname: json["areaname"] ?? '',
      );

  Map<String, dynamic> toJson() => {
        "letter": letter,
        "id": id,
        "areaname": areaname,
      };
}
