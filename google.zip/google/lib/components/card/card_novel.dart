import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:iaimei/model/model_collect_buy_novel.dart';
import 'package:iaimei/model/novel_item_model.dart';
import 'package:iaimei/theme/default.dart';
import 'package:iaimei/utils/networkimage.dart';
import 'package:iaimei/utils/page_jump_util.dart';
import 'package:iaimei/widget/network_img_container.dart';

/// 收藏购买-小说列表项
/// [item]小说列表项
class CardNovelCollectBuy extends StatelessWidget {
  final Datum item;
  const CardNovelCollectBuy({
    Key? key,
    required this.item,
  }) : super(key: key);

  /// 设置是否显示vip按钮
  Widget _setVipBtnWidget() {
    if (item.isType == 1) {
      return Positioned(
        top: ScreenUtil().setWidth(5.0),
        right: ScreenUtil().setWidth(5.0),
        child: Image.asset(
          "assets/images/common/cartoon_vip.png",
          width: ScreenUtil().setWidth(36.0),
          height: ScreenUtil().setWidth(18.0),
        ),
      );
    }
    return const SizedBox();
  }

  /// 设置是否显示vip按钮
  Widget _setTimeWidget() {
    String tempText = '';
    if (item.refreshAt.toString().trim().isNotEmpty) {
      tempText = item.refreshAt.toString().split(" ")[0];
    }
    return Text(
      tempText,
      style: DefaultStyle.gray12,
    );
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.translucent,
      onTap: () {
        PageJumpUtil.forwardToNovelDetailPage(
            context, NovelItemModel(id: item.id));
      },
      child: Padding(
        padding: EdgeInsets.only(
          bottom: ScreenUtil().setWidth(10.0),
        ),
        child: Flex(
          direction: Axis.horizontal,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Stack(
              children: [
                _setVipBtnWidget(),
                ClipRRect(
                  borderRadius: BorderRadius.all(
                    Radius.circular(
                      ScreenUtil().setWidth(10.0),
                    ),
                  ),
                  child: NetworkImgContainer(
                    width: ScreenUtil().setWidth(105.0),
                    height: ScreenUtil().setWidth(140.0),
                    url: item.imgUrlFull.toString(),
                  ),
                ),
              ],
            ),
            Expanded(
              flex: 1,
              child: Container(
                height: ScreenUtil().setWidth(140.0),
                padding: EdgeInsets.only(
                  left: ScreenUtil().setWidth(10.0),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      item.title.toString(),
                      style: DefaultStyle.white14,
                      maxLines: 3,
                    ),
                    _setTimeWidget(),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
