import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:iaimei/components/common/avatar.dart';
import 'package:iaimei/model/chat_model.dart';
import 'package:iaimei/theme/default.dart';

/// 约炮评论列表项
/// [item]约炮评论列表项
class CardDatingComment extends StatelessWidget {
  final CommentList item;
  const CardDatingComment({
    Key? key,
    required this.item,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: ScreenUtil().setWidth(16.0),
      ),
      color: const Color.fromRGBO(26, 21, 47, 1),
      child: Container(
        padding: EdgeInsets.symmetric(
          vertical: ScreenUtil().setWidth(10.0),
        ),
        decoration: const BoxDecoration(
          border: Border(
            bottom: BorderSide(
              width: 1,
              color: Color.fromRGBO(255, 255, 255, 0.2),
            ),
          ),
        ),
        child: Column(
          children: [
            Row(
              children: [
                Avatar(
                  width: ScreenUtil().setWidth(25.0),
                  height: ScreenUtil().setWidth(25.0),
                  borderRadius: BorderRadius.circular(
                    ScreenUtil().setWidth(12.5),
                  ),
                  url: item.member.avatarUrl.toString(),
                ),
                Padding(
                  padding: EdgeInsets.only(
                    left: ScreenUtil().setWidth(7.5),
                  ),
                  child: Text(
                    item.member.nickname.toString(),
                    style: DefaultStyle.white14,
                  ),
                )
              ],
            ),
            Container(
              alignment: Alignment.centerLeft,
              padding: EdgeInsets.only(
                top: ScreenUtil().setWidth(7.5),
              ),
              child: Text(
                item.content.toString(),
                style: TextStyle(
                  color: const Color(0x99FFFFFF),
                  fontSize: ScreenUtil().setSp(12),
                  decoration: TextDecoration.none,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
