import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/res/img_res.dart';
import 'package:iaimei/style/app_text_style.dart';
import 'package:iaimei/widget/app_img_widget.dart';
import 'package:iaimei/widget/frosted_glass_box.dart';
import 'package:iaimei/widget/network_img_container.dart';
import 'package:iaimei/widget/space_widget.dart';
import 'package:iaimei/widget/text_widget.dart';

/// 约炮列表项
class CardReportItem extends StatelessWidget {
  final Map item;

  const CardReportItem({
    Key? key,
    required this.item,
  }) : super(key: key);

  Widget _buildVipSection() {
    if (item["member"] != null &&
        item["member"]["is_vip"] != null &&
        item["member"]["is_vip"]) {
      return Container(
        child: AppImgWidget(
          path: ImgRes.IC_BADGE_USER_VIP,
          height: DimenRes.dimen_14,
        ),
        margin: EdgeInsets.only(bottom: 2),
      );
    }
    return const SizedBox();
  }

  /// 设置用户头像
  Widget _buildUserAvatar() {
    String tempUrl = '';
    if (item["member"] != null && item["member"]["avatar_url"] != null) {
      tempUrl = item["member"]["avatar_url"] ?? '';
    }
    return NetworkImgContainer(
      width: DimenRes.dimen_32,
      height: DimenRes.dimen_32,
      radius: BorderRadius.circular(
        DimenRes.dimen_8,
      ),
      url: tempUrl,
    );
  }

  /// 设置用户昵称
  Widget _buildUserNicknameSection() {
    String tempNickname = '';
    if (item["member"] != null && item["member"]["nickname"] != null) {
      tempNickname = item["member"]["nickname"] ?? '';
    }
    return Padding(
      padding: EdgeInsets.only(
        bottom: ScreenUtil().setWidth(2),
      ),
      child: TextWidget.buildSingleLineText(
        tempNickname,
        AppTextStyle.white_s13,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => {
        context.push(
          '/reportDetail/${item["id"]}}',
        ),
      },
      child: FrostedGlassSimpleBox(
        margin: EdgeInsets.only(
          top: ScreenUtil().setWidth(15),
        ),
        child: Column(
          children: [
            Container(
              padding: EdgeInsets.all(DimenRes.dimen_10),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  _buildUserAvatar(),
                  const SpaceWidget(
                    hSpace: 10,
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      _buildUserNicknameSection(),
                      _buildVipSection(),
                    ],
                  ),
                ],
              ),
            ),
            Container(
              height: DimenRes.convert(146),
              padding: EdgeInsets.all(
                DimenRes.dimen_10,
              ),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.08),
                borderRadius: BorderRadius.vertical(
                  bottom: Radius.circular(
                    DimenRes.radius(10),
                  ),
                ),
              ),
              child: Row(
                children: [
                  NetworkImgContainer(
                    width: DimenRes.convert(97),
                    height: DimenRes.convert(126),
                    url: item["images_full"][0]["url"] ?? '',
                    radius: const BorderRadius.all(Radius.circular(5)),
                    fit: BoxFit.cover,
                  ),
                  const SpaceWidget(
                    hSpace: 10,
                  ),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        TextWidget.buildSingleLineText(
                          item["title"] ?? '',
                          AppTextStyle.cff00b3_s16,
                        ),
                        const SpaceWidget(
                          vSpace: 10,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            CardReportText(
                              title: '年龄：',
                              value: item["girl_age"].toString(),
                            ),
                            const SpaceWidget(
                              hSpace: 20,
                            ),
                            CardReportText(
                              title: '罩杯：',
                              value: item["girl_cup"] ?? '',
                            ),
                          ],
                        ),
                        const SpaceWidget(
                          vSpace: 5,
                        ),
                        Text(
                          item["content"] ?? '',
                          softWrap: true,
                          overflow: TextOverflow.ellipsis,
                          maxLines: 2,
                          style: AppTextStyle.build(
                              Colors.white.withOpacity(0.64), 12),
                        ),
                        const Spacer(
                          flex: 1,
                        ),
                        CardReportText(
                          title: '查阅：',
                          value: item["view_num"].toString(),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// 约炮列表项-标记按钮
class CardReportMarkBtn extends StatelessWidget {
  final String text;

  const CardReportMarkBtn({
    Key? key,
    required this.text,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: ScreenUtil().setWidth(12.5),
      margin: EdgeInsets.only(
        right: ScreenUtil().setWidth(5),
      ),
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: const Color.fromRGBO(255, 255, 255, .2),
        borderRadius: BorderRadius.circular(
          ScreenUtil().setWidth(10.0),
        ),
      ),
      child: Padding(
        padding: EdgeInsets.symmetric(
          horizontal: ScreenUtil().setWidth(2.5),
        ),
        child: Text(
          text,
          style: TextStyle(
            color: const Color(0xFFFFFFFF),
            fontSize: ScreenUtil().setSp(10.0),
            overflow: TextOverflow.ellipsis,
            decoration: TextDecoration.none,
          ),
        ),
      ),
    );
  }
}

/// 约炮列表项-文字
class CardReportText extends StatelessWidget {
  final String title;
  final String value;

  const CardReportText({
    Key? key,
    required this.title,
    required this.value,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      alignment: Alignment.centerLeft,
      child: Text.rich(
        TextSpan(
          text: title,
          style: AppTextStyle.build(Colors.white.withOpacity(0.64), 12),
          children: [
            TextSpan(
              text: value,
              style: AppTextStyle.white_s12,
            ),
          ],
        ),
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
      ),
    );
  }
}
