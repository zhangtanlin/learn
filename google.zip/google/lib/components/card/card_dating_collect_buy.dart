import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../model/model_collect_buy_dating.dart';
import 'package:iaimei/theme/default.dart';
import 'package:iaimei/widget/network_img_widget.dart';
import 'package:iaimei/router/routers.dart';
import 'package:go_router/go_router.dart';

/// 约炮列表项-我的收藏/我的购买
/// [item]约炮列表项-我的收藏/我的购买
class CardDatingCollectBuy extends StatelessWidget {
  final Datum item;

  const CardDatingCollectBuy({
    Key? key,
    required this.item,
  }) : super(key: key);

  Widget setItem({
    String key = "",
    String value = "",
  }) {
    return RichText(
      text: TextSpan(
        text: key,
        style: DefaultStyle.gray12,
        children: <TextSpan>[
          TextSpan(
            text: value,
            style: DefaultStyle.white12,
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.translucent,
      onTap: () {
        // context.push("/datingInfo/${item.infoId}");
        context.push('/${Routes.datingDetail}', extra: {'info_id': item.infoId});
      },
      child: Padding(
        padding: EdgeInsets.only(
          bottom: ScreenUtil().setWidth(10.0),
        ),
        child: Flex(
          direction: Axis.horizontal,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Stack(
              children: [
                Positioned(
                  top: ScreenUtil().setWidth(5.0),
                  right: ScreenUtil().setWidth(5.0),
                  child: Image.asset(
                    "assets/images/common/cartoon_vip.png",
                    width: ScreenUtil().setWidth(36.0),
                    height: ScreenUtil().setWidth(18.0),
                  ),
                ),
                ClipRRect(
                  borderRadius: BorderRadius.all(
                    Radius.circular(
                      ScreenUtil().setWidth(10.0),
                    ),
                  ),
                  child: Container(
                    width: ScreenUtil().setWidth(105.0),
                    height: ScreenUtil().setWidth(140.0),
                    color: DefaultStyle.bgDefault,
                    child: NetworkImgWidget(
                      // width: ScreenUtil().setWidth(105.0),
                      // height: ScreenUtil().setWidth(140.0),
                      url: item.thumbUrl,
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ],
            ),
            Expanded(
              flex: 1,
              child: Container(
                height: ScreenUtil().setWidth(140.0),
                padding: EdgeInsets.only(
                  left: ScreenUtil().setWidth(10.0),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          item.title.toString(),
                          style: DefaultStyle.white14,
                          maxLines: 3,
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            top: ScreenUtil().setWidth(10.0),
                          ),
                          child: Text(
                            item.desc.toString(),
                            style: DefaultStyle.gray12,
                          ),
                        ),
                        // Padding(
                        //   padding: EdgeInsets.only(
                        //     top: ScreenUtil().setWidth(10.0),
                        //   ),
                        //   child: setItem(
                        //     key: "手机号：",
                        //     value: "18511111111",
                        //   ),
                        // ),
                        // Padding(
                        //   padding: EdgeInsets.only(
                        //     top: ScreenUtil().setWidth(10.0),
                        //   ),
                        //   child: setItem(
                        //     key: "微信号：",
                        //     value: "wxsdfsfsfsfsd123",
                        //   ),
                        // ),
                      ],
                    ),
                    Text(
                      item.createdStr.toString(),
                      style: DefaultStyle.gray12,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}