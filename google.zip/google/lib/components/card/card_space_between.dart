import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:iaimei/theme/default.dart';

/// 左右排列列表行项(用于个人中心的设置/个人信息列表页中等)
/// [title]左侧文字
/// [text]右侧文字
/// [right]右侧部件（可自定义右侧样式）
/// [onTap]点击事件
class CardSpaceBetween extends StatelessWidget {
  final EdgeInsetsGeometry? padding;
  final Color? background;
  final String title;
  final String? text;
  final Widget? left;
  final Widget? right;
  final Function()? onTap;
  const CardSpaceBetween({
    Key? key,
    this.padding,
    this.background,
    required this.title,
    this.text,
    this.left,
    this.right,
    this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    /// 左侧
    Widget tempLeft = Text(
      title.toString(),
      style: DefaultStyle.white14,
    );
    if (left != null) {
      tempLeft = left!;
    }

    /// 设置内边距
    EdgeInsetsGeometry setPadding() {
      if (padding != null) {
        return padding as EdgeInsetsGeometry;
      }
      return EdgeInsets.all(
        ScreenUtil().setWidth(10.0),
      );
    }

    /// 设置背景色
    Color setBackground() {
      if (background != null) {
        return background as Color;
      }
      return DefaultStyle.bgDefault;
    }

    /// 右侧
    Widget tempRight = Container();
    if (right != null) {
      tempRight = right!;
    } else {
      Widget? tempText = Container();
      if (text != null) {
        tempText = Text(
          text.toString(),
          style: DefaultStyle.white12,
        );
      }
      tempRight = Row(
        children: [
          Padding(
            padding: EdgeInsets.only(
              right: ScreenUtil().setWidth(10.0),
            ),
            child: tempText,
          ),
          Image.asset(
            "assets/images/common/arrow_go.png",
            height: ScreenUtil().setWidth(18.0),
          ),
        ],
      );
    }
    return GestureDetector(
      onTap: () {
        if (onTap != null) {
          onTap!();
        }
      },
      child: Container(
        margin: EdgeInsets.only(
          right: DefaultStyle.pagePadding,
          bottom: DefaultStyle.pagePadding,
          left: DefaultStyle.pagePadding,
        ),
        padding: setPadding(),
        decoration: BoxDecoration(
          color: setBackground(),
          borderRadius: BorderRadius.all(
            Radius.circular(
              ScreenUtil().setWidth(12.0),
            ),
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            tempLeft,
            tempRight,
          ],
        ),
      ),
    );
  }
}
