import 'package:bot_toast/bot_toast.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:iaimei/model/basic.dart';
import 'package:iaimei/model/model_fans_list.dart';
import 'package:iaimei/theme/default.dart';
import 'package:iaimei/utils/api.dart';
import 'package:iaimei/widget/buttom_widget.dart';
import 'package:iaimei/widget/network_img_container.dart';

/// 关注
/// [item]关注列表项
class CardFollow extends StatefulWidget {
  final Datum? item;
  const CardFollow({
    Key? key,
    required this.item,
  }) : super(key: key);

  @override
  State<CardFollow> createState() => _CardFollowState();
}

class _CardFollowState extends State<CardFollow> {
  // 是否关注
  bool isFollow = false;
  // 关注/未关注按钮是否被点击
  bool isClicked = true;

  @override
  void initState() {
    super.initState();
    if (widget.item!.isAttention == 1) {
      isFollow = true;
    } else {
      isFollow = false;
    }
    setState(() {});
  }

  /// 关注/取消点击事件
  Future<void> handleSubmit() async {
    if (!isClicked) {
      return;
    }
    isClicked = false;
    Basic? res = await apiFollowing(
      uid: widget.item?.uid.toString(),
    );
    if (res?.status == 1) {
      setState(() {
        isFollow = !isFollow;
      });
      BotToast.showText(text: res!.data["msg"]);
    } else {
      BotToast.showText(text: res!.msg.toString());
    }
    isClicked = true;
  }

  /// vip等级标记
  Widget setVip() {
    if (widget.item!.isVip == true) {
      return Padding(
        padding: EdgeInsets.only(top: 5.0.w, right: 5.0.w),
        child: Image.asset(
          "assets/images/common/grade_vip.png",
          height: 14.0.w,
        ),
      );
    }
    return Container();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(
        top: ScreenUtil().setWidth(10.0),
      ),
      // child: GlassmorphoismBox(
      child: Container(
        width: ScreenUtil().setWidth(343.0),
        height: ScreenUtil().setWidth(64.0),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.all(Radius.circular(12.w)),
            border: Border.all(color: const Color(0x0dffffff), width: 0.5),
            color: const Color(0x1fb2aaff)),
        padding: EdgeInsets.symmetric(horizontal: 10.w),
        child: Flex(
          direction: Axis.horizontal,
          children: [
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(22.w),
                border: Border.all(color: const Color(0x3dffffff), width: 1.w),
                color: const Color(0xffd8d8d8),
              ),
              clipBehavior: Clip.hardEdge,
              width: 44.w,
              height: 44.w,
              child: NetworkImgContainer(
                url: widget.item!.avatarUrl.toString(),
                fit: BoxFit.cover,
                radius: BorderRadius.circular(22.w),
              ),
            ),
            SizedBox(width: 10.w),
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.item!.nickname.toString(),
                    overflow: TextOverflow.ellipsis,
                    style: DefaultStyle.white14,
                  ),
                  Row(
                    children: [
                      setVip(),
                    ],
                  ),
                ],
              ),
            ),
            SizedBox(width: 10.w),
            ButtonWidget.bgText(
              isFollow ? '取关' : '关注',
              isFollow
                  ? "assets/images/button/btn_black.png"
                  : "assets/images/button/btn_small.png",
              size: Size(68.w, 34.w),
              onTap: handleSubmit,
            ),
          ],
        ),
      ),
    );
  }
}
