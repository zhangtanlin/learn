import 'package:flutter/material.dart';
import 'package:flutter_html/shims/dart_ui_real.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:iaimei/model/atlas_item_model.dart';
import 'package:iaimei/model/model_collect_buy_pictures.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/style/app_text_style.dart';
import 'package:iaimei/theme/default.dart';
import 'package:iaimei/utils/badge_util.dart';
import 'package:iaimei/utils/page_jump_util.dart';
import 'package:iaimei/utils/printLog.dart';
import 'package:iaimei/widget/app_img_widget.dart';
import 'package:iaimei/widget/network_img_container.dart';
import 'package:iaimei/widget/text_widget.dart';

/// 收藏购买-图集列表项
/// [item]图集列表项
class CardPicturesCollectBuy extends StatelessWidget {
  final Datum item;
  const CardPicturesCollectBuy({
    Key? key,
    required this.item,
  }) : super(key: key);

  /// 设置是否显示vip按钮
  Widget _setVipBtnWidget() {
    if (item.isType == 1) {
      return Positioned(
        top: ScreenUtil().setWidth(5.0),
        right: ScreenUtil().setWidth(5.0),
        child: Image.asset(
          "assets/images/common/cartoon_vip.png",
          width: ScreenUtil().setWidth(36.0),
          height: ScreenUtil().setWidth(18.0),
        ),
      );
    }
    return const SizedBox();
  }

  /// 设置是否显示vip按钮
  Widget _setTimeWidget() {
    String tempText = '';
    if (item.refreshAt.toString().trim().isNotEmpty) {
      tempText = item.refreshAt.toString().split(" ")[0];
    }
    return Text(
      tempText,
      style: DefaultStyle.gray12,
    );
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.translucent,
      onTap: () {
        var item = AtlasItemModel(id: this.item.id, title: this.item.title);
        PageJumpUtil.forwardToAtlasDetailPage(context, item);
      },
      child: Padding(
        padding: EdgeInsets.only(
          bottom: ScreenUtil().setWidth(10.0),
        ),
        child: Flex(
          direction: Axis.horizontal,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Stack(
              children: [
                _setVipBtnWidget(),
                ClipRRect(
                  borderRadius: BorderRadius.all(
                    Radius.circular(
                      ScreenUtil().setWidth(10.0),
                    ),
                  ),
                  child: Container(
                    width: ScreenUtil().setWidth(105.0),
                    height: ScreenUtil().setWidth(140.0),
                    color: DefaultStyle.bgDefault,

                    child: NetworkImgContainer(
                      width: ScreenUtil().setWidth(105.0),
                      height: ScreenUtil().setWidth(140.0),
                      url: item.thumbFull.toString(),
                    ),
                  ),
                ),
              ],
            ),
            Expanded(
              flex: 1,
              child: Container(
                height: ScreenUtil().setWidth(140.0),
                padding: EdgeInsets.only(
                  left: ScreenUtil().setWidth(10.0),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      item.title.toString(),
                      style: DefaultStyle.white14,
                      maxLines: 3,
                    ),
                    _setTimeWidget(),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// 筛选-图集列表
class CardPicturesFilter extends StatelessWidget {
  final AtlasItemModel atlasModel;
  const CardPicturesFilter({
    Key? key,
    required this.atlasModel,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    double tempWidth = (DimenRes.screenWidth - DimenRes.dimen_6) / 2;
    return Stack(
      children: [
        NetworkImgContainer(
          width: double.infinity,
          height: double.infinity,
          url: '${atlasModel.thumbFull}',
          radius: BorderRadius.circular(10),
        ),
        ClipRRect(
          borderRadius: BorderRadius.circular(10),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 40, sigmaY: 40),
            child: Opacity(
              opacity: 0.2,
              child: Container(
                width: double.infinity,
                height: double.infinity,
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.2),
                ),
              ),
            ),
          ),
        ),
        Column(
          children: [
            Stack(
              children: [
                NetworkImgContainer(
                  width: double.infinity,
                  height: tempWidth * 4 / 3,
                  url: '${atlasModel.thumbFull}',
                  radius: const BorderRadius.only(
                    topRight: Radius.circular(10),
                    topLeft: Radius.circular(10),
                  ),
                ),
                Positioned(
                  right: DimenRes.dimen_5,
                  top: DimenRes.dimen_5,
                  child: AppImgWidget(
                    path: BadgeUtil.getVideoTypeBadgeImgPath(
                      atlasModel.isType!,
                    ),
                    width: DimenRes.dimen_36,
                    height: DimenRes.dimen_18,
                  ),
                )
              ],
            ),
            Container(
              alignment: Alignment.topLeft,
              padding: EdgeInsets.symmetric(
                horizontal: DimenRes.dimen_8,
                vertical: DimenRes.dimen_5,
              ),
              child: TextWidget.build(
                atlasModel.title ?? '',
                AppTextStyle.white_s12,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
            )
          ],
        ),
      ],
    );
  }
}
