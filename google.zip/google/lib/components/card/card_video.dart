import 'package:flutter/material.dart';
import 'package:flutter_html/shims/dart_ui_real.dart';
import 'package:iaimei/model/video_model.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/res/img_res.dart';
import 'package:iaimei/style/app_text_style.dart';
import 'package:iaimei/utils/badge_util.dart';
import 'package:iaimei/utils/string_util.dart';
import 'package:iaimei/widget/app_img_widget.dart';
import 'package:iaimei/widget/network_img_container.dart';
import 'package:iaimei/widget/space_widget.dart';
import 'package:iaimei/widget/text_widget.dart';

/// 筛选-短视频列表项
/// [width]宽度
/// [videoModel]数据
class CardVideoFilter extends StatelessWidget {
  final double width;
  final VideoModel videoModel;
  final int type;

  const CardVideoFilter({
    Key? key,
    required this.width,
    required this.videoModel,
    this.type = 1,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      clipBehavior: Clip.antiAlias,
      borderRadius: BorderRadius.circular(12),
      child: Stack(
        children: [
          NetworkImgContainer(
            width: double.infinity,
            height: double.infinity,
            url: videoModel.coverThumbUrl,
          ),
          BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
              child: const SizedBox(
                width: double.infinity,
                height: double.infinity,
              )),
          Column(
            children: [
              Stack(
                children: [
                  NetworkImgContainer(
                    width: width,
                    height: width * (type == 1 ? 9 / 16 : 4 / 3),
                    url: videoModel.coverThumbUrl,
                  ),
                  Visibility(
                    child: Positioned(
                      child: Container(
                        alignment: Alignment.center,
                        decoration: const BoxDecoration(
                          color: Color(0x6b000000),
                          borderRadius: BorderRadius.only(
                            topRight: Radius.circular(6),
                          ),
                        ),
                        padding: EdgeInsets.symmetric(
                          horizontal: DimenRes.dimen_6,
                          vertical: DimenRes.dimen_3,
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            AppImgWidget(
                              path: ImgRes.IC_PLAY_NUM,
                              width: DimenRes.dimen_8,
                              height: DimenRes.dimen_10,
                              fit: BoxFit.contain,
                            ),
                            const SpaceWidget(hSpace: 3),
                            TextWidget.buildSingleLineText(
                              '${videoModel.rating}',
                              AppTextStyle.white_s10,
                            )
                          ],
                        ),
                      ),
                      bottom: 0,
                      left: 0,
                    ),
                    visible: videoModel.rating > 0,
                  ),
                  Visibility(
                      visible: StringUtil.isNotEmpty(videoModel.durationStr),
                      child: Positioned(
                        child: Container(
                          decoration: const BoxDecoration(
                            color: Color(0x6b000000),
                            borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(6),
                            ),
                          ),
                          padding: EdgeInsets.symmetric(
                            horizontal: DimenRes.dimen_6,
                            vertical: DimenRes.dimen_3,
                          ),
                          child: TextWidget.buildSingleLineText(
                            videoModel.durationStr,
                            AppTextStyle.white_s10,
                          ),
                        ),
                        bottom: 0,
                        right: 0,
                      )),
                  Positioned(
                    right: DimenRes.dimen_5,
                    top: DimenRes.dimen_5,
                    child: AppImgWidget(
                      path:
                          BadgeUtil.getVideoTypeBadgeImgPath(videoModel.isFree),
                      width: DimenRes.dimen_36,
                      height: DimenRes.dimen_18,
                    ),
                  )
                ],
              ),
              Container(
                alignment: Alignment.topLeft,
                padding: EdgeInsets.symmetric(
                  horizontal: DimenRes.dimen_8,
                  vertical: DimenRes.dimen_5,
                ),
                child: TextWidget.build(
                  videoModel.title,
                  AppTextStyle.white_s12,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              )
            ],
          ),
        ],
      ),
    );
  }
}
