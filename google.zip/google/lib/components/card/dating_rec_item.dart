import 'package:flutter/material.dart';
import 'package:iaimei/model/dating_girl_info_model.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/style/app_text_style.dart';
import 'package:iaimei/widget/frosted_glass_box.dart';
import 'package:iaimei/widget/network_img_container.dart';
import 'package:iaimei/widget/space_widget.dart';
import 'package:iaimei/widget/text_widget.dart';

/// 约炮swiper列表项
class DatingRecItem extends StatefulWidget {

  final DatingGirlInfoModel item;

  const DatingRecItem({
    Key? key,
    required this.item,
  }) : super(key: key);

  @override
  State<DatingRecItem> createState() => _DatingRecItemState();
}

class _DatingRecItemState extends State<DatingRecItem> {
  @override
  Widget build(BuildContext context) {
    var title = widget.item.title ?? '';
    return FrostedGlassSimpleBox(
      child: Padding(
        padding: EdgeInsets.symmetric(
          horizontal: DimenRes.dimen_10,
          vertical: DimenRes.dimen_10,
        ),
        child: Row(
          children: [
            NetworkImgContainer(
              radius: BorderRadius.circular(
                DimenRes.radius(5),
              ),
              width: DimenRes.convert(133),
              height: DimenRes.convert(186),
              noVisibilityDetector: true,
              url: widget.item.thumbUrl ?? '',
            ),
            Expanded(
              child: Padding(
                padding: EdgeInsets.only(
                  left: DimenRes.convert(15),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                            child: TextWidget.buildSingleLineText(
                                title, AppTextStyle.white_s16)),
                        Container(
                          margin: EdgeInsets.only(
                            left: DimenRes.dimen_5,
                          ),
                          padding: EdgeInsets.only(
                              left: DimenRes.dimen_5,
                              right: DimenRes.dimen_5,
                              bottom: DimenRes.dimen_1,
                              top: DimenRes.dimen_1),
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            color: const Color(0x3dffffff),
                            borderRadius: BorderRadius.circular(
                              DimenRes.radius(5),
                            ),
                          ),
                          child: TextWidget.buildSingleLineText(
                              widget.item.cityName ?? '',
                              AppTextStyle.build(
                                  Colors.white.withOpacity(0.72), 10)),
                        )
                      ],
                    ),
                    Padding(
                      padding: EdgeInsets.only(
                        top: DimenRes.convert(30.0),
                      ),
                      child: Text(
                        widget.item.desc ?? '',
                        softWrap: true,
                        overflow: TextOverflow.ellipsis,
                        maxLines: 4,
                        style: AppTextStyle.build(
                            Colors.white.withOpacity(0.72), 12),
                      ),
                    ),
                    const Spacer(
                      flex: 1,
                    ),
                    Row(
                      children: [
                        Text(
                          '年龄:',
                          style: AppTextStyle.build(
                              Colors.white.withOpacity(0.64), 12),
                        ),
                        const SpaceWidget(
                          hSpace: 5,
                        ),
                        TextWidget.buildSingleLineText(
                          "${widget.item.girlAge}",
                          AppTextStyle.white_s12,
                        ),
                        const SpaceWidget(
                          hSpace: 20,
                        ),
                        Text(
                          '罩杯:',
                          style: AppTextStyle.build(
                              Colors.white.withOpacity(0.64), 12),
                        ),
                        const SpaceWidget(
                          hSpace: 5,
                        ),
                        TextWidget.buildSingleLineText(
                          widget.item.girlCup ?? '未知',
                          AppTextStyle.white_s12,
                        )
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
