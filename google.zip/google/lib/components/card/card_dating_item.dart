import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/res/img_res.dart';
import 'package:iaimei/style/app_text_style.dart';
import 'package:iaimei/utils/page_jump_util.dart';
import 'package:iaimei/widget/app_img_widget.dart';
import 'package:iaimei/widget/frosted_glass_box.dart';
import 'package:iaimei/widget/network_img_container.dart';
import 'package:iaimei/widget/space_widget.dart';
import 'package:iaimei/widget/text_widget.dart';

class CardDatingItem extends StatelessWidget {
  final Map item;

  const CardDatingItem({
    Key? key,
    required this.item,
  }) : super(key: key);

  Widget markBadge(String text,
      {Color txtColor = const Color(0xa3ffffff),
      double fontSize = 10,
      Color bgColor = Colors.white12,
      BorderRadiusGeometry? radius,
      EdgeInsetsGeometry? margin}) {
    return Container(
      margin: margin,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: radius,
      ),
      padding: EdgeInsets.only(
        left: DimenRes.dimen_5,
        right: DimenRes.dimen_5,
        bottom: DimenRes.dimen_1,
        top: DimenRes.dimen_1,
      ),
      child: TextWidget.buildSingleLineText(
          text, AppTextStyle.build(txtColor, fontSize)),
    );
  }

  /// 名称和值
  Widget basicInfoItem(key, value) {
    return Container(
      alignment: Alignment.centerLeft,
      child: Text.rich(
        TextSpan(
          text: key,
          style: AppTextStyle.build(Colors.white.withOpacity(0.64), 12),
          children: [
            TextSpan(
              text: value,
              style: AppTextStyle.white_s12,
            ),
          ],
        ),
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
      ),
    );
  }

  /// 设置赔付按钮
  Widget _buildBadgePay() {
    if (item["is_peifu"] == 1) {
      return Container(
          margin:
              EdgeInsets.only(top: DimenRes.dimen_10, right: DimenRes.dimen_5),
          child: AppImgWidget(
            path: ImgRes.IC_BADGE_PAY,
            height: DimenRes.dimen_14,
          ));
    }
    return const SizedBox();
  }

  /// 设置认证按钮
  Widget _buildBadgeAuth() {
    if (item["type"] == 1) {
      return Container(
          margin:
              EdgeInsets.only(top: DimenRes.dimen_10, right: DimenRes.dimen_5),
          child: AppImgWidget(
            path: ImgRes.IC_BADGE_AUTH,
            height: DimenRes.dimen_14,
          ));
    }
    return const SizedBox();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        PageJumpUtil.forwardToDatingDetailPage(context, item["id"]);
      },
      child: FrostedGlassSimpleBox(
        margin: EdgeInsets.only(
          top: ScreenUtil().setWidth(15),
        ),
        child: Padding(
          padding: EdgeInsets.symmetric(
            horizontal: DimenRes.dimen_10,
            vertical: DimenRes.dimen_10,
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              NetworkImgContainer(
                radius: BorderRadius.circular(
                  ScreenUtil().setWidth(5),
                ),
                url: item["thumb_url"] ?? '',
                width: DimenRes.convert(100),
                height: DimenRes.convert(140),
                fit: BoxFit.cover,
              ),
              const SpaceWidget(
                hSpace: 10,
              ),
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Expanded(
                            child: TextWidget.buildSingleLineText(
                          item["title"] ?? '',
                          AppTextStyle.cff00b3_s16,
                        )),
                        markBadge(item["city_name"] ?? '',
                            radius: const BorderRadius.all(Radius.circular(5)),
                            margin: const EdgeInsets.only(left: 10)),
                      ],
                    ),
                    Row(
                      children: [_buildBadgePay(), _buildBadgeAuth()],
                    ),
                    Container(
                      margin: EdgeInsets.only(top: DimenRes.dimen_10),
                      padding: EdgeInsets.only(
                          top: DimenRes.dimen_10,
                          bottom: DimenRes.dimen_10,
                          left: DimenRes.dimen_10,
                          right: DimenRes.dimen_10),
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.12),
                        borderRadius: BorderRadius.circular(
                          ScreenUtil().setWidth(6),
                        ),
                      ),
                      child: Column(
                        children: [
                          Row(
                            children: [
                              basicInfoItem(
                                '年龄：',
                                item["girl_age"].toString(),
                              ),
                              const SpaceWidget(
                                hSpace: 20,
                              ),
                              basicInfoItem(
                                '罩杯：',
                                item["girl_cup"] ?? '',
                              ),
                            ],
                          ),
                          const SpaceWidget(
                            vSpace: 5,
                          ),
                          basicInfoItem(
                            '价格：',
                            item["girl_price"] ?? '',
                          ),
                          const SpaceWidget(
                            vSpace: 5,
                          ),
                          basicInfoItem(
                            '服务项目：',
                            item["girl_service_type"] ?? '',
                          ),
                          const SpaceWidget(
                            vSpace: 5,
                          ),
                          basicInfoItem(
                            '特征：',
                            item["girl_tags"] ?? '',
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
