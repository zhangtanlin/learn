import 'dart:async';

import 'package:flutter/material.dart'
    hide RefreshIndicator, RefreshIndicatorState;
import 'package:flutter/cupertino.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:iaimei/utils/common.dart';

class GifHeader extends RefreshIndicator {
  GifHeader({
    Key? key,
  }) : super(
          key: key,
          height: ScreenUtil().setWidth(80),
          refreshStyle: RefreshStyle.Follow,
        );
  @override
  State<StatefulWidget> createState() {
    return GifHeaderState();
  }
}

class GifHeaderState extends RefreshIndicatorState<GifHeader> {
  @override
  void initState() {
    super.initState();
  }

  @override
  void onModeChange(mode) {
    if (mode == RefreshStatus.refreshing) {}
    super.onModeChange(mode);
  }

  @override
  Future<void> endRefresh() {
    return Future.delayed(
      const Duration(microseconds: 500),
      () {},
    );
  }

  @override
  void resetValue() {
    super.resetValue();
  }

  @override
  Widget buildContent(BuildContext context, RefreshStatus mode) {
    return Container(
      margin: EdgeInsets.symmetric(
        vertical: ScreenUtil().setWidth(15),
      ),
      child: Image.asset(
        'assets/images/common/downrefresh.gif',
        // mode == RefreshStatus.refreshing
        //     ? 'assets/images/common/downrefresh.gif'
        //     : 'assets/images/common/downrefresh.png',
        height: ScreenUtil().setWidth(50),
        fit: BoxFit.fitHeight,
      ),
    );
  }

  @override
  void dispose() {
    super.dispose();
  }
}

// ignore: must_be_immutable
class PullRefreshList extends StatefulWidget {
  PullRefreshList(
      {Key? key,
      this.child,
      this.onRefresh,
      this.onLoading,
      this.isAll = false})
      : super(key: key);
  Widget? child;
  Function? onRefresh;
  Function? onLoading;
  bool isAll = false;
  @override
  _PullRefreshListState createState() => _PullRefreshListState();
}

class _PullRefreshListState extends State<PullRefreshList> {
  late RefreshController _refreshController;
  late Timer _timerout = Timer.periodic(const Duration(seconds: 10), (time) {});
  late Timer _timer =
      Timer.periodic(const Duration(milliseconds: 1500), (time) {});
  bool startReq = false;
  @override
  void initState() {
    super.initState();
    _refreshController = RefreshController(initialRefresh: false);
  }

  @override
  void dispose() {
    super.dispose();
    _refreshController.dispose();
    _timer.cancel();
    _timerout.cancel();
  }

  void _onRefresh() async {
    // 下拉刷新数据
    if (widget.onRefresh != null) {
      startReq = true;
      _timerout = Timer.periodic(const Duration(seconds: 10), (time) {
        time.cancel();
        if (_timer.isActive) {
          _timer.cancel();
        }
        Method.showText('请求超时,请您检查网络');
        _refreshController.refreshCompleted();
      });
      _timer = Timer.periodic(const Duration(milliseconds: 1500), (time) {
        if (!startReq) {
          if (_timerout.isActive) {
            _timerout.cancel();
          }
          time.cancel();
          _refreshController.refreshCompleted();
        }
      });
      await widget.onRefresh!();
      startReq = false;
    }
  }

  void _onLoading() async {
    // 加载更多数据
    if (widget.onLoading != null) {
      widget.onLoading!();
      _refreshController.loadComplete();
    }
  }

  @override
  Widget build(BuildContext context) {
    if (widget.isAll) {
      _refreshController.loadNoData();
    } else {
      _refreshController.resetNoData();
    }
    return SmartRefresher(
      enablePullDown: widget.onRefresh != null,
      enablePullUp: widget.onLoading != null,
      header: GifHeader(),
      footer: CustomFooter(
        builder: (BuildContext context, LoadStatus? mode) {
          Widget body;
          if (mode == LoadStatus.idle) {
            body = const Text("再拉一点", style: TextStyle(color: Colors.white));
          } else if (mode == LoadStatus.loading) {
            body = const CupertinoActivityIndicator();
          } else if (mode == LoadStatus.failed) {
            body = const Text("加载失败，点击重新加载",
                style: TextStyle(color: Colors.white));
          } else if (mode == LoadStatus.canLoading) {
            body =
                const Text("松手加载更多数据", style: TextStyle(color: Colors.white));
          } else {
            body = const Text("-- 我也是有底线的 --",
                style: TextStyle(color: Color.fromRGBO(255, 255, 255, 0.4)));
          }
          return SizedBox(
            height: 55.0,
            child: DefaultTextStyle(
              style: const TextStyle(color: Colors.white),
              child: Center(child: body),
            ),
          );
        },
      ),
      controller: _refreshController,
      onRefresh: _onRefresh,
      onLoading: _onLoading,
      child: widget.child,
    );
  }
}
