import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:iaimei/res/img_res.dart';

class StackPage extends StatefulWidget {
  const StackPage({
    Key? key,
    required this.child,
    this.header = const Text(""),
    this.bgPath,
  }) : super(key: key);
  final Widget child;
  final Widget header;
  final String? bgPath;
  @override
  State<StackPage> createState() => _StackPageState();
}

class _StackPageState extends State<StackPage> {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: MediaQuery.of(context).size.width,
      height: MediaQuery.of(context).size.height,
      decoration: BoxDecoration(
        image: DecorationImage(
            image: AssetImage(widget.bgPath ?? ImgRes.IMG_APP_BG),
            fit: BoxFit.cover,
            alignment: Alignment.topCenter),
      ),
      // child: Scaffold(
      //   appBar: PreferredSize(
      //     preferredSize: Size.fromHeight(44.w),
      //     child: AppBar(
      //       automaticallyImplyLeading: false,
      //       title: widget.header,
      //       backgroundColor: Colors.transparent,
      //       // backgroundColor: Colors.red,
      //       elevation: 0,
      //     ),
      //   ),
      //   backgroundColor: Colors.transparent,
      //   body: widget.child,
      // ),
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: Column(
          children: [
            SizedBox(height: MediaQuery.of(context).padding.top),
            widget.header,
            Expanded(child: widget.child),
          ],
        ),
      ),
    );
  }
}
