import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:iaimei/res/img_res.dart';
import 'package:iaimei/theme/default.dart';

/// 头部
/// [type]左侧类型{1: 仅是一个返回箭头,2: 圆形背景返回按钮}
/// [leftText]左侧文字
/// [center]表示中部部件
/// [right]表示右侧部件
class HeadBack extends StatefulWidget {
  final int? type;
  final String? leftText;
  final Widget? center;
  final Widget? right;

  const HeadBack({
    Key? key,
    this.type,
    required this.leftText,
    this.center,
    this.right,
  }) : super(key: key);

  @override
  State<HeadBack> createState() => _HeadBackState();
}

// 返回按钮+文字
Widget setLeftBtn(String? text, context) {
  return GestureDetector(
    onTap: () {
      Navigator.pop(context);
    },
    child: Container(
      padding: EdgeInsets.only(left: 7.w),
      height: ScreenUtil().setWidth(50.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            width: ScreenUtil().setWidth(36.0),
            height: ScreenUtil().setWidth(36.0),
            margin: EdgeInsets.only(
              right: ScreenUtil().setWidth(10.0),
            ),
            child: Image.asset(
              ImgRes.IC_ARROW_BACK,
              width: ScreenUtil().setWidth(15.0),
              fit: BoxFit.cover,
            ),
          ),
          Text(
            text ?? '',
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: DefaultStyle.white16,
          ),
        ],
      ),
    ),
  );
}

class _HeadBackState extends State<HeadBack> {
  @override
  Widget build(BuildContext context) {
    return Flex(
      direction: Axis.horizontal,
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: <Widget>[
        setLeftBtn(widget.leftText, context),
        widget.center ?? Container(),
        Padding(
          padding: EdgeInsets.only(right: 10.w),
          child: widget.right ?? Container(),
        ),
      ],
    );
  }
}
