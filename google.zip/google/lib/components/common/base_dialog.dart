import 'package:bot_toast/bot_toast.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:iaimei/components/common/glassmorphism.dart';
import 'package:iaimei/theme/default.dart';

class BaseDialog {
  static Future<dynamic> showdialog(BuildContext context,
      {Widget child = const SizedBox(),
      String title = '',
      Function? content,
      bool clear = false,
      Function? callBack,
      Function? cancelBack,
      String submitText = '确定',
      String cancelText = '取消',
      Function? changeBtnText,
      bool prohibitClose = false,
      bool barrierDismissible = false, //点击对话框barrier(遮罩)时是否关闭它
      double? raduis,
      Color barrierColor = Colors.black26,
      double insetPadding = 24.0}) {
    var radii = raduis ?? 24.w;
    return showDialog<dynamic>(
      context: context,
      barrierDismissible: barrierDismissible,
      barrierColor: barrierColor,
      builder: (context) {
        return Dialog(
          backgroundColor: Colors.transparent,
          insetPadding: EdgeInsets.all(insetPadding),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              DialogGlassmorphoismBox(
                  borderRadius: BorderRadius.circular(radii), child: child),
              SizedBox(height: 20.w),
              GestureDetector(
                onTap: () {
                  cancelBack?.call();
                  Navigator.pop(context);
                },
                child: Image.asset(
                  'assets/images/common/action_close.png',
                  height: 36.w,
                  width: 36.w,
                  fit: BoxFit.fitHeight,
                ),
              ),
            ],
          ),
        );
      },
    ).then((value) {
      if (cancelBack != null && clear) {
        cancelBack();
      }
    });
  }

  /// 轻提示
  /// [text]提示文字
  /// [type]类型{"success": "成功", "error/null": "失败/警告"}
  static toast({
    String text = '',
    String type = '',
  }) {
    String tempImgUrl;
    switch (type) {
      case "success":
        tempImgUrl = "assets/images/common/toast_success.png";
        break;
      default:
        tempImgUrl = "assets/images/common/toast_warn.png";
        break;
    }
    return BotToast.showCustomText(
      align: Alignment.center,
      toastBuilder: (cancelFunc) {
        return Container(
          width: ScreenUtil().setWidth(315.0),
          height: ScreenUtil().setWidth(168.0),
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: const Color.fromRGBO(0, 0, 0, 0.42),
            borderRadius: BorderRadius.all(
              Radius.circular(
                ScreenUtil().setWidth(14.0),
              ),
            ),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset(
                tempImgUrl,
                width: ScreenUtil().setWidth(60.0),
                height: ScreenUtil().setWidth(60.0),
              ),
              Padding(
                padding: EdgeInsets.only(
                  top: ScreenUtil().setWidth(15.0),
                ),
                child: Text(
                  text,
                  style: DefaultStyle.white16,
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
