import 'package:flutter/material.dart';
import 'package:iaimei/theme/default.dart';
import 'package:iaimei/utils/networkimage.dart';
import 'package:iaimei/widget/network_img_container.dart';

/// 头像
/// [url]头像地址
/// [coverImgUrl]覆盖头像的图片地址
class Avatar extends StatelessWidget {
  final double width;
  final double height;
  final BorderRadius borderRadius;
  final String url;
  final String? coverImgUrl;
  final Function()? onTap;
  const Avatar({
    Key? key,
    this.width = 72.0,
    this.height = 72.0,
    this.borderRadius = const BorderRadius.all(
      Radius.circular(12.0),
    ),
    required this.url,
    this.coverImgUrl,
    this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Widget tempCover = Container();
    if (coverImgUrl != null) {
      tempCover = Positioned(
        top: 0,
        right: 0,
        bottom: 0,
        left: 0,
        child: Image.asset(
          coverImgUrl!,
          width: width,
          height: height,
        ),
      );
    }
    return GestureDetector(
      onTap: () {
        if (onTap != null) {
          onTap!();
        }
      },
      child: ClipRRect(
        borderRadius: borderRadius,
        child: Stack(
          children: [
            Container(
              width: width,
              height: height,
              decoration: BoxDecoration(
                color: DefaultStyle.bgDefault,
                borderRadius: borderRadius,
              ),
              child: NetworkImgContainer(
                width: width,
                height: width,
                url: url,
              ),
            ),
            tempCover,
          ],
        ),
      ),
    );
  }
}
