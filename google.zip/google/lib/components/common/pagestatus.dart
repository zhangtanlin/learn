import 'package:bot_toast/bot_toast.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:iaimei/utils/networkimage.dart';

class PageStatus {
  //全屏式loding
  static Function showLoading({String text = ''}) {
    return BotToast.showLoading(
        backgroundColor: Colors.black45,
        wrapToastAnimation: (AnimationController animation, fc, Widget child) {
          return Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SpinKitFadingCircle(
                color: Color(0xffff00b3),
                size: 45.0,
              ),
              SizedBox(
                height: ScreenUtil().setWidth(15),
              ),
              Text(
                text,
                style: TextStyle(
                    color: const Color.fromRGBO(255, 255, 255, 1),
                    fontSize: ScreenUtil().setSp(12),
                    overflow: TextOverflow.ellipsis,
                    decoration: TextDecoration.none),
              )
            ],
          );
        });
  }

//列表loding
  static Widget loading(bool mouted, {String text = '正在为您加载数据...'}) {
    if (mouted) {
      return Container(
        alignment: Alignment.center,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SpinKitFadingCircle(
              color: Color(0xffff00b3),
              size: 45.0,
            ),
            SizedBox(
              height: ScreenUtil().setWidth(15),
            ),
            Text(
              text,
              style: TextStyle(
                  color: const Color(0xffd7d7d7),
                  fontSize: ScreenUtil().setSp(12),
                  overflow: TextOverflow.ellipsis,
                  decoration: TextDecoration.none),
            )
          ],
        ),
      );
    } else {
      return Container();
    }
  }

//关闭全屏式loading
  static void closeLoading() {
    return BotToast.closeAllLoading();
  }

//无数据
  static Widget noData({
    String text = '暂无数据',
    EdgeInsetsGeometry padding = const EdgeInsets.symmetric(
      vertical: 100,
    ),
  }) {
    return Container(
      padding: padding,
      alignment: Alignment.topCenter,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Image.asset(
            'assets/images/common/ic_no_data.png',
            width: ScreenUtil().setWidth(100),
            fit: BoxFit.fitWidth,
          ),
          SizedBox(
            height: ScreenUtil().setWidth(9),
          ),
          Text(
            text,
            style: TextStyle(
                color: Colors.white, fontSize: ScreenUtil().setSp(12)),
          )
        ],
      ),
    );
  }

//网络错误
  static Widget noNetWork(
      {String text = '加载失败，检查网络', required Function onTap}) {
    return InkWell(
      onTap: () {
        onTap();
      },
      child: Container(
        alignment: Alignment.topCenter,
        child: Padding(
          padding: EdgeInsets.only(top: ScreenUtil().setWidth(100)),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              PlatformAwareAssetImage(
                url: 'assets/images/networkerr.png',
                width: ScreenUtil().setWidth(100),
                fit: BoxFit.fitWidth,
              ),
              SizedBox(
                height: ScreenUtil().setWidth(9),
              ),
              Text(
                text,
              ),
              SizedBox(
                height: ScreenUtil().setWidth(20),
              ),
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  PlatformAwareAssetImage(
                    url: 'assets/images/icon_shuaxin.png',
                    width: ScreenUtil().setWidth(14),
                    fit: BoxFit.fitWidth,
                  ),
                  SizedBox(
                    width: ScreenUtil().setWidth(5),
                  ),
                  Text(
                    '轻触屏幕重试',
                    style: TextStyle(
                        fontSize: ScreenUtil().setSp(15),
                        color: const Color(0xfff52219)),
                  )
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
