import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class GlassmorphoismBox extends StatelessWidget {
  final Widget child;
  final double width;
  final double height;
  final BorderRadius borderRadius;
  const GlassmorphoismBox({
    Key? key,
    required this.child,
    required this.width,
    required this.height,
    this.borderRadius = const BorderRadius.all(Radius.circular(10)),
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: width,
      height: height,
      decoration: BoxDecoration(
        boxShadow: const [
          BoxShadow(
              blurStyle: BlurStyle.outer,
              color: Color.fromRGBO(26, 21, 47, 0.42),
              offset: Offset(0, 2),
              blurRadius: 5),
        ],
        color: const Color.fromRGBO(133, 102, 255, 0.12),
        borderRadius: borderRadius,
      ),
      child: Container(
        width: width,
        height: height,
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: [
            Colors.white.withOpacity(0.06),
            Colors.white.withOpacity(0.02),
          ], begin: Alignment.topLeft, end: Alignment.bottomRight),
          borderRadius: borderRadius,
          boxShadow: const [
            BoxShadow(
                blurStyle: BlurStyle.outer,
                color: Color.fromRGBO(255, 255, 255, 0.5),
                offset: Offset(0, -1),
                blurRadius: 0.1,
                spreadRadius: -0.5),
          ],
        ),
        child: child,
      ),
    );
  }
}

class GlassmorphoismTags extends StatelessWidget {
  final Widget child;
  final BorderRadius borderRadius;
  const GlassmorphoismTags({
    Key? key,
    required this.child,
    this.borderRadius = const BorderRadius.all(Radius.circular(15)),
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: const Color.fromRGBO(133, 102, 255, 0.12),
        borderRadius: borderRadius,
      ),
      child: Container(
        padding: EdgeInsets.symmetric(
            vertical: ScreenUtil().setWidth(6),
            horizontal: ScreenUtil().setWidth(20)),
        decoration: BoxDecoration(
          boxShadow: const [
            BoxShadow(
                blurStyle: BlurStyle.outer,
                color: Color.fromRGBO(255, 255, 255, 0.5),
                offset: Offset(0, -1),
                blurRadius: 0.1,
                spreadRadius: -0.5),
          ],
          gradient: LinearGradient(colors: [
            Colors.white.withOpacity(0.06),
            Colors.white.withOpacity(0.02),
          ], begin: Alignment.topLeft, end: Alignment.bottomRight),
          borderRadius: borderRadius,
        ),
        child: child,
      ),
    );
  }
}

class GlassmorphoismCityLabal extends StatelessWidget {
  final Widget child;
  final BorderRadius borderRadius;
  const GlassmorphoismCityLabal({
    Key? key,
    required this.child,
    this.borderRadius = const BorderRadius.all(Radius.circular(12)),
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: const Color.fromRGBO(133, 102, 255, 0.12),
        borderRadius: borderRadius,
      ),
      child: Container(
        padding: EdgeInsets.symmetric(
            vertical: ScreenUtil().setWidth(3),
            horizontal: ScreenUtil().setWidth(10)),
        decoration: BoxDecoration(
          boxShadow: const [
            // BoxShadow(
            //     blurStyle: BlurStyle.outer,
            //     color: Color.fromRGBO(26, 21, 47, 0.42),
            //     offset: Offset(0, 3),
            //     blurRadius: 5),
            BoxShadow(
                blurStyle: BlurStyle.outer,
                color: Color.fromRGBO(255, 255, 255, 0.5),
                offset: Offset(0, -1),
                blurRadius: 0.1,
                spreadRadius: -0.5),
          ],
          gradient: LinearGradient(colors: [
            Colors.white.withOpacity(0.06),
            Colors.white.withOpacity(0.02),
          ], begin: Alignment.topLeft, end: Alignment.bottomRight),
          borderRadius: borderRadius,
          // border: Border.all(
          //   width: 0.8,
          //   color: Colors.white.withOpacity(0.1),
          // ),
        ),
        child: child,
      ),
    );
  }
}

class HightGlassmorphoismBox extends StatelessWidget {
  const HightGlassmorphoismBox({
    Key? key,
    required this.child,
    this.width = double.infinity,
    this.height = double.infinity,
    this.borderRadius = const BorderRadius.all(Radius.circular(0)),
  }) : super(key: key);
  final Widget child;
  final double width;
  final double height;
  final BorderRadius borderRadius;

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 3, sigmaY: 3),
        child: Container(
          width: width,
          height: height,
          decoration: BoxDecoration(
            color: const Color.fromRGBO(133, 102, 255, 0.12),
            borderRadius: borderRadius,
          ),
          child: Container(
            width: width,
            height: height,
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [
                Colors.white.withOpacity(0.06),
                Colors.white.withOpacity(0.02),
              ], begin: Alignment.topLeft, end: Alignment.bottomRight),
              borderRadius: borderRadius,
              border: Border.all(
                width: 0.8,
                color: Colors.white.withOpacity(0.1),
              ),
            ),
            child: child,
          ),
        ),
      ),
    );
  }
}

class CardGlassmorphoismBox extends StatelessWidget {
  const CardGlassmorphoismBox({
    Key? key,
    required this.child,
    this.width = double.infinity,
    this.height = double.infinity,
    this.sigma = 20.0,
    this.borderRadius = const BorderRadius.all(Radius.circular(0)),
    this.alignment = Alignment.center,
  }) : super(key: key);
  final Widget child;
  final double width;
  final double height;
  final double sigma;
  final BorderRadius borderRadius;
  final AlignmentGeometry alignment;

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: borderRadius,
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: sigma, sigmaY: sigma),
        child: Container(
            width: width,
            height: height,
            alignment: alignment,
            decoration: BoxDecoration(
              borderRadius: borderRadius,
            ),
            child: child),
      ),
    );
  }
}

class DialogGlassmorphoismBox extends StatelessWidget {
  const DialogGlassmorphoismBox({
    Key? key,
    required this.child,
    this.width = double.infinity,
    this.height = double.infinity,
    this.sigma = 13.0,
    this.borderRadius = const BorderRadius.all(Radius.circular(0)),
    this.alignment = Alignment.center,
  }) : super(key: key);
  final Widget child;
  final double width;
  final double height;
  final double sigma;
  final BorderRadius borderRadius;
  final AlignmentGeometry alignment;

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: borderRadius,
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: sigma, sigmaY: sigma),
        child: Container(
          width: double.infinity,
          decoration: const BoxDecoration(
            gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Color.fromRGBO(178, 170, 255, 0.12),
                  Color.fromRGBO(108, 82, 222, 0.08),
                ]),
          ),
          child: Container(
            width: double.infinity,
            margin: const EdgeInsets.all(0.5),
            decoration: BoxDecoration(
              color: const Color(0xff56257B).withOpacity(0.4),
              borderRadius: BorderRadius.circular(24.w),
              // color: const Color(0x666e399d).withOpacity(0.2),
              border: Border.all(color: const Color(0x4dffffff), width: 0.5),
              // gradient: LinearGradient(colors: [
              //   const Color(0xff56257B).withOpacity(0.4),
              //   const Color(0xff56257B).withOpacity(0.4),
              // ], begin: Alignment.topCenter, end: Alignment.bottomCenter),
            ),
            child: child,
          ),
        ),
      ),
    );
  }
}

/// 红色按钮
class RedGlassmorphoismBox extends StatelessWidget {
  final double? width;
  final double? height;
  final BorderRadius? borderRadius;
  final Widget child;
  const RedGlassmorphoismBox({
    Key? key,
    this.width,
    this.height,
    this.borderRadius = const BorderRadius.all(
      Radius.circular(20.0),
    ),
    required this.child,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: width,
          height: height,
          decoration: BoxDecoration(
            color: const Color.fromRGBO(255, 0, 179, 1),
            borderRadius: borderRadius,
            gradient: const LinearGradient(
              colors: [
                Color.fromRGBO(255, 0, 179, .25),
                Color.fromRGBO(255, 0, 179, 1),
              ],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
          ),
          child: Container(
            width: width,
            height: height,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              boxShadow: const [
                BoxShadow(
                  // 阴影颜色
                  color: Color.fromRGBO(255, 0, 179, .75),
                  // 偏移量(x, y)
                  offset: Offset(0, 0),
                  // 模糊量(0-1),0表示一点都不模糊
                  blurRadius: 1,
                  // 模糊距离
                  spreadRadius: 0,
                  // 模糊样式{inner: 内部,normal: 正常,outer: 外部,solid: 实体(里面结实外面模糊),values: 常量值(按顺序取值),}
                  blurStyle: BlurStyle.outer,
                ),
              ],
              gradient: const LinearGradient(
                colors: [
                  Color.fromRGBO(0, 0, 0, .25),
                  Color.fromRGBO(0, 0, 0, 0),
                  Color.fromRGBO(0, 0, 0, .25),
                ],
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
              ),
              borderRadius: borderRadius,
            ),
            child: child,
          ),
        ),
      ],
    );
  }
}
