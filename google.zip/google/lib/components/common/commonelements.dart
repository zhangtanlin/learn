import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:iaimei/model/video_model.dart';
import 'package:iaimei/res/img_res.dart';
import 'package:iaimei/router/routers.dart';
import 'package:iaimei/utils/common_utils.dart';
import 'package:iaimei/utils/video_util.dart';
import 'package:iaimei/widget/network_img_container.dart';

class WaterfallExtra {
  WaterfallExtra({
    required this.title,
    this.isWaterfallsflow = false,
    this.crossAxisCount = 1,
    this.url = '',
    this.params,
    this.showSubscript = true,
  });

  bool isWaterfallsflow; // 是否采用瀑布流布局，开启则crossAxisCount失效
  String title; // 页面标题
  int crossAxisCount; // 一行显示个数，默认1
  String url; // 接口地址
  dynamic params; // 接口参数
  bool showSubscript;
}

class TitleCell extends StatelessWidget {
  const TitleCell({
    Key? key,
    required this.title,
    this.isWaterfallsflow = false,
    this.crossAxisCount = 1,
    this.url = '',
    this.label = '',
    this.onTap,
    this.params,
  }) : super(key: key);
  final String title;
  final String label;
  final bool isWaterfallsflow;
  final int crossAxisCount;
  final String url;
  final dynamic params;
  final GestureTapCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
        behavior: HitTestBehavior.translucent,
        onTap: () {
          if (onTap != null) {
            onTap?.call();
          } else {
            WaterfallExtra object = WaterfallExtra(
              title: title,
              isWaterfallsflow: isWaterfallsflow,
              crossAxisCount: crossAxisCount,
              url: url,
              params: params,
            );
            context.push('/${Routes.mvListViewPage}', extra: object);
          }
        },
        child: Padding(
          padding: EdgeInsets.only(
              left: ScreenUtil().setWidth(16),
              right: ScreenUtil().setWidth(16),
              top: ScreenUtil().setWidth(20),
              bottom: ScreenUtil().setWidth(9)),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                mainAxisSize: MainAxisSize.max,
                children: [
                  SizedBox(
                    width: 0.8.sw,
                    child: Text(title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w500,
                            fontStyle: FontStyle.normal,
                            fontSize: ScreenUtil().setSp(18))),
                  ),
                  Image.asset(
                    "assets/images/common/arrow_go.png",
                    width: ScreenUtil().setWidth(12),
                    height: ScreenUtil().setWidth(18),
                  ),
                ],
              ),
              Offstage(
                offstage: label.isEmpty,
                child: Text(label,
                    style: TextStyle(
                        color: const Color.fromRGBO(255, 255, 255, 0.74),
                        fontWeight: FontWeight.w400,
                        fontStyle: FontStyle.normal,
                        fontSize: ScreenUtil().setWidth(12))),
              )
            ],
          ),
        ));
  }
}

class GirlAvatar extends StatelessWidget {
  const GirlAvatar({
    Key? key,
    required this.name,
    this.id = 0,
    required this.onTap,
    required this.url,
  }) : super(key: key);
  final String name;
  final int id;
  final GestureTapCallback onTap;
  final String url;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        onTap.call();
      },
      child: Container(
        width: ScreenUtil().setWidth(44),
        margin: EdgeInsets.only(right: ScreenUtil().setWidth(20)),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ClipOval(
              child: SizedBox(
                width: 44.w,
                height: 44.w,
                child: NetworkImgContainer(
                  url: url,
                  fit: BoxFit.cover,
                ),
              ),
            ),
            SizedBox(height: ScreenUtil().setWidth(5)),
            Text(name,
                overflow: TextOverflow.ellipsis,
                maxLines: 1,
                style: TextStyle(
                    color: const Color(0xffffffff),
                    fontWeight: FontWeight.w400,
                    fontStyle: FontStyle.normal,
                    fontSize: ScreenUtil().setSp(10)),
                textAlign: TextAlign.center)
          ],
        ),
      ),
    );
  }
}

class HorderLine extends StatelessWidget {
  const HorderLine({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: ScreenUtil().setWidth(16)),
      width: double.infinity,
      height: ScreenUtil().setWidth(0.5),
      color: const Color.fromRGBO(255, 255, 255, 0.2),
    );
  }
}

/// 头部操作按钮
/// [url] 图标地址
/// [mark] 是否有标记（例如消息按钮上的白色标点）
/// [onTap] 点击事件
class ActionIcon extends StatelessWidget {
  final String url;
  final bool mark;
  final GestureTapCallback onTap;

  const ActionIcon({
    Key? key,
    required this.url,
    this.mark = false,
    required this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Widget setMark() {
      if (mark) {
        return Positioned(
          top: ScreenUtil().setWidth(3.0),
          right: ScreenUtil().setWidth(3.0),
          child: Container(
            width: ScreenUtil().setWidth(7.5),
            height: ScreenUtil().setWidth(7.5),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(
                ScreenUtil().setWidth(7.5),
              ),
            ),
          ),
        );
      }
      return Container();
    }

    return GestureDetector(
      onTap: onTap,
      child: Stack(
        children: [
          SizedBox(
            width: ScreenUtil().setWidth(35),
            height: ScreenUtil().setWidth(35),
            child: Image.asset(
              url,
              fit: BoxFit.contain,
            ),
          ),
          setMark(),
        ],
      ),
    );
  }
}

class CustomHeader extends StatefulWidget {
  const CustomHeader({
    Key? key,
    this.lMargin,
    this.popAction,
    this.title,
    this.titleWidget,
    this.height, // default 44.w
    final List<Widget>? rListWidget,
  })  : listWidget = rListWidget,
        super(key: key);
  final double? height;
  final double? lMargin;
  final Function()? popAction;
  final String? title;
  final Widget? titleWidget;
  final List<Widget>? listWidget;

  @override
  State<CustomHeader> createState() => _CustomHeaderState();
}

class _CustomHeaderState extends State<CustomHeader> {
  void popAction() {
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: widget.height ?? 44.w,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(width: widget.lMargin ?? 6.w),
          GestureDetector(
            onTap: widget.popAction ?? popAction,
            child: Image.asset(ImgRes.IC_ARROW_BACK, height: 36.w, width: 36.w),
          ),
          SizedBox(width: 10.w),
          Expanded(
            child: widget.titleWidget ??
                Text(
                  widget.title ?? '',
                  style: TextStyle(color: Colors.white, fontSize: 18.w),
                ),
          ),
          SizedBox(width: 10.w),
          ...widget.listWidget ?? [],
        ],
      ),
    );
  }
}