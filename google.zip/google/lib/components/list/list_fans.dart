import 'package:flutter/material.dart';
import 'package:iaimei/components/card/card_follow.dart';
import 'package:iaimei/components/common/pullrefreshlist.dart';
import 'package:iaimei/components/common/pagestatus.dart';
import 'package:iaimei/model/model_fans_list.dart';
import 'package:iaimei/theme/default.dart';
import 'package:iaimei/utils/api.dart';

/// 粉丝列表列表
/// [type]类型{0: 粉丝，1: 关注}
/// [uid]类型{null: 表示自己的粉丝/关注列表,uid:表示别人的粉丝/关注列表}
class ListFans extends StatefulWidget {
  final int? type;
  final String? uid;
  const ListFans({
    Key? key,
    this.type = 0,
    this.uid,
  }) : super(key: key);

  @override
  State<ListFans> createState() => _ListFansState();
}

class _ListFansState extends State<ListFans> {
  bool loading = true; // 加载状态
  List<Datum> data = [];
  int page = 1;
  int limit = 10;
  bool isAll = false;

  Future<void> getData() async {
    if (isAll) return;
    ModelFansList? res;
    switch (widget.type) {
      case 1:
        res = await apiFollowedList(
          page: page,
          limit: limit,
          uid: widget.uid,
        );
        break;
      default:
        res = await apiFansList(
          page: page,
          limit: limit,
          uid: widget.uid,
        );
    }
    if (res?.status == 1) {
      List<Datum> tempData = res!.data ?? [];
      if (page == 1) {
        data = tempData;
      } else {
        data.addAll(tempData);
      }
      if (tempData.length < limit) {
        isAll = true;
      } else {
        isAll = false;
      }
    }
    loading = false;
    setState(() {});
  }

  @override
  void initState() {
    super.initState();
    getData();
  }

  Widget setListWidget() {
    if (data.isEmpty) {
      return PageStatus.noData();
    }
    return ListView.builder(
      itemCount: data.length,
      itemBuilder: (
        BuildContext context,
        int index,
      ) {
        return CardFollow(
          item: data[index],
        );
      },
    );
  }

  Widget init() {
    if (loading) {
      return PageStatus.loading(true);
    }
    return Padding(
      padding: EdgeInsets.symmetric(
        horizontal: DefaultStyle.pagePadding,
      ),
      child: Flex(
        direction: Axis.vertical,
        children: [
          Expanded(
            child: PullRefreshList(
              onLoading: () {
                if (!isAll) {
                  page++;
                  getData();
                }
              },
              onRefresh: () {
                page = 1;
                isAll = false;
                getData();
              },
              child: setListWidget(),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return init();
  }
}
