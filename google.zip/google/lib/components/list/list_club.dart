import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:iaimei/components/card/card_follow.dart';
import 'package:iaimei/components/common/pullrefreshlist.dart';
import 'package:iaimei/components/common/pagestatus.dart';
import 'package:iaimei/model/model_club_list.dart';
import 'package:iaimei/model/model_fans_list.dart';
import 'package:iaimei/theme/default.dart';
import 'package:iaimei/utils/api.dart';

/// 粉丝列表
class ListClub extends StatefulWidget {
  final dynamic id;
  const ListClub({
    Key? key,
    this.id,
  }) : super(key: key);

  @override
  State<ListClub> createState() => _ListClubState();
}

class _ListClubState extends State<ListClub> {
  bool loading = true; // 加载状态
  List<Datum> data = [];
  int? count = 0;
  int? todayCount = 0;
  int page = 1;
  int limit = 10;
  bool isAll = false;

  Future<void> getData() async {
    if (isAll) return;
    ModelClubList? res = await apiClubMemberList(
      page: page,
      limit: limit,
      id: widget.id,
    );
    if (res?.status == 1) {
      List<Datum> tempData = res!.data!.list ?? [];
      int tempCount = res.data!.count ?? 0;
      int tempTodayCount = res.data!.todayCount ?? 0;
      if (page == 1) {
        count = tempCount;
        todayCount = tempTodayCount;
        data = tempData;
      } else {
        data.addAll(tempData);
      }
      if (tempData.length < limit) {
        isAll = true;
      } else {
        isAll = false;
      }
    }
    loading = false;
    setState(() {});
  }

  @override
  void initState() {
    super.initState();
    getData();
  }

  /// 如果是粉丝团就显示统计列表
  Widget statisticsBox() {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: ScreenUtil().setWidth(25.0),
        vertical: ScreenUtil().setWidth(10.0),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            "粉丝团共$count人",
            style: DefaultStyle.white12,
          ),
          Text(
            "今日新增$todayCount人",
            style: DefaultStyle.red12,
          ),
        ],
      ),
    );
  }

  Widget setListWidget() {
    if (data.isEmpty) {
      return PageStatus.noData();
    }
    return ListView.builder(
      itemCount: data.length,
      itemBuilder: (
        BuildContext context,
        int index,
      ) {
        return CardFollow(
          item: data[index],
        );
      },
    );
  }

  Widget init() {
    if (loading) {
      return PageStatus.loading(true);
    }
    return Padding(
      padding: EdgeInsets.symmetric(
        horizontal: DefaultStyle.pagePadding,
      ),
      child: Flex(
        direction: Axis.vertical,
        children: [
          statisticsBox(),
          Expanded(
            child: PullRefreshList(
              isAll: isAll,
              onLoading: () {
                if (!isAll) {
                  page++;
                  getData();
                }
              },
              onRefresh: () {
                page = 1;
                isAll = false;
                getData();
              },
              child: setListWidget(),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return init();
  }
}
