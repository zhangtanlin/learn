import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:iaimei/components/card/card_pictures.dart';
import 'package:iaimei/components/common/pullrefreshlist.dart';
import 'package:iaimei/components/common/pagestatus.dart';
import 'package:iaimei/model/model_collect_buy_pictures.dart';
import 'package:iaimei/theme/default.dart';
import 'package:iaimei/utils/api.dart';

/// 收藏/购买-图集列表
/// [type]{0/null:收藏,1:购买}
class ListPicturesCollectBuy extends StatefulWidget {
  final int? type;
  const ListPicturesCollectBuy({
    Key? key,
    this.type = 0,
  }) : super(key: key);

  @override
  State<ListPicturesCollectBuy> createState() => _ListPicturesCollectBuyState();
}

class _ListPicturesCollectBuyState extends State<ListPicturesCollectBuy> {
  // 加载状态
  bool _loading = true;
  List _data = [];
  int _page = 1;
  final int _limit = 10;
  bool _isAll = false;

  Future<void> _getData() async {
    if (_isAll) return;
    ModelCollectBuyPictures? res;
    switch (widget.type) {
      case 1:
        res = await apiBuyPictures(page: _page, limit: _limit);
        break;
      default:
        res = await apiFavoritesPictures(page: _page, limit: _limit);
    }
    List<Datum>? tempData = res?.data ?? [];
    if (res?.status == 1) {
      if (_page == 1) {
        _data = tempData;
      } else {
        _data.addAll(tempData);
      }
      if (tempData.length < _limit) {
        _isAll = true;
      } else {
        _isAll = false;
      }
    }
    _loading = false;
    setState(() {});
  }

  Future<void> _initData() async {
    await _getData();
  }

  @override
  void initState() {
    super.initState();
    _initData();
  }

  @override
  Widget build(BuildContext context) {
    return _init();
  }

  Widget _init() {
    Widget _widget = PageStatus.loading(true);
    return _loading ? _widget : _listView();
  }

  Widget _listView() {
    if (_data.isNotEmpty) {
      return Padding(
        padding: EdgeInsets.fromLTRB(16.w, 10.w, 16.w, 20.w),
        child: PullRefreshList(
          isAll: _isAll,
          onRefresh: () {
            _page = 1;
            _isAll = false;
            _initData();
          },
          onLoading: () {
            if (!_isAll) {
              _page++;
              _getData();
            }
          },
          child: ListView.builder(
            itemCount: _data.length,
            itemBuilder: (
              BuildContext context,
              int index,
            ) {
              return CardPicturesCollectBuy(
                item: _data[index],
              );
            },
          ),
        ),
      );
    }
    return PageStatus.noData(
      padding: EdgeInsets.only(
        top: ScreenUtil().setWidth(20.0),
      ),
    );
  }
}
