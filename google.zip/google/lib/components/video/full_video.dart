import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:iaimei/pages/video/long_video_player.dart';
import 'package:video_player/video_player.dart';

class FullVideo extends StatefulWidget {
  const FullVideo({
    Key? key,
    required this.controller,
  }) : super(key: key);
  final VideoPlayerController controller;
  @override
  _FullVideoState createState() => _FullVideoState();
}

class _FullVideoState extends State<FullVideo> {
  @override
  void initState() {
    super.initState();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.manual, overlays: []);
    SystemChrome.setPreferredOrientations(
      [
        DeviceOrientation.landscapeLeft,
        DeviceOrientation.landscapeRight,
      ],
    );
  }

  @override
  void dispose() {
    SystemChrome.setPreferredOrientations(
      [DeviceOrientation.portraitUp, DeviceOrientation.portraitDown],
    );
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black54,
      body: SafeArea(
        child: LongVideoPlayer(
          controller: widget.controller,
          isFull: true,
          // videoUrl: '',
        ),
      ),
    );
  }
}
