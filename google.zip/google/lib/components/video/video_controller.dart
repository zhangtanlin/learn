import 'dart:async';
import 'dart:ui' as ui;
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:iaimei/components/video/full_video.dart';
import 'package:iaimei/pages/video/long_video_player.dart';
import 'package:iaimei/mixin/video_mixin.dart';
import 'package:iaimei/theme/default.dart';
import 'package:iaimei/utils/common.dart';
import 'package:video_player/video_player.dart';

class VideoController extends StatefulWidget {
  const VideoController({
    Key? key,
    required this.videoController,
    this.hideControl = false,
    this.initShow = false,
    this.id,
    this.data,
    this.autoPlay = true,
    this.loop = true,
    this.noVolume = false,
    this.noBack = true,
    this.isFull = false,
    this.setController,
    this.videoUrl = '',
    this.setVideoUrl,
    this.isLocal = false,
    this.isPreview = false,
    this.setPreviewShow,
    this.previewShow = false,
  }) : super(key: key);
  final VideoPlayerController videoController;
  final bool hideControl;
  final bool initShow;
  final String? id;
  final dynamic data;
  final bool autoPlay;
  final bool loop;
  final bool noVolume;
  final bool noBack;
  final bool isFull;
  final String videoUrl;
  final Function? setVideoUrl;
  final bool isLocal;
  final SetControllerCallback? setController;
  final bool isPreview;
  final Function? setPreviewShow;
  final bool previewShow;
  @override
  _VideoControllerState createState() => _VideoControllerState();
}

class _VideoControllerState extends State<VideoController> with VideoMinxin {
  bool showControl = false; //控制器展示
  bool isLock = false; //锁定状态
  Timer timerfc =
      Timer.periodic(const Duration(seconds: 2), (time) {}); //播放暂停按钮的隐藏定时器
  double videoValue = 0.0; //当前视频播放时间
  double videoMaxTime = 0.0; //视频总播放时间
  bool changeStartIsPlay = false; //拖动进度条时视频是否处于播放状态
  bool videoPageIsActive = true;
  bool loading = true;

  double panStart = 0;
  bool showUpTime = false;
  double upValue = 0;
  bool usecheck = false;
  bool videoPlayErr = false;
  ui.Image? customImage;

  Future<ui.Image> load(String asset) async {
    ByteData data = await rootBundle.load(asset);
    ui.Codec codec = await ui.instantiateImageCodec(data.buffer.asUint8List(),
        targetHeight: 16, targetWidth: 12);
    ui.FrameInfo frameInfo = await codec.getNextFrame();
    return frameInfo.image;
  }

  @override
  void initState() {
    load("assets/images/video/ic_slider_bar.png").then((image) {
      customImage = image;
    });
    super.initState();
    if (widget.initShow) {
      showControl = true;
    }

    // EventBus().on('stop-current-play', (arg) {
    //   if (widget.videoController.value.isPlaying) {
    //     widget.videoController.pause();
    //   }
    //   videoPageIsActive = false;
    // });
    if (widget.videoController.value.isInitialized) {
      videoMaxTime =
          widget.videoController.value.duration.inMilliseconds.toDouble();
      videoValue =
          widget.videoController.value.position.inMilliseconds.toDouble();
      setState(() {});
      widget.videoController.addListener(setVideoValue);
    } else {
      initVideo();
    }
  }

  initVideo() {
    if (videoPlayErr) {
      videoPlayErr = false;
      setState(() {});
    }
    widget.videoController.initialize().then((value) {
      widget.videoController.addListener(setVideoValue);
      if (widget.setController != null) {
        widget.setController!(widget.videoController);
      }
      if (widget.loop) {
        widget.videoController.setLooping(widget.loop);
      }
      if (widget.autoPlay &&
          !kIsWeb &&
          videoPageIsActive &&
          !widget.videoController.value.isPlaying) {
        if (!widget.hideControl) {
          hideControl();
        }
        widget.videoController.play();
        setState(() {});
      }
    }).onError((error, stackTrace) {
      if (mounted) {
        videoPlayErr = true;
        setState(() {});
        Method.debugPrint(widget.videoUrl);
        Method.debugPrint('【播放资源时出错】:$error');
        Method.showText('视频资源播放错误');
      }
    }).timeout(const Duration(seconds: 30), onTimeout: () {
      if (mounted) {
        videoPlayErr = true;
        setState(() {});
        Method.showText('视频资源播放超时');
      }
    });
  }

  @override
  void dispose() {
    if (widget.videoController != null) {
      widget.videoController.removeListener(setVideoValue);
    }
    if (!widget.isFull) {
      widget.videoController.dispose();
      // EventBus().off('stop-current-play');
    }
    timerfc.cancel();
    super.dispose();
  }

  getTimeStr(double time) {
    int s = (time / 1000 / 60).truncate();
    int h = (time / 1000 - (s * 60)).truncate();
    String timeStr(int numb) {
      return numb < 10 ? '0$numb' : numb.toString();
    }

    return '${timeStr(s)}:${timeStr(h)}';
  }

  Future<void> changeFull() async {
    if (widget.isFull) {
     SystemChrome.setPreferredOrientations(
              [DeviceOrientation.portraitUp, DeviceOrientation.portraitDown]);
      Navigator.pop(context);
    } else {
      if (widget.videoController.value.isInitialized) {
       Navigator.push(
                context,
                PageRouteBuilder(
                  transitionDuration:
                      const Duration(milliseconds: 0), //动画时间为500毫秒
                  pageBuilder: (BuildContext context,
                      Animation<double> animation,
                      Animation secondaryAnimation) {
                    return FadeTransition(
                      //使用渐隐渐入过渡,
                      opacity: animation,
                      child: FullVideo(
                        controller: widget.videoController,
                      ), //路由B
                    );
                  },
                ),
              );
      } else {
        Method.showText('视频正在加载中...');
      }
    }
  }

  setVideoValue() {
    if (widget.videoController.value.hasError) {
      Method.debugPrint(widget.videoController.value.errorDescription);
    }
    if (widget.isPreview) {
      widget.setPreviewShow!(widget.videoController.value.isPlaying);
    }
    videoMaxTime =
        widget.videoController.value.duration.inMilliseconds.toDouble();
    if (!usecheck) {
      videoValue =
          widget.videoController.value.position.inMilliseconds.toDouble();
    }
    if (widget.videoController.value.buffered.isNotEmpty) {
      double bufValue = widget
          .videoController.value.buffered.last.end.inMilliseconds
          .toDouble();
      if (videoValue < bufValue - 1000.0 ||
          widget.videoController.value.buffered.last.end.inMilliseconds ==
              widget.videoController.value.duration.inMilliseconds) {
        loading = false;
      } else {
        loading = true;
      }
    }
    setState(() {});
  }

  hideControl() {
    if (widget.hideControl) return;
    if (!showControl) {
      showControl = true;
      setState(() {});
    }
    if (widget.videoController == null) return;
    if (timerfc != null) {
      timerfc.cancel();
      timerfc = Timer.periodic(const Duration(seconds: 2), (time) {
        if (widget.videoController.value.isPlaying) {
          showControl = false;
          setState(() {});
        }
        time.cancel();
      });
    } else {
      timerfc = Timer.periodic(const Duration(seconds: 2), (time) {
        if (widget.videoController.value.isPlaying) {
          showControl = false;
          setState(() {});
        }
        time.cancel();
      });
    }
  }

  Widget controlShow() {
    return Stack(
      children: [
        Positioned(
            child:
                mounted && widget.videoController.value.isBuffering && loading
                    ? const Center(
                        child: SpinKitFadingCircle(
                        color: Color(0xffff00b3),
                        size: 45.0,
                      ))
                    : Container()),
        animatedBox(
            top: null,
            bottom: showControl && !isLock && !widget.isPreview ? 0 : -44.w,
            opacity: showControl && !isLock && !widget.isPreview ? 1 : 0,
            child: !widget.videoController.value.isInitialized ||
                    widget.isPreview
                ? const SizedBox()
                : Container(
                    width: double.infinity,
                    decoration: const BoxDecoration(
                        gradient: LinearGradient(
                      colors: [Color.fromRGBO(0, 0, 0, 0), Colors.black38],
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                    )),
                    padding: EdgeInsets.symmetric(
                        horizontal: DefaultStyle.pagePadding),
                    child: Row(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        GestureDetector(
                          onTap: () {
                            if (widget.videoController.value.isPlaying) {
                              widget.videoController.pause();
                              hideControl();
                            } else {
                              widget.videoController.play();
                              videoPageIsActive = true;
                              hideControl();
                            }
                          },
                          child: Image.asset(
                            'assets/images/video/${widget.videoController.value.isPlaying ? 'stop_icon' : 'play_icon'}.png',
                            width: 20.w,
                            fit: BoxFit.cover,
                          ),
                        ),
                        Expanded(
                            child: SliderTheme(
                                data: SliderTheme.of(context).copyWith(
                                  trackHeight: 2.w,
                                  trackShape: GradientSliderTrackShape(
                                    linearGradient: const LinearGradient(
                                        colors: [
                                          Color(0xffff36da),
                                          Color(0xffa653ff)
                                        ]),
                                  ),
                                  inactiveTrackColor: const Color(0x3dffffff),
                                  thumbShape: customImage != null
                                      ? SliderThumbImage(customImage!)
                                      : const RoundSliderThumbShape(),
                                ),
                                child: Slider(
                                    value: videoValue > videoMaxTime
                                        ? videoMaxTime
                                        : videoValue,
                                    max: videoMaxTime,
                                    min: 0,
                                    onChangeStart: (e) {
                                      usecheck = true;
                                      changeStartIsPlay = widget
                                          .videoController.value.isPlaying;
                                      widget.videoController.pause();
                                    },
                                    onChangeEnd: (e) {
                                      if (changeStartIsPlay) {
                                        widget.videoController.play();
                                        videoPageIsActive = true;
                                      }
                                    },
                                    onChanged: (e) {
                                      try {
                                        if (widget.videoController.value
                                            .isInitialized) {
                                          videoValue = e;
                                          setState(() {});
                                          widget.videoController
                                              .seekTo(Duration(
                                                  milliseconds:
                                                      videoValue.toInt()))
                                              .then((value) {
                                            usecheck = false;
                                          });
                                        }
                                      } catch (e) {
                                        return;
                                      }
                                    }))),
                        Text(
                          getTimeStr(videoValue),
                          style: DefaultStyle.white10,
                        ),
                        Text(
                          '/',
                          style: DefaultStyle.white10,
                        ),
                        Text(
                          getTimeStr(videoMaxTime),
                          style: DefaultStyle.white10,
                        ),
                        GestureDetector(
                          onTap: changeFull,
                          child: Container(
                            margin: EdgeInsets.only(left: 15.w),
                            child: Image.asset(
                              'assets/images/video/${widget.isFull ? 'close_full' : 'fullscreen'}.png',
                              width: 20.w,
                              fit: BoxFit.cover,
                            ),
                          ),
                        )
                      ],
                    ),
                  )),
        animatedBox(
            right: null,
            left: showControl ? 0 : -100.w,
            child:
                widget.videoController.value.isInitialized && !widget.isPreview
                    ? Center(
                        child: Padding(
                          padding: EdgeInsets.all(DefaultStyle.pagePadding),
                          child: GestureDetector(
                            onTap: () {
                              isLock = !isLock;
                              setState(() {});
                            },
                            behavior: HitTestBehavior.translucent,
                            child: Icon(
                              isLock ? Icons.lock : Icons.lock_open,
                              color: Colors.white,
                              size: 30.w,
                            ),
                          ),
                        ),
                      )
                    : Container()),
        Positioned(
            child: !showUpTime || widget.isPreview
                ? Container()
                : Center(
                    child: Container(
                      decoration: BoxDecoration(
                          color: Colors.black87,
                          borderRadius: BorderRadius.circular(10.w)),
                      padding: EdgeInsets.symmetric(
                          horizontal: 15.w, vertical: 10.w),
                      child: Text(getTimeStr(videoValue),
                          style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize:
                                  ScreenUtil().setSp(1.sw > 1.sh ? 50 : 18))),
                    ),
                  )),
        animatedBox(
            top: showControl && !isLock || widget.isPreview ? 0 : -44.w,
            bottom: null,
            opacity: showControl && !isLock ? 1 : 0,
            child: head(
                noBack: true,
                rightWidget: widget.videoController.value.isInitialized &&
                        !widget.isPreview
                    ? GestureDetector(
                        onTap: () {
                          if (widget.videoController.value.volume > 0) {
                            widget.videoController.setVolume(0);
                          } else {
                            widget.videoController.setVolume(1);
                          }
                        },
                        child: Container(
                          margin: EdgeInsets.only(left: 15.w),
                          child: Icon(
                            widget.videoController.value.volume > 0
                                ? Icons.volume_up
                                : Icons.volume_off,
                            color: Colors.white,
                            size: 22.w,
                          ),
                        ),
                      )
                    : Container())),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return videoPlayErr
        ? Container(
            color: const Color.fromRGBO(0, 0, 0, 0.24),
            child: Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    '视频播放错误,请检查网络后重试',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: ScreenUtil().setSp(16),
                    ),
                  ),
                  GestureDetector(
                    onTap: () {
                      initVideo();
                    },
                    child: Container(
                      margin: EdgeInsets.only(
                        top: ScreenUtil().setWidth(22.0),
                      ),
                      height: 44.w,
                      width: 120,
                      child: Center(
                        child: SizedBox(
                          width: ScreenUtil().setWidth(120),
                          height: ScreenUtil().setWidth(44),
                          child: Stack(
                            children: [
                              Image.asset(
                                "assets/images/button/btn_pink_base.png",
                                width: ScreenUtil().setWidth(120),
                                height: ScreenUtil().setWidth(44),
                              ),
                              Positioned.fill(
                                child: Padding(
                                  padding: EdgeInsets.only(
                                      top: ScreenUtil().setWidth(9)),
                                  child: Text(
                                    "重新加载",
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                        color: const Color(0xffffffff),
                                        fontWeight: FontWeight.w500,
                                        fontStyle: FontStyle.normal,
                                        fontSize: ScreenUtil().setSp(16)),
                                  ),
                                ),
                              )
                            ],
                          ),
                        ),
                      ),
                    ),
                  )
                ],
              ),
            ),
          )
        : GestureDetector(
            behavior: HitTestBehavior.translucent,
            onPanStart: (DragStartDetails e) {
              if (isLock ||
                  widget.isPreview ||
                  !widget.videoController.value.isInitialized) return;
              Method.debugPrint('panStart:${e.localPosition.dx}');
              usecheck = true;
              showControl = false;
              showUpTime = true;
              setState(() {});
              changeStartIsPlay = widget.videoController.value.isPlaying;
              widget.videoController.pause();
              panStart = e.localPosition.dx;
            },
            onPanUpdate: (DragUpdateDetails e) {
              if (isLock ||
                  widget.isPreview ||
                  !widget.videoController.value.isInitialized) return;
              upValue = videoValue + (e.localPosition.dx - panStart) * 10;
              if (upValue > videoMaxTime) return;
              if (upValue > 0 && upValue < videoMaxTime) {
                videoValue = upValue;
              }
              widget.videoController
                  .seekTo(Duration(milliseconds: videoValue.toInt()))
                  .then((value) {
                usecheck = false;
              });
            },
            onPanEnd: (DragEndDetails e) {
              if (isLock ||
                  widget.isPreview ||
                  !widget.videoController.value.isInitialized) return;
              Method.debugPrint('panEnd:结束');
              if (changeStartIsPlay) {
                widget.videoController.play();
                videoPageIsActive = true;
              }
              upValue = 0;
              showUpTime = false;
              setState(() {});
            },
            onTap: () {
              hideControl();
            },
            child: controlShow());
  }
}

class GradientSliderTrackShape extends SliderTrackShape
    with BaseSliderTrackShape {
  LinearGradient? linearGradient;
  double trackWidth;

  GradientSliderTrackShape(
      {this.linearGradient, this.trackWidth = double.infinity}) {
    linearGradient ??
        const LinearGradient(colors: [Color(0xffff36da), Color(0xffa653ff)]);
  }

  @override
  void paint(
    PaintingContext context,
    Offset offset, {
    required RenderBox parentBox,
    required SliderThemeData sliderTheme,
    required Animation<double> enableAnimation,
    required TextDirection textDirection,
    required Offset thumbCenter,
    bool isDiscrete = false,
    bool isEnabled = false,
    double trackWidth = double.infinity,
    double additionalActiveTrackHeight = 2,
  }) {
    assert(sliderTheme.disabledActiveTrackColor != null);
    assert(sliderTheme.disabledInactiveTrackColor != null);
    assert(sliderTheme.activeTrackColor != null);
    assert(sliderTheme.inactiveTrackColor != null);
    assert(sliderTheme.thumbShape != null);

    if (sliderTheme.trackHeight! <= 0) {
      return;
    }

    final Rect trackRect = getPreferredRect(
      parentBox: parentBox,
      offset: offset,
      sliderTheme: sliderTheme,
      isEnabled: isEnabled,
      isDiscrete: isDiscrete,
    );
    final activeGradientRect = Rect.fromLTRB(
      trackRect.left,
      (textDirection == TextDirection.ltr)
          ? trackRect.top - (additionalActiveTrackHeight / 2)
          : trackRect.top,
      thumbCenter.dx,
      (textDirection == TextDirection.ltr)
          ? trackRect.bottom + (additionalActiveTrackHeight / 2)
          : trackRect.bottom,
    );

    final ColorTween activeTrackColorTween = ColorTween(
        begin: sliderTheme.disabledActiveTrackColor,
        end: sliderTheme.activeTrackColor);
    final ColorTween inactiveTrackColorTween = ColorTween(
        begin: sliderTheme.disabledInactiveTrackColor,
        end: sliderTheme.inactiveTrackColor);
    final Paint activePaint = Paint()
      ..shader = linearGradient!.createShader(activeGradientRect)
      ..color = activeTrackColorTween.evaluate(enableAnimation)!;
    final Paint inactivePaint = Paint()
      ..color = inactiveTrackColorTween.evaluate(enableAnimation)!;
    final Paint leftTrackPaint;
    final Paint rightTrackPaint;
    switch (textDirection) {
      case TextDirection.ltr:
        leftTrackPaint = activePaint;
        rightTrackPaint = inactivePaint;
        break;
      case TextDirection.rtl:
        leftTrackPaint = inactivePaint;
        rightTrackPaint = activePaint;
        break;
    }

    final Rect leftTrackSegment = Rect.fromLTRB(
        trackRect.left, trackRect.top, thumbCenter.dx, trackRect.bottom);
    if (!leftTrackSegment.isEmpty) {
      context.canvas.drawRect(leftTrackSegment, leftTrackPaint);
    }
    final Rect rightTrackSegment = Rect.fromLTRB(
        thumbCenter.dx, trackRect.top, trackRect.right, trackRect.bottom);
    if (!rightTrackSegment.isEmpty) {
      context.canvas.drawRect(rightTrackSegment, rightTrackPaint);
    }
  }
}

class SliderThumbImage extends SliderComponentShape {
  final ui.Image image;

  SliderThumbImage(this.image);
  @override
  Size getPreferredSize(bool isEnabled, bool isDiscrete) {
    return const Size(0, 0);
  }

  @override
  void paint(PaintingContext context, Offset center,
      {required Animation<double> activationAnimation,
      required Animation<double> enableAnimation,
      required bool isDiscrete,
      required TextPainter labelPainter,
      required RenderBox parentBox,
      required SliderThemeData sliderTheme,
      required TextDirection textDirection,
      required double value,
      required double textScaleFactor,
      required Size sizeWithOverflow}) {
    var canvas = context.canvas;
    final picWidth = image.width;
    final picHeight = image.height;

    Offset picOffset = Offset(
      (center.dx - (picWidth / 2)),
      (center.dy - (picHeight / 2)),
    );

    Paint paint = Paint()..filterQuality = FilterQuality.medium;
    canvas.drawImage(image, picOffset, paint);
  }
}
