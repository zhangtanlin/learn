import 'dart:async';

import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:iaimei/pages/video/long_video_player.dart';
import 'package:iaimei/global.dart';
import 'package:iaimei/utils/common.dart';
import 'package:iaimei/utils/crypto.dart';
import 'package:iaimei/utils/shelf_proxy.dart';
import 'package:iaimei/widget/network_img_container.dart';
import 'package:video_player/video_player.dart';
import 'package:visibility_detector/visibility_detector.dart';
import 'package:universal_html/html.dart' as html;

class PreviewVideo extends StatefulWidget {
  const PreviewVideo({
    Key? key,
    this.thumbUrl,
    required this.previewUrl,
  }) : super(key: key);
  final dynamic thumbUrl;
  final String previewUrl;
  @override
  _PreviewVideoState createState() => _PreviewVideoState();
}

class _PreviewVideoState extends State<PreviewVideo> {
  late GlobalKey _key;
  bool volumeOn = false;
  late String videoUrl;
  late VideoPlayerController videoController;
  late Timer timefc;
  dynamic _url;
  @override
  void initState() {
    super.initState();
    AppGlobal.visibilityDetectorIndex++;
    _key = GlobalKey(
        debugLabel: 'visibility_detector_${AppGlobal.visibilityDetectorIndex}');
  }

  void _handleVisibilityChanged(VisibilityInfo info) {
    Method.getRealImage(
      url: widget.thumbUrl,
      imgUrl: _url,
      setUrl: (e) {
        if (!mounted) return;
        setState(() {
          _url = e;
        });
      },
    );
    if (_key.currentContext == null || _key != info.key) return;
    RenderBox renderBox = _key.currentContext?.findRenderObject() as RenderBox;
    Offset positions = renderBox.localToGlobal(Offset.zero);
    double shCenter = ScreenUtil().screenHeight / 2;
    double swCenter = ScreenUtil().screenWidth / 2;
    double boxH = info.size.height;
    double boxW = info.size.width;
    double boxT = positions.dy;
    double boxL = positions.dx;

    bool isVisibility() {
      bool isShow = false;
      if ((boxH + boxT) >= boxH &&
          boxT < shCenter &&
          (boxW + boxL) > swCenter &&
          boxL < swCenter) {
        isShow = true;
      }
      return isShow;
    }

    initVideo(url) {
      if (kIsWeb) {
        if (AppGlobal.m3u8Encrypt == '1') {
          Dio().get(url).then((res) {
            String decrypted = PlatformAwareCrypto.decryptM3U8(res.data);
            final _blob =
                html.Blob([decrypted], 'application/x-mpegURL', 'native');
            final _url = html.Url.createObjectUrl(_blob);
            Method.debugPrint(_url);
            createVideo(_url);
          });
        } else {
          createVideo(url);
        }
      } else {
        if (AppGlobal.m3u8Encrypt == '1') {
          createServer(url).then((proxyConfig) {
            String proxyurl = url.replaceAll(
                proxyConfig['origin'], proxyConfig['localproxy']);
            createVideo(proxyurl);
          });
        } else {
          createVideo(url);
        }
      }
    }

    if (isVisibility() && videoController == null) {
      initVideo(widget.previewUrl);
    } else if (!isVisibility()) {
      videoController = 'null' as VideoPlayerController;
      setState(() {});
    }
  }

  createVideo(url) {
    videoController = VideoPlayerController.network(url)
      ..initialize().then((_) {
        videoController.setLooping(true);
        videoController.setVolume(0);
        videoController.play();
      }).whenComplete(() {
        if (!mounted) return;
        setState(() {});
      });
  }

  @override
  Widget build(BuildContext context) {
    return VisibilityDetector(
      key: _key,
      onVisibilityChanged: _handleVisibilityChanged,
      child: Stack(
        children: [
          SizedBox(
            width: double.infinity,
            height: double.infinity,
            child: videoController.value.isInitialized
                ? LongVideoPlayer(
                    controller: videoController,
                    setController: (VideoPlayerController controller) {},
                    setVideoUrl: () {},
                    // videoUrl: '',
                  )
                : NetworkImgContainer(
                    url: _url,
                  ),
          ),
          videoController != null
              ? const SizedBox()
              : Positioned(
                  top: 0,
                  right: 0,
                  bottom: 0,
                  left: 0,
                  child: Center(
                    child: Image.asset(
                      'assets/pengke/video/play-icon.png',
                      width: ScreenUtil().setWidth(40),
                      height: ScreenUtil().setWidth(40),
                    ),
                  ),
                )
        ],
      ),
    );
  }
}
