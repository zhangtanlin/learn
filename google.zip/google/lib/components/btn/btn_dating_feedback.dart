import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:iaimei/model/model_helper.dart';
import 'package:iaimei/components/common/glassmorphism.dart';
import 'package:iaimei/theme/default.dart';

/// 投诉原因按钮
class BtnDartingFeedback extends StatelessWidget {
  final ListElement item;
  final bool active;
  final Function()? onTap;
  const BtnDartingFeedback({
    Key? key,
    required this.item,
    this.active = false,
    this.onTap,
  }) : super(key: key);

  Widget setBtn() {
    if (active) {
      return RedGlassmorphoismBox(
        child: Container(
          padding: EdgeInsets.symmetric(
            vertical: ScreenUtil().setWidth(6.0),
            horizontal: ScreenUtil().setWidth(20.0),
          ),
          child: Text(
            item.text.toString(),
            style: DefaultStyle.white12,
          ),
        ),
      );
    }
    return GlassmorphoismTags(
      child: Text(
        item.text.toString(),
        style: DefaultStyle.white12,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        if (onTap != null) {
          onTap!();
        }
      },
      child: setBtn(),
    );
  }
}
