import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:iaimei/theme/default.dart';

/// 性别切换单选框
class RadioSexBox extends StatelessWidget {
  final int value;
  final List list;
  final Function onTap;
  const RadioSexBox({
    Key? key,
    required this.value,
    required this.list,
    required this.onTap,
  }) : super(key: key);

  Widget setItem() {
    List<Widget> tempList = [];
    for (var i = 0; i < list.length; i++) {
      TextStyle textStyle =
          TextStyle(color: const Color(0xd6ffffff), fontSize: 13.sp);
      if (list[i]["value"] == value) {
        textStyle = TextStyle(color: const Color(0xffff00b3), fontSize: 13.sp);
      }
      tempList.add(
        GestureDetector(
          onTap: () {
            onTap(list[i]["value"]);
          },
          child: Padding(
            padding: EdgeInsets.symmetric(
              vertical: ScreenUtil().setWidth(5.0),
              horizontal: ScreenUtil().setWidth(10.0),
            ),
            child: Text(
              list[i]["label"].toString(),
              style: textStyle,
            ),
          ),
        ),
      );
    }
    return Row(children: tempList);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: const Color.fromRGBO(0, 0, 0, .25),
        borderRadius: BorderRadius.all(
          Radius.circular(
            ScreenUtil().setWidth(15.0),
          ),
        ),
      ),
      child: setItem(),
    );
  }
}
