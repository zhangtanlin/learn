import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:iaimei/components/calendar/utils/zn_extension.dart';

import 'utils/calendar_widget.dart';
import 'utils/models.dart';
import 'utils/service.dart';

class Calendar extends StatefulWidget {
  final bool disable;
  final ValueChanged<Date?>? onSelected;
  final DateTime? selectedDate;

  const Calendar({
    Key? key,
    this.onSelected,
    this.disable = false,
    this.selectedDate,
  }) : super(key: key);

  @override
  _CalendarState createState() => _CalendarState();
}

class _CalendarState extends State<Calendar>
    with SingleTickerProviderStateMixin {
  late CalendarPageController controller;
  PageController? pageController;

  @override
  void initState() {
    pageController = PageController(initialPage: 1);
    controller = CalendarPageController(
      pageController,
      widget.selectedDate,
    );

    super.initState();
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        image: DecorationImage(
          image: AssetImage("assets/images/common/app_bg.png"),
          fit: BoxFit.cover,
          alignment: Alignment.topCenter,
        ),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          _buildHeaderWidget(),
          // display week
          _buildWeeklyWidget(),
          SizedBox(height: 10.w),
          Container(
            height: 288.w,
            margin: EdgeInsets.symmetric(horizontal: 16.w),
            child: StreamBuilder<PageDirection>(
              stream: controller.update.stream,
              builder: (context, snapshot) => PageView(
                controller: pageController,
                onPageChanged: controller.onChage,
                children: [
                  CalendarWidget(
                    key: Key(controller.dataCollection.previousMonth!.key),
                    date: controller.dataCollection.previousMonth,
                    selectedDate: widget.selectedDate,
                    onSelected:
                        widget.disable == true ? null : widget.onSelected,
                  ),
                  CalendarWidget(
                    key: Key(controller.dataCollection.currentMonth!.key),
                    date: controller.dataCollection.currentMonth,
                    selectedDate: widget.selectedDate,
                    onSelected:
                        widget.disable == true ? null : widget.onSelected,
                  ),
                  CalendarWidget(
                    key: Key(controller.dataCollection.nextMonth!.key),
                    date: controller.dataCollection.nextMonth,
                    selectedDate: widget.selectedDate,
                    onSelected:
                        widget.disable == true ? null : widget.onSelected,
                  ),
                ],
              ),
            ),
          ),
          SizedBox(height: 10.w),
          _buildBottomWidget(),
        ],
      ),
    );
  }

  Widget _buildBottomWidget() {
    return Container(
      height: 44.w,
      alignment: Alignment.center,
      child: GestureDetector(
        behavior: HitTestBehavior.translucent,
        child: Image.asset("assets/images/common/action_hide_calendar.png",
            width: 36.w, height: 36.w),
        onTap: () => widget.onSelected!(null),
      ),
    );
  }

  Widget _buildWeeklyWidget() {
    return Container(
      height: 32.w, // 32 + 12
      alignment: Alignment.center,
      margin: EdgeInsets.symmetric(horizontal: 16.w, vertical: 6.w),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16.w),
        color: const Color.fromRGBO(0, 0, 0, 0.2),
      ),
      child: Table(children: [
        TableRow(
          children: List.generate(7, (index) {
            return Center(
              child: Text(
                index.week,
                style: TextStyle(color: Colors.white, fontSize: 14.sp),
              ),
            );
          }),
        ),
      ]),
    );
  }

  Widget _buildHeaderWidget() {
    return Container(
      height: 44.w,
      margin: EdgeInsets.fromLTRB(16.w, 20.w, 16.w, 0),
      child: Row(
        mainAxisSize: MainAxisSize.max,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          GestureDetector(
            behavior: HitTestBehavior.translucent,
            child: Image.asset("assets/images/common/action_prev.png",
                width: 36.w, height: 36.w),
            onTap: () => pageController!.previousPage(
                duration: const Duration(milliseconds: 200),
                curve: Curves.linear),
          ),
          StreamBuilder(
              stream: controller.update,
              initialData: PageDirection.none,
              builder: (context, snapshot) {
                return Text(
                  "${controller.dataCollection.currentMonth!.year}年   ${controller.dataCollection.currentMonth!.month!.month}",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 16.sp,
                    fontWeight: FontWeight.w500,
                  ),
                );
              }),
          GestureDetector(
            behavior: HitTestBehavior.translucent,
            child: Image.asset("assets/images/common/action_next.png",
                width: 36.w, height: 36.w),
            onTap: () => pageController!.nextPage(
                duration: const Duration(milliseconds: 200),
                curve: Curves.linear),
          ),
        ],
      ),
    );
  }
}
