extension WeekDay on int {
  String get week {
    switch (this) {
      case 0:
        return "日";
      case 1:
        return "一";
      case 2:
        return "二";
      case 3:
        return "三";
      case 4:
        return "四";
      case 5:
        return "五";
      case 6:
        return "六";
      default:
        throw "无效";
    }
  }
}

extension Month on int {
  String get month {
    switch (this) {
      case 1:
        return "1月";
      case 2:
        return "2月";
      case 3:
        return "3月";
      case 4:
        return "4月";
      case 5:
        return "5月";
      case 6:
        return "6月";
      case 7:
        return "7月";
      case 8:
        return "8月";
      case 9:
        return "9月";
      case 10:
        return "10月";
      case 11:
        return "11月";
      case 12:
        return "12月";
      default:
        throw "无效";
    }
  }
}
