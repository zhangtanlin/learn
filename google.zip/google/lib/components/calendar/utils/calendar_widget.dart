import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'models.dart';
import 'service.dart';

class CalendarWidget extends StatefulWidget {
  final Date? date;
  final Color? activeColor;
  final DateTime? selectedDate;
  final ValueChanged<Date>? onSelected;
  const CalendarWidget({
    Key? key,
    this.activeColor,
    this.onSelected,
    this.selectedDate,
    required this.date,
  }) : super(key: key);

  @override
  _CalendarWidgetState createState() => _CalendarWidgetState();
}

class _CalendarWidgetState extends State<CalendarWidget> {
  late Controller _controller;
  Day? daySelected;
  @override
  void initState() {
    final dateNow = DateTime.now();
    if (dateNow.month == widget.date!.month &&
        dateNow.year == widget.date!.year &&
        widget.selectedDate?.day == dateNow.day) {
      daySelected = Day(
          value: dateNow.day,
          weekDay: dateNow.weekday,
          date: Date(
            day: dateNow.day,
            month: widget.date!.month,
            year: widget.date!.year,
          ));
    } else {
      if (widget.selectedDate?.day != null) {
        daySelected = Day(
            value: widget.selectedDate?.day,
            weekDay: widget.selectedDate?.weekday,
            date: Date(
              day: widget.selectedDate?.day,
              month: widget.selectedDate?.month,
              year: widget.selectedDate?.year,
            ));
      }
    }
    _controller =
        Controller(month: widget.date!.month, year: widget.date!.year);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    debugPrint(_controller.list.toString());
    return Table(
      defaultColumnWidth: FixedColumnWidth(43.w),
      children: _controller.list.map((week) {
        return TableRow(
          children: week.map((day) {
            var nextDay = DateTime(
                int.parse(widget.date!.year.toString()),
                int.parse(widget.date!.month.toString()),
                int.parse(day.value.toString()));
            var isAfter = nextDay.isAfter(DateTime.now());
            var isSelected = daySelected?.date?.year == day.date?.year &&
                daySelected?.date?.month == day.date?.month &&
                daySelected?.date?.day == day.date?.day;
            return GestureDetector(
              onTap: () {
                if (widget.onSelected != null) {
                  widget.onSelected!(Date(
                    year: widget.date!.year,
                    month: widget.date!.month,
                    day: day.value,
                  ));
                  daySelected = day == daySelected ? null : day;
                  setState(() {});
                }
              },
              child: Container(
                height: 43.w,
                alignment: Alignment.center,
                margin: EdgeInsets.only(left: 3.w, right: 3.w, bottom: 6.w),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12.w),
                  border: Border.all(
                      color: isSelected
                          ? const Color(0x33ffffff)
                          : Colors.transparent,
                      width: 0.5),
                  gradient: LinearGradient(
                      begin: const Alignment(0.5, 0.5),
                      end: const Alignment(0.5, -1),
                      stops: const [0, 1],
                      colors: isSelected
                          ? [const Color(0xf4ff00b3), const Color(0x66ff00b3)]
                          : [Colors.transparent, Colors.transparent]),
                ),
                child: Text(day.label,
                    style: TextStyle(
                        color: isAfter
                            ? Colors.white.withOpacity(0.64)
                            : Colors.white,
                        fontSize: 15.sp)),
              ),
            );
          }).toList(),
        );
      }).toList(),
    );
  }
}