class Day {
  final int? value;
  final int? weekDay;
  final Date? date;

  @override
  String toString() => value == 0 ? "" : "$value";

  String get label => value == 0 ? "" : "$value";

  bool get isWeekend => weekDay == 0 || weekDay == 6;

  Day({this.date, this.value, this.weekDay});

  @override
  int get hashCode => date.hashCode;

  @override
  operator ==(other) => other.hashCode == hashCode;
}

class Date {
  final int? year;
  final int? month;
  final int? day;

  Date({
    this.year,
    this.month,
    this.day,
  });

  String get key => "$month/$year";

  @override
  int get hashCode => month! * year! * day! * 2;

  @override
  operator ==(other) => other.hashCode == hashCode;

  @override
  String toString() => "$year-${month!}-$day";

  factory Date.addMonth(Date current) {
    if (current.month! + 1 == 13) {
      final year = current.year! + 1;
      const month = 1;
      return Date(month: month, year: year);
    } else {
      final month = current.month! + 1;
      return Date(month: month, year: current.year);
    }
  }

  factory Date.removeMonth(Date current) {
    if (current.month! - 1 == 0) {
      final year = current.year! - 1;
      const month = 12;
      return Date(month: month, year: year);
    } else {
      final month = current.month! - 1;
      return Date(month: month, year: current.year);
    }
  }
}
