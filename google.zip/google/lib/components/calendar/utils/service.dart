import 'dart:async';
import 'package:flutter/material.dart';
import 'package:iaimei/components/calendar/utils/zn_extension.dart';
import 'package:rxdart/subjects.dart';

import 'intl_date.dart';
import 'models.dart';

enum PageDirection { previous, next, none }

class DataCollection {
  Date? currentMonth;
  Date? previousMonth;
  Date? nextMonth;

  DataCollection({this.currentMonth, this.previousMonth, this.nextMonth});

  factory DataCollection.next(Date old) {
    final current = Date.addMonth(old);
    return DataCollection.mount(current);
  }

  factory DataCollection.previous(Date old) {
    final current = Date.removeMonth(old);
    return DataCollection.mount(current);
  }

  factory DataCollection.mount(Date current) {
    return DataCollection(
        previousMonth: Date.removeMonth(current),
        currentMonth: current,
        nextMonth: Date.addMonth(current));
  }

  factory DataCollection.init({DateTime? initialDate}) {
    final now = initialDate ?? DateTime.now();
    final current = Date(day: now.day, month: now.month, year: now.year);
    return DataCollection(
        previousMonth: Date.removeMonth(current),
        currentMonth: current,
        nextMonth: Date.addMonth(current));
  }
}

class CalendarPageController {
  final currentPage = BehaviorSubject<int>();
  final update = BehaviorSubject<PageDirection>();
  var month;
  var year;
  late DataCollection dataCollection;
  late StreamSubscription subscription;

  CalendarPageController(
    PageController? pageController,
    DateTime? initialDate,
  ) {
    dataCollection = DataCollection.init(initialDate: initialDate);

    update.sink.add(PageDirection.none);

    subscription = currentPage.stream.listen((event) {
      if (event == 0) {
        dataCollection = DataCollection.previous(dataCollection.currentMonth!);
        Future.delayed(const Duration(milliseconds: 50)).then((value) {
          update.sink.add(PageDirection.previous);
          pageController!.jumpToPage(1);
        });
      } else if (event == 2) {
        dataCollection = DataCollection.next(dataCollection.currentMonth!);
        Future.delayed(const Duration(milliseconds: 50)).then((value) {
          update.sink.add(PageDirection.next);
          pageController!.jumpToPage(1);
        });
      }
    });
    month = update.stream
        .asyncMap<String>((event) => dataCollection.currentMonth!.month!.month);
  }

  void onChage(int value) => currentPage.sink.add(value);

  void dispose() {
    subscription.cancel();
    update.close();
    currentPage.close();
  }
}

class Service {
  int? maxDaysInMonth({required int month, required int year}) =>
      DateUtil().daysInMonth(month, year);

  int weekDayByDate(DateTime date) => date.weekday == 7 ? 0 : date.weekday;

  List<List<Day>> getDaysInMonth({required int month, required int year}) {
    final date = DateTime(year, month);

    var weekDay = weekDayByDate(date);

    var monthDays = maxDaysInMonth(month: month, year: year)!;

    var listDays = List.generate(monthDays, (index) => index + 1);

    //Generate spaces start month
    if (weekDay > 0) {
      var listSpace = List.generate(weekDay, (index) => 0);
      listDays = List.from(listSpace + listDays);
    }

    //Generate spaces and month

    final weeks = (listDays.length ~/ 7).toInt();
    final listNumberScape = 7 - (listDays.length - weeks * 7);
    final listSpace = List.generate(listNumberScape, (index) => 0);

    listDays = List.from(listDays + listSpace);

    final listWeeks = <List<Day>>[];
    var listDaysOfWeek = <Day>[];
    var weekDayCount = 0;

    for (var item in listDays) {
      listDaysOfWeek.add(Day(
          value: item,
          weekDay: weekDayCount,
          date: Date(day: item, month: month, year: year)));
      weekDayCount++;
      if (listDaysOfWeek.length == 7) {
        listWeeks.add(List.from(listDaysOfWeek));
        listDaysOfWeek.clear();

        weekDayCount = 0;
      }
    }
    return listWeeks;
  }
}

class Controller {
  final _service = Service();
  final int? month;
  final int? year;

  late List<List<Day>> list;

  Controller({this.month, this.year}) {
    generate();
  }

  void generate() {
    list = _service.getDaysInMonth(month: month!, year: year!);
  }
}
