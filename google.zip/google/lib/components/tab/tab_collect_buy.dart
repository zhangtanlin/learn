import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:iaimei/components/common/pagestatus.dart';
import 'package:iaimei/components/common/pageviewmixin.dart';
import 'package:iaimei/components/list/list_cartoon.dart';
import 'package:iaimei/components/list/list_gather.dart';
import 'package:iaimei/components/list/list_novel.dart';
import 'package:iaimei/components/list/list_mv.dart';
import 'package:iaimei/components/list/list_chat.dart';
import 'package:iaimei/components/list/list_pictures.dart';
import 'package:iaimei/pages/dating/dating_collect_buy_list.dart';
import 'package:iaimei/pages/mv/nav_tab_bar_mixin.dart';
import 'package:iaimei/widget/tab_bar_view_ext.dart';

/// 收藏购买二级选项卡
/// [type]类型{0/null: 收藏,1: 购买,}
class TabCollectBuy extends StatefulWidget {
  final int? type;
  final List tabs;
  const TabCollectBuy({
    Key? key,
    this.type = 0,
    required this.tabs,
  }) : super(key: key);

  @override
  State<TabCollectBuy> createState() => _TabCollectBuyState();
}

class _TabCollectBuyState extends State<TabCollectBuy>
    with TickerProviderStateMixin {
  // 加载中
  bool _loading = true;
  // 列表
  List _tabs = [];
  // 选项卡控制器
  int selectIndex = 0;
  late TabController _tabController;

  /// 请求初始化
  void _initData() {
    if (widget.tabs.isNotEmpty) {
      _tabs = widget.tabs;
      _tabController = TabController(
        initialIndex: selectIndex,
        length: widget.tabs.length,
        vsync: this,
      );
      // _tabController.addListener(() {
      //   setState(() => selectIndex = _tabController.index);
      // });
      _loading = false;
      setState(() {});
    }
  }

  @override
  void initState() {
    super.initState();
    _initData();
  }

  @override
  Widget build(BuildContext context) {
    return _init();
  }

  /// 初始化构建
  Widget _init() {
    if (_loading) {
      return PageStatus.loading(_loading);
    }
    return Flex(
      direction: Axis.vertical,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildTabBarWidget(),
        Container(
          color: const Color.fromRGBO(255, 255, 255, 0.2),
          height: 1.w,
          margin: EdgeInsets.symmetric(horizontal: 16.w),
        ),
        Expanded(
          flex: 1,
          child: _buildTabbarViewWidget(),
        ),
      ],
    );
  }

  /// 选项卡头部
  Widget _buildTabBarWidget() {
    return NavTabBarWidget(
      tabVc: _tabController,
      tabs: _tabs.map<String>((item) => item['name']).toList(),
      textPadding: EdgeInsets.symmetric(horizontal: 15.w),
      norTextStyle: TextStyle(
          color: Colors.white, fontSize: 14.sp, fontWeight: FontWeight.w400),
      selTextStyle: TextStyle(
          color: const Color(0xffff00b3),
          fontSize: 14.sp,
          fontWeight: FontWeight.w600),
      selectedIndex: selectIndex,
      // onTapCallback: (index) => setState(() => selectIndex = index),
    );
  }

  /// 选项卡内容
  Widget _buildTabbarViewWidget() {
    return TabBarViewExt(
      controller: _tabController,
      children: [
        for (var i = 0; i < _tabs.length; i++) ...[
          _setListByType(_tabs[i]["id"]),
        ]
      ],
    );
  }

  /// 根据选项卡不同设置不同的列表
  /// [type]类型{0: 视频,1: 漫画,2:小说,3:裸聊,4:约炮,5:图集,}
  Widget _setListByType(int type) {
    Widget tempList;
    switch (type) {
      case 1:
        tempList = ListMv(type: widget.type);
        break;
      case 2:
        tempList = ListCartoon(type: widget.type);
        break;
      case 3:
        tempList = ListNovelCollectBuy(type: widget.type);
        break;
      case 4:
        tempList = ListChatCollectBuy(type: widget.type);
        break;
      case 5:
        tempList = ListDatingCollectBuy(type: widget.type);
        break;
      case 6:
        tempList = ListPicturesCollectBuy(type: widget.type);
        break;
      case 7:
        tempList = ListGather(type: widget.type);
        break;
      default:
        tempList = const SizedBox();
    }
    return PageViewMixin(
      child: tempList,
    );
  }
}
