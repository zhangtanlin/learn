import 'package:iaimei/pages/comics/comics_read_setting_page.dart';

class ComicsReadConfigChangeEvent{

  final TypeReadWay? way;
  final int? time;

  ComicsReadConfigChangeEvent(this.way, this.time);

}