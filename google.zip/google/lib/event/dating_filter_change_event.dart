class DatingFilterChangeEvent {
  final Map<String, dynamic>? param;

  DatingFilterChangeEvent(this.param);
}
