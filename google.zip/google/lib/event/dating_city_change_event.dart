class DatingCityChangeEvent {}
