import 'package:flutter/material.dart';
import 'package:iaimei/utils/list_util.dart';
import 'package:iaimei/widget/text_widget.dart';

class TopTabNavConfig {
  TopTabNavConfig(
      {this.isScrollable = true,
      this.tabHeight = 44,
      this.tabBgColor = Colors.transparent,
      this.navMargin = EdgeInsets.zero,
      this.navTabMargin = EdgeInsets.zero,
      this.tabItemMargin = EdgeInsets.zero,
      this.tabItemTextPadding = EdgeInsets.zero,
      this.textColor = Colors.grey,
      this.selectedTextColor = Colors.black,
      this.textStyle,
      this.selectedTextStyle,
      this.indicatorSize = TabBarIndicatorSize.label,
      this.indicatorPadding = EdgeInsets.zero,
      this.indicatorDecoration = const BoxDecoration(),
      this.indicatorWidget = const SizedBox(),
      this.leftWidget = const SizedBox(),
      this.rightWidget = const SizedBox(),
      this.tabItemSelectDecoration = const BoxDecoration(),
      this.tabItemDecoration = const BoxDecoration(),
      this.tabItemWidth,
      this.tabItemHeight});

  final bool isScrollable;

  final Color tabBgColor;
  final double tabHeight;
  final EdgeInsets navMargin;
  final EdgeInsets navTabMargin;
  final EdgeInsets tabItemMargin;
  final EdgeInsets tabItemTextPadding;

  final Color textColor;
  final Color selectedTextColor;
  final TextStyle? textStyle;
  final TextStyle? selectedTextStyle;

  final EdgeInsets indicatorPadding;
  final Decoration indicatorDecoration;

  final Widget leftWidget;
  final Widget rightWidget;
  final Widget indicatorWidget;
  final TabBarIndicatorSize indicatorSize;
  final double? tabItemWidth;
  final double? tabItemHeight;
  final BoxDecoration? tabItemSelectDecoration;
  final BoxDecoration? tabItemDecoration;
}

class TopTabNavigator extends StatefulWidget {
  final List<String> tabItems;
  final List<Widget> pages;
  final TopTabNavConfig config;
  final int initIndex;
  final Widget divideWidget;

  const TopTabNavigator(
      {Key? key,
      required this.tabItems,
      required this.pages,
      required this.config,
      this.initIndex = 0,
      this.divideWidget = const SizedBox()})
      : super(key: key);

  @override
  _TopTabNavigatorState createState() => _TopTabNavigatorState();
}

class _TopTabNavigatorState extends State<TopTabNavigator>
    with SingleTickerProviderStateMixin {
  TabController? _tabController;
  List<String>? _tabItems;
  int selectedIndex = 0;

  @override
  void initState() {
    super.initState();
    _tabItems = widget.tabItems;
    _tabController = TabController(
      initialIndex: widget.initIndex,
      length: _tabItems!.length,
      vsync: this,
    );
    selectedIndex = widget.initIndex;
    if (_tabController != null) {
      _tabController!.addListener(() {
        selectedIndex = _tabController!.index;
        setState(() {});
      });
    }
  }

  @override
  void dispose() {
    if (_tabController != null) {
      _tabController?.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        _buildTabNavBarSection(),
        widget.divideWidget,
        Expanded(
            child: TabBarView(
          controller: _tabController,
          children: widget.pages,
        ))
      ],
    );
  }

  _buildTabNavBarSection() {
    return Container(
      height: widget.config.tabHeight,
      color: widget.config.tabBgColor,
      margin: widget.config.navMargin,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          widget.config.leftWidget,
          Expanded(
              child: ListUtil.isNotEmpty(_tabItems)
                  ? Container(
                      margin: widget.config.navTabMargin,
                      child: _buildTabBar(),
                    )
                  : const SizedBox()),
          widget.config.rightWidget,
        ],
      ),
    );
  }

  Widget _buildTabBar() {
    return Theme(
        data: ThemeData(
            splashColor: Colors.transparent,
            highlightColor: Colors.transparent),
        child: TabBar(
          controller: _tabController,
          isScrollable: widget.config.isScrollable,
          labelPadding: widget.config.tabItemMargin,
          indicatorPadding: widget.config.indicatorPadding,
          indicator: widget.config.indicatorDecoration,
          indicatorSize: widget.config.indicatorSize,
          unselectedLabelColor: widget.config.textColor,
          unselectedLabelStyle: widget.config.textStyle,
          labelColor: widget.config.selectedTextColor,
          labelStyle: widget.config.selectedTextStyle,
          tabs: _tabItems!.asMap().keys.map((index) {
            return _buildTabBarItem(index);
          }).toList(),
        ));
  }

  Widget _buildTabBarItem(int index) {
    return Container(
      alignment: Alignment.center,
      width: widget.config.tabItemWidth,
      height: widget.config.tabItemHeight,
      child: Stack(
        children: [
          Positioned.fill(
              left: 0,
              right: 0,
              top: 0,
              bottom: 0,
              child: selectedIndex == index
                  ? widget.config.indicatorWidget
                  : const SizedBox()),
          Container(
            padding: widget.config.tabItemTextPadding,
            alignment: Alignment.center,
            decoration: selectedIndex == index
                ? widget.config.tabItemSelectDecoration
                : widget.config.tabItemDecoration,
            child: TextWidget.buildSingleLineText(
              _tabItems![index],
              selectedIndex == index
                  ? widget.config.selectedTextStyle
                  : widget.config.textStyle,
            ),
          ),
        ],
      ),
    );
  }
}


