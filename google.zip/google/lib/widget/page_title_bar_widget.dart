import 'package:flutter/material.dart';

// ignore: must_be_immutable
class PageTitleBarWidget extends StatefulWidget implements PreferredSizeWidget {
  final Widget? rightWidget;
  final Color? bgColor;
  final Widget? leftWidget;
  final VoidCallback? leftCallback;
  final Widget? titleWidget;
  final bool isShowLine;
  final double? barHeight;

  const PageTitleBarWidget({
    Key? key,
    this.leftWidget,
    this.leftCallback,
    this.bgColor = Colors.transparent,
    this.rightWidget,
    this.titleWidget,
    this.isShowLine = false,
    this.barHeight = 44,
  }) : super(key: key);

  @override
  _PageTitleBarWidgetState createState() => _PageTitleBarWidgetState();

  @override
  Size get preferredSize => Size.fromHeight(barHeight ?? 44);
}

class _PageTitleBarWidgetState extends State<PageTitleBarWidget> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      // decoration: BoxDecoration(
      //     border: Border(
      //         bottom: BorderSide(
      //             width: 0.5,
      //             color: widget.isShowLine
      //                 ? const Color(0xfff5f5f5)
      //                 : Colors.transparent))),
      color: widget.bgColor,
      child: SafeArea(
        bottom: false,
        child: Stack(
          children: [
            SizedBox(
              height: widget.barHeight,
              child: widget.titleWidget,
            ),
            Positioned(
                left: 0,
                top: 0,
                bottom: 0,
                child: InkWell(
                  onTap: widget.leftCallback ??
                      () {
                        Navigator.pop(context);
                      },
                  child: widget.leftWidget ?? const SizedBox(),
                )),
            Positioned(
                right: 0,
                top: 0,
                bottom: 0,
                child: widget.rightWidget ?? const SizedBox())
          ],
        ),
      ),
    );
  }
}

// Container(
//   alignment: Alignment.center,
//   width: DimenRes.screenWidth,
//   color: Colors.transparent,
//   height:
//       widget.height > 0.0 ? widget.height : AppStyle.titleBarHeight,
//   child: StringUtil.isNotEmpty(widget?.title)
//       ? Text(
//           widget?.title,
//           style: widget.textStyle ?? AppTextStyle.c333333_s18,
//         )
//       : const SizedBox(),
// ),
// Positioned(
//     left: 0,
//     right: 0,
//     bottom: 0,
//     top: 0,
//     child: Row(
//       mainAxisAlignment: MainAxisAlignment.spaceBetween,
//       crossAxisAlignment: CrossAxisAlignment.center,
//       children: [
//         InkWell(
//           child: Padding(
//             padding: EdgeInsets.symmetric(
//                 horizontal: DimenRes.dimen_10,
//                 vertical: DimenRes.dimen_10),
//             child: ImgWidget.buildSimpleLocalImg(
//                 widget.backIcon ?? ImgRes.IC_BACK_BLACK,
//                 width: DimenRes.dimen_20,
//                 height: DimenRes.dimen_20),
//           ),
//           onTap: () {
//             context.pop();
//           },
//         ),
//         InkWell(
//           onTap: widget?.rightWidgetCallback,
//           child: Container(
//             alignment: Alignment.center,
//             height: widget.height > 0.0
//                 ? widget.height
//                 : AppStyle.titleBarHeight,
//             padding:
//                 EdgeInsets.symmetric(horizontal: DimenRes.dimen_15),
//             child: widget.rightWidget ?? Container(),
//           ),
//         )
//       ],
//     )),
// widget.isShowLine
//     ? Positioned(
//         child: Container(
//           width: DimenRes.screenWidth,
//           height: DimenRes.dimen_0_2,
//           color: ColorRes.color_ebebeb,
//         ),
//         bottom: 0,
//       )
//     : const SizedBox(),
