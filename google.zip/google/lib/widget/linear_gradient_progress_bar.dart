import 'package:flutter/material.dart';

class LinearGradientProgressBar extends StatelessWidget {
  final double? value;
  final Color? bgColor;
  final BorderRadius? borderRadius;
  final Decoration? decoration;

  const LinearGradientProgressBar(
      {Key? key,
      this.value = 0.5,
      this.bgColor = const Color(0x1f000000),
      this.borderRadius = const BorderRadius.all(Radius.circular(10)),
      this.decoration})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      //圆角大小
      borderRadius: borderRadius,
      child: SizedBox(
        width: double.infinity,
        height: double.infinity,
        //层叠到一起的进度
        child: buildProgressBarSection(),
      ),
    );
  }

  Stack buildProgressBarSection() {
    return Stack(
      children: [
        //背景
        Positioned.fill(
          child: Container(
            height: double.infinity,
            width: double.infinity,
            color: bgColor,
          ),
        ),
        //进度
        Padding(
          padding: const EdgeInsets.all(2.0),
          child: ClipRRect(
            //对齐
            borderRadius: borderRadius,
            child: Align(
              //裁剪比例
              widthFactor: value,
              child: Container(
                height: double.infinity,
                width: double.infinity,
                //背景装饰
                decoration: decoration ??
                     const BoxDecoration(
                      gradient: LinearGradient(colors: [
                        Color(0xffff4cca),
                        Color(0xff5c35ff),
                      ]),
                    ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}
