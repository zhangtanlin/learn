import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:iaimei/base/app_base_widget_state.dart';
import 'package:iaimei/res/color_res.dart';
import 'package:iaimei/widget/app_page_title_bar.dart';
import 'package:iaimei/widget/network_img_widget.dart';
import 'package:photo_view/photo_view.dart';
import 'package:photo_view/photo_view_gallery.dart';

typedef PageChanged = void Function(int index);

class ImagePreview extends StatefulWidget {
  final List imgItems; //图片列表
  final int defaultIndex; //默认第几张
  final PageChanged? pageChanged; //切换图片回调
  final Axis? direction; //图片查看方向
  final BoxDecoration? decoration; //背景设计

  const ImagePreview(
      {Key? key,
      required this.imgItems,
      this.defaultIndex = 0,
      this.pageChanged,
      this.direction,
      this.decoration})
      : assert(imgItems != null),
        super(key: key);

  @override
  _ImagePreviewState createState() => _ImagePreviewState();
}

class _ImagePreviewState extends AppBaseWidgetState<ImagePreview> {
  late int tempSelectItem;
  late PageController pageController;

  @override
  void initState() {
    super.initState();
    pageController = PageController(initialPage: widget.defaultIndex);
    tempSelectItem = widget.defaultIndex + 1;
  }

  @override
  void dispose() {
    if (pageController != null) {
      pageController.dispose();
    }
    super.dispose();
  }

  @override
  bool isShowSafeArea() {
    return false;
  }

  @override
  Widget buildPageLayout() {
    return Stack(
      children: [
        PhotoViewGallery.builder(
          scrollPhysics: const BouncingScrollPhysics(),
          itemCount: widget.imgItems.length,
          scrollDirection: widget.direction ?? Axis.horizontal,
          backgroundDecoration: widget.decoration ??
              const BoxDecoration(color: Colors.transparent),
          pageController: pageController,
          builder: (context, index) {
            return PhotoViewGalleryPageOptions.customChild(
                maxScale: PhotoViewComputedScale.contained * 2,
                minScale: PhotoViewComputedScale.contained * 1,
                child: NetworkImgWidget(
                  url: widget.imgItems[index],
                  background: Colors.transparent,
                  fit: BoxFit.contain,
                ));
          },
          loadingBuilder: (context, event) => const Center(
            child: SpinKitFadingCircle(
              color: ColorRes.color_ff00b3,
              size: 20.0,
            ),
          ),
          onPageChanged: (index) {
            setState(() {
              tempSelectItem = index + 1;
              if (widget.pageChanged != null) {
                widget.pageChanged!(index);
              }
            });
          },
        ),
        Positioned(
          left: 20,
          bottom: 30,
          right: 20,
          child: Text(
            '$tempSelectItem/${widget.imgItems.length}',
            style: const TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.normal),
            textAlign: TextAlign.center,
          ),
        ),
        AppPageTitleBar.getNormalAppBar()
      ],
    );
  }
}
