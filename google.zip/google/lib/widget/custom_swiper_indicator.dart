import 'package:card_swiper/card_swiper.dart';
import 'package:flutter/material.dart';
import 'package:iaimei/res/color_res.dart';
import 'package:iaimei/res/dimen_res.dart';

class CustomSwiperIndicator extends StatelessWidget {
  final SwiperPluginConfig? config;
  final List<dynamic>? list;

  const CustomSwiperIndicator({Key? key, this.config, this.list})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return _buildIndicatorRow(config!, list!);
  }

  Row _buildIndicatorRow(SwiperPluginConfig config, List adList) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      crossAxisAlignment: CrossAxisAlignment.end,
      children: adList.asMap().keys.map<Widget>((index) {
        return AnimatedContainer(
          duration: const Duration(milliseconds: 250),
          width: DimenRes.convert(config.activeIndex == index ? 20 : 5),
          height: DimenRes.convert(5),
          margin: EdgeInsets.only(right: DimenRes.convert(5)),
          decoration: BoxDecoration(
              color: config.activeIndex == index
                  ? ColorRes.color_ff00b3
                  : Colors.white,
              borderRadius: BorderRadius.circular(DimenRes.convert(5))),
        );
      }).toList(),
    );
  }



}
