import 'package:flutter/material.dart';
import 'package:iaimei/res/dimen_res.dart';

class SpaceWidget extends StatelessWidget {

  final double hSpace;

  final double vSpace;

  const SpaceWidget({Key? key, this.hSpace = 0, this.vSpace = 0})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: DimenRes.convert(hSpace),
      height: DimenRes.convert(vSpace),
    );
  }
}
