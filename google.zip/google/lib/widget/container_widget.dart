import 'package:flutter/material.dart';

class ContainerWidget {
  static Container build(
      {EdgeInsetsGeometry? padding,
      EdgeInsetsGeometry? margin,
      double? width,
      double? height,
      Color? bgColor,
      Decoration? decoration,
      AlignmentGeometry? alignment,
      BoxConstraints? constraints,
      Widget? child}) {
    return Container(
      width: width,
      height: height,
      color: bgColor,
      alignment: alignment,
      decoration: decoration,
      constraints: constraints,
      padding: padding,
      margin: margin,
      child: child,
    );
  }
}
