import 'package:flutter/material.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/widget/frosted_glass_box.dart';

class AppTagWidget extends StatelessWidget {
  final Widget? child;
  final VoidCallback? onTap;

  const AppTagWidget({Key? key, this.child, this.onTap}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: FrostedGlassSimpleBox(
        borderRadius: BorderRadius.circular(20),
        padding: EdgeInsets.symmetric(
            horizontal: DimenRes.dimen_20, vertical: DimenRes.dimen_6),
        child: child ?? const SizedBox(),
      ),
    );
  }
}
