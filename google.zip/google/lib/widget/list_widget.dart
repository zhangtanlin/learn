import 'package:flutter/material.dart';
import 'package:iaimei/res/dimen_res.dart';

class ListWidget {
  static buildVerticalListView(
      {required int itemCount,
      required IndexedWidgetBuilder itemBuilder,
      EdgeInsets pagePadding = EdgeInsets.zero,
      bool shrinkWrap = true,
      ScrollController? scrollController,
      ScrollPhysics physics = const BouncingScrollPhysics()}) {
    return ListView.builder(
      padding: pagePadding,
      itemCount: itemCount,
      shrinkWrap: shrinkWrap,
      controller: scrollController ?? ScrollController(),
      scrollDirection: Axis.vertical,
      physics: physics,
      cacheExtent: DimenRes.screenHeight * 5,
      itemBuilder: itemBuilder,
    );
  }

  static buildHorizontalListView(
      {required int itemCount,
      required IndexedWidgetBuilder itemBuilder,
      EdgeInsets pagePadding = EdgeInsets.zero,
      bool shrinkWrap = true,
      ScrollPhysics physics = const BouncingScrollPhysics()}) {
    return ListView.builder(
      padding: pagePadding,
      itemCount: itemCount,
      shrinkWrap: shrinkWrap,
      scrollDirection: Axis.horizontal,
      physics: physics,
      cacheExtent: DimenRes.screenWidth * 5,
      itemBuilder: itemBuilder,
    );
  }

  static buildGridView(
      {required int itemCount,
      required IndexedWidgetBuilder itemBuilder,
      double childRatio = 1,
      int crossCount = 2,
      double mainSpace = 0,
      double crossSpace = 0,
      EdgeInsets padding = EdgeInsets.zero,
      ScrollController? controller,
      bool shrinkWrap = true,
      ScrollPhysics physics = const BouncingScrollPhysics()}) {
    return GridView.builder(
        padding: padding,
        itemCount: itemCount,
        shrinkWrap: shrinkWrap,
        physics: physics,
        controller: controller ?? ScrollController(),
        cacheExtent: DimenRes.screenHeight * 5,
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            mainAxisSpacing: mainSpace,
            crossAxisSpacing: crossSpace,
            childAspectRatio: childRatio,
            crossAxisCount: crossCount),
        itemBuilder: itemBuilder);
  }
}
