import 'package:flutter/material.dart';
import 'package:iaimei/style/app_text_style.dart';
import 'package:iaimei/widget/app_img_widget.dart';
import 'package:iaimei/widget/text_widget.dart';

class AppTextWithImgBgWidget extends StatelessWidget {
  final String? text;
  final TextStyle? textStyle;
  final String? bgImgPath;
  final double? bgImgWidth;
  final double? bgImgHeight;
  final double left;
  final double right;
  final double top;
  final double bottom;
  final AlignmentGeometry alignment;
  final Function? onTap;

  const AppTextWithImgBgWidget(
      {Key? key,
      this.text,
      this.textStyle,
      this.bgImgPath,
      this.bgImgWidth,
      this.bgImgHeight,
      this.left = 15,
      this.right = 15,
      this.top = 8,
      this.bottom = 8,
      this.alignment = Alignment.center,
      this.onTap})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        if (onTap != null) onTap!.call();
      },
      child:
      Container(
          alignment: alignment,
          child: Stack(
            children: [
              AppImgWidget(
                path: bgImgPath ?? '',
                height: bgImgHeight,
                width: bgImgWidth,
              ),
              Positioned.fill(
                  left: left,
                  right: right,
                  top: top,
                  bottom: bottom,
                  child: Container(
                    alignment: Alignment.center,
                    child: TextWidget.buildSingleLineText(
                        text ?? '', textStyle ?? AppTextStyle.white_s14),
                  )),
            ],
          )),
    );
  }
}
