import 'package:flutter/material.dart';
import 'package:iaimei/utils/list_util.dart';
import 'package:iaimei/widget/nested_scroll_view_ext.dart';
import 'package:iaimei/widget/text_widget.dart';

class SnapTopTabNavConfig {
  SnapTopTabNavConfig({
    this.isScrollable = true,
    this.snapTopHeight = 44,
    this.snapTopBgColor = Colors.transparent,
    this.navMargin = EdgeInsets.zero,
    this.navTabMargin = EdgeInsets.zero,
    this.tabItemMargin = EdgeInsets.zero,
    this.indicatorPadding = EdgeInsets.zero,
    this.tabItemTextPadding = EdgeInsets.zero,
    this.indicatorSize = TabBarIndicatorSize.label,
    this.textColor = Colors.grey,
    this.selectedTextColor = Colors.black,
    this.textStyle,
    this.selectedTextStyle,
    this.indicatorDecoration = const BoxDecoration(),
    this.indicatorWidget = const SizedBox(),
    this.scrollController,
    this.indicator = const SizedBox(),
    this.leftWidget = const SizedBox(),
    this.rightWidget = const SizedBox(),
    this.alignment = Alignment.bottomCenter,
    this.snapTopMargin = EdgeInsets.zero,
    this.snapTopPadding = EdgeInsets.zero,
    this.snapTopDecoration,
    this.tabItemWidth,
    this.tabItemHeight,
  });

  final bool isScrollable;

  /// nav container
  final Color snapTopBgColor;
  final double snapTopHeight;
  final EdgeInsets indicatorPadding;
  final EdgeInsets navMargin;
  final EdgeInsets navTabMargin;
  final EdgeInsets tabItemMargin;
  final EdgeInsets tabItemTextPadding;
  final EdgeInsets? snapTopMargin;
  final EdgeInsets? snapTopPadding;
  final Decoration? snapTopDecoration;
  final double? tabItemWidth;
  final double? tabItemHeight;

  /// label setting
  final Color textColor;
  final Color selectedTextColor;
  final TextStyle? textStyle;
  final TextStyle? selectedTextStyle;

  /// indicator setting
  final Decoration indicatorDecoration;

  /// custom indicator
  final Widget indicator;
  final Alignment alignment;

  final Widget leftWidget;
  final Widget rightWidget;

  final Widget indicatorWidget;
  final TabBarIndicatorSize indicatorSize;
  final ScrollController? scrollController;
}

class SnapTopTabNavigator extends StatefulWidget {
  final Widget foldWidget;
  final Widget tabBarTopWidget;
  final Widget tabBarBottomWidget;
  final Widget divideWidget;
  final List<String> tabItems;
  final List<Widget> pages;
  final SnapTopTabNavConfig config;
  final int initIndex;

  const SnapTopTabNavigator(
      {Key? key,
      required this.tabItems,
      required this.pages,
      required this.config,
      this.initIndex = 0,
      this.foldWidget = const SizedBox(),
      this.tabBarTopWidget = const SizedBox(),
      this.tabBarBottomWidget = const SizedBox(),
      this.divideWidget = const SizedBox()})
      : super(key: key);

  @override
  _SnapTopTabNavigatorState createState() => _SnapTopTabNavigatorState();
}

class _SnapTopTabNavigatorState extends State<SnapTopTabNavigator>
    with TickerProviderStateMixin {
  TabController? _tabController;
  List<String>? _tabItems;
  int selectedIndex = 0;
  ScrollController? _scrollController;

  @override
  void initState() {
    super.initState();
    _tabItems = widget.tabItems;
    _scrollController = widget.config.scrollController ?? ScrollController();
    _tabController = TabController(
      initialIndex: widget.initIndex,
      length: _tabItems!.length,
      vsync: this,
    );
    if (_tabController != null) {
      _tabController!.addListener(() {
        setState(() {
          selectedIndex = _tabController!.index;
        });
      });
    }
  }

  @override
  void dispose() {
    if (_tabController != null) {
      _tabController!.dispose();
    }
    if (_scrollController != null) {
      _scrollController!.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return NestedScrollViewExt(
      controller: _scrollController,
      onlyOneScrollInBody: true,
      headerSliverBuilder: (BuildContext context, bool innerBoxIsScrolled) {
        return [
          SliverToBoxAdapter(child: widget.foldWidget),
        ];
      },
      body: Column(
        children: [
          _buildNavBar(),
          widget.divideWidget,
          Expanded(
            child: TabBarView(
              children: widget.pages,
              controller: _tabController,
            ),
          )
        ],
      ),
    );
  }

  _buildNavBar() {
    return Container(
      height: widget.config.snapTopHeight,
      margin: widget.config.snapTopMargin,
      padding: widget.config.snapTopPadding,
      alignment: Alignment.centerLeft,
      decoration: widget.config.snapTopDecoration ??
          BoxDecoration(
            color: widget.config.snapTopBgColor,
          ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          widget.tabBarTopWidget,
          Container(
            padding: widget.config.navMargin,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                widget.config.leftWidget,
                Expanded(
                    child: ListUtil.isNotEmpty(_tabItems)
                        ? Container(
                            margin: widget.config.navTabMargin,
                            child: _buildTabBar())
                        : const SizedBox()),
                widget.config.rightWidget,
              ],
            ),
          ),
          widget.tabBarBottomWidget,
        ],
      ),
    );
  }

  Widget _buildTabBar() {
    return Theme(
        data: ThemeData(
            splashColor: Colors.transparent,
            highlightColor: Colors.transparent),
        child: TabBar(
          controller: _tabController,
          isScrollable: widget.config.isScrollable,
          labelPadding: widget.config.tabItemMargin,
          indicatorPadding: widget.config.indicatorPadding,
          indicator: widget.config.indicatorDecoration,
          indicatorSize: widget.config.indicatorSize,
          unselectedLabelColor: widget.config.textColor,
          labelColor: widget.config.selectedTextColor,
          unselectedLabelStyle: widget.config.textStyle,
          labelStyle: widget.config.selectedTextStyle,
          tabs: _tabItems!
              .asMap()
              .keys
              .map((index) => _buildTabBarItem(index))
              .toList(),
        ));
  }

  Widget _buildTabBarItem(int index) {
    return Container(
      alignment: Alignment.center,
      width: widget.config.tabItemWidth,
      height: widget.config.tabItemHeight,
      child: Stack(
        children: [
          Positioned.fill(
              left: 0,
              right: 0,
              top: 0,
              bottom: 0,
              child: selectedIndex == index
                  ? widget.config.indicatorWidget
                  : const SizedBox()),
          Container(
            padding: widget.config.tabItemTextPadding,
            alignment: Alignment.center,
            child: TextWidget.buildSingleLineText(
              _tabItems?[index] ?? '',
              selectedIndex == index
                  ? widget.config.selectedTextStyle
                  : widget.config.textStyle,
            ),
          ),
        ],
      ),
    );
  }
}
