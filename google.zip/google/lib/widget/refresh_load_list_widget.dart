import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart'
    hide RefreshIndicator, RefreshIndicatorState;
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/res/img_res.dart';
import 'package:iaimei/res/string_res.dart';
import 'package:iaimei/style/app_text_style.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';

class GifHeader extends RefreshIndicator {
  GifHeader({Key? key})
      : super(
            key: key,
            height: DimenRes.dimen_80,
            refreshStyle: RefreshStyle.Follow);

  @override
  State<StatefulWidget> createState() {
    return GifHeaderState();
  }
}

class GifHeaderState extends RefreshIndicatorState<GifHeader> {
  @override
  void initState() {
    super.initState();
  }

  @override
  void onModeChange(RefreshStatus? mode) {
    if (mode == RefreshStatus.refreshing) {}
    super.onModeChange(mode);
  }

  @override
  Future<void> endRefresh() {
    return Future.delayed(
      const Duration(microseconds: 500),
      () {},
    );
  }

  @override
  void resetValue() {
    super.resetValue();
  }

  @override
  Widget buildContent(BuildContext context, RefreshStatus mode) {
    return Container(
        margin: EdgeInsets.symmetric(vertical: DimenRes.dimen_15),
        child: Image.asset(
          ImgRes.DOWN_REFRESH_GIF,
          height: DimenRes.dimen_50,
          fit: BoxFit.contain,
        ));
  }

  @override
  void dispose() {
    super.dispose();
  }
}

// ignore: must_be_immutable
class RefreshLoadListWidget extends StatefulWidget {
  const RefreshLoadListWidget({
    Key? key,
    required this.child,
    this.refreshController,
    this.onRefresh,
    this.enableRefresh = true,
    this.enableLoad = true,
    this.onLoad,
    this.scrollController,
  }) : super(key: key);

  final Widget child;
  final bool enableRefresh;
  final bool enableLoad;
  final VoidCallback? onRefresh;
  final VoidCallback? onLoad;
  final RefreshController? refreshController;
  final ScrollController? scrollController;

  @override
  _RefreshLoadListWidgetState createState() => _RefreshLoadListWidgetState();
}

class _RefreshLoadListWidgetState extends State<RefreshLoadListWidget> {
  RefreshController? _refreshController;
  ScrollController? _scrollController;

  @override
  void initState() {
    super.initState();
    _refreshController = widget.refreshController;
    _scrollController = widget.scrollController;
  }

  @override
  void dispose() {
    if (_refreshController != null) {
      _refreshController?.dispose();
    }
    if (_scrollController != null) {
      _scrollController?.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SmartRefresher(
      enablePullDown: widget.enableRefresh,
      enablePullUp: widget.enableLoad,
      header: GifHeader(),
      footer: _buildCustomFooter(),
      controller:
          _refreshController ?? RefreshController(initialRefresh: false),
      scrollController: _scrollController,
      onRefresh: widget.onRefresh,
      onLoading: widget.onLoad,
      child: widget.child,
    );
  }

  CustomFooter _buildCustomFooter() {
    return CustomFooter(
      builder: (context, mode) {
        Widget body;
        if (mode == LoadStatus.idle) {
          body = Text(StringRes.str_pull_up_load,
              style: AppTextStyle.build(Colors.white.withOpacity(0.8), 12));
        } else if (mode == LoadStatus.loading) {
          body = Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(
                width: DimenRes.dimen_12,
                height: DimenRes.dimen_12,
                child: CircularProgressIndicator(
                  strokeWidth: 1.5,
                  color: Colors.white.withOpacity(0.8),
                ),
              ),
              Padding(
                padding: EdgeInsets.only(left: DimenRes.dimen_5),
                child: Text(StringRes.str_loading_hint,
                    style:
                        AppTextStyle.build(Colors.white.withOpacity(0.8), 12)),
              )
            ],
          );
        } else if (mode == LoadStatus.failed) {
          body = Text(StringRes.str_load_failed,
              style: AppTextStyle.build(Colors.white.withOpacity(0.8), 12));
        } else if (mode == LoadStatus.canLoading) {
          body = Text(StringRes.str_release_load_more,
              style: AppTextStyle.build(Colors.white.withOpacity(0.8), 12));
        } else {
          body = Text(StringRes.str_no_more_data,
              style: AppTextStyle.build(Colors.white.withOpacity(0.8), 12));
        }
        return SizedBox(
          height: 50.0,
          child: Center(child: body),
        );
      },
    );
  }
}
