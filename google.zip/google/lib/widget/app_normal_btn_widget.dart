import 'package:flutter/material.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/res/img_res.dart';
import 'package:iaimei/style/app_text_style.dart';
import 'package:iaimei/widget/app_img_widget.dart';
import 'package:iaimei/widget/text_widget.dart';

class AppDialogBtnWidget extends StatelessWidget {
  final String text;
  final TextStyle? textStyle;
  final VoidCallback? onTap;
  final double left;
  final double right;
  final double top;
  final double bottom;

  const AppDialogBtnWidget(
      {Key? key,
      required this.text,
      this.textStyle,
      this.onTap,
      this.left = 15,
      this.right = 15,
      this.top = 8,
      this.bottom = 8})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
          alignment: Alignment.center,
          child: Stack(
            children: [
              AppImgWidget(
                path: ImgRes.DIALOG_BTN_BG,
                height: DimenRes.dimen_44,
              ),
              Positioned.fill(
                  left: left,
                  right: right,
                  top: top,
                  bottom: bottom,
                  child: Container(
                    alignment: Alignment.center,
                    child: TextWidget.buildSingleLineText(
                        text, textStyle ?? AppTextStyle.white_s14),
                  )),
            ],
          )),
    );
  }
}
