import 'package:flutter/material.dart';
import 'package:iaimei/res/dimen_res.dart';

class FrostedGlassBox extends StatelessWidget {
  final Widget child;
  final double? width;
  final double? height;
  final BorderRadius? borderRadius;
  final EdgeInsetsGeometry? margin;
  final EdgeInsetsGeometry? padding;

  const FrostedGlassBox(
      {Key? key,
      required this.child,
      this.width,
      this.height,
      this.borderRadius,
      this.margin,
      this.padding})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: width,
      height: height,
      margin: margin,
      padding: padding,
      decoration: BoxDecoration(
          boxShadow: const [
            BoxShadow(
                color: Color.fromRGBO(26, 21, 47, 0.12),
                offset: Offset(0, 3),
                blurRadius: 3,
                spreadRadius: 0)
          ],
          border: Border.all(color: Colors.white.withOpacity(0.12), width: 0.3),
          borderRadius: borderRadius ?? BorderRadius.circular(12),
          gradient: const LinearGradient(colors: [
            Color.fromRGBO(178, 170, 255, 0.12),
            Color.fromRGBO(108, 82, 222, 0.08),
          ], begin: Alignment.topCenter, end: Alignment.bottomCenter)),
      child: child,
    );
  }
}

class FrostedGlassSimpleBox extends StatelessWidget {
  final Widget child;
  final BorderRadius? borderRadius;
  final EdgeInsetsGeometry? margin;
  final EdgeInsetsGeometry? padding;
  final double? width;
  final double? height;
  final AlignmentGeometry? alignment;

  const FrostedGlassSimpleBox(
      {Key? key,
      required this.child,
      this.borderRadius,
      this.margin,
      this.padding,
      this.width,
      this.height,
      this.alignment})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: width,
      height: height,
      margin: margin,
      padding: padding,
      alignment: alignment,
      decoration: BoxDecoration(
          border: Border.all(color: Colors.white.withOpacity(0.12), width: 0.3),
          borderRadius:
              borderRadius ?? BorderRadius.circular(DimenRes.radius(12)),
          gradient: const LinearGradient(colors: [
            Color.fromRGBO(178, 170, 255, 0.12),
            Color.fromRGBO(108, 82, 222, 0.08),
          ], begin: Alignment.topCenter, end: Alignment.bottomCenter)),
      child: child,
    );
  }
}

class FrostedGlassDeepBox extends StatelessWidget {
  final Widget child;
  final BorderRadius? borderRadius;
  final EdgeInsetsGeometry? margin;
  final EdgeInsetsGeometry? padding;
  final double? width;
  final double? height;

  const FrostedGlassDeepBox(
      {Key? key,
      required this.child,
      this.borderRadius,
      this.margin,
      this.padding,
      this.width,
      this.height})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: width,
      height: height,
      margin: margin,
      padding: padding,
      decoration: BoxDecoration(
          border: Border.all(color: Colors.white.withOpacity(0.12), width: 0.3),
          borderRadius: borderRadius ?? BorderRadius.circular(12),
          gradient: const LinearGradient(colors: [
            Color.fromRGBO(178, 170, 255, 0.16),
            Color.fromRGBO(108, 82, 222, 0.12),
          ], begin: Alignment.topCenter, end: Alignment.bottomCenter)),
      child: child,
    );
  }
}
