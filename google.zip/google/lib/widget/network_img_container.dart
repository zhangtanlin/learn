import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import 'network_img_widget.dart';

class NetworkImgContainer extends StatelessWidget {
  final String url;
  final double? width;
  final double? height;
  final BorderRadius radius;
  final BoxFit fit;
  final Color? bgColor;
  final String? logoPath;
  final FilterQuality filterQuality;
  final bool noVisibilityDetector;



  const NetworkImgContainer(
      {Key? key,
      required this.url,
      this.width,
      this.height,
      this.radius = BorderRadius.zero,
      this.fit = BoxFit.cover,
      this.bgColor,
      this.logoPath,
      this.filterQuality = FilterQuality.medium,
      this.noVisibilityDetector = false})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: radius,
      clipBehavior: Clip.antiAlias,
      child: SizedBox(
        width: width,
        height: height,
        child: NetworkImgWidget(
          url: url,
          fit: fit,
          logoPath: logoPath,
          filterQuality: filterQuality,
          noVisibilityDetector: noVisibilityDetector,
          background: bgColor ?? Colors.white.withOpacity(0.12),
        ),
      ),
    );
  }
}
