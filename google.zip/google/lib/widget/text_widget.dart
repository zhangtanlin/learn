import 'package:flutter/material.dart';

class TextWidget {
  static buildSingleLineText(String text, TextStyle? style,
      {TextAlign? textAlign}) {
    return build(text, style,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        softWrap: false,
        textAlign: textAlign);
  }

  static build(String text, TextStyle? style,
      {int? maxLines,
      TextOverflow? overflow,
      TextAlign? textAlign,
      bool softWrap = true}) {
    return Text(
      text,
      maxLines: maxLines,
      softWrap: softWrap,
      //是否自动换行
      overflow: overflow,
      textAlign: textAlign,
      style: style,
    );
  }
}
