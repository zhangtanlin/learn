import 'package:bot_toast/bot_toast.dart';
import 'package:card_swiper/card_swiper.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:iaimei/components/common/commonelements.dart';
import 'package:iaimei/model/ads_model.dart';
import 'package:iaimei/model/atlas_item_model.dart';
import 'package:iaimei/model/atlas_series_item_model.dart';
import 'package:iaimei/model/comics_index_list_model.dart';
import 'package:iaimei/model/comics_item_model.dart';
import 'package:iaimei/model/novel_item_model.dart';
import 'package:iaimei/model/novel_list_model.dart';
import 'package:iaimei/model/video_model.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/router/routers.dart';
import 'package:iaimei/utils/list_util.dart';
import 'package:iaimei/utils/page_jump_util.dart';
import 'package:iaimei/utils/video_util.dart';
import 'package:iaimei/utils/web_util.dart';
import 'package:iaimei/widget/custom_swiper_indicator.dart';
import 'package:iaimei/widget/network_img_container.dart';
import 'package:iaimei/widget/toast_widget.dart';

typedef SwiperIndicator = Widget Function(
    BuildContext context, SwiperPluginConfig config);

class BannerWidget extends StatelessWidget {
  final List<AdsModel>? adList;
  final EdgeInsets margin;
  final EdgeInsets padding;
  final double width;
  final double height;
  final BorderRadius? radius;
  final ValueChanged<int>? onItemTap;
  final Axis scrollDirection;
  final SwiperController? swiperController;
  final Curve curve;
  final SwiperIndicator? swiperIndicator;

  const BannerWidget(
      {Key? key,
      this.adList,
      this.margin = EdgeInsets.zero,
      this.padding = EdgeInsets.zero,
      this.height = 150,
      this.width = 0,
      this.radius,
      this.onItemTap,
      this.scrollDirection = Axis.horizontal,
      this.swiperController,
      this.curve = Curves.ease,
      this.swiperIndicator})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    double bWidth = width > 0 ? width : double.infinity;
    double bHeight = height;
    return Container(
      margin: margin,
      padding: padding,
      width: bWidth,
      height: bHeight,
      child: Swiper(
        itemCount: adList!.length,
        autoplay: adList!.length > 1,
        itemWidth: double.infinity,
        itemHeight: double.infinity,
        curve: curve,
        onTap: onItemTap ??
            (index) {
              _onItemClick(context, index);
            },
        scrollDirection: scrollDirection,
        controller: swiperController ?? SwiperController(),
        itemBuilder: (context, index) {
          return NetworkImgContainer(
              url: adList?[index].imgUrl ?? '',
              radius: radius ?? BorderRadius.zero,
              noVisibilityDetector: true);
        },
        pagination: SwiperPagination(
            alignment: Alignment.bottomRight,
            margin: EdgeInsets.only(
                bottom: DimenRes.dimen_6, right: DimenRes.dimen_6),
            builder: SwiperCustomPagination(
                builder: (BuildContext context, SwiperPluginConfig config) {
              return swiperIndicator != null
                  ? swiperIndicator!(context, config)
                  : CustomSwiperIndicator(
                      config: config,
                      list: adList,
                    );
            })),
      ),
    );
  }

  void _onItemClick(BuildContext context, int index) {
    if (ListUtil.isEmpty(adList) || adList!.length <= index) return;
    BannerWidget.parseAdType(context, adList![index], isSub: false);
  }

  static void parseAdType(BuildContext context, AdsModel adsModel,
      {bool isSub = true}) {
    switch (adsModel.type) {
      case 0: // 不处理
        break;
      case 1: // 外部跳转 1
        WebUtil.browserLaunchURL(adsModel.url!);
        break;
      case 2: // 标签视频 不处理
        break;
      case 3: // 内部跳转 1
        PageJumpUtil.forwardToWebViewPage(context,
            {'title': adsModel.title ?? '', 'url': adsModel.url ?? ''});
        break;
      case 4: // 指定视频 1
        var videoModel = VideoModel()..id = int.parse(adsModel.url ?? '0');
        VideoUtil.jumpToVideoPlayer(context,[videoModel]);
        break;
      case 5: // 指定小说 1
        PageJumpUtil.forwardToNovelDetailPage(
          context,
          NovelItemModel(
              id: int.parse(adsModel.url ?? ''), title: adsModel.title),
        );
        break;
      case 6: // 跳充值VIP 1
        context.push('/' + Routes.rechargeVip);
        break;
      case 7: // 跳余额充值 1
        context.push('/' + Routes.rechargeCoins);
        break;
      case 8: // 系列视频 1
        _buildSeriesVideoAction(context, adsModel.title, '${adsModel.url}');
        break;
      case 9: // 指定特价 不处理
        break;
      case 10: // 女优主页 1
        context.push('/' + Routes.actressDetail, extra: adsModel.url);
        break;
      case 11: // 指定约炮 1
        context.push(
          '/${Routes.datingDetail}',
          extra: {'info_id': adsModel.url},
        );
        break;
      case 12: // 指定漫画 1
        PageJumpUtil.forwardToComicsDetailPage(
          context,
          ComicsItemModel(
              id: int.parse(adsModel.url ?? '0'), title: adsModel.title),
        );
        break;
      case 13: // 系列漫画 1
        PageJumpUtil.forwardToComicsSeriesPage(
          context,
          ComicsListModel(
              id: int.parse(adsModel.url ?? '0'), name: adsModel.title),
        );
        break;
      case 14: // 指定图集 1
        PageJumpUtil.forwardToAtlasDetailPage(
          context,
          AtlasItemModel(
              id: int.parse(adsModel.url ?? '0'), title: adsModel.title),
        );
        break;
      case 15: // 系列图集 1
        PageJumpUtil.forwardToAtlasSeriesPage(
          context,
          AtlasSeriesItemModel(
              id: int.parse(adsModel.url ?? '0'), name: adsModel.title),
        );
        break;
      case 16: // 创作中心 不处理
        context.push('/' + Routes.creator);
        break;
      case 17: // 原生通用 1
        commonPushAction(context, adsModel.url ?? '');
        break;
      case 18: // 系列小说 1
        PageJumpUtil.forwardToNovelSeriesPage(
          context,
          NovelListModel(
              id: int.parse(adsModel.url ?? '0'), name: adsModel.title),
        );
        break;
      case 19: // 指定裸聊 1
        context.push(
          '/${Routes.chatDetail}',
          extra: {'info_id': adsModel.url},
        );
        break;
      default:
        ToastWidget.showToast("当前版本较低，请更新至最新版");
        break;
    }
  }

  static void _buildSeriesVideoAction(BuildContext context, title, String url) {
    List param = url.split('#'); // id#column#isWaterfallsflow
    if (param.isEmpty) {
      BotToast.showText(text: '数据错误...');
      return;
    }
    WaterfallExtra object = WaterfallExtra(
      title: '$title',
      isWaterfallsflow: param.length > 2 ? int.parse(param[1]) > 0 : false,
      crossAxisCount: param.length > 1 ? int.parse(param[1]) : 1,
      url: '/api/menu/series_mv',
      params: {'id': param.first},
    );
    context.push('/' + Routes.mvListViewPage, extra: object);
  }

  static void commonPushAction(BuildContext context, String value) {
    switch (value) {
      case 'agency': // 全民代理
        context.push('/' + Routes.agency);
        break;
      case 'creator': // 创作中心
        context.push('/' + Routes.creator);
        break;
      case 'members': // 跳充值VIP
        context.push('/' + Routes.rechargeVip);
        break;
      case 'balance': // 跳余额充值
        context.push('/' + Routes.rechargeCoins);
        break;
      case 'official': // 联系官方
        context.push('/' + Routes.contact);
        break;
      case 'services':  // 联系客服
        context.push('/' + Routes.contact);
        break;
      default:
    }
  }
}
