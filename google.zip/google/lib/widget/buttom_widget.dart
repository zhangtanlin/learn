import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

enum IconStyle {
  pink,
  pink_207_50,
  pink_60_34,
  pink_68_34,
  purple,
}

class ButtonWidget {
  static Widget build(String text, {IconStyle? style, void Function()? onTap}) {
    late String path;
    double btnWidth = 126.w;
    double btnHeight = 50.w;
    switch (style) {
      case IconStyle.purple:
        path = 'assets/images/button/btn_purple.png';
        break;
      case IconStyle.pink_207_50:
        path = 'assets/images/button/btn_pink_largest.png';
        btnWidth = 207.w;
        break;
      case IconStyle.pink_60_34:
        path = 'assets/images/button/btn_pink_60_34.png';
        btnWidth = 60.w;
        btnHeight = 34.w;
        break;
      case IconStyle.pink_68_34:
        path = 'assets/images/button/btn_small.png';
        btnWidth = 68.w;
        btnHeight = 34.w;
        break;
      default:
        path = 'assets/images/button/btn_pink_base.png';
    }
    return bgText(text, path, size: Size(btnWidth, btnHeight), onTap: onTap);
  }

  static Widget bgText(String text, String path,
      {Size? size, void Function()? onTap}) {
    size ??= Size(126.w, 50.w);
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.only(bottom: 3.w),
        height: size.height,
        width: size.width,
        decoration: BoxDecoration(
          image: DecorationImage(image: AssetImage(path), fit: BoxFit.fitHeight),
        ),
        child: Center(
          child: Text(
            text,
            style: TextStyle(
              color: Colors.white,
              fontSize: size.height < 50 ? 12.sp : 16.sp,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
      ),
    );
  }

  static Widget transparent(
      {String text = '联系客服',
      Color color = const Color(0xa3ffffff),
      void Function()? onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: SizedBox(
        height: 50.w,
        width: 126.w,
        child: Center(
          child: Text(
            text,
            style: TextStyle(color: color, fontSize: 16.sp),
          ),
        ),
      ),
    );
  }
}
