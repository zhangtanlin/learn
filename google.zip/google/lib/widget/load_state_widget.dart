import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:iaimei/res/color_res.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/res/img_res.dart';
import 'package:iaimei/res/string_res.dart';
import 'package:iaimei/style/app_text_style.dart';
import 'package:iaimei/widget/text_widget.dart';

class LoadSateWidget {
  static Widget errorView(GestureTapCallback callback,
      {Color bgColor = Colors.transparent,
      String hint = StringRes.str_load_failed_retry}) {
    return LayoutBuilder(
      builder: (BuildContext context, BoxConstraints constraints) {
        return SingleChildScrollView(
          physics: const NeverScrollableScrollPhysics(),
          child: ConstrainedBox(
            constraints: BoxConstraints(
              minWidth: constraints.maxWidth,
              maxWidth: double.infinity,
              minHeight: constraints.maxHeight,
              maxHeight: double.infinity,
            ),
            child: IntrinsicHeight(
              child: Container(
                color: bgColor,
                child: InkWell(
                  onTap: callback,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Padding(
                        padding: const EdgeInsets.symmetric(
                            vertical: 15, horizontal: 30),
                        child: Image.asset(
                          ImgRes.IC_LOAD_ERROR,
                          fit: BoxFit.contain,
                          height: DimenRes.dimen_120,
                        ),
                      ),
                      TextWidget.build(hint, AppTextStyle.white_s14)
                    ],
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  static Widget loadingView(
      {Color bgColor = Colors.transparent,
      Color loadColor = ColorRes.color_ff00b3}) {
    return Container(
      width: double.infinity,
      height: double.infinity,
      color: bgColor,
      child: SpinKitFadingCircle(
        color: loadColor,
        size: 45.0,
      ),
    );
  }

  static Widget noDataView(GestureTapCallback callback,
      {Color bgColor = Colors.transparent,
      String hint = StringRes.str_no_date_retry}) {
    return LayoutBuilder(
        builder: (BuildContext context, BoxConstraints constraints) {
      return SingleChildScrollView(
        physics: const NeverScrollableScrollPhysics(),
        child: ConstrainedBox(
          constraints: BoxConstraints(
            minWidth: constraints.maxWidth,
            maxWidth: double.infinity,
            minHeight: constraints.maxHeight,
            maxHeight: double.infinity,
          ),
          child: IntrinsicHeight(
            child: Container(
              color: bgColor,
              child: InkWell(
                onTap: callback,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(
                          vertical: 15, horizontal: 30),
                      child: Image.asset(
                        ImgRes.IC_NO_DATA,
                        fit: BoxFit.contain,
                        height: DimenRes.dimen_120,
                      ),
                    ),
                    TextWidget.build(hint, AppTextStyle.white_s14)
                  ],
                ),
              ),
            ),
          ),
        ),
      );
    });
  }

  static Widget noNetWorkView(GestureTapCallback callback,
      {Color bgColor = Colors.transparent,
      String hint = StringRes.str_no_net_retry}) {
    return LayoutBuilder(
      builder: (BuildContext context, BoxConstraints constraints) {
        return SingleChildScrollView(
          physics: const NeverScrollableScrollPhysics(),
          child: ConstrainedBox(
            constraints: BoxConstraints(
              minWidth: constraints.maxWidth,
              maxWidth: double.infinity,
              minHeight: constraints.maxHeight,
              maxHeight: double.infinity,
            ),
            child: IntrinsicHeight(
              child: Container(
                color: bgColor,
                child: InkWell(
                  onTap: callback,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Padding(
                        padding: const EdgeInsets.symmetric(
                            vertical: 15, horizontal: 30),
                        child: Image.asset(
                          ImgRes.IC_NO_NETWORK,
                          fit: BoxFit.contain,
                          height: DimenRes.dimen_120,
                        ),
                      ),
                      TextWidget.build(hint, AppTextStyle.white_s14)
                    ],
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
