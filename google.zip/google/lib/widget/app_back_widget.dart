import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/res/img_res.dart';

class AppBackWidget extends StatelessWidget {
  final String? path;
  final BoxFit? fit;
  final double? width;
  final double? height;
  final VoidCallback? onTap;

  const AppBackWidget({
    Key? key,
    this.path,
    this.fit = BoxFit.contain,
    this.width,
    this.height,
    this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap ??
          () {
            Navigator.pop(context);
          },
      child: Image.asset(
        path ?? ImgRes.IC_ARROW_BACK,
        fit: fit,
        width: width ?? DimenRes.dimen_35,
        height: height ?? DimenRes.dimen_35,
      ),
    );
  }
}
