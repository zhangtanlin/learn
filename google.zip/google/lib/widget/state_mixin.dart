import 'package:bot_toast/bot_toast.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:iaimei/net/http_error.dart';
import 'package:iaimei/widget/convenient_mixin.dart';

enum WidgetState {
  init,
  noNetwork,
  error,
  empty, // list为空
  noData, // 根据size判断是否有下页
  finish, //
}

mixin StateMixin<T extends StatefulWidget> on ConvenientMixin, State<T> {
  WidgetState widgetState = WidgetState.init;
  int size = 20;
  int currentPage = 1;

  List dataList = [];
  Map<String, dynamic> get param => {'page': currentPage, 'limit': size};

  /* *loading refresh * */
  void onRefresh() {
    currentPage = 1;
    initLoadingData();
  }

  void onLoading() {
    // 没更多数据，不用再加载更多
    if (widgetState == WidgetState.noData) return;

    // 第一页没数据，不用再加载更多
    if (widgetState == WidgetState.empty) return;

    currentPage += 1;
    initLoadingData();
  }

  void initLoadingData() {}

  @override
  void initState() {
    super.initState();
    initLoadingData();
    feedbackBlock = () => context.push('/onlineService');
  }

  /* ------------------- */

  void updateListAndWidgetState(List list, {bool useEmpty = true}) {
    if (list.isEmpty) {
      if (currentPage == 1) {
        widgetState = useEmpty ? WidgetState.empty : WidgetState.noData;
      } else {
        widgetState = WidgetState.noData;
      }
      // widgetState = useEmpty ? WidgetState.empty : WidgetState.noData;
    } else {
      if (currentPage == 1) {
        dataList = list;
      } else {
        dataList.addAll(list);
      }
      widgetState = WidgetState.finish;
    }
    if (mounted) setState(() {});
  }

  void dealWithErrorsWidgetState(HttpError error) {
    if (error.code == -2) {
      widgetState = WidgetState.noNetwork;
    } else {
      widgetState = WidgetState.error; //
    }

    // if (currentPage > 1) {
    BotToast.showText(text: error.message ?? '...');
    // }
    setState(() {});
  }

  bool get isAll {
    return widgetState == WidgetState.noData ||
        widgetState == WidgetState.empty;
  }

  Widget placeholderWidget() {
    switch (widgetState) {
      case WidgetState.init:
        return loadingWiget();
      case WidgetState.noNetwork:
        return noNetWidget();
      case WidgetState.empty: // 首页
        return noDataWidget();
      case WidgetState.error:
        return errorWidget();
      case WidgetState.noData: // 非首页
        return Container();
      case WidgetState.finish: //
        return Container();
    }
  }
}
