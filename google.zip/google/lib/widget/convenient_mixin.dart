import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';

mixin ConvenientMixin {
  final fontM = FontWeight.w500;
  final fontB = FontWeight.w600;

  final wColor = const Color.fromRGBO(255, 255, 255, 1);
  final rColor = const Color.fromRGBO(255, 0, 179, 1.0);

  final color_84 = const Color.fromRGBO(255, 255, 255, 0.84);
  final color_72 = const Color.fromRGBO(255, 255, 255, 0.72);
  final color_64 = const Color.fromRGBO(255, 255, 255, 0.64);
  final color_54 = const Color.fromRGBO(255, 255, 255, 0.54);

  var radii = BorderRadius.circular(12);
  Widget buildContainerWidget({
    required double width,
    required double height,
    required Widget child,
    EdgeInsets? margin,
    EdgeInsets? padding,
    BorderRadius? radius,
  }) {
    radius ??= radii;
    return Container(
      height: height,
      width: width,
      margin: margin,
      padding: padding,
      clipBehavior: Clip.hardEdge,
      decoration: BoxDecoration(
        color: const Color.fromRGBO(188, 136, 255, 0.12),
        borderRadius: BorderRadius.circular(12.sp),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(12.sp),
        child: child,
      ),
    );
  }

  Widget loadingWiget({Color bgColor = Colors.transparent, Color? loadColor}) {
    return Container(
      width: double.infinity,
      height: double.infinity,
      color: bgColor,
      child: SpinKitFadingCircle(
        color: loadColor ?? rColor,
        size: 45.0,
      ),
    );
  }

  Widget noNetWidget() {
    return buildDataWidget(
        icon: 'assets/images/common/ic_no_network.png',
        content: '没有网络',
        tipHidden: true);
  }

  Widget errorWidget() {
    return buildDataWidget(
        icon: 'assets/images/common/ic_load_error.png',
        content: '加载失败',
        tipHidden: true);
  }

  void Function()? feedbackBlock;
  Widget noDataWidget() {
    return buildDataWidget(
        icon: 'assets/images/common/ic_load_error.png',
        content: '暂无数据',
        btnText: '反馈',
        onTap: feedbackBlock);
  }

  /* *无数据特殊处理 开始* */
  Widget noDataVipWidget() {
    return buildDataWidget(
        icon: 'assets/images/income/pm_no_data_vip.png',
        content: '这里什么都没找到',
        top: 104.w,
        tipHidden: true);
  }

  /* *无数据特殊处理 结束* */

  Widget buildDataWidget({
    String? icon,
    String content = '',
    double? top,
    String? btnText,
    bool tipHidden = false,
    void Function()? onTap,
  }) {
    return Align(
      alignment: Alignment.topCenter,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(height: top ?? 38.w),
          Offstage(
            offstage: icon == null,
            child: Image.asset(icon ?? 'assets/images/common/ic_load_error.png',
                width: 120.w, height: 90.w),
          ),
          Text(
            content,
            style: TextStyle(fontSize: 12.sp, color: wColor, fontWeight: fontB),
          ),
          Offstage(
            offstage: btnText == null,
            child: Padding(
              padding: EdgeInsets.only(top: 42.5.w),
              child: _buildButtonWidget('$btnText', onTap: onTap),
            ),
          ),
          Offstage(
            offstage: tipHidden,
            child: Padding(
              padding: EdgeInsets.only(top: 20.w),
              child: Text(
                '我们拥有强大的运营团队，时刻把用户体验放在第一位',
                style: TextStyle(color: color_64, fontSize: 12.sp),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildButtonWidget(String text, {void Function()? onTap}) {
    var path = 'assets/images/button/btn_pink_base.png';
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 50.w,
        width: 126.w,
        padding: EdgeInsets.only(bottom: 3.w),
        decoration: BoxDecoration(
          image: DecorationImage(image: AssetImage(path)),
        ),
        child: Center(
          child: Text(
            text,
            style: TextStyle(fontWeight: fontM, fontSize: 16.sp, color: wColor),
          ),
        ),
      ),
    );
  }
}
