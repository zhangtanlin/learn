import 'package:flutter/material.dart';
import 'package:flutter_html/shims/dart_ui_real.dart';

class PurpleFrostedGlassContainer extends StatelessWidget {
  final Widget child;
  final BorderRadius? radius;
  final double sigmaX;
  final double sigmaY;

  const PurpleFrostedGlassContainer(
      {Key? key,
      required this.child,
      this.radius,
      this.sigmaX = 0,
      this.sigmaY = 0})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: radius,
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: sigmaX, sigmaY: sigmaY),
        child: Container(
          width: double.infinity,
          decoration: const BoxDecoration(
              gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                Color.fromRGBO(178, 170, 255, 0.12),
                Color.fromRGBO(108, 82, 222, 0.08),
              ])),
          child: Container(
            decoration: BoxDecoration(
              color: const Color(0xff56257B).withOpacity(0.4)
            ),
            child: child,
          ),
        ),
      ),
    );
  }
}
