import 'package:flutter/material.dart';

class RichTextWidget extends StatelessWidget {
  final String? frontText;
  final TextStyle? frontTextStyle;
  final String? backText;
  final TextStyle? backTextStyle;
  final Widget? midWidget;
  final int? maxLines;
  final PlaceholderAlignment? imgAlignment;
  final TextAlign? textAlign = TextAlign.start;
  final double? space;
  final bool? softWrap;

  const RichTextWidget(
      {Key? key,
      this.frontText,
      this.frontTextStyle,
      this.backText,
      this.backTextStyle,
      this.midWidget,
      this.maxLines,
      this.space,
      this.softWrap,
      this.imgAlignment})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Text.rich(
      TextSpan(text: frontText, style: frontTextStyle, children: [
        WidgetSpan(
            child: midWidget ??
                SizedBox(
                  width: space,
                ),
            alignment: imgAlignment ?? PlaceholderAlignment.middle),
        TextSpan(
          text: backText,
          style: backTextStyle,
        ),
      ]),
      textAlign: textAlign,
      maxLines: maxLines,
      softWrap: softWrap,
    );
  }
}
