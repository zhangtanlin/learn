import 'package:flutter/material.dart';

class TransitionWidget extends StatelessWidget {
  final double? height;
  final double? width;
  final double? left;
  final double? right;
  final double? bottom;
  final double? top;
  final double opacity;
  final Widget? child;
  final int time;

  const TransitionWidget(
      {Key? key,
      this.height,
      this.width,
      this.left,
      this.right,
      this.bottom,
      this.top,
      this.opacity = 0,
      this.child,
      this.time = 200})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: height,
      width: width,
      child: Stack(
        children: [
          Container(),
          AnimatedPositioned(
              left: left,
              right: right,
              bottom: bottom,
              top: top,
              child: AnimatedOpacity(
                opacity: opacity,
                duration:  Duration(milliseconds: time),
                child: child,
              ),
              duration:  Duration(milliseconds: time))
        ],
      ),
    );
  }
}
