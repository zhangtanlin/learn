import 'package:flutter/material.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/style/app_text_style.dart';
import 'package:iaimei/widget/app_back_widget.dart';
import 'package:iaimei/widget/page_title_bar_widget.dart';
import 'package:iaimei/widget/text_widget.dart';

class AppPageTitleBar {
  static getNormalAppBar(
      {String? title,
      AlignmentGeometry titleAlignment = Alignment.centerLeft,
      Color bgColor = Colors.transparent,
      double barHeight = 0,
      Widget? rightWidget}) {
    return PageTitleBarWidget(
      bgColor: bgColor,
      barHeight: barHeight > 0 ? barHeight : DimenRes.dimen_44,
      leftWidget: Container(
        padding: EdgeInsets.symmetric(horizontal: DimenRes.dimen_6),
        child: const AppBackWidget(),
      ),
      titleWidget: Container(
          alignment: titleAlignment,
          margin: EdgeInsets.symmetric(horizontal: DimenRes.dimen_45),
          child: TextWidget.buildSingleLineText(
              title ?? '', AppTextStyle.white_s16)),
      rightWidget: rightWidget != null
          ? Container(
              padding: EdgeInsets.symmetric(horizontal: DimenRes.dimen_15),
              child: rightWidget,
            )
          : const SizedBox(),
    );
  }
}
