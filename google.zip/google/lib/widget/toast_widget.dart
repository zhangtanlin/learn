import 'package:bot_toast/bot_toast.dart';
import 'package:flutter/material.dart';
import 'package:iaimei/res/color_res.dart';

class ToastWidget {
  static showToast(String content,
      {double radius = 20,
      Color contentColor = ColorRes.color_ff00b3,
      double fontSize = 12,
      Color textColor = Colors.white,
      AlignmentGeometry align = const Alignment(0, 0.8),
      int seconds = 3}) {
    return BotToast.showText(
        text: content,
        align: align,
        borderRadius: BorderRadius.all(Radius.circular(radius)),
        contentColor: contentColor.withOpacity(0.8),
        textStyle: TextStyle(
            overflow: TextOverflow.ellipsis,
            fontSize: fontSize,
            color: textColor),
        contentPadding: const EdgeInsets.symmetric(horizontal: 15, vertical: 5),
        duration: Duration(seconds: seconds));
  }
}
