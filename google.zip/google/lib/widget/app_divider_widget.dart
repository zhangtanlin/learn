import 'package:flutter/material.dart';

class AppDividerWidget extends StatelessWidget {
  final double? height;
  final Color? color;
  final EdgeInsetsGeometry? padding;

  const AppDividerWidget({Key? key, this.height, this.color, this.padding})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: padding ?? EdgeInsets.zero,
      child: Divider(
        height: height ?? 0.5,
        color: color ?? Colors.white.withOpacity(0.2),
      ),
    );
  }
}
