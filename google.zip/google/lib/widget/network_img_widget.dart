import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:iaimei/res/img_res.dart';
import 'package:iaimei/utils/common.dart';
import 'package:visibility_detector/visibility_detector.dart';

class NetworkImgWidget extends StatefulWidget {
  final dynamic url;
  final BoxFit fit;
  final bool noVisibilityDetector;
  final BorderRadius? borderRadius;
  final Clip clipBehavior;
  final FilterQuality filterQuality;
  final Color background;
  final String? logoPath;

  const NetworkImgWidget(
      {Key? key,
      this.url,
      this.fit = BoxFit.cover,
      this.noVisibilityDetector = false,
      this.borderRadius,
      this.clipBehavior = Clip.hardEdge,
      this.filterQuality = FilterQuality.medium,
      this.background = Colors.transparent,
      this.logoPath})
      : super(key: key);

  @override
  _NetworkImgWidgetState createState() => _NetworkImgWidgetState();
}

class _NetworkImgWidgetState extends State<NetworkImgWidget> {
  dynamic _url;
  final GlobalKey _key = GlobalKey();
  bool isAnimated = true;
  bool isLoad = false;

  @override
  void initState() {
    super.initState();
    if (widget.noVisibilityDetector && mounted) {
      setImgUrl();
    }
  }


  @override
  Widget build(BuildContext context) {
    return VisibilityDetector(
        key: _key,
        child: imageWidget(),
        onVisibilityChanged: _handleVisibilityChanged);
  }

  void _handleVisibilityChanged(VisibilityInfo info) {
    if (isLoad) return;
    isLoad = true;
    _getRealImg();
  }

  void setImgUrl() {
    _getRealImg();
  }

  void _getRealImg() {
    Method.getRealImage(
        url: widget.url,
        imgUrl: _url,
        setUrl: (e) {
          if (!mounted) return;
          setState(() {
            _url = e;
          });
        });
  }

  @override
  void didUpdateWidget(covariant NetworkImgWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.url != oldWidget.url) {
      setImgUrl();
    }
  }

  @override
  void dispose() {
    super.dispose();
  }

  Widget imageWidget() {
    bool isShow = _url != null;
    return LayoutBuilder(
        builder: (BuildContext context, BoxConstraints constraints) {
      return Container(
        width: double.infinity,
        height: double.infinity,
        clipBehavior: widget.clipBehavior,
        decoration: BoxDecoration(
            color: !isShow ? widget.background : Colors.transparent,
            borderRadius: widget.borderRadius ?? BorderRadius.circular(0)),
        child: Stack(
          children: [
            !isShow ? _buildPlaceholderSection(constraints) : const SizedBox(),
            Positioned(
                top: 0,
                bottom: 0,
                left: 0,
                right: 0,
                child: !isAnimated
                    ? (isShow
                        ? Image.memory(
                            _url,
                            fit: widget.fit,
                            filterQuality: widget.filterQuality,
                          )
                        : Container())
                    : AnimatedOpacity(
                        curve: Curves.easeIn,
                        opacity: isShow ? 1 : 0,
                        child: isShow
                            ? Image.memory(
                                _url,
                                fit: widget.fit,
                                filterQuality: widget.filterQuality,
                              )
                            : Container(),
                        duration: const Duration(milliseconds: 100))),
          ],
        ),
      );
    });
  }

  _buildPlaceholderSection(BoxConstraints constraints) {
    double imgSize = constraints.maxWidth <= constraints.maxHeight
        ? constraints.maxWidth
        : constraints.maxHeight;
    return Center(
      child: Image.asset(
        widget.logoPath ?? ImgRes.IC_PLACEHOLDER_LOGO,
        height: imgSize / 5,
        fit: BoxFit.contain,
      ),
    );
  }
}
