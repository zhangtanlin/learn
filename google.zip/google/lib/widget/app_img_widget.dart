import 'package:flutter/material.dart';

class AppImgWidget extends StatelessWidget {
  final String path;
  final BoxFit? fit;
  final double? width;
  final double? height;
  final VoidCallback? onTap;

  const AppImgWidget({
    Key? key,
    required this.path,
    this.fit = BoxFit.contain,
    this.width,
    this.height,
    this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return onTap != null
        ? GestureDetector(
            onTap: onTap,
            child: _buildImageSection(),
          )
        : _buildImageSection();
  }

  Image _buildImageSection() {
    return Image.asset(
      path,
      fit: fit,
      width: width,
      height: height,
    );
  }
}
