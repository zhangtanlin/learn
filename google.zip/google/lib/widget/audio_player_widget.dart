import 'dart:async';

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:iaimei/components/common/customslider.dart';
import 'package:iaimei/res/dimen_res.dart';
import 'package:iaimei/res/img_res.dart';
import 'package:iaimei/style/app_text_style.dart';
import 'package:iaimei/utils/audio_util.dart';

class AudioPlayerWidget extends StatefulWidget {
  const AudioPlayerWidget(
      {Key? key,
      this.url,
      this.curIndex = 0,
      this.isFront = true,
      this.index = 0})
      : super(key: key);

  final dynamic url;
  final bool isFront;
  final int curIndex;
  final int index;

  @override
  State<AudioPlayerWidget> createState() => _AudioPlayerWidgetState();
}

class _AudioPlayerWidgetState extends State<AudioPlayerWidget> {
  late AudioPlayer audioPlayer;
  late String _curUrl;
  bool isPlaying = false;
  bool isBuffering = false;
  Duration _position = Duration.zero;
  Duration _duration = Duration.zero;
  StreamSubscription? _positionSubscription;
  StreamSubscription? _durationSubscription;
  StreamSubscription? _playerCompleteSubscription;
  StreamSubscription? _playerStateChangeSubscription;

  String getFormatDuration(Duration duration) {
    String tempDurationText = '';
    int hours = duration.inHours;
    if (hours > 0) {
      tempDurationText = duration.toString().split('.').first;
    } else {
      tempDurationText = duration.toString().substring(2, 7);
    }
    return tempDurationText;
  }

  String get _durationText {
    return getFormatDuration(_duration);
  }

  String get _positionText {
    return getFormatDuration(_position);
  }

  Future<void> _play() async {
    final position = _position;
    if (position != null && position.inMilliseconds > 0) {
      await audioPlayer.seek(position);
    }
    await audioPlayer.resume();
    setState(() {
      isPlaying = true;
      isBuffering = true;
    });
  }

  Future<void> _pause() async {
    await audioPlayer.pause();
    setState(() {
      isPlaying = false;
      isBuffering = false;
    });
  }

  Future<void> _stop() async {
    await audioPlayer.stop();
    setState(() {
      isPlaying = false;
      isBuffering = false;
      _position = const Duration();
    });
  }

  @override
  void initState() {
    super.initState();
    audioPlayer = AudioPlayer();
    getCurAudioUrl();
    initAudioListener();
  }

  getCurAudioUrl() async {
    _curUrl = await AudioUtil.getRealUrl(widget.url);
  }

  void initAudioListener() {
    Future.delayed(Duration.zero, () async {
      UrlSource urlSource = UrlSource(_curUrl);
      audioPlayer.setSource(urlSource);
      _positionSubscription = audioPlayer.onPositionChanged.listen(
        (position) {
          if (mounted) {
            if (isPlaying) {
              setState(() {
                if (_position != position) {
                  _position = position;
                  isBuffering = false;
                } else {
                  isBuffering = true;
                }
              });
            }
          }
        },
      );

      _durationSubscription = audioPlayer.onDurationChanged.listen((duration) {
        if (mounted) {
          setState(() {
            _duration = duration;
          });
        }
      });

      _playerCompleteSubscription =
          audioPlayer.onPlayerComplete.listen((event) {
        _stop();
      });

      _playerStateChangeSubscription =
          audioPlayer.onPlayerStateChanged.listen((state) {});
    });
  }

  @override
  void dispose() {
    _positionSubscription?.cancel();
    _durationSubscription?.cancel();
    _playerCompleteSubscription?.cancel();
    _playerStateChangeSubscription?.cancel();
    audioPlayer.dispose();
    super.dispose();
  }

  @override
  void didUpdateWidget(covariant AudioPlayerWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.index != widget.curIndex || !widget.isFront) {
      _pause();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      mainAxisSize: MainAxisSize.min,
      children: [
        isBuffering ? _buildBufferSection() : _buildPlayPauseSection(),
        Expanded(
          child: _buildCustomSliderSection(),
        ),
        _buildPositionText()
      ],
    );
  }

  Text _buildPositionText() {
    return Text(
      _position != null ? _positionText : '',
      maxLines: 1,
      overflow: TextOverflow.ellipsis,
      style: AppTextStyle.white_s11,
    );
  }

  CustomSlider _buildCustomSliderSection() {
    return CustomSlider(
      value: (_position != null &&
              _duration != null &&
              _position.inMilliseconds > 0 &&
              _position.inMilliseconds < _duration.inMilliseconds)
          ? _position.inMilliseconds / _duration.inMilliseconds
          : 0.0,
      linearGradient:
          const LinearGradient(colors: [Color(0xffff36da), Color(0xffa653ff)]),
      assetImage: ImgRes.IC_SLIDER_BAR,
      inActiveTrackColor: const Color(0x3dffffff),
      trackHeight: DimenRes.dimen_2,
      onChanged: (double value) async {
        final duration = _duration;
        if (duration == null) {
          return;
        }
        final position = value * duration.inMilliseconds;
        audioPlayer.seek(Duration(milliseconds: position.round()));
      },
    );
  }

  GestureDetector _buildPlayPauseSection() {
    return GestureDetector(
      onTap: () {
        isPlaying ? _pause() : _play();
      },
      child: Image.asset(
        isPlaying ? ImgRes.IC_WHITE_PAUSE : ImgRes.IC_WHITE_PLAY,
        width: DimenRes.convert(24),
        height: DimenRes.convert(24),
      ),
    );
  }

  _buildBufferSection() {
    return SizedBox(
      width: DimenRes.dimen_20,
      height: DimenRes.dimen_20,
      child: CircularProgressIndicator(
        strokeWidth: DimenRes.dimen_3,
        color: Colors.white,
      ),
    );
  }
}
