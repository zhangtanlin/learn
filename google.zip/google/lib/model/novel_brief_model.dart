class NovelBriefModel {
  final int id;
  final int episode;
  final int totalEpisode;
  final String title;
  final String updateInfo;

  NovelBriefModel(this.id, this.episode,this.totalEpisode,
      this.title, this.updateInfo);
}
