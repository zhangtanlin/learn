class ChatSet {
  ChatSet({
    String? name,
    String? value,
    String? setId,}){
    _name = name;
    _value = value;
    _setId = setId;
  }

  ChatSet.fromJson(dynamic json) {
    _name = json['name'];
    _value = json['value'];
    _setId = json['set_id'];
  }
  String? _name;
  String? _value;
  String? _setId;
  ChatSet copyWith({  String? name,
    String? value,
    String? setId,
  }) => ChatSet(  name: name ?? _name,
    value: value ?? _value,
    setId: setId ?? _setId,
  );
  String? get name => _name;
  String? get value => _value;
  String? get setId => _setId;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['name'] = _name;
    map['value'] = _value;
    map['set_id'] = _setId;
    return map;
  }
}