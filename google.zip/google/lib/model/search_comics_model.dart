import 'package:iaimei/model/comics_item_model.dart';

/// total : "69"
/// list : [{"id":8,"title":"任何小姐","description":"残酷现实的解决师化身为任何人的暗黑英雄","category_id":10,"thumb":"/new/ads/20220215/2022021516401844248.jpeg","update_time":"周六","is_type":0,"refresh_at":"2022-03-22 13:23:31"},{"id":12487,"title":"[神代竜] 大小姐的色女傭事件(お嬢様のメイド事情) (中文)","description":"","category_id":0,"thumb":"/new/ads/20220215/2022021516401844248.jpeg","update_time":"完结","is_type":0,"refresh_at":"2022-03-22 13:23:31"}]

class SearchComicsModel {
  SearchComicsModel({
    String? total,
    List<ComicsItemModel>? list,
  }) {
    _total = total;
    _list = list;
  }

  SearchComicsModel.fromJson(dynamic json) {
    _total = json['total'];
    if (json['list'] != null) {
      _list = [];
      json['list'].forEach((v) {
        _list?.add(ComicsItemModel.fromJson(v));
      });
    }
  }

  String? _total;
  List<ComicsItemModel>? _list;

  SearchComicsModel copyWith({
    String? total,
    List<ComicsItemModel>? list,
  }) =>
      SearchComicsModel(
        total: total ?? _total,
        list: list ?? _list,
      );

  String? get total => _total;

  List<ComicsItemModel>? get list => _list;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['total'] = _total;
    if (_list != null) {
      map['list'] = _list?.map((v) => v.toJson()).toList();
    }
    return map;
  }
}
