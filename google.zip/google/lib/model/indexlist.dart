import 'package:iaimei/model/ads_model.dart';

class HomeModel {
  List<AdsModel> ads = [];
  List<AdsModel> adsNext = [];
  List<Menu> menu = [];
  HomeModel();
  HomeModel.fromJson(Map<String, dynamic> json) {
    ads = json["ads"] == null
        ? []
        : List<AdsModel>.from(json["ads"].map((x) => AdsModel.fromJson(x)));
    adsNext = json["ads_next"] == null
        ? []
        : List<AdsModel>.from(
            json["ads_next"].map((x) => AdsModel.fromJson(x)));
    menu = json["menu"] == null
        ? []
        : List<Menu>.from(json["menu"].map((x) => Menu.fromJson(x)));
  }

  Map<String, dynamic> toJson() => {
        "ads": List<dynamic>.from(ads.map((x) => x.toJson())),
        "ads_next": List<dynamic>.from(adsNext.map((x) => x.toJson())),
        "menu": List<dynamic>.from(menu.map((x) => x.toJson())),
      };
}

class Menu {
  int id = 0;
  String name = '';
  String type = '';
  String value = '';
  int sort = 0;
  int pid = 0;
  String subName = '';
  String iconFull = '';

  Menu();

  Menu.fromJson(Map<String, dynamic> json) {
    id = json["id"] ?? 0;
    name = json["name"] ?? '';
    type = json["type"] ?? '';
    value = json["value"] ?? '';
    sort = json["sort"] ?? 0;
    pid = json["pid"] ?? 0;
    subName = json["sub_name"] ?? '';
    iconFull = json["icon_full"] ?? '';
  }

  Map<String, dynamic> toJson() => {
        "id": id,
        "name": name,
        "type": type,
        "value": value,
        "sort": sort,
        "pid": pid,
        "sub_name": subName,
        "icon_full": iconFull,
      };
}
