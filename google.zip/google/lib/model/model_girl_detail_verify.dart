// To parse this JSON data, do
//
//     final modelGirlDetailVerify = modelGirlDetailVerifyFromJson(jsonString);

import 'dart:convert';

ModelGirlDetailVerify modelGirlDetailVerifyFromJson(String str) =>
    ModelGirlDetailVerify.fromJson(json.decode(str));

String modelGirlDetailVerifyToJson(ModelGirlDetailVerify data) =>
    json.encode(data.toJson());

class ModelGirlDetailVerify {
  ModelGirlDetailVerify({
    this.data,
    this.status,
    this.msg,
    this.crypt,
    this.isVv,
    this.needLogin,
    this.isLogin,
  });

  Data? data;
  int? status;
  String? msg;
  bool? crypt;
  bool? isVv;
  bool? needLogin;
  bool? isLogin;

  factory ModelGirlDetailVerify.fromJson(Map<String, dynamic> json) =>
      ModelGirlDetailVerify(
        data: Data.fromJson(json["data"]),
        status: json["status"],
        msg: json["msg"],
        crypt: json["crypt"],
        isVv: json["isVV"],
        needLogin: json["needLogin"],
        isLogin: json["isLogin"],
      );

  Map<String, dynamic> toJson() => {
        "data": data?.toJson(),
        "status": status,
        "msg": msg,
        "crypt": crypt,
        "isVV": isVv,
        "needLogin": needLogin,
        "isLogin": isLogin,
      };
}

class Data {
  Data({
    this.id,
    this.infoId,
    this.content,
    this.ipStr,
    this.cityName,
    this.status,
    this.viewNum,
    this.createdAt,
    this.statusStr,
    this.createStr,
    this.imagesFull,
    this.isVideo,
    this.playUrl,
  });

  int? id;
  int? infoId;
  String? content;
  String? ipStr;
  String? cityName;
  int? status;
  int? viewNum;
  int? createdAt;
  String? statusStr;
  DateTime? createStr;
  List<ImagesFull>? imagesFull;
  int? isVideo;
  String? playUrl;

  factory Data.fromJson(Map<String, dynamic> json) => Data(
        id: json["id"],
        infoId: json["info_id"],
        content: json["content"],
        ipStr: json["ip_str"],
        cityName: json["city_name"],
        status: json["status"],
        viewNum: json["view_num"],
        createdAt: json["created_at"],
        statusStr: json["status_str"],
        createStr: DateTime.parse(json["create_str"]),
        imagesFull: List<ImagesFull>.from(
            json["images_full"].map((x) => ImagesFull.fromJson(x))),
        isVideo: json["is_video"],
        playUrl: json["play_url"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "info_id": infoId,
        "content": content,
        "ip_str": ipStr,
        "city_name": cityName,
        "status": status,
        "view_num": viewNum,
        "created_at": createdAt,
        "status_str": statusStr,
        "create_str": createStr?.toIso8601String(),
        "images_full": List<dynamic>.from(imagesFull!.map((x) => x.toJson())),
        "is_video": isVideo,
        "play_url": playUrl,
      };
}

class ImagesFull {
  ImagesFull({
    this.url,
    this.width,
    this.height,
  });

  String? url;
  int? width;
  int? height;

  factory ImagesFull.fromJson(Map<String, dynamic> json) => ImagesFull(
        url: json["url"],
        width: json["width"],
        height: json["height"],
      );

  Map<String, dynamic> toJson() => {
        "url": url,
        "width": width,
        "height": height,
      };
}
