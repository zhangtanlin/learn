import 'package:iaimei/model/unlock_info_model.dart';

class AtlasItemModel {
  AtlasItemModel({
      int? id, 
      String? title, 
      String? desc, 
      String? thumb, 
      int? categoryId, 
      String? tags, 
      int? isType, 
      int? viewCount, 
      int? favorites, 
      int? viewMoney, 
      String? refreshAt, 
      int? recommend, 
      int? coins, 
      int? status, 
      String? thumbFull, 
      int? isPay, 
      UnlockInfoModel? payData,}){
    _id = id;
    _title = title;
    _desc = desc;
    _thumb = thumb;
    _categoryId = categoryId;
    _tags = tags;
    _isType = isType;
    _viewCount = viewCount;
    _favorites = favorites;
    _viewMoney = viewMoney;
    _refreshAt = refreshAt;
    _recommend = recommend;
    _coins = coins;
    _status = status;
    _thumbFull = thumbFull;
    _isPay = isPay;
    _payData = payData;
}

  AtlasItemModel.fromJson(dynamic json) {
    _id = json['id'];
    _title = json['title'];
    _desc = json['desc'];
    _thumb = json['thumb'];
    _categoryId = json['category_id'];
    _tags = json['tags'];
    _isType = json['is_type'];
    _viewCount = json['view_count'];
    _favorites = json['favorites'];
    _viewMoney = json['view_money'];
    _refreshAt = json['refresh_at'];
    _recommend = json['recommend'];
    _coins = json['coins'];
    _status = json['status'];
    _thumbFull = json['thumb_full'];
    _isPay = json['is_pay'];
    _payData = json['pay_data'];
  }
  int? _id;
  String? _title;
  String? _desc;
  String? _thumb;
  int? _categoryId;
  String? _tags;
  int? _isType;
  int? _viewCount;
  int? _favorites;
  int? _viewMoney;
  String? _refreshAt;
  int? _recommend;
  int? _coins;
  int? _status;
  String? _thumbFull;
  int? _isPay;
  UnlockInfoModel? _payData;
AtlasItemModel copyWith({  int? id,
  String? title,
  String? desc,
  String? thumb,
  int? categoryId,
  String? tags,
  int? isType,
  int? viewCount,
  int? favorites,
  int? viewMoney,
  String? refreshAt,
  int? recommend,
  int? coins,
  int? status,
  String? thumbFull,
  int? isPay,
  UnlockInfoModel? payData,
}) => AtlasItemModel(  id: id ?? _id,
  title: title ?? _title,
  desc: desc ?? _desc,
  thumb: thumb ?? _thumb,
  categoryId: categoryId ?? _categoryId,
  tags: tags ?? _tags,
  isType: isType ?? _isType,
  viewCount: viewCount ?? _viewCount,
  favorites: favorites ?? _favorites,
  viewMoney: viewMoney ?? _viewMoney,
  refreshAt: refreshAt ?? _refreshAt,
  recommend: recommend ?? _recommend,
  coins: coins ?? _coins,
  status: status ?? _status,
  thumbFull: thumbFull ?? _thumbFull,
  isPay: isPay ?? _isPay,
  payData: payData ?? _payData,
);
  int? get id => _id;
  String? get title => _title;
  String? get desc => _desc;
  String? get thumb => _thumb;
  int? get categoryId => _categoryId;
  String? get tags => _tags;
  int? get isType => _isType;
  int? get viewCount => _viewCount;
  int? get favorites => _favorites;
  int? get viewMoney => _viewMoney;
  String? get refreshAt => _refreshAt;
  int? get recommend => _recommend;
  int? get coins => _coins;
  int? get status => _status;
  String? get thumbFull => _thumbFull;
  int? get isPay => _isPay;
  UnlockInfoModel? get payData => _payData;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = _id;
    map['title'] = _title;
    map['desc'] = _desc;
    map['thumb'] = _thumb;
    map['category_id'] = _categoryId;
    map['tags'] = _tags;
    map['is_type'] = _isType;
    map['view_count'] = _viewCount;
    map['favorites'] = _favorites;
    map['view_money'] = _viewMoney;
    map['refresh_at'] = _refreshAt;
    map['recommend'] = _recommend;
    map['coins'] = _coins;
    map['status'] = _status;
    map['thumb_full'] = _thumbFull;
    map['is_pay'] = _isPay;
    map['pay_data'] = _payData;
    return map;
  }

}