import 'package:iaimei/model/unlock_info_model.dart';

import 'chat_set.dart';

class ChatItemModel {
  ChatItemModel({
    int? id,
    int? uid,
    String? title,
    int? type,
    String? thumb,
    int? girlAge,
    int? girlHeight,
    int? girlWeight,
    String? girlCup,
    String? girlPrice,
    String? girlServiceType,
    String? girlBusinessHours,
    String? girlPics,
    String? desc,
    int? buyOriginalPrice,
    int? buyPrice,
    int? buyNum,
    String? address,
    int? status,
    String? createdAt,
    String? updatedAt,
    int? isRecommed,
    String? m3u8,
    String? packageSet,
    String? typeStr,
    String? statusStr,
    String? thumbUrl,
    List<String>? girlPicsUrl,
    String? isRecommedStr,
    int? isLike,
    int? isPay,
    UnlockInfoModel? payData,
    String? m3u8Full,
    List<ChatSet>? chatset,
  }) {
    _id = id;
    _uid = uid;
    _title = title;
    _type = type;
    _thumb = thumb;
    _girlAge = girlAge;
    _girlHeight = girlHeight;
    _girlWeight = girlWeight;
    _girlCup = girlCup;
    _girlPrice = girlPrice;
    _girlServiceType = girlServiceType;
    _girlBusinessHours = girlBusinessHours;
    _girlPics = girlPics;
    _desc = desc;
    _buyOriginalPrice = buyOriginalPrice;
    _buyPrice = buyPrice;
    _buyNum = buyNum;
    _address = address;
    _status = status;
    _createdAt = createdAt;
    _updatedAt = updatedAt;
    _isRecommed = isRecommed;
    _m3u8 = m3u8;
    _packageSet = packageSet;
    _typeStr = typeStr;
    _statusStr = statusStr;
    _thumbUrl = thumbUrl;
    _girlPicsUrl = girlPicsUrl;
    _isRecommedStr = isRecommedStr;
    _isLike = isLike;
    _isPay = isPay;
    _payData = payData;
    _m3u8Full = m3u8Full;
    _chatset = chatset;
  }

  ChatItemModel.fromJson(dynamic json) {
    _id = json['id'];
    _uid = json['uid'];
    _title = json['title'];
    _type = json['type'];
    _thumb = json['thumb'];
    _girlAge = json['girl_age'];
    _girlHeight = json['girl_height'];
    _girlWeight = json['girl_weight'];
    _girlCup = json['girl_cup'];
    _girlPrice = json['girl_price'];
    _girlServiceType = json['girl_service_type'];
    _girlBusinessHours = json['girl_business_hours'];
    _girlPics = json['girl_pics'];
    _desc = json['desc'];
    _buyOriginalPrice = json['buy_original_price'];
    _buyPrice = json['buy_price'];
    _buyNum = json['buy_num'];
    _address = json['address'];
    _status = json['status'];
    _createdAt = json['created_at'];
    _updatedAt = json['updated_at'];
    _isRecommed = json['is_recommed'];
    _m3u8 = json['m3u8'];
    _packageSet = json['package_set'];
    _typeStr = json['type_str'];
    _statusStr = json['status_str'];
    _thumbUrl = json['thumb_url'];
    _girlPicsUrl = json['girl_pics_url'] != null
        ? json['girl_pics_url'].cast<String>()
        : [];
    _isRecommedStr = json['is_recommed_str'];
    _isLike = json['is_like'];
    _isPay = json['is_pay'];
    _payData = json['pay_data'];
    _m3u8Full = json['m3u8_full'];
    if (json['chatset'] != null) {
      _chatset = [];
      json['chatset'].forEach((v) {
        _chatset?.add(ChatSet.fromJson(v));
      });
    }
  }

  int? _id;
  int? _uid;
  String? _title;
  int? _type;
  String? _thumb;
  int? _girlAge;
  int? _girlHeight;
  int? _girlWeight;
  String? _girlCup;
  String? _girlPrice;
  String? _girlServiceType;
  String? _girlBusinessHours;
  String? _girlPics;
  String? _desc;
  int? _buyOriginalPrice;
  int? _buyPrice;
  int? _buyNum;
  String? _address;
  int? _status;
  String? _createdAt;
  String? _updatedAt;
  int? _isRecommed;
  String? _m3u8;
  String? _packageSet;
  String? _typeStr;
  String? _statusStr;
  String? _thumbUrl;
  List<String>? _girlPicsUrl;
  String? _isRecommedStr;
  int? _isLike;
  int? _isPay;
  UnlockInfoModel? _payData;
  String? _m3u8Full;
  List<ChatSet>? _chatset;

  ChatItemModel copyWith({
    int? id,
    int? uid,
    String? title,
    int? type,
    String? thumb,
    int? girlAge,
    int? girlHeight,
    int? girlWeight,
    String? girlCup,
    String? girlPrice,
    String? girlServiceType,
    String? girlBusinessHours,
    String? girlPics,
    String? desc,
    int? buyOriginalPrice,
    int? buyPrice,
    int? buyNum,
    String? address,
    int? status,
    String? createdAt,
    String? updatedAt,
    int? isRecommed,
    String? m3u8,
    String? packageSet,
    String? typeStr,
    String? statusStr,
    String? thumbUrl,
    List<String>? girlPicsUrl,
    String? isRecommedStr,
    int? isLike,
    int? isPay,
    UnlockInfoModel? payData,
    String? m3u8Full,
    List<ChatSet>? chatset,
  }) =>
      ChatItemModel(
        id: id ?? _id,
        uid: uid ?? _uid,
        title: title ?? _title,
        type: type ?? _type,
        thumb: thumb ?? _thumb,
        girlAge: girlAge ?? _girlAge,
        girlHeight: girlHeight ?? _girlHeight,
        girlWeight: girlWeight ?? _girlWeight,
        girlCup: girlCup ?? _girlCup,
        girlPrice: girlPrice ?? _girlPrice,
        girlServiceType: girlServiceType ?? _girlServiceType,
        girlBusinessHours: girlBusinessHours ?? _girlBusinessHours,
        girlPics: girlPics ?? _girlPics,
        desc: desc ?? _desc,
        buyOriginalPrice: buyOriginalPrice ?? _buyOriginalPrice,
        buyPrice: buyPrice ?? _buyPrice,
        buyNum: buyNum ?? _buyNum,
        address: address ?? _address,
        status: status ?? _status,
        createdAt: createdAt ?? _createdAt,
        updatedAt: updatedAt ?? _updatedAt,
        isRecommed: isRecommed ?? _isRecommed,
        m3u8: m3u8 ?? _m3u8,
        packageSet: packageSet ?? _packageSet,
        typeStr: typeStr ?? _typeStr,
        statusStr: statusStr ?? _statusStr,
        thumbUrl: thumbUrl ?? _thumbUrl,
        girlPicsUrl: girlPicsUrl ?? _girlPicsUrl,
        isRecommedStr: isRecommedStr ?? _isRecommedStr,
        isLike: isLike ?? _isLike,
        isPay: isPay ?? _isPay,
        payData: payData ?? _payData,
        m3u8Full: m3u8Full ?? _m3u8Full,
        chatset: chatset ?? _chatset,
      );

  int? get id => _id;

  int? get uid => _uid;

  String? get title => _title;

  int? get type => _type;

  String? get thumb => _thumb;

  int? get girlAge => _girlAge;

  int? get girlHeight => _girlHeight;

  int? get girlWeight => _girlWeight;

  String? get girlCup => _girlCup;

  String? get girlPrice => _girlPrice;

  String? get girlServiceType => _girlServiceType;

  String? get girlBusinessHours => _girlBusinessHours;

  String? get girlPics => _girlPics;

  String? get desc => _desc;

  int? get buyOriginalPrice => _buyOriginalPrice;

  int? get buyPrice => _buyPrice;

  int? get buyNum => _buyNum;

  String? get address => _address;

  int? get status => _status;

  String? get createdAt => _createdAt;

  String? get updatedAt => _updatedAt;

  int? get isRecommed => _isRecommed;

  String? get m3u8 => _m3u8;

  String? get packageSet => _packageSet;

  String? get typeStr => _typeStr;

  String? get statusStr => _statusStr;

  String? get thumbUrl => _thumbUrl;

  List<String>? get girlPicsUrl => _girlPicsUrl;

  String? get isRecommedStr => _isRecommedStr;

  int? get isLike => _isLike;

  int? get isPay => _isPay;

  UnlockInfoModel? get payData => _payData;

  String? get m3u8Full => _m3u8Full;

  List<ChatSet>? get chatset => _chatset;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = _id;
    map['uid'] = _uid;
    map['title'] = _title;
    map['type'] = _type;
    map['thumb'] = _thumb;
    map['girl_age'] = _girlAge;
    map['girl_height'] = _girlHeight;
    map['girl_weight'] = _girlWeight;
    map['girl_cup'] = _girlCup;
    map['girl_price'] = _girlPrice;
    map['girl_service_type'] = _girlServiceType;
    map['girl_business_hours'] = _girlBusinessHours;
    map['girl_pics'] = _girlPics;
    map['desc'] = _desc;
    map['buy_original_price'] = _buyOriginalPrice;
    map['buy_price'] = _buyPrice;
    map['buy_num'] = _buyNum;
    map['address'] = _address;
    map['status'] = _status;
    map['created_at'] = _createdAt;
    map['updated_at'] = _updatedAt;
    map['is_recommed'] = _isRecommed;
    map['m3u8'] = _m3u8;
    map['package_set'] = _packageSet;
    map['type_str'] = _typeStr;
    map['status_str'] = _statusStr;
    map['thumb_url'] = _thumbUrl;
    map['girl_pics_url'] = _girlPicsUrl;
    map['is_recommed_str'] = _isRecommedStr;
    map['is_like'] = _isLike;
    map['is_pay'] = _isPay;
    map['pay_data'] = _payData;
    map['m3u8_full'] = _m3u8Full;
    if (_chatset != null) {
      map['chatset'] = _chatset?.map((v) => v.toJson()).toList();
    }
    return map;
  }
}