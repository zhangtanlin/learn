import 'dart:convert';

PictureAtlas pictureAtlasFromJson(String str) =>
    PictureAtlas.fromJson(json.decode(str));

String pictureAtlasToJson(PictureAtlas data) => json.encode(data.toJson());

class PictureAtlas {
  PictureAtlas({
    required this.data,
    required this.status,
    required this.msg,
    required this.crypt,
    required this.isVv,
    required this.needLogin,
    required this.isLogin,
  });

  Data data;
  int status;
  String msg;
  bool crypt;
  bool isVv;
  bool needLogin;
  bool isLogin;

  factory PictureAtlas.fromJson(Map<String, dynamic> json) => PictureAtlas(
        data: Data.fromJson(json["data"]),
        status: json["status"],
        msg: json["msg"],
        crypt: json["crypt"],
        isVv: json["isVV"],
        needLogin: json["needLogin"],
        isLogin: json["isLogin"],
      );

  Map<String, dynamic> toJson() => {
        "data": data.toJson(),
        "status": status,
        "msg": msg,
        "crypt": crypt,
        "isVV": isVv,
        "needLogin": needLogin,
        "isLogin": isLogin,
      };
}

class Data {
  Data({
    required this.ads,
    required this.types,
    required this.categoryList,
    required this.categoryArr,
  });

  List<dynamic> ads;
  List<Type> types;
  List<Category> categoryList;
  List<Category> categoryArr;

  factory Data.fromJson(Map<String, dynamic> json) => Data(
        ads: List<dynamic>.from(json["ads"].map((x) => x)),
        types: List<Type>.from(json["types"].map((x) => Type.fromJson(x))),
        categoryList: List<Category>.from(
            json["category_list"].map((x) => Category.fromJson(x))),
        categoryArr: List<Category>.from(
            json["category_arr"].map((x) => Category.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "ads": List<dynamic>.from(ads.map((x) => x)),
        "types": List<dynamic>.from(types.map((x) => x.toJson())),
        "category_list":
            List<dynamic>.from(categoryList.map((x) => x.toJson())),
        "category_arr": List<dynamic>.from(categoryArr.map((x) => x.toJson())),
      };
}

class Category {
  Category({
    required this.id,
    required this.pid,
    required this.name,
    required this.sort,
    required this.status,
    required this.refreshTime,
    required this.clickNum,
    required this.list,
  });

  int id;
  int pid;
  String name;
  int sort;
  int status;
  DateTime refreshTime;
  int clickNum;
  List<ListElement> list;

  factory Category.fromJson(Map<String, dynamic> json) => Category(
        id: json["id"],
        pid: json["pid"],
        name: json["name"],
        sort: json["sort"],
        status: json["status"],
        refreshTime: DateTime.parse(json["refresh_time"]),
        clickNum: json["click_num"],
        list: json["list"] == null
            ? []
            : List<ListElement>.from(
                json["list"].map((x) => ListElement.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "pid": pid,
        "name": name,
        "sort": sort,
        "status": status,
        "refresh_time": refreshTime.toIso8601String(),
        "click_num": clickNum,
        "list":
            list == null ? [] : List<dynamic>.from(list.map((x) => x.toJson())),
      };
}

class ListElement {
  ListElement({
    required this.listId,
    required this.id,
    required this.aff,
    required this.title,
    required this.desc,
    required this.author,
    required this.thumb,
    required this.tags,
    required this.categoryId,
    required this.isFree,
    required this.viewsCount,
    required this.favorites,
    required this.likesCount,
    required this.viewMoney,
    required this.downloadMoney,
    required this.freeTime,
    required this.recommend,
    required this.status,
    required this.createdAt,
    required this.updatedAt,
  });

  int listId;
  dynamic id;
  int aff;
  String title;
  dynamic desc;
  String author;
  String thumb;
  String tags;
  int categoryId;
  int isFree;
  int viewsCount;
  int favorites;
  int likesCount;
  int viewMoney;
  int downloadMoney;
  int freeTime;
  int recommend;
  int status;
  DateTime createdAt;
  DateTime updatedAt;

  factory ListElement.fromJson(Map<String, dynamic> json) => ListElement(
        listId: json["id"],
        id: json["_id"],
        aff: json["aff"],
        title: json["title"],
        desc: json["desc"],
        author: json["author"],
        thumb: json["thumb"],
        tags: json["tags"],
        categoryId: json["category_id"],
        isFree: json["is_free"],
        viewsCount: json["views_count"],
        favorites: json["favorites"],
        likesCount: json["likes_count"],
        viewMoney: json["view_money"],
        downloadMoney: json["download_money"],
        freeTime: json["free_time"],
        recommend: json["recommend"],
        status: json["status"],
        createdAt: DateTime.parse(json["created_at"]),
        updatedAt: DateTime.parse(json["updated_at"]),
      );

  Map<String, dynamic> toJson() => {
        "id": listId,
        "_id": id,
        "aff": aff,
        "title": title,
        "desc": desc,
        "author": author,
        "thumb": thumb,
        "tags": tags,
        "category_id": categoryId,
        "is_free": isFree,
        "views_count": viewsCount,
        "favorites": favorites,
        "likes_count": likesCount,
        "view_money": viewMoney,
        "download_money": downloadMoney,
        "free_time": freeTime,
        "recommend": recommend,
        "status": status,
        "created_at": createdAt.toIso8601String(),
        "updated_at": updatedAt.toIso8601String(),
      };
}

class Type {
  Type({
    required this.id,
    required this.name,
  });

  int id;
  String name;

  factory Type.fromJson(Map<String, dynamic> json) => Type(
        id: json["id"],
        name: json["name"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "name": name,
      };
}
