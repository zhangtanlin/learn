import 'package:iaimei/model/comics_catalog_item_model.dart';

/// detail : {"id":22,"title":"妻子的情人","description":"我的妻子有了炮友!对我性冷淡的妻子竟浑身赤裸勾引外卖小哥……!!!!要离婚? 不! 我也找一个炮友就好了~","category_id":9,"uid":0,"bg_thumb":"","thumb":"/images/mh/data/cover/22.jpg","favorites":11,"view_money":0,"tags":"剧情","status":1,"update_time":"周一","recommend":0,"obtained":1,"is_type":0,"refresh_at":"2022-04-28 04:22:19","view_count":3382503,"coins":0,"thumb_full":"https://new.tthykps.cn/images/mh/data/cover/22.jpg","bg_thumb_full":"https://new.tthykps.cn/images/mh/data/cover/22.jpg","is_pay":0,"update_info":"连载中·周一更新"}
/// comics_series : [{"id":1028,"pid":22,"episode":1,"title":"1","is_free":1,"pay_data":{"resource_coins":"0","resource_g_coins":"0","resource_type":1,"is_vip":false,"is_pay":0,"free":0,"user_coins":"18320.00","user_g_coins":"19980","user_times":"0","pay_way":null}}]
/// total : 101

class ComicsDetailModel {
  ComicsDetailModel({
    Detail? detail,
    List<ComicsCatalogItemModel>? comicsSeries,
    int? total,
  }) {
    _detail = detail;
    _comicsSeries = comicsSeries;
    _total = total;
  }

  ComicsDetailModel.fromJson(dynamic json) {
    _detail = json['detail'] != null ? Detail.fromJson(json['detail']) : null;
    if (json['comics_series'] != null) {
      _comicsSeries = [];
      json['comics_series'].forEach((v) {
        _comicsSeries?.add(ComicsCatalogItemModel.fromJson(v));
      });
    }
    _total = json['total'];
  }

  Detail? _detail;
  List<ComicsCatalogItemModel>? _comicsSeries;
  int? _total;

  ComicsDetailModel copyWith({
    Detail? detail,
    List<ComicsCatalogItemModel>? comicsSeries,
    int? total,
  }) =>
      ComicsDetailModel(
        detail: detail ?? _detail,
        comicsSeries: comicsSeries ?? _comicsSeries,
        total: total ?? _total,
      );

  Detail? get detail => _detail;

  List<ComicsCatalogItemModel>? get comicsSeries => _comicsSeries;

  int? get total => _total;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    if (_detail != null) {
      map['detail'] = _detail?.toJson();
    }
    if (_comicsSeries != null) {
      map['comics_series'] = _comicsSeries?.map((v) => v.toJson()).toList();
    }
    map['total'] = _total;
    return map;
  }
}

class Detail {
  Detail({
    int? id,
    String? title,
    String? description,
    int? categoryId,
    int? uid,
    String? bgThumb,
    String? thumb,
    int? favorites,
    int? viewMoney,
    String? tags,
    int? status,
    String? updateTime,
    int? recommend,
    int? obtained,
    int? isType,
    String? refreshAt,
    int? viewCount,
    int? coins,
    String? thumbFull,
    String? bgThumbFull,
    int? isPay,
    String? updateInfo,
  }) {
    _id = id;
    _title = title;
    _description = description;
    _categoryId = categoryId;
    _uid = uid;
    _bgThumb = bgThumb;
    _thumb = thumb;
    _favorites = favorites;
    _viewMoney = viewMoney;
    _tags = tags;
    _status = status;
    _updateTime = updateTime;
    _recommend = recommend;
    _obtained = obtained;
    _isType = isType;
    _refreshAt = refreshAt;
    _viewCount = viewCount;
    _coins = coins;
    _thumbFull = thumbFull;
    _bgThumbFull = bgThumbFull;
    _isPay = isPay;
    _updateInfo = updateInfo;
  }

  Detail.fromJson(dynamic json) {
    _id = json['id'];
    _title = json['title'];
    _description = json['description'];
    _categoryId = json['category_id'];
    _uid = json['uid'];
    _bgThumb = json['bg_thumb'];
    _thumb = json['thumb'];
    _favorites = json['favorites'];
    _viewMoney = json['view_money'];
    _tags = json['tags'];
    _status = json['status'];
    _updateTime = json['update_time'];
    _recommend = json['recommend'];
    _obtained = json['obtained'];
    _isType = json['is_type'];
    _refreshAt = json['refresh_at'];
    _viewCount = json['view_count'];
    _coins = json['coins'];
    _thumbFull = json['thumb_full'];
    _bgThumbFull = json['bg_thumb_full'];
    _isPay = json['is_pay'];
    _updateInfo = json['update_info'];
  }

  int? _id;
  String? _title;
  String? _description;
  int? _categoryId;
  int? _uid;
  String? _bgThumb;
  String? _thumb;
  int? _favorites;
  int? _viewMoney;
  String? _tags;
  int? _status;
  String? _updateTime;
  int? _recommend;
  int? _obtained;
  int? _isType;
  String? _refreshAt;
  int? _viewCount;
  int? _coins;
  String? _thumbFull;
  String? _bgThumbFull;
  int? _isPay;
  String? _updateInfo;

  Detail copyWith({
    int? id,
    String? title,
    String? description,
    int? categoryId,
    int? uid,
    String? bgThumb,
    String? thumb,
    int? favorites,
    int? viewMoney,
    String? tags,
    int? status,
    String? updateTime,
    int? recommend,
    int? obtained,
    int? isType,
    String? refreshAt,
    int? viewCount,
    int? coins,
    String? thumbFull,
    String? bgThumbFull,
    int? isPay,
    String? updateInfo,
  }) =>
      Detail(
        id: id ?? _id,
        title: title ?? _title,
        description: description ?? _description,
        categoryId: categoryId ?? _categoryId,
        uid: uid ?? _uid,
        bgThumb: bgThumb ?? _bgThumb,
        thumb: thumb ?? _thumb,
        favorites: favorites ?? _favorites,
        viewMoney: viewMoney ?? _viewMoney,
        tags: tags ?? _tags,
        status: status ?? _status,
        updateTime: updateTime ?? _updateTime,
        recommend: recommend ?? _recommend,
        obtained: obtained ?? _obtained,
        isType: isType ?? _isType,
        refreshAt: refreshAt ?? _refreshAt,
        viewCount: viewCount ?? _viewCount,
        coins: coins ?? _coins,
        thumbFull: thumbFull ?? _thumbFull,
        bgThumbFull: bgThumbFull ?? _bgThumbFull,
        isPay: isPay ?? _isPay,
        updateInfo: updateInfo ?? _updateInfo,
      );

  int? get id => _id;

  String? get title => _title;

  String? get description => _description;

  int? get categoryId => _categoryId;

  int? get uid => _uid;

  String? get bgThumb => _bgThumb;

  String? get thumb => _thumb;

  int? get favorites => _favorites;

  int? get viewMoney => _viewMoney;

  String? get tags => _tags;

  int? get status => _status;

  String? get updateTime => _updateTime;

  int? get recommend => _recommend;

  int? get obtained => _obtained;

  int? get isType => _isType;

  String? get refreshAt => _refreshAt;

  int? get viewCount => _viewCount;

  int? get coins => _coins;

  String? get thumbFull => _thumbFull;

  String? get bgThumbFull => _bgThumbFull;

  int? get isPay => _isPay;

  String? get updateInfo => _updateInfo;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = _id;
    map['title'] = _title;
    map['description'] = _description;
    map['category_id'] = _categoryId;
    map['uid'] = _uid;
    map['bg_thumb'] = _bgThumb;
    map['thumb'] = _thumb;
    map['favorites'] = _favorites;
    map['view_money'] = _viewMoney;
    map['tags'] = _tags;
    map['status'] = _status;
    map['update_time'] = _updateTime;
    map['recommend'] = _recommend;
    map['obtained'] = _obtained;
    map['is_type'] = _isType;
    map['refresh_at'] = _refreshAt;
    map['view_count'] = _viewCount;
    map['coins'] = _coins;
    map['thumb_full'] = _thumbFull;
    map['bg_thumb_full'] = _bgThumbFull;
    map['is_pay'] = _isPay;
    map['update_info'] = _updateInfo;
    return map;
  }
}
