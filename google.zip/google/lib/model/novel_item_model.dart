import 'package:iaimei/model/unlock_info_model.dart';

/// id : 3305
/// title : "隔壁阿姨"
/// desc : "隔壁阿姨"
/// thumb : "https://new.tthykps.cn/new/upload/20210415/2021041515540265298.jpeg"
/// bg_thumb : ""
/// category_id : 1
/// is_type : 1
/// view_count : 1
/// favorites : 1
/// view_money : 0
/// download_money : 0
/// free_time : 0
/// recommend : 1
/// type : 1
/// status : 1
/// refresh_at:"2021-12-15 21:23:55",
/// tags : "激情,高清,自拍作品"
/// update_time : "完结",
/// update_status: 1,
/// coins: 100,
/// img_url_full: "https://new.tthykps.cn/new/upload/20210415/2021041515540265298.jpeg",
/// bg_thumb_full: '',
/// is_pay': '',
/// pay_data:
/// created_at : "2022-02-15 16:40:31"
/// updated_at : "2022-02-15 16:41:42"

class NovelItemModel {
  NovelItemModel({
    int? id,
    String? title,
    String? desc,
    String? thumb,
    String? bgThumb,
    int? categoryId,
    int? isType,
    int? viewCount,
    int? favorites,
    int? viewMoney,
    int? downloadMoney,
    int? freeTime,
    int? recommend,
    int? type,
    int? status,
    String? refreshAt,
    // String? createdAt,
    // String? updatedAt,
    String? tags,
    String? updateTime,
    int? updateStatus,
    int? coins,
    int? obtained,
    String? imgUrlFull,
    String? bgThumbFull,
    int? isPay,
    UnlockInfoModel? payData,
  }) {
    _id = id;
    _title = title;
    _desc = desc;
    _thumb = thumb;
    _bgThumb = bgThumb;
    _categoryId = categoryId;
    _isType = isType;
    _viewCount = viewCount;
    _favorites = favorites;
    _viewMoney = viewMoney;
    _downloadMoney = downloadMoney;
    _freeTime = freeTime;
    _recommend = recommend;
    _type = type;
    _status = status;
    _refreshAt = refreshAt;
    // _createdAt = createdAt;
    // _updatedAt = updatedAt;
    _tags = tags;
    _updateTime = updateTime;
    _updateStatus = updateStatus;
    _coins = coins;
    _obtained = obtained;
    _imgUrlFull = imgUrlFull;
    _bgThumbFull = bgThumbFull;
    _isPay = isPay;
    _payData = payData;
  }

  NovelItemModel.fromJson(dynamic json) {
    _id = json['id'];
    _title = json['title'];
    _desc = json['desc'];
    _thumb = json['thumb'];
    _bgThumb = json['bg_thumb'];
    _categoryId = json['category_id'];
    _isType = json['is_type'];
    _viewCount = json['view_count'];
    _favorites = json['favorites'];
    _viewMoney = json['view_money'];
    _downloadMoney = json['download_money'];
    _freeTime = json['free_time'];
    _recommend = json['recommend'];
    _type = json['type'];
    _status = json['status'];
    _refreshAt = json['refresh_at'];
    // _createdAt = json['created_at'];
    // _updatedAt = json['updated_at'];
    _tags = json['tags'];
    _updateTime = json["update_time"];
    _updateStatus = json["update_status"];
    _coins = json["coins"];
    _obtained = json['obtained'];
    _imgUrlFull = json["img_url_full"];
    _bgThumbFull = json["bg_thumb_full"];
    _isPay = json["is_pay"];
    if (json["pay_data"] != null) {
      _payData = UnlockInfoModel.fromJson(json["pay_data"]);
    }
  }
  int? _id;
  String? _title;
  String? _desc;
  String? _thumb;
  String? _bgThumb;
  int? _categoryId;
  int? _isType;
  int? _viewCount;
  int? _favorites;
  int? _viewMoney;
  int? _downloadMoney;
  int? _freeTime;
  int? _recommend;
  int? _type;
  int? _status;
  String? _refreshAt;
  // String? _createdAt;
  // String? _updatedAt;
  String? _tags;
  String? _updateTime;
  int? _updateStatus;
  int? _coins;
  int? _obtained;
  String? _imgUrlFull;
  String? _bgThumbFull;
  int? _isPay;
  UnlockInfoModel? _payData;

  NovelItemModel copyWith({
    int? id,
    String? title,
    String? desc,
    String? thumb,
    String? bgThumb,
    int? categoryId,
    int? isType,
    int? viewCount,
    int? favorites,
    int? viewMoney,
    int? downloadMoney,
    int? freeTime,
    int? recommend,
    int? type,
    int? status,
    String? refreshAt,
    // String? createdAt,
    // String? updatedAt,
    String? tags,
    String? updateTime,
    int? updateStatus,
    int? coins,
    int? obtained,
    String? imgUrlFull,
    String? bgThumbFull,
    int? isPay,
    UnlockInfoModel? payData,
  }) =>
      NovelItemModel(
        id: id ?? _id,
        title: title ?? _title,
        desc: desc ?? _desc,
        thumb: thumb ?? _thumb,
        bgThumb: bgThumb ?? _bgThumb,
        categoryId: categoryId ?? _categoryId,
        isType: isType ?? _isType,
        viewCount: viewCount ?? _viewCount,
        favorites: favorites ?? _favorites,
        viewMoney: viewMoney ?? _viewMoney,
        downloadMoney: downloadMoney ?? _downloadMoney,
        freeTime: freeTime ?? _freeTime,
        recommend: recommend ?? _recommend,
        type: type ?? _type,
        status: status ?? _status,
        refreshAt: refreshAt ?? _refreshAt,
        // createdAt: createdAt ?? _createdAt,
        // updatedAt: updatedAt ?? _updatedAt,
        tags: tags ?? _tags,
        updateTime: updateTime ?? _updateTime,
        updateStatus: updateStatus ?? _updateStatus,
        coins: coins ?? _coins,
        obtained: obtained ?? _obtained,
        imgUrlFull: imgUrlFull ?? _imgUrlFull,
        bgThumbFull: bgThumbFull ?? _bgThumbFull,
        isPay: isPay ?? _isPay,
        payData: payData ?? _payData,
      );
  int? get id => _id;
  String? get title => _title;
  String? get desc => _desc;
  String? get thumb => _thumb;
  String? get bgThumb => _bgThumb;
  int? get categoryId => _categoryId;
  int? get isType => _isType;
  int? get viewCount => _viewCount;
  int? get favorites => _favorites;
  int? get viewMoney => _viewMoney;
  int? get downloadMoney => _downloadMoney;
  int? get freeTime => _freeTime;
  int? get recommend => _recommend;
  int? get type => _type;
  int? get status => _status;
  String? get refreshAt => _refreshAt;
  // String? get createdAt => _createdAt;
  // String? get updatedAt => _updatedAt;
  String? get tags => _tags;
  String? get updateTime => _updateTime;
  int? get updateStatus => _updateStatus;
  int? get coins => _coins;
  int? get obtained => _obtained;
  String? get imgUrlFull => _imgUrlFull;
  String? get bgThumbFull => _bgThumbFull;
  int? get isPay => _isPay;
  UnlockInfoModel? get payData => _payData;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = _id;
    map['title'] = _title;
    map['desc'] = _desc;
    map['thumb'] = _thumb;
    map['bg_thumb'] = _bgThumb;
    map['category_id'] = _categoryId;
    map['is_type'] = _isType;
    map['view_count'] = _viewCount;
    map['favorites'] = _favorites;
    map['view_money'] = _viewMoney;
    map['download_money'] = _downloadMoney;
    map['free_time'] = _freeTime;
    map['recommend'] = _recommend;
    map['type'] = _type;
    map['status'] = _status;
    map['refresh_at'] = _refreshAt;
    // map['created_at'] = _createdAt;
    // map['updated_at'] = _updatedAt;
    map['tags'] = _tags;
    map['update_time'] = _updateTime;
    map['update_status'] = _updateStatus;
    map['coins'] = _coins;
    map['obtained'] = _obtained;
    map['img_url_full'] = _imgUrlFull;
    map['bg_thumb_full'] = _bgThumbFull;
    map['is_pay'] = _isPay;
    map['pay_data'] = _payData?.toJson();
    return map;
  }
}
