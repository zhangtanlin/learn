import 'package:iaimei/model/ads_model.dart';
import 'package:iaimei/model/comics_item_model.dart';

/// ads : []
/// datalist : [{"id":15,"pid":8,"name":"韩1系列","sort":100,"status":1,"refresh_time":"2022-03-17 07:13:55","click_num":0,"itemlist":[{"id":67348,"title":"[天外悪十文字 (悪の東丈、ネズミン)] 俺の夏2019 (妖怪ウォッチ) [DL版][63P]","description":"","category_id":15,"thumb":"/new/upload/20211020/2021102007505219525.jpeg","views_count":4,"update_time":"完结"},{"id":67347,"title":"[瓦屋本舗 (瓦屋A太)] 華 巻之八 魂ハ華 (新世紀エヴァンゲリオン) [45P]","description":"","category_id":15,"thumb":"/new/upload/20211020/2021102007472787386.jpeg","views_count":1,"update_time":"完结"},{"id":67346,"title":"[下り坂ガードレール (しらそ)] 駆錬輝晶 クォルタ アメテュス[48P]","description":"","category_id":15,"thumb":"/new/upload/20211020/2021102007435281233.jpeg","views_count":0,"update_time":"完结"}]},{"id":16,"pid":8,"name":"韩2系列","sort":100,"status":1,"refresh_time":"2022-03-17 07:14:08","click_num":0,"itemlist":[{"id":67345,"title":"[月下カグヤ] 弁護士→フタナリ→生配信♥ [DL版][197P]","description":"","category_id":16,"thumb":"/new/upload/20211020/2021102007290114857.jpeg","views_count":3,"update_time":"完结"},{"id":67344,"title":"[仔馬牧場 (ぼに～)] 一夜ちゃんの受難2[55P]","description":"","category_id":16,"thumb":"/new/upload/20211020/2021102007250744384.jpeg","views_count":1,"update_time":"完结"},{"id":67343,"title":"[昭和最終戦線 (はなうな)] 爆乳JKお便女デビュー[50P]","description":"","category_id":16,"thumb":"/new/upload/20211020/2021102007214581116.jpeg","views_count":2,"update_time":"完结"}]}]

class ComicsIndexListModel {
  ComicsIndexListModel({
    List<AdsModel>? ads,
    List<ComicsListModel>? list,
  }) {
    _ads = ads;
    _list = list;
  }

  ComicsIndexListModel.fromJson(dynamic json) {
    if (json['ads'] != null) {
      _ads = [];
      json['ads'].forEach((v) {
        _ads?.add(AdsModel.fromJson(v));
      });
    }
    if (json['list'] != null) {
      _list = [];
      json['list'].forEach((v) {
        _list?.add(ComicsListModel.fromJson(v));
      });
    }
  }

  List<AdsModel>? _ads;
  List<ComicsListModel>? _list;

  List<AdsModel>? get ads => _ads;

  List<ComicsListModel>? get list => _list;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    if (_ads != null) {
      map['ads'] = _ads?.map((v) => v.toJson()).toList();
    }
    if (_list != null) {
      map['list'] = _list?.map((v) => v.toJson()).toList();
    }
    return map;
  }
}

/// id : 15
/// pid : 8
/// name : "韩1系列"
/// sort : 100
/// status : 1
/// refresh_time : "2022-03-17 07:13:55"
/// click_num : 0
/// itemlist : [{"id":67348,"title":"[天外悪十文字 (悪の東丈、ネズミン)] 俺の夏2019 (妖怪ウォッチ) [DL版][63P]","description":"","category_id":15,"thumb":"/new/upload/20211020/2021102007505219525.jpeg","views_count":4,"update_time":"完结"},{"id":67347,"title":"[瓦屋本舗 (瓦屋A太)] 華 巻之八 魂ハ華 (新世紀エヴァンゲリオン) [45P]","description":"","category_id":15,"thumb":"/new/upload/20211020/2021102007472787386.jpeg","views_count":1,"update_time":"完结"},{"id":67346,"title":"[下り坂ガードレール (しらそ)] 駆錬輝晶 クォルタ アメテュス[48P]","description":"","category_id":15,"thumb":"/new/upload/20211020/2021102007435281233.jpeg","views_count":0,"update_time":"完结"}]

class ComicsListModel {
  ComicsListModel({
    int? id,
    int? pid,
    String? name,
    int? sort,
    int? status,
    String? refreshTime,
    int? clickNum,
    List<ComicsItemModel>? list,
  }) {
    _id = id;
    _pid = pid;
    _name = name;
    _sort = sort;
    _status = status;
    _refreshTime = refreshTime;
    _clickNum = clickNum;
    _list = list;
  }

  ComicsListModel.fromJson(dynamic json) {
    _id = json['id'];
    _pid = json['pid'];
    _name = json['name'];
    _sort = json['sort'];
    _status = json['status'];
    _refreshTime = json['refresh_time'];
    _clickNum = json['click_num'];
    if (json['list'] != null) {
      _list = [];
      json['list'].forEach((v) {
        _list?.add(ComicsItemModel.fromJson(v));
      });
    }
  }

  int? _id;
  int? _pid;
  String? _name;
  int? _sort;
  int? _status;
  String? _refreshTime;
  int? _clickNum;
  List<ComicsItemModel>? _list;

  int? get id => _id;

  int? get pid => _pid;

  String? get name => _name;

  int? get sort => _sort;

  int? get status => _status;

  String? get refreshTime => _refreshTime;

  int? get clickNum => _clickNum;

  List<ComicsItemModel>? get list => _list;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = _id;
    map['pid'] = _pid;
    map['name'] = _name;
    map['sort'] = _sort;
    map['status'] = _status;
    map['refresh_time'] = _refreshTime;
    map['click_num'] = _clickNum;
    if (_list != null) {
      map['list'] = _list?.map((v) => v.toJson()).toList();
    }
    return map;
  }
}


