import 'package:iaimei/model/comics_item_model.dart';

class ComicsSeriesModel {
  ComicsSeriesModel({
      List<ComicsItemModel>? list,}){
    _list = list;
}

  ComicsSeriesModel.fromJson(dynamic json) {
    if (json['list'] != null) {
      _list = [];
      json['list'].forEach((v) {
        _list?.add(ComicsItemModel.fromJson(v));
      });
    }
  }
  List<ComicsItemModel>? _list;

  List<ComicsItemModel>? get list => _list;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    if (_list != null) {
      map['list'] = _list?.map((v) => v.toJson()).toList();
    }
    return map;
  }

}