import 'package:iaimei/model/ads_model.dart';

class Config {
  Version version = Version();
  String domainName = '';
  String imgUploadUrl = '';
  String uploadImgKey = '';
  String videoUploadUrl = '';
  String uploadKey = '';
  int watchCount = 0;
  int watchIsFeeCount = 0;
  int timestamp = 0;
  String maintainSwitch = '0';
  String maintainTips = '';
  String tg = '';
  List<AdsModel> adsScreen = <AdsModel>[];
  List<AdsModel> adsPop = <AdsModel>[];
  PlayerCfg playerCfg = PlayerCfg();
  int gapInsertSet = 0;

  Config();
  Config.fromJson(Map<String, dynamic> json) {
    domainName = json["domain_name"] ?? '';
    imgUploadUrl = json["imgUploadUrl"] ?? '';
    uploadImgKey = json["upload_img_key"] ?? '';
    videoUploadUrl = json["videoUploadUrl"] ?? '';
    uploadKey = json["uploadKey"] ?? '';
    watchCount = json["watch_count"] ?? 0;
    watchIsFeeCount = json["watch_is_fee_count"] ?? 0;
    timestamp = json["timestamp"] ?? 0;
    maintainSwitch = json["maintain_switch"] ?? '0';
    maintainTips = json["maintain_tips"] ?? '';
    tg = json["tg"] ?? '';
    gapInsertSet = json["gap_insert_set"] ?? 0;
    
    version = json["version"] != null && json["version"] is Map
        ? Version.fromJson(json["version"])
        : Version();
    adsScreen = json["ads_screen"] != null && json["ads_screen"] is List
        ? json["ads_screen"].map<AdsModel>((x) => AdsModel.fromJson(x)).toList()
        : [];
    adsPop = json["ads_pop"] != null && json["ads_pop"] is List
        ? json["ads_pop"].map<AdsModel>((x) => AdsModel.fromJson(x)).toList()
        : [];
    playerCfg = json["player_cfg"] != null && json["player_cfg"] is Map
        ? PlayerCfg.fromJson(json["player_cfg"])
        : PlayerCfg();

  }

  Map<String, dynamic> toJson() => {
        "version": version.toJson(),
        "domain_name": domainName,
        "imgUploadUrl": imgUploadUrl,
        "upload_img_key": uploadImgKey,
        "videoUploadUrl": videoUploadUrl,
        "uploadKey": uploadKey,
        "watch_count": watchCount,
        "watch_is_fee_count": watchIsFeeCount,
        "timestamp": timestamp,
        "maintain_switch": maintainSwitch,
        "maintain_tips": maintainTips,
        "tg": tg,
        "ads_screen": List<dynamic>.from(adsScreen.map((x) => x.toJson())),
        "ads_pop": List<dynamic>.from(adsPop.map((x) => x.toJson())),
        "player_cfg": playerCfg.toJson(),
        "gap_insert_set": gapInsertSet,
      };
}

class PlayerCfg {
  String xAuth = '';
  String refer = '';
  String dekey = '';
  bool useNew = false;

  PlayerCfg();
  PlayerCfg.fromJson(Map<String, dynamic> json) {
    xAuth = json["x_auth"] ?? '';
    refer = json["refer"] ?? '';
    dekey = json["dekey"] ?? '';
    useNew = json["use_new"] ?? false;
  }

  Map<String, dynamic> toJson() => {
        "x_auth": xAuth,
        "refer": refer,
        "dekey": dekey,
        "use_new": useNew,
      };
}

class Version {
  int id = 0;
  String version = '';
  String type = '';
  String apk = '';
  String tips = '';
  int must = 0;
  String via = '';

  Version();
  Version.fromJson(Map<String, dynamic> json) {
    id = json["id"] ?? 0;
    version = json["version"] ?? '';
    type = json["type"] ?? '';
    apk = json["apk"] ?? '';
    tips = json["tips"] ?? '';
    must = json["must"] ?? 0;
    via = json["via"] ?? '';
  }

  Map<String, dynamic> toJson() => {
        "id": id,
        "version": version,
        "type": type,
        "apk": apk,
        "tips": tips,
        "must": must,
        "via": via,
      };
}
