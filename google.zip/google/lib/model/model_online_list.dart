// To parse this JSON data, do
//
//     final modelOnlineList = modelOnlineListFromJson(jsonString);

import 'dart:convert';

ModelOnlineList modelOnlineListFromJson(String str) =>
    ModelOnlineList.fromJson(json.decode(str));

String modelOnlineListToJson(ModelOnlineList data) =>
    json.encode(data.toJson());

class ModelOnlineList {
  ModelOnlineList({
    this.data,
    this.status,
    this.msg,
    this.crypt,
    this.isVv,
    this.needLogin,
    this.isLogin,
  });

  List<Datum>? data;
  int? status;
  String? msg;
  bool? crypt;
  bool? isVv;
  bool? needLogin;
  bool? isLogin;

  factory ModelOnlineList.fromJson(Map<String, dynamic> json) =>
      ModelOnlineList(
        data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
        status: json["status"],
        msg: json["msg"],
        crypt: json["crypt"],
        isVv: json["isVV"],
        needLogin: json["needLogin"],
        isLogin: json["isLogin"],
      );

  Map<String, dynamic> toJson() => {
        "data": List<dynamic>.from(data!.map((x) => x.toJson())),
        "status": status,
        "msg": msg,
        "crypt": crypt,
        "isVV": isVv,
        "needLogin": needLogin,
        "isLogin": isLogin,
      };
}

class Datum {
  Datum({
    this.id,
    this.content,
    this.thumbFull,
    this.addtimeStr,
    this.status,
    this.uptimeStr,
    this.replyContent,
    this.createdAtStr,
  });

  int? id;
  String? content;
  String? thumbFull;
  String? addtimeStr;
  int? status;
  String? uptimeStr;
  dynamic replyContent;
  String? createdAtStr;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
        id: json["id"],
        content: json["content"],
        thumbFull: json["thumb_full"],
        addtimeStr: json["addtime_str"],
        status: json["status"],
        uptimeStr: json["uptime_str"],
        replyContent: json["reply_content"],
        createdAtStr: json["created_at_str"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "content": content,
        "thumb_full": thumbFull,
        "addtime_str": addtimeStr,
        "status": status,
        "uptime_str": uptimeStr,
        "reply_content": replyContent,
        "created_at_str": createdAtStr,
      };
}
