import 'dart:convert';

import 'package:iaimei/model/video_model.dart';

class TabItemModel {
  int id = 0;
  String name = '';
  String type = '';
  String value = '';
  int sort = 0;
  int pid = 0;
  int isDefault = 0;
  dynamic subName;

  TabItemModel();
  TabItemModel.fromJson(Map<String, dynamic> json) {
    id = json["id"] ?? 0;
    name = json["name"] ?? '';
    type = json["type"] ?? '';
    value = json["value"] ?? '';
    sort = json["sort"] ?? 0;
    pid = json["pid"] ?? 0;
    isDefault = json["is_default"] ?? 0;
    subName = json["sub_name"];
  }

  Map<String, dynamic> toJson() => {
        "id": id,
        "name": name,
        "type": type,
        "value": value,
        "sort": sort,
        "pid": pid,
        "is_default": isDefault,
        "sub_name": subName,
      };
}

class SeriesItemModel {
  int id = 0;
  int itemId = 0;
  String title = '';
  String subTitle = '';
  int showStyle = 0;
  int showMax = 0;
  int number = 0;
  int originalCoins = 0;
  int coins = 0;
  int isPay = 0; // 特价使用
  List<VideoModel> list = [];

  SeriesItemModel();
  SeriesItemModel.fromJson(Map json) {
    id = json['id'] ?? 0;
    itemId = json['item_id'] ?? 0;
    title = json['title'] ?? '';
    subTitle = json['sub_title'] ?? '';
    showStyle = json['show_style'] ?? 0;
    showMax = json['show_max'] ?? 0;
    number = json['number'] ?? 0;
    originalCoins = json['original_coins'] ?? 0;
    coins = json['coins'] ?? 0;
    isPay = json['is_pay'] ?? 0;
    if (json['list'] != null && json['list'] is List) {
      list = json['list'].map<VideoModel>((e) => VideoModel.fromJson(e)).toList();
    }
  }

  Map<String, dynamic> toJson() => {
        "id": id,
        "item_id": itemId,
        "title": title,
        "sub_title": subTitle,
        "show_style": showStyle,
        "showMax": showMax,
        "number": number,
        "original_coins": originalCoins,
        "coins": coins,
        'is_pay': isPay,
        'list': List.from(list.map((e) => e.toJson()))
      };
}

InterfaceConnectorTab interfaceConnectorTabFromJson(String str) =>
    InterfaceConnectorTab.fromJson(json.decode(str));

String interfaceConnectorTabToJson(InterfaceConnectorTab data) =>
    json.encode(data.toJson());

class InterfaceConnectorTab {
  InterfaceConnectorTab({
    required this.data,
    required this.status,
    required this.msg,
    required this.crypt,
    required this.isVv,
    required this.needLogin,
    required this.isLogin,
  });

  List<TabDatum> data;
  int status;
  String msg;
  bool crypt;
  bool isVv;
  bool needLogin;
  bool isLogin;

  factory InterfaceConnectorTab.fromJson(Map<String, dynamic> json) =>
      InterfaceConnectorTab(
        data: json["data"] == null
            ? []
            : List<TabDatum>.from(
                json["data"].map((x) => TabDatum.fromJson(x))),
        status: json["status"] == null ? null : json["status"],
        msg: json["msg"] == null ? null : json["msg"],
        crypt: json["crypt"] == null ? null : json["crypt"],
        isVv: json["isVV"] == null ? null : json["isVV"],
        needLogin: json["needLogin"] == null ? null : json["needLogin"],
        isLogin: json["isLogin"] == null ? null : json["isLogin"],
      );

  Map<String, dynamic> toJson() => {
        "data": data == null
            ? null
            : List<dynamic>.from(data.map((x) => x.toJson())),
        "status": status == null ? null : status,
        "msg": msg == null ? null : msg,
        "crypt": crypt == null ? null : crypt,
        "isVV": isVv == null ? null : isVv,
        "needLogin": needLogin == null ? null : needLogin,
        "isLogin": isLogin == null ? null : isLogin,
      };
}

class TabDatum {
  TabDatum({
    required this.id,
    required this.name,
    required this.api,
    required this.subTab,
    required this.ads,
  });

  int id;
  String name;
  String api;
  List<SubTab> subTab;
  List<AtlisAd> ads;

  factory TabDatum.fromJson(Map<String, dynamic> json) => TabDatum(
        id: json["id"] == null ? null : json["id"],
        name: json["name"] == null ? null : json["name"],
        api: json["api"] == null ? null : json["api"],
        subTab: json["sub_tab"] == null
            ? []
            : List<SubTab>.from(json["sub_tab"].map((x) => SubTab.fromJson(x))),
        ads: json["ads"] == null
            ? []
            : List<AtlisAd>.from(json["ads"].map((x) => AtlisAd.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "id": id == null ? null : id,
        "name": name == null ? null : name,
        "api": api == null ? null : api,
        "sub_tab": subTab == null
            ? null
            : List<dynamic>.from(subTab.map((x) => x.toJson())),
        "ads":
            ads == null ? null : List<dynamic>.from(ads.map((x) => x.toJson())),
      };
}

class AtlisAd {
  AtlisAd({
    required this.id,
    required this.imgUrl,
  });

  int id;
  String imgUrl;

  factory AtlisAd.fromJson(Map<String, dynamic> json) => AtlisAd(
        id: json["id"] == null ? null : json["id"],
        imgUrl: json["img_url"] == null ? null : json["img_url"],
      );

  Map<String, dynamic> toJson() => {
        "id": id == null ? null : id,
        "img_url": imgUrl == null ? null : imgUrl,
      };
}

class SubTab {
  SubTab({
    required this.name,
    required this.value,
  });

  String name;
  String value;

  factory SubTab.fromJson(Map<String, dynamic> json) => SubTab(
        name: json["name"] == null ? null : json["name"],
        value: json["value"] == null ? null : json["value"],
      );

  Map<String, dynamic> toJson() => {
        "name": name == null ? null : name,
        "value": value == null ? null : value,
      };
}
