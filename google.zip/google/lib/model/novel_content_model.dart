import 'package:iaimei/model/unlock_info_model.dart';

/// pay_data : {"resource_coins":"100","resource_g_coins":"1000","resource_type":2,"is_vip":false,"is_pay":0,"free":0,"user_coins":"1000.00","user_g_coins":"5000","pay_way":[{"type":"resource_coins","name":"当前余额1000.00"},{"type":"resource_g_coins","name":"当前钻石5000"}]}
/// alist : {"story_id":635,"series":1,"title":"[學生校園]美女大學生竟然被老頭給.....","url":"/20220406/20220406082649029223.txt","url_full":"https://txt.microservices.vip/20220406/20220406082649029223.txt"}

class NovelContentModel {
  NovelContentModel({
    UnlockInfoModel? payData,
    NovelContentItem? list,
  }) {
    _payData = payData;
    _list = list;
  }

  NovelContentModel.fromJson(dynamic json) {
    _payData =
        json['pay_data'] != null ? UnlockInfoModel.fromJson(json['pay_data']) : null;
    _list = json['list'] != null ? NovelContentItem.fromJson(json['list']) : null;
  }

  UnlockInfoModel? _payData;
  NovelContentItem? _list;

  NovelContentModel copyWith({
    UnlockInfoModel? payData,
    NovelContentItem? list,
  }) =>
      NovelContentModel(
        payData: payData ?? _payData,
        list: list ?? _list,
      );

  UnlockInfoModel? get payData => _payData;

  NovelContentItem? get list => _list;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    if (_payData != null) {
      map['pay_data'] = _payData?.toJson();
    }
    map['list'] = _list;
    return map;
  }
}

/// story_id : 635
/// series : 1
/// title : "[學生校園]美女大學生竟然被老頭給....."
/// url : "/20220406/20220406082649029223.txt"
/// url_full : "https://txt.microservices.vip/20220406/20220406082649029223.txt"

class NovelContentItem {
  NovelContentItem({
    int? storyId,
    int? series,
    String? title,
    String? url,
    String? urlFull,
  }) {
    _storyId = storyId;
    _series = series;
    _title = title;
    _url = url;
    _urlFull = urlFull;
  }

  NovelContentItem.fromJson(dynamic json) {
    _storyId = json['story_id'];
    _series = json['series'];
    _title = json['title'];
    _url = json['url'];
    _urlFull = json['url_full'];
  }

  int? _storyId;
  int? _series;
  String? _title;
  String? _url;
  String? _urlFull;

  NovelContentItem copyWith({
    int? storyId,
    int? series,
    String? title,
    String? url,
    String? urlFull,
  }) =>
      NovelContentItem(
        storyId: storyId ?? _storyId,
        series: series ?? _series,
        title: title ?? _title,
        url: url ?? _url,
        urlFull: urlFull ?? _urlFull,
      );

  int? get storyId => _storyId;

  int? get series => _series;

  String? get title => _title;

  String? get url => _url;

  String? get urlFull => _urlFull;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['story_id'] = _storyId;
    map['series'] = _series;
    map['title'] = _title;
    map['url'] = _url;
    map['url_full'] = _urlFull;
    return map;
  }
}

