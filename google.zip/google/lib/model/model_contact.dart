// To parse this JSON data, do
//
//     final modelContact = modelContactFromJson(jsonString);

import 'dart:convert';

ModelContact modelContactFromJson(String str) =>
    ModelContact.fromJson(json.decode(str));

String modelContactToJson(ModelContact data) => json.encode(data.toJson());

class ModelContact {
  ModelContact({
    this.data,
    this.status,
    this.msg,
    this.crypt,
    this.isVv,
    this.needLogin,
    this.isLogin,
  });

  Data? data;
  int? status;
  String? msg;
  bool? crypt;
  bool? isVv;
  bool? needLogin;
  bool? isLogin;

  factory ModelContact.fromJson(Map<String, dynamic> json) => ModelContact(
        data: Data.fromJson(json["data"]),
        status: json["status"],
        msg: json["msg"],
        crypt: json["crypt"],
        isVv: json["isVV"],
        needLogin: json["needLogin"],
        isLogin: json["isLogin"],
      );

  Map<String, dynamic> toJson() => {
        "data": data?.toJson(),
        "status": status,
        "msg": msg,
        "crypt": crypt,
        "isVV": isVv,
        "needLogin": needLogin,
        "isLogin": isLogin,
      };
}

class Data {
  Data({
    this.list,
  });

  List<DataList>? list;

  factory Data.fromJson(Map<String, dynamic> json) => Data(
        list:
            List<DataList>.from(json["list"].map((x) => DataList.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "list": List<dynamic>.from(list!.map((x) => x.toJson())),
      };
}

class DataList {
  DataList({
    this.title,
    this.text,
    this.key,
    this.list,
  });

  String? title;
  String? text;
  String? key;
  List<ListList>? list;

  factory DataList.fromJson(Map<String, dynamic> json) => DataList(
        title: json["title"],
        text: json["text"],
        key: json["key"],
        list:
            List<ListList>.from(json["list"].map((x) => ListList.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "title": title,
        "text": text,
        "key": key,
        "list": List<dynamic>.from(list!.map((x) => x.toJson())),
      };
}

class ListList {
  ListList({
    this.id,
    this.title,
    this.icon,
    this.text,
    this.url,
    this.group,
    this.status,
    this.iconFull,
  });

  int? id;
  String? title;
  String? icon;
  String? text;
  String? url;
  String? group;
  int? status;
  String? iconFull;

  factory ListList.fromJson(Map<String, dynamic> json) => ListList(
        id: json["id"],
        title: json["title"],
        icon: json["icon"],
        text: json["text"],
        url: json["url"],
        group: json["group"],
        status: json["status"],
        iconFull: json["icon_full"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "title": title,
        "icon": icon,
        "text": text,
        "url": url,
        "group": group,
        "status": status,
        "icon_full": iconFull,
      };
}
