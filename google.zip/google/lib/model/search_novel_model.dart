import 'package:iaimei/model/comics_item_model.dart';
import 'package:iaimei/model/novel_item_model.dart';

/// total : "69"
/// list : [{"id":8,"title":"任何小姐","description":"残酷现实的解决师化身为任何人的暗黑英雄","category_id":10,"thumb":"/new/ads/20220215/2022021516401844248.jpeg","update_time":"周六","is_type":0,"refresh_at":"2022-03-22 13:23:31"},{"id":12487,"title":"[神代竜] 大小姐的色女傭事件(お嬢様のメイド事情) (中文)","description":"","category_id":0,"thumb":"/new/ads/20220215/2022021516401844248.jpeg","update_time":"完结","is_type":0,"refresh_at":"2022-03-22 13:23:31"}]

class SearchNovelModel {
  SearchNovelModel({
    String? total,
    List<NovelItemModel>? list,
  }) {
    _total = total;
    _list = list;
  }

  SearchNovelModel.fromJson(dynamic json) {
    _total = json['total'];
    if (json['list'] != null) {
      _list = [];
      json['list'].forEach((v) {
        _list?.add(NovelItemModel.fromJson(v));
      });
    }
  }

  String? _total;
  List<NovelItemModel>? _list;

  SearchNovelModel copyWith({
    String? total,
    List<NovelItemModel>? list,
  }) =>
      SearchNovelModel(
        total: total ?? _total,
        list: list ?? _list,
      );

  String? get total => _total;

  List<NovelItemModel>? get list => _list;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['total'] = _total;
    if (_list != null) {
      map['list'] = _list?.map((v) => v.toJson()).toList();
    }
    return map;
  }
}
