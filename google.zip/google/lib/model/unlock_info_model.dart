/// resource_coins : "90"
/// resource_g_coins : "900"
/// resource_type : 2
/// is_vip : true
/// is_pay : 0
/// free : 2
/// user_coins : "17379.00"
/// user_g_coins : "14040"
/// user_times : 10
/// pay_way : [{"type":"user_times","name":"剩余解锁次数:10"}]

class UnlockInfoModel {
  UnlockInfoModel({
      String? resourceCoins, 
      String? resourceGCoins, 
      int? resourceType, 
      bool? isVip, 
      int? isPay, 
      int? free, 
      String? userCoins, 
      String? userGCoins, 
      int? userTimes, 
      List<PayWay>? payWay,}){
    _resourceCoins = resourceCoins;
    _resourceGCoins = resourceGCoins;
    _resourceType = resourceType;
    _isVip = isVip;
    _isPay = isPay;
    _free = free;
    _userCoins = userCoins;
    _userGCoins = userGCoins;
    _userTimes = userTimes;
    _payWay = payWay;
}

  UnlockInfoModel.fromJson(dynamic json) {
    _resourceCoins = json['resource_coins'];
    _resourceGCoins = json['resource_g_coins'];
    _resourceType = json['resource_type'];
    _isVip = json['is_vip'];
    _isPay = json['is_pay'];
    _free = json['free'];
    _userCoins = json['user_coins'];
    _userGCoins = json['user_g_coins'];
    _userTimes = json['user_times'];
    if (json['pay_way'] != null) {
      _payWay = [];
      json['pay_way'].forEach((v) {
        _payWay?.add(PayWay.fromJson(v));
      });
    }
  }
  String? _resourceCoins;
  String? _resourceGCoins;
  int? _resourceType;
  bool? _isVip;
  int? _isPay;
  int? _free;
  String? _userCoins;
  String? _userGCoins;
  int? _userTimes;
  List<PayWay>? _payWay;
UnlockInfoModel copyWith({  String? resourceCoins,
  String? resourceGCoins,
  int? resourceType,
  bool? isVip,
  int? isPay,
  int? free,
  String? userCoins,
  String? userGCoins,
  int? userTimes,
  List<PayWay>? payWay,
}) => UnlockInfoModel(  resourceCoins: resourceCoins ?? _resourceCoins,
  resourceGCoins: resourceGCoins ?? _resourceGCoins,
  resourceType: resourceType ?? _resourceType,
  isVip: isVip ?? _isVip,
  isPay: isPay ?? _isPay,
  free: free ?? _free,
  userCoins: userCoins ?? _userCoins,
  userGCoins: userGCoins ?? _userGCoins,
  userTimes: userTimes ?? _userTimes,
  payWay: payWay ?? _payWay,
);
  String? get resourceCoins => _resourceCoins;
  String? get resourceGCoins => _resourceGCoins;
  int? get resourceType => _resourceType;
  bool? get isVip => _isVip;
  int? get isPay => _isPay;
  int? get free => _free;
  String? get userCoins => _userCoins;
  String? get userGCoins => _userGCoins;
  int? get userTimes => _userTimes;
  List<PayWay>? get payWay => _payWay;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['resource_coins'] = _resourceCoins;
    map['resource_g_coins'] = _resourceGCoins;
    map['resource_type'] = _resourceType;
    map['is_vip'] = _isVip;
    map['is_pay'] = _isPay;
    map['free'] = _free;
    map['user_coins'] = _userCoins;
    map['user_g_coins'] = _userGCoins;
    map['user_times'] = _userTimes;
    if (_payWay != null) {
      map['pay_way'] = _payWay?.map((v) => v.toJson()).toList();
    }
    return map;
  }

}

/// type : "user_times"
/// name : "剩余解锁次数:10"

class PayWay {
  PayWay({
      String? type, 
      String? name,}){
    _type = type;
    _name = name;
}

  PayWay.fromJson(dynamic json) {
    _type = json['type'];
    _name = json['name'];
  }
  String? _type;
  String? _name;
PayWay copyWith({  String? type,
  String? name,
}) => PayWay(  type: type ?? _type,
  name: name ?? _name,
);
  String? get type => _type;
  String? get name => _name;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['type'] = _type;
    map['name'] = _name;
    return map;
  }
}