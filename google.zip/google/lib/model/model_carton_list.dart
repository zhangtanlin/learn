// To parse this JSON data, do
//
//     final modelCartonList = modelCartonListFromJson(jsonString);

import 'dart:convert';

ModelCartonList modelCartonListFromJson(String str) =>
    ModelCartonList.fromJson(json.decode(str));

String modelCartonListToJson(ModelCartonList data) =>
    json.encode(data.toJson());

class ModelCartonList {
  ModelCartonList({
    this.data,
    this.status,
    this.msg,
    this.crypt,
    this.isVv,
    this.needLogin,
    this.isLogin,
  });

  List<Datum>? data;
  int? status;
  String? msg;
  bool? crypt;
  bool? isVv;
  bool? needLogin;
  bool? isLogin;

  factory ModelCartonList.fromJson(Map<String, dynamic> json) =>
      ModelCartonList(
        data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
        status: json["status"],
        msg: json["msg"],
        crypt: json["crypt"],
        isVv: json["isVV"],
        needLogin: json["needLogin"],
        isLogin: json["isLogin"],
      );

  Map<String, dynamic> toJson() => {
        "data": List<dynamic>.from(data!.map((x) => x.toJson())),
        "status": status,
        "msg": msg,
        "crypt": crypt,
        "isVV": isVv,
        "needLogin": needLogin,
        "isLogin": isLogin,
      };
}

class Datum {
  Datum({
    this.id,
    this.title,
    this.thumbFull,
    this.description,
    this.isType,
    this.refreshAt,
  });

  int? id;
  String? title;
  String? thumbFull;
  String? description;
  int? isType;
  DateTime? refreshAt;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
        id: json["id"],
        title: json["title"],
        thumbFull: json["thumb_full"],
        description: json["description"],
        isType: json["is_type"],
        refreshAt: DateTime.parse(json["refresh_at"]),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "title": title,
        "thumb_full": thumbFull,
        "description": description,
        "is_type": isType,
        "refresh_at": refreshAt?.toIso8601String(),
      };
}
