import 'package:iaimei/model/ads_model.dart';

class TabData {
  TabData({
    int? id,
    String? name,
    String? api,
    List<SubTab>? subTab,
    List<AdsModel>? ads,}){
    _id = id;
    _name = name;
    _api = api;
    _subTab = subTab;
    _ads = ads;
  }

  TabData.fromJson(dynamic json) {
    _id = json['id'];
    _name = json['name'];
    _api = json['api'];
    if (json['sub_tab'] != null) {
      _subTab = [];
      json['sub_tab'].forEach((v) {
        _subTab?.add(SubTab.fromJson(v));
      });
    }
    if (json['ads'] != null) {
      _ads = [];
      json['ads'].forEach((v) {
        _ads?.add(AdsModel.fromJson(v));
      });
    }
  }
  int? _id;
  String? _name;
  String? _api;
  List<SubTab>? _subTab;
  List<AdsModel>? _ads;

  int? get id => _id;
  String? get name => _name;
  String? get api => _api;
  List<SubTab>? get subTab => _subTab;
  List<AdsModel>? get ads => _ads;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = _id;
    map['name'] = _name;
    map['api'] = _api;
    if (_subTab != null) {
      map['sub_tab'] = _subTab?.map((v) => v.toJson()).toList();
    }
    if (_ads != null) {
      map['ads'] = _ads?.map((v) => v.toJson()).toList();
    }
    return map;
  }

}

/// name : "最新"
/// value : "new"

class SubTab {
  SubTab({
    String? name,
    String? value,}){
    _name = name;
    _value = value;
  }

  SubTab.fromJson(dynamic json) {
    _name = json['name'];
    _value = json['value'];
  }
  String? _name;
  String? _value;

  String? get name => _name;
  String? get value => _value;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['name'] = _name;
    map['value'] = _value;
    return map;
  }

}