import 'dart:convert';

Basic configFromJson(String str) => Basic.fromJson(json.decode(str));

String configToJson(Basic data) => json.encode(data.toJson());

class Basic {
  Basic({
    required this.data,
    required this.status,
    required this.msg,
    required this.crypt,
    required this.isVv,
    required this.needLogin,
    required this.isLogin,
  });

  dynamic data;
  int status;
  String msg;
  bool crypt;
  bool isVv;
  bool needLogin;
  bool isLogin;

  factory Basic.fromJson(Map<String, dynamic> json) => Basic(
        data: json["data"],
        status: json["status"],
        msg: json["msg"],
        crypt: json["crypt"],
        isVv: json["isVV"],
        needLogin: json["needLogin"],
        isLogin: json["isLogin"],
      );

  Map<String, dynamic> toJson() => {
        "data": data,
        "status": status,
        "msg": msg,
        "crypt": crypt,
        "isVV": isVv,
        "needLogin": needLogin,
        "isLogin": isLogin,
      };
}
