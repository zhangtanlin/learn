import 'package:iaimei/model/chat_set.dart';
import 'package:iaimei/model/reward_set.dart';
import 'package:iaimei/model/unlock_info_model.dart';

/// id : 5
/// uid : 42363
/// title : "邦妮"
/// type : 1
/// thumb : "/new/ads/20211222/2021122217464794661.jpeg"
/// girl_age : 21
/// girl_height : 167
/// girl_weight : 45
/// girl_cup : "F"
/// girl_price : "2000-4000"
/// girl_service_type : "才艺,自慰,裸舞,呻吟"
/// girl_business_hours : "12:00-02:00"
/// girl_pics : "/new/ads/20211222/2021122215051598571.jpeg,/new/ads/20220426/2022042610253375517.jpeg,/new/ads/20220426/2022042610260524682.jpeg"
/// desc : "邦尼是个大长腿哦~"
/// buy_original_price : 100
/// buy_price : 80
/// buy_num : 3
/// address : "广州市区都可以去"
/// status : 1
/// created_at : "2022-05-11 03:20:45"
/// updated_at : "2022-01-22 16:12:39"
/// is_recommed : 0
/// m3u8 : "/watch8/09d821a3518643697633fbe89c2c4641/09d821a3518643697633fbe89c2c4641.m3u8"
/// package_set : "10|100,20|200,30|300"
/// rewardset : [{"name":"红包","value":"10","gid":"g10"},{"name":"鲜花","value":"20","gid":"g20"},{"name":"牛鞭","value":"50","gid":"g50"},{"name":"福到","value":"88","gid":"g88"},{"name":"红酒","value":"200","gid":"g200"},{"name":"我爱你","value":"520","gid":"g52"}]
/// type_str : "官方认证"
/// status_str : "上架"
/// thumb_url : "https://new.tthykps.cn/new/ads/20211222/2021122217464794661.jpeg"
/// girl_pics_url : ["https://new.tthykps.cn/new/ads/20211222/2021122215051598571.jpeg","https://new.tthykps.cn/new/ads/20220426/2022042610253375517.jpeg","https://new.tthykps.cn/new/ads/20220426/2022042610260524682.jpeg"]
/// is_recommed_str : "否"
/// is_like : 0
/// is_pay : 0
/// pay_data : {"resource_coins":"0","resource_g_coins":"0","resource_type":1,"is_vip":false,"is_pay":0,"free":1,"user_coins":"18109.00","user_g_coins":"14040","user_times":"0","pay_way":[]}
/// m3u8_full : "https://120play.ktpdgao.cn/watch8/09d821a3518643697633fbe89c2c4641/09d821a3518643697633fbe89c2c4641.m3u8?auth_key=1652246719-0-0-15fccbdd040e5f588dfaac66c184f8c7"
/// chatset : [{"name":"10分钟","value":"100","set_id":"s10"},{"name":"20分钟","value":"200","set_id":"s20"},{"name":"30分钟","value":"300","set_id":"s30"}]
/// member : {"uid":42363,"nickname":"小心脏","thumb":"/new/xiao/20201117/2020111718103034588.png","vip_level":0,"sex":0,"expired_at":1650438671,"aff":42363,"avatar_url":"https://new.tthykps.cn/new/xiao/20201117/2020111718103034588.png","expired_str":"2022-04-20 15:11:11","is_vip":false,"is_attention":0}

class ChatDetailModel {
  ChatDetailModel({
      int? id, 
      int? uid, 
      String? title, 
      int? type, 
      String? thumb, 
      int? girlAge, 
      int? girlHeight, 
      int? girlWeight, 
      String? girlCup, 
      String? girlPrice, 
      String? girlServiceType, 
      String? girlBusinessHours, 
      String? girlPics, 
      String? desc, 
      int? buyOriginalPrice, 
      int? buyPrice, 
      int? buyNum, 
      String? address, 
      int? status, 
      String? createdAt, 
      String? updatedAt, 
      int? isRecommed, 
      String? m3u8, 
      String? packageSet, 
      List<RewardSet>? rewardset,
      String? typeStr, 
      String? statusStr, 
      String? thumbUrl, 
      List<String>? girlPicsUrl, 
      String? isRecommedStr, 
      int? isLike, 
      int? isPay, 
      UnlockInfoModel? payData,
      String? m3u8Full, 
      List<ChatSet>? chatset,
      Member? member,}){
    _id = id;
    _uid = uid;
    _title = title;
    _type = type;
    _thumb = thumb;
    _girlAge = girlAge;
    _girlHeight = girlHeight;
    _girlWeight = girlWeight;
    _girlCup = girlCup;
    _girlPrice = girlPrice;
    _girlServiceType = girlServiceType;
    _girlBusinessHours = girlBusinessHours;
    _girlPics = girlPics;
    _desc = desc;
    _buyOriginalPrice = buyOriginalPrice;
    _buyPrice = buyPrice;
    _buyNum = buyNum;
    _address = address;
    _status = status;
    _createdAt = createdAt;
    _updatedAt = updatedAt;
    _isRecommed = isRecommed;
    _m3u8 = m3u8;
    _packageSet = packageSet;
    _rewardset = rewardset;
    _typeStr = typeStr;
    _statusStr = statusStr;
    _thumbUrl = thumbUrl;
    _girlPicsUrl = girlPicsUrl;
    _isRecommedStr = isRecommedStr;
    _isLike = isLike;
    _isPay = isPay;
    _payData = payData;
    _m3u8Full = m3u8Full;
    _chatset = chatset;
    _member = member;
}

  ChatDetailModel.fromJson(dynamic json) {
    _id = json['id'];
    _uid = json['uid'];
    _title = json['title'];
    _type = json['type'];
    _thumb = json['thumb'];
    _girlAge = json['girl_age'];
    _girlHeight = json['girl_height'];
    _girlWeight = json['girl_weight'];
    _girlCup = json['girl_cup'];
    _girlPrice = json['girl_price'];
    _girlServiceType = json['girl_service_type'];
    _girlBusinessHours = json['girl_business_hours'];
    _girlPics = json['girl_pics'];
    _desc = json['desc'];
    _buyOriginalPrice = json['buy_original_price'];
    _buyPrice = json['buy_price'];
    _buyNum = json['buy_num'];
    _address = json['address'];
    _status = json['status'];
    _createdAt = json['created_at'];
    _updatedAt = json['updated_at'];
    _isRecommed = json['is_recommed'];
    _m3u8 = json['m3u8'];
    _packageSet = json['package_set'];
    if (json['rewardset'] != null) {
      _rewardset = [];
      json['rewardset'].forEach((v) {
        _rewardset?.add(RewardSet.fromJson(v));
      });
    }
    _typeStr = json['type_str'];
    _statusStr = json['status_str'];
    _thumbUrl = json['thumb_url'];
    _girlPicsUrl = json['girl_pics_url'] != null ? json['girl_pics_url'].cast<String>() : [];
    _isRecommedStr = json['is_recommed_str'];
    _isLike = json['is_like'];
    _isPay = json['is_pay'];
    _payData = json['pay_data'] != null ? UnlockInfoModel.fromJson(json['pay_data']) : null;
    _m3u8Full = json['m3u8_full'];
    if (json['chatset'] != null) {
      _chatset = [];
      json['chatset'].forEach((v) {
        _chatset?.add(ChatSet.fromJson(v));
      });
    }
    _member = json['member'] != null ? Member.fromJson(json['member']) : null;
  }
  int? _id;
  int? _uid;
  String? _title;
  int? _type;
  String? _thumb;
  int? _girlAge;
  int? _girlHeight;
  int? _girlWeight;
  String? _girlCup;
  String? _girlPrice;
  String? _girlServiceType;
  String? _girlBusinessHours;
  String? _girlPics;
  String? _desc;
  int? _buyOriginalPrice;
  int? _buyPrice;
  int? _buyNum;
  String? _address;
  int? _status;
  String? _createdAt;
  String? _updatedAt;
  int? _isRecommed;
  String? _m3u8;
  String? _packageSet;
  List<RewardSet>? _rewardset;
  String? _typeStr;
  String? _statusStr;
  String? _thumbUrl;
  List<String>? _girlPicsUrl;
  String? _isRecommedStr;
  int? _isLike;
  int? _isPay;
  UnlockInfoModel? _payData;
  String? _m3u8Full;
  List<ChatSet>? _chatset;
  Member? _member;
ChatDetailModel copyWith({  int? id,
  int? uid,
  String? title,
  int? type,
  String? thumb,
  int? girlAge,
  int? girlHeight,
  int? girlWeight,
  String? girlCup,
  String? girlPrice,
  String? girlServiceType,
  String? girlBusinessHours,
  String? girlPics,
  String? desc,
  int? buyOriginalPrice,
  int? buyPrice,
  int? buyNum,
  String? address,
  int? status,
  String? createdAt,
  String? updatedAt,
  int? isRecommed,
  String? m3u8,
  String? packageSet,
  List<RewardSet>? rewardset,
  String? typeStr,
  String? statusStr,
  String? thumbUrl,
  List<String>? girlPicsUrl,
  String? isRecommedStr,
  int? isLike,
  int? isPay,
  UnlockInfoModel? payData,
  String? m3u8Full,
  List<ChatSet>? chatset,
  Member? member,
}) => ChatDetailModel(  id: id ?? _id,
  uid: uid ?? _uid,
  title: title ?? _title,
  type: type ?? _type,
  thumb: thumb ?? _thumb,
  girlAge: girlAge ?? _girlAge,
  girlHeight: girlHeight ?? _girlHeight,
  girlWeight: girlWeight ?? _girlWeight,
  girlCup: girlCup ?? _girlCup,
  girlPrice: girlPrice ?? _girlPrice,
  girlServiceType: girlServiceType ?? _girlServiceType,
  girlBusinessHours: girlBusinessHours ?? _girlBusinessHours,
  girlPics: girlPics ?? _girlPics,
  desc: desc ?? _desc,
  buyOriginalPrice: buyOriginalPrice ?? _buyOriginalPrice,
  buyPrice: buyPrice ?? _buyPrice,
  buyNum: buyNum ?? _buyNum,
  address: address ?? _address,
  status: status ?? _status,
  createdAt: createdAt ?? _createdAt,
  updatedAt: updatedAt ?? _updatedAt,
  isRecommed: isRecommed ?? _isRecommed,
  m3u8: m3u8 ?? _m3u8,
  packageSet: packageSet ?? _packageSet,
  rewardset: rewardset ?? _rewardset,
  typeStr: typeStr ?? _typeStr,
  statusStr: statusStr ?? _statusStr,
  thumbUrl: thumbUrl ?? _thumbUrl,
  girlPicsUrl: girlPicsUrl ?? _girlPicsUrl,
  isRecommedStr: isRecommedStr ?? _isRecommedStr,
  isLike: isLike ?? _isLike,
  isPay: isPay ?? _isPay,
  payData: payData ?? _payData,
  m3u8Full: m3u8Full ?? _m3u8Full,
  chatset: chatset ?? _chatset,
  member: member ?? _member,
);
  int? get id => _id;
  int? get uid => _uid;
  String? get title => _title;
  int? get type => _type;
  String? get thumb => _thumb;
  int? get girlAge => _girlAge;
  int? get girlHeight => _girlHeight;
  int? get girlWeight => _girlWeight;
  String? get girlCup => _girlCup;
  String? get girlPrice => _girlPrice;
  String? get girlServiceType => _girlServiceType;
  String? get girlBusinessHours => _girlBusinessHours;
  String? get girlPics => _girlPics;
  String? get desc => _desc;
  int? get buyOriginalPrice => _buyOriginalPrice;
  int? get buyPrice => _buyPrice;
  int? get buyNum => _buyNum;
  String? get address => _address;
  int? get status => _status;
  String? get createdAt => _createdAt;
  String? get updatedAt => _updatedAt;
  int? get isRecommed => _isRecommed;
  String? get m3u8 => _m3u8;
  String? get packageSet => _packageSet;
  List<RewardSet>? get rewardset => _rewardset;
  String? get typeStr => _typeStr;
  String? get statusStr => _statusStr;
  String? get thumbUrl => _thumbUrl;
  List<String>? get girlPicsUrl => _girlPicsUrl;
  String? get isRecommedStr => _isRecommedStr;
  int? get isLike => _isLike;
  int? get isPay => _isPay;
  UnlockInfoModel? get payData => _payData;
  String? get m3u8Full => _m3u8Full;
  List<ChatSet>? get chatset => _chatset;
  Member? get member => _member;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = _id;
    map['uid'] = _uid;
    map['title'] = _title;
    map['type'] = _type;
    map['thumb'] = _thumb;
    map['girl_age'] = _girlAge;
    map['girl_height'] = _girlHeight;
    map['girl_weight'] = _girlWeight;
    map['girl_cup'] = _girlCup;
    map['girl_price'] = _girlPrice;
    map['girl_service_type'] = _girlServiceType;
    map['girl_business_hours'] = _girlBusinessHours;
    map['girl_pics'] = _girlPics;
    map['desc'] = _desc;
    map['buy_original_price'] = _buyOriginalPrice;
    map['buy_price'] = _buyPrice;
    map['buy_num'] = _buyNum;
    map['address'] = _address;
    map['status'] = _status;
    map['created_at'] = _createdAt;
    map['updated_at'] = _updatedAt;
    map['is_recommed'] = _isRecommed;
    map['m3u8'] = _m3u8;
    map['package_set'] = _packageSet;
    if (_rewardset != null) {
      map['rewardset'] = _rewardset?.map((v) => v.toJson()).toList();
    }
    map['type_str'] = _typeStr;
    map['status_str'] = _statusStr;
    map['thumb_url'] = _thumbUrl;
    map['girl_pics_url'] = _girlPicsUrl;
    map['is_recommed_str'] = _isRecommedStr;
    map['is_like'] = _isLike;
    map['is_pay'] = _isPay;
    if (_payData != null) {
      map['pay_data'] = _payData?.toJson();
    }
    map['m3u8_full'] = _m3u8Full;
    if (_chatset != null) {
      map['chatset'] = _chatset?.map((v) => v.toJson()).toList();
    }
    if (_member != null) {
      map['member'] = _member?.toJson();
    }
    return map;
  }

}

/// uid : 42363
/// nickname : "小心脏"
/// thumb : "/new/xiao/20201117/2020111718103034588.png"
/// vip_level : 0
/// sex : 0
/// expired_at : 1650438671
/// aff : 42363
/// avatar_url : "https://new.tthykps.cn/new/xiao/20201117/2020111718103034588.png"
/// expired_str : "2022-04-20 15:11:11"
/// is_vip : false
/// is_attention : 0

class Member {
  Member({
      int? uid, 
      String? nickname, 
      String? thumb, 
      int? vipLevel, 
      int? sex, 
      int? expiredAt, 
      int? aff, 
      String? avatarUrl, 
      String? expiredStr, 
      bool? isVip, 
      int? isAttention,}){
    _uid = uid;
    _nickname = nickname;
    _thumb = thumb;
    _vipLevel = vipLevel;
    _sex = sex;
    _expiredAt = expiredAt;
    _aff = aff;
    _avatarUrl = avatarUrl;
    _expiredStr = expiredStr;
    _isVip = isVip;
    _isAttention = isAttention;
}

  Member.fromJson(dynamic json) {
    _uid = json['uid'];
    _nickname = json['nickname'];
    _thumb = json['thumb'];
    _vipLevel = json['vip_level'];
    _sex = json['sex'];
    _expiredAt = json['expired_at'];
    _aff = json['aff'];
    _avatarUrl = json['avatar_url'];
    _expiredStr = json['expired_str'];
    _isVip = json['is_vip'];
    _isAttention = json['is_attention'];
  }
  int? _uid;
  String? _nickname;
  String? _thumb;
  int? _vipLevel;
  int? _sex;
  int? _expiredAt;
  int? _aff;
  String? _avatarUrl;
  String? _expiredStr;
  bool? _isVip;
  int? _isAttention;
Member copyWith({  int? uid,
  String? nickname,
  String? thumb,
  int? vipLevel,
  int? sex,
  int? expiredAt,
  int? aff,
  String? avatarUrl,
  String? expiredStr,
  bool? isVip,
  int? isAttention,
}) => Member(  uid: uid ?? _uid,
  nickname: nickname ?? _nickname,
  thumb: thumb ?? _thumb,
  vipLevel: vipLevel ?? _vipLevel,
  sex: sex ?? _sex,
  expiredAt: expiredAt ?? _expiredAt,
  aff: aff ?? _aff,
  avatarUrl: avatarUrl ?? _avatarUrl,
  expiredStr: expiredStr ?? _expiredStr,
  isVip: isVip ?? _isVip,
  isAttention: isAttention ?? _isAttention,
);
  int? get uid => _uid;
  String? get nickname => _nickname;
  String? get thumb => _thumb;
  int? get vipLevel => _vipLevel;
  int? get sex => _sex;
  int? get expiredAt => _expiredAt;
  int? get aff => _aff;
  String? get avatarUrl => _avatarUrl;
  String? get expiredStr => _expiredStr;
  bool? get isVip => _isVip;
  int? get isAttention => _isAttention;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['uid'] = _uid;
    map['nickname'] = _nickname;
    map['thumb'] = _thumb;
    map['vip_level'] = _vipLevel;
    map['sex'] = _sex;
    map['expired_at'] = _expiredAt;
    map['aff'] = _aff;
    map['avatar_url'] = _avatarUrl;
    map['expired_str'] = _expiredStr;
    map['is_vip'] = _isVip;
    map['is_attention'] = _isAttention;
    return map;
  }

}


