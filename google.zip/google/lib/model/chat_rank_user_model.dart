/// uid : 42363
/// nickname : "小心脏"
/// thumb : "/new/xiao/20201117/2020111718103034588.png"
/// vip_level : 0
/// sex : 0
/// expired_at : 1650438671
/// aff : 42363
/// rank : "850.77"
/// avatar_url : "https://new.kkzzzz.com/new/xiao/20201117/2020111718103034588.png"
/// expired_str : "2022-04-20 15:11:11"
/// is_vip : false
/// is_attention : 0

class ChatRankUserModel {
  ChatRankUserModel({
      int? uid, 
      String? nickname, 
      String? thumb, 
      int? vipLevel, 
      int? sex, 
      int? expiredAt, 
      int? aff, 
      String? rank, 
      String? avatarUrl, 
      String? expiredStr, 
      bool? isVip, 
      int? isAttention,}){
    _uid = uid;
    _nickname = nickname;
    _thumb = thumb;
    _vipLevel = vipLevel;
    _sex = sex;
    _expiredAt = expiredAt;
    _aff = aff;
    _rank = rank;
    _avatarUrl = avatarUrl;
    _expiredStr = expiredStr;
    _isVip = isVip;
    _isAttention = isAttention;
}

  ChatRankUserModel.fromJson(dynamic json) {
    _uid = json['uid'];
    _nickname = json['nickname'];
    _thumb = json['thumb'];
    _vipLevel = json['vip_level'];
    _sex = json['sex'];
    _expiredAt = json['expired_at'];
    _aff = json['aff'];
    _rank = json['rank'];
    _avatarUrl = json['avatar_url'];
    _expiredStr = json['expired_str'];
    _isVip = json['is_vip'];
    _isAttention = json['is_attention'];
  }
  int? _uid;
  String? _nickname;
  String? _thumb;
  int? _vipLevel;
  int? _sex;
  int? _expiredAt;
  int? _aff;
  String? _rank;
  String? _avatarUrl;
  String? _expiredStr;
  bool? _isVip;
  int? _isAttention;
ChatRankUserModel copyWith({  int? uid,
  String? nickname,
  String? thumb,
  int? vipLevel,
  int? sex,
  int? expiredAt,
  int? aff,
  String? rank,
  String? avatarUrl,
  String? expiredStr,
  bool? isVip,
  int? isAttention,
}) => ChatRankUserModel(  uid: uid ?? _uid,
  nickname: nickname ?? _nickname,
  thumb: thumb ?? _thumb,
  vipLevel: vipLevel ?? _vipLevel,
  sex: sex ?? _sex,
  expiredAt: expiredAt ?? _expiredAt,
  aff: aff ?? _aff,
  rank: rank ?? _rank,
  avatarUrl: avatarUrl ?? _avatarUrl,
  expiredStr: expiredStr ?? _expiredStr,
  isVip: isVip ?? _isVip,
  isAttention: isAttention ?? _isAttention,
);
  int? get uid => _uid;
  String? get nickname => _nickname;
  String? get thumb => _thumb;
  int? get vipLevel => _vipLevel;
  int? get sex => _sex;
  int? get expiredAt => _expiredAt;
  int? get aff => _aff;
  String? get rank => _rank;
  String? get avatarUrl => _avatarUrl;
  String? get expiredStr => _expiredStr;
  bool? get isVip => _isVip;
  int? get isAttention => _isAttention;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['uid'] = _uid;
    map['nickname'] = _nickname;
    map['thumb'] = _thumb;
    map['vip_level'] = _vipLevel;
    map['sex'] = _sex;
    map['expired_at'] = _expiredAt;
    map['aff'] = _aff;
    map['rank'] = _rank;
    map['avatar_url'] = _avatarUrl;
    map['expired_str'] = _expiredStr;
    map['is_vip'] = _isVip;
    map['is_attention'] = _isAttention;
    return map;
  }

}