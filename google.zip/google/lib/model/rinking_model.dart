import 'dart:convert';

RanKTabsModel ranKTabsModelFromJson(String str) =>
    RanKTabsModel.fromJson(json.decode(str));

String ranKTabsModelToJson(RanKTabsModel data) => json.encode(data.toJson());

class RanKTabsModel {
  RanKTabsModel({
    required this.data,
    required this.status,
    required this.msg,
    required this.crypt,
    required this.isVv,
    required this.needLogin,
    required this.isLogin,
  });

  List<RanKTabs> data;
  int status;
  String msg;
  bool crypt;
  bool isVv;
  bool needLogin;
  bool isLogin;

  factory RanKTabsModel.fromJson(Map<String, dynamic> json) => RanKTabsModel(
        data: json["data"] == null
            ? []
            : List<RanKTabs>.from(
                json["data"].map((x) => RanKTabs.fromJson(x))),
        status: json["status"] == null ? null : json["status"],
        msg: json["msg"] == null ? null : json["msg"],
        crypt: json["crypt"] == null ? null : json["crypt"],
        isVv: json["isVV"] == null ? null : json["isVV"],
        needLogin: json["needLogin"] == null ? null : json["needLogin"],
        isLogin: json["isLogin"] == null ? null : json["isLogin"],
      );

  Map<String, dynamic> toJson() => {
        "data": data == null
            ? null
            : List<dynamic>.from(data.map((x) => x.toJson())),
        "status": status == null ? null : status,
        "msg": msg == null ? null : msg,
        "crypt": crypt == null ? null : crypt,
        "isVV": isVv == null ? null : isVv,
        "needLogin": needLogin == null ? null : needLogin,
        "isLogin": isLogin == null ? null : isLogin,
      };
}

class RanKTabs {
  RanKTabs({
    required this.name,
    required this.api,
    required this.type,
  });

  String name;
  String api;
  String type;

  factory RanKTabs.fromJson(Map<String, dynamic> json) => RanKTabs(
        name: json["name"] == null ? null : json["name"],
        api: json["api"] == null ? null : json["api"],
        type: json["type"] == null ? null : json["type"],
      );

  Map<String, dynamic> toJson() => {
        "name": name == null ? null : name,
        "api": api == null ? null : api,
        "type": type == null ? null : type,
      };
}
