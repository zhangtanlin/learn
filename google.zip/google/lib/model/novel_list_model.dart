import 'package:iaimei/model/novel_item_model.dart';

/// id : 5
/// pid : 0
/// name : "空姐系列"
/// sort : 100
/// status : 1
/// refresh_time : "2022-03-21 09:00:17"
/// click_num : 0
/// vlist : [{"id":635,"title":"[學生校園]美女大學生竟然被老頭給.....","desc":null,"thumb":"/new/upload/20210415/2021041515540265298.jpeg","category_id":5,"is_free":0,"views_count":0,"favorites":0,"view_money":1,"download_money":1,"free_time":0,"recommend":0,"type":1,"status":1,"created_at":"2021-12-15 21:24:03","updated_at":"2021-12-15 21:24:03","img_url_full":"https://new.tthykps.cn/new/upload/20210415/2021041515540265298.jpeg"},{"id":634,"title":"[學生校園]女教師與學生","desc":null,"thumb":"/new/upload/20210415/2021041515540265298.jpeg","category_id":5,"is_free":0,"views_count":0,"favorites":0,"view_money":1,"download_money":1,"free_time":0,"recommend":0,"type":1,"status":1,"created_at":"2021-12-15 21:24:01","updated_at":"2021-12-15 21:24:01","img_url_full":"https://new.tthykps.cn/new/upload/20210415/2021041515540265298.jpeg"},{"id":633,"title":"[學生校園]校董室裡幹學姊","desc":null,"thumb":"/new/upload/20210415/2021041515540265298.jpeg","category_id":5,"is_free":0,"views_count":0,"favorites":0,"view_money":1,"download_money":1,"free_time":0,"recommend":1,"type":1,"status":1,"created_at":"2021-12-15 21:23:59","updated_at":"2021-12-15 21:23:59","img_url_full":"https://new.tthykps.cn/new/upload/20210415/2021041515540265298.jpeg"},{"id":632,"title":"[學生校園]校園鬼魅","desc":null,"thumb":"/new/upload/20210415/2021041515540265298.jpeg","category_id":5,"is_free":0,"views_count":0,"favorites":0,"view_money":1,"download_money":1,"free_time":0,"recommend":1,"type":1,"status":1,"created_at":"2021-12-15 21:23:57","updated_at":"2021-12-15 21:23:57","img_url_full":"https://new.tthykps.cn/new/upload/20210415/2021041515540265298.jpeg"},{"id":631,"title":"[學生校園]互相空虛寂寞的時候遇到了彼此","desc":null,"thumb":"/new/upload/20210415/2021041515540265298.jpeg","category_id":5,"is_free":0,"views_count":0,"favorites":0,"view_money":1,"download_money":1,"free_time":0,"recommend":1,"type":1,"status":1,"created_at":"2021-12-15 21:23:55","updated_at":"2021-12-15 21:23:55","img_url_full":"https://new.tthykps.cn/new/upload/20210415/2021041515540265298.jpeg"}]

class NovelListModel {
  NovelListModel({
    int? id,
    int? pid,
    String? name,
    int? sort,
    int? status,
    String? refreshTime,
    int? clickNum,
    List<NovelItemModel>? list,
  }) {
    _id = id;
    _pid = pid;
    _name = name;
    _sort = sort;
    _status = status;
    _refreshTime = refreshTime;
    _clickNum = clickNum;
    _list = list;
  }

  NovelListModel.fromJson(dynamic json) {
    _id = json['id'];
    _pid = json['pid'];
    _name = json['name'];
    _sort = json['sort'];
    _status = json['status'];
    _refreshTime = json['refresh_time'];
    _clickNum = json['click_num'];
    if (json['list'] != null) {
      _list = [];
      json['list'].forEach((v) {
        _list?.add(NovelItemModel.fromJson(v));
      });
    }
  }

  int? _id;
  int? _pid;
  String? _name;
  int? _sort;
  int? _status;
  String? _refreshTime;
  int? _clickNum;
  List<NovelItemModel>? _list;

  NovelListModel copyWith({
    int? id,
    int? pid,
    String? name,
    int? sort,
    int? status,
    String? refreshTime,
    int? clickNum,
    List<NovelItemModel>? list,
  }) =>
      NovelListModel(
        id: id ?? _id,
        pid: pid ?? _pid,
        name: name ?? _name,
        sort: sort ?? _sort,
        status: status ?? _status,
        refreshTime: refreshTime ?? _refreshTime,
        clickNum: clickNum ?? _clickNum,
        list: list ?? _list,
      );

  int? get id => _id;

  int? get pid => _pid;

  String? get name => _name;

  int? get sort => _sort;

  int? get status => _status;

  String? get refreshTime => _refreshTime;

  int? get clickNum => _clickNum;

  List<NovelItemModel>? get list => _list;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = _id;
    map['pid'] = _pid;
    map['name'] = _name;
    map['sort'] = _sort;
    map['status'] = _status;
    map['refresh_time'] = _refreshTime;
    map['click_num'] = _clickNum;
    if (_list != null) {
      map['list'] = _list?.map((v) => v.toJson()).toList();
    }
    return map;
  }
}


