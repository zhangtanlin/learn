import 'package:flutter/material.dart';
import 'package:iaimei/widget/image_preview.dart';

class ImgPreviewInfo {

  List imgItems; //图片列表
  int defaultIndex; //默认第几张
  PageChanged? pageChanged; //切换图片回调
  Axis? direction; //图片查看方向
  BoxDecoration? decoration; //背景设计

  ImgPreviewInfo(this.imgItems,
      {this.defaultIndex = 0,
      this.pageChanged,
      this.direction,
      this.decoration});
}
