import 'package:iaimei/model/chat_item_model.dart';


class ChatRecModel {
  ChatRecModel({
      List<ChatItemModel>? list,
      String? lastIx,}){
    _list = list;
    _lastIx = lastIx;
}

  ChatRecModel.fromJson(dynamic json) {
    if (json['list'] != null) {
      _list = [];
      json['list'].forEach((v) {
        _list?.add(ChatItemModel.fromJson(v));
      });
    }
    _lastIx = json['last_ix'];
  }
  List<ChatItemModel>? _list;
  String? _lastIx;
ChatRecModel copyWith({  List<ChatItemModel>? list,
  String? lastIx,
}) => ChatRecModel(  list: list ?? _list,
  lastIx: lastIx ?? _lastIx,
);
  List<ChatItemModel>? get list => _list;
  String? get lastIx => _lastIx;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    if (_list != null) {
      map['list'] = _list?.map((v) => v.toJson()).toList();
    }
    map['last_ix'] = _lastIx;
    return map;
  }

}

