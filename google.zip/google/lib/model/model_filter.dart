class Category {
  Category({
    this.name,
    this.items,
  });

  String? name;
  List<Item>? items;

  factory Category.fromJson(Map<String, dynamic> json) => Category(
        name: json["name"],
        items: List<Item>.from(json["items"].map((x) => Item.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "name": name,
        "items": List<dynamic>.from(items!.map((x) => x.toJson())),
      };
}

class Item {
  Item({
    this.label,
    this.value,
  });

  String? label;
  String? value;

  factory Item.fromJson(Map<String, dynamic> json) => Item(
        label: json["label"],
        value: json["value"],
      );

  Map<String, dynamic> toJson() => {
        "label": label,
        "value": value,
      };
}
