/// tab : [{"name":"长视频","value":"/api/search/long"},{"name":"短视频","value":"/api/search/short"},{"name":"漫画","value":"/api/search/mh"},{"name":"小说","value":"/api/search/story"},{"name":"图集","value":"/api/search/image"}]
/// alist : [{"name":"热播榜","type":"play","data":[{"name":"私人玩物1 / 91CM-244 / 高梨遥香「91制片厂」","value":"33074","type":"1"},{"name":"淫劫无间 林晓雪-国产AV,爱豆,MAD035","value":"20286","type":"1"},{"name":"想和你生宝宝-yuixin辛尤里","value":"14578","type":"2"},{"name":"乱伦洞房 林晓雪 爱豆 MAD034","value":"21514","type":"1"},{"name":"骚女人拿外卖","value":"17311","type":"2"},{"name":"放假了手机约个男淫来爆操我吧，内射中出后的我更满足-粉红兔TW","value":"11849","type":"1"},{"name":"时间停止器 顾桃桃 MDX0238-3","value":"21517","type":"1"},{"name":"剧情：少女之梦-正在复习的小兔子被我发现自慰，她拿出了一根非常棒的肉棒填满了她的悲伤洞-粉红兔TW","value":"11856","type":"1"},{"name":"肥臀巨乳模特儿 佐伯雪菜 口爆篇-中字无码","value":"11187","type":"1"},{"name":"现代金瓶梅 新人女优 倪哇哇 MAD012","value":"22889","type":"1"}]}]

class SearchIndexModel {
  SearchIndexModel({
      List<TabData>? tab,
      List<SearchSortList>? list,}){
    _tab = tab;
    _list = list;
}

  SearchIndexModel.fromJson(dynamic json) {
    if (json['tab'] != null) {
      _tab = [];
      json['tab'].forEach((v) {
        _tab?.add(TabData.fromJson(v));
      });
    }
    if (json['list'] != null) {
      _list = [];
      json['list'].forEach((v) {
        _list?.add(SearchSortList.fromJson(v));
      });
    }
  }
  List<TabData>? _tab;
  List<SearchSortList>? _list;
SearchIndexModel copyWith({  List<TabData>? tab,
  List<SearchSortList>? list,
}) => SearchIndexModel(  tab: tab ?? _tab,
  list: list ?? _list,
);
  List<TabData>? get tab => _tab;
  List<SearchSortList>? get list => _list;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    if (_tab != null) {
      map['tab'] = _tab?.map((v) => v.toJson()).toList();
    }
    if (_list != null) {
      map['list'] = _list?.map((v) => v.toJson()).toList();
    }
    return map;
  }

}

/// name : "热播榜"
/// type : "play"
/// data : [{"name":"私人玩物1 / 91CM-244 / 高梨遥香「91制片厂」","value":"33074","type":"1"},{"name":"淫劫无间 林晓雪-国产AV,爱豆,MAD035","value":"20286","type":"1"},{"name":"想和你生宝宝-yuixin辛尤里","value":"14578","type":"2"},{"name":"乱伦洞房 林晓雪 爱豆 MAD034","value":"21514","type":"1"},{"name":"骚女人拿外卖","value":"17311","type":"2"},{"name":"放假了手机约个男淫来爆操我吧，内射中出后的我更满足-粉红兔TW","value":"11849","type":"1"},{"name":"时间停止器 顾桃桃 MDX0238-3","value":"21517","type":"1"},{"name":"剧情：少女之梦-正在复习的小兔子被我发现自慰，她拿出了一根非常棒的肉棒填满了她的悲伤洞-粉红兔TW","value":"11856","type":"1"},{"name":"肥臀巨乳模特儿 佐伯雪菜 口爆篇-中字无码","value":"11187","type":"1"},{"name":"现代金瓶梅 新人女优 倪哇哇 MAD012","value":"22889","type":"1"}]

class SearchSortList {
  SearchSortList({
      String? name, 
      String? type, 
      List<SearchSortData>? data,}){
    _name = name;
    _type = type;
    _data = data;
}

  SearchSortList.fromJson(dynamic json) {
    _name = json['name'];
    _type = json['type'];
    if (json['data'] != null) {
      _data = [];
      json['data'].forEach((v) {
        _data?.add(SearchSortData.fromJson(v));
      });
    }
  }
  String? _name;
  String? _type;
  List<SearchSortData>? _data;
SearchSortList copyWith({  String? name,
  String? type,
  List<SearchSortData>? data,
}) => SearchSortList(  name: name ?? _name,
  type: type ?? _type,
  data: data ?? _data,
);
  String? get name => _name;
  String? get type => _type;
  List<SearchSortData>? get data => _data;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['name'] = _name;
    map['type'] = _type;
    if (_data != null) {
      map['data'] = _data?.map((v) => v.toJson()).toList();
    }
    return map;
  }

}

/// name : "私人玩物1 / 91CM-244 / 高梨遥香「91制片厂」"
/// value : "33074"
/// type : "1"

class SearchSortData {
  SearchSortData({
      String? name, 
      String? value, 
      String? type,}){
    _name = name;
    _value = value;
    _type = type;
}

  SearchSortData.fromJson(dynamic json) {
    _name = json['name'];
    _value = json['value'];
    _type = json['type'];
  }
  String? _name;
  String? _value;
  String? _type;
SearchSortData copyWith({  String? name,
  String? value,
  String? type,
}) => SearchSortData(  name: name ?? _name,
  value: value ?? _value,
  type: type ?? _type,
);
  String? get name => _name;
  String? get value => _value;
  String? get type => _type;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['name'] = _name;
    map['value'] = _value;
    map['type'] = _type;
    return map;
  }

}

/// name : "长视频"
/// value : "/api/search/long"

class TabData {
  TabData({
      String? name, 
      String? value,}){
    _name = name;
    _value = value;
}

  TabData.fromJson(dynamic json) {
    _name = json['name'];
    _value = json['value'];
  }
  String? _name;
  String? _value;
TabData copyWith({  String? name,
  String? value,
}) => TabData(  name: name ?? _name,
  value: value ?? _value,
);
  String? get name => _name;
  String? get value => _value;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['name'] = _name;
    map['value'] = _value;
    return map;
  }

}