import 'package:iaimei/model/ads_model.dart';

class UserInfoModel {
  UserInfoModel();
  UserInfoModel.fromJson(dynamic json) {
    uid = json['uid'];
    username = json['username'];
    isReg = json['is_reg'];
    roleId = json['role_id'];
    invitedBy = json['invited_by'];
    invitedNum = json['invited_num'];
    nickname = json['nickname'];
    gCoins = json['g_coins'];
    coins = json['coins'];
    coinsTotal = json['coins_total'];
    fansCount = json['fans_count'];
    followedCount = json['followed_count'];
    fabulousCount = json['fabulous_count'];
    sex = json['sex'];
    vipLevel = json['vip_level'] ?? 0;
    personSignnatrue = json['person_signnatrue'];
    buildId = json['build_id'];
    authStatus = json['auth_status'];
    chatUid = json['chat_uid'];
    birthday = json['birthday'];
    totalTuiCoins = json['total_tui_coins'];
    meetTimes = json['meet_times'];
    avatarUrl = json['avatar_url'];
    expiredStr = json['expired_str'];
    isVip = json['is_vip'] ?? false;
    isAttention = json['is_attention'];
    affCode = json['aff_code'];
    inviteByCode = json['invite_by_code'];
    shareUrl = json['share_url'];
    shareText = json['share_text'];
    token = json['token'];
    watchCount = json['watch_count'];
    canWatch = json['can_watch'];
    maker = json['maker'];
    club = json['club'];
    messageTip = json['message_tip'];
    todayCoins = json['today_coins'];
    todayTuiCoins = json['today_tui_coins'];
    allTuiCoins = json['all_tui_coins'];
    myTicketNumber = json['my_ticket_number'];
    ads = json['ads'] == null && json['ads'] is List
        ? []
        : json['ads'].map<AdsModel>((v) => AdsModel.fromJson(v)).toList();
    withdrawRate = json['withdraw_rate'];
    wxts = json['wxts'];
  }

  int? uid;
  String? username;
  int? isReg;
  int? roleId;
  int? invitedBy;
  int? invitedNum;
  String? nickname;
  int? gCoins;
  String? coins;
  String? coinsTotal;
  int? fansCount;
  int? followedCount;
  int? fabulousCount;
  int? sex;
  bool isVip = false;
  int vipLevel = 0;
  String? personSignnatrue;
  String? buildId;
  int? authStatus;
  String? chatUid;
  String? birthday;
  String? totalTuiCoins;
  int? meetTimes;
  String? avatarUrl;
  String? expiredStr;
  int? isAttention;
  String? affCode;
  String? inviteByCode;
  String? shareUrl;
  String? shareText;
  String? token;
  int? watchCount;
  int? canWatch;
  dynamic maker;
  dynamic club;
  int? messageTip;
  dynamic todayCoins;
  dynamic todayTuiCoins;
  dynamic allTuiCoins;
  int? myTicketNumber;
  List<AdsModel>? ads;
  double? withdrawRate;
  String? wxts;

  Map<String, dynamic> toJson() => {
        'uid': uid,
        'username': username,
        'is_reg': isReg,
        'role_id': roleId,
        'invited_by': invitedBy,
        'invited_num': invitedNum,
        'nickname': nickname,
        'g_coins': gCoins,
        'coins': coins,
        'coins_total': coinsTotal,
        'fans_count': fansCount,
        'followed_count': followedCount,
        'fabulous_count': fabulousCount,
        'sex': sex,
        'vip_level': vipLevel,
        'person_signnatrue': personSignnatrue,
        'build_id': buildId,
        'auth_status': authStatus,
        'chat_uid': chatUid,
        'birthday': birthday,
        'total_tui_coins': totalTuiCoins,
        'meet_times': meetTimes,
        'avatar_url': avatarUrl,
        'expired_str': expiredStr,
        'is_vip': isVip,
        'is_attention': isAttention,
        'aff_code': affCode,
        'invite_by_code': inviteByCode,
        'share_url': shareUrl,
        'share_text': shareText,
        'token': token,
        'watch_count': watchCount,
        'can_watch': canWatch,
        'maker': maker,
        'club': club,
        'message_tip': messageTip,
        'today_coins': todayCoins,
        'today_tui_coins': todayTuiCoins,
        'my_ticket_number': myTicketNumber,
        'ads': ads == null ? null : ads!.map((v) => v.toJson()).toList(),
        'withdraw_rate': withdrawRate,
        'wxts': wxts,
      };
}
