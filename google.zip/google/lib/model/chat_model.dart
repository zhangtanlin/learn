import 'dart:convert';

import 'package:iaimei/model/unlock_info_model.dart';

class ChatIndex {
  ChatIndex({
    required this.data,
    required this.status,
    required this.msg,
    required this.crypt,
    required this.isVv,
    required this.needLogin,
    required this.isLogin,
  });

  Data data;
  int status;
  String msg;
  bool crypt;
  bool isVv;
  bool needLogin;
  bool isLogin;

  factory ChatIndex.fromJson(Map<String, dynamic> json) => ChatIndex(
        data: json["data"] == null ? json["data"] : Data.fromJson(json["data"]),
        status: json["status"],
        msg: json["msg"],
        crypt: json["crypt"],
        isVv: json["isVV"],
        needLogin: json["needLogin"],
        isLogin: json["isLogin"],
      );

  Map<String, dynamic> toJson() => {
        "data": data == null ? null : data.toJson(),
        "status": status,
        "msg": msg,
        "crypt": crypt,
        "isVV": isVv,
        "needLogin": needLogin,
        "isLogin": isLogin,
      };
}

class Data {
  Data({
    required this.category,
    required this.recommend,
    required this.list,
  });

  List<Category> category;
  List<ChatModel> recommend;
  List<ChatModel> list;

  factory Data.fromJson(Map<String, dynamic> json) => Data(
        category: json["category"] == null
            ? []
            : List<Category>.from(
                json["category"].map((x) => Category.fromJson(x))),
        recommend: json["recommend"] == null
            ? []
            : List<ChatModel>.from(
                json["recommend"].map((x) => ChatModel.fromJson(x))),
        list: json["list"] == null
            ? []
            : List<ChatModel>.from(
                json["list"].map((x) => ChatModel.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "category": List<dynamic>.from(category.map((x) => x.toJson())),
        "recommed": List<dynamic>.from(recommend.map((x) => x.toJson())),
        "list": List<dynamic>.from(list.map((x) => x.toJson())),
      };
}

class Category {
  Category({
    required this.label,
    required this.name,
    required this.items,
  });

  String label;
  String name;
  List<Item> items;

  factory Category.fromJson(Map<String, dynamic> json) => Category(
        label: json["label"] ?? '',
        name: json["name"],
        items: json["items"] == null
            ? []
            : List<Item>.from(json["items"].map((x) => Item.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "label": label,
        "name": name,
        "items": List<dynamic>.from(items.map((x) => x.toJson())),
      };
}

class Item {
  Item({
    required this.label,
    required this.value,
  });

  String label;
  String value;

  factory Item.fromJson(Map<String, dynamic> json) => Item(
        label: json["label"],
        value: json["value"],
      );

  Map<String, dynamic> toJson() => {
        "label": label,
        "value": value,
      };
}

class ChatModel {
  ChatModel();
  int? id;
  int? uid;
  String title = '';
  int? type;
  String thumb = '';
  String desc = '';
  int? buyOriginalPrice;
  int? buyPrice;
  int? status;
  int? isRecommed;
  String typeStr = '';
  String statusStr = '';
  String thumbUrl = '';
  List<dynamic> girlPicsUrl = [];
  String isRecommedStr = '';
  int isLike = 0;
  int isPay = 0;
  UnlockInfoModel payData = UnlockInfoModel();
  String mediaUrl = '';

  String isFeatureStr = '';
  String isAdsStr = '';
  String girlSexStr = '';
  dynamic auth;
  String authStr = '';

  ChatModel.fromJson(Map<String, dynamic> json) {
    id = json["id"];
    uid = json["uid"];
    title = json["title"] ?? '';
    type = json["type"];
    thumb = json["thumb"] ?? '';
    desc = json["desc"] ?? '';
    buyOriginalPrice = json["buy_original_price"];
    buyPrice = json["buy_price"];
    status = json["status"];
    isRecommed = json["is_recommed"];
    typeStr = json["type_str"] ?? '';
    statusStr = json["status_str"] ?? '';
    thumbUrl = json["thumb_url"] ?? '';
    girlPicsUrl = json["girl_pics_url"] ?? [];
    isRecommedStr = json["is_recommed_str"] ?? '';
    isLike = json['is_like'] ?? 0;
    isPay = json['is_pay'] ?? 0;
    if (json['pay_data'] != null) {
      payData = UnlockInfoModel.fromJson(json['pay_data']);
    }
    mediaUrl = json['m3u8_full'] ?? '';
    // if (json["videos"] is List && json['videos'].isNotEmpty) {
    //   mediaUrl = json["videos"].first ?? '';
    // }

    isFeatureStr = json["is_feature_str"] ?? '';
    isAdsStr = json["is_ads_str"] ?? '';
    girlSexStr = json["girl_sex_str"] ?? '';
    auth = json["auth"];
    authStr = json["auth_str"] ?? '';
  }

  Map<String, dynamic> toJson() => {
        "id": id,
        "uid": uid,
        "title": title,
        "type": type,
        "thumb": thumb,
        "desc": desc,
        "buy_original_price": buyOriginalPrice,
        "buy_price": buyPrice,
        "status": status,
        "is_recommed": isRecommed,
        "type_str": typeStr,
        "status_str": statusStr,
        "thumb_url": thumbUrl,
        "girl_pics_url": girlPicsUrl,
        "is_recommed_str": isRecommedStr,
        'is_like': isLike,
        'is_pay': isPay,
        'pay_data': payData.toJson(),
        "m3u8_full": mediaUrl,
        "is_feature_str": isFeatureStr,
        "is_ads_str": isAdsStr,
        "girl_sex_str": girlSexStr,
        "auth": auth,
        "auth_str": authStr,
      };
}

class ChatRecommend {
  ChatRecommend({
    required this.data,
    required this.status,
    required this.msg,
    required this.crypt,
    required this.isVv,
    required this.needLogin,
    required this.isLogin,
  });

  RecommendData data;
  int status;
  String msg;
  bool crypt;
  bool isVv;
  bool needLogin;
  bool isLogin;

  factory ChatRecommend.fromJson(Map<String, dynamic> json) => ChatRecommend(
        data: json["data"] == null
            ? json["data"]
            : RecommendData.fromJson(json["data"]),
        status: json["status"],
        msg: json["msg"],
        crypt: json["crypt"],
        isVv: json["isVV"],
        needLogin: json["needLogin"],
        isLogin: json["isLogin"],
      );

  Map<String, dynamic> toJson() => {
        "data": data == null ? null : data.toJson(),
        "status": status,
        "msg": msg,
        "crypt": crypt,
        "isVV": isVv,
        "needLogin": needLogin,
        "isLogin": isLogin,
      };
}

class RecommendData {
  RecommendData({
    required this.list,
    required this.lastIx,
  });

  List<ChatModel> list;
  String lastIx;

  factory RecommendData.fromJson(Map<String, dynamic> json) => RecommendData(
        list: json["list"] == null
            ? []
            : List<ChatModel>.from(
                json["list"].map((x) => ChatModel.fromJson(x))),
        lastIx: json["last_ix"],
      );

  Map<String, dynamic> toJson() => {
        "list":
            list == null ? [] : List<dynamic>.from(list.map((x) => x.toJson())),
        "last_ix": lastIx,
      };
}



ChatListComment chatListCommentFromJson(String str) =>
    ChatListComment.fromJson(json.decode(str));

String chatListCommentToJson(ChatListComment data) =>
    json.encode(data.toJson());

class ChatListComment {
  ChatListComment({
    required this.data,
    required this.status,
    required this.msg,
    required this.crypt,
    required this.isVv,
    required this.needLogin,
    required this.isLogin,
  });

  ListCommentData data;
  int status;
  String msg;
  bool crypt;
  bool isVv;
  bool needLogin;
  bool isLogin;

  factory ChatListComment.fromJson(Map<String, dynamic> json) =>
      ChatListComment(
        data: json["data"] == null
            ? json["data"]
            : ListCommentData.fromJson(json["data"]),
        status: json["status"],
        msg: json["msg"],
        crypt: json["crypt"],
        isVv: json["isVV"],
        needLogin: json["needLogin"],
        isLogin: json["isLogin"],
      );

  Map<String, dynamic> toJson() => {
        "data": data == null ? null : data.toJson(),
        "status": status,
        "msg": msg,
        "crypt": crypt,
        "isVV": isVv,
        "needLogin": needLogin,
        "isLogin": isLogin,
      };
}

class ListCommentData {
  ListCommentData({
    required this.list,
    required this.lastIx,
  });

  List<CommentList> list;
  String lastIx;

  factory ListCommentData.fromJson(Map<String, dynamic> json) =>
      ListCommentData(
        list: json["list"] == null
            ? []
            : List<CommentList>.from(
                json["list"].map((x) => CommentList.fromJson(x))),
        lastIx: json["last_ix"] ?? 0,
      );

  Map<String, dynamic> toJson() => {
        "list":
            list == null ? [] : List<dynamic>.from(list.map((x) => x.toJson())),
        "last_ix": lastIx,
      };
}

class CommentList {
  CommentList({
    required this.id,
    required this.uid,
    required this.infoId,
    required this.content,
    required this.ipStr,
    required this.cityName,
    required this.status,
    required this.faceScore,
    required this.serviceScore,
    required this.createdAt,
    required this.createStr,
    required this.statusStr,
    required this.member,
  });

  int id;
  int uid;
  int infoId;
  String content;
  String ipStr;
  String cityName;
  int status;
  String faceScore;
  String serviceScore;
  int createdAt;
  String createStr;
  String statusStr;
  Member member;

  factory CommentList.fromJson(Map<String, dynamic> json) => CommentList(
        id: json["id"],
        uid: json["uid"],
        infoId: json["info_id"],
        content: json["content"],
        ipStr: json["ip_str"],
        cityName: json["city_name"],
        status: json["status"],
        faceScore: json["face_score"],
        serviceScore: json["service_score"],
        createdAt: json["created_at"],
        createStr: json["create_str"],
        statusStr: json["status_str"],
        member: json["member"] == null
            ? json["member"]
            : Member.fromJson(json["member"]),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "uid": uid,
        "info_id": infoId,
        "content": content,
        "ip_str": ipStr,
        "city_name": cityName,
        "status": status,
        "face_score": faceScore,
        "service_score": serviceScore,
        "created_at": createdAt,
        "create_str": createStr,
        "status_str": statusStr,
        "member": member == null ? null : member.toJson(),
      };
}

class Member {
  Member({
    required this.uid,
    required this.nickname,
    required this.thumb,
    required this.avatarUrl,
    required this.expiredStr,
    required this.isVip,
    required this.isAttention,
  });

  int uid;
  String nickname;
  String thumb;
  String avatarUrl;
  String expiredStr;
  bool isVip;
  int isAttention;

  factory Member.fromJson(Map<String, dynamic> json) => Member(
        uid: json["uid"],
        nickname: json["nickname"],
        thumb: json["thumb"],
        avatarUrl: json["avatar_url"],
        expiredStr: json["expired_str"],
        isVip: json["is_vip"],
        isAttention: json["is_attention"],
      );

  Map<String, dynamic> toJson() => {
        "uid": uid,
        "nickname": nickname,
        "thumb": thumb,
        "avatar_url": avatarUrl,
        "expired_str": expiredStr,
        "is_vip": isVip,
        "is_attention": isAttention,
      };
}
