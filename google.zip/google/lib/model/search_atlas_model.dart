import 'package:iaimei/model/atlas_item_model.dart';

/// total : "69"
/// alist : [{"id":217,"title":"小姐姐吹拉彈唱，大哥哥威武雄壯[15P]","desc":"","thumb":"/new/upload/20211218/2021121811402861311.jpeg","category_id":0,"tags":"偷窥,自拍","is_type":0,"view_count":0,"favorites":0,"view_money":1,"refresh_at":"2021-12-18 11:40:28","recommend":0,"coins":0,"status":1,"thumb_full":"https://new.tthykps.cn/new/upload/20211218/2021121811402861311.jpeg","is_pay":0,"pay_data":null},{"id":188,"title":"中國旅游小姐被我上了，極品[21P]","desc":"","thumb":"/new/upload/20211218/2021121810443852734.jpeg","category_id":0,"tags":"偷窥,自拍","is_type":0,"view_count":1,"favorites":0,"view_money":1,"refresh_at":"2021-12-18 10:44:38","recommend":0,"coins":0,"status":1,"thumb_full":"https://new.tthykps.cn/new/upload/20211218/2021121810443852734.jpeg","is_pay":0,"pay_data":null}]

class SearchAtlasModel {
  SearchAtlasModel({
      String? total, 
      List<AtlasItemModel>? list,}){
    _total = total;
    _list = list;
}

  SearchAtlasModel.fromJson(dynamic json) {
    _total = json['total'];
    if (json['list'] != null) {
      _list = [];
      json['list'].forEach((v) {
        _list?.add(AtlasItemModel.fromJson(v));
      });
    }
  }
  String? _total;
  List<AtlasItemModel>? _list;
SearchAtlasModel copyWith({  String? total,
  List<AtlasItemModel>? list,
}) => SearchAtlasModel(  total: total ?? _total,
  list: list ?? _list,
);
  String? get total => _total;
  List<AtlasItemModel>? get list => _list;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['total'] = _total;
    if (_list != null) {
      map['list'] = _list?.map((v) => v.toJson()).toList();
    }
    return map;
  }

}

