import 'package:iaimei/model/reward_set.dart';

class ChatRewardList {
  ChatRewardList({
    List<RewardSet>? gifts,
    Member? member,
  }) {
    _gifts = gifts;
    _member = member;
  }

  ChatRewardList.fromJson(dynamic json) {
    if (json['gifts'] != null) {
      _gifts = [];
      json['gifts'].forEach((v) {
        _gifts?.add(RewardSet.fromJson(v));
      });
    }
    _member = json['member'] != null ? Member.fromJson(json['member']) : null;
  }

  List<RewardSet>? _gifts;
  Member? _member;

  ChatRewardList copyWith({
    List<RewardSet>? gifts,
    Member? member,
  }) =>
      ChatRewardList(
        gifts: gifts ?? _gifts,
        member: member ?? _member,
      );

  List<RewardSet>? get gifts => _gifts;

  Member? get member => _member;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    if (_gifts != null) {
      map['gifts'] = _gifts?.map((v) => v.toJson()).toList();
    }
    if (_member != null) {
      map['member'] = _member?.toJson();
    }
    return map;
  }
}

class Member {
  Member({
    String? coins,
  }) {
    _coins = coins;
  }

  Member.fromJson(dynamic json) {
    _coins = json['coins'];
  }

  String? _coins;

  Member copyWith({
    String? coins,
  }) =>
      Member(
        coins: coins ?? _coins,
      );

  String? get coins => _coins;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['coins'] = _coins;
    return map;
  }
}
