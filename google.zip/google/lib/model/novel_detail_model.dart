import 'package:iaimei/model/unlock_info_model.dart';

/// detail : {"id":12612,"title":"逼姦美麗少婦","desc":null,"thumb":"/new/upload/20220321/2022032121294524275.jpeg","bg_thumb":"","category_id":5,"is_type":0,"view_count":21,"favorites":0,"view_money":1,"download_money":0,"free_time":0,"recommend":0,"type":1,"status":1,"refresh_at":"2022-04-29 20:45:41","tags":"强暴,虐待,激情","update_time":"完结","update_status":1,"coins":1,"img_url_full":"https://new.tthykps.cn/new/upload/20220321/2022032121294524275.jpeg","bg_thumb_full":"","is_pay":0,"pay_data":null,"update_info":"共1章·已完结"}
/// total : 1

class NovelDetailModel {
  NovelDetailModel({
      Detail? detail, 
      int? total,}){
    _detail = detail;
    _total = total;
}

  NovelDetailModel.fromJson(dynamic json) {
    _detail = json['detail'] != null ? Detail.fromJson(json['detail']) : null;
    _total = json['total'];
  }
  Detail? _detail;
  int? _total;
NovelDetailModel copyWith({  Detail? detail,
  int? total,
}) => NovelDetailModel(  detail: detail ?? _detail,
  total: total ?? _total,
);
  Detail? get detail => _detail;
  int? get total => _total;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    if (_detail != null) {
      map['detail'] = _detail?.toJson();
    }
    map['total'] = _total;
    return map;
  }

}

/// id : 12612
/// title : "逼姦美麗少婦"
/// desc : null
/// thumb : "/new/upload/20220321/2022032121294524275.jpeg"
/// bg_thumb : ""
/// category_id : 5
/// is_type : 0
/// view_count : 21
/// favorites : 0
/// view_money : 1
/// download_money : 0
/// free_time : 0
/// recommend : 0
/// type : 1
/// status : 1
/// refresh_at : "2022-04-29 20:45:41"
/// tags : "强暴,虐待,激情"
/// update_time : "完结"
/// update_status : 1
/// coins : 1
/// img_url_full : "https://new.tthykps.cn/new/upload/20220321/2022032121294524275.jpeg"
/// bg_thumb_full : ""
/// is_pay : 0
/// pay_data : null
/// update_info : "共1章·已完结"

class Detail {
  Detail({
      int? id, 
      String? title, 
      dynamic desc, 
      String? thumb, 
      String? bgThumb, 
      int? categoryId, 
      int? isType, 
      int? viewCount, 
      int? favorites, 
      int? viewMoney, 
      int? downloadMoney, 
      int? freeTime, 
      int? recommend, 
      int? type, 
      int? status, 
      String? refreshAt, 
      String? tags, 
      String? updateTime, 
      int? updateStatus, 
      int? coins, 
      String? imgUrlFull, 
      String? bgThumbFull, 
      int? isPay, 
      UnlockInfoModel? payData,
      String? updateInfo,}){
    _id = id;
    _title = title;
    _desc = desc;
    _thumb = thumb;
    _bgThumb = bgThumb;
    _categoryId = categoryId;
    _isType = isType;
    _viewCount = viewCount;
    _favorites = favorites;
    _viewMoney = viewMoney;
    _downloadMoney = downloadMoney;
    _freeTime = freeTime;
    _recommend = recommend;
    _type = type;
    _status = status;
    _refreshAt = refreshAt;
    _tags = tags;
    _updateTime = updateTime;
    _updateStatus = updateStatus;
    _coins = coins;
    _imgUrlFull = imgUrlFull;
    _bgThumbFull = bgThumbFull;
    _isPay = isPay;
    _payData = payData;
    _updateInfo = updateInfo;
}

  Detail.fromJson(dynamic json) {
    _id = json['id'];
    _title = json['title'];
    _desc = json['desc'];
    _thumb = json['thumb'];
    _bgThumb = json['bg_thumb'];
    _categoryId = json['category_id'];
    _isType = json['is_type'];
    _viewCount = json['view_count'];
    _favorites = json['favorites'];
    _viewMoney = json['view_money'];
    _downloadMoney = json['download_money'];
    _freeTime = json['free_time'];
    _recommend = json['recommend'];
    _type = json['type'];
    _status = json['status'];
    _refreshAt = json['refresh_at'];
    _tags = json['tags'];
    _updateTime = json['update_time'];
    _updateStatus = json['update_status'];
    _coins = json['coins'];
    _imgUrlFull = json['img_url_full'];
    _bgThumbFull = json['bg_thumb_full'];
    _isPay = json['is_pay'];
    _payData = json['pay_data'];
    _updateInfo = json['update_info'];
  }
  int? _id;
  String? _title;
  dynamic _desc;
  String? _thumb;
  String? _bgThumb;
  int? _categoryId;
  int? _isType;
  int? _viewCount;
  int? _favorites;
  int? _viewMoney;
  int? _downloadMoney;
  int? _freeTime;
  int? _recommend;
  int? _type;
  int? _status;
  String? _refreshAt;
  String? _tags;
  String? _updateTime;
  int? _updateStatus;
  int? _coins;
  String? _imgUrlFull;
  String? _bgThumbFull;
  int? _isPay;
  UnlockInfoModel? _payData;
  String? _updateInfo;
Detail copyWith({  int? id,
  String? title,
  dynamic desc,
  String? thumb,
  String? bgThumb,
  int? categoryId,
  int? isType,
  int? viewCount,
  int? favorites,
  int? viewMoney,
  int? downloadMoney,
  int? freeTime,
  int? recommend,
  int? type,
  int? status,
  String? refreshAt,
  String? tags,
  String? updateTime,
  int? updateStatus,
  int? coins,
  String? imgUrlFull,
  String? bgThumbFull,
  int? isPay,
  UnlockInfoModel? payData,
  String? updateInfo,
}) => Detail(  id: id ?? _id,
  title: title ?? _title,
  desc: desc ?? _desc,
  thumb: thumb ?? _thumb,
  bgThumb: bgThumb ?? _bgThumb,
  categoryId: categoryId ?? _categoryId,
  isType: isType ?? _isType,
  viewCount: viewCount ?? _viewCount,
  favorites: favorites ?? _favorites,
  viewMoney: viewMoney ?? _viewMoney,
  downloadMoney: downloadMoney ?? _downloadMoney,
  freeTime: freeTime ?? _freeTime,
  recommend: recommend ?? _recommend,
  type: type ?? _type,
  status: status ?? _status,
  refreshAt: refreshAt ?? _refreshAt,
  tags: tags ?? _tags,
  updateTime: updateTime ?? _updateTime,
  updateStatus: updateStatus ?? _updateStatus,
  coins: coins ?? _coins,
  imgUrlFull: imgUrlFull ?? _imgUrlFull,
  bgThumbFull: bgThumbFull ?? _bgThumbFull,
  isPay: isPay ?? _isPay,
  payData: payData ?? _payData,
  updateInfo: updateInfo ?? _updateInfo,
);
  int? get id => _id;
  String? get title => _title;
  dynamic get desc => _desc;
  String? get thumb => _thumb;
  String? get bgThumb => _bgThumb;
  int? get categoryId => _categoryId;
  int? get isType => _isType;
  int? get viewCount => _viewCount;
  int? get favorites => _favorites;
  int? get viewMoney => _viewMoney;
  int? get downloadMoney => _downloadMoney;
  int? get freeTime => _freeTime;
  int? get recommend => _recommend;
  int? get type => _type;
  int? get status => _status;
  String? get refreshAt => _refreshAt;
  String? get tags => _tags;
  String? get updateTime => _updateTime;
  int? get updateStatus => _updateStatus;
  int? get coins => _coins;
  String? get imgUrlFull => _imgUrlFull;
  String? get bgThumbFull => _bgThumbFull;
  int? get isPay => _isPay;
  UnlockInfoModel? get payData => _payData;
  String? get updateInfo => _updateInfo;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = _id;
    map['title'] = _title;
    map['desc'] = _desc;
    map['thumb'] = _thumb;
    map['bg_thumb'] = _bgThumb;
    map['category_id'] = _categoryId;
    map['is_type'] = _isType;
    map['view_count'] = _viewCount;
    map['favorites'] = _favorites;
    map['view_money'] = _viewMoney;
    map['download_money'] = _downloadMoney;
    map['free_time'] = _freeTime;
    map['recommend'] = _recommend;
    map['type'] = _type;
    map['status'] = _status;
    map['refresh_at'] = _refreshAt;
    map['tags'] = _tags;
    map['update_time'] = _updateTime;
    map['update_status'] = _updateStatus;
    map['coins'] = _coins;
    map['img_url_full'] = _imgUrlFull;
    map['bg_thumb_full'] = _bgThumbFull;
    map['is_pay'] = _isPay;
    map['pay_data'] = _payData;
    map['update_info'] = _updateInfo;
    return map;
  }
}