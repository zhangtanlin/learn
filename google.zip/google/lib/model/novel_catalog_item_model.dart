import 'package:iaimei/model/unlock_info_model.dart';

/// id : 635
/// story_id : 635
/// series : 1
/// title : "[學生校園]美女大學生竟然被老頭給....."
/// is_free : 0
/// views_count : 0
/// view_money : 1
/// download_money : 1
/// free_time : 0
/// recommend : 0
/// status : 1
/// created_at : "2021-12-15 21:24:04"
/// updated_at : "2021-12-15 21:24:04"
/// pay_data : {"resource_coins":"100","resource_g_coins":"1000","resource_type":2,"is_vip":false,"is_pay":0,"free":0,"user_coins":"1000.00","user_g_coins":"5000","pay_way":[{"type":"resource_coins","name":"当前余额1000.00"},{"type":"resource_g_coins","name":"当前钻石5000"}]}

class NovelCatalogItemModel {
  NovelCatalogItemModel({
      int? id, 
      int? storyId, 
      int? series, 
      String? title, 
      int? isFree, 
      int? viewsCount, 
      int? viewMoney, 
      int? downloadMoney, 
      int? freeTime, 
      int? recommend, 
      int? status, 
      String? createdAt, 
      String? updatedAt, 
      UnlockInfoModel? payData,}){
    _id = id;
    _storyId = storyId;
    _series = series;
    _title = title;
    _isFree = isFree;
    _viewsCount = viewsCount;
    _viewMoney = viewMoney;
    _downloadMoney = downloadMoney;
    _freeTime = freeTime;
    _recommend = recommend;
    _status = status;
    _createdAt = createdAt;
    _updatedAt = updatedAt;
    _payData = payData;
}

  NovelCatalogItemModel.fromJson(dynamic json) {
    _id = json['id'];
    _storyId = json['story_id'];
    _series = json['series'];
    _title = json['title'];
    _isFree = json['is_free'];
    _viewsCount = json['views_count'];
    _viewMoney = json['view_money'];
    _downloadMoney = json['download_money'];
    _freeTime = json['free_time'];
    _recommend = json['recommend'];
    _status = json['status'];
    _createdAt = json['created_at'];
    _updatedAt = json['updated_at'];
    _payData = json['pay_data'] != null ? UnlockInfoModel.fromJson(json['pay_data']) : null;
  }
  int? _id;
  int? _storyId;
  int? _series;
  String? _title;
  int? _isFree;
  int? _viewsCount;
  int? _viewMoney;
  int? _downloadMoney;
  int? _freeTime;
  int? _recommend;
  int? _status;
  String? _createdAt;
  String? _updatedAt;
  UnlockInfoModel? _payData;
NovelCatalogItemModel copyWith({  int? id,
  int? storyId,
  int? series,
  String? title,
  int? isFree,
  int? viewsCount,
  int? viewMoney,
  int? downloadMoney,
  int? freeTime,
  int? recommend,
  int? status,
  String? createdAt,
  String? updatedAt,
  UnlockInfoModel? payData,
}) => NovelCatalogItemModel(  id: id ?? _id,
  storyId: storyId ?? _storyId,
  series: series ?? _series,
  title: title ?? _title,
  isFree: isFree ?? _isFree,
  viewsCount: viewsCount ?? _viewsCount,
  viewMoney: viewMoney ?? _viewMoney,
  downloadMoney: downloadMoney ?? _downloadMoney,
  freeTime: freeTime ?? _freeTime,
  recommend: recommend ?? _recommend,
  status: status ?? _status,
  createdAt: createdAt ?? _createdAt,
  updatedAt: updatedAt ?? _updatedAt,
  payData: payData ?? _payData,
);
  int? get id => _id;
  int? get storyId => _storyId;
  int? get series => _series;
  String? get title => _title;
  int? get isFree => _isFree;
  int? get viewsCount => _viewsCount;
  int? get viewMoney => _viewMoney;
  int? get downloadMoney => _downloadMoney;
  int? get freeTime => _freeTime;
  int? get recommend => _recommend;
  int? get status => _status;
  String? get createdAt => _createdAt;
  String? get updatedAt => _updatedAt;
  UnlockInfoModel? get payData => _payData;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = _id;
    map['story_id'] = _storyId;
    map['series'] = _series;
    map['title'] = _title;
    map['is_free'] = _isFree;
    map['views_count'] = _viewsCount;
    map['view_money'] = _viewMoney;
    map['download_money'] = _downloadMoney;
    map['free_time'] = _freeTime;
    map['recommend'] = _recommend;
    map['status'] = _status;
    map['created_at'] = _createdAt;
    map['updated_at'] = _updatedAt;
    if (_payData != null) {
      map['pay_data'] = _payData?.toJson();
    }
    return map;
  }

}

