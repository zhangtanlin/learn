class BaseUserModel {
  dynamic uid;
  String nickname = '';
  int vipLevel = 0;
  int expiredAt = 0;
  String thumb = '';
  String avatarUrl = '';
  String expiredStr = '';
  bool isVip = false;
  bool isAttention = false;

  String uuid = '';
  int aff = 0;
  int sexType = 0;
  String pinyin = '';
}

class SimpleUserModel extends BaseUserModel {
  SimpleUserModel();
  SimpleUserModel.fromJson(Map<dynamic, dynamic> json) {
    uid = json['uid'] ?? 0;
    nickname = json['nickname'] ?? '';
    vipLevel = json['vip_level'] ?? 0;

    sexType = json["sexType"] ?? 0;
    if (json['sex'] != null) sexType = json['sex'] ?? 0;

    expiredAt = json['expired_at'] ?? 0;
    thumb = json['thumb'] ?? '';
    avatarUrl = json['avator_full'] ?? '';
    if (json['avatar_url'] != null) {
      avatarUrl = json['avatar_url'] ?? '';
    } 
    expiredStr = json['expired_str'] ?? '';
    isVip = json['is_vip'] ?? false;
    aff = json['aff'] ?? 0;
    uuid = json["uuid"] ?? '';
    isAttention = (json['is_attention'] ?? 0) > 1 ? true : false;
  }

  Map<String, dynamic> toJson() => {
        'uid': uid,
        'nickname': nickname,
        'vip_level': vipLevel,
        'sexType': sexType,
        'expired_at': expiredAt,
        'thumb': thumb,
        'avatar_url': avatarUrl,
        'expired_str': expiredStr,
        'is_vip': isVip,
        'aff': aff,
        'uuid': uuid,
        'is_attention': isAttention ? 1 : 0,
      };
}

class ActressUserModel extends BaseUserModel {
  int status = 0;
  dynamic renqi;
  String bwh = '';
  String cup = '';
  int avCount = 0;
  String brief = '';
  String chinaName = '';
  String coverFull = '';
  String birthday = '';
  String fameDate = '';
  String feature = '';

  ActressUserModel();
  ActressUserModel.fromJson(Map<String, dynamic> json) {
    uid = json['id'] ?? 0;
    nickname = json['name'] ?? '';
    pinyin = json["pinyin"] ?? '';
    thumb = json['avator_full'] ?? '';
    avatarUrl = json['avator_full'] ?? '';
    coverFull = json['cover_full'] ?? '';
    chinaName = json['china_name'] ?? '';
    status = json['status'] ?? 0;
    renqi = json['renqi'];
    bwh = json['bwh'] ?? '';
    cup = json['cup'] ?? '';
    avCount = json['av_count'] ?? 0;
    brief = json['brief'] ?? '';
    birthday = json['birthday'] ?? '--';
    fameDate = json['fame_date'] ?? '--';
    feature = json['feature'] ?? '--';
  }

  Map<String, dynamic> toJson() => {
        'id': uid,
        'name': nickname,
        'pinyin': pinyin,
        'avator': thumb,
        'avator_full': avatarUrl,
        'cover_full': coverFull,
      };
}
