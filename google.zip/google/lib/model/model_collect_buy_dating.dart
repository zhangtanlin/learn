// To parse this JSON data, do
//
//     final modelCollectBuyDating = modelCollectBuyDatingFromJson(jsonString);

import 'dart:convert';

ModelCollectBuyDating modelCollectBuyDatingFromJson(String str) =>
    ModelCollectBuyDating.fromJson(json.decode(str));

String modelCollectBuyDatingToJson(ModelCollectBuyDating data) =>
    json.encode(data.toJson());

class ModelCollectBuyDating {
  ModelCollectBuyDating({
    this.data,
    this.status,
    this.msg,
    this.crypt,
    this.isVv,
    this.needLogin,
    this.isLogin,
  });

  List<Datum>? data;
  int? status;
  String? msg;
  bool? crypt;
  bool? isVv;
  bool? needLogin;
  bool? isLogin;

  factory ModelCollectBuyDating.fromJson(Map<String, dynamic> json) =>
      ModelCollectBuyDating(
        data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
        status: json["status"],
        msg: json["msg"],
        crypt: json["crypt"],
        isVv: json["isVV"],
        needLogin: json["needLogin"],
        isLogin: json["isLogin"],
      );

  Map<String, dynamic> toJson() => {
        "data": List<dynamic>.from(data!.map((x) => x.toJson())),
        "status": status,
        "msg": msg,
        "crypt": crypt,
        "isVV": isVv,
        "needLogin": needLogin,
        "isLogin": isLogin,
      };
}

class Datum {
  Datum({
    this.id,
    this.infoId,
    this.createdStr,
    this.title,
    this.thumbUrl,
    this.desc,
  });

  int? id;
  int? infoId;
  String? createdStr;
  String? title;
  String? thumbUrl;
  String? desc;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
        id: json["id"],
        infoId: json["info_id"],
        createdStr: json["created_str"],
        title: json["title"],
        thumbUrl: json["thumb_url"],
        desc: json["desc"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "info_id": infoId,
        "created_str": createdStr,
        "title": title,
        "thumb_url": thumbUrl,
        "desc": desc,
      };
}
