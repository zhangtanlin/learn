// To parse this JSON data, do
//
//     final modelHelper = modelHelperFromJson(jsonString);

import 'dart:convert';

ModelHelper modelHelperFromJson(String str) =>
    ModelHelper.fromJson(json.decode(str));

String modelHelperToJson(ModelHelper data) => json.encode(data.toJson());

class ModelHelper {
  ModelHelper({
    required this.data,
    required this.status,
    required this.msg,
    required this.crypt,
    required this.isVv,
    required this.needLogin,
    required this.isLogin,
  });

  Data data;
  int status;
  String msg;
  bool crypt;
  bool isVv;
  bool needLogin;
  bool isLogin;

  factory ModelHelper.fromJson(Map<String, dynamic> json) => ModelHelper(
        data: Data.fromJson(json["data"]),
        status: json["status"],
        msg: json["msg"],
        crypt: json["crypt"],
        isVv: json["isVV"],
        needLogin: json["needLogin"],
        isLogin: json["isLogin"],
      );

  Map<String, dynamic> toJson() => {
        "data": data.toJson(),
        "status": status,
        "msg": msg,
        "crypt": crypt,
        "isVV": isVv,
        "needLogin": needLogin,
        "isLogin": isLogin,
      };
}

class Data {
  Data({
    required this.title,
    required this.description,
    required this.content,
    required this.list,
  });

  String title;
  String description;
  String content;
  List<ListElement> list;

  factory Data.fromJson(Map<String, dynamic> json) => Data(
        title: json["title"],
        description: json["description"],
        content: json["content"],
        list: List<ListElement>.from(
            json["list"].map((x) => ListElement.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "title": title,
        "description": description,
        "content": content,
        "list": List<dynamic>.from(list.map((x) => x.toJson())),
      };
}

class ListElement {
  ListElement({
    required this.icon,
    required this.text,
    required this.id,
  });

  String icon;
  String text;
  int id;

  factory ListElement.fromJson(Map<String, dynamic> json) => ListElement(
        icon: json["icon"],
        text: json["text"],
        id: json["id"],
      );

  Map<String, dynamic> toJson() => {
        "icon": icon,
        "text": text,
        "id": id,
      };
}
