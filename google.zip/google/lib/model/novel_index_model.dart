import 'package:iaimei/model/ads_model.dart';

/// ads : [{"id":47,"title":"钻石视频广场-AV推荐","description":"","mv_m3u8":"","img_url":"https://new.tthykps.cn/new/ads/20201013/2020101315212537737.png","url":"106159","type":5,"value":0},{"id":36,"title":"钻石视频广场-AV推荐","description":"","mv_m3u8":"","img_url":"https://new.tthykps.cn/new/ads/20201013/2020101314430770133.png","url":"102147","type":5,"value":0}]
/// data : [{"current":false,"id":-1,"name":"最新","type":"new","api":"/api/story/new"},{"current":true,"id":-1,"name":"推荐","type":"recommend","api":"/api/story/recommend"},{"current":false,"id":-1,"name":"逛逛","type":"rand","api":"/api/story/rand"}]

class NovelIndexModel {
  NovelIndexModel({
    List<AdsModel>? ads,
    List<TabData>? data,
  }) {
    _ads = ads;
    _data = data;
  }

  NovelIndexModel.fromJson(dynamic json) {
    if (json['ads'] != null) {
      _ads = [];
      json['ads'].forEach((v) {
        _ads?.add(AdsModel.fromJson(v));
      });
    }
    if (json['data'] != null) {
      _data = [];
      json['data'].forEach((v) {
        _data?.add(TabData.fromJson(v));
      });
    }
  }

  List<AdsModel>? _ads;
  List<TabData>? _data;

  NovelIndexModel copyWith({
    List<AdsModel>? ads,
    List<TabData>? data,
  }) =>
      NovelIndexModel(
        ads: ads ?? _ads,
        data: data ?? _data,
      );

  List<AdsModel>? get ads => _ads;

  List<TabData>? get data => _data;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    if (_ads != null) {
      map['ads'] = _ads?.map((v) => v.toJson()).toList();
    }
    if (_data != null) {
      map['data'] = _data?.map((v) => v.toJson()).toList();
    }
    return map;
  }
}

/// current : false
/// id : -1
/// name : "最新"
/// type : "new"
/// api : "/api/story/new"

class TabData {
  TabData({
    bool? current,
    int? id,
    String? name,
    String? type,
    String? api,
  }) {
    _current = current;
    _id = id;
    _name = name;
    _type = type;
    _api = api;
  }

  TabData.fromJson(dynamic json) {
    _current = json['current'];
    _id = json['id'];
    _name = json['name'];
    _type = json['type'];
    _api = json['api'];
  }

  bool? _current;
  int? _id;
  String? _name;
  String? _type;
  String? _api;

  TabData copyWith({
    bool? current,
    int? id,
    String? name,
    String? type,
    String? api,
  }) =>
      TabData(
        current: current ?? _current,
        id: id ?? _id,
        name: name ?? _name,
        type: type ?? _type,
        api: api ?? _api,
      );

  bool? get current => _current;

  int? get id => _id;

  String? get name => _name;

  String? get type => _type;

  String? get api => _api;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['current'] = _current;
    map['id'] = _id;
    map['name'] = _name;
    map['type'] = _type;
    map['api'] = _api;
    return map;
  }
}
