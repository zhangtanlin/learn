// To parse this JSON data, do
//
//     final modelDatingDetail = modelDatingDetailFromJson(jsonString);

import 'dart:convert';

import 'package:iaimei/model/dating_girl_info_model.dart';

ModelDatingDetail modelDatingDetailFromJson(String str) =>
    ModelDatingDetail.fromJson(json.decode(str));

String modelDatingDetailToJson(ModelDatingDetail data) =>
    json.encode(data.toJson());

class ModelDatingDetail {
  ModelDatingDetail({
    this.data,
    this.status,
    this.msg,
    this.crypt,
    this.isVv,
    this.needLogin,
    this.isLogin,
  });

  DatingGirlInfoModel? data;
  int? status;
  String? msg;
  bool? crypt;
  bool? isVv;
  bool? needLogin;
  bool? isLogin;

  factory ModelDatingDetail.fromJson(Map<String, dynamic> json) =>
      ModelDatingDetail(
        data: DatingGirlInfoModel.fromJson(json["data"]),
        status: json["status"],
        msg: json["msg"],
        crypt: json["crypt"],
        isVv: json["isVV"],
        needLogin: json["needLogin"],
        isLogin: json["isLogin"],
      );

  Map<String, dynamic> toJson() => {
        "data": data?.toJson(),
        "status": status,
        "msg": msg,
        "crypt": crypt,
        "isVV": isVv,
        "needLogin": needLogin,
        "isLogin": isLogin,
      };
}