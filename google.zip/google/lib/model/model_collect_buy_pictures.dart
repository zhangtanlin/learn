// To parse this JSON data, do
//
//     final modelCollectBuyPictures = modelCollectBuyPicturesFromJson(jsonString);

import 'dart:convert';

ModelCollectBuyPictures modelCollectBuyPicturesFromJson(String str) =>
    ModelCollectBuyPictures.fromJson(json.decode(str));

String modelCollectBuyPicturesToJson(ModelCollectBuyPictures data) =>
    json.encode(data.toJson());

class ModelCollectBuyPictures {
  ModelCollectBuyPictures({
    this.data,
    this.status,
    this.msg,
    this.crypt,
    this.isVv,
    this.needLogin,
    this.isLogin,
  });

  List<Datum>? data;
  int? status;
  String? msg;
  bool? crypt;
  bool? isVv;
  bool? needLogin;
  bool? isLogin;

  factory ModelCollectBuyPictures.fromJson(Map<String, dynamic> json) =>
      ModelCollectBuyPictures(
        data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
        status: json["status"],
        msg: json["msg"],
        crypt: json["crypt"],
        isVv: json["isVV"],
        needLogin: json["needLogin"],
        isLogin: json["isLogin"],
      );

  Map<String, dynamic> toJson() => {
        "data": List<dynamic>.from(data!.map((x) => x.toJson())),
        "status": status,
        "msg": msg,
        "crypt": crypt,
        "isVV": isVv,
        "needLogin": needLogin,
        "isLogin": isLogin,
      };
}

class Datum {
  Datum({
    this.id,
    this.title,
    this.thumbFull,
    this.desc,
    this.isType,
    this.refreshAt,
  });

  int? id;
  String? title;
  String? thumbFull;
  String? desc;
  int? isType;
  String? refreshAt;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
        id: json["id"],
        title: json["title"],
        thumbFull: json["thumb_full"],
        desc: json["desc"],
        isType: json["is_type"],
        refreshAt: json["refresh_at"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "title": title,
        "thumb_full": thumbFull,
        "desc": desc,
        "is_type": isType,
        "refresh_at": refreshAt,
      };
}
