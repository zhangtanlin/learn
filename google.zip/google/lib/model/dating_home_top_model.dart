import 'package:iaimei/model/dating_girl_info_model.dart';

/// ads : []
/// data : [{"name":"为你推荐","value":"/api/girl/recommend","type":"recommend","sub_tab":[]},{"name":"普通专区","value":"/api/girl/normal","type":"normal","sub_tab":[{"id":1,"name":"官方认证","status":1,"sort":0,"is_feature":1},{"id":2,"name":"楼凤","status":1,"sort":0,"is_feature":0},{"id":3,"name":"外围","status":1,"sort":0,"is_feature":1}]},{"name":"精品专区","value":"/api/girl/feature","type":"feature","sub_tab":[{"id":1,"name":"官方认证","status":1,"sort":0,"is_feature":1},{"id":3,"name":"外围","status":1,"sort":0,"is_feature":1}]},{"name":"验车报告","value":"/api/girl/verify","type":"verify","sub_tab":[]}]

class DatingHomeTopModel {
  DatingHomeTopModel({
    List<DatingGirlInfoModel>? ads,
    List<DatingTabData>? data,
  }) {
    _ads = ads;
    _data = data;
  }

  DatingHomeTopModel.fromJson(dynamic json) {
    if (json['ads'] != null) {
      _ads = [];
      json['ads'].forEach((v) {
        _ads?.add(DatingGirlInfoModel.fromJson(v));
      });
    }
    if (json['data'] != null) {
      _data = [];
      json['data'].forEach((v) {
        _data?.add(DatingTabData.fromJson(v));
      });
    }
  }

  List<DatingGirlInfoModel>? _ads;
  List<DatingTabData>? _data;

  DatingHomeTopModel copyWith({
    List<DatingGirlInfoModel>? ads,
    List<DatingTabData>? data,
  }) =>
      DatingHomeTopModel(
        ads: ads ?? _ads,
        data: data ?? _data,
      );

  List<DatingGirlInfoModel>? get ads => _ads;

  List<DatingTabData>? get data => _data;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    if (_ads != null) {
      map['ads'] = _ads?.map((v) => v.toJson()).toList();
    }
    if (_data != null) {
      map['data'] = _data?.map((v) => v.toJson()).toList();
    }
    return map;
  }
}

class DatingTabData {
  DatingTabData({
    String? name,
    String? value,
    String? type,
    List<DatingSubTabModel>? subTab,
  }) {
    _name = name;
    _value = value;
    _type = type;
    _subTab = subTab;
  }

  DatingTabData.fromJson(dynamic json) {
    _name = json['name'];
    _value = json['value'];
    _type = json['type'];
    if (json['sub_tab'] != null) {
      _subTab = [];
      json['sub_tab'].forEach((v) {
        _subTab?.add(DatingSubTabModel.fromJson(v));
      });
    }
  }

  String? _name;
  String? _value;
  String? _type;
  List<DatingSubTabModel>? _subTab;

  DatingTabData copyWith({
    String? name,
    String? value,
    String? type,
    List<DatingSubTabModel>? subTab,
  }) =>
      DatingTabData(
        name: name ?? _name,
        value: value ?? _value,
        type: type ?? _type,
        subTab: subTab ?? _subTab,
      );

  String? get name => _name;

  String? get value => _value;

  String? get type => _type;

  List<DatingSubTabModel>? get subTab => _subTab;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['name'] = _name;
    map['value'] = _value;
    map['type'] = _type;
    if (_subTab != null) {
      map['sub_tab'] = _subTab?.map((v) => v.toJson()).toList();
    }
    return map;
  }
}

class DatingSubTabModel {
  DatingSubTabModel({
    int? id,
    String? name,
    int? status,
    int? sort,
    int? isFeature,
  }) {
    _id = id;
    _name = name;
    _status = status;
    _sort = sort;
    _isFeature = isFeature;
  }

  DatingSubTabModel.fromJson(dynamic json) {
    _id = json['id'];
    _name = json['name'];
    _status = json['status'];
    _sort = json['sort'];
    _isFeature = json['is_feature'];
  }

  int? _id;
  String? _name;
  int? _status;
  int? _sort;
  int? _isFeature;

  DatingSubTabModel copyWith({
    int? id,
    String? name,
    int? status,
    int? sort,
    int? isFeature,
  }) =>
      DatingSubTabModel(
        id: id ?? _id,
        name: name ?? _name,
        status: status ?? _status,
        sort: sort ?? _sort,
        isFeature: isFeature ?? _isFeature,
      );

  int? get id => _id;

  String? get name => _name;

  int? get status => _status;

  int? get sort => _sort;

  int? get isFeature => _isFeature;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = _id;
    map['name'] = _name;
    map['status'] = _status;
    map['sort'] = _sort;
    map['is_feature'] = _isFeature;
    return map;
  }
}
