class AdsModel {
  AdsModel({
      int? id, 
      String? title, 
      String? description, 
      String? mvM3u8, 
      String? imgUrl, 
      String? url, 
      int? type, 
      int? value,}){
    _id = id;
    _title = title;
    _description = description;
    _mvM3u8 = mvM3u8;
    _imgUrl = imgUrl;
    _url = url;
    _type = type;
    _value = value;
}

  AdsModel.fromJson(dynamic json) {
    _id = json['id'];
    _title = json['title'];
    _description = json['description'];
    _mvM3u8 = json['mv_m3u8'];
    _imgUrl = json['img_url'];
    _url = json['url'];
    _type = json['type'];
    _value = json['value'];
  }
  int? _id;
  String? _title;
  String? _description;
  String? _mvM3u8;
  String? _imgUrl;
  String? _url;
  int? _type;
  int? _value;

  int? get id => _id;
  String? get title => _title;
  String? get description => _description;
  String? get mvM3u8 => _mvM3u8;
  String? get imgUrl => _imgUrl;
  String? get url => _url;
  int? get type => _type;
  int? get value => _value;

  set setType(int type) => _type = type;


  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = _id;
    map['title'] = _title;
    map['description'] = _description;
    map['mv_m3u8'] = _mvM3u8;
    map['img_url'] = _imgUrl;
    map['url'] = _url;
    map['type'] = _type;
    map['value'] = _value;
    return map;
  }

}