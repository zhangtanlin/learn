// To parse this JSON data, do
//
//     final modelDatingCollect = modelDatingCollectFromJson(jsonString);

import 'dart:convert';

ModelDatingCollect modelDatingCollectFromJson(String str) =>
    ModelDatingCollect.fromJson(json.decode(str));

String modelDatingCollectToJson(ModelDatingCollect data) =>
    json.encode(data.toJson());

class ModelDatingCollect {
  ModelDatingCollect({
    required this.data,
    required this.status,
    required this.msg,
    required this.crypt,
    required this.isVv,
    required this.needLogin,
    required this.isLogin,
  });

  Data data;
  int status;
  String msg;
  bool crypt;
  bool isVv;
  bool needLogin;
  bool isLogin;

  factory ModelDatingCollect.fromJson(Map<String, dynamic> json) =>
      ModelDatingCollect(
        data: Data.fromJson(json["data"]),
        status: json["status"],
        msg: json["msg"],
        crypt: json["crypt"],
        isVv: json["isVV"],
        needLogin: json["needLogin"],
        isLogin: json["isLogin"],
      );

  Map<String, dynamic> toJson() => {
        "data": data.toJson(),
        "status": status,
        "msg": msg,
        "crypt": crypt,
        "isVV": isVv,
        "needLogin": needLogin,
        "isLogin": isLogin,
      };
}

class Data {
  Data({
    required this.isLike,
  });

  int isLike;

  factory Data.fromJson(Map<String, dynamic> json) => Data(
        isLike: json["is_like"],
      );

  Map<String, dynamic> toJson() => {
        "is_like": isLike,
      };
}
