// To parse this JSON data, do
//
//     final modelFavoritesVideoList = modelFavoritesVideoListFromJson(jsonString);

import 'dart:convert';

import 'package:iaimei/model/video_model.dart';

ModelFavoritesVideoList modelFavoritesVideoListFromJson(String str) =>
    ModelFavoritesVideoList.fromJson(json.decode(str));

String modelFavoritesVideoListToJson(ModelFavoritesVideoList data) =>
    json.encode(data.toJson());

class ModelFavoritesVideoList {
  ModelFavoritesVideoList({
    this.data,
    this.status,
    this.msg,
    this.crypt,
    this.isVv,
    this.needLogin,
    this.isLogin,
  });

  List<VideoModel>? data;
  int? status;
  String? msg;
  bool? crypt;
  bool? isVv;
  bool? needLogin;
  bool? isLogin;

  factory ModelFavoritesVideoList.fromJson(Map<String, dynamic> json) =>
      ModelFavoritesVideoList(
        data: List<VideoModel>.from(
            json["data"].map((x) => VideoModel.fromJson(x))),
        status: json["status"],
        msg: json["msg"],
        crypt: json["crypt"],
        isVv: json["isVV"],
        needLogin: json["needLogin"],
        isLogin: json["isLogin"],
      );

  Map<String, dynamic> toJson() => {
        "data": List<VideoModel>.from(data!.map((x) => x.toJson())),
        "status": status,
        "msg": msg,
        "crypt": crypt,
        "isVV": isVv,
        "needLogin": needLogin,
        "isLogin": isLogin,
      };
}
