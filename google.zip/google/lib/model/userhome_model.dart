// To parse this JSON data, do
//
//     final userHomeModel = userHomeModelFromJson(jsonString);

import 'dart:convert';

UserHomeModel userHomeModelFromJson(String str) =>
    UserHomeModel.fromJson(json.decode(str));

String userHomeModelToJson(UserHomeModel data) => json.encode(data.toJson());

class UserHomeModel {
  UserHomeModel({
    this.data,
    this.status,
    this.msg = "",
    this.crypt = false,
    this.isVv = false,
    this.needLogin = false,
    this.isLogin = false,
  });

  UserHomeData? data;
  int? status;
  String msg;
  bool crypt;
  bool isVv;
  bool needLogin;
  bool isLogin;

  factory UserHomeModel.fromJson(Map<String, dynamic> json) => UserHomeModel(
        data: UserHomeData.fromJson(json["data"]),
        status: json["status"],
        msg: json["msg"],
        crypt: json["crypt"],
        isVv: json["isVV"],
        needLogin: json["needLogin"],
        isLogin: json["isLogin"],
      );

  Map<String, dynamic> toJson() => {
        "data": data?.toJson(),
        "status": status,
        "msg": msg,
        "crypt": crypt,
        "isVV": isVv,
        "needLogin": needLogin,
        "isLogin": isLogin,
      };
}

class UserHomeData {
  UserHomeData({
    this.maker,
    this.club,
    this.uid = 0,
    this.username = "",
    this.isReg = 0,
    this.roleId = 0,
    this.invitedBy = 0,
    this.invitedNum = 0,
    this.nickname = "",
    this.gCoins = 0,
    this.coins = 0,
    this.coinsTotal = 0,
    this.fansCount = 0,
    this.followedCount = 0,
    this.fabulousCount = 0,
    this.sex = 0,
    this.vipLevel = 0,
    this.personSignnatrue = "",
    this.buildId = "",
    this.authStatus = 0,
    this.chatUid = "",
    this.birthday = "",
    this.meetTimes = 0,
    this.avatarUrl = "",
    this.expiredStr = "",
    this.isVip = false,
    this.isAttention = 0,
  });

  Maker? maker;
  Club? club;
  int uid;
  String username;
  int isReg;
  int roleId;
  int invitedBy;
  int invitedNum;
  String nickname;
  int gCoins;
  int coins;
  int coinsTotal;
  int fansCount;
  int followedCount;
  int fabulousCount;
  int sex;
  int vipLevel;
  String personSignnatrue;
  String buildId;
  int authStatus;
  String chatUid;
  String birthday;
  int meetTimes;
  String avatarUrl;
  String expiredStr;
  bool isVip;
  int isAttention;

  factory UserHomeData.fromJson(Map<String, dynamic> json) => UserHomeData(
        maker: json["maker"] == null ? null : Maker.fromJson(json["maker"]),
        club: json["club"] == null ? null : Club.fromJson(json["club"]),
        uid: json["uid"] ?? 0,
        username: json["username"] ?? '',
        isReg: json["is_reg"] ?? 0,
        roleId: json["role_id"] ?? 0,
        invitedBy: json["invited_by"] ?? 0,
        invitedNum: json["invited_num"] ?? 0,
        nickname: json["nickname"] ?? '',
        gCoins: json["g_coins"] ?? 0,
        coins: json["coins"] ?? 0,
        coinsTotal: json["coins_total"] ?? 0,
        fansCount: json["fans_count"] ?? 0,
        followedCount: json["followed_count"] ?? 0,
        fabulousCount: json["fabulous_count"] ?? 0,
        sex: json["sex"] ?? 0,
        vipLevel: json["vip_level"] ?? 0,
        personSignnatrue: json["person_signnatrue"] ?? '',
        buildId: json["build_id"] ?? '',
        authStatus: json["auth_status"] ?? 0,
        chatUid: json["chat_uid"] ?? '',
        birthday: json["birthday"] ?? '',
        meetTimes: json["meet_times"] ?? 0,
        avatarUrl: json["avatar_url"] ?? '',
        expiredStr: json["expired_str"] ?? '',
        isVip: json["is_vip"] ?? false,
        isAttention: json["is_attention"] ?? 0,
      );

  Map<String, dynamic> toJson() => {
        "maker": maker?.toJson(),
        "club": club?.toJson(),
        "uid": uid,
        "username": username,
        "is_reg": isReg,
        "role_id": roleId,
        "invited_by": invitedBy,
        "invited_num": invitedNum,
        "nickname": nickname,
        "g_coins": gCoins,
        "coins": coins,
        "coins_total": coinsTotal,
        "fans_count": fansCount,
        "followed_count": followedCount,
        "fabulous_count": fabulousCount,
        "sex": sex,
        "vip_level": vipLevel,
        "person_signnatrue": personSignnatrue,
        "build_id": buildId,
        "auth_status": authStatus,
        "chat_uid": chatUid,
        "birthday": birthday,
        "meet_times": meetTimes,
        "avatar_url": avatarUrl,
        "expired_str": expiredStr,
        "is_vip": isVip,
        "is_attention": isAttention,
      };
}

class Club {
  Club({
    this.count = 0,
    required this.id,
    this.videosCount = 0,
    this.month = 0,
    this.quarter = 0,
    this.year = 0,
    this.long = 0,
    this.isJoin = false,
  });

  int count;
  int id;
  int videosCount;
  int month;
  int quarter;
  int year;
  int long;
  bool isJoin;

  factory Club.fromJson(Map<String, dynamic> json) => Club(
        id: json["id"] ?? 0,
        videosCount: json["videos_count"] ?? 0,
        count: json["count"] ?? 0,
        month: json["month"] ?? 0,
        quarter: json["quarter"] ?? 0,
        year: json["year"] ?? 0,
        long: json["long"] ?? 0,
        isJoin: json["is_join"] ?? false,
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "videos_count": videosCount,
        "count": count,
        "month": month,
        "quarter": quarter,
        "year": year,
        "long": long,
        "is_join": isJoin,
      };
}

class Maker {
  Maker({
    this.isUp = 0,
    this.isLive = 0,
    this.isLfeng = 0,
    this.isJjren = 0,
    this.isFace = 0,
  });

  int isUp;
  int isLive;
  int isLfeng;
  int isJjren;
  int isFace;

  factory Maker.fromJson(Map<String, dynamic> json) => Maker(
        isUp: json["is_up"],
        isLive: json["is_live"],
        isLfeng: json["is_lfeng"],
        isJjren: json["is_jjren"],
        isFace: json["is_face"],
      );

  Map<String, dynamic> toJson() => {
        "is_up": isUp,
        "is_live": isLive,
        "is_lfeng": isLfeng,
        "is_jjren": isJjren,
        "is_face": isFace,
      };
}
