import 'package:iaimei/model/video_model.dart';

class ShortVideoInfo{

   int? curIndex;
   List<VideoModel>? dataList;

   ShortVideoInfo({this.curIndex, this.dataList});
}