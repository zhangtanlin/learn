// To parse this JSON data, do
//
//     final modelMsgList = modelMsgListFromJson(jsonString);

import 'dart:convert';

ModelMsgList modelMsgListFromJson(String str) =>
    ModelMsgList.fromJson(json.decode(str));

String modelMsgListToJson(ModelMsgList data) => json.encode(data.toJson());

class ModelMsgList {
  ModelMsgList({
    required this.data,
    required this.status,
    required this.msg,
    required this.crypt,
    required this.isVv,
    required this.needLogin,
    required this.isLogin,
  });

  List<Datum> data;
  int status;
  String msg;
  bool crypt;
  bool isVv;
  bool needLogin;
  bool isLogin;

  factory ModelMsgList.fromJson(Map<String, dynamic> json) => ModelMsgList(
        data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
        status: json["status"],
        msg: json["msg"],
        crypt: json["crypt"],
        isVv: json["isVV"],
        needLogin: json["needLogin"],
        isLogin: json["isLogin"],
      );

  Map<String, dynamic> toJson() => {
        "data": List<dynamic>.from(data.map((x) => x.toJson())),
        "status": status,
        "msg": msg,
        "crypt": crypt,
        "isVV": isVv,
        "needLogin": needLogin,
        "isLogin": isLogin,
      };
}

class Datum {
  Datum({
    required this.id,
    required this.title,
    required this.description,
    required this.type,
    required this.createdAt,
    required this.image,
  });

  int id;
  String title;
  String description;
  int type;
  String createdAt;
  String image;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
        id: json["id"],
        title: json["title"],
        description: json["description"],
        type: json["type"],
        createdAt: json["created_at"],
        image: json["image"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "title": title,
        "description": description,
        "type": type,
        "created_at": createdAt,
        "image": image,
      };
}
