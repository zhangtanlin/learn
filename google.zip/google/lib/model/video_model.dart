import 'package:iaimei/model/simple_user.dart';
import 'package:iaimei/model/unlock_info_model.dart';

class VideoModel {
  int id = 0;
  String fanId = '';
  int uid = 0;
  int coins = 0;
  String title = '';
  int duration = 0;
  int thumbWidth = 0;
  int thumbHeight = 0;

  int rating = 0; // 播放次数
  int refreshAt = 0;
  int isFree = 0; // 0 免费 1 vip 2 金币
  int like = 0; // 喜欢或点赞数
  int comment = 0; // 评论数
  int status = 0; // 视频状态

  int thumbStartTime = 0;
  int thumbDuration = 0;
  int isHide = 0; // 下架或隐藏
  int isRecommend = 0; // 是推荐
  int isFeature = 0; // 是精选
  int countPay = 0; // 购买次数
  int type = 0; // 视频类型 1 横 2 竖

  int clubId = 0; // ??
  String playUrl = '';
  String payUrlFull = ''; // 详情才有
  List<String> tagsList = []; // 标签列表
  String coverThumbUrl = ''; //视频封面
  String createdStr = '';
  UnlockInfoModel payData = UnlockInfoModel(); // 购买信息

  int isLike = 0;
  int isPay = 0;
  String durationStr = '';
  SimpleUserModel user = SimpleUserModel();

  /* ******* unknown ******* */

  int pId = 0;
  int musicId = 0;
  String gifThumb = '';
  String gifThumbUrl = '';
  int gifWidth = 0;
  int gifHeight = 0;
  String directors = '';
  String actors = ''; // 演员
  int category = 0;
  String tags = '';
  String via = '';
  int onshelfTm = 0;
  int createdAt = 0;
  int isTop = 0; // 是否置顶
  String previewVideo = ''; // 预览视频
  String previewTip = ''; // 预览提示
  String m3U8 = '';
  int myTicketNumber = 0; // 观影券数

  VideoModel();

  VideoModel.fromJson(Map<dynamic, dynamic> json) {
    id = json['id'] ?? 0;
    fanId = json["fan_id"] ?? '';
    uid = json["uid"] ?? 0;
    coins = json["coins"] ?? 0;
    title = json["title"] ?? '';
    duration = json["duration"] ?? 0;
    thumbWidth = json["thumb_width"] ?? 0;
    thumbHeight = json["thumb_height"] ?? 0;
    rating = json["rating"] ?? 0;
    refreshAt = json["refresh_at"] ?? 0;
    isFree = json["is_free"] ?? 0;
    like = json["like"] ?? 0;
    comment = json["comment"] ?? 0;
    status = json["status"] ?? 0;
    thumbStartTime = json["thumb_start_time"] ?? 0;
    thumbDuration = json["thumb_duration"] ?? 0;
    isHide = json["is_hide"] ?? 0;
    isRecommend = json["is_recommend"] ?? 0;
    isFeature = json["is_feature"] ?? 0;
    countPay = json["count_pay"] ?? 0;
    type = json["type"] ?? 0;
    clubId = json["club_id"] ?? 0;
    playUrl = json["play_url"] ?? '';
    payUrlFull = json['pay_url_full'] ?? '';
    if (json["tags_list"] != null) {
      tagsList = List<String>.from(json["tags_list"].map((x) => x));
    }
    coverThumbUrl = json["cover_thumb_url"] ?? '';
    createdStr = json["created_str"] ?? '';
    if (json['pay_data'] != null) {
      payData = UnlockInfoModel.fromJson(json['pay_data']);
    }
    isLike = json["is_like"] ?? 0;
    durationStr = json["duration_str"] ?? '';
    isPay = json["is_pay"] ?? 0;
    if (json['user'] != null) {
      user = SimpleUserModel.fromJson(json["user"]);
    }

    pId = json["p_id"] ?? 0;
    musicId = json["music_id"] ?? 0;
    gifThumb = json["gif_thumb"] ?? '';
    gifWidth = json["gif_width"] ?? 0;
    gifHeight = json["gif_height"] ?? 0;
    directors = json["directors"] ?? '';
    actors = json["actors"] ?? '';
    category = json["category"] ?? 0;
    tags = json["tags"] ?? '';
    via = json["via"] ?? '';
    onshelfTm = json["onshelf_tm"] ?? 0;
    createdAt = json["created_at"] ?? 0;
    isTop = json["is_top"] ?? 0;
    previewVideo = json["preview_video"] ?? '';
    previewTip = json["preview_tip"] ?? '';
    gifThumbUrl = json["gif_thumb_url"] ?? '';
    m3U8 = json["m3u8"] ?? '';
    myTicketNumber = json["my_ticket_number"] ?? 0;
  }

  Map<String, dynamic> toJson() => {
        "id": id,
        "fan_id": fanId,
        "uid": uid,
        "coins": coins,
        "title": title,
        "duration": duration,
        "thumb_width": thumbWidth,
        "thumb_height": thumbHeight,
        "rating": rating,
        "refresh_at": refreshAt,
        "is_free": isFree,
        "like": like,
        "comment": comment,
        "status": status,
        "thumb_start_time": thumbStartTime,
        "thumb_duration": thumbDuration,
        "is_hide": isHide,
        "is_recommend": isRecommend,
        "is_feature": isFeature,
        "count_pay": countPay,
        "type": type,
        "club_id": clubId,
        "play_url": playUrl,
        'pay_url_full': payUrlFull,
        "tags_list": List<dynamic>.from(tagsList.map((x) => x)),
        "cover_thumb_url": coverThumbUrl,
        "created_str": createdStr,
        'pay_data': payData.toJson(),
        "is_like": isLike,
        "duration_str": durationStr,
        "is_pay": isPay,
        "user": user.toJson(),
        "p_id": pId,
        "music_id": musicId,
        "gif_thumb": gifThumb,
        "gif_width": gifWidth,
        "gif_height": gifHeight,
        "directors": directors,
        "actors": actors,
        "category": category,
        "tags": tags,
        "via": via,
        "onshelf_tm": onshelfTm,
        "created_at": createdAt,
        "is_top": isTop,
        "preview_video": previewVideo,
        "preview_tip": previewTip,
        "gif_thumb_url": gifThumbUrl,
        "m3u8": m3U8,
        "my_ticket_number": myTicketNumber,
      };
}
