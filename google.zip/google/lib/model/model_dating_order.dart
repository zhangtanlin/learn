// To parse this JSON data, do
//
//     final modelDatingOrder = modelDatingOrderFromJson(jsonString);

import 'dart:convert';

ModelDatingOrder modelDatingOrderFromJson(String str) =>
    ModelDatingOrder.fromJson(json.decode(str));

String modelDatingOrderToJson(ModelDatingOrder data) =>
    json.encode(data.toJson());

class ModelDatingOrder {
  ModelDatingOrder({
    this.data,
    this.status,
    this.msg,
    this.crypt,
    this.isVv,
    this.needLogin,
    this.isLogin,
  });

  Data? data;
  int? status;
  String? msg;
  bool? crypt;
  bool? isVv;
  bool? needLogin;
  bool? isLogin;

  factory ModelDatingOrder.fromJson(Map<String, dynamic> json) =>
      ModelDatingOrder(
        data: Data.fromJson(json["data"]),
        status: json["status"],
        msg: json["msg"],
        crypt: json["crypt"],
        isVv: json["isVV"],
        needLogin: json["needLogin"],
        isLogin: json["isLogin"],
      );

  Map<String, dynamic> toJson() => {
        "data": data?.toJson(),
        "status": status,
        "msg": msg,
        "crypt": crypt,
        "isVV": isVv,
        "needLogin": needLogin,
        "isLogin": isLogin,
      };
}

class Data {
  Data({
    this.contact,
    this.download,
    this.orderSn,
  });

  List<Contact>? contact;
  List<Contact>? download;
  String? orderSn;

  factory Data.fromJson(Map<String, dynamic> json) => Data(
        contact:
            List<Contact>.from(json["contact"].map((x) => Contact.fromJson(x))),
        download: List<Contact>.from(
            json["download"].map((x) => Contact.fromJson(x))),
        orderSn: json["order_sn"],
      );

  Map<String, dynamic> toJson() => {
        "contact": List<dynamic>.from(contact!.map((x) => x.toJson())),
        "download": List<dynamic>.from(download!.map((x) => x.toJson())),
        "order_sn": orderSn,
      };
}

class Contact {
  Contact({
    this.id,
    this.title,
    this.icon,
    this.text,
    this.url,
    this.group,
    this.status,
    this.iconFull,
  });

  int? id;
  String? title;
  String? icon;
  String? text;
  String? url;
  String? group;
  int? status;
  String? iconFull;

  factory Contact.fromJson(Map<String, dynamic> json) => Contact(
        id: json["id"],
        title: json["title"],
        icon: json["icon"],
        text: json["text"],
        url: json["url"],
        group: json["group"],
        status: json["status"],
        iconFull: json["icon_full"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "title": title,
        "icon": icon,
        "text": text,
        "url": url,
        "group": group,
        "status": status,
        "icon_full": iconFull,
      };
}
