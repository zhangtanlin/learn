/// data : null
/// status : 1
/// msg : ""
/// crypt : true
/// isVV : true
/// needLogin : true
/// isLogin : true

class BaseResponse {
  BaseResponse({
      dynamic data, 
      int? status, 
      String? msg, 
      bool? crypt, 
      bool? isVV, 
      bool? needLogin, 
      bool? isLogin,}){
    _data = data;
    _status = status;
    _msg = msg;
    _crypt = crypt;
    _isVV = isVV;
    _needLogin = needLogin;
    _isLogin = isLogin;
}

  BaseResponse.fromJson(dynamic json) {
    _data = json['data'];
    _status = json['status'];
    _msg = json['msg'];
    _crypt = json['crypt'];
    _isVV = json['isVV'];
    _needLogin = json['needLogin'];
    _isLogin = json['isLogin'];
  }
  dynamic _data;
  int? _status;
  String? _msg;
  bool? _crypt;
  bool? _isVV;
  bool? _needLogin;
  bool? _isLogin;

  dynamic get data => _data;
  int? get status => _status;
  String? get msg => _msg;
  bool? get crypt => _crypt;
  bool? get isVV => _isVV;
  bool? get needLogin => _needLogin;
  bool? get isLogin => _isLogin;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['data'] = _data;
    map['status'] = _status;
    map['msg'] = _msg;
    map['crypt'] = _crypt;
    map['isVV'] = _isVV;
    map['needLogin'] = _needLogin;
    map['isLogin'] = _isLogin;
    return map;
  }

}