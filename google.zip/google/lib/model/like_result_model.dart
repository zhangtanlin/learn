/// is_like : 1

class LikeResultModel {
  LikeResultModel({
    int? isLike,
  }) {
    _isLike = isLike;
  }

  LikeResultModel.fromJson(dynamic json) {
    _isLike = json['is_like'];
  }

  int? _isLike;

  LikeResultModel copyWith({
    int? isLike,
  }) =>
      LikeResultModel(
        isLike: isLike ?? _isLike,
      );

  int? get isLike => _isLike;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['is_like'] = _isLike;
    return map;
  }
}
