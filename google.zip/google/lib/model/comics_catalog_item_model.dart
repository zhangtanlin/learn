import 'package:iaimei/model/unlock_info_model.dart';

/// id : 1
/// pid : 1
/// episode : 1
/// title : null
/// is_free : 1
/// is_try : 1
/// pay_data : {"resource_coins":10,"resource_g_coins":100,"resource_type":2,"is_vip":false,"is_pay":0,"free":0,"user_coins":0,"user_g_coins":0,"pay_way":[{"type":"resource_coins","name":"当前余额0"},{"type":"resource_g_coins","name":"当前钻石0"}]}

class ComicsCatalogItemModel {
  ComicsCatalogItemModel({
      int? id, 
      int? pid, 
      int? episode, 
      String? title,
      int? isFree, 
      int? isTry, 
      UnlockInfoModel? payData,}){
    _id = id;
    _pid = pid;
    _episode = episode;
    _title = title;
    _isFree = isFree;
    _isTry = isTry;
    _payData = payData;
}

  ComicsCatalogItemModel.fromJson(dynamic json) {
    _id = json['id'];
    _pid = json['pid'];
    _episode = json['episode'];
    _title = json['title'];
    _isFree = json['is_free'];
    _isTry = json['is_try'];
    _payData = json['pay_data'] != null ? UnlockInfoModel.fromJson(json['pay_data']) : null;
  }
  int? _id;
  int? _pid;
  int? _episode;
  String? _title;
  int? _isFree;
  int? _isTry;
  UnlockInfoModel? _payData;
ComicsCatalogItemModel copyWith({  int? id,
  int? pid,
  int? episode,
  String? title,
  int? isFree,
  int? isTry,
  UnlockInfoModel? payData,
}) => ComicsCatalogItemModel(  id: id ?? _id,
  pid: pid ?? _pid,
  episode: episode ?? _episode,
  title: title ?? _title,
  isFree: isFree ?? _isFree,
  isTry: isTry ?? _isTry,
  payData: payData ?? _payData,
);
  int? get id => _id;
  int? get pid => _pid;
  int? get episode => _episode;
  String? get title => _title;
  int? get isFree => _isFree;
  int? get isTry => _isTry;
  UnlockInfoModel? get payData => _payData;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = _id;
    map['pid'] = _pid;
    map['episode'] = _episode;
    map['title'] = _title;
    map['is_free'] = _isFree;
    map['is_try'] = _isTry;
    if (_payData != null) {
      map['pay_data'] = _payData?.toJson();
    }
    return map;
  }

}