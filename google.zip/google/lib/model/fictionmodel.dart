// To parse this JSON data, do
//
//     final fictionModel = fictionModelFromJson(jsonString);

import 'package:meta/meta.dart';
import 'dart:convert';

FictionModel fictionModelFromJson(String str) =>
    FictionModel.fromJson(json.decode(str));

String fictionModelToJson(FictionModel data) => json.encode(data.toJson());

class FictionModel {
  FictionModel({
    required this.data,
    required this.status,
    required this.msg,
    required this.crypt,
    required this.isVv,
    required this.needLogin,
    required this.isLogin,
  });

  Data data;
  int status;
  String msg;
  bool crypt;
  bool isVv;
  bool needLogin;
  bool isLogin;

  factory FictionModel.fromJson(Map<String, dynamic> json) => FictionModel(
        data: json["data"] == null
            ? Data(ads: [], types: [], list: [])
            : Data.fromJson(json["data"]),
        status: json["status"] == null ? null : json["status"],
        msg: json["msg"] == null ? null : json["msg"],
        crypt: json["crypt"] == null ? null : json["crypt"],
        isVv: json["isVV"] == null ? null : json["isVV"],
        needLogin: json["needLogin"] == null ? null : json["needLogin"],
        isLogin: json["isLogin"] == null ? null : json["isLogin"],
      );

  Map<String, dynamic> toJson() => {
        "data": data == null ? null : data.toJson(),
        "status": status == null ? null : status,
        "msg": msg == null ? null : msg,
        "crypt": crypt == null ? null : crypt,
        "isVV": isVv == null ? null : isVv,
        "needLogin": needLogin == null ? null : needLogin,
        "isLogin": isLogin == null ? null : isLogin,
      };
}

class Data {
  Data({
    required this.ads,
    required this.types,
    required this.list,
  });

  List<Ad> ads;
  List<Type> types;
  List<DataList> list;

  factory Data.fromJson(Map<String, dynamic> json) => Data(
        ads: json["ads"] == null
            ? []
            : List<Ad>.from(json["ads"].map((x) => Ad.fromJson(x))),
        types: json["types"] == null
            ? []
            : List<Type>.from(json["types"].map((x) => Type.fromJson(x))),
        list: json["list"] == null
            ? []
            : List<DataList>.from(
                json["list"].map((x) => DataList.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "ads":
            ads == null ? [] : List<dynamic>.from(ads.map((x) => x.toJson())),
        "types": types == null
            ? []
            : List<dynamic>.from(types.map((x) => x.toJson())),
        "list":
            list == null ? [] : List<dynamic>.from(list.map((x) => x.toJson())),
      };
}

class Ad {
  Ad({
    required this.id,
    required this.title,
    required this.description,
    required this.mvM3U8,
    required this.imgUrl,
    required this.url,
    required this.type,
    required this.iosUrl,
    required this.androidUrl,
    required this.value,
  });

  int id;
  String title;
  String description;
  String mvM3U8;
  String imgUrl;
  String url;
  int type;
  String iosUrl;
  String androidUrl;
  int value;

  factory Ad.fromJson(Map<String, dynamic> json) => Ad(
        id: json["id"] == null ? null : json["id"],
        title: json["title"] == null ? null : json["title"],
        description: json["description"] == null ? null : json["description"],
        mvM3U8: json["mv_m3u8"] == null ? null : json["mv_m3u8"],
        imgUrl: json["img_url"] == null ? null : json["img_url"],
        url: json["url"] == null ? null : json["url"],
        type: json["type"] == null ? null : json["type"],
        iosUrl: json["ios_url"] == null ? null : json["ios_url"],
        androidUrl: json["android_url"] == null ? null : json["android_url"],
        value: json["value"] == null ? null : json["value"],
      );

  Map<String, dynamic> toJson() => {
        "id": id == null ? null : id,
        "title": title == null ? null : title,
        "description": description == null ? null : description,
        "mv_m3u8": mvM3U8 == null ? null : mvM3U8,
        "img_url": imgUrl == null ? null : imgUrl,
        "url": url == null ? null : url,
        "type": type == null ? null : type,
        "ios_url": iosUrl == null ? null : iosUrl,
        "android_url": androidUrl == null ? null : androidUrl,
        "value": value == null ? null : value,
      };
}

class DataList {
  DataList({
    required this.id,
    required this.name,
    required this.sort,
    required this.status,
    required this.refreshTime,
    required this.clickNum,
    required this.list,
  });

  int id;
  String name;
  int sort;
  int status;
  String refreshTime;
  int clickNum;
  List<ListList> list;

  factory DataList.fromJson(Map<String, dynamic> json) => DataList(
        id: json["id"] == null ? 0 : json["id"],
        name: json["name"] == null ? '' : json["name"],
        sort: json["sort"] == null ? null : json["sort"],
        status: json["status"] == null ? null : json["status"],
        refreshTime: json["refresh_time"] == null ? '' : json["refresh_time"],
        clickNum: json["click_num"] == null ? null : json["click_num"],
        list: json["list"] == null
            ? []
            : List<ListList>.from(
                json["list"].map((x) => ListList.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "id": id == null ? null : id,
        "name": name == null ? null : name,
        "sort": sort == null ? null : sort,
        "status": status == null ? null : status,
        "refresh_time": refreshTime == null ? '' : refreshTime,
        "click_num": clickNum == null ? null : clickNum,
        "list":
            list == null ? [] : List<dynamic>.from(list.map((x) => x.toJson())),
      };
}

class ListList {
  ListList({
    required this.listId,
    required this.id,
    required this.aff,
    required this.title,
    required this.desc,
    required this.author,
    required this.thumb,
    required this.categoryId,
    required this.tags,
    required this.isFree,
    required this.viewsCount,
    required this.favorites,
    required this.likesCount,
    required this.shareCount,
    required this.viewMoney,
    required this.downloadMoney,
    required this.freeTime,
    required this.recommend,
    required this.isHot,
    required this.type,
    required this.status,
    required this.createdAt,
    required this.updatedAt,
    required this.isShare,
  });

  int listId;
  dynamic id;
  int aff;
  String title;
  dynamic desc;
  String author;
  String thumb;
  int categoryId;
  String tags;
  int isFree;
  int viewsCount;
  int favorites;
  int likesCount;
  int shareCount;
  int viewMoney;
  int downloadMoney;
  int freeTime;
  int recommend;
  int isHot;
  int type;
  int status;
  String createdAt;
  String updatedAt;
  int isShare;

  factory ListList.fromJson(Map<String, dynamic> json) => ListList(
        listId: json["id"] == null ? null : json["id"],
        id: json["_id"],
        aff: json["aff"] == null ? null : json["aff"],
        title: json["title"] == null ? null : json["title"],
        desc: json["desc"],
        author: json["author"] == null ? null : json["author"],
        thumb: json["thumb"] == null ? null : json["thumb"],
        categoryId: json["category_id"] == null ? null : json["category_id"],
        tags: json["tags"] == null ? null : json["tags"],
        isFree: json["is_free"] == null ? null : json["is_free"],
        viewsCount: json["views_count"] == null ? null : json["views_count"],
        favorites: json["favorites"] == null ? null : json["favorites"],
        likesCount: json["likes_count"] == null ? null : json["likes_count"],
        shareCount: json["share_count"] == null ? null : json["share_count"],
        viewMoney: json["view_money"] == null ? null : json["view_money"],
        downloadMoney:
            json["download_money"] == null ? null : json["download_money"],
        freeTime: json["free_time"] == null ? null : json["free_time"],
        recommend: json["recommend"] == null ? null : json["recommend"],
        isHot: json["is_hot"] == null ? null : json["is_hot"],
        type: json["type"] == null ? null : json["type"],
        status: json["status"] == null ? null : json["status"],
        createdAt: json["created_at"] == null ? null : json["created_at"],
        updatedAt: json["updated_at"] == null ? null : json["updated_at"],
        isShare: json["is_share"] == null ? 0 : json["is_share"],
      );

  Map<String, dynamic> toJson() => {
        "id": listId == null ? null : listId,
        "_id": id,
        "aff": aff == null ? null : aff,
        "title": title == null ? null : title,
        "desc": desc,
        "author": author == null ? null : author,
        "thumb": thumb == null ? null : thumb,
        "category_id": categoryId == null ? null : categoryId,
        "tags": tags == null ? null : tags,
        "is_free": isFree == null ? null : isFree,
        "views_count": viewsCount == null ? null : viewsCount,
        "favorites": favorites == null ? null : favorites,
        "likes_count": likesCount == null ? null : likesCount,
        "share_count": shareCount == null ? null : shareCount,
        "view_money": viewMoney == null ? null : viewMoney,
        "download_money": downloadMoney == null ? null : downloadMoney,
        "free_time": freeTime == null ? null : freeTime,
        "recommend": recommend == null ? null : recommend,
        "is_hot": isHot == null ? null : isHot,
        "type": type == null ? null : type,
        "status": status == null ? null : status,
        "created_at": createdAt == null ? null : createdAt,
        "updated_at": updatedAt == null ? null : updatedAt,
        "is_share": isShare == null ? 0 : isShare,
      };
}

class Type {
  Type({
    required this.id,
    required this.name,
  });

  int id;
  String name;

  factory Type.fromJson(Map<String, dynamic> json) => Type(
        id: json["id"] == null ? null : json["id"],
        name: json["name"] == null ? null : json["name"],
      );

  Map<String, dynamic> toJson() => {
        "id": id == null ? null : id,
        "name": name == null ? null : name,
      };
}
