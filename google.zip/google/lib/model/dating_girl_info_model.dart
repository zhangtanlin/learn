import 'package:iaimei/model/unlock_info_model.dart';

/// id : 8266
/// uid : 0
/// title : "精品高端外围"
/// type : 3
/// thumb : "/new/ads/20220518/2022051815311270610.jpeg"
/// city_code : 440100
/// city_name : "广州市"
/// girl_age : 20
/// girl_height : 171
/// girl_weight : 50
/// girl_cup : "E"
/// girl_price : "3000"
/// girl_service_type : "69 浴洗 舌吻 吹箫"
/// girl_consume : ""
/// girl_business_hours : "12:00-24:00"
/// girl_tags : "清纯,长腿"
/// girl_pics : "/new/ads/20220518/2022051815330261316.jpeg,/new/ads/20220518/2022051815330529956.jpeg"
/// desc : "全国一二三线城市均可安排可空降伴游，网红 萝莉 御姐 空姐 孕妇 洋酒 少妇 姐妹 教师等"
/// buy_original_price : 0
/// buy_price : 200
/// buy_num : 0
/// contact : ""
/// address : ""
/// status : 1
/// created_at : "2022-05-24 07:29:25"
/// updated_at : "0000-00-00 00:00:00"
/// is_peifu : 0
/// is_recommed : 1
/// is_feature : 1
/// m3u8 : ""
/// type_str : "外围"
/// status_str : "上架"
/// auth_str : "未知"
/// thumb_url : "https://new.ygneivl.cn/new/ads/20220518/2022051815311270610.jpeg"
/// girl_sex_str : "未知"
/// girl_pics_url : ["https://new.ygneivl.cn/new/ads/20220518/2022051815330261316.jpeg","https://new.ygneivl.cn/new/ads/20220518/2022051815330529956.jpeg"]
/// is_recommed_str : "是"
/// is_feature_str : "是"
/// is_peifu_str : "否"
/// is_like : 0
/// is_pay : 0
/// pay_data : {"resource_coins":"200","resource_g_coins":"0","resource_type":2,"is_vip":false,"is_pay":0,"free":2,"user_coins":"0.00","user_g_coins":"0","user_times":0,"pay_way":[{"type":"resource_coins","name":"当前余额:0.00"}]}
/// m3u8_full : ""
/// member : null

class DatingGirlInfoModel {
  DatingGirlInfoModel({
    int? id,
    int? uid,
    String? title,
    int? type,
    String? thumb,
    int? cityCode,
    String? cityName,
    int? girlAge,
    int? girlHeight,
    int? girlWeight,
    String? girlCup,
    String? girlPrice,
    String? girlServiceType,
    String? girlConsume,
    String? girlBusinessHours,
    String? girlTags,
    String? girlPics,
    String? desc,
    int? buyOriginalPrice,
    int? buyPrice,
    int? buyNum,
    String? contact,
    String? address,
    int? status,
    String? createdAt,
    String? updatedAt,
    int? isPeifu,
    int? isRecommed,
    int? isFeature,
    String? m3u8,
    String? typeStr,
    String? statusStr,
    String? authStr,
    String? thumbUrl,
    String? girlSexStr,
    List<String>? girlPicsUrl,
    String? isRecommedStr,
    String? isFeatureStr,
    String? isPeifuStr,
    int? isLike,
    int? isPay,
    UnlockInfoModel? payData,
    String? m3u8Full,
    dynamic member,
  }) {
    _id = id;
    _uid = uid;
    _title = title;
    _type = type;
    _thumb = thumb;
    _cityCode = cityCode;
    _cityName = cityName;
    _girlAge = girlAge;
    _girlHeight = girlHeight;
    _girlWeight = girlWeight;
    _girlCup = girlCup;
    _girlPrice = girlPrice;
    _girlServiceType = girlServiceType;
    _girlConsume = girlConsume;
    _girlBusinessHours = girlBusinessHours;
    _girlTags = girlTags;
    _girlPics = girlPics;
    _desc = desc;
    _buyOriginalPrice = buyOriginalPrice;
    _buyPrice = buyPrice;
    _buyNum = buyNum;
    _contact = contact;
    _address = address;
    _status = status;
    _createdAt = createdAt;
    _updatedAt = updatedAt;
    _isPeifu = isPeifu;
    _isRecommed = isRecommed;
    _isFeature = isFeature;
    _m3u8 = m3u8;
    _typeStr = typeStr;
    _statusStr = statusStr;
    _authStr = authStr;
    _thumbUrl = thumbUrl;
    _girlSexStr = girlSexStr;
    _girlPicsUrl = girlPicsUrl;
    _isRecommedStr = isRecommedStr;
    _isFeatureStr = isFeatureStr;
    _isPeifuStr = isPeifuStr;
    _isLike = isLike;
    _isPay = isPay;
    _payData = payData;
    _m3u8Full = m3u8Full;
    _member = member;
  }

  DatingGirlInfoModel.fromJson(dynamic json) {
    _id = json['id'];
    _uid = json['uid'];
    _title = json['title'];
    _type = json['type'];
    _thumb = json['thumb'];
    _cityCode = json['city_code'];
    _cityName = json['city_name'];
    _girlAge = json['girl_age'];
    _girlHeight = json['girl_height'];
    _girlWeight = json['girl_weight'];
    _girlCup = json['girl_cup'];
    _girlPrice = json['girl_price'];
    _girlServiceType = json['girl_service_type'];
    _girlConsume = json['girl_consume'];
    _girlBusinessHours = json['girl_business_hours'];
    _girlTags = json['girl_tags'];
    _girlPics = json['girl_pics'];
    _desc = json['desc'];
    _buyOriginalPrice = json['buy_original_price'];
    _buyPrice = json['buy_price'];
    _buyNum = json['buy_num'];
    _contact = json['contact'];
    _address = json['address'];
    _status = json['status'];
    _createdAt = json['created_at'];
    _updatedAt = json['updated_at'];
    _isPeifu = json['is_peifu'];
    _isRecommed = json['is_recommed'];
    _isFeature = json['is_feature'];
    _m3u8 = json['m3u8'];
    _typeStr = json['type_str'];
    _statusStr = json['status_str'];
    _authStr = json['auth_str'];
    _thumbUrl = json['thumb_url'];
    _girlSexStr = json['girl_sex_str'];
    _girlPicsUrl = json['girl_pics_url'] != null
        ? json['girl_pics_url'].cast<String>()
        : [];
    _isRecommedStr = json['is_recommed_str'];
    _isFeatureStr = json['is_feature_str'];
    _isPeifuStr = json['is_peifu_str'];
    _isLike = json['is_like'];
    _isPay = json['is_pay'];
    _payData = json['pay_data'] != null
        ? UnlockInfoModel.fromJson(json['pay_data'])
        : null;
    _m3u8Full = json['m3u8_full'];
    _member = json['member'];
  }

  int? _id;
  int? _uid;
  String? _title;
  int? _type;
  String? _thumb;
  int? _cityCode;
  String? _cityName;
  int? _girlAge;
  int? _girlHeight;
  int? _girlWeight;
  String? _girlCup;
  String? _girlPrice;
  String? _girlServiceType;
  String? _girlConsume;
  String? _girlBusinessHours;
  String? _girlTags;
  String? _girlPics;
  String? _desc;
  int? _buyOriginalPrice;
  int? _buyPrice;
  int? _buyNum;
  String? _contact;
  String? _address;
  int? _status;
  String? _createdAt;
  String? _updatedAt;
  int? _isPeifu;
  int? _isRecommed;
  int? _isFeature;
  String? _m3u8;
  String? _typeStr;
  String? _statusStr;
  String? _authStr;
  String? _thumbUrl;
  String? _girlSexStr;
  List<String>? _girlPicsUrl;
  String? _isRecommedStr;
  String? _isFeatureStr;
  String? _isPeifuStr;
  int? _isLike;
  int? _isPay;
  UnlockInfoModel? _payData;
  String? _m3u8Full;
  dynamic _member;

  DatingGirlInfoModel copyWith({
    int? id,
    int? uid,
    String? title,
    int? type,
    String? thumb,
    int? cityCode,
    String? cityName,
    int? girlAge,
    int? girlHeight,
    int? girlWeight,
    String? girlCup,
    String? girlPrice,
    String? girlServiceType,
    String? girlConsume,
    String? girlBusinessHours,
    String? girlTags,
    String? girlPics,
    String? desc,
    int? buyOriginalPrice,
    int? buyPrice,
    int? buyNum,
    String? contact,
    String? address,
    int? status,
    String? createdAt,
    String? updatedAt,
    int? isPeifu,
    int? isRecommed,
    int? isFeature,
    String? m3u8,
    String? typeStr,
    String? statusStr,
    String? authStr,
    String? thumbUrl,
    String? girlSexStr,
    List<String>? girlPicsUrl,
    String? isRecommedStr,
    String? isFeatureStr,
    String? isPeifuStr,
    int? isLike,
    int? isPay,
    UnlockInfoModel? payData,
    String? m3u8Full,
    dynamic member,
  }) =>
      DatingGirlInfoModel(
        id: id ?? _id,
        uid: uid ?? _uid,
        title: title ?? _title,
        type: type ?? _type,
        thumb: thumb ?? _thumb,
        cityCode: cityCode ?? _cityCode,
        cityName: cityName ?? _cityName,
        girlAge: girlAge ?? _girlAge,
        girlHeight: girlHeight ?? _girlHeight,
        girlWeight: girlWeight ?? _girlWeight,
        girlCup: girlCup ?? _girlCup,
        girlPrice: girlPrice ?? _girlPrice,
        girlServiceType: girlServiceType ?? _girlServiceType,
        girlConsume: girlConsume ?? _girlConsume,
        girlBusinessHours: girlBusinessHours ?? _girlBusinessHours,
        girlTags: girlTags ?? _girlTags,
        girlPics: girlPics ?? _girlPics,
        desc: desc ?? _desc,
        buyOriginalPrice: buyOriginalPrice ?? _buyOriginalPrice,
        buyPrice: buyPrice ?? _buyPrice,
        buyNum: buyNum ?? _buyNum,
        contact: contact ?? _contact,
        address: address ?? _address,
        status: status ?? _status,
        createdAt: createdAt ?? _createdAt,
        updatedAt: updatedAt ?? _updatedAt,
        isPeifu: isPeifu ?? _isPeifu,
        isRecommed: isRecommed ?? _isRecommed,
        isFeature: isFeature ?? _isFeature,
        m3u8: m3u8 ?? _m3u8,
        typeStr: typeStr ?? _typeStr,
        statusStr: statusStr ?? _statusStr,
        authStr: authStr ?? _authStr,
        thumbUrl: thumbUrl ?? _thumbUrl,
        girlSexStr: girlSexStr ?? _girlSexStr,
        girlPicsUrl: girlPicsUrl ?? _girlPicsUrl,
        isRecommedStr: isRecommedStr ?? _isRecommedStr,
        isFeatureStr: isFeatureStr ?? _isFeatureStr,
        isPeifuStr: isPeifuStr ?? _isPeifuStr,
        isLike: isLike ?? _isLike,
        isPay: isPay ?? _isPay,
        payData: payData ?? _payData,
        m3u8Full: m3u8Full ?? _m3u8Full,
        member: member ?? _member,
      );

  int? get id => _id;

  int? get uid => _uid;

  String? get title => _title;

  int? get type => _type;

  String? get thumb => _thumb;

  int? get cityCode => _cityCode;

  String? get cityName => _cityName;

  int? get girlAge => _girlAge;

  int? get girlHeight => _girlHeight;

  int? get girlWeight => _girlWeight;

  String? get girlCup => _girlCup;

  String? get girlPrice => _girlPrice;

  String? get girlServiceType => _girlServiceType;

  String? get girlConsume => _girlConsume;

  String? get girlBusinessHours => _girlBusinessHours;

  String? get girlTags => _girlTags;

  String? get girlPics => _girlPics;

  String? get desc => _desc;

  int? get buyOriginalPrice => _buyOriginalPrice;

  int? get buyPrice => _buyPrice;

  int? get buyNum => _buyNum;

  String? get contact => _contact;

  String? get address => _address;

  int? get status => _status;

  set setStatus(int value) => _status = value;

  String? get createdAt => _createdAt;

  String? get updatedAt => _updatedAt;

  int? get isPeifu => _isPeifu;

  int? get isRecommed => _isRecommed;

  int? get isFeature => _isFeature;

  String? get m3u8 => _m3u8;

  String? get typeStr => _typeStr;

  String? get statusStr => _statusStr;

  String? get authStr => _authStr;

  String? get thumbUrl => _thumbUrl;

  String? get girlSexStr => _girlSexStr;

  List<String>? get girlPicsUrl => _girlPicsUrl;

  String? get isRecommedStr => _isRecommedStr;

  String? get isFeatureStr => _isFeatureStr;

  String? get isPeifuStr => _isPeifuStr;

  int? get isLike => _isLike;

  int? get isPay => _isPay;

  UnlockInfoModel? get payData => _payData;

  String? get m3u8Full => _m3u8Full;

  dynamic get member => _member;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = _id;
    map['uid'] = _uid;
    map['title'] = _title;
    map['type'] = _type;
    map['thumb'] = _thumb;
    map['city_code'] = _cityCode;
    map['city_name'] = _cityName;
    map['girl_age'] = _girlAge;
    map['girl_height'] = _girlHeight;
    map['girl_weight'] = _girlWeight;
    map['girl_cup'] = _girlCup;
    map['girl_price'] = _girlPrice;
    map['girl_service_type'] = _girlServiceType;
    map['girl_consume'] = _girlConsume;
    map['girl_business_hours'] = _girlBusinessHours;
    map['girl_tags'] = _girlTags;
    map['girl_pics'] = _girlPics;
    map['desc'] = _desc;
    map['buy_original_price'] = _buyOriginalPrice;
    map['buy_price'] = _buyPrice;
    map['buy_num'] = _buyNum;
    map['contact'] = _contact;
    map['address'] = _address;
    map['status'] = _status;
    map['created_at'] = _createdAt;
    map['updated_at'] = _updatedAt;
    map['is_peifu'] = _isPeifu;
    map['is_recommed'] = _isRecommed;
    map['is_feature'] = _isFeature;
    map['m3u8'] = _m3u8;
    map['type_str'] = _typeStr;
    map['status_str'] = _statusStr;
    map['auth_str'] = _authStr;
    map['thumb_url'] = _thumbUrl;
    map['girl_sex_str'] = _girlSexStr;
    map['girl_pics_url'] = _girlPicsUrl;
    map['is_recommed_str'] = _isRecommedStr;
    map['is_feature_str'] = _isFeatureStr;
    map['is_peifu_str'] = _isPeifuStr;
    map['is_like'] = _isLike;
    map['is_pay'] = _isPay;
    if (_payData != null) {
      map['pay_data'] = _payData?.toJson();
    }
    map['m3u8_full'] = _m3u8Full;
    map['member'] = _member;
    return map;
  }
}
