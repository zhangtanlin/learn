class RewardSet {
  RewardSet({
    String? name,
    String? value,
    String? gid,}){
    _name = name;
    _value = value;
    _gid = gid;
  }

  RewardSet.fromJson(dynamic json) {
    _name = json['name'];
    _value = json['value'];
    _gid = json['gid'];
  }
  String? _name;
  String? _value;
  String? _gid;
  RewardSet copyWith({  String? name,
    String? value,
    String? gid,
  }) => RewardSet(  name: name ?? _name,
    value: value ?? _value,
    gid: gid ?? _gid,
  );
  String? get name => _name;
  String? get value => _value;
  String? get gid => _gid;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['name'] = _name;
    map['value'] = _value;
    map['gid'] = _gid;
    return map;
  }

}