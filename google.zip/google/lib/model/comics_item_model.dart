/// id : 67354
/// title : "[自家発電処 (flanvia)] 僕は友達の妹を金で買った[DL版][64P]"
/// description : ""
/// category_id : 13
/// bg_thumb : ""
/// thumb : "https://new.tthykps.cn/new/ads/20220215/2022021516401844248.jpeg"
/// favorites : 0
/// view_money : 1
/// status : 1
/// update_time : "完结"
/// recommend : 0
/// obtained : 1
/// is_type : 0
/// refresh_at : "2022-03-22 13:23:31"
/// view_count : 0
/// tags : ""
/// img_url_full : "https://new.tthykps.cn/new/ads/20220215/2022021516401844248.jpeg"
/// category_name : "2号系列"

class ComicsItemModel {
  ComicsItemModel({
      int? id, 
      String? title, 
      String? description, 
      int? categoryId, 
      String? bgThumb, 
      String? thumb, 
      int? favorites, 
      int? viewMoney, 
      int? status, 
      String? updateTime, 
      int? recommend, 
      int? obtained, 
      int? isType, 
      String? refreshAt, 
      int? viewCount, 
      String? tags, 
      String? imgUrlFull, 
      String? categoryName,}){
    _id = id;
    _title = title;
    _description = description;
    _categoryId = categoryId;
    _bgThumb = bgThumb;
    _thumb = thumb;
    _favorites = favorites;
    _viewMoney = viewMoney;
    _status = status;
    _updateTime = updateTime;
    _recommend = recommend;
    _obtained = obtained;
    _isType = isType;
    _refreshAt = refreshAt;
    _viewCount = viewCount;
    _tags = tags;
    _imgUrlFull = imgUrlFull;
    _categoryName = categoryName;
}

  ComicsItemModel.fromJson(dynamic json) {
    _id = json['id'];
    _title = json['title'];
    _description = json['description'];
    _categoryId = json['category_id'];
    _bgThumb = json['bg_thumb'];
    _thumb = json['thumb'];
    _favorites = json['favorites'];
    _viewMoney = json['view_money'];
    _status = json['status'];
    _updateTime = json['update_time'];
    _recommend = json['recommend'];
    _obtained = json['obtained'];
    _isType = json['is_type'];
    _refreshAt = json['refresh_at'];
    _viewCount = json['view_count'];
    _tags = json['tags'];
    // _imgUrlFull = json['img_url_full'];
    _imgUrlFull = json['thumb_full'];
    _categoryName = json['category_name'];
  }
  int? _id;
  String? _title;
  String? _description;
  int? _categoryId;
  String? _bgThumb;
  String? _thumb;
  int? _favorites;
  int? _viewMoney;
  int? _status;
  String? _updateTime;
  int? _recommend;
  int? _obtained;
  int? _isType;
  String? _refreshAt;
  int? _viewCount;
  String? _tags;
  String? _imgUrlFull;
  String? _categoryName;
ComicsItemModel copyWith({  int? id,
  String? title,
  String? description,
  int? categoryId,
  String? bgThumb,
  String? thumb,
  int? favorites,
  int? viewMoney,
  int? status,
  String? updateTime,
  int? recommend,
  int? obtained,
  int? isType,
  String? refreshAt,
  int? viewCount,
  String? tags,
  String? imgUrlFull,
  String? categoryName,
}) => ComicsItemModel(  id: id ?? _id,
  title: title ?? _title,
  description: description ?? _description,
  categoryId: categoryId ?? _categoryId,
  bgThumb: bgThumb ?? _bgThumb,
  thumb: thumb ?? _thumb,
  favorites: favorites ?? _favorites,
  viewMoney: viewMoney ?? _viewMoney,
  status: status ?? _status,
  updateTime: updateTime ?? _updateTime,
  recommend: recommend ?? _recommend,
  obtained: obtained ?? _obtained,
  isType: isType ?? _isType,
  refreshAt: refreshAt ?? _refreshAt,
  viewCount: viewCount ?? _viewCount,
  tags: tags ?? _tags,
  imgUrlFull: imgUrlFull ?? _imgUrlFull,
  categoryName: categoryName ?? _categoryName,
);
  int? get id => _id;
  String? get title => _title;
  String? get description => _description;
  int? get categoryId => _categoryId;
  String? get bgThumb => _bgThumb;
  String? get thumb => _thumb;
  int? get favorites => _favorites;
  int? get viewMoney => _viewMoney;
  int? get status => _status;
  String? get updateTime => _updateTime;
  int? get recommend => _recommend;
  int? get obtained => _obtained;
  int? get isType => _isType;
  String? get refreshAt => _refreshAt;
  int? get viewCount => _viewCount;
  String? get tags => _tags;
  String? get imgUrlFull => _imgUrlFull;
  String? get categoryName => _categoryName;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = _id;
    map['title'] = _title;
    map['description'] = _description;
    map['category_id'] = _categoryId;
    map['bg_thumb'] = _bgThumb;
    map['thumb'] = _thumb;
    map['favorites'] = _favorites;
    map['view_money'] = _viewMoney;
    map['status'] = _status;
    map['update_time'] = _updateTime;
    map['recommend'] = _recommend;
    map['obtained'] = _obtained;
    map['is_type'] = _isType;
    map['refresh_at'] = _refreshAt;
    map['view_count'] = _viewCount;
    map['tags'] = _tags;
    // map['img_url_full'] = _imgUrlFull;
    map['thumb_full'] = _imgUrlFull;
    map['category_name'] = _categoryName;
    return map;
  }

}