class AuthPreModel {
  dynamic bail;
  double coins = 0.00;
  String upload = '';
  String contact = '';
  String tips = '';
  String verifyCode = '';
  int maxVideo = 1;
  int maxImage = 5;

  AuthPreModel();
  AuthPreModel.fromJsom(Map<String, dynamic> json) {
    bail = json['bail'];
    coins = double.parse(json['coins'] ?? '0.00');
    maxVideo = json['max_video'] ?? 1;
    maxImage = json['max_image'] ?? 1;
    verifyCode = '${json['verify_code']}';

    var rule = json['rule_text'];
    if (rule != null && rule is List) {
      for (var item in rule) {
        switch (item['key']) {
          case 'upload':
            upload = item['value'] ?? '';
            break;
          case 'contact':
            contact = item['value'] ?? '';
            break;
          case 'tips':
            tips = item['value'] ?? '';
            break;
          default:
        }
      }
    }
  }
}