import 'dart:convert';

Cardmodel cardmodelFromJson(String str) => Cardmodel.fromJson(json.decode(str));

String cardmodelToJson(Cardmodel data) => json.encode(data.toJson());

class Cardmodel {
  Cardmodel({
    required this.id,
    required this.uid,
    required this.coins,
    required this.title,
    required this.duration,
    required this.thumbWidth,
    required this.thumbHeight,
    required this.rating,
    required this.refreshAt,
    required this.isFree,
    required this.like,
    required this.comment,
    required this.status,
    required this.thumbStartTime,
    required this.thumbDuration,
    required this.isHide,
    required this.isRecommend,
    required this.isFeature,
    required this.isTop,
    required this.countPay,
    required this.type,
    required this.playUrl,
    required this.tagsList,
    required this.coverThumbUrl,
    required this.createdStr,
    required this.isLike,
    required this.durationStr,
    required this.isPay,
    required this.user,
  });

  int id;
  int uid;
  int coins;
  String title;
  int duration;
  int thumbWidth;
  int thumbHeight;
  int rating;
  int refreshAt;
  int isFree;
  int like;
  int comment;
  int status;
  int thumbStartTime;
  int thumbDuration;
  int isHide;
  int isRecommend;
  int isFeature;
  int isTop;
  int countPay;
  int type;
  String playUrl;
  List<String> tagsList;
  String coverThumbUrl;
  DateTime createdStr;
  int isLike;
  String durationStr;
  int isPay;
  User user;

  factory Cardmodel.fromJson(Map<String, dynamic> json) => Cardmodel(
        id: json["id"],
        uid: json["uid"],
        coins: json["coins"],
        title: json["title"],
        duration: json["duration"],
        thumbWidth: json["thumb_width"],
        thumbHeight: json["thumb_height"],
        rating: json["rating"],
        refreshAt: json["refresh_at"],
        isFree: json["is_free"],
        like: json["like"],
        comment: json["comment"],
        status: json["status"],
        thumbStartTime: json["thumb_start_time"],
        thumbDuration: json["thumb_duration"],
        isHide: json["is_hide"],
        isRecommend: json["is_recommend"],
        isFeature: json["is_feature"],
        isTop: json["is_top"],
        countPay: json["count_pay"],
        type: json["type"],
        playUrl: json["play_url"],
        tagsList: List<String>.from(json["tags_list"].map((x) => x)),
        coverThumbUrl: json["cover_thumb_url"],
        createdStr: DateTime.parse(json["created_str"]),
        isLike: json["is_like"],
        durationStr: json["duration_str"],
        isPay: json["is_pay"],
        user: User.fromJson(json["user"]),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "uid": uid,
        "coins": coins,
        "title": title,
        "duration": duration,
        "thumb_width": thumbWidth,
        "thumb_height": thumbHeight,
        "rating": rating,
        "refresh_at": refreshAt,
        "is_free": isFree,
        "like": like,
        "comment": comment,
        "status": status,
        "thumb_start_time": thumbStartTime,
        "thumb_duration": thumbDuration,
        "is_hide": isHide,
        "is_recommend": isRecommend,
        "is_feature": isFeature,
        "is_top": isTop,
        "count_pay": countPay,
        "type": type,
        "play_url": playUrl,
        "tags_list": List<dynamic>.from(tagsList.map((x) => x)),
        "cover_thumb_url": coverThumbUrl,
        "created_str": createdStr.toIso8601String(),
        "is_like": isLike,
        "duration_str": durationStr,
        "is_pay": isPay,
        "user": user.toJson(),
      };
}

class User {
  User({
    required this.uid,
    required this.nickname,
    required this.vipLevel,
    required this.sexType,
    required this.expiredAt,
    required this.aff,
    required this.avatarUrl,
    required this.expiredStr,
    required this.isVip,
    required this.isAttention,
  });

  int uid;
  String nickname;
  int vipLevel;
  int sexType;
  int expiredAt;
  int aff;
  String avatarUrl;
  String expiredStr;
  int isVip;
  int isAttention;

  factory User.fromJson(Map<String, dynamic> json) => User(
        uid: json["uid"],
        nickname: json["nickname"],
        vipLevel: json["vip_level"],
        sexType: json["sexType"],
        expiredAt: json["expired_at"],
        aff: json["aff"],
        avatarUrl: json["avatar_url"],
        expiredStr: json["expired_str"],
        isVip: json["is_vip"],
        isAttention: json["is_attention"],
      );

  Map<String, dynamic> toJson() => {
        "uid": uid,
        "nickname": nickname,
        "vip_level": vipLevel,
        "sexType": sexType,
        "expired_at": expiredAt,
        "aff": aff,
        "avatar_url": avatarUrl,
        "expired_str": expiredStr,
        "is_vip": isVip,
        "is_attention": isAttention,
      };
}
