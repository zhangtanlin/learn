/// hot_city : [{"id":110100,"areaname":"北京"},{"id":510100,"areaname":"成都"},{"id":500100,"areaname":"重庆"},{"id":330100,"areaname":"杭州"}]
/// all_city : [{"id":110100,"areaname":"北京市"},{"id":120100,"areaname":"天津市"},{"id":130100,"areaname":"石家庄市"},{"id":130200,"areaname":"唐山市"},{"id":130300,"areaname":"秦皇岛市"},{"id":130400,"areaname":"邯郸市"},{"id":130500,"areaname":"邢台市"},{"id":130600,"areaname":"保定市"},{"id":130700,"areaname":"张家口市"},{"id":130800,"areaname":"承德市"},{"id":130900,"areaname":"沧州市"},{"id":131000,"areaname":"廊坊市"},{"id":131100,"areaname":"衡水市"},{"id":140100,"areaname":"太原市"},{"id":140200,"areaname":"大同市"},{"id":140300,"areaname":"阳泉市"},{"id":140400,"areaname":"长治市"},{"id":140500,"areaname":"晋城市"},{"id":140600,"areaname":"朔州市"},{"id":140700,"areaname":"晋中市"},{"id":140800,"areaname":"运城市"},{"id":140900,"areaname":"忻州市"},{"id":141000,"areaname":"临汾市"},{"id":141100,"areaname":"吕梁市"},{"id":150100,"areaname":"呼和浩特市"},{"id":150200,"areaname":"包头市"},{"id":150300,"areaname":"乌海市"},{"id":150400,"areaname":"赤峰市"},{"id":150500,"areaname":"通辽市"},{"id":150600,"areaname":"鄂尔多斯市"},{"id":150700,"areaname":"呼伦贝尔市"},{"id":150800,"areaname":"巴彦淖尔市"},{"id":150900,"areaname":"乌兰察布市"},{"id":152200,"areaname":"兴安盟"},{"id":152500,"areaname":"锡林郭勒盟"},{"id":152900,"areaname":"阿拉善盟"},{"id":210100,"areaname":"沈阳市"},{"id":210200,"areaname":"大连市"},{"id":210300,"areaname":"鞍山市"},{"id":210400,"areaname":"抚顺市"},{"id":210500,"areaname":"本溪市"},{"id":210600,"areaname":"丹东市"},{"id":210700,"areaname":"锦州市"},{"id":210800,"areaname":"营口市"},{"id":210900,"areaname":"阜新市"},{"id":211000,"areaname":"辽阳市"},{"id":211100,"areaname":"盘锦市"},{"id":211200,"areaname":"铁岭市"},{"id":211300,"areaname":"朝阳市"},{"id":211400,"areaname":"葫芦岛市"},{"id":220100,"areaname":"长春市"},{"id":220200,"areaname":"吉林市"},{"id":220300,"areaname":"四平市"},{"id":220400,"areaname":"辽源市"},{"id":220500,"areaname":"通化市"},{"id":220600,"areaname":"白山市"},{"id":220700,"areaname":"松原市"},{"id":220800,"areaname":"白城市"},{"id":222400,"areaname":"延边朝鲜族自治州"},{"id":230100,"areaname":"哈尔滨市"},{"id":230200,"areaname":"齐齐哈尔市"},{"id":230300,"areaname":"鸡西市"},{"id":230400,"areaname":"鹤岗市"},{"id":230500,"areaname":"双鸭山市"},{"id":230600,"areaname":"大庆市"},{"id":230700,"areaname":"伊春市"},{"id":230800,"areaname":"佳木斯市"},{"id":230900,"areaname":"七台河市"},{"id":231000,"areaname":"牡丹江市"},{"id":231100,"areaname":"黑河市"},{"id":231200,"areaname":"绥化市"},{"id":232700,"areaname":"大兴安岭地区"},{"id":310100,"areaname":"上海市"},{"id":320100,"areaname":"南京市"},{"id":320200,"areaname":"无锡市"},{"id":320300,"areaname":"徐州市"},{"id":320400,"areaname":"常州市"},{"id":320500,"areaname":"苏州市"},{"id":320600,"areaname":"南通市"},{"id":320700,"areaname":"连云港市"},{"id":320800,"areaname":"淮安市"},{"id":320900,"areaname":"盐城市"},{"id":321000,"areaname":"扬州市"},{"id":321100,"areaname":"镇江市"},{"id":321200,"areaname":"泰州市"},{"id":321300,"areaname":"宿迁市"},{"id":330100,"areaname":"杭州市"},{"id":330200,"areaname":"宁波市"},{"id":330300,"areaname":"温州市"},{"id":330400,"areaname":"嘉兴市"},{"id":330500,"areaname":"湖州市"},{"id":330600,"areaname":"绍兴市"},{"id":330700,"areaname":"金华市"},{"id":330800,"areaname":"衢州市"},{"id":330900,"areaname":"舟山市"},{"id":331000,"areaname":"台州市"},{"id":331100,"areaname":"丽水市"},{"id":340100,"areaname":"合肥市"},{"id":340200,"areaname":"芜湖市"},{"id":340300,"areaname":"蚌埠市"},{"id":340400,"areaname":"淮南市"},{"id":340500,"areaname":"马鞍山市"},{"id":340600,"areaname":"淮北市"},{"id":340700,"areaname":"铜陵市"},{"id":340800,"areaname":"安庆市"},{"id":341000,"areaname":"黄山市"},{"id":341100,"areaname":"滁州市"},{"id":341200,"areaname":"阜阳市"},{"id":341300,"areaname":"宿州市"},{"id":341500,"areaname":"六安市"},{"id":341600,"areaname":"亳州市"},{"id":341700,"areaname":"池州市"},{"id":341800,"areaname":"宣城市"},{"id":350100,"areaname":"福州市"},{"id":350200,"areaname":"厦门市"},{"id":350300,"areaname":"莆田市"},{"id":350400,"areaname":"三明市"},{"id":350500,"areaname":"泉州市"},{"id":350600,"areaname":"漳州市"},{"id":350700,"areaname":"南平市"},{"id":350800,"areaname":"龙岩市"},{"id":350900,"areaname":"宁德市"},{"id":360100,"areaname":"南昌市"},{"id":360200,"areaname":"景德镇市"},{"id":360300,"areaname":"萍乡市"},{"id":360400,"areaname":"九江市"},{"id":360500,"areaname":"新余市"},{"id":360600,"areaname":"鹰潭市"},{"id":360700,"areaname":"赣州市"},{"id":360800,"areaname":"吉安市"},{"id":360900,"areaname":"宜春市"},{"id":361000,"areaname":"抚州市"},{"id":361100,"areaname":"上饶市"},{"id":370100,"areaname":"济南市"},{"id":370200,"areaname":"青岛市"},{"id":370300,"areaname":"淄博市"},{"id":370400,"areaname":"枣庄市"},{"id":370500,"areaname":"东营市"},{"id":370600,"areaname":"烟台市"},{"id":370700,"areaname":"潍坊市"},{"id":370800,"areaname":"济宁市"},{"id":370900,"areaname":"泰安市"},{"id":371000,"areaname":"威海市"},{"id":371100,"areaname":"日照市"},{"id":371200,"areaname":"莱芜市"},{"id":371300,"areaname":"临沂市"},{"id":371400,"areaname":"德州市"},{"id":371500,"areaname":"聊城市"},{"id":371600,"areaname":"滨州市"},{"id":371700,"areaname":"菏泽市"},{"id":410100,"areaname":"郑州市"},{"id":410200,"areaname":"开封市"},{"id":410300,"areaname":"洛阳市"},{"id":410400,"areaname":"平顶山市"},{"id":410500,"areaname":"安阳市"},{"id":410600,"areaname":"鹤壁市"},{"id":410700,"areaname":"新乡市"},{"id":410800,"areaname":"焦作市"},{"id":410881,"areaname":"济源市"},{"id":410900,"areaname":"濮阳市"},{"id":411000,"areaname":"许昌市"},{"id":411100,"areaname":"漯河市"},{"id":411200,"areaname":"三门峡市"},{"id":411300,"areaname":"南阳市"},{"id":411400,"areaname":"商丘市"},{"id":411500,"areaname":"信阳市"},{"id":411600,"areaname":"周口市"},{"id":411700,"areaname":"驻马店市"},{"id":420100,"areaname":"武汉市"},{"id":420200,"areaname":"黄石市"},{"id":420300,"areaname":"十堰市"},{"id":420500,"areaname":"宜昌市"},{"id":420600,"areaname":"襄阳市"},{"id":420700,"areaname":"鄂州市"},{"id":420800,"areaname":"荆门市"},{"id":420900,"areaname":"孝感市"},{"id":421000,"areaname":"荆州市"},{"id":421100,"areaname":"黄冈市"},{"id":421200,"areaname":"咸宁市"},{"id":421300,"areaname":"随州市"},{"id":422800,"areaname":"恩施土家族苗族自治州"},{"id":429004,"areaname":"仙桃市"},{"id":429005,"areaname":"潜江市"},{"id":429006,"areaname":"天门市"},{"id":429021,"areaname":"神农架林区"},{"id":430100,"areaname":"长沙市"},{"id":430200,"areaname":"株洲市"},{"id":430300,"areaname":"湘潭市"},{"id":430400,"areaname":"衡阳市"},{"id":430500,"areaname":"邵阳市"},{"id":430600,"areaname":"岳阳市"},{"id":430700,"areaname":"常德市"},{"id":430800,"areaname":"张家界市"},{"id":430900,"areaname":"益阳市"},{"id":431000,"areaname":"郴州市"},{"id":431100,"areaname":"永州市"},{"id":431200,"areaname":"怀化市"},{"id":431300,"areaname":"娄底市"},{"id":433100,"areaname":"湘西土家族苗族自治州"},{"id":440100,"areaname":"广州市"},{"id":440200,"areaname":"韶关市"},{"id":440300,"areaname":"深圳市"},{"id":440400,"areaname":"珠海市"},{"id":440500,"areaname":"汕头市"},{"id":440600,"areaname":"佛山市"},{"id":440700,"areaname":"江门市"},{"id":440800,"areaname":"湛江市"},{"id":440900,"areaname":"茂名市"},{"id":441200,"areaname":"肇庆市"},{"id":441300,"areaname":"惠州市"},{"id":441400,"areaname":"梅州市"},{"id":441500,"areaname":"汕尾市"},{"id":441600,"areaname":"河源市"},{"id":441700,"areaname":"阳江市"},{"id":441800,"areaname":"清远市"},{"id":441900,"areaname":"东莞市"},{"id":442000,"areaname":"中山市"},{"id":442101,"areaname":"东沙群岛"},{"id":445100,"areaname":"潮州市"},{"id":445200,"areaname":"揭阳市"},{"id":445300,"areaname":"云浮市"},{"id":450100,"areaname":"南宁市"},{"id":450200,"areaname":"柳州市"},{"id":450300,"areaname":"桂林市"},{"id":450400,"areaname":"梧州市"},{"id":450500,"areaname":"北海市"},{"id":450600,"areaname":"防城港市"},{"id":450700,"areaname":"钦州市"},{"id":450800,"areaname":"贵港市"},{"id":450900,"areaname":"玉林市"},{"id":451000,"areaname":"百色市"},{"id":451100,"areaname":"贺州市"},{"id":451200,"areaname":"河池市"},{"id":451300,"areaname":"来宾市"},{"id":451400,"areaname":"崇左市"},{"id":460100,"areaname":"海口市"},{"id":460200,"areaname":"三亚市"},{"id":460300,"areaname":"三沙市"},{"id":469001,"areaname":"五指山市"},{"id":469002,"areaname":"琼海市"},{"id":469003,"areaname":"儋州市"},{"id":469005,"areaname":"文昌市"},{"id":469006,"areaname":"万宁市"},{"id":469007,"areaname":"东方市"},{"id":469025,"areaname":"定安县"},{"id":469026,"areaname":"屯昌县"},{"id":469027,"areaname":"澄迈县"},{"id":469028,"areaname":"临高县"},{"id":469030,"areaname":"白沙黎族自治县"},{"id":469031,"areaname":"昌江黎族自治县"},{"id":469033,"areaname":"乐东黎族自治县"},{"id":469034,"areaname":"陵水黎族自治县"},{"id":469035,"areaname":"保亭黎族苗族自治县"},{"id":469036,"areaname":"琼中黎族苗族自治县"},{"id":500100,"areaname":"重庆市"},{"id":510100,"areaname":"成都市"},{"id":510300,"areaname":"自贡市"},{"id":510400,"areaname":"攀枝花市"},{"id":510500,"areaname":"泸州市"},{"id":510600,"areaname":"德阳市"},{"id":510700,"areaname":"绵阳市"},{"id":510800,"areaname":"广元市"},{"id":510900,"areaname":"遂宁市"},{"id":511000,"areaname":"内江市"},{"id":511100,"areaname":"乐山市"},{"id":511300,"areaname":"南充市"},{"id":511400,"areaname":"眉山市"},{"id":511500,"areaname":"宜宾市"},{"id":511600,"areaname":"广安市"},{"id":511700,"areaname":"达州市"},{"id":511800,"areaname":"雅安市"},{"id":511900,"areaname":"巴中市"},{"id":512000,"areaname":"资阳市"},{"id":513200,"areaname":"阿坝藏族羌族自治州"},{"id":513300,"areaname":"甘孜藏族自治州"},{"id":513400,"areaname":"凉山彝族自治州"},{"id":520100,"areaname":"贵阳市"},{"id":520200,"areaname":"六盘水市"},{"id":520300,"areaname":"遵义市"},{"id":520400,"areaname":"安顺市"},{"id":522200,"areaname":"铜仁市"},{"id":522300,"areaname":"黔西南布依族苗族自治州"},{"id":522400,"areaname":"毕节市"},{"id":522600,"areaname":"黔东南苗族侗族自治州"},{"id":522700,"areaname":"黔南布依族苗族自治州"},{"id":530100,"areaname":"昆明市"},{"id":530300,"areaname":"曲靖市"},{"id":530400,"areaname":"玉溪市"},{"id":530500,"areaname":"保山市"},{"id":530600,"areaname":"昭通市"},{"id":530700,"areaname":"丽江市"},{"id":530800,"areaname":"普洱市"},{"id":530900,"areaname":"临沧市"},{"id":532300,"areaname":"楚雄彝族自治州"},{"id":532500,"areaname":"红河哈尼族彝族自治州"},{"id":532600,"areaname":"文山壮族苗族自治州"},{"id":532800,"areaname":"西双版纳傣族自治州"},{"id":532900,"areaname":"大理白族自治州"},{"id":533100,"areaname":"德宏傣族景颇族自治州"},{"id":533300,"areaname":"怒江傈僳族自治州"},{"id":533400,"areaname":"迪庆藏族自治州"},{"id":540100,"areaname":"拉萨市"},{"id":542100,"areaname":"昌都地区"},{"id":542200,"areaname":"山南地区"},{"id":542300,"areaname":"日喀则地区"},{"id":542400,"areaname":"那曲地区"},{"id":542500,"areaname":"阿里地区"},{"id":542600,"areaname":"林芝地区"},{"id":610100,"areaname":"西安市"},{"id":610200,"areaname":"铜川市"},{"id":610300,"areaname":"宝鸡市"},{"id":610400,"areaname":"咸阳市"},{"id":610500,"areaname":"渭南市"},{"id":610600,"areaname":"延安市"},{"id":610700,"areaname":"汉中市"},{"id":610800,"areaname":"榆林市"},{"id":610900,"areaname":"安康市"},{"id":611000,"areaname":"商洛市"},{"id":620100,"areaname":"兰州市"},{"id":620200,"areaname":"嘉峪关市"},{"id":620300,"areaname":"金昌市"},{"id":620400,"areaname":"白银市"},{"id":620500,"areaname":"天水市"},{"id":620600,"areaname":"武威市"},{"id":620700,"areaname":"张掖市"},{"id":620800,"areaname":"平凉市"},{"id":620900,"areaname":"酒泉市"},{"id":621000,"areaname":"庆阳市"},{"id":621100,"areaname":"定西市"},{"id":621200,"areaname":"陇南市"},{"id":622900,"areaname":"临夏回族自治州"},{"id":623000,"areaname":"甘南藏族自治州"},{"id":630100,"areaname":"西宁市"},{"id":632100,"areaname":"海东市"},{"id":632200,"areaname":"海北藏族自治州"},{"id":632300,"areaname":"黄南藏族自治州"},{"id":632500,"areaname":"海南藏族自治州"},{"id":632600,"areaname":"果洛藏族自治州"},{"id":632700,"areaname":"玉树藏族自治州"},{"id":632800,"areaname":"海西蒙古族藏族自治州"},{"id":640100,"areaname":"银川市"},{"id":640200,"areaname":"石嘴山市"},{"id":640300,"areaname":"吴忠市"},{"id":640400,"areaname":"固原市"},{"id":640500,"areaname":"中卫市"},{"id":650100,"areaname":"乌鲁木齐市"},{"id":650200,"areaname":"克拉玛依市"},{"id":652100,"areaname":"吐鲁番地区"},{"id":652200,"areaname":"哈密地区"},{"id":652300,"areaname":"昌吉回族自治州"},{"id":652700,"areaname":"博尔塔拉蒙古自治州"},{"id":652800,"areaname":"巴音郭楞蒙古自治州"},{"id":652900,"areaname":"阿克苏地区"},{"id":653000,"areaname":"克孜勒苏柯尔克孜自治州"},{"id":653100,"areaname":"喀什地区"},{"id":653200,"areaname":"和田地区"},{"id":654000,"areaname":"伊犁哈萨克自治州"},{"id":654200,"areaname":"塔城地区"},{"id":654300,"areaname":"阿勒泰地区"},{"id":659001,"areaname":"石河子市"},{"id":659002,"areaname":"阿拉尔市"},{"id":659003,"areaname":"图木舒克市"},{"id":659004,"areaname":"五家渠市"},{"id":710100,"areaname":"台北市"},{"id":710200,"areaname":"高雄市"},{"id":710300,"areaname":"台南市"},{"id":710400,"areaname":"台中市"},{"id":710500,"areaname":"金门县"},{"id":710600,"areaname":"南投县"},{"id":710700,"areaname":"基隆市"},{"id":710800,"areaname":"新竹市"},{"id":710900,"areaname":"嘉义市"},{"id":711100,"areaname":"新北市"},{"id":711200,"areaname":"宜兰县"},{"id":711300,"areaname":"新竹县"},{"id":711400,"areaname":"桃园县"},{"id":711500,"areaname":"苗栗县"},{"id":711700,"areaname":"彰化县"},{"id":711900,"areaname":"嘉义县"},{"id":712100,"areaname":"云林县"},{"id":712400,"areaname":"屏东县"},{"id":712500,"areaname":"台东县"},{"id":712600,"areaname":"花莲县"},{"id":712700,"areaname":"澎湖县"},{"id":712800,"areaname":"连江县"},{"id":810100,"areaname":"香港岛"},{"id":810200,"areaname":"九龙"},{"id":810300,"areaname":"新界"},{"id":820100,"areaname":"澳门半岛"},{"id":820200,"areaname":"离岛"}]

class DatingCityModel {
  DatingCityModel({
    List<CityItemModel>? hotCity,
    List<CityItemModel>? allCity,
  }) {
    _hotCity = hotCity;
    _allCity = allCity;
  }

  DatingCityModel.fromJson(dynamic json) {
    if (json['hot_city'] != null) {
      _hotCity = [];
      json['hot_city'].forEach((v) {
        _hotCity?.add(CityItemModel.fromJson(v));
      });
    }
    if (json['all_city'] != null) {
      _allCity = [];
      json['all_city'].forEach((v) {
        _allCity?.add(CityItemModel.fromJson(v));
      });
    }
  }

  List<CityItemModel>? _hotCity;
  List<CityItemModel>? _allCity;

  DatingCityModel copyWith({
    List<CityItemModel>? hotCity,
    List<CityItemModel>? allCity,
  }) =>
      DatingCityModel(
        hotCity: hotCity ?? _hotCity,
        allCity: allCity ?? _allCity,
      );

  List<CityItemModel>? get hotCity => _hotCity;

  List<CityItemModel>? get allCity => _allCity;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    if (_hotCity != null) {
      map['hot_city'] = _hotCity?.map((v) => v.toJson()).toList();
    }
    if (_allCity != null) {
      map['all_city'] = _allCity?.map((v) => v.toJson()).toList();
    }
    return map;
  }
}

class CityItemModel {
  CityItemModel({
    int? id,
    String? areaname,
  }) {
    _id = id;
    _areaname = areaname;
  }

  CityItemModel.fromJson(dynamic json) {
    _id = json['id'];
    _areaname = json['areaname'];
  }

  int? _id;
  String? _areaname;

  CityItemModel copyWith({
    int? id,
    String? areaname,
  }) =>
      CityItemModel(
        id: id ?? _id,
        areaname: areaname ?? _areaname,
      );

  int? get id => _id;

  String? get areaname => _areaname;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = _id;
    map['areaname'] = _areaname;
    return map;
  }
}
