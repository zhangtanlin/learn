/// name : "年龄"
/// key : "age"
/// tags : [{"label":"全部","value":"all"},{"label":"18-21","value":"18-21"},{"label":"22-25","value":"22-25"},{"label":"26","value":"26"}]
/// style : 1
/// style_str : "单选"
/// status_str : "未知"
/// is_search_str : "未知"
/// is_tab_str : "未知"
/// is_category_str : "未知"

class DatingFilterItemModel {
  DatingFilterItemModel({
    String? name,
    String? key,
    List<DatingFilterTags>? tags,
    int? style,
    String? styleStr,
    String? statusStr,
    String? isSearchStr,
    String? isTabStr,
    String? isCategoryStr,
  }) {
    _name = name;
    _key = key;
    _tags = tags;
    _style = style;
    _styleStr = styleStr;
    _statusStr = statusStr;
    _isSearchStr = isSearchStr;
    _isTabStr = isTabStr;
    _isCategoryStr = isCategoryStr;
  }

  DatingFilterItemModel.fromJson(dynamic json) {
    _name = json['name'];
    _key = json['key'];
    if (json['tags'] != null) {
      _tags = [];
      json['tags'].forEach((v) {
        _tags?.add(DatingFilterTags.fromJson(v));
      });
    }
    _style = json['style'];
    _styleStr = json['style_str'];
    _statusStr = json['status_str'];
    _isSearchStr = json['is_search_str'];
    _isTabStr = json['is_tab_str'];
    _isCategoryStr = json['is_category_str'];
  }

  String? _name;
  String? _key;
  List<DatingFilterTags>? _tags;
  int? _style;
  String? _styleStr;
  String? _statusStr;
  String? _isSearchStr;
  String? _isTabStr;
  String? _isCategoryStr;

  DatingFilterItemModel copyWith({
    String? name,
    String? key,
    List<DatingFilterTags>? tags,
    int? style,
    String? styleStr,
    String? statusStr,
    String? isSearchStr,
    String? isTabStr,
    String? isCategoryStr,
  }) =>
      DatingFilterItemModel(
        name: name ?? _name,
        key: key ?? _key,
        tags: tags ?? _tags,
        style: style ?? _style,
        styleStr: styleStr ?? _styleStr,
        statusStr: statusStr ?? _statusStr,
        isSearchStr: isSearchStr ?? _isSearchStr,
        isTabStr: isTabStr ?? _isTabStr,
        isCategoryStr: isCategoryStr ?? _isCategoryStr,
      );

  String? get name => _name;

  String? get key => _key;

  List<DatingFilterTags>? get tags => _tags;

  int? get style => _style;

  String? get styleStr => _styleStr;

  String? get statusStr => _statusStr;

  String? get isSearchStr => _isSearchStr;

  String? get isTabStr => _isTabStr;

  String? get isCategoryStr => _isCategoryStr;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['name'] = _name;
    map['key'] = _key;
    if (_tags != null) {
      map['tags'] = _tags?.map((v) => v.toJson()).toList();
    }
    map['style'] = _style;
    map['style_str'] = _styleStr;
    map['status_str'] = _statusStr;
    map['is_search_str'] = _isSearchStr;
    map['is_tab_str'] = _isTabStr;
    map['is_category_str'] = _isCategoryStr;
    return map;
  }
}

/// label : "全部"
/// value : "all"

class DatingFilterTags {
  DatingFilterTags({
    String? label,
    String? value,
  }) {
    _label = label;
    _value = value;
  }

  DatingFilterTags.fromJson(dynamic json) {
    _label = json['label'];
    _value = json['value'];
  }

  String? _label;
  String? _value;

  DatingFilterTags copyWith({
    String? label,
    String? value,
  }) =>
      DatingFilterTags(
        label: label ?? _label,
        value: value ?? _value,
      );

  String? get label => _label;

  String? get value => _value;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['label'] = _label;
    map['value'] = _value;
    return map;
  }
}
