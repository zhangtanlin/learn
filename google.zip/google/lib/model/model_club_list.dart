// To parse this JSON data, do
//
//     final modelClubList = modelClubListFromJson(jsonString);

import 'dart:convert';

import 'package:iaimei/model/model_fans_list.dart';

ModelClubList modelClubListFromJson(String str) =>
    ModelClubList.fromJson(json.decode(str));

String modelClubListToJson(ModelClubList data) => json.encode(data.toJson());

class ModelClubList {
  ModelClubList({
    this.data,
    this.status,
    this.msg,
    this.crypt,
    this.isVv,
    this.needLogin,
    this.isLogin,
  });

  Data? data;
  int? status;
  String? msg;
  bool? crypt;
  bool? isVv;
  bool? needLogin;
  bool? isLogin;

  factory ModelClubList.fromJson(Map<String, dynamic> json) => ModelClubList(
        data: Data.fromJson(json["data"]),
        status: json["status"],
        msg: json["msg"],
        crypt: json["crypt"],
        isVv: json["isVV"],
        needLogin: json["needLogin"],
        isLogin: json["isLogin"],
      );

  Map<String, dynamic> toJson() => {
        "data": data?.toJson(),
        "status": status,
        "msg": msg,
        "crypt": crypt,
        "isVV": isVv,
        "needLogin": needLogin,
        "isLogin": isLogin,
      };
}

class Data {
  Data({
    this.count,
    this.todayCount,
    this.list,
  });

  int? count;
  int? todayCount;
  List<Datum>? list;

  factory Data.fromJson(Map<String, dynamic> json) => Data(
        count: json["count"],
        todayCount: json["today_count"],
        list: List<Datum>.from(json["list"].map((x) => Datum.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "count": count,
        "today_count": todayCount,
        "list": List<dynamic>.from(list!.map((x) => x.toJson())),
      };
}
