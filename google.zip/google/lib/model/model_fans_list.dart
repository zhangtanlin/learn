// To parse this JSON data, do
//
//     final modelFansList = modelFansListFromJson(jsonString);

import 'dart:convert';

ModelFansList modelFansListFromJson(String str) =>
    ModelFansList.fromJson(json.decode(str));

String modelFansListToJson(ModelFansList data) => json.encode(data.toJson());

class ModelFansList {
  ModelFansList({
    this.data,
    this.status,
    this.msg,
    this.crypt,
    this.isVv,
    this.needLogin,
    this.isLogin,
  });

  List<Datum>? data;
  int? status;
  String? msg;
  bool? crypt;
  bool? isVv;
  bool? needLogin;
  bool? isLogin;

  factory ModelFansList.fromJson(Map<String, dynamic> json) => ModelFansList(
        data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
        status: json["status"],
        msg: json["msg"],
        crypt: json["crypt"],
        isVv: json["isVV"],
        needLogin: json["needLogin"],
        isLogin: json["isLogin"],
      );

  Map<String, dynamic> toJson() => {
        "data": List<dynamic>.from(data!.map((x) => x.toJson())),
        "status": status,
        "msg": msg,
        "crypt": crypt,
        "isVV": isVv,
        "needLogin": needLogin,
        "isLogin": isLogin,
      };
}

class Datum {
  Datum({
    this.uid,
    this.aff,
    this.nickname,
    this.thumb,
    this.personSignnatrue,
    this.vipLevel,
    this.expiredAt,
    this.avatarUrl,
    this.expiredStr,
    this.isVip,
    this.isAttention,
  });

  int? uid;
  int? aff;
  String? nickname;
  String? thumb;
  String? personSignnatrue;
  int? vipLevel;
  int? expiredAt;
  String? avatarUrl;
  String? expiredStr;
  bool? isVip;
  int? isAttention;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
        uid: json["uid"],
        aff: json["aff"],
        nickname: json["nickname"],
        thumb: json["thumb"],
        personSignnatrue: json["person_signnatrue"],
        vipLevel: json["vip_level"],
        expiredAt: json["expired_at"],
        avatarUrl: json["avatar_url"],
        expiredStr: json["expired_str"],
        isVip: json["is_vip"],
        isAttention: json["is_attention"],
      );

  Map<String, dynamic> toJson() => {
        "uid": uid,
        "aff": aff,
        "nickname": nickname,
        "thumb": thumb,
        "person_signnatrue": personSignnatrue,
        "vip_level": vipLevel,
        "expired_at": expiredAt,
        "avatar_url": avatarUrl,
        "expired_str": expiredStr,
        "is_vip": isVip,
        "is_attention": isAttention,
      };
}
