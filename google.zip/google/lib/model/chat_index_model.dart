import 'package:iaimei/model/chat_item_model.dart';

class ChatIndexModel {
  ChatIndexModel({
    List<CategoryModel>? category,
    List<ChatItemModel>? recommend,
    List<ChatItemModel>? list,
  }) {
    _category = category;
    _recommend = recommend;
    _list = list;
  }

  ChatIndexModel.fromJson(dynamic json) {
    if (json['category'] != null) {
      _category = [];
      json['category'].forEach((v) {
        _category?.add(CategoryModel.fromJson(v));
      });
    }
    if (json['recommend'] != null) {
      _recommend = [];
      json['recommend'].forEach((v) {
        _recommend?.add(ChatItemModel.fromJson(v));
      });
    }
    if (json['list'] != null) {
      _list = [];
      json['list'].forEach((v) {
        _list?.add(ChatItemModel.fromJson(v));
      });
    }
  }

  List<CategoryModel>? _category;
  List<ChatItemModel>? _recommend;
  List<ChatItemModel>? _list;

  ChatIndexModel copyWith({
    List<CategoryModel>? category,
    List<ChatItemModel>? recommend,
    List<ChatItemModel>? list,
  }) =>
      ChatIndexModel(
        category: category ?? _category,
        recommend: recommend ?? _recommend,
        list: list ?? _list,
      );

  List<CategoryModel>? get category => _category;

  List<ChatItemModel>? get recommend => _recommend;

  List<ChatItemModel>? get list => _list;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    if (_category != null) {
      map['category'] = _category?.map((v) => v.toJson()).toList();
    }
    if (_recommend != null) {
      map['recommend'] = _recommend?.map((v) => v.toJson()).toList();
    }
    if (_list != null) {
      map['list'] = _list?.map((v) => v.toJson()).toList();
    }
    return map;
  }
}

class CategoryModel {
  CategoryModel({
    String? label,
    String? name,
    List<CategoryItemModel>? items,
  }) {
    _label = label;
    _name = name;
    _items = items;
  }

  CategoryModel.fromJson(dynamic json) {
    _label = json['label'];
    _name = json['name'];
    if (json['items'] != null) {
      _items = [];
      json['items'].forEach((v) {
        _items?.add(CategoryItemModel.fromJson(v));
      });
    }
  }

  String? _label;
  String? _name;
  List<CategoryItemModel>? _items;

  CategoryModel copyWith({
    String? label,
    String? name,
    List<CategoryItemModel>? items,
  }) =>
      CategoryModel(
        label: label ?? _label,
        name: name ?? _name,
        items: items ?? _items,
      );

  String? get label => _label;

  String? get name => _name;

  List<CategoryItemModel>? get items => _items;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['label'] = _label;
    map['name'] = _name;
    if (_items != null) {
      map['items'] = _items?.map((v) => v.toJson()).toList();
    }
    return map;
  }
}

/// label : "全部"
/// value : ""

class CategoryItemModel {
  CategoryItemModel({
    String? label,
    String? value,
  }) {
    _label = label;
    _value = value;
  }

  CategoryItemModel.fromJson(dynamic json) {
    _label = json['label'];
    _value = json['value'];
  }

  String? _label;
  String? _value;

  CategoryItemModel copyWith({
    String? label,
    String? value,
  }) =>
      CategoryItemModel(
        label: label ?? _label,
        value: value ?? _value,
      );

  String? get label => _label;

  String? get value => _value;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['label'] = _label;
    map['value'] = _value;
    return map;
  }
}
