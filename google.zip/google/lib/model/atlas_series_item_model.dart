import 'package:iaimei/model/atlas_item_model.dart';

/// id : 25
/// pid : 22
/// name : "美乳"
/// sort : 100
/// status : 1
/// refresh_time : "2022-04-26 10:20:59"
/// click_num : 0
/// alist : [{"id":2575,"title":"色色","desc":"色色","thumb":"/new/upload/20220411/2022041119394695265.jpeg","category_id":25,"tags":"丝袜,美腿,诱惑","is_type":2,"view_count":63,"favorites":2,"view_money":1,"refresh_at":"2022-04-28 18:06:57","recommend":0,"coins":10,"status":1,"thumb_full":"https://new.tthykps.cn/new/upload/20220411/2022041119394695265.jpeg","is_pay":0,"pay_data":null}]

class AtlasSeriesItemModel {
  AtlasSeriesItemModel({
    int? id,
    int? pid,
    String? name,
    int? sort,
    int? status,
    String? refreshTime,
    int? clickNum,
    List<AtlasItemModel>? list,
  }) {
    _id = id;
    _pid = pid;
    _name = name;
    _sort = sort;
    _status = status;
    _refreshTime = refreshTime;
    _clickNum = clickNum;
    _list = list;
  }

  AtlasSeriesItemModel.fromJson(dynamic json) {
    _id = json['id'];
    _pid = json['pid'];
    _name = json['name'];
    _sort = json['sort'];
    _status = json['status'];
    _refreshTime = json['refresh_time'];
    _clickNum = json['click_num'];
    if (json['list'] != null) {
      _list = [];
      json['list'].forEach((v) {
        _list?.add(AtlasItemModel.fromJson(v));
      });
    }
  }

  int? _id;
  int? _pid;
  String? _name;
  int? _sort;
  int? _status;
  String? _refreshTime;
  int? _clickNum;
  List<AtlasItemModel>? _list;

  AtlasSeriesItemModel copyWith({
    int? id,
    int? pid,
    String? name,
    int? sort,
    int? status,
    String? refreshTime,
    int? clickNum,
    List<AtlasItemModel>? list,
  }) =>
      AtlasSeriesItemModel(
        id: id ?? _id,
        pid: pid ?? _pid,
        name: name ?? _name,
        sort: sort ?? _sort,
        status: status ?? _status,
        refreshTime: refreshTime ?? _refreshTime,
        clickNum: clickNum ?? _clickNum,
        list: list ?? _list,
      );

  int? get id => _id;

  int? get pid => _pid;

  String? get name => _name;

  int? get sort => _sort;

  int? get status => _status;

  String? get refreshTime => _refreshTime;

  int? get clickNum => _clickNum;

  List<AtlasItemModel>? get list => _list;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = _id;
    map['pid'] = _pid;
    map['name'] = _name;
    map['sort'] = _sort;
    map['status'] = _status;
    map['refresh_time'] = _refreshTime;
    map['click_num'] = _clickNum;
    if (_list != null) {
      map['list'] = _list?.map((v) => v.toJson()).toList();
    }
    return map;
  }
}
