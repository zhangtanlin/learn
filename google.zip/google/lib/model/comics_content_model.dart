import 'package:iaimei/model/unlock_info_model.dart';

/// pay_data : {"resource_coins":10,"resource_g_coins":100,"resource_type":2,"is_vip":false,"is_pay":0,"free":0,"user_coins":"0.00","user_g_coins":0,"pay_way":[{"type":"resource_coins","name":"当前余额0.00"},{"type":"resource_g_coins","name":"当前钻石0"}]}
/// alist : [{"id":1619872,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619873,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619874,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619875,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619876,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619877,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619878,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619879,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619880,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619881,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619882,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619883,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619884,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619885,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619886,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619887,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619888,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619889,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619890,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619891,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619892,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619893,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619894,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619895,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619896,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619897,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619898,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619899,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619900,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619901,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619902,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619903,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619904,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619905,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619906,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619907,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619908,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619909,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619910,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619911,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619912,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619913,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619914,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619915,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619916,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619917,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619918,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619919,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619920,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619921,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619922,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619923,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619924,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619925,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619926,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619927,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619928,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619929,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619930,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619931,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619932,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619933,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619934,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619935,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619936,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619937,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619938,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619939,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619940,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619941,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619942,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619943,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619944,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619945,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619946,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619947,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619948,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619949,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619950,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619951,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619952,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619953,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619954,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619955,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619956,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619957,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619958,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619959,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619960,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619961,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619962,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619963,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619964,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619965,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619966,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619967,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619968,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619969,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619970,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619971,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619972,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619973,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619974,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619975,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619976,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619977,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619978,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619979,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619980,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619981,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619982,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619983,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619984,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":1619985,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"},{"id":2284154,"m_id":1,"s_id":2,"img_width":"1200","img_height":"575","img_url_full":"https://new.tthykps.cn/new/ads/20220331/2022033111364159774.jpeg"}]

class ComicsContentModel {
  ComicsContentModel({
    UnlockInfoModel? payData,
    List<ComicsContentItem>? list,
  }) {
    _payData = payData;
    _list = list;
  }

  ComicsContentModel.fromJson(dynamic json) {
    _payData =
        json['pay_data'] != null ? UnlockInfoModel.fromJson(json['pay_data']) : null;
    if (json['list'] != null) {
      _list = [];
      json['list'].forEach((v) {
        _list?.add(ComicsContentItem.fromJson(v));
      });
    }
  }

  UnlockInfoModel? _payData;
  List<ComicsContentItem>? _list;

  ComicsContentModel copyWith({
    UnlockInfoModel? payData,
    List<ComicsContentItem>? list,
  }) =>
      ComicsContentModel(
        payData: payData ?? _payData,
        list: list ?? _list,
      );

  UnlockInfoModel? get payData => _payData;

  List<ComicsContentItem>? get list => _list;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    if (_payData != null) {
      map['pay_data'] = _payData?.toJson();
    }
    if (_list != null) {
      map['list'] = _list?.map((v) => v.toJson()).toList();
    }
    return map;
  }
}


class ComicsContentItem {
  ComicsContentItem({
    int? id,
    int? mId,
    int? sId,
    String? imgWidth,
    String? imgHeight,
    String? imgUrlFull,
  }) {
    _id = id;
    _mId = mId;
    _sId = sId;
    _imgWidth = imgWidth;
    _imgHeight = imgHeight;
    _imgUrlFull = imgUrlFull;
  }

  ComicsContentItem.fromJson(dynamic json) {
    _id = json['id'];
    _mId = json['m_id'];
    _sId = json['s_id'];
    _imgWidth = json['img_width'];
    _imgHeight = json['img_height'];
    _imgUrlFull = json['img_url_full'];
  }

  int? _id;
  int? _mId;
  int? _sId;
  String? _imgWidth;
  String? _imgHeight;
  String? _imgUrlFull;

  ComicsContentItem copyWith({
    int? id,
    int? mId,
    int? sId,
    String? imgWidth,
    String? imgHeight,
    String? imgUrlFull,
  }) =>
      ComicsContentItem(
        id: id ?? _id,
        mId: mId ?? _mId,
        sId: sId ?? _sId,
        imgWidth: imgWidth ?? _imgWidth,
        imgHeight: imgHeight ?? _imgHeight,
        imgUrlFull: imgUrlFull ?? _imgUrlFull,
      );

  int? get id => _id;

  int? get mId => _mId;

  int? get sId => _sId;

  String? get imgWidth => _imgWidth;

  String? get imgHeight => _imgHeight;

  String? get imgUrlFull => _imgUrlFull;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = _id;
    map['m_id'] = _mId;
    map['s_id'] = _sId;
    map['img_width'] = _imgWidth;
    map['img_height'] = _imgHeight;
    map['img_url_full'] = _imgUrlFull;
    return map;
  }
}

