import 'package:iaimei/model/tab_data.dart';

class ComicsIndexModel {

  ComicsIndexModel({
      List<TabData>? data,}){
    _data = data;
}

  ComicsIndexModel.fromJson(dynamic json) {
    if (json['data'] != null) {
      _data = [];
      json['data'].forEach((v) {
        _data?.add(TabData.fromJson(v));
      });
    }
  }
  List<TabData>? _data;

  List<TabData>? get data => _data;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    if (_data != null) {
      map['data'] = _data?.map((v) => v.toJson()).toList();
    }
    return map;
  }
}

