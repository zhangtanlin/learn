// To parse this JSON data, do
//
//     final modelApp = modelAppFromJson(jsonString);

import 'dart:convert';

import 'package:iaimei/model/ads_model.dart';

ModelApp modelAppFromJson(String str) => ModelApp.fromJson(json.decode(str));

String modelAppToJson(ModelApp data) => json.encode(data.toJson());

class ModelApp {
  ModelApp({
    required this.data,
    required this.status,
    required this.msg,
    required this.crypt,
    required this.isVv,
    required this.needLogin,
    required this.isLogin,
  });

  Data data;
  int status;
  String msg;
  bool crypt;
  bool isVv;
  bool needLogin;
  bool isLogin;

  factory ModelApp.fromJson(Map<String, dynamic> json) => ModelApp(
        data: Data.fromJson(json["data"]),
        status: json["status"],
        msg: json["msg"],
        crypt: json["crypt"],
        isVv: json["isVV"],
        needLogin: json["needLogin"],
        isLogin: json["isLogin"],
      );

  Map<String, dynamic> toJson() => {
        "data": data.toJson(),
        "status": status,
        "msg": msg,
        "crypt": crypt,
        "isVV": isVv,
        "needLogin": needLogin,
        "isLogin": isLogin,
      };
}

class Data {
  Data({
    required this.banner,
    required this.apps,
  });

  List<AdsModel> banner;
  List<App> apps;

  factory Data.fromJson(Map<String, dynamic> json) => Data(
        banner: List<AdsModel>.from(
            json["banner"].map((x) => AdsModel.fromJson(x))),
        apps: List<App>.from(json["apps"].map((x) => App.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "banner": List<dynamic>.from(banner.map((x) => x.toJson())),
        "apps": List<dynamic>.from(apps.map((x) => x.toJson())),
      };
}

class App {
  App({
    required this.id,
    required this.title,
    required this.description,
    required this.imgUrl,
    required this.linkUrl,
    required this.clicked,
    required this.createdAt,
  });

  int id;
  String title;
  String description;
  String imgUrl;
  String linkUrl;
  int clicked;
  String createdAt;

  factory App.fromJson(Map<String, dynamic> json) => App(
        id: json["id"],
        title: json["title"],
        description: json["description"],
        imgUrl: json["img_url"],
        linkUrl: json["link_url"],
        clicked: json["clicked"],
        createdAt: json["created_at"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "title": title,
        "description": description,
        "img_url": imgUrl,
        "link_url": linkUrl,
        "clicked": clicked,
        "created_at": createdAt,
      };
}
