import 'package:iaimei/model/unlock_info_model.dart';

/// id : 2536
/// title : "色色"
/// desc : "色色"
/// thumb : "/new/upload/20220407/2022040721183675264.jpeg"
/// category_id : 21
/// tags : "丝袜,美腿,诱惑"
/// is_type : 1
/// view_count : 80
/// favorites : 0
/// view_money : 1
/// refresh_at : "2022-04-30 16:06:56"
/// recommend : 0
/// coins : 1
/// status : 1
/// thumb_full : "https://new.tthykps.cn/new/upload/20220407/2022040721183675264.jpeg"
/// is_pay : 0
/// pay_data : {"resource_coins":"1","resource_g_coins":"10","resource_type":2,"is_vip":false,"is_pay":0,"free":2,"user_coins":"18320.00","user_g_coins":"19980","user_times":"0","pay_way":[{"type":"resource_coins","name":"当前余额:18320.00"},{"type":"resource_g_coins","name":"当前钻石:19980"}]}
/// resources : [{"id":135098,"picture_id":2536,"img_url":"/new/upload/20220407/2022040721183991752.jpeg","img_width":"0","img_height":"0","img_url_full":"https://new.tthykps.cn/new/upload/20220407/2022040721183991752.jpeg"},{"id":135099,"picture_id":2536,"img_url":"/new/upload/20220407/2022040721184033913.jpeg","img_width":"0","img_height":"0","img_url_full":"https://new.tthykps.cn/new/upload/20220407/2022040721184033913.jpeg"}]

class AtlasDetailModel {
  AtlasDetailModel({
      int? id, 
      String? title, 
      String? desc, 
      String? thumb, 
      int? categoryId, 
      String? tags, 
      int? isType, 
      int? viewCount, 
      int? favorites, 
      int? viewMoney, 
      String? refreshAt, 
      int? recommend, 
      int? coins, 
      int? status, 
      String? thumbFull, 
      int? isPay, 
      UnlockInfoModel? payData,
      List<Resources>? resources,}){
    _id = id;
    _title = title;
    _desc = desc;
    _thumb = thumb;
    _categoryId = categoryId;
    _tags = tags;
    _isType = isType;
    _viewCount = viewCount;
    _favorites = favorites;
    _viewMoney = viewMoney;
    _refreshAt = refreshAt;
    _recommend = recommend;
    _coins = coins;
    _status = status;
    _thumbFull = thumbFull;
    _isPay = isPay;
    _payData = payData;
    _resources = resources;
}

  AtlasDetailModel.fromJson(dynamic json) {
    _id = json['id'];
    _title = json['title'];
    _desc = json['desc'];
    _thumb = json['thumb'];
    _categoryId = json['category_id'];
    _tags = json['tags'];
    _isType = json['is_type'];
    _viewCount = json['view_count'];
    _favorites = json['favorites'];
    _viewMoney = json['view_money'];
    _refreshAt = json['refresh_at'];
    _recommend = json['recommend'];
    _coins = json['coins'];
    _status = json['status'];
    _thumbFull = json['thumb_full'];
    _isPay = json['is_pay'];
    _payData = json['pay_data'] != null ? UnlockInfoModel.fromJson(json['pay_data']) : null;
    if (json['resources'] != null) {
      _resources = [];
      json['resources'].forEach((v) {
        _resources?.add(Resources.fromJson(v));
      });
    }
  }
  int? _id;
  String? _title;
  String? _desc;
  String? _thumb;
  int? _categoryId;
  String? _tags;
  int? _isType;
  int? _viewCount;
  int? _favorites;
  int? _viewMoney;
  String? _refreshAt;
  int? _recommend;
  int? _coins;
  int? _status;
  String? _thumbFull;
  int? _isPay;
  UnlockInfoModel? _payData;
  List<Resources>? _resources;
AtlasDetailModel copyWith({  int? id,
  String? title,
  String? desc,
  String? thumb,
  int? categoryId,
  String? tags,
  int? isType,
  int? viewCount,
  int? favorites,
  int? viewMoney,
  String? refreshAt,
  int? recommend,
  int? coins,
  int? status,
  String? thumbFull,
  int? isPay,
  UnlockInfoModel? payData,
  List<Resources>? resources,
}) => AtlasDetailModel(  id: id ?? _id,
  title: title ?? _title,
  desc: desc ?? _desc,
  thumb: thumb ?? _thumb,
  categoryId: categoryId ?? _categoryId,
  tags: tags ?? _tags,
  isType: isType ?? _isType,
  viewCount: viewCount ?? _viewCount,
  favorites: favorites ?? _favorites,
  viewMoney: viewMoney ?? _viewMoney,
  refreshAt: refreshAt ?? _refreshAt,
  recommend: recommend ?? _recommend,
  coins: coins ?? _coins,
  status: status ?? _status,
  thumbFull: thumbFull ?? _thumbFull,
  isPay: isPay ?? _isPay,
  payData: payData ?? _payData,
  resources: resources ?? _resources,
);
  int? get id => _id;
  String? get title => _title;
  String? get desc => _desc;
  String? get thumb => _thumb;
  int? get categoryId => _categoryId;
  String? get tags => _tags;
  int? get isType => _isType;
  int? get viewCount => _viewCount;
  int? get favorites => _favorites;
  int? get viewMoney => _viewMoney;
  String? get refreshAt => _refreshAt;
  int? get recommend => _recommend;
  int? get coins => _coins;
  int? get status => _status;
  String? get thumbFull => _thumbFull;
  int? get isPay => _isPay;
  UnlockInfoModel? get payData => _payData;
  List<Resources>? get resources => _resources;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = _id;
    map['title'] = _title;
    map['desc'] = _desc;
    map['thumb'] = _thumb;
    map['category_id'] = _categoryId;
    map['tags'] = _tags;
    map['is_type'] = _isType;
    map['view_count'] = _viewCount;
    map['favorites'] = _favorites;
    map['view_money'] = _viewMoney;
    map['refresh_at'] = _refreshAt;
    map['recommend'] = _recommend;
    map['coins'] = _coins;
    map['status'] = _status;
    map['thumb_full'] = _thumbFull;
    map['is_pay'] = _isPay;
    if (_payData != null) {
      map['pay_data'] = _payData?.toJson();
    }
    if (_resources != null) {
      map['resources'] = _resources?.map((v) => v.toJson()).toList();
    }
    return map;
  }

}

/// id : 135098
/// picture_id : 2536
/// img_url : "/new/upload/20220407/2022040721183991752.jpeg"
/// img_width : "0"
/// img_height : "0"
/// img_url_full : "https://new.tthykps.cn/new/upload/20220407/2022040721183991752.jpeg"

class Resources {
  Resources({
      int? id, 
      int? pictureId, 
      String? imgUrl, 
      String? imgWidth, 
      String? imgHeight, 
      String? imgUrlFull,}){
    _id = id;
    _pictureId = pictureId;
    _imgUrl = imgUrl;
    _imgWidth = imgWidth;
    _imgHeight = imgHeight;
    _imgUrlFull = imgUrlFull;
}

  Resources.fromJson(dynamic json) {
    _id = json['id'];
    _pictureId = json['picture_id'];
    _imgUrl = json['img_url'];
    _imgWidth = json['img_width'];
    _imgHeight = json['img_height'];
    _imgUrlFull = json['img_url_full'];
  }
  int? _id;
  int? _pictureId;
  String? _imgUrl;
  String? _imgWidth;
  String? _imgHeight;
  String? _imgUrlFull;
Resources copyWith({  int? id,
  int? pictureId,
  String? imgUrl,
  String? imgWidth,
  String? imgHeight,
  String? imgUrlFull,
}) => Resources(  id: id ?? _id,
  pictureId: pictureId ?? _pictureId,
  imgUrl: imgUrl ?? _imgUrl,
  imgWidth: imgWidth ?? _imgWidth,
  imgHeight: imgHeight ?? _imgHeight,
  imgUrlFull: imgUrlFull ?? _imgUrlFull,
);
  int? get id => _id;
  int? get pictureId => _pictureId;
  String? get imgUrl => _imgUrl;
  String? get imgWidth => _imgWidth;
  String? get imgHeight => _imgHeight;
  String? get imgUrlFull => _imgUrlFull;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = _id;
    map['picture_id'] = _pictureId;
    map['img_url'] = _imgUrl;
    map['img_width'] = _imgWidth;
    map['img_height'] = _imgHeight;
    map['img_url_full'] = _imgUrlFull;
    return map;
  }

}
