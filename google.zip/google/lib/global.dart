import 'dart:io';

import 'package:flutter/material.dart';
import 'package:hive/hive.dart';

enum BrowseKey {
  video, // 视频
  comics, // 漫画
  novel, // 小说
  nudeChat, // 裸聊
  dateLove, // 约炮
  imgAsset, // 图集\
}

class AppGlobal {
  static String comicThumb = '';

  static Map appinfo = {};
  // 正式服地址
  static String apiBaseURL = "https://mapi01.myb6api.xyz/api.php";
  // 测试服地址
  // static String apiBaseURL = "http://gogo.hyys.info/api.php";
  static String uploadImgUrl = "";
  static String uploadImgKey = "";
  static String bannerImgBase = "";
  static String uploadVideoUrl = "";
  static String uploadVideoKey = "";
  static String apiToken = "";
  static int visibilityDetectorIndex = 0;
  static bool showActivity = true;
  static Box? appBox;
  static Box? imageCacheBox; // 图片
  static Box? imageAssetBox; //
  static Box? videoWatchRecordBox; // 长视频
  static Box? smallVideoWatchRecordBox; // 小视频
  static Box? comicsWatchRecordBox; // 漫画
  static Box? novelWatchRecordBox; // 小说
  static Box? datingCityBox; // 约炮城市

  static Box? cacheHistoryBox; // 缓存
  static Box? storageHistoryBox; // 浏览

  static int storageMaxNum = 30;
  static initStorageBrowseHistory() async {
    storageHistoryBox = await Hive.openBox('keyStorageHistoryName');
  }

  static storeHistory(BrowseKey type, Map<String, dynamic>? item) {
    if (item == null) return; // null 不用
    String key = type.toString();
    var itemList = storageHistoryBox?.get(key) ?? [];
    if (itemList is! List) return;
    // var itemList = storageHistoryBox?.get(type) as List;
    if (itemList.length >= storageMaxNum) {
      itemList.removeLast(); // 倒序插入
    }
    for (var obj in itemList) {
      if (obj['id'] == item['id']) {
        itemList.remove(obj);
        break; /* 提交结束循环 */
      }
    }
    itemList.insert(0, item); // 放在队首
    storageHistoryBox?.put(key, itemList);
  }

  static List readBrowseHistory(BrowseKey type) {
    String key = type.toString();
    var itemList = storageHistoryBox?.get(key);
    if (itemList is! List) return [];
    return itemList;
  }

  static List helpList = [];
  static int isSetPassword = 0;
  static int vipLevel = 0;
  static bool apInit = false;
  static bool routerReplace = false;
  static bool videoPageIsActive = true;
  static Map<String, dynamic> currentDetailRouteExtra = {};
  static Map<String, dynamic> currentReaderRouteExtra = {};
  static String m3u8Encrypt = "";
  static bool isNewVersion = true;
  static String officeSite = '';
  static DateTime firstVisitTime = DateTime.now();
  static dynamic currenClickData;
  static dynamic appRouter;
  static BuildContext? appContext;
  static Map<String, dynamic> datingFilterParam = {};

  /// 缓存计算
  static void calculateimageCache(void Function(String) callback) async {
    try {
      double size = 0;
      var images = imageCacheBox?.path;
      if (images != null) size += await File(images).length();
      var assets = imageAssetBox?.path;
      if (assets != null) size += await File(assets).length();
      var video = videoWatchRecordBox?.path;
      if (video != null) size += await File(video).length();
      var small = smallVideoWatchRecordBox?.path;
      if (small != null) size += await File(small).length();
      var comics = comicsWatchRecordBox?.path;
      if (comics != null) size += await File(comics).length();
      var novel = novelWatchRecordBox?.path;
      if (novel != null) size += await File(novel).length();
      var storage = storageHistoryBox?.path;
      if (storage != null) size += await File(storage).length();
      var downloadBox = await Hive.openBox('_CacheHistoryBox');
      var download = downloadBox.path;
      if (download != null) size += await File(download).length();

      if (size == 0) {
        callback('0.0B');
        return;
      }
      List<String> unitList = ['B', 'K', 'M', 'G'];
      int index = 0;
      while (size > 1024) {
        index++;
        size = size / 1024;
      }
      callback(size.toStringAsFixed(2) + unitList[index]);
    } catch (e) {
      callback('0.0B');
      debugPrint(e.toString());
    }
  }

  static void clearCache(void Function(String) callback) async {
    // appBox?.clear(); // 不能清楚，线路 token 等信息
    try {
      imageCacheBox?.clear();
      imageAssetBox?.clear();
      videoWatchRecordBox?.clear();
      smallVideoWatchRecordBox?.clear();
      comicsWatchRecordBox?.clear();
      novelWatchRecordBox?.clear();
      storageHistoryBox?.clear(); // 浏览历史

      // 下载视频等缓存
      var downloadBox = await Hive.openBox('_CacheHistoryBox');
      downloadBox.clear();
      // 清楚完成 回调
      calculateimageCache((value) => callback(value));
    } catch (e) {
      callback('0.0B');
      debugPrint(e.toString());
    }
  }
}
