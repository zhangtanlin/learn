import 'package:flutter/material.dart';

abstract class BaseWidgetState<W extends StatefulWidget> extends State<W> {

  final GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        key: scaffoldKey,
        backgroundColor: pageBgColor(),
        extendBodyBehindAppBar: true,
        resizeToAvoidBottomInset: isResizeToAvoidBottomInset(),
        //设置AppBar透明需要
        appBar: buildAppBar(),
        body: _buildPageBody());
  }

  _buildPageBody() {
    return buildPageBg() != null
        ? Stack(
            children: [buildPageBg(), _buildPLayout()],
          )
        : _buildPLayout();
  }

  Widget buildPageLayout();

  Color pageBgColor() {
    return Colors.transparent;
  }

  buildAppBar() {
    return null;
  }

  buildPageBg() {
    return null;
  }

  bool isShowSafeArea() {
    return true;
  }

  GlobalKey<ScaffoldState> getGlobalKey() {
    return scaffoldKey;
  }

  _buildPLayout() {
    return isShowSafeArea()
        ? SafeArea(
            bottom: false,
            child: buildPageLayout(),
          )
        : buildPageLayout();
  }

  bool isResizeToAvoidBottomInset() {
    return true;
  }
}
