import 'package:flutter/material.dart';
import 'package:iaimei/base/base_widget_state.dart';
import 'package:iaimei/res/img_res.dart';

abstract class AppBaseWidgetState<W extends StatefulWidget>
    extends BaseWidgetState<W> {

  @override
  buildPageBg() {
    return Image.asset(
      ImgRes.IMG_APP_BG,
      fit: BoxFit.cover,
      width: MediaQuery.of(context).size.width,
      height: MediaQuery.of(context).size.height,
    );
  }
}
