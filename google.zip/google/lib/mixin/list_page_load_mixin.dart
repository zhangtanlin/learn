import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:iaimei/mixin/page_load_mixin.dart';
import 'package:iaimei/net/http_error.dart';
import 'package:iaimei/utils/list_util.dart';
import 'package:iaimei/widget/load_state_widget.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';

mixin ListPageLoadMixin<W extends StatefulWidget> on State<W> {
  bool _startRefresh = false;
  bool _startLoad = false;

  List<dynamic> _resultList = [];

  List<dynamic> get getResultList => _resultList;

  int _curPage = 1;

  late RefreshController refreshController;

  // String _lastIndex = '';

  // set setLastIndex(String lastIx) => _lastIndex = lastIx;

  // String get getLastIndex => _lastIndex;

  int get getCurPage => _curPage;

  int get getPageSize => setPageSize();

  int setPageSize() {
    return 10;
  }

  int _adPosition = 7;

  int get getAdPosition => _adPosition;
  Timer? _timerOut;

  set setAdPosition(int adPosition) => {
        _adPosition = [5, adPosition].reduce(max)
      };

  @override
  void initState() {
    super.initState();
    refreshController = getCustomRefreshController();
  }

  @override
  void dispose() {
    try {
      if (refreshController != null) {
        refreshController.dispose();
      }
      if (_timerOut != null) {
        _timerOut?.cancel();
      }
    } catch (e) {
      e.toString();
    }
    super.dispose();
  }

  RefreshController getCustomRefreshController() {
    return RefreshController(initialRefresh: false);
  }

  setListPageState(
      bool isRefresh, bool isNotEmptyData, VoidCallback? callback) {
    if (isRefresh) {
      setPageState(isNotEmptyData);
      if (isNotEmptyData) {
        if (callback != null) {
          callback();
        }
      } else {
        _startRefresh = false;
        if (refreshController != null) {
          refreshController.refreshCompleted(resetFooterState: true);
        }
      }
    } else {
      if (callback != null) {
        callback();
      }
    }
  }

  setListPageErrorState(bool isRefresh, HttpError error) {
    if (refreshController != null) {
      if (isRefresh) {
        setPageErrorState(error);
        refreshController.refreshFailed();
        _startRefresh = false;
      } else {
        refreshController.loadFailed();
        _startLoad = false;
      }
    }
  }

  bool isEnableRefresh() {
    return true;
  }

  bool isEnableLoad() {
    return true;
  }

  void onRefreshList() {
    if (!isEnableRefresh() || _startRefresh || _startLoad || !mounted) return;
    if (isEnableRefresh() && !_startRefresh) {
      _startRefresh = true;
      _curPage = 1;
      _timerOut = Timer.periodic(const Duration(seconds: 10), (timer) {
        if (_startRefresh) {
          _startRefresh = false;
          refreshController.refreshCompleted(resetFooterState: true);
        }
        timer.cancel();
      });
      requestListData(true);
    }
  }

  void onLoadList() {
    if (!isEnableLoad() || _startRefresh || _startLoad || !mounted) return;
    if (isEnableLoad() && !_startLoad) {
      _startLoad = true;
      requestListData(false);
    }
  }

  // List<dynamic> handleListAndAds(
  //     List<dynamic> dataList, List<AdsModel> adsList) {
  //   try {
  //     if (dataList != null) {
  //       if (dataList.isNotEmpty) {
  //         if (dataList.length < getAdPosition) {
  //           return dataList;
  //         } else {
  //           if (adsList == null || adsList.isEmpty) {
  //             return dataList;
  //           } else {
  //             List fList = dataList.sublist(0, getAdPosition - 1);
  //             List bList = dataList.sublist(getAdPosition - 1);
  //             return [...fList, adsList[0], ...bList];
  //           }
  //         }
  //       }
  //     }
  //     return [];
  //   } catch (e) {
  //     e.toString();
  //   }
  //   return [];
  // }

  void requestListData(bool isRefresh);

  updatePageList(bool isRefresh, List dataList) {
    try {
      if (mounted) {
        if (isRefresh) {
          refreshController.refreshCompleted(resetFooterState: true);
          if (ListUtil.isNotEmpty(dataList)) {
            setState(() {
              _resultList = dataList;
              if (isEnableLoad()) {
                _curPage = _curPage + 1;
              }
            });
          } else {
            refreshController.loadNoData();
          }
          if (_timerOut != null) {
            _timerOut?.cancel();
          }
          _startRefresh = false;
        } else {
          if (ListUtil.isNotEmpty(dataList)) {
            refreshController.loadComplete();
            setState(() {
              _resultList = _resultList..addAll(dataList);
              if (isEnableLoad()) {
                _curPage = _curPage + 1;
              }
            });
          } else {
            refreshController.loadNoData();
          }
          _startLoad = false;
        }
      }
    } catch (e) {
      Future.delayed(const Duration(seconds: 1), () {
        if (isRefresh) {
          refreshController.refreshFailed();
          _startRefresh = false;
        } else {
          refreshController.loadFailed();
          _startLoad = false;
        }
        setState(() {});
      });
    }
  }

  PageLoadStateType _loadStateType = PageLoadStateType.loading;

  onLoadData();

  Widget successView();

  setPageState(bool isNotEmptyData) {
    if (mounted) {
      setState(() {
        if (isNotEmptyData) {
          _loadStateType = PageLoadStateType.success;
        } else {
          _loadStateType = PageLoadStateType.empty;
        }
      });
    }
  }

  setPageErrorState(HttpError error) {
    if (mounted) {
      setState(() {
        if (error.code == HttpError.NO_NETWORK) {
          _loadStateType = PageLoadStateType.noNet;
        } else {
          _loadStateType = PageLoadStateType.error;
        }
      });
    }
  }

  Widget handlePageStateView() {
    return getPageStateView(_loadStateType);
  }

  retryLoadData() {
    setState(() {
      _loadStateType = PageLoadStateType.loading;
    });
    onLoadData();
  }

  Widget getPageStateView(PageLoadStateType type) {
    Widget showWidget;
    switch (type) {
      case PageLoadStateType.noNet:
        showWidget = LoadSateWidget.noNetWorkView(retryLoadData);
        break;
      case PageLoadStateType.loading:
        showWidget = LoadSateWidget.loadingView();
        break;
      case PageLoadStateType.empty:
        showWidget = LoadSateWidget.noDataView(retryLoadData);
        break;
      case PageLoadStateType.success:
        showWidget = successView();
        break;
      case PageLoadStateType.error:
        showWidget = LoadSateWidget.errorView(retryLoadData);
        break;
    }
    return showWidget;
  }
}
