import 'package:bot_toast/bot_toast.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:iaimei/global.dart';
import 'package:iaimei/res/img_res.dart';
import 'package:iaimei/theme/default.dart';
import 'package:iaimei/utils/networkimage.dart';

mixin VideoMinxin<T extends StatefulWidget> on State<T> {
  @override
  void initState() {
    super.initState();
  }

  /// 是否是横版
  bool isHorizontal() {
    double sW = MediaQuery.of(context).size.width;
    double sH = MediaQuery.of(context).size.height;
    return sW > sH;
  }

  /// 动画盒子
  Widget animatedBox({
    Widget child = const SizedBox(),
    int time = 300,
    double? left = 0,
    double? top = 0,
    double? right = 0,
    double? bottom = 0,
    double opacity = 1,
  }) {
    return AnimatedPositioned(
      left: left,
      top: top,
      right: right,
      bottom: bottom,
      duration: Duration(
        milliseconds: time,
      ),
      child: AnimatedOpacity(
        opacity: opacity,
        duration: Duration(
          milliseconds: time,
        ),
        child: child,
      ),
    );
  }

  Widget head({bool noBack = false, Widget rightWidget = const SizedBox()}) {
    return Container(
      height: 44.w,
      width: double.infinity,
      decoration: const BoxDecoration(
          gradient: LinearGradient(
        colors: [Colors.black38, Color.fromRGBO(0, 0, 0, 0)],
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
      )),
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: DefaultStyle.pagePadding),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            noBack
                ? const SizedBox()
                : GestureDetector(
                    onTap: () {
                      SystemChrome.setEnabledSystemUIMode(SystemUiMode.manual,
                          overlays: SystemUiOverlay.values);
                      SystemChrome.setPreferredOrientations(
                          [DeviceOrientation.portraitUp]);
                      context.pop();
                    },
                    child: Image.asset(
                      ImgRes.IC_ARROW_BACK,
                      width: 22.w,
                      fit: BoxFit.fitWidth,
                    ),
                  ),
            rightWidget
          ],
        ),
      ),
    );
  }

  Future showBuy(data, Function buyFunction) {
    // int money = Provider.of<Config>(context, listen: false).member.money;
    // bool isInsufficient = money < data.discountCoins;
    bool isVip = AppGlobal.vipLevel > 0;
    return showModalBottomSheet(
        backgroundColor: Colors.transparent,
        isScrollControlled: true,
        context: context,
        builder: (BuildContext context) {
          return StatefulBuilder(builder: (context, setBottomSheetState) {
            return Stack(
              children: [
                Positioned(
                    top: 0,
                    bottom: 0,
                    left: 0,
                    right: 0,
                    child: Image.asset(
                      'assets/pengke/bottomsheet_bg.png',
                      fit: BoxFit.fill,
                    )),
                Container(
                  width: double.infinity,
                  height: 221.w + (kIsWeb ? 0 : ScreenUtil().bottomBarHeight),
                  padding: EdgeInsets.symmetric(
                      horizontal: ScreenUtil().setWidth(15)),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        width: double.infinity,
                        padding: EdgeInsets.only(top: 24.5.w, bottom: 19.5.w),
                        child: Center(
                          child: Text(
                            '购买视频',
                            style: DefaultStyle.white16,
                          ),
                        ),
                      ),
                      Expanded(
                          child: Column(
                        children: [
                          Center(
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Text(
                                  '${data.discountCoins}G',
                                  style: TextStyle(
                                      color: const Color(0XFF62f7ff),
                                      fontSize: ScreenUtil().setSp(24),
                                      fontWeight: FontWeight.bold),
                                ),
                                data.coins == data.discountCoins
                                    ? Container()
                                    : Text(
                                        '${data.coins}G',
                                        style: TextStyle(
                                          color: const Color(0XFF6a6a6a),
                                          decoration:
                                              TextDecoration.lineThrough,
                                          fontSize: ScreenUtil().setSp(14),
                                        ),
                                      ),
                              ],
                            ),
                          ),
                          Padding(
                            padding: EdgeInsets.symmetric(
                              vertical: 30.w,
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  '购买视频',
                                  style: TextStyle(
                                      color: const Color(0xffd7d7d7),
                                      fontSize: 14.sp,
                                      decoration: TextDecoration.none),
                                ),
                                Expanded(
                                  child: Container(
                                    padding: EdgeInsets.only(left: 20.w),
                                    child: Text(
                                      data.title,
                                      style: TextStyle(
                                          color: const Color(0xffd7d7d7),
                                          fontSize: ScreenUtil().setSp(14),
                                          overflow: TextOverflow.ellipsis,
                                          decoration: TextDecoration.none),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          isVip
                              ? GestureDetector(
                                  onTap: () {
                                    print('跳转');
                                    // if (isInsufficient) {
                                    //   context.pop();
                                    //   context.push('/${Routes.coinRecharge}');
                                    // } else {
                                    //   buyFunction();
                                    // }
                                  },
                                  child: Stack(
                                    children: [
                                      Positioned(
                                        top: 0,
                                        bottom: 0,
                                        left: 0,
                                        right: 0,
                                        child: Image.asset(
                                          'assets/pengke/video/video_chang_btn.png',
                                          fit: BoxFit.fill,
                                        ),
                                      ),
                                      SizedBox(
                                        width: double.infinity,
                                        height: 34.w,
                                        child: Center(
                                          child: Text(
                                            '立即购买',
                                            // isInsufficient
                                            //     ? 'GOLD不足，前往充值'
                                            //     : '立即购买',
                                            style: DefaultStyle.gray10,
                                          ),
                                        ),
                                      )
                                    ],
                                  ),
                                )
                              : Row(
                                  children: [
                                    Expanded(
                                        child: GestureDetector(
                                      onTap: () {
                                        if (kDebugMode) {
                                          print('退出播放并跳转vip');
                                          // context.pop();
                                          // context.push('/${Routes.vip}');
                                        }
                                      },
                                      child: Stack(
                                        clipBehavior: Clip.none,
                                        children: [
                                          Stack(
                                            children: [
                                              Positioned(
                                                  top: 0,
                                                  bottom: 0,
                                                  left: 0,
                                                  right: 0,
                                                  child: Image.asset(
                                                    'assets/pengke/video/video_duan_btn.png',
                                                    fit: BoxFit.fill,
                                                  )),
                                              SizedBox(
                                                width: double.infinity,
                                                height: 34.w,
                                                child: Center(
                                                  child: Text(
                                                    '升级会员',
                                                    style: DefaultStyle.gray10,
                                                  ),
                                                ),
                                              )
                                            ],
                                          ),
                                          Positioned(
                                            top: -7.w,
                                            left: 0,
                                            child: PlatformAwareAssetImage(
                                              url:
                                                  'assets/images/vie_zhekou.png',
                                              height: 15.w,
                                              fit: BoxFit.fitHeight,
                                            ),
                                          )
                                        ],
                                      ),
                                    )),
                                    SizedBox(
                                      width: 15.w,
                                    ),
                                    Expanded(
                                        child: GestureDetector(
                                      onTap: () {
                                        // if (isInsufficient) {
                                        print('退出播放并跳转金币充值');
                                        // context.pop();
                                        // context
                                        //     .push('/${Routes.coinRecharge}');
                                        // } else {
                                        //   buyFunction();
                                        // }
                                      },
                                      child: Stack(
                                        children: [
                                          Positioned(
                                              top: 0,
                                              bottom: 0,
                                              left: 0,
                                              right: 0,
                                              child: Image.asset(
                                                'assets/pengke/video/video_chang_btn.png',
                                                fit: BoxFit.fill,
                                              )),
                                          SizedBox(
                                            width: double.infinity,
                                            height: 34.w,
                                            child: Center(
                                              child: Text(
                                                '立即购买',
                                                // isInsufficient
                                                //     ? 'GOLD不足，前往充值'
                                                //     : '立即购买',
                                                style: DefaultStyle.gray10,
                                              ),
                                            ),
                                          )
                                        ],
                                      ),
                                    ))
                                  ],
                                )
                        ],
                      )),
                    ],
                  ),
                ),
                Positioned(
                    top: 19.5.w,
                    right: 19.5.w,
                    child: GestureDetector(
                      onTap: () {
                        context.pop();
                      },
                      child: PlatformAwareAssetImage(
                        url: 'assets/images/pment/icon_close.png',
                        width: 14.w,
                        height: 14.w,
                      ),
                    ))
              ],
            );
          });
        });
  }

  Widget coinbuy({
    dynamic data,
    // Function buyFunction,
  }) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text.rich(
          TextSpan(
            text: '该视频需要花费',
            style: DefaultStyle.white14,
            children: [
              TextSpan(
                text: '${data.discountCoins}GOLD',
                style: DefaultStyle.red16,
              )
            ],
          ),
        ),
        GestureDetector(
          onTap: () {
            print('去购买');
            // showBuy(data, buyFunction);
          },
          child: Container(
            margin: EdgeInsets.only(top: 22.w),
            height: 32.w,
            width: 118.5.w,
            decoration: BoxDecoration(
                color: Colors.black54,
                borderRadius: BorderRadius.circular(16.w)),
            child: Center(
              child: Text(
                '继续观看',
                style: DefaultStyle.white12,
              ),
            ),
          ),
        )
      ],
    );
  }

  BackButtonBehavior backButtonBehavior = BackButtonBehavior.none;
  Widget nofree({dynamic data}) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 225.w,
          child: Text(
            '您已经没有播放次数，升级会员即可无限观看海量AV',
            style: TextStyle(
              color: Colors.white,
              fontSize: ScreenUtil().setSp(15),
            ),
            textAlign: TextAlign.center,
          ),
        ),
        SizedBox(
          height: 20.w,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            GestureDetector(
              onTap: () {
                print('分享');
                // var config =
                //     Provider.of<Config>(context, listen: false).config;
                // ShareMovieModel.showShareMovie(
                //   backButtonBehavior,
                //   copyUrl: config.share.affUrlCopy.url,
                //   thumb: data.coverThumbHorizontal,
                //   title: data.title,
                //   subtitle: data.desc,
                //   url: '${config.share.affUrl}',
                // );
              },
              child: Container(
                margin: EdgeInsets.only(right: 26.w),
                width: 119.w,
                height: 32.w,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(16.w),
                    gradient: const LinearGradient(
                      colors: [
                        Color(0xff37f4ff),
                        Color(0xffff6a4a),
                      ],
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                    )),
                child: Center(
                  child: Text(
                    '分享无限看',
                    style: DefaultStyle.white12,
                  ),
                ),
              ),
            ),
            GestureDetector(
              onTap: () {
                print('跳转购买vip');
                // context.push('/${Routes.vip}');
              },
              child: Container(
                width: 119.w,
                height: 32.w,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(16.w),
                    gradient: const LinearGradient(
                      colors: [
                        Color(0xff37f4ff),
                        Color(0xffff6a4a),
                      ],
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                    )),
                child: Center(
                  child: Text(
                    '立即升级会员',
                    style: DefaultStyle.white12,
                  ),
                ),
              ),
            )
          ],
        )
      ],
    );
  }
}
