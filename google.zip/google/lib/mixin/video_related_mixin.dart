import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:iaimei/global.dart';
import 'package:iaimei/model/video_model.dart';
import 'package:iaimei/utils/crypto.dart';
import 'package:iaimei/utils/log_util.dart';
import 'package:iaimei/utils/shelf_proxy.dart';
import 'package:iaimei/utils/video_util.dart';
import 'package:universal_html/html.dart' as html;
import 'package:video_player/video_player.dart';

mixin VideoRelatedMixin<T extends StatefulWidget> on State<T> {

  Future<VideoPlayerController>? initController(VideoModel? videoModel,
      {bool isLocal = false, bool isNew = false}) {
    String purl = VideoUtil.getAvailableVideoUrl(videoModel);
    LogUtil.i('purl--------$purl');
    if (kIsWeb) {
      if (AppGlobal.m3u8Encrypt == '1') {
        Dio().get(purl).then((res) {
          String decrypted = PlatformAwareCrypto.decryptM3U8(res.data);
          final _blob =
              html.Blob([decrypted], 'application/x-mpegURL', 'native');
          final _url = html.Url.createObjectUrl(_blob);

          return VideoPlayerController.network(_url);
        });
      } else {
        return Future.delayed(const Duration(seconds: 0), () {
          return VideoPlayerController.network(purl);
        });
      }
    } else {
      if (!isLocal) {
        if (AppGlobal.m3u8Encrypt == '1') {
          createServer(purl).then((proxyConfig) {
            String proxyUrl = purl.replaceAll(
                proxyConfig['origin'], proxyConfig['localproxy']);
            return VideoPlayerController.network(proxyUrl);
          });
        } else {
          LogUtil.i('-----$purl-----');
          return Future.delayed(const Duration(seconds: 0), () {
            return VideoPlayerController.network(purl);
          });
        }
      } else {
        // 创建本地播放服务
        createStaticServer(purl).then((url) {
          return VideoPlayerController.network(url);
        });
      }
    }
    return null;
  }
}
