import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class DefaultStyle {
  // 栏目顶部导航高度
  static double get navbarHegiht => ScreenUtil().setWidth(42);
  // 底部导航高度
  static double get bottomnavbarHegiht => ScreenUtil().setWidth(64);
  // 页面通用边距
  static double get pagePadding => ScreenUtil().setWidth(16);
  // 页面通用透明背景色
  static Color get bgDefault => const Color.fromRGBO(188, 136, 255, 0.12);
  // 页面通用白色
  static Color get colorWhite => const Color(0xffffffff);
  // 页面通用红色
  static Color get colorRed => const Color(0xffFF00B3);
  // 页面通用灰色
  static Color get colorGray => const Color(0x99FFFFFF);
  // 白色字体样式
  static TextStyle white10 = TextStyle(
    color: colorWhite,
    fontSize: ScreenUtil().setSp(10),
    overflow: TextOverflow.ellipsis,
    decoration: TextDecoration.none,
  );
  static TextStyle white12 = TextStyle(
    color: colorWhite,
    fontSize: ScreenUtil().setSp(12),
    overflow: TextOverflow.ellipsis,
    decoration: TextDecoration.none,
  );
  static TextStyle white14 = TextStyle(
    color: colorWhite,
    fontSize: ScreenUtil().setSp(14),
    overflow: TextOverflow.ellipsis,
    decoration: TextDecoration.none,
  );
  static TextStyle white16 = TextStyle(
    color: colorWhite,
    fontSize: ScreenUtil().setSp(16),
    overflow: TextOverflow.ellipsis,
    decoration: TextDecoration.none,
  );
  static TextStyle white18 = TextStyle(
    color: colorWhite,
    fontSize: ScreenUtil().setSp(18),
    overflow: TextOverflow.ellipsis,
    decoration: TextDecoration.none,
  );
  // 红色字体样式
  static TextStyle red10 = TextStyle(
    color: colorRed,
    fontSize: ScreenUtil().setSp(10),
    overflow: TextOverflow.ellipsis,
    decoration: TextDecoration.none,
  );
  static TextStyle red12 = TextStyle(
    color: colorRed,
    fontSize: ScreenUtil().setSp(12),
    overflow: TextOverflow.ellipsis,
    decoration: TextDecoration.none,
  );
  static TextStyle red14 = TextStyle(
    color: colorRed,
    fontSize: ScreenUtil().setSp(14),
    overflow: TextOverflow.ellipsis,
    decoration: TextDecoration.none,
  );
  static TextStyle red16 = TextStyle(
    color: colorRed,
    fontSize: ScreenUtil().setSp(16),
    overflow: TextOverflow.ellipsis,
    decoration: TextDecoration.none,
  );
  static TextStyle red18 = TextStyle(
    color: colorRed,
    fontSize: ScreenUtil().setSp(18),
    overflow: TextOverflow.ellipsis,
    decoration: TextDecoration.none,
  );
  // 灰色字体样式
  static TextStyle gray10 = TextStyle(
    color: colorGray,
    fontSize: ScreenUtil().setSp(10),
    overflow: TextOverflow.ellipsis,
    decoration: TextDecoration.none,
  );
  static TextStyle gray12 = TextStyle(
    color: colorGray,
    fontSize: ScreenUtil().setSp(12),
    overflow: TextOverflow.ellipsis,
    decoration: TextDecoration.none,
  );
  static TextStyle gray14 = TextStyle(
    color: colorGray,
    fontSize: ScreenUtil().setSp(14),
    overflow: TextOverflow.ellipsis,
    decoration: TextDecoration.none,
  );
  static TextStyle gray16 = TextStyle(
    color: colorGray,
    fontSize: ScreenUtil().setSp(16),
    overflow: TextOverflow.ellipsis,
    decoration: TextDecoration.none,
  );
  static TextStyle gray18 = TextStyle(
    color: colorGray,
    fontSize: ScreenUtil().setSp(18),
    overflow: TextOverflow.ellipsis,
    decoration: TextDecoration.none,
  );

  static TextStyle white20bold = TextStyle(
      color: Color.fromRGBO(255, 255, 255, 1),
      fontSize: ScreenUtil().setSp(20),
      fontWeight: FontWeight.bold,
      overflow: TextOverflow.ellipsis,
      decoration: TextDecoration.none);
}
