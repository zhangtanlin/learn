import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:iaimei/model/base_response.dart';
import 'package:iaimei/net/http_error.dart';
import 'package:iaimei/utils/http.dart';
import 'package:iaimei/utils/log_util.dart';

enum HttpRequestMethod { get, post, put, patch, delete }

///http请求成功回调
typedef OnSuccess<T> = void Function(dynamic data);

///失败回调
typedef OnFailure = void Function(HttpError error);

class HttpRequest {
  // 私有的命名构造函数
  HttpRequest._internal();

  factory HttpRequest() => _instance;

  static late final HttpRequest _instance = HttpRequest._internal();

  ///同一个CancelToken可以用于多个请求，当一个CancelToken取消时，所有使用该CancelToken的请求都会被取消，一个页面对应一个CancelToken。
  final Map<String, CancelToken> _cancelTokens = <String, CancelToken>{};

  request(HttpRequestMethod method, String url, String tag,
      OnSuccess successCallback, OnFailure errorCallback,
      {Map<String, dynamic>? params, bool isJson = true}) async {
    dynamic formData;
    if (!isJson) {
      formData = (params != null ? FormData.fromMap(params) : null) as dynamic;
    } else {
      formData = params as dynamic;
    }
    try {
      CancelToken cancelToken;
      Response? response;
      cancelToken = _cancelTokens[tag] ?? CancelToken();
      _cancelTokens[tag] = cancelToken;

      switch (method) {
        case HttpRequestMethod.get:
          response = await PlatformAwareHttp.get(url,
              params: params, cancelToken: cancelToken);
          break;
        case HttpRequestMethod.post:
          response = await PlatformAwareHttp.post(url,
              data: formData, cancelToken: cancelToken);
          break;
        case HttpRequestMethod.put:
          break;
        case HttpRequestMethod.patch:
          break;
        case HttpRequestMethod.delete:
          break;
      }

      int? statusCode = response?.statusCode;
      // LogUtil.i("[ resp data d]----->${jsonEncode(response?.data)}");
      if (statusCode == 200) {
        BaseResponse resp = BaseResponse.fromJson(response?.data);
        LogUtil.i("[ resp data b]----->${jsonEncode(resp.data)}");
        if (resp.status == 1) {
          successCallback(resp.data);
        } else {
          errorCallback(HttpError(code: resp.status, message: resp.msg ?? ''));
        }
      }
    } on DioError catch (error) {
      errorCallback(HttpError.dioError(error));
    }
  }

  ///取消网络请求
  void cancel(String tag) {
    if (_cancelTokens.containsKey(tag)) {
      if (!(_cancelTokens[tag]!.isCancelled)) {
        _cancelTokens[tag]?.cancel();
      }
      _cancelTokens.remove(tag);
    }
  }

  postRequest(String url, String tag, OnSuccess successCallback,
      OnFailure errorCallback,
      {Map<String, dynamic>? params}) {
    request(HttpRequestMethod.post, url, tag, successCallback, errorCallback,
        params: params, isJson: true);
  }

  getRequest(String url, String tag, OnSuccess successCallback,
      OnFailure errorCallback,
      {Map<String, dynamic>? params}) {
    request(HttpRequestMethod.get, url, tag, successCallback, errorCallback,
        params: params, isJson: true);
  }
}
