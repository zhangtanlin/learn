import 'package:dio/dio.dart';

class HttpError {
  ///HTTP 状态码
  static const int UNAUTHORIZED = 401;
  static const int FORBIDDEN = 403;
  static const int NOT_FOUND = 404;
  static const int REQUEST_TIMEOUT = 408;
  static const int INTERNAL_SERVER_ERROR = 500;
  static const int BAD_GATEWAY = 502;
  static const int SERVICE_UNAVAILABLE = 503;
  static const int GATEWAY_TIMEOUT = 504;
  static const int NO_NETWORK = -2;

  int? code;

  String? message;

  HttpError({this.code = -1, this.message = "未知错误"});

  HttpError.dioError(DioError error) {
    message = error.message;
    switch (error.type) {
      case DioErrorType.connectTimeout:
        code = -2;
        message = "网络连接超时，请检查网络设置";
        break;
      case DioErrorType.receiveTimeout:
        code = -2;
        message = "服务器响应超时，请稍后重试";
        break;
      case DioErrorType.sendTimeout:
        code = -2;
        message = "网络请求超时，请检查网络设置";
        break;
      case DioErrorType.response:
        {
          int? errCode = error.response?.statusCode;
          code = errCode;
          switch (errCode) {
            case 400:
              message = "请求语法错误";
              break;
            case UNAUTHORIZED:
              message = "未完成用户认证，没有权限";
              break;
            case FORBIDDEN:
              message = "服务器拒绝执行";
              break;
            case NOT_FOUND:
              message = "无法连接服务器";
              break;
            case 405:
              message = "请求方法被禁止";
              break;
            case INTERNAL_SERVER_ERROR:
              message = "服务器内部错误";
              break;
            case BAD_GATEWAY:
              message = "无效的请求";
              break;
            case SERVICE_UNAVAILABLE:
              message = "服务器超载";
              break;
            case GATEWAY_TIMEOUT:
              message = "网关超时";
              break;
            case 505:
              message = "不支持HTTP协议请求";
              break;
            default:
              message = error.response?.statusMessage ?? '未知错误';
              break;
          }
        }
        break;
      case DioErrorType.cancel:
        message = "请求已被取消，请重新请求";
        break;
      case DioErrorType.other:
        code = NO_NETWORK;
        message = "网络异常，请稍后重试";
        break;
    }
  }

  @override
  String toString() {
    return 'HttpError{code: $code, message: $message}';
  }
}
