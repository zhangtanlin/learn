import 'package:iaimei/net/http_api.dart';
import 'package:iaimei/net/http_request.dart';
import 'package:iaimei/net/http_request_tag.dart';

class HttpHelper {
  static appConfig(OnSuccess successBlock, OnFailure failureBlock) {
    HttpRequest().postRequest(
        '/api/home/getConfig', 'appConfig', successBlock, failureBlock);
  }

  static void getComicsIndex(
      OnSuccess successCallback, OnFailure errorCallback) {
    HttpRequest().postRequest(HttpApi.getComicsIndex,
        HttpRequestTag.getComicsIndex, successCallback, errorCallback);
  }

  static void getAtlasIndex(
      OnSuccess successCallback, OnFailure errorCallback) {
    HttpRequest().postRequest(HttpApi.getAtlasIndex,
        HttpRequestTag.getAtlasIndex, successCallback, errorCallback);
  }

  static void updateInvite(
      String code, OnSuccess successCallback, OnFailure errorCallback) {
    Map<String, dynamic> params = {};
    params['aff_code'] = code;
    HttpRequest().postRequest(HttpApi.updateInvite, HttpRequestTag.updateInvite,
        successCallback, errorCallback,
        params: params);
  }

  static void requestCommonInterface(String api, Map<String, dynamic> params,
      OnSuccess successCallback, OnFailure errorCallback) {
    HttpRequest()
        .postRequest(api, api, successCallback, errorCallback, params: params);
  }

  static void getCommonIndexList(
      String api,
      String id,
      String subName,
      int curPage,
      int pageSize,
      OnSuccess successCallback,
      OnFailure errorCallback) {
    Map<String, dynamic> params = {};
    params['id'] = id;
    params['sub'] = subName;
    params['page'] = curPage;
    params['limit'] = pageSize;
    HttpRequest()
        .postRequest(api, api, successCallback, errorCallback, params: params);
  }

  static void getComicsIndexList(String id, String subName, int curPage,
      int pageSize, OnSuccess successCallback, OnFailure errorCallback) {
    Map<String, dynamic> params = {};
    params['id'] = id;
    params['sub'] = subName;
    params['page'] = curPage;
    params['limit'] = pageSize;
    HttpRequest().postRequest(HttpApi.getComicsIndexList,
        HttpRequestTag.getComicsIndexList, successCallback, errorCallback,
        params: params);
  }

  static void getComicsSeriesList(String id, int curPage, int pageSize,
      OnSuccess successCallback, OnFailure errorCallback) {
    Map<String, dynamic> params = {};
    params['id'] = id;
    params['page'] = curPage;
    params['limit'] = pageSize;
    HttpRequest().postRequest(HttpApi.getComicsSeriesList,
        HttpRequestTag.getComicsSeriesList, successCallback, errorCallback,
        params: params);
  }

  static void getAtlasSeriesList(String id, int curPage, int pageSize,
      OnSuccess successCallback, OnFailure errorCallback) {
    Map<String, dynamic> params = {};
    params['id'] = id;
    params['page'] = curPage;
    params['limit'] = pageSize;
    HttpRequest().postRequest(HttpApi.getAtlasSeriesList,
        HttpRequestTag.getAtlasSeriesList, successCallback, errorCallback,
        params: params);
  }

  static void getComicsDetail(
      String id, OnSuccess successCallback, OnFailure errorCallback) {
    Map<String, dynamic> params = {};
    params['id'] = id;
    HttpRequest().postRequest(HttpApi.getComicsDetail,
        HttpRequestTag.getComicsDetail, successCallback, errorCallback,
        params: params);
  }

  static void getChatDetail(dynamic id, dynamic uid, OnSuccess successCallback,
      OnFailure errorCallback) {
    Map<String, dynamic> params = {};
    params['info_id'] = id;
    params['uid'] = uid;
    HttpRequest().postRequest(HttpApi.getChatDetail,
        HttpRequestTag.getChatDetail, successCallback, errorCallback,
        params: params);
  }

  static void cancelComicsDetail() {
    HttpRequest().cancel(HttpRequestTag.getComicsDetail);
  }

  static void getAtlasDetail(
      String id, OnSuccess successCallback, OnFailure errorCallback) {
    Map<String, dynamic> params = {};
    params['id'] = id;
    HttpRequest().postRequest(HttpApi.getAtlasDetail,
        HttpRequestTag.getAtlasDetail, successCallback, errorCallback,
        params: params);
  }

  static void likeAtlas(
      String id, OnSuccess successCallback, OnFailure errorCallback) {
    Map<String, dynamic> params = {};
    params['id'] = id;
    HttpRequest().postRequest(HttpApi.likeAtlas, HttpRequestTag.likeAtlas,
        successCallback, errorCallback,
        params: params);
  }

  static void atlasUnlock(String id, String type, OnSuccess successCallback,
      OnFailure errorCallback) {
    Map<String, dynamic> params = {};
    params['id'] = id;
    params['type'] = type;
    HttpRequest().postRequest(HttpApi.atlasUnlock, HttpRequestTag.atlasUnlock,
        successCallback, errorCallback,
        params: params);
  }

  static void comicsUnlock(String id, String type, OnSuccess successCallback,
      OnFailure errorCallback) {
    Map<String, dynamic> params = {};
    params['id'] = id;
    params['type'] = type;
    HttpRequest().postRequest(HttpApi.comicsUnlock, HttpRequestTag.comicsUnlock,
        successCallback, errorCallback,
        params: params);
  }

  static void novelUnlock(String id, String type, OnSuccess successCallback,
      OnFailure errorCallback) {
    Map<String, dynamic> params = {};
    params['id'] = id;
    params['type'] = type;
    HttpRequest().postRequest(HttpApi.novelUnlock, HttpRequestTag.novelUnlock,
        successCallback, errorCallback,
        params: params);
  }

  static void videoUnlock(String id, String type, OnSuccess successCallback,
      OnFailure errorCallback) {
    Map<String, dynamic> params = {};
    params['id'] = id;
    params['type'] = type;
    HttpRequest().postRequest(HttpApi.videoUnlock, HttpRequestTag.videoUnlock,
        successCallback, errorCallback,
        params: params);
  }

  static void datingUnlock(String id, String type, OnSuccess successCallback,
      OnFailure errorCallback) {
    Map<String, dynamic> params = {};
    params['info_id'] = id;
    params['type'] = type;
    HttpRequest().postRequest(HttpApi.datingUnlock, HttpRequestTag.datingUnlock,
        successCallback, errorCallback,
        params: params);
  }

  static void getComicsCatalogList(String id, int curPage, int pageSize,
      OnSuccess successCallback, OnFailure errorCallback) {
    Map<String, dynamic> params = {};
    params['id'] = id;
    params['page'] = curPage;
    params['limit'] = pageSize;
    HttpRequest().postRequest(HttpApi.getComicsCatalogList,
        HttpRequestTag.getComicsCatalogList, successCallback, errorCallback,
        params: params);
  }

  static void getNovelCatalogList(String id, String order, int curPage,
      int pageSize, OnSuccess successCallback, OnFailure errorCallback) {
    Map<String, dynamic> params = {};
    params['id'] = id;
    params['order'] = order;
    params['page'] = curPage;
    params['limit'] = pageSize;
    HttpRequest().postRequest(HttpApi.getNovelCatalogList,
        HttpRequestTag.getNovelCatalogList, successCallback, errorCallback,
        params: params);
  }

  static void getComicsMore(
      String id, OnSuccess successCallback, OnFailure errorCallback) {
    Map<String, dynamic> params = {};
    params['id'] = id;
    HttpRequest().postRequest(HttpApi.getComicsMore,
        HttpRequestTag.getComicsMore, successCallback, errorCallback,
        params: params);
  }

  static void cancelComicsMore() {
    HttpRequest().cancel(HttpRequestTag.getComicsMore);
  }

  static void getComicContentImg(String id, String chapterId,
      OnSuccess successCallback, OnFailure errorCallback) {
    Map<String, dynamic> params = {};
    params['comics_id'] = id;
    params['series_id'] = chapterId;
    HttpRequest().postRequest(HttpApi.getComicsContentImg,
        HttpRequestTag.getComicsContentImg, successCallback, errorCallback,
        params: params);
  }

  static void getNovelContent(String id, String chapterId,
      OnSuccess successCallback, OnFailure errorCallback) {
    Map<String, dynamic> params = {};
    params['id'] = id;
    params['series_id'] = chapterId;
    HttpRequest().postRequest(HttpApi.getNovelContent,
        HttpRequestTag.getNovelContent, successCallback, errorCallback,
        params: params);
  }

  static void cancelNovelContent() {
    HttpRequest().cancel(HttpRequestTag.getNovelContent);
  }

  static void getNovelIndex(
      OnSuccess successCallback, OnFailure errorCallback) {
    HttpRequest().postRequest(HttpApi.getNovelIndex,
        HttpRequestTag.getNovelIndex, successCallback, errorCallback);
  }

  static void getNovelSeriesList(String id, int curPage, int pageSize,
      OnSuccess successCallback, OnFailure errorCallback) {
    Map<String, dynamic> params = {};
    params['id'] = id;
    params['page'] = curPage;
    params['limit'] = pageSize;
    HttpRequest().postRequest(HttpApi.getNovelSeriesList,
        HttpRequestTag.getComicsSeriesList, successCallback, errorCallback,
        params: params);
  }

  static void getChatRecList(int curPage, int pageSize,
      OnSuccess successCallback, OnFailure errorCallback) {
    Map<String, dynamic> params = {};
    params['page'] = curPage;
    params['limit'] = pageSize;
    HttpRequest().postRequest(HttpApi.getChatRecList,
        HttpRequestTag.getChatRecList, successCallback, errorCallback,
        params: params);
  }

  static void searchIndex(OnSuccess successCallback, OnFailure errorCallback) {
    HttpRequest().postRequest(HttpApi.searchIndex, HttpRequestTag.searchIndex,
        successCallback, errorCallback);
  }

  static void searchVideoList(String keywords, int curPage, int pageSize,
      OnSuccess successCallback, OnFailure errorCallback) {
    Map<String, dynamic> params = {};
    params['kwy'] = keywords;
    params['page'] = curPage;
    params['limit'] = pageSize;
    HttpRequest().postRequest(HttpApi.searchVideoList,
        HttpRequestTag.searchVideoList, successCallback, errorCallback,
        params: params);
  }

  static void searchShortVideoList(String keywords, int curPage, int pageSize,
      OnSuccess successCallback, OnFailure errorCallback) {
    Map<String, dynamic> params = {};
    params['kwy'] = keywords;
    params['page'] = curPage;
    params['limit'] = pageSize;
    HttpRequest().postRequest(HttpApi.searchShortVideoList,
        HttpRequestTag.searchShortVideoList, successCallback, errorCallback,
        params: params);
  }

  static void searchAtlasList(String keywords, int curPage, int pageSize,
      OnSuccess successCallback, OnFailure errorCallback) {
    Map<String, dynamic> params = {};
    params['kwy'] = keywords;
    params['page'] = curPage;
    params['limit'] = pageSize;
    HttpRequest().postRequest(HttpApi.searchAtlasList,
        HttpRequestTag.searchAtlasList, successCallback, errorCallback,
        params: params);
  }

  static void searchComicsList(String keywords, int curPage, int pageSize,
      OnSuccess successCallback, OnFailure errorCallback) {
    Map<String, dynamic> params = {};
    params['kwy'] = keywords;
    params['page'] = curPage;
    params['limit'] = pageSize;
    HttpRequest().postRequest(HttpApi.searchComicsList,
        HttpRequestTag.searchComicsList, successCallback, errorCallback,
        params: params);
  }

  static void searchNovelList(String keywords, int curPage, int pageSize,
      OnSuccess successCallback, OnFailure errorCallback) {
    Map<String, dynamic> params = {};
    params['kwy'] = keywords;
    params['page'] = curPage;
    params['limit'] = pageSize;
    HttpRequest().postRequest(HttpApi.searchNovelList,
        HttpRequestTag.searchNovelList, successCallback, errorCallback,
        params: params);
  }

  static void getNovelDetail(
      String id, OnSuccess successCallback, OnFailure errorCallback) {
    Map<String, dynamic> params = {};
    params['id'] = id;
    HttpRequest().postRequest(HttpApi.getNovelDetail,
        HttpRequestTag.getNovelDetail, successCallback, errorCallback,
        params: params);
  }

  static void cancelNovelDetail() {
    HttpRequest().cancel(HttpRequestTag.getNovelDetail);
  }

  static void getNovelMore(
      String id, OnSuccess successCallback, OnFailure errorCallback) {
    Map<String, dynamic> params = {};
    params['id'] = id;
    HttpRequest().postRequest(HttpApi.getNovelMore, HttpRequestTag.getNovelMore,
        successCallback, errorCallback,
        params: params);
  }

  static void cancelNovelMore() {
    HttpRequest().cancel(HttpRequestTag.getNovelMore);
  }

  static void likeComics(
      String id, OnSuccess successCallback, OnFailure errorCallback) {
    Map<String, dynamic> params = {};
    params['id'] = id;
    HttpRequest().postRequest(HttpApi.likeComicsItem,
        HttpRequestTag.likeComicsItem, successCallback, errorCallback,
        params: params);
  }

  static void likeNovel(
      String id, OnSuccess successCallback, OnFailure errorCallback) {
    Map<String, dynamic> params = {};
    params['id'] = id;
    HttpRequest().postRequest(HttpApi.likeNovelItem,
        HttpRequestTag.likeNovelItem, successCallback, errorCallback,
        params: params);
  }

  static void getVideoDetail(
      int id, OnSuccess successCallback, OnFailure errorCallback) {
    Map<String, dynamic> params = {};
    params['id'] = id;
    HttpRequest().postRequest(HttpApi.getVideoDetail,
        HttpRequestTag.getVideoDetail, successCallback, errorCallback,
        params: params);
  }

  static void likeVideoAction(
      int id, OnSuccess successCallback, OnFailure errorCallback) {
    Map<String, dynamic> params = {};
    params['id'] = id;
    HttpRequest().postRequest(HttpApi.likeVideoAction,
        HttpRequestTag.likeVideoAction, successCallback, errorCallback,
        params: params);
  }

  static void likeChatAction(
      int id, OnSuccess successCallback, OnFailure errorCallback) {
    Map<String, dynamic> params = {};
    params['info_id'] = id;
    HttpRequest().postRequest(HttpApi.likeChatAction,
        HttpRequestTag.likeChatAction, successCallback, errorCallback,
        params: params);
  }

  static void getChatFilterData(String age, String cup,
      OnSuccess successCallback, OnFailure errorCallback) {
    Map<String, dynamic> params = {};
    params['age'] = age;
    params['cup'] = cup;
    HttpRequest().postRequest(HttpApi.chatFilterAction,
        HttpRequestTag.chatFilterAction, successCallback, errorCallback,
        params: params);
  }

  static void getChatRanking(int type,
      OnSuccess successCallback, OnFailure errorCallback) {
    Map<String, dynamic> params = {};
    params['type'] = type;
    HttpRequest().postRequest(HttpApi.getChatRanking,
        HttpRequestTag.getChatRanking, successCallback, errorCallback,
        params: params);
  }


  static void chatBuyAction(int infoId, String chatSet,
      OnSuccess successCallback, OnFailure errorCallback) {
    Map<String, dynamic> params = {};
    params['info_id'] = infoId;
    params['chatset'] = chatSet;
    params['type'] = 'resource_coins';
    HttpRequest().postRequest(HttpApi.chatBuyAction,
        HttpRequestTag.chatBuyAction, successCallback, errorCallback,
        params: params);
  }

  static void chatRewardAction(
      int uid, String gid, OnSuccess successCallback, OnFailure errorCallback) {
    Map<String, dynamic> params = {};
    params['uid'] = uid;
    params['type'] = 1;
    params['gid'] = gid;
    HttpRequest().postRequest(HttpApi.chatRewardAction,
        HttpRequestTag.chatRewardAction, successCallback, errorCallback,
        params: params);
  }

  static void getDatingHomeTab(
      OnSuccess successCallback, OnFailure errorCallback) {
    HttpRequest().postRequest(HttpApi.datingHomeTab,
        HttpRequestTag.datingHomeTab, successCallback, errorCallback);
  }

  static void likeDatingAction(
      String id, OnSuccess successCallback, OnFailure errorCallback) {
    Map<String, dynamic> params = {};
    params['info_id'] = id;
    HttpRequest().postRequest(HttpApi.likeDatingItem,
        HttpRequestTag.likeDatingItemAction, successCallback, errorCallback,
        params: params);
  }

  static void getDatingDetail(Map<String, dynamic> params,
      OnSuccess successCallback, OnFailure errorCallback) {
    HttpRequest().postRequest(HttpApi.getDatingDetail,
        HttpRequestTag.getDatingDetail, successCallback, errorCallback,
        params: params);
  }

  static void getDatingFilter(
      OnSuccess successCallback, OnFailure errorCallback) {
    HttpRequest().postRequest(HttpApi.getDatingFilter,
        HttpRequestTag.getDatingFilter, successCallback, errorCallback);
  }

  static void getDatingCityList(
      OnSuccess successCallback, OnFailure errorCallback) {
    HttpRequest().postRequest(HttpApi.getDatingCityList,
        HttpRequestTag.getDatingCityList, successCallback, errorCallback);
  }



  static productList(type, OnSuccess successBlock, OnFailure failureBlock) {
    HttpRequest().postRequest(
        '/api/product/list', 'api/product/list', successBlock, failureBlock,
        params: {'type': type});
  }

  static cardsList(OnSuccess successBlock, OnFailure failureBlock) {
    HttpRequest().postRequest(
        '/api/users/cards', 'api/users/cards', successBlock, failureBlock);
  }

  static gainGold(param, OnSuccess successBlock, OnFailure failureBlock) {
    HttpRequest().postRequest(
        '/api/users/gain_gold', 'gainGold', successBlock, failureBlock,
        params: param);
  }

  static createOrder(param, OnSuccess successBlock, OnFailure failureBlock) {
    HttpRequest().postRequest('/api/product/create_order', 'productCreateOrder',
        successBlock, failureBlock,
        params: param);
  }

  static paymentList(param, OnSuccess successBlock, OnFailure failureBlock) {
    HttpRequest().postRequest(
        '/api/users/orders', 'usersOrders', successBlock, failureBlock,
        params: param);
  }

  static expendIncome(param, OnSuccess successBlock, OnFailure failureBlock) {
    HttpRequest().postRequest(
        '/api/users/coin_log', 'usersCoins', successBlock, failureBlock,
        params: param);
  }

  static withdrawList(param, OnSuccess successBlock, OnFailure failureBlock) {
    HttpRequest().postRequest(
        '/api/proxy/my_draw_list', 'withdrawList', successBlock, failureBlock,
        params: param);
  }

  static categoryList(OnSuccess successBlock, OnFailure failureBlock) {
    HttpRequest().postRequest(
        '/api/mv/category', 'mvCategory', successBlock, failureBlock);
  }

  static historyAccount(OnSuccess successBlock, OnFailure failureBlock) {
    HttpRequest().postRequest(
        '/api/users/history_account', 'hisAccount', successBlock, failureBlock);
  }

  static overWithdraw(param, OnSuccess successBlock, OnFailure failureBlock) {
    HttpRequest().postRequest(
        '/api/proxy/withdraw', 'overWithdraw', successBlock, failureBlock,
        params: param);
  }

  static incomeData(OnSuccess successBlock, OnFailure failureBlock) {
    HttpRequest().postRequest(
        '/api/proxy/proxy_stat', 'incomeData', successBlock, failureBlock);
  }

  static incomeType(param, OnSuccess successBlock, OnFailure failureBlock) {
    HttpRequest().postRequest(
        '/api/proxy/proxy_list', 'icomeType', successBlock, failureBlock,
        params: param);
  }

  /* ********** 作品 ********* */
  static worksWait(param, OnSuccess successBlock, OnFailure failureBlock) {
    HttpRequest().postRequest(
        '/api/works/wait', 'workWait', successBlock, failureBlock,
        params: param);
  }

  static worksReject(param, OnSuccess successBlock, OnFailure failureBlock) {
    HttpRequest().postRequest(
        '/api/works/reject', 'workReject', successBlock, failureBlock,
        params: param);
  }

  static worksRelease(param, OnSuccess successBlock, OnFailure failureBlock) {
    HttpRequest().postRequest(
        '/api/works/release', 'workRelease', successBlock, failureBlock,
        params: param);
  }

  static uploadTags(OnSuccess successBlock, OnFailure failureBlock) {
    HttpRequest().postRequest(
        '/api/works/uper_tags', 'uperTags', successBlock, failureBlock);
  }

  static uploadWork(param, OnSuccess successBlock, OnFailure failureBlock) {
    HttpRequest().postRequest(
        '/api/works/upload', 'uplodWorks', successBlock, failureBlock,
        params: param);
  }

/* ********** ---- ********* */

  static upperList(OnSuccess successBlock, OnFailure failureBlock) {
    HttpRequest().postRequest(
        '/api/creator/uper_list', 'uperlist', successBlock, failureBlock);
  }

  static actorList(OnSuccess successBlock, OnFailure failureBlock) {
    HttpRequest().postRequest(
        '/api/av/actor_all', 'actorAll', successBlock, failureBlock);
  }

  static actorWorks(param, OnSuccess successBlock, OnFailure failureBlock) {
    HttpRequest().postRequest(
        '/api/av/actor_works', 'actorWorks', successBlock, failureBlock,
        params: param);
  }

  static preVerify(param, OnSuccess successBlock, OnFailure failureBlock) {
    HttpRequest().postRequest(
        '/api/creator/pre_verify', 'preVerify', successBlock, failureBlock,
        params: param);
  }

  static dateLoveInfo(OnSuccess successBlock, OnFailure failureBlock) {
    HttpRequest().postRequest(
        '/api/girl/meet_select', 'dateLoveInfo', successBlock, failureBlock);
  }

  static submitDateLoveInfo(
      param, OnSuccess successBlock, OnFailure failureBlock) {
    HttpRequest().postRequest(
        '/api/girl/create', 'submitDateLoveInfo', successBlock, failureBlock,
        params: param);
  }

  static dateLoveList(param, OnSuccess successBlock, OnFailure failureBlock) {
    HttpRequest().postRequest(
        '/api/girl/my_meet', 'dateLoveList', successBlock, failureBlock,
        params: param);
  }

  // info_id
  static dateLoveDelete(param, OnSuccess successBlock, OnFailure failureBlock) {
    HttpRequest().postRequest(
        '/api/girl/delete', 'dateLoveDelte', successBlock, failureBlock,
        params: param);
  }

  // info_id
  static dateLoveUpDown(param, OnSuccess successBlock, OnFailure failureBlock) {
    HttpRequest().postRequest(
        'api/girl/toggle_listed', 'dateLoveUpDown', successBlock, failureBlock,
        params: param);
  }

  static submitDateLoveAuth(
      param, OnSuccess successBlock, OnFailure failureBlock) {
    HttpRequest().postRequest(
        '/api/creator/apply', 'submitDateLoveAuth', successBlock, failureBlock,
        params: param);
  }

  static inviteList(param, OnSuccess successBlock, OnFailure failureBlock) {
    HttpRequest().postRequest(
        '/api/proxy/invite_list', 'inviteList', successBlock, failureBlock,
        params: param);
  }

  static creatorVideo(param, OnSuccess successBlock, OnFailure failureBlock) {
    HttpRequest().postRequest(
        '/api/works/videos', 'creatorVideos', successBlock, failureBlock,
        params: param);
  }

  static fansClubVideo(param, OnSuccess successBlock, OnFailure failureBlock) {
    HttpRequest().postRequest(
        '/api/works/club_videos', 'clubVideos', successBlock, failureBlock,
        params: param);
  }

  static joinFansClub(param, OnSuccess successBlock, OnFailure failureBlock) {
    HttpRequest().postRequest(
        '/api/creator/join_club', 'joinClub', successBlock, failureBlock,
        params: param);
  }

  static attentCreator(param, OnSuccess successBlock, OnFailure failureBlock) {
    HttpRequest().postRequest(
        '/api/users/following', 'attentCreator', successBlock, failureBlock,
        params: param);
  }

  static rewardGiftList(OnSuccess successBlock, OnFailure failureBlock) {
    HttpRequest().postRequest(
        '/api/home/gift_list', 'giftList', successBlock, failureBlock);
  }

  static downloadLimit(param, OnSuccess successBlock, OnFailure failureBlock) {
    HttpRequest().postRequest(
        '/api/system/download', 'download', successBlock, failureBlock,
        params: param);
  }
}
