
/// 项目常量
class AppConst {

  static const bool isDebug = false;
  static const String appVersion = '2.6.0';

  static const String KEY_TOKEN = "aimei_token";
  static const String OAUTH_TYPE = "pwa";
  static const String logPrefix = ">>>>>aimei<<<<<";
  static const String appPrefix = "aimei";

  static const String appHiveBoxName = 'AMHiveBox';
  static const String imgCacheHiveBoxName = 'AMImgCacheHiveBox';
  static const String bundleId = "com.aimei.iaimei";
  static const String searchHistoryKey = 'searchHistory';
  static const String oauthTypeIos = 'ios';
  static const String oauthTypeAndroid = 'android';
  static const String oauthTypeWeb = 'web';
  static const String apiLinesKey = 'apiLines';
  static const String appClipboardPrefix = 'aimei_aff';
  static const String comicsReadWayKey = 'ComicsReadWay';
  static const String readTypeKey = 'type';
  static const String readTimeKey = 'time';
  static const int typeManualRead = 0;
  static const int typeAutoRead = 1;
  static const String comicsReadRecordBoxName = 'AMComicsReadRecord';
  static const String novelReadRecordBoxName = 'AMNovelReadRecord';
  static const String videoWatchRecordBoxName = 'AMVideoWatchRecord';
  static const String shortVideoWatchRecordBoxName = 'AMShortVideoWatchRecord';
  static const String splashAdKey = 'splashAd';

  // 数据库-约炮选中的城市
  static const String datingCityKey = 'AMDatingCity';

  static List<String> apiLines = [
    "https://mapi01.myb6api.xyz/api.php",
    "https://am.yiqiapi01.com/api.php",
    "https://am.yiqiapi01.net/api.php"
  ];

  // static List<String> apiLines = [
  //   "http://gogo.hyys.info/api.php",
  //   "http://gogo.hyys.info/api.php",
  //   "http://gogo.hyys.info/api.php"
  // ];

  static String githubUrl =
      "https://raw.githubusercontent.com/little-5/backup/master/aimei.txt";
}
