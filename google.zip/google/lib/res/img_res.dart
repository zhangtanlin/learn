// ignore_for_file: non_constant_identifier_names

class ImgRes {
  static String IMAGE_PATH = 'assets/images/';
  static String IMAGE_COMMON_PATH = '${IMAGE_PATH}common/';
  static String IMAGE_COMICS_PATH = '${IMAGE_PATH}comics/';
  static String IMAGE_INPUT_PATH = '${IMAGE_PATH}input/';
  static String IMAGE_VIDEO_PATH = '${IMAGE_PATH}video/';
  static String IMAGE_BUTTON_PATH = '${IMAGE_PATH}button/';
  static String IMAGE_CHAT_PATH = '${IMAGE_PATH}chat/';
  static String LOTTIE_PATH = 'assets/lottie/';
  static String IMG_APP_BG = '${IMAGE_COMMON_PATH}app_bg.png';
  static String IC_ARROW_BACK = '${IMAGE_COMMON_PATH}ic_arrow_back.png';
  static String IC_ARROW_BACK_GOLD = '${IMAGE_COMMON_PATH}ic_arrow_back_gold.png';
  static String IC_NO_DATA = '${IMAGE_COMMON_PATH}ic_no_data.png';
  static String IC_NO_NETWORK = '${IMAGE_COMMON_PATH}ic_no_network.png';
  static String IC_LOAD_ERROR = '${IMAGE_COMMON_PATH}ic_load_error.png';
  static String DOWN_REFRESH_GIF = '${IMAGE_COMMON_PATH}downrefresh.gif';
  static String IC_SEARCH = '${IMAGE_COMMON_PATH}ic_search.png';
  static String IC_MORE = '${IMAGE_COMMON_PATH}ic_more.png';
  static String IC_FILTER = '${IMAGE_COMMON_PATH}ic_filter.png';
  static String IC_DIALOG_CLOSE = '${IMAGE_COMMON_PATH}ic_dialog_close.png';
  static String IC_PLACEHOLDER_LOGO =
      '${IMAGE_COMMON_PATH}ic_placeholder_logo.png';
  static String IC_ARROW_RIGHT = '${IMAGE_COMMON_PATH}ic_arrow_right.png';
  static String IC_BADGE_VIP = '${IMAGE_COMMON_PATH}ic_badge_vip.png';
  static String IC_BADGE_COIN = '${IMAGE_COMMON_PATH}ic_badge_coin.png';
  static String IC_BADGE_FREE = '${IMAGE_COMMON_PATH}ic_badge_free.png';
  static String IC_BADGE_FAN = '${IMAGE_COMMON_PATH}ic_badge_fan.png';
  static String IC_BADGE_NEW = '${IMAGE_COMMON_PATH}ic_badge_new.png';
  static String DIALOG_BTN_BG = '${IMAGE_COMMON_PATH}dialog_btn_bg.png';
  static String IC_BADGE_PAY = '${IMAGE_COMMON_PATH}ic_badge_pay.png';
  static String IC_BADGE_AUTH = '${IMAGE_COMMON_PATH}ic_badge_auth.png';

  static String IMG_BG_BTN = '${IMAGE_COMICS_PATH}img_bg_btn.png';
  static String IC_RESORT = '${IMAGE_COMICS_PATH}ic_resort.png';
  static String IC_READER_LIKE = '${IMAGE_COMICS_PATH}ic_reader_like.png';
  static String IC_READER_SHARE = '${IMAGE_COMICS_PATH}ic_reader_share.png';
  static String IC_COMICS_PLAY = '${IMAGE_COMICS_PATH}ic_comics_play.png';
  static String IC_ADD = '${IMAGE_COMICS_PATH}ic_add.png';
  static String IC_ADD_INACTIVE = '${IMAGE_COMICS_PATH}ic_add_inactive.png';
  static String IC_MINUS_INACTIVE = '${IMAGE_COMICS_PATH}ic_minus_inactive.png';
  static String IC_MINUS = '${IMAGE_COMICS_PATH}ic_minus.png';
  static String IMG_SPLASH = '${IMAGE_COMMON_PATH}img_splash.png';
  static String IMG_BG_GRAY_BTN = '${IMAGE_COMMON_PATH}img_bg_gray_btn.png';
  static String IMG_UPGRADE_TOP = '${IMAGE_COMMON_PATH}img_upgrade_top.png';
  static String BTN_UPGRADE_NOW = '${IMAGE_COMMON_PATH}btn_upgrade_now.png';
  static String IC_PLAY_NUM = '${IMAGE_COMMON_PATH}ic_play_num.png';
  static String IC_REWARD = '${IMAGE_COMMON_PATH}ic_reward.png';
  static String IC_RANK = '${IMAGE_COMMON_PATH}ic_rank.png';
  static String IC_PRE_SEARCH = '${IMAGE_INPUT_PATH}ic_pre_search.png';
  static String IC_SUF_CLEAR = '${IMAGE_INPUT_PATH}ic_suf_clear.png';
  static String IC_VIDEO_BACK = '${IMAGE_COMMON_PATH}ic_video_back.png';
  static String IC_PLAY = '${IMAGE_COMMON_PATH}ic_play.png';
  static String IC_PAUSE = '${IMAGE_COMMON_PATH}ic_pause.png';
  static String IC_SHARE = '${IMAGE_COMMON_PATH}ic_share.png';
  static String IC_NO_LIKE = '${IMAGE_COMMON_PATH}ic_no_like.png';
  static String IC_LIKED = '${IMAGE_COMMON_PATH}ic_liked.png';
  static String IC_REPORT = '${IMAGE_COMMON_PATH}ic_report.png';
  static String IC_REPORTED = '${IMAGE_COMMON_PATH}ic_reported.png';
  static String IC_DOWNLOAD = '${IMAGE_COMMON_PATH}ic_download.png';
  static String IC_DOWNLOAD_UNABLE =
      '${IMAGE_COMMON_PATH}ic_download_unable.png';
  static String SOUND_MIN_N = '${IMAGE_COMMON_PATH}sound_min_n.png';
  static String SOUND_MAX_N = '${IMAGE_COMMON_PATH}sound_max_n.png';
  static String IC_FULL_SCREEN = '${IMAGE_COMMON_PATH}ic_full_screen.png';
  static String IC_FULL_SCREEN_S = '${IMAGE_COMMON_PATH}ic_full_screen_s.png';
  static String IC_EXIT_FULL_SCREEN =
      '${IMAGE_COMMON_PATH}ic_exit_full_screen.png';
  static String IC_REPLAY = '${IMAGE_COMMON_PATH}ic_replay.png';
  static String IC_VIDEO_PLAY = '${IMAGE_VIDEO_PATH}ic_video_play.png';
  static String BG_UNLOCK_WATCH_WHOLE =
      '${IMAGE_VIDEO_PATH}bg_unlock_watch_whole.png';
  static String BTN_GRADIENT = '${IMAGE_BUTTON_PATH}btn_gradient.png';
  static String BTN_GRADIENT_S = '${IMAGE_BUTTON_PATH}btn_gradient_s.png';
  static String LAYER_GRADIENT_SMALL =
      '${IMAGE_COMMON_PATH}layer_gradient_small.png';
  static String LAYER_GRADIENT_LARGE =
      '${IMAGE_COMMON_PATH}layer_gradient_large.png';
  static String GRADIENT_LAYER_MID = '${IMAGE_COMMON_PATH}gradient_layer_mid.png';
  static String IC_WHITE_PAUSE = '${IMAGE_COMMON_PATH}ic_white_pause.png';
  static String IC_WHITE_PLAY = '${IMAGE_COMMON_PATH}ic_white_play.png';
  static String IC_SLIDER_BAR = '${IMAGE_COMMON_PATH}ic_slider_bar.png';
  static String IC_COMMENT = '${IMAGE_COMMON_PATH}ic_comment.png';
  static String IC_BADGE_USER_VIP = '${IMAGE_COMMON_PATH}ic_badge_user_vip.png';
  static String IC_WARN = '${IMAGE_COMMON_PATH}ic_warn.png';
  static String BG_BTN_GRADIENT = '${IMAGE_COMMON_PATH}bg_btn_gradient.png';
  static String BTN_SMALL = '${IMAGE_BUTTON_PATH}btn_small.png';
  static String BTN_MIDDLE = '${IMAGE_BUTTON_PATH}btn_middle.png';
  static String BTN_MIDDLE_S = '${IMAGE_BUTTON_PATH}btn_middle_s.png';
  static String BTN_BUY_BIG = '${IMAGE_BUTTON_PATH}btn_buy_big.png';
  static String BTN_PINK = '${IMAGE_BUTTON_PATH}btn_pink.png';
  static String BTN_DATING_FILTER = '${IMAGE_BUTTON_PATH}btn_dating_filter.png';
  static String BTN_FILTER_SUBMIT = '${IMAGE_BUTTON_PATH}btn_filter_submit.png';
  static String BG_RANK_MEILI = '${IMAGE_CHAT_PATH}bg_rank_meili.png';
  static String BG_RANK_TUHAO = '${IMAGE_CHAT_PATH}bg_rank_tuhao.png';
  static String TAB_TUHAO = '${IMAGE_CHAT_PATH}tab_tuhao.png';
  static String TAB_MEILI = '${IMAGE_CHAT_PATH}tab_meili.png';
  static String AVATAR_BORDER_1 = '${IMAGE_CHAT_PATH}avatar_border_1.png';
  static String AVATAR_BORDER_23 = '${IMAGE_CHAT_PATH}avatar_border_23.png';
  static String AVATAR_BORDER_GOLD_1 = '${IMAGE_CHAT_PATH}avatar_border_gold_1.png';
  static String AVATAR_BORDER_GOLD_23 = '${IMAGE_CHAT_PATH}avatar_border_gold_23.png';
}
